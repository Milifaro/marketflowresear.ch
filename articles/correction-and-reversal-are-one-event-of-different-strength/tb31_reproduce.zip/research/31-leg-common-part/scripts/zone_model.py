"""Модель констатації: звичайна подія, зона корекції чи зона півота.

Дослідження: research/31-leg-common-part/
Правила: rules/03-models.md → Розбиття по часу, rules/01-data-and-db.md

Розмітку дає [`zones.py`](zones.py): кожна подія ноги — один із трьох
видів. Тут на ній вчиться модель, яка **констатує** вид поточної події
за самими фічами класу.

Два вікна, і різниця між ними принципова:

| вікно | що бачить модель | що це означає |
| ----- | ---------------- | ------------- |
| `causal` | `W` подій, що закінчуються на поточній | те, що можна порахувати наживо |
| `centered` | `W` подій навколо поточної, з майбутнім | стеля констатації: скільки в сигналі взагалі є |

Вхід моделі — рівні семи фіч у вікні, зведені чотирма числами на фічу
(середнє, останнє, розкид, розмах) плюс значення самої події: 7 × 5 =
**35 чисел**. Лічильника від півота у вході немає навмисне: він знає
відповідь на питання, яке ставиться.

Рівні — ранги, **зняті з train** (`rules/01-data-and-db.md` → Скейлер,
порахований на train): val міряється лінійкою train, інакше вибірка
підказує собі свій розподіл.

Розбиття — **по часу** (`rules/03-models.md`): межа `train | val` та
сама, що в датасеті (перший час у `val.npz`). Зони, які лежать на межі,
відкидаються цілком — інакше та сама зона стояла б в обох вибірках.

Базові прогнози, поруч з якими читається модель:

| базовий | що це |
| ------- | ----- |
| `majority` | завжди «звичайна подія» — частка звичайних у val |
| `prior` | випадкова відповідь за частками класів train |

Вхід : results/zones_<PAIR>_<клас>.json + датасет класу
Вихід: results/zone_model_<PAIR>_<клас>.json

Запуск:
    python3 research/31-leg-common-part/scripts/zone_model.py
    python3 research/31-leg-common-part/scripts/zone_model.py --window 21
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from zones import MARKS, Zones  # noqa: E402
from opposite import auc_of  # noqa: E402
from leg_common import (CLASS, PAIR, PARTS, REDUCE, REDUCERS,  # noqa: E402
                        RESULTS, curves_of, kept_legs, load, pivots_of,
                        reduce_blocks)

sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
from build_class210x10x7dc import PAIRS  # noqa: E402
from scalers import quantile_apply, quantile_fit  # noqa: E402

WINDOW = 11               # скільки подій бачить модель
KINDS = ("causal", "centered")
SEED = 0
PARAMS = {"max_iter": 300, "max_depth": 6, "learning_rate": 0.06,
          "l2_regularization": 1.0, "random_state": SEED}


def ranks_from_train(data: dict, inside: np.ndarray, cut: int,
                     reduce: str) -> np.ndarray:
    """Рівні фіч у рангах, знятих **тільки з train**: (події, фічі)."""
    out = np.full((len(data["t"]), len(data["features"])), np.nan)
    learn = inside & (data["t"] < cut)
    for index in range(len(data["features"])):
        column = reduce_blocks(data["x"][..., index], reduce)
        good = learn & np.isfinite(column)
        if good.sum() < 10:
            continue
        knots = quantile_fit(column[good])
        seen = inside & np.isfinite(column)
        out[seen, index] = quantile_apply(column[seen], knots)
    return out


def windows(levels: np.ndarray, where: np.ndarray, size: int,
            kind: str) -> tuple[np.ndarray, np.ndarray]:
    """Вікно навколо кожної події: (події, 7 × 5) і прапорець готовності.

    Вікно не виходить за межі **своєї ноги**: подія сусідньої ноги в
    ньому означала б, що модель дивиться через півот, а саме його вона
    й має знайти.
    """
    count, features = levels.shape
    rows = np.full((count, features * 5), np.nan)
    ready = np.zeros(count, dtype=bool)
    back = size - 1 if kind == "causal" else size // 2
    ahead = 0 if kind == "causal" else size - 1 - size // 2
    for leg in np.unique(where[where > 0]):
        piece = np.flatnonzero(where == leg)
        block = levels[piece]
        for place in range(len(piece)):
            first, last = place - back, place + ahead
            if first < 0 or last >= len(piece):
                continue
            view = block[first:last + 1]
            if not np.isfinite(view).all():
                continue
            rows[piece[place]] = np.concatenate([
                view.mean(axis=0), view[-1], view.std(axis=0),
                view.max(axis=0) - view.min(axis=0), block[place]])
            ready[piece[place]] = True
    return rows, ready


def columns(names: list) -> list:
    """Імена 35 колонок входу — у тому самому порядку, що й числа."""
    return ([f"{name}·середнє" for name in names]
            + [f"{name}·останнє" for name in names]
            + [f"{name}·розкид" for name in names]
            + [f"{name}·розмах" for name in names]
            + [f"{name}·подія" for name in names])


SHARES = (0.001, 0.005, 0.01, 0.02, 0.05)   # верхівки для точності


def top_share(scores: np.ndarray, yes: np.ndarray) -> list:
    """Точність верхівки: скільки правди в найвпевненіших відповідях.

    Класи рідкі, тому `argmax` мовчить — читати модель треба порогом.
    """
    order = np.argsort(scores)[::-1]
    base = float(yes.mean())
    out = []
    for share in SHARES:
        count = max(1, int(len(scores) * share))
        pick = order[:count]
        precision = float(yes[pick].mean())
        out.append({"share": share, "events": count,
                    "limit": float(scores[pick[-1]]),
                    "precision": precision,
                    "lift": precision / base if base else None,
                    "recall": float(yes[pick].sum() / max(yes.sum(), 1))})
    return out


def metrics(truth: np.ndarray, proba: np.ndarray, share: dict) -> dict:
    """AUC кожного класу проти решти, влучність і матриця помилок."""
    guess = proba.argmax(axis=1)
    out = {"events": int(len(truth)),
           "accuracy": float((guess == truth).mean()),
           "majority": max(share.values()),
           "prior": float(sum(value ** 2 for value in share.values())),
           "by_class": {}, "confusion": []}
    for index, name in enumerate(MARKS):
        yes = truth == index
        out["by_class"][name] = {
            "events": int(yes.sum()),
            "share": float(yes.mean()),
            "auc": auc_of(proba[yes, index], proba[~yes, index]),
            "precision": (float((truth[guess == index] == index).mean())
                          if (guess == index).any() else None),
            "recall": float((guess[yes] == index).mean()) if yes.any()
            else None,
            "top": top_share(proba[:, index], yes)}
    for index in range(len(MARKS)):
        out["confusion"].append([int(((truth == index) & (guess == other))
                                     .sum()) for other in range(len(MARKS))])
    return out


def coin_rows(pair: str, class_name: str, reduce: str, part: str, size: int,
              kind: str, limit: float | None,
              root: Path | None) -> dict:
    """Один ряд монети: вікна, мітки, час і скільки в ній зон."""
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    curves = curves_of(data, where > 0, reduce)
    zones = Zones(data, where, legs, curves,
                  **({"limit": limit} if limit is not None else {}))
    zones.run()
    cut = int(data["cut"])
    levels = ranks_from_train(data, where > 0, cut, reduce)
    rows, ready = windows(levels, where, size, kind)
    # зона, що лежить на межі train|val, не йде нікуди: інакше та сама
    # зона вчила б модель і перевіряла її
    edge = np.zeros(len(data["t"]), dtype=bool)
    for zone in zones.zones:
        piece = slice(zone["first"], zone["last"] + 1)
        if (data["t"][piece] < cut).any() and (data["t"][piece] >= cut).any():
            edge[piece] = True
    take = ready & ~edge
    return {"pair": pair, "rows": rows[take], "labels": zones.mark[take],
            "t": data["t"][take], "price": data["open"][take], "cut": cut,
            "ema": zones.smooth_price[take],
            "pivots": [one for one in pivots_of(data)],
            "zones_list": zones.records(), "legs": counts["legs_kept"],
            "limit": zones.limit, "dropped_edge": int(edge.sum()),
            "features": list(data["features"]),
            "zones": {name: sum(1 for one in zones.zones
                                if one["kind"] == name)
                      for name in ("pivot", "correction")},
            "zones_val": {name: sum(1 for one in zones.zones
                                    if one["kind"] == name
                                    and data["t"][one["at"]] >= cut)
                          for name in ("pivot", "correction")}}


def build(pair: str = PAIR, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", size: int = WINDOW, limit: float | None = None,
          root: Path | None = None, pairs: tuple | None = None,
          series: str | None = None) -> dict:
    from sklearn.ensemble import HistGradientBoostingClassifier

    coins = tuple(pairs) if pairs else (pair,)
    report = {
        "script": "research/31-leg-common-part/scripts/zone_model.py",
        "pair": pair, "pairs": list(coins), "class": class_name, "part": part,
        "reduce": reduce, "window": size, "kinds": list(KINDS),
        "marks": list(MARKS), "seed": SEED, "params": PARAMS,
        "by_kind": {},
    }

    for kind in KINDS:
        blocks = [coin_rows(one, class_name, reduce, part, size, kind, limit,
                            root) for one in coins]
        report.setdefault("features", blocks[0]["features"])
        report.setdefault("columns", columns(blocks[0]["features"]))
        report.setdefault("cut", blocks[0]["cut"])
        report.setdefault("limit", blocks[0]["limit"])
        report.setdefault("legs", sum(one["legs"] for one in blocks))
        report.setdefault("zones", {
            name: sum(one["zones"][name] for one in blocks)
            for name in ("pivot", "correction")})
        report.setdefault("dropped_edge",
                          sum(one["dropped_edge"] for one in blocks))
        report.setdefault("by_pair", {
            one["pair"]: {"legs": one["legs"], "zones": one["zones"],
                          "zones_val": one["zones_val"]} for one in blocks})

        rows = np.concatenate([one["rows"] for one in blocks])
        labels = np.concatenate([one["labels"] for one in blocks])
        stamps = np.concatenate([one["t"] for one in blocks])
        price = np.concatenate([one["price"] for one in blocks])
        coin = np.concatenate([np.full(len(one["t"]), index)
                               for index, one in enumerate(blocks)])
        cuts = np.concatenate([np.full(len(one["t"]), one["cut"])
                               for one in blocks])
        train, test = stamps < cuts, stamps >= cuts
        if train.sum() < 100 or test.sum() < 50:
            report["by_kind"][kind] = {"ready": False,
                                       "train": int(train.sum()),
                                       "val": int(test.sum())}
            continue
        share = {name: float((labels[train] == index).mean())
                 for index, name in enumerate(MARKS)}
        model = HistGradientBoostingClassifier(**PARAMS)
        model.fit(rows[train], labels[train])
        report["by_kind"][kind] = {
            "ready": True, "train": int(train.sum()), "val": int(test.sum()),
            "share_train": share,
            "val_metrics": metrics(labels[test],
                                   model.predict_proba(rows[test]),
                                   {name: float((labels[test] == index).mean())
                                    for index, name in enumerate(MARKS)}),
            "train_metrics": metrics(labels[train],
                                     model.predict_proba(rows[train]), share),
            "zones_val": {name: sum(one["zones_val"][name] for one in blocks)
                          for name in ("pivot", "correction")},
            # та сама модель, але видача кожної монети окремо: спільне
            # число ховає монету, у якій зон майже немає
            "by_pair": {
                one["pair"]: metrics(
                    labels[test & (coin == index)],
                    model.predict_proba(rows[test & (coin == index)]),
                    {name: float((labels[test & (coin == index)] == mark)
                                 .mean())
                     for mark, name in enumerate(MARKS)})
                for index, one in enumerate(blocks)
                if (test & (coin == index)).sum() > 50}}
        if series and series in coins:
            index = coins.index(series)
            pick = test & (coin == index)
            block = blocks[index]
            stamp = stamps[pick]
            proba = model.predict_proba(rows[pick])
            report.setdefault("series", {})[kind] = {
                "pair": series, "window": kind, "events": int(pick.sum()),
                "class": class_name, "size": size,
                "from": int(stamp.min()), "to": int(stamp.max()),
                "marks": list(MARKS),
                "auc": {name: report["by_kind"][kind]["by_pair"][series]
                        ["by_class"][name]["auc"] for name in MARKS},
                "counts": {name: int((labels[pick] == mark).sum())
                           for mark, name in enumerate(MARKS)},
                "t": [int(one) for one in stamp],
                "price": [round(float(one), 2) for one in price[pick]],
                "ema": [round(float(one), 2) for one in block["ema"][
                    np.isin(block["t"], stamp)]],
                "label": [int(one) for one in labels[pick]],
                "pivots": [one for one in block["pivots"]
                           if stamp.min() <= one["t"] <= stamp.max()],
                "zones": [one for one in block["zones_list"]
                          if one["to_t"] >= stamp.min()
                          and one["from_t"] <= stamp.max()],
                **{f"p_{name}": [round(float(one), 4)
                                 for one in proba[:, mark]]
                   for mark, name in enumerate(MARKS)}}
    return report


def save(report: dict, results: Path = RESULTS) -> Path:
    """Звіт і — окремим файлом — ряд val тієї монети, яку просили.

    Ряд важить більше за весь звіт, а читає його інша вкладка, тому він
    не лежить усередині.
    """
    results.mkdir(parents=True, exist_ok=True)
    tail = "all" if len(report["pairs"]) > 1 else report["pairs"][0]
    series = report.pop("series", None)
    path = results / f"zone_model_{tail}_{report['class']}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    if series:
        pair = next(iter(series.values()))["pair"]
        (results / f"zone_series_{pair}_{report['class']}.json").write_text(
            json.dumps(series, ensure_ascii=False), encoding="utf-8")
    return path


def show(report: dict) -> None:
    def number(value, digits=3):
        return "—" if value is None else f"{value:.{digits}f}"

    print(f"{', '.join(report['pairs'])} · {report['class']} · вікно "
          f"{report['window']} "
          f"подій · зон: півот {report['zones']['pivot']}, корекція "
          f"{report['zones']['correction']} · на межі відкинуто "
          f"{report['dropped_edge']} подій")
    for kind in report["kinds"]:
        block = report["by_kind"][kind]
        if not block.get("ready"):
            print(f"\n{kind}: замало рядків "
                  f"({block['train']} / {block['val']})")
            continue
        val = block["val_metrics"]
        print(f"\nвікно {kind}: train {block['train']}, val {block['val']} "
              f"подій · зон у val: півот {block['zones_val']['pivot']}, "
              f"корекція {block['zones_val']['correction']}")
        print(f"  влучність {number(val['accuracy'])} проти "
              f"{number(val['majority'])} у «завжди звичайна»")
        print(f"  {'клас':<12}{'подій':>8}{'частка':>8}{'AUC':>7}"
              f"{'точність':>10}{'повнота':>9}")
        for name in MARKS:
            one = val["by_class"][name]
            print(f"  {name:<12}{one['events']:>8}{number(one['share']):>8}"
                  f"{number(one['auc']):>7}{number(one['precision']):>10}"
                  f"{number(one['recall']):>9}")
        for name, one in (block.get("by_pair") or {}).items():
            top = one["by_class"]["pivot"]["top"][2]
            print(f"    {name:<10} val {one['events']:>6} подій · "
                  f"AUC півот {number(one['by_class']['pivot']['auc'])} · "
                  f"верхівка 1 % {top['precision'] * 100:>5.1f} % "
                  f"(×{top['lift']:.1f})")
        print(f"  верхівка ймовірності «півот»: "
              + ", ".join(
                  f"{one['share'] * 100:g} % -> {one['precision'] * 100:.1f} % "
                  f"(×{one['lift']:.1f})"
                  for one in val["by_class"]["pivot"]["top"]))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--limit", type=float, default=None)
    parser.add_argument("--pairs", default=None,
                        help="перелік монет через кому або 'all'")
    parser.add_argument("--series", default=None,
                        help="монета, чию видачу на val зберегти рядом")
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()

    chosen = None
    if args.pairs:
        chosen = PAIRS if args.pairs == "all" else tuple(args.pairs.split(","))
    report = build(args.pair, args.class_name, args.reduce, args.part,
                   args.window, args.limit, pairs=chosen, series=args.series)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
