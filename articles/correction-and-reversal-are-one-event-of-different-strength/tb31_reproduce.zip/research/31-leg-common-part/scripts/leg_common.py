"""Спільна складова ноги: рівень фічі, однаковий для всіх подій ноги.

Дослідження: research/31-leg-common-part/
Правила: rules/01-data-and-db.md → `клас210х10-1х7д/д`, rules/02-markup.md

Питання. Події ноги зігзага 2.3 % тримають спільний рівень: усередині
однієї ноги сім фіч `клас210х10-1х7д/д` стоять не там, де в сусідній.
Цей спільний рівень — **розмір події ноги** — і є те, що в кожній події
однакове. Він нічого не каже про саму подію: щоб побачити події, які
виділяються, його треба зняти.

Хід:

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 % -> ноги
    -> ноги вгору і ноги вниз нарізно
    -> величина події = згортка девʼяти блоків фічі -> ранг по монеті
    -> база ноги = середній рівень **попередньої ноги того самого напрямку**
    -> залишок = рівень події − база

База береться з **попередньої** ноги свого напрямку, а не з власної:
власне середнє ноги знає все, що в нозі сталось, і віднімати його —
це дивитись уперед. Попередня нога того самого напрямку закінчилась до
першої події цієї, тому відняти її рівень можна на будь-якій події
в реальному часі.

Рівень міряється **рангами** серед подій ніг монети: фічі класу —
відношення похідних, у них немає скінченного розкиду, і середнє сирих
чисел не значить нічого (rules/01-data-and-db.md → `клас210х10-1х7д/д`).
Ранг 0…1, рівень ряду 0.5. Криві дві:

    ранг      ранг самої величини: куди схилена фіча
    амплітуда ранг |величини|: наскільки подія велика, без напрямку

Сама амплітуда і є «розмір події» в тій постановці, з якої починалось
питання; ранг лишається поруч, бо спільна складова буває і в знаку.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_common_<PAIR>_<клас>.json       — перелік ніг і зведення
       results/leg_common_<PAIR>_<клас>.meta.json  — те саме без переліку ніг
       results/legs/leg_common_<PAIR>_<клас>_<нога>.json — ряд однієї ноги

Запуск:
    python3 research/31-leg-common-part/scripts/leg_common.py
    python3 research/31-leg-common-part/scripts/leg_common.py \
        --pair BTC_USDT --class class210x10m1x7dd --reduce mean
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
# розмітка ноги і згортки події — той самий хід, що в дослідженнях 28 і 30
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
INLEG_SCRIPTS = PROJECT_ROOT / "research" / "30-inleg-events" / "scripts"
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(INLEG_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from edge_profile import HOLE, PERIOD, THRESHOLD, legs_of  # noqa: E402
from inleg_profile import PARTS, load, ranks, reduce_blocks  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
CLASS = "class210x10m1x7dd"
REDUCE = "mean"                  # згортка девʼяти блоків події в одне число
REDUCERS = ("mean", "first", "last", "peak", "spread", "slope")
CURVES = ("rank", "amplitude")   # ранг величини і ранг її модуля
LEVEL = 0.5                      # рівень ряду в рангах: пульна база
MIN_LEG = 20                     # коротша нога ні базою, ні ціллю не буває
KINDS = ("up", "down")


# ------------------------------------------------------------------- ноги

def kept_legs(data: dict) -> tuple[np.ndarray, list, dict]:
    """Ноги ряду, придатні до заміру, і номер ноги кожної події.

    Відкидаються ноги з дірою в ряді понад `HOLE` (як у дослідженнях 28,
    29 і 30) і коротші за `MIN_LEG` подій: у них немає ні свого рівня,
    ні права бути базою.
    """
    place, legs = legs_of(data)
    keep = [leg for leg in legs
            if leg["hole_hours"] * 3600 <= HOLE and leg["events"] >= MIN_LEG]
    where = np.zeros(len(data["t"]), dtype=np.int32)
    for number, leg in enumerate(keep, start=1):
        leg["leg"] = number
        where[leg["first"]:leg["last"] + 1] = number
    return where, keep, {"legs_found": len(legs), "legs_kept": len(keep),
                         "dropped": len(legs) - len(keep)}


def pivots_of(data: dict) -> list:
    """Півоти зігзага на ема10 — ті самі, якими нарізані ноги."""
    smooth = ema(data["open"], PERIOD)
    return [{"t": int(data["t"][pivot.index]), "kind": pivot.kind,
             "ema": float(smooth[pivot.index])}
            for pivot in zigzag(smooth, THRESHOLD)]


# --------------------------------------------------------------- величини

def curves_of(data: dict, inside: np.ndarray, reduce: str) -> dict:
    """Рівень кожної фічі на кожній події: `{крива: {фіча: масив}}`."""
    out = {curve: {} for curve in CURVES}
    for index, name in enumerate(data["features"]):
        column = reduce_blocks(data["x"][..., index], reduce)
        out["rank"][name] = ranks(column, inside)
        out["amplitude"][name] = ranks(np.abs(column), inside)
    return out


def mean_of(values: np.ndarray) -> float | None:
    good = np.isfinite(values)
    return float(values[good].mean()) if good.any() else None


def rms(values: np.ndarray) -> float | None:
    """Середньоквадратичне відхилення від нуля — розкид залишку."""
    good = values[np.isfinite(values)]
    return float(np.sqrt((good ** 2).mean())) if good.size else None


def spearman(left: list, right: list) -> float | None:
    """Спірмен двох коротких рядів по ногах."""
    left, right = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    good = np.isfinite(left) & np.isfinite(right)
    if good.sum() < 3:
        return None
    rank = [np.argsort(np.argsort(one[good], kind="stable"),
                       kind="stable").astype(float)
            for one in (left, right)]
    first, second = (one - one.mean() for one in rank)
    bottom = float(np.sqrt((first ** 2).sum() * (second ** 2).sum()))
    return float((first * second).sum() / bottom) if bottom else None


# ------------------------------------------------------------------ база

def build_legs(data: dict, where: np.ndarray, legs: list, curves: dict) -> list:
    """Кожній нозі — її власний рівень і база з попередньої ноги напрямку.

    Ноги йдуть по часу, тому попередня нога свого напрямку вже порахована
    до того, як починається ця: база причинна.
    """
    last = {kind: None for kind in KINDS}
    rows = []
    for leg in legs:
        piece = where == leg["leg"]
        own = {curve: {name: mean_of(values[piece])
                       for name, values in by_feature.items()}
               for curve, by_feature in curves.items()}
        base = last[leg["kind"]]
        row = {"leg": leg["leg"], "kind": leg["kind"], "events": leg["events"],
               "from": leg["from"], "to": leg["to"],
               "hole_hours": round(leg["hole_hours"], 3),
               "move": round(leg["move"], 5),
               "first": leg["first"], "last": leg["last"],
               "base_leg": None if base is None else base["leg"],
               "ready": base is not None,
               "own": own,
               "base": None if base is None else base["own"]}
        if base is not None:
            row["shift"] = {
                curve: {name: None if own[curve][name] is None
                        or base["own"][curve][name] is None
                        else own[curve][name] - base["own"][curve][name]
                        for name in own[curve]}
                for curve in CURVES}
        rows.append(row)
        last[leg["kind"]] = row
    return rows


def spread_report(data: dict, where: np.ndarray, rows: list,
                  curves: dict) -> dict:
    """Скільки розкиду знімає віднімання — три бази поруч.

    `pool` — подія проти рівня ряду (0.5), нічого не віднімається;
    `previous` — проти бази з попередньої ноги свого напрямку (причинна);
    `own` — проти середнього **своєї** ноги: стеля, недосяжна в реальному
    часі, бо середнє ноги відоме тільки після її кінця.
    """
    out = {}
    for kind in KINDS + ("all",):
        chosen = [row for row in rows
                  if row["ready"] and (kind == "all" or row["kind"] == kind)]
        block = {}
        for curve in CURVES:
            block[curve] = {}
            for name in data["features"]:
                values = curves[curve][name]
                pool, previous, own, levels, bases = [], [], [], [], []
                for row in chosen:
                    piece = values[where == row["leg"]]
                    piece = piece[np.isfinite(piece)]
                    if not piece.size or row["base"][curve][name] is None:
                        continue
                    pool.append(piece - LEVEL)
                    previous.append(piece - row["base"][curve][name])
                    own.append(piece - row["own"][curve][name])
                    levels.append(row["own"][curve][name])
                    bases.append(row["base"][curve][name])
                if not pool:
                    block[curve][name] = {"legs": 0}
                    continue
                block[curve][name] = {
                    "legs": len(pool),
                    "events": int(sum(one.size for one in pool)),
                    "pool": rms(np.concatenate(pool)),
                    "previous": rms(np.concatenate(previous)),
                    "own": rms(np.concatenate(own)),
                    "carry": spearman(bases, levels),
                    "level": float(np.mean(levels))}
        out[kind] = block
    return out


# --------------------------------------------------------------- збереження

def leg_series(data: dict, where: np.ndarray, row: dict, curves: dict,
               pivots: list, pair: str, class_name: str, reduce: str) -> dict:
    """Ряд однієї ноги: ціна, рівні фіч до віднімання і база під них."""
    piece = np.flatnonzero(where == row["leg"])
    # півот, з якого нога починається, стоїть на одну подію лівіше за її
    # першу подію: беремо його в ряд, щоб на графіку було видно обидва
    # кінці ноги. Рівні фіч на ньому — від попередньої ноги, тому в
    # підвалі вони порожні (`None`), і лінія починається з самої ноги.
    start = 1 if piece[0] > 0 else 0
    if start:
        piece = np.concatenate(([piece[0] - 1], piece))
    stamps = data["t"][piece]
    edges = [pivot for pivot in pivots
             if stamps[0] <= pivot["t"] <= stamps[-1]]
    values = {curve: {name: [None if index < start or not np.isfinite(one)
                             else round(one, 4)
                             for index, one in enumerate(by_feature[name][piece])]
                      for name in data["features"]}
              for curve, by_feature in curves.items()}
    return {"pair": pair, "class": class_name, "reduce": reduce,
            "script": "research/31-leg-common-part/scripts/leg_common.py",
            "leg": row["leg"], "kind": row["kind"], "base_leg": row["base_leg"],
            "ready": row["ready"], "events": int(piece.size),
            "start": start, "leg_events": row["events"],
            "from": row["from"], "to": row["to"], "move": row["move"],
            "features": list(data["features"]), "curves": list(CURVES),
            "level": LEVEL,
            "t": [int(one) for one in stamps],
            "price": [round(float(one), 2) for one in data["open"][piece]],
            "ema": [round(float(one), 2)
                    for one in ema(data["open"], PERIOD)[piece]],
            "pivots": edges,
            "values": values,
            "own": row["own"], "base": row["base"],
            "shift": row.get("shift")}


def build(pair: str = PAIR, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", root: Path | None = None) -> tuple[dict, list]:
    """Повний замір: зведення по ногах і ряд кожної ноги окремо."""
    if reduce not in REDUCERS:
        raise ValueError(f"невідома згортка: {reduce}")
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    inside = where > 0
    curves = curves_of(data, inside, reduce)
    rows = build_legs(data, where, legs, curves)
    pivots = pivots_of(data)
    report = {
        "script": "research/31-leg-common-part/scripts/leg_common.py",
        "pair": pair, "class": class_name, "part": part, "reduce": reduce,
        "reducers": list(REDUCERS), "curves": list(CURVES),
        "features": list(data["features"]),
        "threshold": THRESHOLD, "period": PERIOD, "deciles": None,
        "hole_hours": HOLE / 3600, "min_leg": MIN_LEG, "level": LEVEL,
        "events": int(len(data["t"])), "in_legs": int(inside.sum()),
        "from": int(data["t"][0]), "to": int(data["t"][-1]),
        "cut": int(data["cut"]),
        **counts,
        "with_base": sum(1 for row in rows if row["ready"]),
        "by_kind": {kind: sum(1 for row in rows if row["kind"] == kind)
                    for kind in KINDS},
        "spread": spread_report(data, where, rows, curves),
        "legs": [{key: value for key, value in row.items()
                  if key not in ("first", "last")} for row in rows],
    }
    series = [leg_series(data, where, row, curves, pivots, pair, class_name,
                         reduce) for row in rows]
    return report, series


def save(report: dict, series: list, results: Path = RESULTS) -> Path:
    """Звіт, його meta без переліку ніг і ряд кожної ноги окремим файлом."""
    results.mkdir(parents=True, exist_ok=True)
    (results / "legs").mkdir(parents=True, exist_ok=True)
    stem = f"leg_common_{report['pair']}_{report['class']}"
    path = results / f"{stem}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "legs"}
    meta["legs_listed"] = len(report["legs"])
    (results / f"{stem}.meta.json").write_text(
        json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    for one in series:
        (results / "legs" / f"{stem}_{one['leg']}.json").write_text(
            json.dumps(one, ensure_ascii=False), encoding="utf-8")
    return path


def show(report: dict) -> None:
    print(f"{report['pair']} · {report['class']} · згортка {report['reduce']}"
          f" · частина {report['part']}")
    print(f"подій {report['events']}, у ногах {report['in_legs']}, "
          f"ніг {report['legs_kept']} (відкинуто {report['dropped']}), "
          f"з базою {report['with_base']}")
    for kind in KINDS:
        block = report["spread"][kind]["amplitude"]
        print(f"\nноги {kind}: розкид амплітуди, rms")
        print(f"{'фіча':<22}{'пул':>8}{'попередня':>11}{'своя':>8}"
              f"{'перенос':>9}{'рівень':>8}")
        for name in report["features"]:
            one = block[name]
            if not one.get("legs"):
                continue
            carry = "—" if one["carry"] is None else f"{one['carry']:.3f}"
            print(f"{name:<22}{one['pool']:>8.3f}{one['previous']:>11.3f}"
                  f"{one['own']:>8.3f}{carry:>9}{one['level']:>8.3f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()

    report, series = build(args.pair, args.class_name, args.reduce, args.part)
    path = save(report, series, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
