"""LSTM з памʼяттю в кілька ніг на тих самих трьох видах події.

Дослідження: research/31-leg-common-part/
Правила: rules/03-models.md → Розбиття по часу, Навчання без свопа

Етап 5 ставив питання вікном в 11 подій: модель бачила рівно те, що
поруч. Тут те саме питання ставиться мережею з памʼяттю, яка веде ряд
подія за подією й **не забуває попередні ноги**.

Памʼять міряється ногами. Ряд монети ріжеться на блоки по `LEGS` ніг
підряд; усередині блока стан LSTM переноситься з події в подію й між
чанками TBPTT, а на початку блока обнуляється:

| `--legs` | що це означає |
| -------- | ------------- |
| 1 | памʼять на одну ногу — контроль: те, що вміє мережа без минулого |
| 3, 5 | памʼять у кілька ніг: мережа памʼятає, що було до цього розвороту |
| 0 | памʼять на весь ряд монети: стан не обнуляється взагалі |

Вхід на кожній події — рівні семи фіч класу в рангах, **знятих з train**
(`rules/01-data-and-db.md` → Скейлер, порахований на train), плюс
восьмий канал: частка пропущених фіч у цій події. Пропуск (нульовий
знаменник відношення похідних) заміняється рівнем ряду 0.5 — один NaN
на вході отруює весь подальший стан LSTM. Ніяких лічильників від
півота: вони знають відповідь.

Вихід — три логіти на **кожну** подію (звичайна / зона корекції / зона
півота). Голова буває двох видів, і це не дрібниця:

| `--head` | втрата | що з каналами |
| -------- | ------ | ------------- |
| `sigmoid` | три незалежні `BCEWithLogits` із `pos_weight` | кожен канал живе своєю шкалою й ходить від 0 до 1 |
| `softmax` | зважена крос-ентропія | канали ділять одиницю: рідкий клас притиснутий до сталої, і його видача виглядає пласкою смугою |

За замовчуванням `sigmoid`: під софтмаксом канал «зона корекції»
(11 % подій, AUC 0.70) стояв у смузі 0.30…0.43 при розкиді 0.065 —
на графіку це рівна лінія, з якої нічого не прочитати.

Класи стоять як 90 / 8 / 2 %, тому кожен канал іде зі своєю вагою
позитиву; без неї мережа відповідала б «звичайна» завжди.

Розбиття за часом: train — до межі датасету, val — після. Стан на межі
**переноситься** з train у val: train це минуле, і причинності це не
порушує. Зона, що лежить на межі, не йде нікуди.

Поруч читається бустинг етапу 5 (`zone_model.py`) на тому самому
розбитті й тій самій розмітці.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/zone_lstm_all_<клас>.json

Запуск:
    python3 research/31-leg-common-part/scripts/zone_lstm.py --legs 3
    python3 research/31-leg-common-part/scripts/zone_lstm.py \
        --memory 1,3,5,0 --epochs 8
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from zones import MARKS, Zones  # noqa: E402
from zone_model import SHARES, ranks_from_train, top_share  # noqa: E402
from opposite import auc_of  # noqa: E402
from leg_common import (CLASS, PAIR, PARTS, REDUCE, REDUCERS,  # noqa: E402
                        RESULTS, curves_of, kept_legs, load, pivots_of)

sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "19-leg-end-lstm"
                       / "scripts"))
from build_class210x10x7dc import PAIRS  # noqa: E402
from leg_end_train import device_name, no_swap  # noqa: E402

MEMORY = (1, 3, 5, 0)     # скільки ніг памʼяті міряємо; 0 — увесь ряд
LEGS = 3                  # скільки ніг у блоці за замовчуванням
CHUNK = 512               # довжина чанка TBPTT, подій
HIDDEN = 64
LAYERS = 2
DROPOUT = 0.1
LR = 0.003
EPOCHS = 8
SEED = 0
WEIGHT_CAP = 20.0         # стеля ваги рідкого класу
HEADS = ("sigmoid", "softmax")
HEAD = "sigmoid"          # голова: незалежні канали чи софтмакс
LOSSES = ("bce", "focal", "softmax")
LOSS = "bce"              # яка функція втрат на незалежних каналах
GAMMA = 2.0               # фокус focal-loss: наскільки гасити легкі події
CONFUSE = 0.0             # штраф за «корекцію на півоті», у частках втрати


def blocks_of(where: np.ndarray, legs: list, stamps: np.ndarray, cut: int,
              step: int, part: str, align: str = "events") -> list:
    """Блоки памʼяті: `step` ніг завдовжки; `step = 0` — уся частина.

    `align` каже, **де** блок починається, і це не дрібниця:

    | `align` | початок блока | чим платить |
    | ------- | ------------- | ----------- |
    | `events` | будь-де: блок це `step × медіана довжини ноги` подій | нічим — межа блока про ноги не знає |
    | `legs` | рівно на початку ноги | обнулення стану саме́ підказує, що тут півот |

    Тому за замовчуванням `events`: інакше мережа з памʼяттю в одну ногу
    дістає відповідь безплатно. Блок не перетинає межу train|val.
    """
    chosen = []
    for leg in legs:
        piece = np.flatnonzero(where == leg["leg"])
        if not piece.size:
            continue
        inside = (stamps[piece] < cut) if part == "train" \
            else (stamps[piece] >= cut)
        if not inside.all():          # нога на межі не йде нікуди
            continue
        chosen.append(piece)
    if not chosen:
        return []
    if step <= 0:
        return [np.concatenate(chosen)]
    if align == "legs":
        return [np.concatenate(chosen[start:start + step])
                for start in range(0, len(chosen), step)]
    line = np.concatenate(chosen)
    size = max(CHUNK, int(step * np.median([len(one) for one in chosen])))
    return [line[start:start + size] for start in range(0, len(line), size)
            if len(line[start:start + size]) >= CHUNK // 4]


def coin_data(pair: str, class_name: str, reduce: str, part: str,
              limit: float | None, root: Path | None) -> dict:
    """Ряд монети: канали, мітки й блоки ніг для train і val."""
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    curves = curves_of(data, where > 0, reduce)
    zones = Zones(data, where, legs, curves,
                  **({"limit": limit} if limit is not None else {}))
    zones.run()
    cut = int(data["cut"])
    levels = ranks_from_train(data, where > 0, cut, reduce)
    # Пропуск у фічі (нульовий знаменник відношення похідних) мережа
    # зʼїсти не може: один NaN на вході отруює весь подальший стан.
    # Ставимо на його місце рівень ряду 0.5 і додаємо восьмий канал —
    # частку пропущених фіч події, щоб мережа бачила сам факт пропуску.
    missing = ~np.isfinite(levels)
    levels = np.where(missing, 0.5, levels)
    levels = np.concatenate(
        [levels, missing.mean(axis=1, keepdims=True)], axis=1)
    # далі потрібні тільки канали й мітки: сам клас (десятки мегабайтів
    # на монету) у навчанні не бере участі й у памʼяті не тримається
    out = {"pair": pair, "levels": levels.astype(np.float32),
           "labels": zones.mark.copy(), "t": data["t"].copy(),
           "price": data["open"].copy(), "where": where,
           "pivots": pivots_of(data), "zone_records": zones.records(),
           "legs": [{key: leg[key] for key in
                     ("leg", "kind", "first", "last", "events")}
                    for leg in legs],
           "cut": cut,
           "counts": {name: sum(1 for one in zones.zones
                                if one["kind"] == name)
                      for name in ("pivot", "correction")}}
    del data, curves, zones
    return out


def build_net(channels: int, hidden: int = HIDDEN, layers: int = LAYERS,
              dropout: float = DROPOUT, seed: int = SEED):
    import torch
    from torch import nn

    torch.manual_seed(seed)

    class Zone(nn.Module):
        """LSTM по ряду подій -> три логіти на кожну подію."""

        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(channels, hidden, num_layers=layers,
                                batch_first=True, dropout=dropout
                                if layers > 1 else 0.0)
            self.norm = nn.LayerNorm(hidden)
            self.drop = nn.Dropout(dropout)
            self.head = nn.Linear(hidden, len(MARKS))

        def forward(self, x, state=None):
            out, state = self.lstm(x, state)
            return self.head(self.drop(self.norm(out))), state

    return Zone()


def class_weight(labels: np.ndarray, cap: float = WEIGHT_CAP,
                 head: str = HEAD):
    """Вага класу: для софтмакса — обернена частота, для сигмоїд —
    відношення «решта до класу» (`pos_weight` кожного каналу). Обидві
    зі стелею: 2 % проти 90 % інакше дають вагу під п'ятдесят."""
    share = np.array([(labels == index).mean() for index in
                      range(len(MARKS))], dtype=float)
    share = np.where((share > 0) & (share < 1), share, 0.5)
    if head == "sigmoid":
        return np.minimum((1 - share) / share, cap)
    weight = 1.0 / share
    return np.minimum(weight / weight.min(), cap)


def loss_for(head: str, weight, device: str, confuse: float = CONFUSE,
             gamma: float = GAMMA):
    """Функція втрат і спосіб читати вихід.

    | `head` | що рахується |
    | ------ | ------------ |
    | `bce` | три незалежні `BCEWithLogits` із власним `pos_weight` |
    | `focal` | те саме, але легкі події гасяться множником `(1−p)^γ` |
    | `softmax` | канали ділять одиницю: зважена крос-ентропія |

    `confuse` додає **прицільний штраф**: на подіях, де правда — зона
    півота, канал «зона корекції» штрафується ще раз із цією вагою.
    Саме ця помилка коштує дорого: модель каже «корекція» там, де
    насправді розворот.
    """
    import torch
    from torch import nn

    pull = None if weight is None else torch.tensor(weight,
                                                    dtype=torch.float32,
                                                    device=device)
    pivot = MARKS.index("pivot")
    correction = MARKS.index("correction")

    def hot_of(out, want):
        hot = torch.zeros_like(out)
        hot[torch.arange(len(want), device=out.device), want] = 1.0
        return hot

    def extra(out, want):
        """Штраф за «корекцію на півоті» — нуль, коли таких подій немає."""
        if confuse <= 0:
            return 0.0
        here = want == pivot
        if not bool(here.any()):
            return 0.0
        logit = out[here][:, correction]
        return confuse * nn.functional.binary_cross_entropy_with_logits(
            logit, torch.zeros_like(logit))

    if head == "softmax":
        inner = nn.CrossEntropyLoss(weight=pull)

        def loss_fn(out, want):
            return inner(out, want) + extra(out, want)

        return loss_fn, (lambda one: torch.softmax(one, dim=-1))

    if head == "focal":
        def loss_fn(out, want):
            hot = hot_of(out, want)
            raw = nn.functional.binary_cross_entropy_with_logits(
                out, hot, reduction="none")
            proba = torch.sigmoid(out)
            near = torch.where(hot > 0, proba, 1 - proba)
            wide = torch.ones_like(out) if pull is None else \
                torch.where(hot > 0, pull.expand_as(out),
                            torch.ones_like(out))
            return ((1 - near) ** gamma * raw * wide).mean() \
                + extra(out, want)

        return loss_fn, torch.sigmoid

    inner = nn.BCEWithLogitsLoss(pos_weight=pull)

    def loss_fn(out, want):
        return inner(out, hot_of(out, want)) + extra(out, want)

    return loss_fn, torch.sigmoid


def run_blocks(model, coins: list, part: str, step: int, device: str,
               chunk: int, train: bool, optimiser=None, weight=None,
               head: str = HEAD, confuse: float = CONFUSE,
               gamma: float = GAMMA):
    """Прохід по всіх блоках: навчання або видача.

    Стан переноситься всередині блока (TBPTT з відірваним градієнтом) і
    обнуляється на його початку — це і є памʼять у `step` ніг.
    """
    import torch
    from torch import nn

    loss_fn, answer = loss_for(head, weight, device, confuse, gamma)
    model.train(train)
    total, seen = 0.0, 0
    found, truth, place = [], [], []
    grad = torch.enable_grad() if train else torch.no_grad()
    with grad:
      for coin in coins:
          for piece in coin[f"blocks_{part}"]:
              x = torch.from_numpy(coin["levels"][piece].astype(np.float32)
                                   ).unsqueeze(0).to(device)
              y = torch.from_numpy(coin["labels"][piece].astype(np.int64)
                                   ).unsqueeze(0).to(device)
              state = None
              for start in range(0, x.shape[1], chunk):
                  view = x[:, start:start + chunk]
                  want = y[:, start:start + chunk]
                  if train:
                      optimiser.zero_grad()
                  out, state = model(view, state)
                  state = tuple(one.detach() for one in state)
                  loss = loss_fn(out.reshape(-1, len(MARKS)), want.reshape(-1))
                  if train:
                      loss.backward()
                      torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                      optimiser.step()
                  else:
                      found.append(answer(out)
                                   .reshape(-1, len(MARKS)).cpu().numpy())
                      truth.append(want.reshape(-1).cpu().numpy())
                      place.append(piece[start:start + chunk])
                  total += float(loss.detach()) * view.shape[1]
                  seen += view.shape[1]
    if train:
        return {"loss": total / max(seen, 1)}
    return {"loss": total / max(seen, 1),
            "proba": np.concatenate(found) if found else np.empty((0, 3)),
            "truth": np.concatenate(truth) if truth else np.empty(0),
            "index": np.concatenate(place) if place else np.empty(0, int)}


def mixup_of(truth: np.ndarray, proba: np.ndarray) -> dict:
    """Та сама помилка, за яку штрафуємо: «корекція» на зоні півота.

    Міра **рангова**: кожен канал переводиться в ранг серед усіх подій
    val, і на зонах півота рахується частка подій, де ранг корекції
    вищий за ранг півота. Сирі ймовірності тут не годяться: канал можна
    просто опустити вниз — плутанина зникне, а модель не покращає.
    """
    pivot, correction = MARKS.index("pivot"), MARKS.index("correction")
    here = truth == pivot
    if not here.any() or len(truth) < 2:
        return {"events": 0, "share": None, "level": None, "gap": None}
    rank = np.empty_like(proba)
    for column in range(proba.shape[1]):
        order = np.argsort(np.argsort(proba[:, column], kind="stable"),
                           kind="stable")
        rank[:, column] = (order + 0.5) / len(order)
    return {"events": int(here.sum()),
            "share": float((rank[here, correction]
                            > rank[here, pivot]).mean()),
            "level": float(proba[here, correction].mean()),
            "gap": float((rank[here, pivot]
                          - rank[here, correction]).mean())}


def metrics_of(truth: np.ndarray, proba: np.ndarray) -> dict:
    """AUC кожного класу проти решти, точність верхівки й плутанина."""
    out = {"events": int(len(truth)), "by_class": {},
           "mixup": mixup_of(truth, proba)}
    guess = proba.argmax(axis=1)
    out["accuracy"] = float((guess == truth).mean()) if len(truth) else None
    out["majority"] = float(max((truth == index).mean()
                                for index in range(len(MARKS)))) \
        if len(truth) else None
    for index, name in enumerate(MARKS):
        yes = truth == index
        out["by_class"][name] = {
            "events": int(yes.sum()), "share": float(yes.mean()),
            "auc": auc_of(proba[yes, index], proba[~yes, index]),
            "top": top_share(proba[:, index], yes) if yes.any() else []}
    return out


def train_one(coins: list, step: int, device: str, epochs: int, chunk: int,
              lr: float, seed: int, series: str | None = None,
              head: str = HEAD, confuse: float = CONFUSE,
              gamma: float = GAMMA, hidden: int = HIDDEN,
              layers: int = LAYERS, log=print) -> dict:
    """Одна памʼять: навчання, вибір епохи по val, видача."""
    import torch

    channels = coins[0]["levels"].shape[1]
    model = build_net(channels, hidden, layers, seed=seed).to(device)
    optimiser = torch.optim.Adam(model.parameters(), lr=lr)
    labels = np.concatenate([coin["labels"][np.concatenate(
        coin["blocks_train"])] for coin in coins])
    weight = class_weight(labels,
                          head="softmax" if head == "softmax" else "sigmoid")
    best, history = None, []
    frame, by_epoch = None, {}
    for epoch in range(1, epochs + 1):
        started = time.time()
        hurt = run_blocks(model, coins, "train", step, device, chunk, True,
                          optimiser, weight, head, confuse, gamma)
        got = run_blocks(model, coins, "val", step, device, chunk, False,
                         weight=weight, head=head, confuse=confuse,
                         gamma=gamma)
        block = metrics_of(got["truth"], got["proba"])
        row = {"epoch": epoch, "train_loss": hurt["loss"],
               "val_loss": got["loss"],
               "auc_pivot": block["by_class"]["pivot"]["auc"],
               "auc_correction": block["by_class"]["correction"]["auc"],
               "mixup": block["mixup"]["share"],
               "seconds": round(time.time() - started, 1)}
        history.append(row)
        auc = row["auc_pivot"]
        log(f"    епоха {epoch}: втрата train {hurt['loss']:.4f}, "
            f"val {got['loss']:.4f} · AUC півот "
            f"{'—' if auc is None else format(auc, '.3f')} · "
            f"{row['seconds']:.0f} с")
        if series:                 # видача кожної епохи, а не лише кращої
            frame = frame or series_frame(coins, got, series)
            answer = series_answer(coins, got, series)
            if answer is not None:
                by_epoch[str(epoch)] = {**answer, "auc_pivot": auc,
                                        "auc_correction":
                                            row["auc_correction"]}
        if auc is None:                 # епоха без відповіді в вибір не йде
            continue
        if best is None or auc > best["row"]["auc_pivot"]:
            best = {"row": row, "metrics": block, "proba": got["proba"],
                    "truth": got["truth"], "index": got["index"]}
    settled = [one["auc_pivot"] for one in history[2:]
               if one["auc_pivot"] is not None]
    steady = float(np.median(settled)) if settled else None
    if best is None:
        return {"history": history, "best_epoch": None, "ready": False,
                "weight": [float(one) for one in weight],
                "frame": frame, "by_epoch": by_epoch}
    return {"history": history, "best_epoch": best["row"]["epoch"],
            "steady_auc": steady,
            "val": best["metrics"], "weight": [float(one) for one in weight],
            "proba": best["proba"], "truth": best["truth"],
            "index": best["index"], "frame": frame, "by_epoch": by_epoch}


def coin_edges(coins: list) -> dict:
    """Де в зведеній видачі починається й закінчується кожна монета."""
    edges, at = {}, 0
    for coin in coins:
        size = sum(len(piece) for piece in coin["blocks_val"])
        edges[coin["pair"]] = (at, at + size)
        at += size
    return edges


def series_order(coins: list, out: dict, pair: str):
    """Місця подій однієї монети у зведеній видачі, впорядковані за часом."""
    coin = next((one for one in coins if one["pair"] == pair), None)
    if coin is None:
        return None, None, None
    low, high = coin_edges(coins)[pair]
    index = out["index"][low:high]
    order = np.argsort(index, kind="stable")   # блоки йдуть підряд, але
    return coin, index[order], low + order     # порядок відновлюємо явно


def series_answer(coins: list, out: dict, pair: str) -> dict | None:
    """Видача **однієї епохи**: три ймовірності на кожну подію ряду."""
    coin, _, place = series_order(coins, out, pair)
    if coin is None:
        return None
    proba = out["proba"][place]
    return {f"p_{name}": [round(float(one), 4) for one in proba[:, mark]]
            for mark, name in enumerate(MARKS)}


def series_frame(coins: list, out: dict, pair: str) -> dict | None:
    """Нерухома частина ряду: час, ціна, мітки, півоти й зони.

    Вона одна на всі епохи — по епохах міняється тільки видача.
    """
    coin, index, _ = series_order(coins, out, pair)
    if coin is None:
        return None
    stamps = coin["t"][index]
    return {"pair": pair, "events": int(len(index)),
            "from": int(stamps.min()), "to": int(stamps.max()),
            "marks": list(MARKS),
            "counts": {name: int((coin["labels"][index] == mark).sum())
                       for mark, name in enumerate(MARKS)},
            "t": [int(one) for one in stamps],
            "price": [round(float(one), 2) for one in coin["price"][index]],
            "label": [int(one) for one in coin["labels"][index]],
            "pivots": [one for one in coin["pivots"]
                       if stamps.min() <= one["t"] <= stamps.max()],
            "zones": [one for one in coin["zone_records"]
                      if one["to_t"] >= stamps.min()
                      and one["from_t"] <= stamps.max()]}


def by_pair_metrics(coins: list, out: dict) -> dict:
    """Видача, рознесена по монетах: спільне число ховає монету."""
    edges = coin_edges(coins)
    answer = {}
    for pair, (low, high) in edges.items():
        if high - low < 50:
            continue
        answer[pair] = metrics_of(out["truth"][low:high],
                                  out["proba"][low:high])
    return answer


def build(pairs=PAIRS, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", memory=MEMORY, epochs: int = EPOCHS,
          chunk: int = CHUNK, lr: float = LR, seed: int = SEED,
          limit: float | None = None, device: str | None = None,
          root: Path | None = None, align: str = "events",
          series: str | None = None, head: str = HEAD, log=print) -> dict:
    device = device or device_name()
    coins = [coin_data(one, class_name, reduce, part, limit, root)
             for one in pairs]
    report = {
        "script": "research/31-leg-common-part/scripts/zone_lstm.py",
        "pairs": list(pairs), "class": class_name, "part": part,
        "reduce": reduce, "marks": list(MARKS), "memory": list(memory),
        "epochs": epochs, "chunk": chunk, "hidden": HIDDEN, "layers": LAYERS,
        "dropout": DROPOUT, "lr": lr, "seed": seed, "device": device,
        "align": align, "head": head,
        "channels": int(coins[0]["levels"].shape[1]),
        "zones": {name: sum(coin["counts"][name] for coin in coins)
                  for name in ("pivot", "correction")},
        "by_memory": {},
    }
    for step in memory:
        for coin in coins:
            for name in ("train", "val"):
                coin[f"blocks_{name}"] = blocks_of(
                    coin["where"], coin["legs"], coin["t"], coin["cut"],
                    step, name, align)
        counts = {name: sum(len(coin[f"blocks_{name}"]) for coin in coins)
                  for name in ("train", "val")}
        log(f"  памʼять {step or 'увесь ряд'} ніг: блоків train "
            f"{counts['train']}, val {counts['val']}")
        if not counts["train"] or not counts["val"]:
            report["by_memory"][str(step)] = {"ready": False, **counts}
            continue
        out = train_one(coins, step, device, epochs, chunk, lr, seed,
                        series=series, head=head, log=log)
        if out.get("ready") is False:
            report["by_memory"][str(step)] = {"ready": False, **counts,
                                              "history": out["history"]}
            continue
        report["by_memory"][str(step)] = {
            "ready": True, "legs": step, "blocks": counts,
            "best_epoch": out["best_epoch"], "history": out["history"],
            "steady_auc": out["steady_auc"],
            "weight": out["weight"], "val": out["val"],
            "by_pair": by_pair_metrics(coins, out)}
        if series and out.get("frame"):
            report.setdefault("series", {})[str(step)] = {
                **out["frame"], "best_epoch": out["best_epoch"],
                "epochs": sorted(out["by_epoch"], key=int),
                "by_epoch": out["by_epoch"]}
    return report


def save(report: dict, results: Path = RESULTS) -> Path:
    """Звіт і — окремим файлом — ряд val монети, яку просили.

    Ряд важить більше за весь звіт, а читає його інший розділ вкладки.
    """
    results.mkdir(parents=True, exist_ok=True)
    tail = "" if report.get("align", "events") == "events" else "_legs"
    if report.get("head", HEAD) != HEAD:
        tail += f"_{report['head']}"
    series = report.pop("series", None)
    path = results / f"zone_lstm_all_{report['class']}{tail}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    if series:
        pair = next(iter(series.values()))["pair"]
        (results / f"zone_lstm_series_{pair}_{report['class']}{tail}.json"
         ).write_text(json.dumps(series, ensure_ascii=False),
                      encoding="utf-8")
    return path


def show(report: dict) -> None:
    def number(value, digits=3):
        return "—" if value is None else f"{value:.{digits}f}"

    print(f"\n{len(report['pairs'])} монет · клас {report['class']} · "
          f"LSTM {report['hidden']}×{report['layers']}, чанк "
          f"{report['chunk']}, {report['epochs']} епох, {report['device']}, "
          f"голова {report.get('head', HEAD)}")
    print(f"блоки: {report.get('align', 'events')}")
    print(f"{'памʼять':<12}{'епоха':>7}{'AUC півот':>11}{'медіана':>9}"
          f"{'AUC корекц':>12}{'верхівка 1 %':>14}{'підйом':>8}")
    for step in report["memory"]:
        block = report["by_memory"][str(step)]
        if not block.get("ready"):
            continue
        pivot = block["val"]["by_class"]["pivot"]
        top = pivot["top"][2] if len(pivot["top"]) > 2 else {}
        name = "увесь ряд" if step == 0 else f"{step} ніг"
        lift = "" if not top else f"×{top['lift']:.1f}"
        print(f"{name:<12}{block['best_epoch']:>7}"
              f"{number(pivot['auc']):>11}"
              f"{number(block.get('steady_auc')):>9}"
              f"{number(block['val']['by_class']['correction']['auc']):>12}"
              f"{(top.get('precision') or 0) * 100:>13.1f} %{lift:>8}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", default="all")
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--memory", default=None,
                        help="скільки ніг памʼяті, через кому; 0 — увесь ряд")
    parser.add_argument("--legs", type=int, default=None,
                        help="одна памʼять замість переліку")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--chunk", type=int, default=CHUNK)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--limit", type=float, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--align", default="events", choices=("events",
                                                              "legs"),
                        help="де починається блок памʼяті")
    parser.add_argument("--series", default=None,
                        help="монета, чию видачу на val зберегти рядом")
    parser.add_argument("--head", default=HEAD, choices=HEADS,
                        help="незалежні канали (sigmoid) чи софтмакс")
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--force", action="store_true",
                        help="почати навчання при малій вільній памʼяті")
    args = parser.parse_args()

    no_swap(force=args.force)        # rules/03 → Навчання без свопа
    pairs = PAIRS if args.pairs == "all" else tuple(args.pairs.split(","))
    memory = (args.legs,) if args.legs is not None else (
        tuple(int(one) for one in args.memory.split(","))
        if args.memory else MEMORY)
    report = build(pairs, args.class_name, args.reduce, args.part, memory,
                   args.epochs, args.chunk, args.lr, args.seed, args.limit,
                   args.device, align=args.align, series=args.series,
                   head=args.head)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
