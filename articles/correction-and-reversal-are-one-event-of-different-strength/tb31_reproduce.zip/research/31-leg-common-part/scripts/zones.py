"""Зона півота і зона корекції: де розворот, а де звичайні події ноги.

Дослідження: research/31-leg-common-part/
Правила: rules/01-data-and-db.md → `клас210х10-1х7д/д`, rules/02-markup.md

Півот зігзага — оцінка, а не подія. Ема зсуває екстремум, ряд подій
проріджений по 210 с, поріг 2.3 % підтверджується заднім числом. Тому
ділити ряд на «до півота» і «після півота» по одній події неправильно:
розворот займає **відрізок**.

Межа відрізка ставиться **за фічами класу**, а не за ціною:

    від точки розвороту йдемо ліворуч, поки подія відрізняється від
    середнього рівня своєї ноги; як тільки події стали звичайними —
    ліва межа знайдена. Так само праворуч, але вже проти середнього
    рівня **наступної** ноги.

Ліва половина належить хвосту старої ноги, права — голові нової, і
кожна міряється проти **своєї** ноги. Довжини половин не задані наперед
і між собою не рівні.

Те саме правило — для **корекцій**. Усередині ноги є місця, схожі на
розворот: ціна пішла проти ноги й повернулась. Вони знаходяться
вкладеним зігзагом `CORRECTION` (0.5 %) по тій самій ема, і навколо
кожної такої точки виділяється **зона корекції** — тим самим ходом, що
й зона півота, тільки обидві половини міряються проти однієї ноги.

Ряд ділиться на три види подій:

| мітка | що це |
| ----- | ----- |
| `regular` | звичайна подія ноги: рівень фіч не відрізняється від середнього ноги |
| `correction` | зона корекції: відрізок навколо вкладеного розвороту 0.5 % |
| `pivot` | зона півота: відрізок навколо розвороту 2.3 % |

Рівень події — ранг серед подій ніг монети (як у `leg_common`): сирі
відношення похідних не мають скінченного розкиду
(rules/01-data-and-db.md → `клас210х10-1х7д/д`).

Відхилення події від ноги — **робастний z по семи фічах**:

    z_f(t) = |ранг_f(t) − медіана_f(нога)| / IQR_f(нога)
    d(t)   = медіана по семи фічах z_f(t)

Медіана по фічах, а не середнє: одна фіча, що пішла в хвіст, не робить
зону сама. `d` згладжується ковзною медіаною `SMOOTH` подій — межа
ставиться по поведінці відрізка, а не по одній події.

Поріг «несхожа» — **квантиль `d` самої ноги** (`LIMIT`, типово 0.75), а
не стале число: розкид `d` у ніг різний, і один поріг на всіх дав би в
одній нозі зону на пів ноги, а в іншій — жодної події.

Зона виділена **за фічами**, тому порівнювати рівні фіч зони з рештою
ноги — частково замкнене коло. Поруч тому стоїть **контроль фіксованим
вікном**: ті самі міри на `±WINDOW` подіях навколо тієї самої точки, без
жодного погляду на фічі. Що є в обох — те справжнє.

Опора ноги (`медіана` і `IQR`) рахується **двічі**: спершу по середині
ноги (десятини 4–7), потім — по всіх подіях ноги, що не потрапили в
жодну зону. Інакше край ноги сам тягнув би опору на себе.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/zones_<PAIR>_<клас>.json       — зони, мітки, порівняння
       results/zones_<PAIR>_<клас>.meta.json  — те саме без переліку зон

Запуск:
    python3 research/31-leg-common-part/scripts/zones.py
    python3 research/31-leg-common-part/scripts/zones.py \
        --pair BTC_USDT --limit 0.75 --smooth 5 --patience 3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from opposite import auc_of, stat  # noqa: E402
from leg_common import (CLASS, CURVES, PAIR, PARTS, PERIOD,  # noqa: E402
                        REDUCE, REDUCERS, RESULTS, THRESHOLD, curves_of,
                        kept_legs, load, pivots_of)

sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

CORRECTION = 0.005        # поріг вкладеного зігзага: що вважати корекцією
# Поріг несхожості — **квантиль `d` самої ноги**, а не стале число:
# розкид `d` у ніг різний, і один поріг на всіх дав би в одній нозі
# зону на пів ноги, а в іншій — жодної події.
LIMIT = 0.75              # подія несхожа, поки `d` вище цього квантиля ноги
LIMITS = (0.5, 0.6, 0.7, 0.75, 0.8, 0.9)   # сітка для калібрування
WINDOW = 5                # фіксоване вікно навколо точки: контроль на замкненість
REACH = 40                # доки тягнути профіль `d` навколо точки, подій
SMOOTH = 5                # ковзна медіана `d`, подій
PATIENCE = 3              # скільки звичайних подій підряд закривають зону
MAX_SHARE = 0.25          # довша половина зони не буває: частка ноги
CORE = (4, 7)             # десятини ноги, з яких береться перша опора
MARKS = ("regular", "correction", "pivot")
CURVE = "rank"            # на якій кривій міряється несхожість


def rolling_median(values: np.ndarray, window: int) -> np.ndarray:
    """Ковзна медіана по центру; на краях вікно вкорочується."""
    if window <= 1:
        return values
    half = window // 2
    out = np.full(values.shape, np.nan)
    for index in range(len(values)):
        piece = values[max(0, index - half):index + half + 1]
        piece = piece[np.isfinite(piece)]
        if piece.size:
            out[index] = np.median(piece)
    return out


def leg_reference(levels: np.ndarray, keep: np.ndarray) -> tuple:
    """Опора ноги: медіана і IQR по фічах на подіях `keep`."""
    piece = levels[keep]
    if piece.shape[0] < 4:
        piece = levels
    center = np.nanmedian(piece, axis=0)
    spread = (np.nanquantile(piece, 0.75, axis=0)
              - np.nanquantile(piece, 0.25, axis=0))
    spread = np.where(np.isfinite(spread) & (spread > 1e-9), spread, 1.0)
    return center, spread


def deviation(levels: np.ndarray, center: np.ndarray, spread: np.ndarray,
              smooth: int = SMOOTH) -> np.ndarray:
    """`d` кожної події ноги: медіана робастних z по семи фічах."""
    z = np.abs(levels - center) / spread
    with np.errstate(invalid="ignore"):
        line = np.nanmedian(z, axis=1)
    return rolling_median(line, smooth)


def grow(line: np.ndarray, start: int, step: int, limit: float,
         patience: int, cap: int) -> int:
    """Скільки подій від `start` у бік `step` ще не схожі на ногу.

    Йдемо, поки `d` вище за `limit`; зупиняє `patience` звичайних подій
    поспіль, і повертається довжина **до них**. Нуль означає, що вже
    сусідня подія звичайна.
    """
    taken = 0
    calm = 0
    index = start
    while 0 <= index < len(line) and taken < cap:
        value = line[index]
        if not np.isfinite(value) or value < limit:
            calm += 1
            if calm >= patience:
                break
        else:
            taken += calm + 1
            calm = 0
        index += step
    return taken


class Zones:
    """Розмітка ряду на звичайні події, зони корекції й зони півота."""

    def __init__(self, data: dict, where: np.ndarray, legs: list,
                 curves: dict, limit: float = LIMIT, smooth: int = SMOOTH,
                 patience: int = PATIENCE, correction: float = CORRECTION):
        self.data = data
        self.where = where
        self.legs = legs
        self.limit, self.smooth = limit, smooth
        self.patience, self.correction = patience, correction
        self.names = list(data["features"])
        self.levels = np.stack([curves[CURVE][name] for name in self.names],
                               axis=1)
        self.smooth_price = ema(data["open"], PERIOD)
        self.piece = {leg["leg"]: np.flatnonzero(where == leg["leg"])
                      for leg in legs}
        self.mark = np.zeros(len(data["t"]), dtype=np.int8)
        self.line = np.full(len(data["t"]), np.nan)
        self.zones: list[dict] = []

    # ------------------------------------------------------------ опора

    def core_of(self, leg: dict) -> np.ndarray:
        """Перша опора — середина ноги, десятини 4–7."""
        piece = self.piece[leg["leg"]]
        place = np.floor(np.arange(len(piece)) / len(piece) * 10) + 1
        return (place >= CORE[0]) & (place <= CORE[1])

    def measure(self, keep: dict) -> None:
        """`d` кожної події ряду проти опори своєї ноги."""
        for leg in self.legs:
            piece = self.piece[leg["leg"]]
            center, spread = leg_reference(self.levels[piece],
                                           keep[leg["leg"]])
            self.line[piece] = deviation(self.levels[piece], center, spread,
                                         self.smooth)

    # ------------------------------------------------------------ зони

    def anchors(self) -> list[dict]:
        """Точки, навколо яких ростуть зони: півоти й корекції."""
        out = []
        for index, leg in enumerate(self.legs):
            nxt = self.legs[index + 1] if index + 1 < len(self.legs) else None
            if nxt is not None and leg["last"] + 1 == nxt["first"]:
                out.append({"kind": "pivot", "at": leg["last"],
                            "left_leg": leg, "right_leg": nxt})
            piece = self.piece[leg["leg"]]
            inner = zigzag(self.smooth_price[piece], self.correction)
            for pivot in inner:
                at = int(piece[pivot.index])
                if at in (piece[0], piece[-1]):
                    continue
                out.append({"kind": "correction", "at": at,
                            "left_leg": leg, "right_leg": leg,
                            "side": pivot.kind})
        return sorted(out, key=lambda one: one["at"])

    def cut_of(self, leg: dict) -> float:
        """Поріг ноги: квантиль `d` її власних подій."""
        piece = self.line[self.piece[leg["leg"]]]
        piece = piece[np.isfinite(piece)]
        return float(np.quantile(piece, self.limit)) if piece.size else np.inf

    def zone_of(self, anchor: dict) -> dict:
        """Межі однієї зони: ліворуч проти своєї ноги, праворуч проти своєї."""
        left_leg, right_leg = anchor["left_leg"], anchor["right_leg"]
        left_piece, right_piece = (self.piece[left_leg["leg"]],
                                   self.piece[right_leg["leg"]])
        at = anchor["at"]
        left_line = self.line[left_piece]
        right_line = self.line[right_piece]
        here_left = int(np.flatnonzero(left_piece == at)[0]) \
            if at in left_piece else len(left_piece) - 1
        here_right = int(np.flatnonzero(right_piece == at)[0]) \
            if at in right_piece else 0
        cap_left = max(1, int(len(left_piece) * MAX_SHARE))
        cap_right = max(1, int(len(right_piece) * MAX_SHARE))
        back = grow(left_line, here_left - 1, -1, self.cut_of(left_leg),
                    self.patience, cap_left)
        ahead = grow(right_line, here_right + 1, 1, self.cut_of(right_leg),
                     self.patience, cap_right)
        first = int(left_piece[max(0, here_left - back)])
        last = int(right_piece[min(len(right_piece) - 1, here_right + ahead)])
        return {"kind": anchor["kind"], "at": at, "left": back, "right": ahead,
                "first": first, "last": last,
                "leg_left": left_leg["leg"], "leg_right": right_leg["leg"],
                "side": anchor.get("side")}

    def carve(self) -> None:
        """Зони по всіх точках; півот сильніший за корекцію на перетині."""
        self.zones = [self.zone_of(one) for one in self.anchors()]
        self.mark[:] = 0
        for zone in sorted(self.zones,
                           key=lambda one: MARKS.index(one["kind"])):
            self.mark[zone["first"]:zone["last"] + 1] = \
                MARKS.index(zone["kind"])
        self.mark[self.where == 0] = 0

    def run(self, rounds: int = 2) -> None:
        """Опора — середина ноги, далі нога без зон. Два кола."""
        keep = {leg["leg"]: self.core_of(leg) for leg in self.legs}
        for step in range(rounds):
            self.measure(keep)
            self.carve()
            keep = {leg["leg"]: self.mark[self.piece[leg["leg"]]] == 0
                    for leg in self.legs}
            # нога, у якій зони з'їли все, лишається зі своєю серединою
            for leg in self.legs:
                if keep[leg["leg"]].sum() < 4:
                    keep[leg["leg"]] = self.core_of(leg)

    # -------------------------------------------------------- звіт

    def records(self) -> list:
        """Зони з часом, довжиною і розмахом ціни всередині."""
        out = []
        for zone in self.zones:
            piece = slice(zone["first"], zone["last"] + 1)
            price = self.data["open"][piece]
            leg = next(one for one in self.legs
                       if one["leg"] == zone["leg_left"])
            out.append({
                **{key: zone[key] for key in ("kind", "left", "right", "side",
                                              "leg_left", "leg_right")},
                "events": int(zone["last"] - zone["first"] + 1),
                "at_t": int(self.data["t"][zone["at"]]),
                "from_t": int(self.data["t"][zone["first"]]),
                "to_t": int(self.data["t"][zone["last"]]),
                "share_left": round(zone["left"] / leg["events"], 4),
                "span": round(float(price.max() / price.min() - 1), 5),
                "at_price": round(float(self.data["open"][zone["at"]]), 2),
            })
        return out


def profile(zones: Zones, kind: str, reach: int = REACH) -> dict:
    """Хід `d` навколо точки розвороту: чи є там узагалі підйом.

    Це перевірка самого правила: якщо `d` біля точки не вища, ніж у
    середині ноги, то й межа зони стоїть на шумі.
    """
    rows = []
    for zone in zones.zones:
        if zone["kind"] != kind:
            continue
        at = zone["at"]
        rows.append([zones.line[at + step]
                     if 0 <= at + step < len(zones.line)
                     and zones.where[at + step] > 0 else np.nan
                     for step in range(-reach, reach + 1)])
    if not rows:
        return {"ready": False}
    table = np.asarray(rows, dtype=float)
    with np.errstate(invalid="ignore"):
        curve = np.nanmedian(table, axis=0)
    base = float(np.nanmedian(zones.line[zones.where > 0]))
    far = float(np.nanmedian(curve[np.abs(np.arange(-reach, reach + 1))
                                   >= reach * 0.75]))
    return {"ready": True, "points": int(len(rows)), "reach": reach,
            "curve": [None if not np.isfinite(one) else round(float(one), 4)
                      for one in curve],
            "base": base, "far": far, "at": float(curve[reach]),
            "lift": float(curve[reach] / far - 1) if far else None}


def calibrate(data: dict, where: np.ndarray, legs: list, curves: dict,
              smooth: int, patience: int, correction: float,
              limits=LIMITS) -> list:
    """Як розмір зони залежить від порога — щоб поріг не був на віру."""
    out = []
    for limit in limits:
        zones = Zones(data, where, legs, curves, limit, smooth, patience,
                      correction)
        zones.run()
        records = zones.records()
        inside = where > 0
        row = {"limit": limit}
        for index, name in enumerate(MARKS):
            row[name] = round(float(((zones.mark == index)
                                     & inside).sum() / inside.sum()), 4)
        for kind in ("pivot", "correction"):
            rows = [one["events"] for one in records if one["kind"] == kind]
            row[f"{kind}_events"] = (round(float(np.mean(rows)), 2)
                                     if rows else None)
        out.append(row)
    return out


def fixed_window(zones: Zones, window: int = WINDOW) -> dict:
    """Контроль: ті самі три види, але межі — стале вікно навколо точки.

    Вікно про фічі не знає нічого, тому різниця, що лишилась тут, не
    може бути наслідком способу нарізки.
    """
    mark = np.zeros(len(zones.mark), dtype=np.int8)
    for zone in sorted(zones.zones, key=lambda one: MARKS.index(one["kind"])):
        at = zone["at"]
        mark[max(0, at - window):at + window + 1] = MARKS.index(zone["kind"])
    mark[zones.where == 0] = 0
    return marks_report(zones, mark)


def marks_report(zones: Zones, mark: np.ndarray) -> dict:
    """Рівні фіч і AUC трьох видів подій за готовою розміткою."""
    inside = zones.where > 0
    picks = {name: inside & (mark == index)
             for index, name in enumerate(MARKS)}
    out = {"counts": {name: int(pick.sum()) for name, pick in picks.items()},
           "by_feature": {}, "deviation": {}}
    for name, pick in picks.items():
        piece = zones.line[pick]
        piece = piece[np.isfinite(piece)]
        out["deviation"][name] = {
            "mean": float(piece.mean()) if piece.size else None,
            "median": float(np.median(piece)) if piece.size else None}
    for index, feature in enumerate(zones.names):
        values = zones.levels[:, index]
        block = {}
        for name, pick in picks.items():
            piece = values[pick]
            piece = piece[np.isfinite(piece)]
            block[name] = {"level": float(piece.mean()) if piece.size else None,
                           "events": int(piece.size)}
        block["auc"] = {
            "pivot_regular": auc_of(values[picks["pivot"]],
                                    values[picks["regular"]]),
            "correction_regular": auc_of(values[picks["correction"]],
                                         values[picks["regular"]]),
            "pivot_correction": auc_of(values[picks["pivot"]],
                                       values[picks["correction"]])}
        out["by_feature"][feature] = block
    out["auc_deviation"] = {
        "pivot_regular": auc_of(zones.line[picks["pivot"]],
                                zones.line[picks["regular"]]),
        "correction_regular": auc_of(zones.line[picks["correction"]],
                                     zones.line[picks["regular"]]),
        "pivot_correction": auc_of(zones.line[picks["pivot"]],
                                   zones.line[picks["correction"]])}
    return out


def compare(zones: Zones) -> dict:
    """Порівняння трьох видів подій: рівні фіч, несхожість, AUC.

    Пул подій великий, але одиниць мало (зон і ніг), тому поруч із
    кожним числом стоїть кількість зон (rules/03-models.md → Розмір
    вибірки в незалежних одиницях).
    """
    return marks_report(zones, zones.mark)


def shapes(records: list) -> dict:
    """Розмір зони: половини, події, розмах ціни — окремо на кожен вид."""
    out = {}
    for kind in ("pivot", "correction"):
        rows = [one for one in records if one["kind"] == kind]
        out[kind] = {
            "zones": len(rows),
            "left": stat([one["left"] for one in rows]),
            "right": stat([one["right"] for one in rows]),
            "events": stat([one["events"] for one in rows]),
            "span": stat([one["span"] for one in rows]),
            "share_left": stat([one["share_left"] for one in rows])}
    return out


def build(pair: str = PAIR, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", limit: float = LIMIT, smooth: int = SMOOTH,
          patience: int = PATIENCE, correction: float = CORRECTION,
          root: Path | None = None) -> tuple[dict, Zones]:
    if reduce not in REDUCERS:
        raise ValueError(f"невідома згортка: {reduce}")
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    curves = curves_of(data, where > 0, reduce)
    zones = Zones(data, where, legs, curves, limit, smooth, patience,
                  correction)
    zones.run()
    records = zones.records()
    report = {
        "script": "research/31-leg-common-part/scripts/zones.py",
        "pair": pair, "class": class_name, "part": part, "reduce": reduce,
        "curve": CURVE, "features": list(data["features"]),
        "marks": list(MARKS), "limit": limit, "smooth": smooth,
        "patience": patience, "correction": correction,
        "max_share": MAX_SHARE, "core": list(CORE),
        "threshold": THRESHOLD, "period": PERIOD,
        "events": int(len(data["t"])), "in_legs": int((where > 0).sum()),
        "legs": counts["legs_kept"], "dropped": counts["dropped"],
        "window": WINDOW, "reach": REACH, "limits": list(LIMITS),
        "shapes": shapes(records), "compare": compare(zones),
        "fixed": fixed_window(zones),
        "profile": {kind: profile(zones, kind)
                    for kind in ("pivot", "correction")},
        "calibration": calibrate(data, where, legs, curves, smooth, patience,
                                 correction),
        "zones": records,
    }
    return report, zones


def save(report: dict, results: Path = RESULTS) -> Path:
    results.mkdir(parents=True, exist_ok=True)
    stem = f"zones_{report['pair']}_{report['class']}"
    path = results / f"{stem}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "zones"}
    (results / f"{stem}.meta.json").write_text(
        json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    return path


def show(report: dict) -> None:
    def number(value, digits=3):
        return "—" if value is None else f"{value:.{digits}f}"

    counts = report["compare"]["counts"]
    total = sum(counts.values())
    print(f"{report['pair']} · {report['class']} · поріг несхожості "
          f"{report['limit']}, згладжування {report['smooth']}, "
          f"терпіння {report['patience']}")
    print(f"подій у ногах {total}: "
          + ", ".join(f"{name} {counts[name]} "
                      f"({counts[name] / total * 100:.1f} %)"
                      for name in MARKS))
    for kind in ("pivot", "correction"):
        one = report["shapes"][kind]
        print(f"\n{kind}: {one['zones']} зон · ліворуч "
              f"{number(one['left']['mean'], 1)} подій, праворуч "
              f"{number(one['right']['mean'], 1)}, разом "
              f"{number(one['events']['mean'], 1)} · розмах ціни "
              f"{number((one['span']['mean'] or 0) * 100, 2)} %")
    print(f"\n{'фіча':<22}{'звичайна':>10}{'корекція':>10}{'півот':>8}"
          f"{'AUC п/з':>9}{'AUC к/з':>9}{'AUC п/к':>9}")
    for name in report["features"]:
        block = report["compare"]["by_feature"][name]
        auc = block["auc"]
        print(f"{name:<22}{number(block['regular']['level']):>10}"
              f"{number(block['correction']['level']):>10}"
              f"{number(block['pivot']['level']):>8}"
              f"{number(auc['pivot_regular']):>9}"
              f"{number(auc['correction_regular']):>9}"
              f"{number(auc['pivot_correction']):>9}")
    dev = report["compare"]["auc_deviation"]
    print(f"\nнесхожість d: півот/звичайна {number(dev['pivot_regular'])}, "
          f"корекція/звичайна {number(dev['correction_regular'])}, "
          f"півот/корекція {number(dev['pivot_correction'])}")
    for kind in ("pivot", "correction"):
        one = report["profile"][kind]
        if one.get("ready"):
            print(f"профіль d навколо {kind}: у точці {number(one['at'])}, "
                  f"за {one['reach']} подій {number(one['far'])}, "
                  f"підйом {number((one['lift'] or 0) * 100, 1)} %")
    print(f"\nконтроль фіксованим вікном ±{report['window']} подій:")
    print(f"{'фіча':<22}{'AUC п/з':>9}{'AUC к/з':>9}{'AUC п/к':>9}")
    for name in report["features"]:
        auc = report["fixed"]["by_feature"][name]["auc"]
        print(f"{name:<22}{number(auc['pivot_regular']):>9}"
              f"{number(auc['correction_regular']):>9}"
              f"{number(auc['pivot_correction']):>9}")
    print("\nпоріг -> частка подій і розмір зони")
    print(f"{'квантиль':<10}{'звичайні':>10}{'корекція':>10}{'півот':>8}"
          f"{'подій у зоні півота':>21}{'корекції':>10}")
    for row in report["calibration"]:
        print(f"{row['limit']:<10}{row['regular']:>10.3f}"
              f"{row['correction']:>10.3f}{row['pivot']:>8.3f}"
              f"{number(row['pivot_events'], 1):>21}"
              f"{number(row['correction_events'], 1):>10}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--limit", type=float, default=LIMIT)
    parser.add_argument("--smooth", type=int, default=SMOOTH)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--correction", type=float, default=CORRECTION)
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()

    report, _ = build(args.pair, args.class_name, args.reduce, args.part,
                      args.limit, args.smooth, args.patience, args.correction)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
