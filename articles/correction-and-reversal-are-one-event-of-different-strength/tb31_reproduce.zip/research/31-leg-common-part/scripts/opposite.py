"""Сусідні різнонаправлені ноги: чим відрізняються їхні події.

Дослідження: research/31-leg-common-part/
Правила: rules/01-data-and-db.md → `клас210х10-1х7д/д`, rules/03-models.md

Зігзаг чергує напрямки, тому дві сусідні ноги завжди різнонаправлені й
діляться спільним півотом. Вони стоять поруч у часі — ринок той самий,
година та сама, — і відрізняються тільки тим, куди йде рух. Питання:
чи видно цю різницю в подіях класу.

Три міри на кожну фічу, усередині **кожної пари окремо**:

| міра | що це |
| ---- | ----- |
| `auc` | ймовірність, що випадкова подія ноги вгору вища за випадкову подію сусідньої ноги вниз |
| `diff` | різниця середніх рівнів пари, у рангах ноги вгору мінус нога вниз |
| `by_cohort` | та сама різниця по 20 когортах (5 % довжини): де в нозі вона більша |

Контроль — пара **однонаправлених** ніг на тій самій відстані: нога і
наступна нога її ж напрямку (через одну). Якщо клас бачить саме
напрямок, контроль має лягти на 0.5; якщо ж різниця в парі — це просто
різний час, контроль покаже те саме, що й пара через півот.

Рівень події — ранг серед подій ніг монети (`leg_common.curves_of`), як
в етапі 1: сирі відношення похідних не мають скінченного розкиду
(rules/01-data-and-db.md → `клас210х10-1х7д/д`). Спільна складова ноги
тут **не віднімається**: саме рівень ноги й порівнюється.

Одиниця вибірки — **пара ніг**, не подія (rules/03-models.md → Розмір
вибірки в незалежних одиницях): усередині пари події залежні.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/opposite_<PAIR>_<клас>.json
       results/opposite_<PAIR>_<клас>.meta.json — те саме без кривих

Запуск:
    python3 research/31-leg-common-part/scripts/opposite.py
    python3 research/31-leg-common-part/scripts/opposite.py \
        --pair BTC_USDT --class class210x10m1x7dd
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cohort_link import COHORTS, cohort_of  # noqa: E402
from leg_common import (CLASS, CURVES, PAIR, PARTS, PERIOD,  # noqa: E402
                        REDUCE, REDUCERS, RESULTS, THRESHOLD, curves_of,
                        kept_legs, load)

MIN_PAIR = 20            # коротша нога в пару не йде: рівень нічим міряти


def auc_of(left: np.ndarray, right: np.ndarray) -> float | None:
    """Ймовірність, що значення з `left` вище за значення з `right`.

    Рангова міра Манна — Уїтні: до величин класу застосовна, бо дивиться
    тільки на порядок.
    """
    left = left[np.isfinite(left)]
    right = right[np.isfinite(right)]
    if not left.size or not right.size:
        return None
    both = np.concatenate([left, right])
    order = np.argsort(np.argsort(both, kind="stable"), kind="stable") + 1.0
    # середній ранг на зв'язках: інакше однакові числа дали б зсув
    values, first, counts = np.unique(both, return_inverse=True,
                                      return_counts=True)
    total = np.zeros(values.size)
    np.add.at(total, first, order)
    order = (total / counts)[first]
    top = order[:left.size].sum()
    return float((top - left.size * (left.size + 1) / 2)
                 / (left.size * right.size))


def stat(values: list, base: float = 0.0) -> dict:
    """Середнє по парах, похибка середнього, t і частка вище за `base`.

    `base` — рівень, від якого міра нічого не означає: нуль для різниці
    й 0.5 для AUC. Без нього частка для AUC була б завжди одиницею.
    """
    good = np.asarray([one for one in values if one is not None], dtype=float)
    good = good[np.isfinite(good)]
    if good.size < 2:
        return {"mean": None, "err": None, "t": None, "share": None,
                "pairs": int(good.size)}
    err = float(good.std(ddof=1) / np.sqrt(good.size))
    return {"mean": float(good.mean()), "err": err,
            "t": float((good.mean() - base) / err) if err else None,
            "share": float((good > base).mean()), "pairs": int(good.size)}


def adjacent(legs: list) -> list:
    """Пари сусідніх ніг: різнонаправлені — через півот, однонаправлені —
    через одну ногу, як контроль на ту саму часову відстань."""
    out = []
    for index, leg in enumerate(legs):
        for step, kind in ((1, "opposite"), (2, "same")):
            if index + step >= len(legs):
                continue
            other = legs[index + step]
            # ноги мають стояти в ряді підряд: між ними нічого не викинуто
            if legs[index + step - 1]["last"] + 1 != other["first"]:
                continue
            if (leg["kind"] == other["kind"]) != (kind == "same"):
                continue
            if min(leg["events"], other["events"]) < MIN_PAIR:
                continue
            out.append({"kind": kind, "first": leg, "second": other})
    return out


def pair_block(pair: dict, values: np.ndarray, where: np.ndarray,
               count: int = COHORTS) -> dict:
    """Одна пара ніг на одній фічі: AUC, різниця і різниця по когортах.

    Нога вгору завжди стоїть першою стороною порівняння — інакше знак
    різниці означав би просто порядок ніг у часі.
    """
    sides = {}
    for leg in (pair["first"], pair["second"]):
        piece = np.flatnonzero(where == leg["leg"])
        sides[leg["leg"]] = {"kind": leg["kind"], "values": values[piece],
                             "place": cohort_of(len(piece), count)}
    if pair["kind"] == "same":                 # контроль: перша проти другої
        left, right = (sides[pair["first"]["leg"]],
                       sides[pair["second"]["leg"]])
    else:
        up = [one for one in sides.values() if one["kind"] == "up"][0]
        down = [one for one in sides.values() if one["kind"] == "down"][0]
        left, right = up, down
    line = []
    for cohort in range(count):
        here = left["values"][left["place"] == cohort]
        there = right["values"][right["place"] == cohort]
        here, there = here[np.isfinite(here)], there[np.isfinite(there)]
        line.append(float(here.mean() - there.mean())
                    if here.size and there.size else None)
    good_left = left["values"][np.isfinite(left["values"])]
    good_right = right["values"][np.isfinite(right["values"])]
    return {"auc": auc_of(left["values"], right["values"]),
            "diff": (float(good_left.mean() - good_right.mean())
                     if good_left.size and good_right.size else None),
            "by_cohort": line}


def build(pair: str = PAIR, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", count: int = COHORTS,
          root: Path | None = None) -> dict:
    """Повний замір: пари через півот і однонаправлений контроль."""
    if reduce not in REDUCERS:
        raise ValueError(f"невідома згортка: {reduce}")
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    curves = curves_of(data, where > 0, reduce)
    pairs = adjacent(legs)

    by_curve = {}
    for curve in CURVES:
        by_curve[curve] = {}
        for name in data["features"]:
            values = curves[curve][name]
            blocks = {kind: [pair_block(one, values, where, count)
                             for one in pairs if one["kind"] == kind]
                      for kind in ("opposite", "same")}
            block = {}
            for kind, rows in blocks.items():
                cohorts = [[row["by_cohort"][cohort] for row in rows]
                           for cohort in range(count)]
                block[kind] = {
                    "auc": stat([row["auc"] for row in rows], 0.5),
                    "away": stat([abs(row["auc"] - 0.5) for row in rows
                                  if row["auc"] is not None]),
                    "diff": stat([row["diff"] for row in rows]),
                    "by_cohort": [stat(one) for one in cohorts]}
            block["gain"] = (block["opposite"]["away"]["mean"]
                             - block["same"]["away"]["mean"]
                             if block["opposite"]["away"]["mean"] is not None
                             and block["same"]["away"]["mean"] is not None
                             else None)
            by_curve[curve][name] = block

    return {
        "script": "research/31-leg-common-part/scripts/opposite.py",
        "pair": pair, "class": class_name, "part": part, "reduce": reduce,
        "features": list(data["features"]), "curves": list(CURVES),
        "cohorts": count, "share": 1 / count, "min_pair": MIN_PAIR,
        "threshold": THRESHOLD, "period": PERIOD,
        "legs": counts["legs_kept"], "dropped": counts["dropped"],
        "events": int(len(data["t"])), "in_legs": int((where > 0).sum()),
        "pairs": {kind: sum(1 for one in pairs if one["kind"] == kind)
                  for kind in ("opposite", "same")},
        "by_curve": by_curve,
    }


def save(report: dict, results: Path = RESULTS) -> Path:
    results.mkdir(parents=True, exist_ok=True)
    stem = f"opposite_{report['pair']}_{report['class']}"
    path = results / f"{stem}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "by_curve"}
    (results / f"{stem}.meta.json").write_text(
        json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    return path


def show(report: dict) -> None:
    def number(value, digits=3):
        return "—" if value is None else f"{value:.{digits}f}"

    print(f"{report['pair']} · {report['class']} · "
          f"{report['pairs']['opposite']} пар через півот, "
          f"{report['pairs']['same']} однонаправлених")
    for curve in report["curves"]:
        print(f"\nкрива {curve}: нога вгору проти сусідньої ноги вниз")
        print(f"{'фіча':<22}{'AUC':>7}{'t':>7}{'частка':>8}"
              f"{'|відхід|':>10}{'контроль':>10}{'виграш':>8}")
        for name in report["features"]:
            block = report["by_curve"][curve][name]
            one, control = block["opposite"], block["same"]
            print(f"{name:<22}{number(one['auc']['mean']):>7}"
                  f"{number(one['auc']['t'], 1):>7}"
                  f"{number(one['auc']['share'], 2):>8}"
                  f"{number(one['away']['mean']):>10}"
                  f"{number(control['away']['mean']):>10}"
                  f"{number(block['gain']):>8}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--cohorts", type=int, default=COHORTS)
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.reduce, args.part,
                   args.cohorts)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
