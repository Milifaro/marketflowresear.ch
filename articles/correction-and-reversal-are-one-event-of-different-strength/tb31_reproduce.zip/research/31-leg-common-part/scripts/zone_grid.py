"""Грід мережі етапу 6: функція втрат, штраф за плутанину і ручки LSTM.

Дослідження: research/31-leg-common-part/
Правила: rules/03-models.md → Типи мереж (грубий грід, вибір по val)

Мережа етапу 6 плутає **зону корекції із зоною півота**: обидві мають
той самий підпис у класі, тільки різної сили (етап 4). Тут ця помилка
штрафується прицільно й перебираються способи це зробити.

Що перебирається — по одній зміні від базового набору
(`rules/03-models.md` → один експеримент, одна зміна):

| ручка | значення | навіщо |
| ----- | -------- | ------ |
| `loss` | `bce`, `focal`, `softmax` | форма втрати на трьох каналах |
| `confuse` | 0, 1, 3 | вага прицільного штрафу за «корекцію на півоті» |
| `hidden` | 64, 128 | ширина LSTM |
| `layers` | 1, 2 | глибина |
| `lr` | 0.003, 0.001 | крок |

Прицільний штраф. На події, де правда — **зона півота**, канал «зона
корекції» отримує додаткову втрату з вагою `confuse`
(`zone_lstm.loss_for`). Її видно окремою мірою `mixup`: частка подій
зони півота, де модель поставила корекцію вище за півот.

Памʼять — «увесь ряд» (етап 6: більша памʼять нічого не додає, а блок,
нарізаний по ногах, підказує відповідь). Дані читаються **один раз** на
весь грід.

Вибір кращого набору — по val, за сумою `AUC(півот) + AUC(корекція)`
мінус `mixup`: один AUC окремо не бачить саме тої плутанини, заради
якої все робиться.

**Умова допуску.** Плутанину легко звести до нуля, зламавши канал
корекції: штраф тисне його вниз, ранги розсипаються, плутанини немає —
але й сказати «це корекція» модель більше не може. Тому набір із AUC
будь-якого з двох каналів нижче `FLOOR` (0.6) у вибір кращого не йде,
хоч і лишається в таблиці.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/zone_grid_all_<клас>.json           — усі прогони
       results/zone_grid_series_<PAIR>_<клас>.json — ряд val кращого

Запуск:
    python3 research/31-leg-common-part/scripts/zone_grid.py
    python3 research/31-leg-common-part/scripts/zone_grid.py \
        --epochs 6 --series BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import zone_lstm as net  # noqa: E402
from leg_common import CLASS, PARTS, REDUCE, REDUCERS, RESULTS  # noqa: E402

sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "19-leg-end-lstm"
                       / "scripts"))
from build_class210x10x7dc import PAIRS  # noqa: E402
from leg_end_train import device_name, no_swap  # noqa: E402

MEMORY = 0                # памʼять «увесь ряд» — вибір етапу 6
EPOCHS = 8
BASE = {"loss": "bce", "confuse": 0.0, "gamma": net.GAMMA,
        "hidden": net.HIDDEN, "layers": net.LAYERS, "lr": net.LR}
GRID = [
    {"name": "база: bce"},
    {"name": "bce + штраф 0.3", "confuse": 0.3},
    {"name": "bce + штраф 1", "confuse": 1.0},
    {"name": "bce + штраф 3", "confuse": 3.0},
    {"name": "focal", "loss": "focal"},
    {"name": "focal + штраф 1", "loss": "focal", "confuse": 1.0},
    {"name": "softmax + штраф 1", "loss": "softmax", "confuse": 1.0},
    {"name": "ширше: hidden 128", "hidden": 128},
    {"name": "мілкіше: 1 шар", "layers": 1},
    {"name": "повільніше: lr 0.001", "lr": 0.001},
]


FLOOR = 0.6               # нижче цього AUC канал вважається зламаним


def score_of(block: dict) -> float | None:
    """Одне число на набір: обидва AUC мінус плутанина.

    Окремий AUC не бачить помилки, заради якої все робиться: модель
    може добре ранжувати клас і при цьому ставити корекцію вище за
    півот саме на зонах розвороту.
    """
    pivot = block["by_class"]["pivot"]["auc"]
    correction = block["by_class"]["correction"]["auc"]
    mixup = block["mixup"]["share"]
    if pivot is None or correction is None:
        return None
    return pivot + correction - (mixup if mixup is not None else 0.0)


def qualified_of(block: dict) -> bool:
    """Чи можна взагалі рахувати цей набір кращим.

    Плутанину легко звести до нуля, **зламавши** канал корекції: штраф
    тисне його вниз, ранги розсипаються, і «корекція вище за півот» уже
    не трапляється — але сказати «це корекція» модель теж більше не
    може. Набір із AUC каналу нижче `FLOOR` у вибір не йде.
    """
    return all((block["by_class"][name]["auc"] or 0) >= FLOOR
               for name in ("pivot", "correction"))


def run_grid(pairs=PAIRS, class_name: str = CLASS, reduce: str = REDUCE,
             part: str = "all", memory: int = MEMORY, epochs: int = EPOCHS,
             chunk: int = net.CHUNK, seed: int = net.SEED,
             limit: float | None = None, device: str | None = None,
             root: Path | None = None, series: str | None = None,
             grid=GRID, log=print) -> dict:
    device = device or device_name()
    coins = [net.coin_data(one, class_name, reduce, part, limit, root)
             for one in pairs]
    for coin in coins:                     # блоки одні на весь грід
        for name in ("train", "val"):
            coin[f"blocks_{name}"] = net.blocks_of(
                coin["where"], coin["legs"], coin["t"], coin["cut"],
                memory, name, "events")
    report = {
        "script": "research/31-leg-common-part/scripts/zone_grid.py",
        "pairs": list(pairs), "class": class_name, "part": part,
        "reduce": reduce, "marks": list(net.MARKS), "memory": memory,
        "epochs": epochs, "chunk": chunk, "seed": seed, "device": device,
        "base": dict(BASE), "channels": int(coins[0]["levels"].shape[1]),
        "blocks": {name: sum(len(coin[f"blocks_{name}"]) for coin in coins)
                   for name in ("train", "val")},
        "zones": {name: sum(coin["counts"][name] for coin in coins)
                  for name in ("pivot", "correction")},
        "runs": [],
    }
    best = None
    for row in grid:
        config = {**BASE, **{key: value for key, value in row.items()
                             if key != "name"}}
        started = time.time()
        log(f"  {row['name']}: {config}")
        out = net.train_one(coins, memory, device, epochs, chunk,
                            config["lr"], seed, series=series,
                            head=config["loss"], confuse=config["confuse"],
                            gamma=config["gamma"], hidden=config["hidden"],
                            layers=config["layers"], log=log)
        if out.get("ready") is False:
            report["runs"].append({"name": row["name"], "config": config,
                                   "ready": False})
            continue
        block = {"name": row["name"], "ready": True, "config": config,
                 "best_epoch": out["best_epoch"], "history": out["history"],
                 "steady_auc": out["steady_auc"], "val": out["val"],
                 "score": score_of(out["val"]),
                 "qualified": qualified_of(out["val"]),
                 "seconds": round(time.time() - started, 1)}
        report["runs"].append(block)
        log(f"    AUC півот {out['val']['by_class']['pivot']['auc']:.3f} · "
            f"корекція {out['val']['by_class']['correction']['auc']:.3f} · "
            f"плутанина {out['val']['mixup']['share']:.3f} · "
            f"оцінка {block['score']:.3f} · {block['seconds']:.0f} с")
        if series and out.get("frame") and (
                best is None or block["score"] > best["score"]):
            best = {**block,
                    "series": {**out["frame"], "best_epoch": out["best_epoch"],
                               "epochs": sorted(out["by_epoch"], key=int),
                               "by_epoch": out["by_epoch"]}}
    ready = [one for one in report["runs"] if one.get("ready")
             and one.get("qualified")]
    report["floor"] = FLOOR
    if ready:
        top = max(ready, key=lambda one: one["score"] or -9)
        report["best"] = top["name"]
    if best is not None:
        report["series"] = {"name": best["name"], "config": best["config"],
                            **best["series"]}
    return report


def save(report: dict, results: Path = RESULTS) -> Path:
    results.mkdir(parents=True, exist_ok=True)
    series = report.pop("series", None)
    path = results / f"zone_grid_all_{report['class']}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    if series:
        (results / f"zone_grid_series_{series['pair']}_{report['class']}.json"
         ).write_text(json.dumps(series, ensure_ascii=False),
                      encoding="utf-8")
    return path


def show(report: dict) -> None:
    def number(value, digits=3):
        return "—" if value is None else f"{value:.{digits}f}"

    print(f"\n{len(report['pairs'])} монет · памʼять "
          f"{report['memory'] or 'увесь ряд'} · {report['epochs']} епох · "
          f"{report['device']}")
    print(f"{'набір':<24}{'епоха':>7}{'AUC півот':>11}{'AUC корекц':>12}"
          f"{'плутанина':>11}{'оцінка':>9}{'у вибір':>9}{'час':>7}")
    for row in report["runs"]:
        if not row.get("ready"):
            print(f"{row['name']:<24}   не порахувався")
            continue
        val = row["val"]
        print(f"{row['name']:<24}{row['best_epoch']:>7}"
              f"{number(val['by_class']['pivot']['auc']):>11}"
              f"{number(val['by_class']['correction']['auc']):>12}"
              f"{number(val['mixup']['share']):>11}"
              f"{number(row['score']):>9}"
              f"{'так' if row.get('qualified') else 'ні':>9}"
              f"{row['seconds']:>6.0f}с")
    print(f"\nкращий набір: {report.get('best', '—')}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", default="all")
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--memory", type=int, default=MEMORY)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--chunk", type=int, default=net.CHUNK)
    parser.add_argument("--seed", type=int, default=net.SEED)
    parser.add_argument("--limit", type=float, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--series", default="BTC_USDT")
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    no_swap(force=args.force)        # rules/03 → Навчання без свопа
    pairs = PAIRS if args.pairs == "all" else tuple(args.pairs.split(","))
    report = run_grid(pairs, args.class_name, args.reduce, args.part,
                      args.memory, args.epochs, args.chunk, args.seed,
                      args.limit, args.device, series=args.series)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
