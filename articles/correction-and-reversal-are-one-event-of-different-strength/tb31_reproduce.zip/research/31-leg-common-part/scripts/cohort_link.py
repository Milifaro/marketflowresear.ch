"""Когорти по 5 % ноги: чи звʼязані між собою і чи повторюються в сусідній.

Дослідження: research/31-leg-common-part/
Правила: rules/01-data-and-db.md → `клас210х10-1х7д/д`, rules/03-models.md

Етап 1 зняв з подій ноги спільну складову — рівень, однаковий для всіх її
подій. Лишились відхилення від цього рівня. Питання етапу 2 — чи є в них
порядок:

1. **Когорта з когортою.** Нога ділиться на 20 когорт по 5 % довжини.
   Рівень когорти — середнє її подій. Спірмен кожної когорти з кожною
   рахується **по ногах**: чи тягне рівень першої п'ятірки відсотків
   рівень останньої, і як звʼязок спадає з відстанню між когортами.
2. **Та сама позиція в сусідній нозі.** Для кожної когорти — Спірмен
   між її рівнем у нозі й рівнем **тієї самої** когорти в наступній
   нозі того самого напрямку. Контроль — та сама міра на випадкових
   парах ніг того напрямку: якщо сусідство нічого не додає, число ляже
   в розкид контролю.

Обидві міри рахуються двічі: **до** віднімання спільної складової
(рівень фічі як є) і **після** (рівень мінус база з попередньої ноги
свого напрямку, етап 1). Так видно, що з кореляцій робить саме
віднімання.

Одиниця вибірки — **нога**, не подія (rules/03-models.md → Розмір
вибірки в незалежних одиницях): когорта це агрегат по нозі, і корелюють
між собою ноги. Тому поруч із кожним числом стоїть кількість ніг, а
похибка Спірмена бралась як `1/sqrt(ніг − 3)`.

Хід:

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 % -> ноги
    -> рівень події в рангах, база з попередньої ноги свого напрямку
    -> 20 когорт по 5 % довжини ноги, рівень когорти = середнє подій
    -> матриця 20 x 20 по ногах і драбина «та сама когорта через N ніг»

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/cohort_link_<PAIR>_<клас>.json
       results/cohort_link_<PAIR>_<клас>.meta.json — те саме без матриць

Запуск:
    python3 research/31-leg-common-part/scripts/cohort_link.py
    python3 research/31-leg-common-part/scripts/cohort_link.py \
        --pair BTC_USDT --class class210x10m1x7dd --cohorts 20
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from leg_common import (CLASS, CURVES, KINDS, PAIR, REDUCE,  # noqa: E402
                        REDUCERS, RESULTS, build_legs, curves_of, kept_legs,
                        load, spearman)
from leg_common import PARTS, PERIOD, THRESHOLD, HOLE, MIN_LEG  # noqa: E402

COHORTS = 20                 # 20 когорт по 5 % довжини ноги
STAGES = ("before", "after")  # до і після віднімання спільної складової
GAPS = (1, 2, 3)             # через скільки ніг свого напрямку порівнювати
SHUFFLES = 200               # скільки разів перемішується контроль
SEED = 0


def cohort_of(length: int, count: int = COHORTS) -> np.ndarray:
    """Номер когорти кожної події ноги: 0 … count−1, по 5 % довжини."""
    place = np.floor(np.arange(length) / length * count).astype(int)
    return np.minimum(place, count - 1)


def cells(data: dict, where: np.ndarray, rows: list, curves: dict,
          count: int = COHORTS) -> dict:
    """Рівень когорти на кожній нозі: `{крива: {етап: {фіча: (ноги, когорти)}}}`.

    Беруться тільки ноги з базою — без неї етапу «після» не існує.
    """
    chosen = [row for row in rows if row["ready"]]
    out = {curve: {stage: {name: np.full((len(chosen), count), np.nan)
                           for name in curves[curve]}
                   for stage in STAGES}
           for curve in curves}
    for index, row in enumerate(chosen):
        piece = np.flatnonzero(where == row["leg"])
        place = cohort_of(len(piece), count)
        for curve, by_feature in curves.items():
            for name, values in by_feature.items():
                level = values[piece]
                base = row["base"][curve][name]
                for cohort in range(count):
                    take = level[place == cohort]
                    take = take[np.isfinite(take)]
                    if not take.size:
                        continue
                    out[curve]["before"][name][index, cohort] = take.mean()
                    if base is not None:
                        out[curve]["after"][name][index, cohort] = \
                            take.mean() - base
    return {"cells": out, "legs": chosen}


def matrix(table: np.ndarray) -> list:
    """Спірмен когорти з когортою по ногах: (ноги, когорти) -> 20 x 20."""
    count = table.shape[1]
    return [[1.0 if left == right
             else spearman(table[:, left], table[:, right])
             for right in range(count)]
            for left in range(count)]


def matrix_report(table: np.ndarray) -> dict:
    """Матриця й два числа, якими вона читається.

    `near` — середній звʼязок сусідніх когорт (відстань 1), `far` —
    крайніх між собою (перша з останньою). Похибка Спірмена на `n` ногах
    береться як `1/sqrt(n − 3)`.
    """
    grid = matrix(table)
    count = len(grid)
    good = int(np.isfinite(table).all(axis=1).sum())
    near = [grid[index][index + 1] for index in range(count - 1)
            if grid[index][index + 1] is not None]
    away = [grid[left][right] for left in range(count)
            for right in range(left + 1, count)
            if grid[left][right] is not None]
    return {"grid": grid, "legs": good,
            "err": float(1 / np.sqrt(good - 3)) if good > 3 else None,
            "near": float(np.mean(near)) if near else None,
            "far": grid[0][count - 1],
            "mean_off": float(np.mean(away)) if away else None}


def neighbour(table: np.ndarray, gap: int, rng: np.random.Generator) -> dict:
    """Та сама когорта через `gap` ніг свого напрямку, з контролем.

    Контроль — той самий замір на випадкових парах ніг того напрямку:
    він каже, скільки в числі просто того, що ноги одного напрямку
    схожі між собою взагалі.
    """
    legs, count = table.shape
    if legs <= gap + 3:
        return {"gap": gap, "ready": False, "pairs": max(legs - gap, 0)}
    left, right = table[:-gap], table[gap:]
    line = [spearman(left[:, cohort], right[:, cohort])
            for cohort in range(count)]
    seen = [one for one in line if one is not None]
    value = float(np.mean(seen)) if seen else None
    null = []
    for _ in range(SHUFFLES):
        order = rng.permutation(legs)
        mixed = table[order]
        shuffled = [spearman(table[:, cohort], mixed[:, cohort])
                    for cohort in range(count)]
        shuffled = [one for one in shuffled if one is not None]
        if shuffled:
            null.append(float(np.mean(shuffled)))
    null = np.asarray(null, dtype=float)
    return {"gap": gap, "ready": True, "pairs": int(legs - gap),
            "curve": line, "mean": value,
            "null_p95": float(np.quantile(np.abs(null), 0.95)) if null.size
            else None,
            "null_sd": float(null.std(ddof=1)) if null.size > 1 else None,
            "p_value": (float((np.abs(null) >= abs(value)).mean())
                        if null.size and value is not None else None)}


def build(pair: str = PAIR, class_name: str = CLASS, reduce: str = REDUCE,
          part: str = "all", count: int = COHORTS,
          root: Path | None = None) -> dict:
    """Повний замір: матриці когорт і драбина сусідніх ніг."""
    if reduce not in REDUCERS:
        raise ValueError(f"невідома згортка: {reduce}")
    data = load(pair, class_name, root, part)
    where, legs, counts = kept_legs(data)
    curves = curves_of(data, where > 0, reduce)
    rows = build_legs(data, where, legs, curves)
    table = cells(data, where, rows, curves, count)
    chosen = table["legs"]
    rng = np.random.default_rng(SEED)

    by_kind = {}
    for kind in KINDS + ("all",):
        pick = np.array([kind in (one["kind"], "all") for one in chosen])
        block = {}
        for curve in CURVES:
            block[curve] = {}
            for stage in STAGES:
                block[curve][stage] = {}
                for name in data["features"]:
                    piece = table["cells"][curve][stage][name][pick]
                    block[curve][stage][name] = {
                        **matrix_report(piece),
                        "by_gap": [neighbour(piece, gap, rng) for gap in GAPS]}
        block["legs"] = int(pick.sum())
        by_kind[kind] = block

    return {
        "script": "research/31-leg-common-part/scripts/cohort_link.py",
        "pair": pair, "class": class_name, "part": part, "reduce": reduce,
        "features": list(data["features"]), "curves": list(CURVES),
        "stages": list(STAGES), "kinds": list(KINDS) + ["all"],
        "cohorts": count, "share": 1 / count, "gaps": list(GAPS),
        "shuffles": SHUFFLES, "seed": SEED,
        "threshold": THRESHOLD, "period": PERIOD, "hole_hours": HOLE / 3600,
        "min_leg": MIN_LEG, "events": int(len(data["t"])),
        "in_legs": int((where > 0).sum()), "legs_kept": counts["legs_kept"],
        "dropped": counts["dropped"], "legs": len(chosen),
        "by_kind": by_kind,
    }


def save(report: dict, results: Path = RESULTS) -> Path:
    """Звіт і його meta без матриць — для картки вкладки «Дослідження»."""
    results.mkdir(parents=True, exist_ok=True)
    stem = f"cohort_link_{report['pair']}_{report['class']}"
    path = results / f"{stem}.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "by_kind"}
    (results / f"{stem}.meta.json").write_text(
        json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    return path


def show(report: dict) -> None:
    print(f"{report['pair']} · {report['class']} · {report['cohorts']} когорт "
          f"по {report['share'] * 100:.0f} % · {report['legs']} ніг з базою")
    def number(value: float | None, digits: int = 3) -> str:
        return "—" if value is None else f"{value:.{digits}f}"

    for kind in KINDS:
        block = report["by_kind"][kind]
        print(f"\nноги {kind}, амплітуда · {block['legs']} ніг "
              f"(похибка Спірмена "
              f"{number(block['amplitude']['after'][report['features'][0]]['err'], 2)})")
        print(f"{'фіча':<22}{'до: сусід':>10}{'усі':>7}{'край':>7}"
              f"{'після: сусід':>14}{'усі':>7}{'край':>7}"
              f"{'нога+1':>9}{'p':>7}")
        for name in report["features"]:
            before = block["amplitude"]["before"][name]
            after = block["amplitude"]["after"][name]
            gap = after["by_gap"][0]
            print(f"{name:<22}{number(before['near']):>10}"
                  f"{number(before['mean_off']):>7}{number(before['far']):>7}"
                  f"{number(after['near']):>14}{number(after['mean_off']):>7}"
                  f"{number(after['far']):>7}{number(gap.get('mean')):>9}"
                  f"{number(gap.get('p_value')):>7}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default=REDUCE, choices=REDUCERS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--cohorts", type=int, default=COHORTS)
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.reduce, args.part,
                   args.cohorts)
    path = save(report, args.results)
    show(report)
    print(f"\n{path}")


if __name__ == "__main__":
    main()
