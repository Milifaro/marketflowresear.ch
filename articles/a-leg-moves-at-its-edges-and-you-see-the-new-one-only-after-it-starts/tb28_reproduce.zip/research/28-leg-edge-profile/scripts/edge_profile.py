"""Профіль ноги: де в нозі стається рух і скільки в ній подій.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Дослідження 01 (етап 10) показало: рух ноги зігзага 2.3 % збирається на її
**краях** — 18 % у першій десятині, 19 % в останній, по 6 % у середині.
Тут це міряється окремо й до кінця: профіль по десятинах, краї проти
середини, довжина ноги в подіях і те, як довжина міняє профіль.

Скрипт написаний так, щоб тим самим ходом міряти **будь-який клас**:
величина події `v` береться або з ціни (за замовчуванням), або з фічі
класу. Решта — ряд, ноги, десятини, приведення до напрямку ноги —
однакова, тому профілі різних класів прямо порівнюються.

Хід (той самий, що на вкладці `/umap`):

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 %
    -> ноги -> десятини -> величина події -> профіль по десятинах

Величина події:

    ціна    v = ln(price_close / price_open) — рух за 210 с події
    фіча    v = згортка фічі класу по блоках події (mean / last / sum)

Усе приводиться до напрямку ноги (`v * direction`), тому ноги вгору
й вниз лягають в один ряд.

Ноги з дірою в ряді довше за годину викидаються: дослідження 01 (етап 11)
показало, що на них рух приходить із розриву, а не з подій.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/edge_profile.json      — профілі, довжини, звʼязок із рухом
       results/edge_profile.meta.json — те саме без переліку ніг

Запуск:
    python3 research/28-leg-edge-profile/scripts/edge_profile.py
    python3 research/28-leg-edge-profile/scripts/edge_profile.py \\
        --class class210x10x7 --feature vol_balance --reduce mean
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS, PARTS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import Pivot, zigzag  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"

THRESHOLD = 0.023          # зігзаг 2.3 %
PERIOD = 10                # ема ціни, на якій стоять півоти
DECILES = 10               # на скільки частин ділиться нога
ROW_CLASS = "class210x10x7"    # ряд подій за замовчуванням
HOLE = 3600                # діра в ряді, з якої нога не рахується, секунд
EDGES = (1, DECILES)       # які десятини вважаються краями
MIDDLE = (4, 5, 6, 7)      # а які — серединою
LENGTH_BINS = 4            # на скільки груп за довжиною діляться ноги


def load(pair: str, class_name: str, root: Path | None = None) -> dict:
    """Повний ряд монети за часом: час, ціна події і масив фіч класу.

    Класи зберігаються двома розкладками ключів — `t_start` (класи на
    блоки по 21 с) і `timestamp` (класи на блоки по 14 с). Беремо ту, що є.
    """
    folder = (root or DATASETS) / pair / class_name
    stamps, opens, closes, values = [], [], [], []
    for part in PARTS:
        with np.load(folder / f"{part}.npz") as store:
            key = "t_start" if "t_start" in store else "timestamp"
            stamps.append(store[key])
            opens.append(store["price_open"])
            closes.append(store["price_close"])
            values.append(store["x"])
            names = [str(name) for name in store["features"]]
    stamps = np.concatenate(stamps)
    order = np.argsort(stamps, kind="stable")
    return {"t": stamps[order].astype(np.int64),
            "open": np.concatenate(opens)[order].astype(float),
            "close": np.concatenate(closes)[order].astype(float),
            "x": np.concatenate(values)[order].astype(float),
            "features": names}


def value(data: dict, feature: str | None, reduce: str = "mean") -> np.ndarray:
    """Величина події: рух ціни або згортка фічі класу по блоках події."""
    if feature is None:
        return np.log(data["close"] / data["open"])
    index = data["features"].index(feature)
    column = data["x"][..., index]
    if column.ndim == 1:
        return column
    return {"mean": column.mean, "sum": column.sum,
            "last": lambda axis: column[:, -1]}[reduce](axis=1)


def legs_of(data: dict) -> tuple[np.ndarray, list]:
    """Ноги ряду і десятина кожної події: рецепт вкладки `/umap`."""
    smooth = ema(data["open"], PERIOD)
    pivots: list[Pivot] = zigzag(smooth, THRESHOLD)
    place = np.zeros(len(smooth), dtype=np.int16)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        length = last - first + 1
        decile = np.minimum(np.floor(np.arange(length) / length * DECILES) + 1,
                            DECILES).astype(np.int16)
        place[first:last + 1] = decile
        step = np.diff(data["t"][first:last + 1])
        legs.append({"leg": len(legs) + 1,
                     "kind": "up" if pivot.kind == "high" else "down",
                     "first": first, "last": last, "events": int(length),
                     "from": int(data["t"][first]), "to": int(data["t"][last]),
                     "hole_hours": float((step[step > 210] - 210).sum() / 3600),
                     "move": float(np.log(data["close"][last]
                                          / data["open"][first]))})
    return place, legs


def profile(rows: list) -> dict:
    """Профіль по десятинах двома способами — пулом і по нозі.

    `pooled` — сума величин десятини до суми по всіх ногах: так видно,
    де насправді лежить рух. `per_leg` — та сама частка, порахована
    в кожній нозі окремо й усереднена: так довга нога не тисне коротку.
    `mean` — середня величина події десятини, вона працює й для фіч,
    які не додаються.
    """
    if not rows:
        return {"legs": 0}
    sums = np.array([row["by_decile"] for row in rows], dtype=float)
    means = np.array([row["mean_by_decile"] for row in rows], dtype=float)
    total = sums.sum(axis=1, keepdims=True)
    per_leg = np.divide(sums, total, out=np.zeros_like(sums), where=total != 0)
    pooled = sums.sum(axis=0) / sums.sum() if sums.sum() else np.zeros(DECILES)
    edges = [part - 1 for part in EDGES]
    middle = [part - 1 for part in MIDDLE]
    return {
        "legs": len(rows),
        "events": int(sum(row["events"] for row in rows)),
        "pooled": pooled.tolist(),
        "per_leg": per_leg.mean(axis=0).tolist(),
        "per_leg_std": per_leg.std(axis=0).tolist(),
        "mean": means.mean(axis=0).tolist(),
        "edges": float(pooled[edges].sum()),
        "middle": float(pooled[middle].sum()),
        "edge_to_middle": float(pooled[edges].mean() / pooled[middle].mean())
        if pooled[middle].mean() else 0.0,
    }


def lengths(rows: list, bins: int = 12) -> dict:
    """Довжина ноги в подіях: квартилі й гістограма."""
    events = np.array([row["events"] for row in rows], dtype=float)
    counts, edges = np.histogram(events, bins=bins)
    return {"median": float(np.median(events)),
            "q1": float(np.percentile(events, 25)),
            "q3": float(np.percentile(events, 75)),
            "shortest": float(events.min()), "longest": float(events.max()),
            "hist": {"counts": counts.tolist(),
                     "edges": [float(edge) for edge in edges]}}


def by_length(rows: list, parts: int = LENGTH_BINS) -> list:
    """Профіль у розрізі довжини ноги: чи тримаються краї на довгих ногах."""
    events = np.array([row["events"] for row in rows], dtype=float)
    bounds = [np.percentile(events, 100 * i / parts) for i in range(parts + 1)]
    groups = []
    for index in range(parts):
        low, high = bounds[index], bounds[index + 1]
        picked = [row for row in rows
                  if low <= row["events"] <= high] if index == parts - 1 else \
            [row for row in rows if low <= row["events"] < high]
        groups.append({"from": float(low), "to": float(high),
                       **profile(picked),
                       "move_median": float(np.median(
                           [abs(row["move"]) for row in picked]))
                       if picked else 0.0})
    return groups


def move_vs_events(rows: list) -> dict:
    """Звʼязок довжини ноги з її рухом: кореляція і біни."""
    events = np.array([row["events"] for row in rows], dtype=float)
    move = np.abs([row["move"] for row in rows])
    corr = float(np.corrcoef(events, move)[0, 1]) if len(rows) > 1 else 0.0
    order = np.argsort(events)
    chunks = np.array_split(order, 8)
    return {"corr": corr,
            "bins": [{"events": float(np.median(events[chunk])),
                      "move": float(np.median(move[chunk])),
                      "legs": int(chunk.size)} for chunk in chunks]}


def leg_rows(data: dict, place: np.ndarray, legs: list, values: np.ndarray,
             pair: str) -> list:
    """Нога за ногою: величина по десятинах, приведена до напрямку ноги."""
    rows = []
    for leg in legs:
        if leg["hole_hours"] * 3600 > HOLE:
            continue
        first, last = leg["first"], leg["last"]
        direction = 1 if leg["kind"] == "up" else -1
        piece = values[first:last + 1] * direction
        parts = place[first:last + 1]
        rows.append({"pair": pair, "leg": leg["leg"], "kind": leg["kind"],
                     "events": leg["events"], "from": leg["from"],
                     "to": leg["to"], "move": leg["move"] * direction,
                     "hole_hours": leg["hole_hours"],
                     "by_decile": [float(piece[parts == part].sum())
                                   for part in range(1, DECILES + 1)],
                     "mean_by_decile": [float(piece[parts == part].mean())
                                        if np.any(parts == part) else 0.0
                                        for part in range(1, DECILES + 1)]})
    return rows


def build(pairs=PAIRS, class_name: str = ROW_CLASS, feature: str | None = None,
          reduce: str = "mean", root: Path | None = None) -> dict:
    rows, dropped = [], 0
    for pair in pairs:
        data = load(pair, class_name, root)
        place, legs = legs_of(data)
        values = value(data, feature, reduce)
        picked = leg_rows(data, place, legs, values, pair)
        dropped += len(legs) - len(picked)
        rows.extend(picked)
    return {
        "script": "research/28-leg-edge-profile/scripts/edge_profile.py",
        "threshold": THRESHOLD, "period": PERIOD, "deciles": DECILES,
        "class": class_name, "feature": feature or "ціна події",
        "reduce": reduce if feature else "—",
        "edges": list(EDGES), "middle": list(MIDDLE),
        "hole_hours": HOLE / 3600, "dropped_legs": dropped,
        "pairs": list(pairs),
        "all": profile(rows),
        "by_kind": {kind: profile([row for row in rows if row["kind"] == kind])
                    for kind in ("up", "down")},
        "by_pair": {pair: profile([row for row in rows if row["pair"] == pair])
                    for pair in pairs},
        "by_length": by_length(rows),
        "lengths": lengths(rows),
        "lengths_by_pair": {pair: lengths([row for row in rows
                                           if row["pair"] == pair])
                            for pair in pairs},
        "move_vs_events": move_vs_events(rows),
        "legs": rows, "ready": bool(rows),
    }


def show(report: dict) -> None:
    everything = report["all"]
    print(f"ноги {everything['legs']} (відкинуто з дірами "
          f"{report['dropped_legs']}), подій {everything['events']}, "
          f"величина — {report['feature']}")
    print("\nпрофіль по десятинах")
    for name, title in (("pooled", "пулом"), ("per_leg", "по нозі")):
        line = " ".join(f"{v:+.3f}" for v in everything[name])
        print(f"  {title:<8} {line}")
    print(f"  краї (1 і 10) {everything['edges']:.3f} проти середини "
          f"(4–7) {everything['middle']:.3f}, "
          f"десятина краю сильніша в {everything['edge_to_middle']:.2f} раза")
    print("\nноги вгору і вниз")
    for kind in ("up", "down"):
        block = report["by_kind"][kind]
        line = " ".join(f"{v:+.3f}" for v in block["pooled"])
        print(f"  {'вгору' if kind == 'up' else 'вниз':<6} "
              f"{block['legs']:>4} ніг  {line}")
    print("\nза довжиною ноги")
    for group in report["by_length"]:
        line = " ".join(f"{v:+.3f}" for v in group["pooled"])
        print(f"  {group['from']:>5.0f}…{group['to']:<5.0f} "
              f"{group['legs']:>4} ніг  {line}  "
              f"краї {group['edges']:.3f}")
    length = report["lengths"]
    print(f"\nдовжина ноги, подій: медіана {length['median']:.0f} "
          f"(квартилі {length['q1']:.0f} … {length['q3']:.0f}, "
          f"від {length['shortest']:.0f} до {length['longest']:.0f})")
    print(f"кореляція довжини ноги з її рухом: "
          f"{report['move_vs_events']['corr']:+.3f}")
    print("\nпо монетах")
    for pair, block in report["by_pair"].items():
        print(f"  {pair:<10} {block['legs']:>4} ніг · краї "
              f"{block['edges']:.3f} · середина {block['middle']:.3f} · "
              f"медіана довжини "
              f"{report['lengths_by_pair'][pair]['median']:.0f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--feature", default=None,
                        help="фіча класу; без неї міряється рух ціни")
    parser.add_argument("--reduce", default="mean",
                        choices=("mean", "sum", "last"))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.feature,
                   args.reduce, args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    name = "edge_profile" if args.feature is None \
        else f"edge_profile_{args.class_name}_{args.feature}"
    (args.out / f"{name}.json").write_text(
        json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "legs"}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
