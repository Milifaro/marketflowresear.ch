"""Нова нога на подіях класу: вікно описується класом, а не ціною.

Дослідження: research/28-leg-edge-profile/
Правила: rules/01-data-and-db.md, rules/03-models.md

Етап 6 описував вікно **порахованими з ціни** числами: хід, шлях, розкид,
місце вершини. Тут те саме питання — «чи стався розворот усередині
останніх `X` подій» — ставиться на **самих подіях класу**, без жодної
ціни.

Клас: `клас210х14х4` — перший клас датасету (`клас210х8` проміжний і в
`data/datasets/` не лежить). Подія — `(15, 4)`: чотири фічі в обʼємах,
по 15 блоків на подію.

Квантування, бо сирих чисел забагато: подія в 100 подій вікна дала б
`100 × 15 × 4 = 6000` колонок. Тому:

    1  блоки події згортаються в одне число на фічу (середнє по 15)
    2  вікно ділиться на `SEGMENTS` рівних частин **за подіями**
    3  на кожну частину береться середнє і розкид кожної фічі

Виходить `SEGMENTS × фіч × 2` колонок — форма вікна лишається, а розмір
не залежить від його довжини.

Вхід : data/datasets/<PAIR>/class210x14x4/{train,val}.npz
Вихід: results/class_new_leg.json      — AUC, крива порога, затримка
       results/class_new_leg.meta.json — те саме

Запуск:
    python3 research/28-leg-edge-profile/scripts/class_new_leg.py
    python3 research/28-leg-edge-profile/scripts/class_new_leg.py --class class210x10x7
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from edge_profile import DATASETS, PERIOD, THRESHOLD, load  # noqa: E402
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402
from edge_profile import HOLE, legs_of  # noqa: E402
from new_leg import TOPS, WINDOWS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

CLASS = "class210x14x4"    # перший клас датасету
SEGMENTS = 8               # на скільки частин ділиться вікно
KEEP = 0.2                 # менше цієї частки ряду — фільтр дір міняється


def folded(data: dict) -> np.ndarray:
    """Подія класу одним рядком: середнє по блоках кожної фічі."""
    block = data["x"]
    return block.mean(axis=1) if block.ndim == 3 else block


def features(data: dict, size: int) -> tuple[np.ndarray, list, np.ndarray]:
    """Вікно з `size` подій класу, поділене на `SEGMENTS` частин."""
    values = folded(data)
    names, columns = [], []
    for number, feature in enumerate(data["features"]):
        view = sliding_window_view(values[:, number], size)
        for part, piece in enumerate(np.array_split(view, SEGMENTS, axis=1)):
            columns.append(piece.mean(axis=1))
            names.append(f"{feature}_{part + 1}")
            columns.append(piece.std(axis=1))
            names.append(f"{feature}_{part + 1}_std")
    order = np.argsort(names)
    matrix = np.column_stack([columns[one] for one in order])
    return matrix, [names[one] for one in order], \
        np.arange(size - 1, len(values))


def marks(data: dict, index: np.ndarray, size: int,
          holes: str = "sum") -> dict:
    """Мітка: розворот усередині вікна — подія з перших `size` ноги.

    Фільтр дір має два режими. `sum` — той самий, що на етапах 1–6:
    нога відкидається, коли **сума** розривів більша за годину. `max` —
    для розріджених класів: `клас210х14х4` вимагає 210 секунд суцільної
    історії, тому в його ряді вдвічі менше подій, ніж у `клас210х10х7`,
    і сума дрібних розривів на будь-якій нозі перевищує годину; там нога
    відкидається за **найбільшим одним** розривом.
    """
    _, legs = legs_of(data)
    total = len(data["t"])
    from_start = np.full(total, -1)
    for leg in legs:
        first, last = leg["first"], leg["last"]
        step = np.diff(data["t"][first:last + 1])
        if step.size:
            gap = step.max() if holes == "max" \
                else (step[step > 210] - 210).sum()
            if gap > HOLE:
                continue
        from_start[first:last + 1] = np.arange(last - first + 1)
    keep = index[from_start[index] >= 0]
    return {"index": keep, "from_start": from_start[keep],
            "part": np.where(data["t"][keep] >= VAL_FROM, "val", "train"),
            "y": (from_start[keep] < size).astype(int)}


def collect(pairs, class_name: str, size: int, root: Path | None,
            holes: str = "sum") -> dict:
    rows = {"x": [], "y": [], "part": [], "from_start": []}
    names = []
    for pair in pairs:
        data = load(pair, class_name, root)
        matrix, names, index = features(data, size)
        found = marks(data, index, size, holes)
        picked = np.searchsorted(index, found["index"])
        rows["x"].append(matrix[picked])
        rows["y"].append(found["y"])
        rows["part"].append(found["part"])
        rows["from_start"].append(found["from_start"])
    return {"x": np.vstack(rows["x"]), "features": names,
            "y": np.concatenate(rows["y"]),
            "part": np.concatenate(rows["part"]),
            "from_start": np.concatenate(rows["from_start"])}


def model_of(rows: dict):
    from sklearn.ensemble import HistGradientBoostingClassifier

    train = rows["part"] == "train"
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(rows["x"][train], rows["y"][train])
    return model


def learn(rows: dict, size: int) -> dict:
    """AUC, крива порога і затримка — той самий рахунок, що на етапі 6."""
    from sklearn.metrics import roc_auc_score

    train = rows["part"] == "train"
    val = ~train
    model = model_of(rows)
    score = model.predict_proba(rows["x"][val])[:, 1]
    y_val = rows["y"][val]
    steps = rows["from_start"][val]
    base = float(y_val.mean())
    curve = []
    for share in TOPS:
        limit = float(np.quantile(score, 1 - share))
        top = score >= limit
        hit = top & (y_val > 0)
        curve.append({
            "share": share, "limit": limit, "events": int(top.sum()),
            "precision": float(y_val[top].mean()),
            "lift": float(y_val[top].mean() / base) if base else 0.0,
            "recall": float(y_val[top].sum() / max(y_val.sum(), 1)),
            "lag": float(np.median(steps[hit]) + 1) if hit.any() else 0.0})
    # рівні класу бувають невизначені (блок із нульовим обʼємом): модель
    # читає їх як пропуск, а одна колонка міряється по визначених рядках
    singles = []
    for number, name in enumerate(rows["features"]):
        column = rows["x"][val][:, number]
        good = np.isfinite(column)
        if good.sum() < 100 or len(np.unique(y_val[good])) < 2:
            continue
        singles.append({"feature": name,
                        "auc": float(roc_auc_score(y_val[good],
                                                   column[good])),
                        "events": int(good.sum())})
    singles.sort(key=lambda one: -abs(one["auc"] - 0.5))
    singles = singles[:6]
    return {"window": size, "base": base, "seconds": size * 210,
            "events": {"train": int(train.sum()), "val": int(val.sum())},
            "auc": float(roc_auc_score(y_val, score)),
            "curve": curve, "singles": singles,
            "columns": len(rows["features"])}


def shared(pairs=PAIRS, root: Path | None = None) -> list:
    """Класи, що є в датасеті **всіх** монет."""
    folder = root or DATASETS
    found = None
    for pair in pairs:
        names = {one.name for one in (folder / pair).iterdir()
                 if one.is_dir()}
        found = names if found is None else found & names
    return sorted(found or ())


def holes_for(pairs, class_name: str, size: int,
              root: Path | None) -> str:
    """Сумою чи найбільшим розривом рахувати діру на цьому класі.

    Розріджені класи (`клас210х14х*` стоять на 210 с суцільної історії)
    втрачають на сумі розривів геть увесь ряд, тому там діра рахується
    найбільшим одним розривом.
    """
    data = load(pairs[0], class_name, root)
    _, _, index = features(data, size)
    kept = marks(data, index, size, "sum")["index"].size
    return "sum" if kept > KEEP * index.size else "max"


def build(pairs=PAIRS, class_name: str = CLASS, windows=WINDOWS,
          root: Path | None = None, holes: str = "max") -> dict:
    return {
        "holes": holes,
        "script": "research/28-leg-edge-profile/scripts/class_new_leg.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "segments": SEGMENTS, "windows": list(windows), "tops": list(TOPS),
        "seed": SEED, "val_from": "2026-08-14", "pairs": list(pairs),
        "about": "розворот стався всередині останніх X подій класу",
        "by_window": {str(size): learn(collect(pairs, class_name, size,
                                               root, holes), size)
                      for size in windows},
        "ready": True,
    }


def show(report: dict) -> None:
    print(f"клас {report['class']} · вікно ділиться на "
          f"{report['segments']} частин · діри — {report['holes']}\n")
    print(f"{'X':>4} {'колонок':>8} {'частка':>7} {'AUC':>7}   "
          f"точність 0.1 / 1 / 5 %   затримка")
    for size in report["windows"]:
        block = report["by_window"][str(size)]
        curve = {one["share"]: one for one in block["curve"]}
        print(f"{size:>4} {block['columns']:>8} {block['base']:>7.3f} "
              f"{block['auc']:>7.3f}   "
              f"{curve[0.001]['precision']:.3f} / "
              f"{curve[0.01]['precision']:.3f} / "
              f"{curve[0.05]['precision']:.3f}       "
              f"{curve[0.01]['lag']:.0f} подій")
    print("\nнайсильніші окремі колонки")
    for size in report["windows"]:
        block = report["by_window"][str(size)]
        line = " · ".join(f"{one['feature']} {one['auc']:.3f}"
                          for one in block["singles"][:3])
        print(f"  X={size:<4} {line}")


def every(pairs=PAIRS, windows=WINDOWS, root: Path | None = None) -> dict:
    """Той самий замір на кожному класі, що є в усіх монет."""
    listed = {}
    for class_name in shared(pairs, root):
        holes = holes_for(pairs, class_name, max(windows), root)
        data = load(pairs[0], class_name, root)
        listed[class_name] = {
            **build(pairs, class_name, windows, root, holes),
            "features": [str(one) for one in data["features"]],
            "events": int(len(data["t"])),
        }
        block = listed[class_name]["by_window"]
        line = " · ".join(
            f"X={size}: AUC {block[str(size)]['auc']:.3f}"
            for size in windows)
        print(f"{class_name:<26} діри {holes:<4} {line}", flush=True)
    return {
        "script": "research/28-leg-edge-profile/scripts/class_new_leg.py",
        "ready": True, "segments": SEGMENTS, "windows": list(windows),
        "threshold": THRESHOLD, "period": PERIOD, "seed": SEED,
        "val_from": "2026-08-14", "pairs": list(pairs),
        "classes": sorted(listed), "by_class": listed,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--window", type=int, action="append", default=None)
    parser.add_argument("--holes", choices=("sum", "max"), default="max",
                        help="діра рахується сумою розривів чи найбільшим")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--all", action="store_true",
                        help="усі класи, що є в усіх монет")
    args = parser.parse_args()

    if args.all:
        report = every(args.pair or list(PAIRS),
                       tuple(args.window or WINDOWS), args.data)
        args.out.mkdir(parents=True, exist_ok=True)
        for name, dump in (("class_new_leg_all.json", {}),
                           ("class_new_leg_all.meta.json", {"indent": 2})):
            (args.out / name).write_text(
                json.dumps(strict(report), ensure_ascii=False,
                           allow_nan=False, **dump), encoding="utf-8")
        print(f"\nзаписано в {args.out / 'class_new_leg_all.json'}")
        return

    report = build(args.pair or list(PAIRS), args.class_name,
                   tuple(args.window or WINDOWS), args.data, args.holes)
    args.out.mkdir(parents=True, exist_ok=True)
    stem = "class_new_leg" if args.class_name == CLASS \
        else f"class_new_leg_{args.class_name}"
    for name, dump in ((f"{stem}.json", {}),
                       (f"{stem}.meta.json", {"indent": 2})):
        (args.out / name).write_text(
            json.dumps(strict(report), ensure_ascii=False, allow_nan=False,
                       **dump), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{stem}.json'}")


if __name__ == "__main__":
    main()
