"""За скільки подій видно, що почалась нова нога.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md, rules/03-models.md

Ціль: узяти останні `X` подій ряду і сказати, чи **всередині них** стався
розворот зігзага 2.3 % — тобто чи це початок нової ноги. `X` перебирається
від 5 до 100 подій, щоб побачити ціну затримки: коротке вікно відповідає
швидше, довге — точніше.

Крім самого вікна модель дістає **порівняння з попереднім вікном** такої
самої довжини: у вікні початку нової ноги хід зламався, і попередні `X`
подій ішли в інший бік. Звідси три сімʼї ознак:

    вікно      рух, розкид, шлях, підйом, просадка, прямота, нахили
    злам       де у вікні лежить вершина ходу і скільки шляху після неї
    контраст   те саме проти попередніх X подій: відношення шляху й
               розкиду, різниця напрямків, кут між ходами

Мітка: подія лежить у перших `X` подіях своєї ноги (розворот усередині
вікна). Ознаки — тільки з минулого, мітка — з розмітки зігзага.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/new_leg.json      — на кожне X: AUC, крива порога, затримка
       results/new_leg.meta.json — те саме

Запуск:
    python3 research/28-leg-edge-profile/scripts/new_leg.py
    python3 research/28-leg-edge-profile/scripts/new_leg.py --window 20
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from edge_profile import HOLE, PERIOD, ROW_CLASS, THRESHOLD  # noqa: E402
from edge_profile import legs_of, load  # noqa: E402
from event_edges import slopes  # noqa: E402
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

WINDOWS = (5, 10, 20, 39, 60, 100)
TOPS = (0.001, 0.005, 0.01, 0.02, 0.05, 0.10)


def window_block(v: np.ndarray, size: int) -> dict:
    """Ознаки одного вікна: хід, злам усередині нього, форма."""
    view = sliding_window_view(v, size)
    cum = np.cumsum(view, axis=1)
    peak = np.argmax(cum, axis=1)
    pit = np.argmin(cum, axis=1)
    rows = np.arange(view.shape[0])
    path = np.abs(view).sum(axis=1)
    total = view.sum(axis=1)
    return {
        "v_sum": total, "v_std": view.std(axis=1), "path": path,
        "v_abs": np.abs(view).mean(axis=1), "v_max": view.max(axis=1),
        "v_min": view.min(axis=1), "up_share": (view > 0).mean(axis=1),
        "run_up": cum.max(axis=1), "draw_down": cum.min(axis=1),
        "v_slope": slopes(view),
        "straight": np.divide(total, path, out=np.zeros_like(total),
                              where=path != 0),
        # злам: де у вікні вершина ходу і скільки шляху лишилось після неї
        "peak_at": peak / max(size - 1, 1),
        "pit_at": pit / max(size - 1, 1),
        "after_peak": cum[:, -1] - cum[rows, peak],
        "after_pit": cum[:, -1] - cum[rows, pit],
    }


def features(data: dict, size: int) -> tuple[np.ndarray, list, np.ndarray]:
    """Вікно останніх `size` подій і його контраст із попереднім таким."""
    v = np.log(data["close"] / data["open"])
    block = window_block(v, size)
    count = len(v) - 2 * size + 1              # де є і вікно, і попереднє
    columns = {}
    for name, column in block.items():
        columns[name] = column[size:]          # поточне вікно
        columns[f"was_{name}"] = column[:-size]  # попереднє вікно
    for name in ("path", "v_std", "v_abs"):
        near, was = columns[name], columns[f"was_{name}"]
        columns[f"ratio_{name}"] = np.divide(near, was,
                                             out=np.ones_like(near),
                                             where=was != 0)
    # злам напрямку: різниця ходів і те, чи змінився знак
    columns["turn"] = columns["v_sum"] - columns["was_v_sum"]
    columns["turned"] = ((columns["v_sum"] * columns["was_v_sum"]) < 0
                         ).astype(float)
    columns["price"] = np.log(data["open"][2 * size - 1:])
    names = sorted(columns)
    matrix = np.column_stack([columns[name][:count] for name in names])
    return matrix, names, np.arange(2 * size - 1, len(v))


def marks(data: dict, index: np.ndarray, size: int) -> dict:
    """Мітка: розворот стався всередині вікна — подія з перших `size` ноги."""
    _, legs = legs_of(data)
    total = len(data["t"])
    from_start = np.full(total, -1)
    for leg in legs:
        if leg["hole_hours"] * 3600 > HOLE:
            continue
        first, last = leg["first"], leg["last"]
        from_start[first:last + 1] = np.arange(last - first + 1)
    keep = index[from_start[index] >= 0]
    return {"index": keep, "from_start": from_start[keep],
            "part": np.where(data["t"][keep] >= VAL_FROM, "val", "train"),
            "y": (from_start[keep] < size).astype(int)}


def collect(pairs, class_name: str, size: int, root: Path | None) -> dict:
    rows = {"x": [], "y": [], "part": [], "from_start": []}
    names = []
    for pair in pairs:
        data = load(pair, class_name, root)
        matrix, names, index = features(data, size)
        found = marks(data, index, size)
        picked = np.searchsorted(index, found["index"])
        rows["x"].append(matrix[picked])
        rows["y"].append(found["y"])
        rows["part"].append(found["part"])
        rows["from_start"].append(found["from_start"])
    return {"x": np.vstack(rows["x"]), "features": names,
            "y": np.concatenate(rows["y"]),
            "part": np.concatenate(rows["part"]),
            "from_start": np.concatenate(rows["from_start"])}


def learn(rows: dict, size: int) -> dict:
    """Бустинг на вікні: AUC, крива порога і затримка сигналу після півота."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import roc_auc_score

    train = rows["part"] == "train"
    val = ~train
    y_train, y_val = rows["y"][train], rows["y"][val]
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(rows["x"][train], y_train)
    score = model.predict_proba(rows["x"][val])[:, 1]
    steps = rows["from_start"][val]
    base = float(y_val.mean())
    curve = []
    for share in TOPS:
        limit = float(np.quantile(score, 1 - share))
        top = score >= limit
        hit = top & (y_val > 0)
        curve.append({
            "share": share, "limit": limit, "events": int(top.sum()),
            "precision": float(y_val[top].mean()),
            "lift": float(y_val[top].mean() / base) if base else 0.0,
            "recall": float(y_val[top].sum() / max(y_val.sum(), 1)),
            "lag": float(np.median(steps[hit]) + 1) if hit.any() else 0.0,
        })
    singles = sorted(
        ({"feature": name,
          "auc": float(roc_auc_score(y_val, rows["x"][val][:, number]))}
         for number, name in enumerate(rows["features"])),
        key=lambda one: -abs(one["auc"] - 0.5))[:6]
    return {"window": size, "base": base,
            "events": {"train": int(train.sum()), "val": int(val.sum())},
            "auc": float(roc_auc_score(y_val, score)),
            "curve": curve, "singles": singles}


def build(pairs=PAIRS, class_name: str = ROW_CLASS, windows=WINDOWS,
          root: Path | None = None) -> dict:
    return {
        "script": "research/28-leg-edge-profile/scripts/new_leg.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "windows": list(windows), "tops": list(TOPS), "seed": SEED,
        "val_from": "2026-08-14", "pairs": list(pairs),
        "about": "розворот стався всередині останніх X подій",
        "by_window": {str(size): learn(collect(pairs, class_name, size, root),
                                       size) for size in windows},
        "ready": True,
    }


def show(report: dict) -> None:
    print("розворот усередині останніх X подій\n")
    print(f"{'X':>4} {'частка':>7} {'AUC':>7}   "
          f"точність на верхівці 0.1 / 1 / 5 %   затримка на 1 %")
    for size in report["windows"]:
        block = report["by_window"][str(size)]
        curve = {one["share"]: one for one in block["curve"]}
        print(f"{size:>4} {block['base']:>7.3f} {block['auc']:>7.3f}   "
              f"{curve[0.001]['precision']:.3f} / "
              f"{curve[0.01]['precision']:.3f} / "
              f"{curve[0.05]['precision']:.3f}"
              f"              {curve[0.01]['lag']:.0f} подій")
    print("\nнайсильніші окремі ознаки")
    for size in report["windows"]:
        block = report["by_window"][str(size)]
        line = " · ".join(f"{one['feature']} {one['auc']:.3f}"
                          for one in block["singles"][:3])
        print(f"  X={size:<4} {line}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--window", type=int, action="append", default=None)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name,
                   tuple(args.window or WINDOWS), args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, dump in (("new_leg.json", {}),
                       ("new_leg.meta.json", {"indent": 2})):
        (args.out / name).write_text(
            json.dumps(strict(report), ensure_ascii=False, allow_nan=False,
                       **dump), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'new_leg.json'}")


if __name__ == "__main__":
    main()
