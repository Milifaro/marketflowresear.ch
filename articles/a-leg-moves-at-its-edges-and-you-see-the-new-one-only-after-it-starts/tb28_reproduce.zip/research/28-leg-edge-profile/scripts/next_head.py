"""Хвіст попередньої ноги: чи видно з нього початок наступної.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md, rules/03-models.md

Етапи 2 і 3 читали початок ноги. Тут читається **кінець попередньої**:
останні 39 подій ноги A, і з них ставиться питання про перші 39 подій
ноги B, що йде одразу за півотом.

Напрямок ноги B питати нема сенсу — на зігзагу ноги чергуються, і він
відомий наперед. Питається **як саме почнеться** нога B:

    head_move    рух перших 39 подій, за напрямком ноги B
    head_std     розкид подій початку
    head_path    пройдений шлях початку
    head_max     найбільша подія початку, |ln|
    head_speed   ln подій, щоб ціна відійшла від півота на 0.15 %
    head_share   частка подій, що йдуть за ногою
    next_events  ln довжини ноги B у подіях

Поруч із моделлю стоїть **перенос**: та сама ознака хвоста прямо, без
навчання (`v_std` хвоста проти `head_std` початку). Якщо модель не
кращаза перенос, то нічого, крім тривання волатильності, тут немає.

Пара ніг береться, тільки якщо **обидві** без дір довших за годину.
Розбиття за датою: пара йде у `val`, якщо нога B починається від
2026-08-14.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/next_head.json      — пари ніг, ознаки, цілі, якість
       results/next_head.meta.json — те саме без переліку пар

Запуск:
    python3 research/28-leg-edge-profile/scripts/next_head.py
    python3 research/28-leg-edge-profile/scripts/next_head.py --tail 100
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import HOLE, PERIOD, ROW_CLASS, THRESHOLD  # noqa: E402
from edge_profile import legs_of, load  # noqa: E402
from leg_start import HEAD, SEED, TREES, VAL_FROM  # noqa: E402
from leg_start import head_features, matrix, spread, strict  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

MOVE = 0.0015              # межа для `head_speed`: рух від півота

TARGETS = {
    "head_move": "рух перших подій ноги B, за її напрямком",
    "head_std": "розкид подій початку ноги B",
    "head_path": "пройдений шлях початку ноги B",
    "head_max": "найбільша подія початку ноги B, |ln|",
    "head_speed": "ln подій, щоб ціна відійшла від півота на 0.15 %",
    "head_share": "частка подій початку, що йдуть за ногою B",
    "next_events": "ln довжини ноги B у подіях",
}

# Ознака хвоста, яку модель має перебити: те саме число на попередній нозі.
# `n` у хвості завжди однакове, тому для швидкості й довжини переносяться
# ті числа хвоста, які справді гуляють: розмах події і час на 39 подій.
CARRY = {"head_move": "v_sum", "head_std": "v_std", "head_path": "path",
         "head_max": "v_max", "head_speed": "v_abs",
         "head_share": "up_share", "next_events": "seconds"}


def head_targets(data: dict, leg: dict, size: int) -> dict:
    """Яким виходить початок ноги B: рух, розкид, шлях, швидкість."""
    first = leg["first"]
    direction = 1 if leg["kind"] == "up" else -1
    piece = np.log(data["close"][first:first + size]
                   / data["open"][first:first + size]) * direction
    from_pivot = np.abs(np.log(data["close"][first:leg["last"] + 1]
                               / data["open"][first]))
    reached = np.flatnonzero(from_pivot >= MOVE)
    speed = int(reached[0]) + 1 if reached.size else leg["events"]
    return {"head_move": float(piece.sum()),
            "head_std": float(piece.std()),
            "head_path": float(np.abs(piece).sum()),
            "head_max": float(np.abs(piece).max()),
            "head_speed": float(np.log(max(speed, 1))),
            "head_share": float((piece > 0).mean()),
            "next_events": float(np.log(leg["events"]))}


def collect(pairs=PAIRS, class_name: str = ROW_CLASS, size: int = HEAD,
            root: Path | None = None) -> list:
    """Пара сусідніх ніг: хвіст ноги A і початок ноги B."""
    rows = []
    for pair in pairs:
        data = load(pair, class_name, root)
        smooth = ema(data["open"], PERIOD)
        _, legs = legs_of(data)
        for before, after in zip(legs, legs[1:]):
            if max(before["hole_hours"], after["hole_hours"]) * 3600 > HOLE:
                continue
            if before["events"] < size or after["events"] < size:
                continue
            stop = before["last"] + 1
            rows.append({
                "pair": pair, "leg": after["leg"], "kind": after["kind"],
                "before_kind": before["kind"],
                "before_events": before["events"],
                "before_move": before["move"]
                * (1 if before["kind"] == "up" else -1),
                "events": after["events"],
                "from": after["from"], "to": after["to"],
                "part": "val" if after["from"] >= VAL_FROM else "train",
                "x": head_features(data, stop - size, stop, smooth),
                "y": head_targets(data, after, size),
            })
    return rows


def learn(rows: list, names: list, target: str) -> dict:
    """Бустинг на хвості ноги A проти медіани train і проти переносу."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    from scipy.stats import spearmanr

    train = [row for row in rows if row["part"] == "train"]
    val = [row for row in rows if row["part"] == "val"]
    y_train = np.array([row["y"][target] for row in train], dtype=float)
    y_val = np.array([row["y"][target] for row in val], dtype=float)
    model = HistGradientBoostingRegressor(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
        min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
    model.fit(matrix(train, names), y_train)
    out = model.predict(matrix(val, names))
    base = float(np.median(y_train))
    err = float(np.median(np.abs(out - y_val)))
    base_err = float(np.median(np.abs(base - y_val)))
    carry = np.array([row["x"][CARRY[target]] for row in val], dtype=float)
    return {
        "target": target, "about": TARGETS[target],
        "legs": {"train": len(train), "val": len(val)},
        "spread": {"train": spread(y_train), "val": spread(y_val)},
        "spearman": float(spearmanr(out, y_val).statistic)
        if y_val.std() else 0.0,
        "err": err, "base_err": base_err,
        "gain": float(1 - err / base_err) if base_err else 0.0,
        "carry": CARRY[target],
        "carry_spearman": float(spearmanr(carry, y_val,
                                          nan_policy="omit").statistic),
    }


def build(pairs=PAIRS, class_name: str = ROW_CLASS, size: int = HEAD,
          root: Path | None = None) -> dict:
    rows = collect(pairs, class_name, size, root)
    names = sorted(rows[0]["x"]) if rows else []
    return {
        "script": "research/28-leg-edge-profile/scripts/next_head.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "size": size, "move": MOVE, "hole_hours": HOLE / 3600, "seed": SEED,
        "val_from": "2026-08-14", "pairs": list(pairs),
        "features": names, "about": TARGETS, "carry": CARRY,
        "legs": {"all": len(rows),
                 "train": sum(row["part"] == "train" for row in rows),
                 "val": sum(row["part"] == "val" for row in rows)},
        "by_kind": {kind: sum(row["kind"] == kind for row in rows)
                    for kind in ("up", "down")},
        "targets": {name: learn(rows, names, name) for name in TARGETS}
        if rows else {},
        "rows": rows, "ready": bool(rows),
    }


def show(report: dict) -> None:
    legs = report["legs"]
    print(f"пари ніг {legs['all']} (train {legs['train']} · val "
          f"{legs['val']}) · хвіст {report['size']} подій ноги A → "
          f"перші {report['size']} подій ноги B")
    print(f"\n{'ціль':<13} {'Спірмен':>8} {'виграш':>8}  перенос")
    for name, block in report["targets"].items():
        print(f"{name:<13} {block['spearman']:+8.3f} {block['gain']:+7.1%}  "
              f"{block['carry']:<8} {block['carry_spearman']:+.3f}")
    print("\nрозкид цілей на ногах val")
    for name, block in report["targets"].items():
        one = block["spread"]["val"]
        print(f"  {name:<13} медіана {one['median']:+.4f} · квартилі "
              f"{one['q1']:+.4f} … {one['q3']:+.4f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--tail", type=int, default=HEAD,
                        help="скільки подій брати з хвоста і з початку")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.tail,
                   args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "next_head.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "rows"}
    (args.out / "next_head.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'next_head.json'}")


if __name__ == "__main__":
    main()
