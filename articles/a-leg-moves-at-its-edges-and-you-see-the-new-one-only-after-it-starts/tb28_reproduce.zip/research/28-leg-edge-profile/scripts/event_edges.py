"""Подія кінця ноги і подія початку ноги: чи відрізняються вони від решти.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md, rules/03-models.md

Етапи 2–4 питали про ногу цілком. Тут питається про **окрему подію**:

    1  чи можна відрізнити подію кінця ноги від звичайної події ноги
    2  чи можна побачити, що почались події нової ноги
    3  на якому етапі формування ноги це стає видно

Кожна подія ряду дістає ознаки з **вікна своїх попередніх подій** —
нічого з майбутнього в них немає. Мітка навпаки береться з розмітки:
подія кінця — остання десятина ноги або останні 10 подій; подія початку —
перша десятина або перші 10 подій.

Оцінка моделі дивиться, куди вона росте вздовж ноги: середня видача по
десятинах і по позиції після півота показує, **коли** подія стає
помітною.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/event_edges.json      — якість, криві, пороги
       results/event_edges.meta.json — те саме без переліку подій

Запуск:
    python3 research/28-leg-edge-profile/scripts/event_edges.py
    python3 research/28-leg-edge-profile/scripts/event_edges.py --window 100
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import DECILES, HOLE, PERIOD, ROW_CLASS  # noqa: E402
from edge_profile import THRESHOLD, legs_of, load  # noqa: E402
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

WINDOW = 39                # скільки попередніх подій читає одна подія
MARKS = 10                 # скільки подій з краю ноги вважати краєм
TOP = 0.05                 # частка найвищих оцінок, на якій міряється точність
TOPS = (0.001, 0.005, 0.01, 0.02, 0.05, 0.10)   # уся крива порога

LABELS = {
    "end_fifth": "подія останніх двох десятин ноги",
    "end_decile": "подія останньої десятини ноги",
    "end_ten": f"подія з останніх {MARKS} подій ноги",
    "start_decile": "подія першої десятини ноги",
    "start_ten": f"подія з перших {MARKS} подій ноги",
    "near_pivot": f"подія в межах {MARKS} подій від півота, з будь-якого боку",
    "start_window": "розворот стався всередині вікна: подія з перших "
                    f"{WINDOW} подій ноги",
}

# Прості ознаки, кожна сама по собі: чи вистачає «рух більший за звичайний».
SINGLES = ("path", "v_abs", "v_std", "straight", "run_up", "draw_down",
           "v_max", "v_min")


def slopes(block: np.ndarray) -> np.ndarray:
    """Нахил прямої в кожному вікні: скалярний добуток зі сталою вагою."""
    size = block.shape[-1]
    steps = np.arange(size, dtype=float)
    weight = (steps - steps.mean()) / ((steps - steps.mean()) ** 2).sum()
    return block @ weight


def features(data: dict, window: int) -> tuple[np.ndarray, list, np.ndarray]:
    """Ознаки події з вікна її попередніх подій. Нічого з майбутнього."""
    v = np.log(data["close"] / data["open"])
    view = sliding_window_view(v, window)          # (n - window + 1, window)
    cum = np.cumsum(view, axis=1)
    smooth = sliding_window_view(ema(data["open"], PERIOD), window)
    columns = {
        "v_sum": view.sum(axis=1), "v_mean": view.mean(axis=1),
        "v_std": view.std(axis=1), "v_max": view.max(axis=1),
        "v_min": view.min(axis=1), "v_abs": np.abs(view).mean(axis=1),
        "v_last": view[:, -1], "up_share": (view > 0).mean(axis=1),
        "path": np.abs(view).sum(axis=1),
        "run_up": cum.max(axis=1), "draw_down": cum.min(axis=1),
        "v_slope": slopes(view), "ema_slope": slopes(smooth),
        "price": np.log(data["open"][window - 1:]),
    }
    columns["straight"] = np.divide(columns["v_sum"], columns["path"],
                                    out=np.zeros_like(columns["v_sum"]),
                                    where=columns["path"] != 0)
    blocks = data["x"].mean(axis=1)                # згортка блоків події
    for index, name in enumerate(data["features"]):
        piece = sliding_window_view(blocks[:, index], window)
        columns[f"{name}_mean"] = piece.mean(axis=1)
        columns[f"{name}_slope"] = slopes(piece)
    names = sorted(columns)
    matrix = np.column_stack([columns[name] for name in names])
    return matrix, names, np.arange(window - 1, len(v))


def marks(data: dict, index: np.ndarray, window: int) -> dict:
    """Мітки події: край ноги, десятина, позиція в нозі, частина вибірки."""
    place, legs = legs_of(data)
    size = len(data["t"])
    leg_id = np.full(size, -1)
    from_start = np.full(size, -1)
    to_end = np.full(size, -1)
    for number, leg in enumerate(legs):
        if leg["hole_hours"] * 3600 > HOLE:
            continue
        first, last = leg["first"], leg["last"]
        leg_id[first:last + 1] = number
        from_start[first:last + 1] = np.arange(last - first + 1)
        to_end[first:last + 1] = np.arange(last - first, -1, -1)
    keep = index[leg_id[index] >= 0]
    return {"index": keep, "decile": place[keep],
            "from_start": from_start[keep], "to_end": to_end[keep],
            "leg": leg_id[keep],
            "part": np.where(data["t"][keep] >= VAL_FROM, "val", "train"),
            "y": {"end_fifth": (place[keep] >= DECILES - 1).astype(int),
                  "end_decile": (place[keep] == DECILES).astype(int),
                  "end_ten": (to_end[keep] < MARKS).astype(int),
                  "start_decile": (place[keep] == 1).astype(int),
                  "start_ten": (from_start[keep] < MARKS).astype(int),
                  "near_pivot": ((to_end[keep] < MARKS)
                                 | (from_start[keep] < MARKS)).astype(int),
                  "start_window": (from_start[keep] < window).astype(int)},
            "window": window}


def collect(pairs=PAIRS, class_name: str = ROW_CLASS, window: int = WINDOW,
            root: Path | None = None) -> dict:
    rows = {"x": [], "pair": [], "decile": [], "from_start": [],
            "to_end": [], "part": [], "y": {name: [] for name in LABELS}}
    names = []
    for pair in pairs:
        data = load(pair, class_name, root)
        matrix, names, index = features(data, window)
        found = marks(data, index, window)
        picked = np.searchsorted(index, found["index"])
        rows["x"].append(matrix[picked])
        rows["pair"].append(np.full(found["index"].size, pair))
        for key in ("decile", "from_start", "to_end", "part"):
            rows[key].append(found[key])
        for name in LABELS:
            rows["y"][name].append(found["y"][name])
    return {"x": np.vstack(rows["x"]), "features": names,
            "pair": np.concatenate(rows["pair"]),
            "decile": np.concatenate(rows["decile"]),
            "from_start": np.concatenate(rows["from_start"]),
            "to_end": np.concatenate(rows["to_end"]),
            "part": np.concatenate(rows["part"]),
            "y": {name: np.concatenate(rows["y"][name]) for name in LABELS}}


def learn(rows: dict, label: str) -> dict:
    """Бустинг на вікні події: AUC на val і точність на верхівці оцінок."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import roc_auc_score

    train = rows["part"] == "train"
    val = ~train
    y_train, y_val = rows["y"][label][train], rows["y"][label][val]
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(rows["x"][train], y_train)
    score = model.predict_proba(rows["x"][val])[:, 1]
    limit = float(np.quantile(score, 1 - TOP))
    top = score >= limit
    base = float(y_val.mean())
    deciles = rows["decile"][val]
    walk = [float(score[deciles == part].mean()) if np.any(deciles == part)
            else 0.0 for part in range(1, DECILES + 1)]
    steps = rows["from_start"][val]
    after = [float(score[steps == step].mean()) if np.any(steps == step)
             else 0.0 for step in range(WINDOW)]
    singles = []
    for name in SINGLES:
        column = rows["x"][val][:, rows["features"].index(name)]
        singles.append({"feature": name,
                        "auc": float(roc_auc_score(y_val, column))})
    singles.sort(key=lambda one: -abs(one["auc"] - 0.5))
    return {
        "label": label, "about": LABELS[label],
        "singles": singles,
        "events": {"train": int(train.sum()), "val": int(val.sum())},
        "base": base, "auc": float(roc_auc_score(y_val, score)),
        "top": {"share": TOP, "limit": limit,
                "precision": float(y_val[top].mean()),
                "lift": float(y_val[top].mean() / base) if base else 0.0,
                "recall": float(y_val[top].sum() / max(y_val.sum(), 1))},
        "curve": [{"share": share,
                   "limit": float(np.quantile(score, 1 - share)),
                   "events": int((score >= np.quantile(score,
                                                       1 - share)).sum()),
                   "precision": float(
                       y_val[score >= np.quantile(score, 1 - share)].mean()),
                   "lift": float(
                       y_val[score >= np.quantile(score, 1 - share)].mean()
                       / base) if base else 0.0,
                   "recall": float(
                       y_val[score >= np.quantile(score, 1 - share)].sum()
                       / max(y_val.sum(), 1))}
                  for share in TOPS],
        "by_decile": walk, "after_pivot": after,
    }


def sides(rows: dict) -> dict:
    """Півот поруч — але з якого боку? Тільки події краю ноги.

    Детектор краю може казати просто «біля півота»: останні події ноги A
    і перші події ноги B стоять поруч і виглядають однаково. Тут беруться
    **лише** події краю, і питається, до півота вони чи після нього.
    """
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import roc_auc_score

    before = rows["to_end"] < MARKS
    after = rows["from_start"] < MARKS
    picked = (before | after) & ~(before & after)   # крихітні ноги — геть
    label = after[picked].astype(int)
    part = rows["part"][picked]
    x = rows["x"][picked]
    train, val = part == "train", part == "val"
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(x[train], label[train])
    score = model.predict_proba(x[val])[:, 1]
    hit = (score > 0.5) == (label[val] > 0)
    # Скільки подій відділяє подію від півота: після нього — від 1 до MARKS,
    # до нього — так само. Так видно, коли констатація стає впевненою.
    step = np.where(after[picked], rows["from_start"][picked] + 1,
                    rows["to_end"][picked] + 1)[val]
    walk = []
    for shift in range(1, MARKS + 1):
        for side, name in ((True, "після"), (False, "до")):
            mark = (step == shift) & ((label[val] > 0) == side)
            if mark.sum():
                walk.append({"offset": shift, "side": name,
                             "events": int(mark.sum()),
                             "accuracy": float(hit[mark].mean())})
    return {"about": "подія краю: після півота (1) чи до нього (0)",
            "events": {"train": int(train.sum()), "val": int(val.sum())},
            "base": float(label[val].mean()),
            "auc": float(roc_auc_score(label[val], score)),
            "accuracy": float(hit.mean()), "by_offset": walk}


def build(pairs=PAIRS, class_name: str = ROW_CLASS, window: int = WINDOW,
          root: Path | None = None) -> dict:
    rows = collect(pairs, class_name, window, root)
    return {
        "script": "research/28-leg-edge-profile/scripts/event_edges.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "window": window, "marks": MARKS, "top": TOP, "seed": SEED,
        "deciles": DECILES, "val_from": "2026-08-14", "pairs": list(pairs),
        "features": rows["features"], "about": LABELS,
        "events": {"all": int(rows["x"].shape[0]),
                   "train": int((rows["part"] == "train").sum()),
                   "val": int((rows["part"] == "val").sum())},
        "labels": {name: learn(rows, name) for name in LABELS},
        "sides": sides(rows),
        "ready": bool(rows["x"].size),
    }


def show(report: dict) -> None:
    events = report["events"]
    print(f"подій {events['all']} (train {events['train']} · val "
          f"{events['val']}) · вікно {report['window']} подій")
    print(f"\n{'мітка':<14} {'частка':>7} {'AUC':>7} "
          f"{'точність згори':>15} {'приріст':>8}")
    for name, block in report["labels"].items():
        print(f"{name:<14} {block['base']:>7.3f} {block['auc']:>7.3f} "
              f"{block['top']['precision']:>15.3f} "
              f"{block['top']['lift']:>7.2f}×")
    side = report["sides"]
    print(f"\nподія краю: до півота чи після — AUC {side['auc']:.3f}, "
          f"точність {side['accuracy']:.3f} на {side['events']['val']} "
          f"подіях val (база {side['base']:.3f})")
    print("\nодна ознака проти всієї моделі, AUC")
    for name, block in report["labels"].items():
        best = block["singles"][0]
        print(f"  {name:<14} модель {block['auc']:.3f} · "
              f"найкраща ознака {best['feature']} {best['auc']:.3f}")
    print("\nкрива порога: точність на верхівці оцінок")
    for name, block in report["labels"].items():
        line = "  ".join(f"{one['share'] * 100:g}%:{one['precision']:.3f}"
                         for one in block["curve"])
        print(f"  {name:<14} {line}")
    print("\nточність сторони за відстанню від півота, подій")
    for shift in range(1, MARKS + 1):
        line = "  ".join(
            f"{one['side']} {one['accuracy']:.3f} ({one['events']})"
            for one in side["by_offset"] if one["offset"] == shift)
        print(f"  {shift:>2}  {line}")
    print("\nсередня оцінка по десятинах ноги")
    for name, block in report["labels"].items():
        line = " ".join(f"{value:.3f}" for value in block["by_decile"])
        print(f"  {name:<14} {line}")
    print("\nсередня оцінка по позиції після півота (перші 10)")
    for name, block in report["labels"].items():
        line = " ".join(f"{value:.3f}" for value in block["after_pivot"][:10])
        print(f"  {name:<14} {line}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.window,
                   args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "event_edges.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    (args.out / "event_edges.meta.json").write_text(
        json.dumps(strict(report), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'event_edges.json'}")


if __name__ == "__main__":
    main()
