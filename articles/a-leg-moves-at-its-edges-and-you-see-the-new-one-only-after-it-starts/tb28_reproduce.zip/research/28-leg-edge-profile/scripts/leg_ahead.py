"""Прогноз середини й кінця ноги: з попередніх ніг і з власного початку.

Дослідження: research/28-leg-edge-profile/
Правила: rules/03-models.md → Навчання моделей

Питання: чи можна сказати наперед, **якими будуть події середини ноги**
(десятини 4–7) і **якими будуть події її кінця** (десятина 10), маючи

    попередню ногу        те, що закінчилось на останньому півоті
    ще одну ногу до неї   позаминулу ногу
    власний початок ноги  перші `HEAD` подій після півота

Ноги коротші за `SHORT` подій у замір не йдуть: інакше перші 39 подій
залазять у середину ноги і прогноз стає читанням відповіді
(39 / 130 = 0.30 — рівно межа третьої десятини).

Цілі — параметри **подій** відрізка, а не самої ціни:

    v_abs    середній модуль руху події, ln
    v_std    розкид рухів події
    path     сума модулів — скільки ціна пройшла на відрізку
    move     напрямлений хід відрізка
    events   скільки в ньому подій
    up_share частка подій у бік ноги

Кожна ціль міряється проти двох базових рівнів:

    медіана  train-медіана цілі — модель без жодного входу
    перенос  те саме число з попередньої ноги, без навчання

Ділень два. **За датою** — train до 14.08, val після: чесний час, але
на val лишається 58 ніг. **Відкладена монета** — модель учиться на пʼятьох
монетах і відповідає на шостій, і так шість разів: 382 ноги в замірі,
але час перемішаний. Перший каже, чи працює це наперед; другий — чи є
звʼязок узагалі.

Вхід : data/datasets/<PAIR>/class210x10x7/{train,val}.npz
Вихід: results/leg_ahead.json, results/leg_ahead.meta.json

Запуск:
    python3 research/28-leg-edge-profile/scripts/leg_ahead.py
    python3 research/28-leg-edge-profile/scripts/leg_ahead.py --head 60
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS  # noqa: E402
from edge_profile import (DECILES, HOLE, PERIOD, ROW_CLASS,  # noqa: E402
                          THRESHOLD, legs_of, load, value)
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

HEAD = 39                  # скільки подій початку ноги видно моделі
SHORT = 130                # коротші ноги не міряються: HEAD / SHORT = 0.30
MIDDLE = (4, 5, 6, 7)      # десятини середини
END = (DECILES,)           # десятина кінця
SETS = ("prev", "prev2", "head", "head_prev")
TARGETS = ("v_abs", "v_std", "path", "move", "events", "up_share")


def block(piece: np.ndarray, seconds: np.ndarray) -> dict:
    """Параметри подій відрізка, приведені до напрямку ноги."""
    if piece.size == 0:
        return {name: float("nan") for name in TARGETS}
    return {"v_abs": float(np.abs(piece).mean()),
            "v_std": float(piece.std()),
            "path": float(np.abs(piece).sum()),
            "move": float(piece.sum()),
            "events": float(piece.size),
            "up_share": float((piece > 0).mean())}


def parts_of(length: int) -> np.ndarray:
    return np.minimum(np.floor(np.arange(length) / length * DECILES) + 1,
                      DECILES).astype(int)


def leg_block(data: dict, values: np.ndarray, leg: dict) -> dict:
    """Ціла нога, її середина, її кінець і її перші HEAD подій."""
    first, last = leg["first"], leg["last"]
    direction = 1 if leg["kind"] == "up" else -1
    piece = values[first:last + 1] * direction
    steps = np.diff(data["t"][first:last + 2]) if last + 2 <= len(data["t"]) \
        else np.diff(data["t"][first:last + 1])
    parts = parts_of(piece.size)
    picked = {"leg": (parts > 0),
              "middle": np.isin(parts, MIDDLE),
              "end": np.isin(parts, END),
              "head": np.arange(piece.size) < HEAD}
    out = {}
    for name, mask in picked.items():
        got = block(piece[mask], steps[mask[:steps.size]])
        out[name] = got
    out["kind"] = leg["kind"]
    out["from"] = leg["from"]
    out["events"] = leg["events"]
    return out


def rows_of(pairs, root: Path | None, head: int) -> list:
    """Трійки ніг підряд: позаминула, минула, поточна."""
    global HEAD
    HEAD = head
    rows = []
    for pair in pairs:
        data = load(pair, ROW_CLASS, root)
        _, legs = legs_of(data)
        values = value(data, None)
        clean = [leg for leg in legs if leg["hole_hours"] * 3600 <= HOLE]
        blocks = {leg["leg"]: leg_block(data, values, leg) for leg in clean}
        order = {leg["leg"]: number for number, leg in enumerate(clean)}
        for leg in clean:
            number = order[leg["leg"]]
            if number < 2 or leg["events"] < SHORT:
                continue
            one, two = clean[number - 1], clean[number - 2]
            if one["leg"] != leg["leg"] - 1 or two["leg"] != leg["leg"] - 2:
                continue
            rows.append({"pair": pair, "leg": leg["leg"], "kind": leg["kind"],
                         "from": leg["from"], "events": leg["events"],
                         "now": blocks[leg["leg"]],
                         "prev": blocks[one["leg"]],
                         "prev2": blocks[two["leg"]],
                         "part": "val" if leg["from"] >= VAL_FROM else "train"})
    return rows


def columns(row: dict, kit: str) -> dict:
    """Вхід моделі: що саме їй видно."""
    out = {}
    if kit in ("prev", "prev2", "head_prev"):
        for where in ("leg", "end", "head"):
            for name, item in row["prev"][where].items():
                out[f"p1_{where}_{name}"] = item
        out["p1_same_side"] = float(row["prev"]["kind"] == row["kind"])
    if kit == "prev2":
        for where in ("leg", "end"):
            for name, item in row["prev2"][where].items():
                out[f"p2_{where}_{name}"] = item
    if kit in ("head", "head_prev"):
        for name, item in row["now"]["head"].items():
            out[f"h_{name}"] = item
        out["h_up"] = float(row["kind"] == "up")
    return out


def model_of(x_train, y_train):
    from sklearn.ensemble import HistGradientBoostingRegressor

    model = HistGradientBoostingRegressor(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
        min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
    model.fit(x_train, y_train)
    return model


def learn(rows: list, where: str, target: str, kit: str) -> dict:
    """Одна ціль на одному наборі входів проти медіани й переносу."""
    from scipy.stats import spearmanr

    names = sorted(columns(rows[0], kit))
    x = np.array([[columns(row, kit)[name] for name in names]
                  for row in rows], dtype=float)
    y = np.array([row["now"][where][target] for row in rows], dtype=float)
    carry = np.array([row["prev"][where][target] for row in rows], dtype=float)
    train = np.array([row["part"] == "train" for row in rows])
    good = np.isfinite(y) & np.isfinite(carry)
    train, val = train & good, (~train) & good
    if train.sum() < 30 or val.sum() < 15:
        return {"legs": int(val.sum())}
    model = model_of(x[train], y[train])
    out = model.predict(x[val])
    truth = y[val]
    base = float(np.median(y[train]))
    err = float(np.median(np.abs(out - truth)))
    base_err = float(np.median(np.abs(base - truth)))
    carry_err = float(np.median(np.abs(carry[val] - truth)))
    return {
        "target": f"{where}_{target}", "kit": kit,
        "legs": {"train": int(train.sum()), "val": int(val.sum())},
        "columns": len(names),
        "spearman": float(spearmanr(out, truth).statistic),
        "carry_spearman": float(spearmanr(carry[val], truth).statistic),
        "err": err, "median_err": base_err, "carry_err": carry_err,
        "gain": float(1 - err / base_err) if base_err else 0.0,
        "carry_gain": float(1 - carry_err / base_err) if base_err else 0.0,
        "truth_median": float(np.median(truth)),
    }


def apart(rows: list, where: str, target: str, kit: str) -> dict:
    """Той самий замір відкладеною монетою: усі 382 ноги в тесті."""
    from scipy.stats import spearmanr

    names = sorted(columns(rows[0], kit))
    x = np.array([[columns(row, kit)[name] for name in names]
                  for row in rows], dtype=float)
    y = np.array([row["now"][where][target] for row in rows], dtype=float)
    carry = np.array([row["prev"][where][target] for row in rows], dtype=float)
    coins = np.array([row["pair"] for row in rows])
    good = np.isfinite(y) & np.isfinite(carry)
    out = np.full(len(rows), np.nan)
    base = np.full(len(rows), np.nan)
    for coin in sorted(set(coins)):
        train = good & (coins != coin)
        test = good & (coins == coin)
        if train.sum() < 30 or test.sum() < 5:
            continue
        out[test] = model_of(x[train], y[train]).predict(x[test])
        base[test] = float(np.median(y[train]))
    seen = np.isfinite(out)
    if seen.sum() < 30:
        return {"legs": int(seen.sum())}
    truth = y[seen]
    err = float(np.median(np.abs(out[seen] - truth)))
    base_err = float(np.median(np.abs(base[seen] - truth)))
    carry_err = float(np.median(np.abs(carry[seen] - truth)))
    return {"legs": int(seen.sum()),
            "spearman": float(spearmanr(out[seen], truth).statistic),
            "carry_spearman": float(spearmanr(carry[seen], truth).statistic),
            "err": err, "median_err": base_err, "carry_err": carry_err,
            "gain": float(1 - err / base_err) if base_err else 0.0,
            "carry_gain": float(1 - carry_err / base_err) if base_err else 0.0}


def build(pairs=PAIRS, head: int = HEAD, root: Path | None = None) -> dict:
    rows = rows_of(pairs, root, head)
    table = {}
    for where in ("middle", "end"):
        for target in TARGETS:
            for kit in SETS:
                table.setdefault(f"{where}_{target}", {})[kit] = {
                    **learn(rows, where, target, kit),
                    "apart": apart(rows, where, target, kit)}
    val = [row for row in rows if row["part"] == "val"]
    return {
        "script": "research/28-leg-edge-profile/scripts/leg_ahead.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": ROW_CLASS,
        "head": head, "short": SHORT, "middle": list(MIDDLE),
        "end": list(END), "seed": SEED, "val_from": "2026-08-14",
        "pairs": list(pairs), "sets": list(SETS), "targets": list(TARGETS),
        "legs": {"all": len(rows), "val": len(val),
                 "train": len(rows) - len(val)},
        "by_target": table,
        "rows": [{key: row[key] for key in
                  ("pair", "leg", "kind", "from", "events", "part")}
                 for row in rows],
        "ready": bool(rows),
    }


def show(report: dict) -> None:
    print(f"ноги {report['legs']['all']} (train {report['legs']['train']}, "
          f"val {report['legs']['val']}), початок — {report['head']} подій, "
          f"коротші за {report['short']} подій не рахуються\n")
    print(f"{'ціль':<16} {'набір':<10} | за датою, 58 ніг      "
          f"| відкладена монета, {report['legs']['all']} ніг")
    print(f"{'':<16} {'':<10} | {'Спірмен':>8} {'виграш':>7} "
          f"| {'Спірмен':>8} {'виграш':>7} {'перенос':>8}")
    for name, block in report["by_target"].items():
        for kit in report["sets"]:
            one = block[kit]
            if "err" not in one:
                continue
            far = one["apart"]
            print(f"{name:<16} {kit:<10} | {one['spearman']:>+8.3f} "
                  f"{one['gain']:>+7.3f} | {far['spearman']:>+8.3f} "
                  f"{far['gain']:>+7.3f} {far['carry_gain']:>+8.3f}")
        print()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--head", type=int, default=HEAD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.head, args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, dump in (("leg_ahead.json", {}),
                       ("leg_ahead.meta.json", {"indent": 2})):
        (args.out / name).write_text(
            json.dumps(strict(report), ensure_ascii=False, allow_nan=False,
                       **dump), encoding="utf-8")
    show(report)
    print(f"записано в {args.out / 'leg_ahead.json'}")


if __name__ == "__main__":
    main()
