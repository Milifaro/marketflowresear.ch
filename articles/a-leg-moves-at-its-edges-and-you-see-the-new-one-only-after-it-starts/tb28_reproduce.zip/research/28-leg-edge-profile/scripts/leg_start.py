"""Перші 10 % ноги: що з них видно про решту ноги.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md, rules/03-models.md

Етап 1 показав, де в нозі лежить рух. Тут береться **тільки перша
десятина** кожної ноги — перші 10 % її подій — і з неї ставляться три
питання про решту 90 %:

    1  напрямок ноги            вгору чи вниз
    2  події завершення ноги    скільки їх ще буде, який рух принесе
                                остання десятина і які там події
    3  зустрічний рух           діапазон цінових різниць подій, що йдуть
                                проти ноги

Ноги, десятини, фільтр дір і приведення до напрямку — ті самі, що на
етапі 1 (`edge_profile.py`), тому обидва заміри стоять на одному ряді.

Розбиття за датою: нога йде у `val`, якщо її перша подія від 2026-08-14,
інакше — у `train`. Модель — градієнтний бустинг на ознаках першої
десятини; поруч рахується базовий рівень (частка більшого класу для
напрямку, медіана `train` для чисел), щоб було видно, чи є користь.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_start.json      — ноги, ознаки, цілі, якість
       results/leg_start.meta.json — те саме без переліку ніг

Запуск:
    python3 research/28-leg-edge-profile/scripts/leg_start.py
    python3 research/28-leg-edge-profile/scripts/leg_start.py --share 0.1
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import DATASETS, HOLE, PERIOD, ROW_CLASS, THRESHOLD  # noqa: E402,E501
from edge_profile import legs_of, load  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

SHARE = 0.10               # яка частка ноги з початку читається
HEAD = 39                  # стільки подій після півота — медіана тих 10 %
MOVES = (0.0015, 0.003, 0.005)   # або початок за рухом ціни від півота
VAL_FROM = 1786665600      # 2026-08-14 00:00 UTC — межа train / val
SEED = 17
TREES = 300
SIZE = ("n", "seconds")   # ознаки, що видають довжину ноги наперед

TARGETS = {
    "direction": "напрямок ноги: вгору (1) чи вниз (0)",
    "events_left": "ln подій до кінця ноги після першої десятини",
    "last_share": "частка руху ноги, яку принесе остання десятина",
    "last_event": "середній рух події останньої десятини, за ногою",
    "against_share": "частка подій решти ноги, що йдуть проти неї",
    "against_p90": "90-й процентиль зустрічної події, |ln|",
    "against_max": "найбільша зустрічна подія решти ноги, |ln|",
    "against_sum": "сума зустрічного руху решти ноги до руху ноги",
}


def slope(values: np.ndarray) -> float:
    """Нахил прямої по ряду: як величина йде всередині десятини."""
    if values.size < 2:
        return 0.0
    steps = np.arange(values.size, dtype=float)
    return float(np.polyfit(steps, values, 1)[0])


def head_features(data: dict, first: int, stop: int,
                  smooth: np.ndarray) -> dict:
    """Ознаки першої десятини ноги: тільки її події, нічого з майбутнього."""
    v = np.log(data["close"][first:stop] / data["open"][first:stop])
    t = data["t"][first:stop]
    cum = np.cumsum(v)
    row = {
        "n": float(v.size),
        "seconds": float(t[-1] - t[0]) if v.size > 1 else 0.0,
        "gap": float(np.median(np.diff(t))) if v.size > 1 else 210.0,
        "v_sum": float(v.sum()), "v_mean": float(v.mean()),
        "v_std": float(v.std()), "v_max": float(v.max()),
        "v_min": float(v.min()), "v_last": float(v[-1]),
        "v_abs": float(np.abs(v).mean()),
        "up_share": float((v > 0).mean()),
        "run_up": float(cum.max()), "draw_down": float(cum.min()),
        "path": float(np.abs(v).sum()),
        "ema_slope": slope(smooth[first:stop]),
        "price": float(np.log(data["open"][first])),
    }
    row["straight"] = row["v_sum"] / row["path"] if row["path"] else 0.0
    block = data["x"][first:stop].mean(axis=1)
    for index, name in enumerate(data["features"]):
        column = block[:, index]
        row[f"{name}_mean"] = float(column.mean())
        row[f"{name}_slope"] = slope(column)
    return row


def leg_targets(data: dict, leg: dict, stop: int,
                share: float = SHARE) -> dict:
    """Цілі: що станеться в решті ноги після першої десятини."""
    first, last = leg["first"], leg["last"]
    direction = 1 if leg["kind"] == "up" else -1
    rest = np.log(data["close"][stop:last + 1]
                  / data["open"][stop:last + 1]) * direction
    tail_from = last + 1 - max(1, int(round(leg["events"] * share)))
    tail = np.log(data["close"][tail_from:last + 1]
                  / data["open"][tail_from:last + 1]) * direction
    whole = np.log(data["close"][first:last + 1]
                   / data["open"][first:last + 1]) * direction
    total = float(whole.sum())
    against = -rest[rest < 0]
    return {
        "direction": 1.0 if leg["kind"] == "up" else 0.0,
        "events_left": float(np.log(max(rest.size, 1))),
        "last_share": float(tail.sum() / total) if total else 0.0,
        "last_event": float(tail.mean()),
        "against_share": float((rest < 0).mean()) if rest.size else 0.0,
        "against_p90": float(np.percentile(against, 90)) if against.size
        else 0.0,
        "against_max": float(against.max()) if against.size else 0.0,
        "against_sum": float(against.sum() / total) if total else 0.0,
    }


def head_by_move(data: dict, first: int, last: int, move: float) -> int:
    """Скільки подій треба, щоб ціна відійшла від півота на `move`.

    Причинний спосіб узяти початок: не «стільки подій», а «поки ціна не
    відійшла на стільки відсотків». Знак не важить — береться модуль,
    тому напрямок ноги в саму межу не закладено.
    """
    piece = np.log(data["close"][first:last + 1] / data["open"][first])
    reached = np.flatnonzero(np.abs(piece) >= move)
    return int(reached[0]) + 1 if reached.size else 0


def collect(pairs=PAIRS, class_name: str = ROW_CLASS, share: float = SHARE,
            root: Path | None = None, fixed: int | None = None,
            move: float | None = None) -> list:
    """Нога за ногою: ознаки початку ноги і цілі решти ноги.

    Три способи взяти початок:

    `share` — часткою подій ноги (перші 10 %); сам розмір такого початку
    вже знає довжину ноги. `fixed` — сталим числом подій після півота;
    про майбутнє в ознаках немає нічого, але розмір руху в початку
    гуляє. `move` — поки ціна не відійде від півота на стільки відсотків;
    розмір руху сталий, а число подій різне.
    """
    rows = []
    for pair in pairs:
        data = load(pair, class_name, root)
        smooth = ema(data["open"], PERIOD)
        _, legs = legs_of(data)
        for leg in legs:
            if leg["hole_hours"] * 3600 > HOLE:
                continue
            if move:
                head = head_by_move(data, leg["first"], leg["last"], move)
                if not head:
                    continue
                head = max(2, head)   # інакше ноги з різким першим
                                      # рухом випадали б з вибірки
            elif fixed:
                head = fixed
            else:
                head = max(1, int(round(leg["events"] * share)))
            stop = leg["first"] + head
            if leg["events"] - head < 5:
                continue
            rows.append({
                "pair": pair, "leg": leg["leg"], "kind": leg["kind"],
                "events": leg["events"], "head": head,
                "hole_hours": leg["hole_hours"],
                "from": leg["from"], "to": leg["to"],
                "move": leg["move"] * (1 if leg["kind"] == "up" else -1),
                "part": "val" if leg["from"] >= VAL_FROM else "train",
                "x": head_features(data, leg["first"], stop, smooth),
                "y": leg_targets(data, leg, stop, share),
            })
    return rows


def matrix(rows: list, names: list) -> np.ndarray:
    return np.array([[row["x"][name] for name in names] for row in rows],
                    dtype=float)


def spread(values: np.ndarray) -> dict:
    """Розкид ряду: квартилі, краї, середнє."""
    return {"median": float(np.median(values)),
            "q1": float(np.percentile(values, 25)),
            "q3": float(np.percentile(values, 75)),
            "p90": float(np.percentile(values, 90)),
            "min": float(values.min()), "max": float(values.max()),
            "mean": float(values.mean())}


def learn(rows: list, names: list, target: str) -> dict:
    """Бустинг на ознаках першої десятини: train до 14.08, val — після.

    Для напрямку рахується точність і AUC проти частки більшого класу,
    для чисел — кореляція Спірмена і **медіанна** похибка проти медіани
    train: середню тут ламає одна нога, у якої сума власних подій майже
    нульова, і частка останньої десятини в ній іде в десятки.
    """
    from sklearn.ensemble import (HistGradientBoostingClassifier,
                                  HistGradientBoostingRegressor)
    from sklearn.metrics import roc_auc_score
    from scipy.stats import spearmanr

    train = [row for row in rows if row["part"] == "train"]
    val = [row for row in rows if row["part"] == "val"]
    x_train, x_val = matrix(train, names), matrix(val, names)
    y_train = np.array([row["y"][target] for row in train], dtype=float)
    y_val = np.array([row["y"][target] for row in val], dtype=float)
    report = {"target": target, "about": TARGETS[target],
              "legs": {"train": len(train), "val": len(val)},
              "spread": {"train": spread(y_train), "val": spread(y_val)}}

    if target == "direction":
        model = HistGradientBoostingClassifier(
            max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
            min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
        model.fit(x_train, y_train)
        out = model.predict_proba(x_val)[:, 1]
        base = float(max(y_train.mean(), 1 - y_train.mean()))
        report.update({
            "kind": "клас",
            "accuracy": float(((out > 0.5) == (y_val > 0.5)).mean()),
            "auc": float(roc_auc_score(y_val, out)) if y_val.std() else 0.0,
            "base_accuracy": base,
            "train_accuracy": float(
                (model.predict(x_train) == y_train).mean()),
        })
        return report

    model = HistGradientBoostingRegressor(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
        min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
    model.fit(x_train, y_train)
    out = model.predict(x_val)
    base = float(np.median(y_train))
    report.update({
        "kind": "число",
        "spearman": float(spearmanr(out, y_val).statistic)
        if y_val.std() else 0.0,
        "err": float(np.median(np.abs(out - y_val))),
        "base_err": float(np.median(np.abs(base - y_val))),
        "train_err": float(np.median(np.abs(model.predict(x_train)
                                            - y_train))),
    })
    report["gain"] = float(1 - report["err"] / report["base_err"]) \
        if report["base_err"] else 0.0
    return report


def rule(rows: list) -> dict:
    """Правило без моделі: напрямок ноги за знаком руху першої десятини."""
    val = [row for row in rows if row["part"] == "val"]
    hit = [(row["x"]["v_sum"] > 0) == (row["y"]["direction"] > 0.5)
           for row in val]
    return {"about": "напрямок за знаком руху першої десятини",
            "legs": len(val), "accuracy": float(np.mean(hit)) if hit else 0.0}


def measure(rows: list, pairs) -> dict:
    """Один спосіб узяти початок ноги: скільки ніг, ознаки, якість цілей."""
    names = sorted(rows[0]["x"]) if rows else []
    blind = [name for name in names if name not in SIZE]
    return {
        "features": names,
        "legs": {"all": len(rows),
                 "train": sum(row["part"] == "train" for row in rows),
                 "val": sum(row["part"] == "val" for row in rows)},
        "head_events": spread(np.array([row["head"] for row in rows],
                                       dtype=float)) if rows else {},
        "targets": {name: learn(rows, names, name) for name in TARGETS}
        if rows else {},
        "targets_blind": {name: learn(rows, blind, name) for name in TARGETS}
        if rows else {},
        "rule": rule(rows) if rows else {},
        "by_pair": {pair: sum(row["pair"] == pair for row in rows)
                    for pair in pairs},
    }


def build(pairs=PAIRS, class_name: str = ROW_CLASS, share: float = SHARE,
          root: Path | None = None, fixed: int = HEAD,
          moves=MOVES) -> dict:
    """Одне питання трьома способами взяти початок ноги."""
    by_share = collect(pairs, class_name, share, root)
    by_fixed = collect(pairs, class_name, share, root, fixed=fixed)
    by_move = {f"{one}": collect(pairs, class_name, share, root, move=one)
               for one in moves}
    return {
        "script": "research/28-leg-edge-profile/scripts/leg_start.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "share": share, "fixed": fixed, "hole_hours": HOLE / 3600,
        "seed": SEED, "size_features": list(SIZE),
        "val_from": datetime.fromtimestamp(VAL_FROM, timezone.utc)
        .strftime("%Y-%m-%d"),
        "pairs": list(pairs), "about": TARGETS,
        "moves": list(moves),
        "share_head": measure(by_share, pairs),
        "fixed_head": measure(by_fixed, pairs),
        "move_head": {key: measure(rows, pairs)
                      for key, rows in by_move.items()},
        "rows": by_share, "rows_fixed": by_fixed, "ready": bool(by_share),
    }


def strict(node):
    """`NaN` у JSON браузер не читає — рівні без опори пишуться `null`.

    Самі рівні класу (`resist`, `support` і їхні баланси) бувають
    невизначені: опори в блоці не було. Модель читає їх як пропуск,
    а у файл вони йдуть `null`.
    """
    if isinstance(node, dict):
        return {key: strict(item) for key, item in node.items()}
    if isinstance(node, list):
        return [strict(item) for item in node]
    if isinstance(node, float) and not np.isfinite(node):
        return None
    return node


def show(report: dict) -> None:
    blocks = [(report["share_head"],
               f"початок = перші {report['share'] * 100:.0f} % ноги"),
              (report["fixed_head"],
               f"початок = перші {report['fixed']} подій після півота")]
    blocks += [(report["move_head"][key],
                f"початок = поки ціна не відійде на "
                f"{float(key) * 100:.2f} % від півота")
               for key in report["move_head"]]
    for block, title in blocks:
        legs = block["legs"]
        print(f"\n=== {title} ===")
        print(f"ноги {legs['all']} (train {legs['train']} · val "
              f"{legs['val']}), у початку медіана "
              f"{block['head_events']['median']:.0f} подій")
        print(f"правило «знак руху початку»: точність "
              f"{block['rule']['accuracy']:.3f} на "
              f"{block['rule']['legs']} ногах val")
        for name, part in (("усі ознаки", "targets"),
                           ("без довжини ноги", "targets_blind")):
            print(f"\n  {name}")
            block_show(block[part])
    print("\nрозкид цілей на ногах train")
    for name, block in report["share_head"]["targets"].items():
        one = block["spread"]["train"]
        print(f"  {name:<14} медіана {one['median']:+.4f} · квартилі "
              f"{one['q1']:+.4f} … {one['q3']:+.4f} · край {one['max']:+.4f}")


def block_show(targets: dict) -> None:
    print(f"  {'ціль':<14} {'val':>5}  якість на val")
    for name, block in targets.items():
        if block["kind"] == "клас":
            line = (f"точність {block['accuracy']:.3f} (база "
                    f"{block['base_accuracy']:.3f}) · AUC {block['auc']:.3f}")
        else:
            line = (f"Спірмен {block['spearman']:+.3f} · похибка "
                    f"{block['err']:.4f} проти базової "
                    f"{block['base_err']:.4f} ({block['gain']:+.1%})")
        print(f"  {name:<14} {block['legs']['val']:>5}  {line}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--share", type=float, default=SHARE)
    parser.add_argument("--head", type=int, default=HEAD,
                        help="стале число подій після півота")
    parser.add_argument("--move", type=float, action="append", default=None,
                        help="межа початку за рухом ціни від півота")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.share,
                   args.data, args.head, tuple(args.move or MOVES))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_start.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items()
            if key not in ("rows", "rows_fixed")}
    (args.out / "leg_start.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'leg_start.json'}")


if __name__ == "__main__":
    main()
