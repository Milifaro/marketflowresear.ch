"""Видача моделі «нова нога» рядом на val: ціна, сигнал, мітка.

Дослідження: research/28-leg-edge-profile/
Правила: rules/03-models.md, rules/05-visualization.md

Етап 6 виміряв модель числами. Тут та сама модель показується **рядом**:
на кожну монету — вікно валідації, ема ціни із зігзагом 2.3 %, під нею
сира видача моделі, поріг із `train` і смуги того, що з цього виходить.

Поріг береться **на train**, не на val: верхівка `TOP` оцінок навчальної
частини. Так число на val чесне — воно не підібране під ті самі дані.

Смуги під сигналом:

    влучив         сигнал на події, де розворот справді у вікні
    хибний         сигнал там, де розвороту у вікні немає
    проґавив       розворот у вікні є, а сигналу немає

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/new_leg_series.json          — перелік монет і межі
       results/new_leg_series_<PAIR>.json   — ряд однієї монети

Запуск:
    python3 research/28-leg-edge-profile/scripts/new_leg_series.py
    python3 research/28-leg-edge-profile/scripts/new_leg_series.py --top 0.02
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import DATASETS, PERIOD, ROW_CLASS  # noqa: E402
from edge_profile import THRESHOLD, load  # noqa: E402
from edge_profile import legs_of  # noqa: E402
from leg_start import SEED, TREES, strict  # noqa: E402
import class_new_leg as by_class  # noqa: E402
from new_leg import WINDOWS, collect, features, marks  # noqa: E402

SHOWN = (39, 100)          # довжини вікна, які показуються рядом
PRICE = "price"            # мова опису вікна: числа, пораховані з ходу ціни
# Решта мов — класи. Ряд один на всі смуги, тому беруться лише класи на
# **тій самій сітці подій**, що й ціна: `t_start`, 210 с на подію.
# Розріджені класи (`клас210х14х*`) мають свій ряд і свої ноги — вони
# міряються окремо в `class_new_leg.py --all`, але в спільну плашку не
# лягають.
GRID = "t_start"

RESULTS = RESEARCH_DIR / "results"

TOP = 0.01                 # верхівка оцінок train, з якої береться поріг
DIGITS = 6                 # знаків у ціні ряду


def utc(stamp: int) -> str:
    return datetime.fromtimestamp(int(stamp), timezone.utc) \
        .strftime("%Y-%m-%d %H:%M")


def dense(pairs, root: Path | None = None) -> list:
    """Класи на сітці ціни: ті, що лягають на спільний ряд плашки."""
    found = []
    for name in by_class.shared(pairs, root):
        with np.load((root or DATASETS) / pairs[0] / name
                     / "train.npz") as store:
            if GRID in store:
                found.append(name)
    return found


def rows_of(source: str, pairs, size: int, root: Path | None) -> dict:
    """Той самий ряд, описаний ціною або подіями якогось класу."""
    if source == PRICE:
        return collect(pairs, ROW_CLASS, size, root)
    return by_class.collect(pairs, source, size, root, holes="sum")


def window_of(source: str, data: dict, size: int):
    return features(data, size) if source == PRICE \
        else by_class.features(data, size)


def marks_of(source: str, data: dict, index, size: int) -> dict:
    return marks(data, index, size) if source == PRICE \
        else by_class.marks(data, index, size, holes="sum")


def title_of(source: str) -> str:
    return "ціна" if source == PRICE else source.replace("class", "клас")


def fit(source: str, pairs, size: int, root: Path | None,
        top: float = TOP):
    """Модель однієї мови опису і поріг із train."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    rows = rows_of(source, pairs, size, root)
    train = rows["part"] == "train"
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(rows["x"][train], rows["y"][train])
    inside = model.predict_proba(rows["x"][train])[:, 1]
    return model, float(np.quantile(inside, 1 - top))


def scores(pair: str, source: str, size: int, model, edge: float,
           root: Path | None) -> dict:
    """Видача однієї моделі на val однієї монети."""
    data = load(pair, ROW_CLASS if source == PRICE else source, root)
    matrix, _, index = window_of(source, data, size)
    found = marks_of(source, data, index, size)
    picked = np.searchsorted(index, found["index"])
    val = found["part"] == "val"
    score = model.predict_proba(matrix[picked][val])[:, 1]
    label = found["y"][val]
    fired = score >= edge
    # сигнал однією смугою: +1 — влучив, −1 — хибний, 0 — мовчить
    signal = np.where(fired & (label > 0), 1, np.where(fired, -1, 0))
    return {
        "place": found["index"][val],
        "source": source, "title": title_of(source),
        "edge": edge, "window": size, "seconds": size * 210,
        "score": [round(float(one), 4) for one in score],
        "label": label.astype(int).tolist(),
        "signal": signal.astype(int).tolist(),
        "counts": {"label": int(label.sum()), "fired": int(fired.sum()),
                   "hit": int(((label > 0) & fired).sum()),
                   "false": int(((label == 0) & fired).sum()),
                   "miss": int(((label > 0) & ~fired).sum())},
    }


def series(pair: str, class_name: str, models: dict, root: Path | None,
           top: float) -> dict:
    """Ряд однієї монети: ціна із зігзагом і **обидві** видачі на ній.

    Вікна різної довжини набирають історію з `train`, тому на `val` у них
    той самий перелік подій — обидві видачі лягають на одну вісь.
    """
    data = load(pair, class_name, root)
    smooth = ema(data["open"], PERIOD)
    legs = legs_of(data)[1]
    lanes, place = {}, None
    for key, (source, size, model, edge) in models.items():
        block = scores(pair, source, size, model, edge, root)
        if place is None:
            place = block["place"]
        elif not np.array_equal(place, block["place"]):
            raise ValueError(f"{pair}: {key} дивиться на інші події val")
        lanes[key] = {name: item for name, item in block.items()
                      if name != "place"}
    low, high = int(place.min()), int(place.max())
    return {
        "ready": True, "pair": pair, "events": int(place.size),
        "top": top, "threshold": THRESHOLD, "period": PERIOD,
        "class": class_name, "segments": by_class.SEGMENTS,
        "lanes": list(lanes),
        "from_utc": utc(data["t"][low]), "to_utc": utc(data["t"][high]),
        "t": data["t"][place].astype(int).tolist(),
        "price": [round(float(one), DIGITS) for one in smooth[place]],
        "pivots": [{"t": int(data["t"][leg["last"]]),
                    "ema": round(float(smooth[leg["last"]]), DIGITS),
                    "kind": "high" if leg["kind"] == "up" else "low"}
                   for leg in legs if low <= leg["last"] <= high],
        "by_lane": lanes,
    }


def build(pairs=PAIRS, class_name: str = ROW_CLASS, windows=SHOWN,
          root: Path | None = None, out: Path = RESULTS,
          top: float = TOP, sources=None) -> dict:
    """Модель на кожну мову опису × кожну довжину вікна, усі на одному ряді."""
    out.mkdir(parents=True, exist_ok=True)
    sources = list(sources or [PRICE, *dense(pairs, root)])
    models = {f"{source}:{size}": (source, size,
                                   *fit(source, pairs, size, root, top))
              for source in sources for size in windows}
    listed = []
    for pair in pairs:
        body = series(pair, class_name, models, root, top)
        (out / f"new_leg_series_{pair}.json").write_text(
            json.dumps(strict(body), ensure_ascii=False, allow_nan=False),
            encoding="utf-8")
        listed.append({"pair": pair, "events": body["events"],
                       "from_utc": body["from_utc"],
                       "to_utc": body["to_utc"],
                       "counts": {key: body["by_lane"][key]["counts"]
                                  for key in body["by_lane"]}})
    return {
        "script": "research/28-leg-edge-profile/scripts/new_leg_series.py",
        "ready": True, "windows": list(windows), "top": top,
        "sources": {source: title_of(source) for source in sources},
        "lanes": [{"id": key, "source": models[key][0],
                   "title": title_of(models[key][0]),
                   "window": models[key][1], "seconds": models[key][1] * 210,
                   "edge": models[key][3]} for key in models],
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "seed": SEED, "val_from": "2026-08-14", "pairs": list(pairs),
        "coins": listed,
    }


def show(report: dict) -> None:
    for lane in report["lanes"]:
        hours = lane["seconds"] / 3600
        print(f"\n=== {lane['title']}, вікно {lane['window']} подій "
              f"({hours:.1f} год) · поріг {lane['edge']:.4f} (верхівка "
              f"{report['top'] * 100:g} % оцінок train) ===")
        print(f"{'монета':<10} {'подій':>7} {'мітка':>7} {'сигнал':>7} "
              f"{'влучив':>7} {'хибний':>7} {'точність':>9}")
        shot = hit = 0
        for one in report["coins"]:
            counts = one["counts"][lane["id"]]
            fired = counts["hit"] + counts["false"]
            shot += fired
            hit += counts["hit"]
            print(f"{one['pair']:<10} {one['events']:>7} "
                  f"{counts['label']:>7} {counts['fired']:>7} "
                  f"{counts['hit']:>7} {counts['false']:>7} "
                  f"{counts['hit'] / fired if fired else 0:>9.3f}")
        print(f"{'разом':<10} {'':>7} {'':>7} {shot:>7} {hit:>7} "
              f"{shot - hit:>7} {hit / max(shot, 1):>9.3f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--window", type=int, action="append",
                        default=None)
    parser.add_argument("--source", action="append", default=None,
                        help="ціна (price) або імʼя класу; можна кілька")
    parser.add_argument("--top", type=float, default=TOP)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name,
                   tuple(args.window or SHOWN), args.data, args.out,
                   args.top, args.source)
    (args.out / "new_leg_series.json").write_text(
        json.dumps(strict(report), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'new_leg_series.json'}")


if __name__ == "__main__":
    main()
