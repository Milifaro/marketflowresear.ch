"""Початок ноги: ріст проти падіння.

Дослідження: research/28-leg-edge-profile/
Правила: rules/02-markup.md, rules/03-models.md

Етап 2 брав перші 39 подій після півота, не розділяючи ноги. Тут той
самий початок розбирається **окремо на ногах росту і окремо на ногах
падіння**: чим початки відрізняються між собою і які звʼязки з рештою
ноги в кожному напрямку є.

Чотири заміри:

    1  сам початок      31 ознака початку: медіана й квартилі на ногах
                        росту проти ніг падіння, критерій Манна-Вітні
                        і розмір ефекту (дельта Кліффа)
    2  хід усередині    рух події на кожній із 39 позицій початку,
                        ріст і падіння окремо
    3  звʼязки          Спірмен кожної ознаки з кожною ціллю решти ноги,
                        окремо ріст і падіння, на `train` з поправкою
                        Бенʼяміні-Хохберга і перевіркою на `val`
    4  модель нарізно   бустинг на ногах одного напрямку проти бустинга
                        на всіх ногах: чи дає розділення користь

Ноги, початок, ознаки й цілі — з `leg_start.py`, тому етапи 2 і 3
стоять на одному замірі.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/head_by_kind.json      — усі чотири заміри
       results/head_by_kind.meta.json — те саме без переліку ніг

Запуск:
    python3 research/28-leg-edge-profile/scripts/head_by_kind.py
    python3 research/28-leg-edge-profile/scripts/head_by_kind.py --head 100
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import HOLE, PERIOD, ROW_CLASS, THRESHOLD  # noqa: E402
from edge_profile import legs_of, load  # noqa: E402
from leg_start import HEAD, SEED, TARGETS, TREES, VAL_FROM  # noqa: E402
from leg_start import collect, matrix, strict  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

FDR = 0.05                 # рівень поправки Бенʼяміні-Хохберга
KINDS = ("up", "down")
SPLIT_TARGETS = ("events_left", "last_share", "against_p90", "against_sum")


def cliff(first: np.ndarray, second: np.ndarray) -> float:
    """Дельта Кліффа: наскільки один ряд лежить вище за другий.

    +1 — кожне значення першого ряду більше за будь-яке з другого,
    0 — ряди перемішані. Ранговий розмір ефекту, викиди його не рухають.
    """
    if not first.size or not second.size:
        return 0.0
    greater = (first[:, None] > second[None, :]).sum()
    less = (first[:, None] < second[None, :]).sum()
    return float((greater - less) / (first.size * second.size))


def clean(values: np.ndarray) -> np.ndarray:
    return values[np.isfinite(values)]


def spread(values: np.ndarray) -> dict:
    values = clean(values)
    if not values.size:
        return {"n": 0}
    return {"n": int(values.size), "median": float(np.median(values)),
            "q1": float(np.percentile(values, 25)),
            "q3": float(np.percentile(values, 75)),
            "mean": float(values.mean())}


def head_vs_head(rows: list, names: list) -> list:
    """Замір 1: ознака початку на ногах росту проти ніг падіння."""
    from scipy.stats import mannwhitneyu

    table = []
    for name in names:
        parts = {kind: clean(np.array([row["x"][name] for row in rows
                                       if row["kind"] == kind], dtype=float))
                 for kind in KINDS}
        if parts["up"].size < 3 or parts["down"].size < 3:
            continue
        test = mannwhitneyu(parts["up"], parts["down"],
                            alternative="two-sided")
        table.append({"feature": name,
                      "up": spread(parts["up"]),
                      "down": spread(parts["down"]),
                      "p": float(test.pvalue),
                      "delta": cliff(parts["up"], parts["down"])})
    table.sort(key=lambda one: -abs(one["delta"]))
    return table


def walk(pairs, class_name: str, head: int, root: Path | None) -> dict:
    """Замір 2: рух події на кожній позиції початку, ріст і падіння окремо."""
    steps = {kind: np.zeros((0, head)) for kind in KINDS}
    for pair in pairs:
        data = load(pair, class_name, root)
        _, legs = legs_of(data)
        for leg in legs:
            if leg["hole_hours"] * 3600 > HOLE:
                continue
            if leg["events"] - head < 5:
                continue
            first = leg["first"]
            piece = np.log(data["close"][first:first + head]
                           / data["open"][first:first + head])
            piece = piece * (1 if leg["kind"] == "up" else -1)
            steps[leg["kind"]] = np.vstack([steps[leg["kind"]], piece])
    return {kind: {"legs": int(block.shape[0]),
                   "mean": block.mean(axis=0).tolist(),
                   "median": np.median(block, axis=0).tolist(),
                   "abs_mean": np.abs(block).mean(axis=0).tolist(),
                   "cumulative": block.mean(axis=0).cumsum().tolist()}
            for kind, block in steps.items()}


def benjamini(values: list, level: float = FDR) -> float:
    """Поріг Бенʼяміні-Хохберга: 496 перевірок дають хибні знахідки самі."""
    if not values:
        return 0.0
    ordered = np.sort(np.array(values, dtype=float))
    count = ordered.size
    marks = ordered <= level * (np.arange(1, count + 1) / count)
    return float(ordered[marks].max()) if marks.any() else 0.0


def links(rows: list, names: list) -> dict:
    """Замір 3: звʼязок ознаки початку з ціллю решти ноги, у кожному напрямку.

    Шукається на `train`, поріг ставиться поправкою Бенʼяміні-Хохберга
    на всі перевірки разом, і кожна знахідка перевіряється на `val`:
    звʼязок вважається підтвердженим, якщо на `val` він того самого знака
    і не слабший за 0.15.
    """
    from scipy.stats import spearmanr

    found, all_p = {}, []
    for kind in KINDS:
        train = [row for row in rows
                 if row["kind"] == kind and row["part"] == "train"]
        val = [row for row in rows
               if row["kind"] == kind and row["part"] == "val"]
        block = []
        for name in names:
            x_train = np.array([row["x"][name] for row in train], dtype=float)
            x_val = np.array([row["x"][name] for row in val], dtype=float)
            for target in TARGETS:
                if target == "direction":
                    continue
                y_train = np.array([row["y"][target] for row in train],
                                   dtype=float)
                y_val = np.array([row["y"][target] for row in val],
                                 dtype=float)
                one = spearmanr(x_train, y_train, nan_policy="omit")
                other = spearmanr(x_val, y_val, nan_policy="omit")
                rho = float(one.statistic)
                if not np.isfinite(rho):
                    continue
                block.append({"feature": name, "target": target,
                              "rho": rho, "p": float(one.pvalue),
                              "val_rho": float(other.statistic)
                              if np.isfinite(other.statistic) else 0.0,
                              "legs": {"train": len(train), "val": len(val)}})
                all_p.append(float(one.pvalue))
        found[kind] = block

    limit = benjamini(all_p)
    for kind in KINDS:
        for one in found[kind]:
            one["strong"] = bool(one["p"] <= limit)
            one["held"] = bool(one["strong"]
                               and np.sign(one["val_rho"]) == np.sign(one["rho"])
                               and abs(one["val_rho"]) >= 0.15)
        found[kind].sort(key=lambda one: -abs(one["rho"]))
    return {"limit": limit, "checks": len(all_p), "fdr": FDR, "by_kind": found}


def apart(rows: list, names: list) -> dict:
    """Замір 4: модель на ногах одного напрямку проти моделі на всіх."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    from scipy.stats import spearmanr

    def fit(train: list, val: list, target: str) -> dict:
        if len(train) < 40 or len(val) < 10:
            return {"legs": {"train": len(train), "val": len(val)}}
        model = HistGradientBoostingRegressor(
            max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
            min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
        model.fit(matrix(train, names),
                  np.array([row["y"][target] for row in train], dtype=float))
        out = model.predict(matrix(val, names))
        truth = np.array([row["y"][target] for row in val], dtype=float)
        base = float(np.median([row["y"][target] for row in train]))
        err = float(np.median(np.abs(out - truth)))
        base_err = float(np.median(np.abs(base - truth)))
        return {"legs": {"train": len(train), "val": len(val)},
                "spearman": float(spearmanr(out, truth).statistic)
                if truth.std() else 0.0,
                "err": err, "base_err": base_err,
                "gain": float(1 - err / base_err) if base_err else 0.0}

    report = {}
    for target in SPLIT_TARGETS:
        report[target] = {}
        for kind in KINDS:
            same = [row for row in rows if row["kind"] == kind]
            train = [row for row in same if row["part"] == "train"]
            val = [row for row in same if row["part"] == "val"]
            whole = [row for row in rows if row["part"] == "train"]
            report[target][kind] = {
                "apart": fit(train, val, target),
                "together": fit(whole, val, target),
            }
    return report


def build(pairs=PAIRS, class_name: str = ROW_CLASS, head: int = HEAD,
          root: Path | None = None) -> dict:
    rows = collect(pairs, class_name, root=root, fixed=head)
    names = sorted(rows[0]["x"]) if rows else []
    return {
        "script": "research/28-leg-edge-profile/scripts/head_by_kind.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "head": head, "hole_hours": HOLE / 3600, "seed": SEED,
        "val_from": "2026-08-14", "pairs": list(pairs),
        "features": names, "about": TARGETS,
        "legs": {kind: {"all": sum(row["kind"] == kind for row in rows),
                        "train": sum(row["kind"] == kind
                                     and row["part"] == "train"
                                     for row in rows),
                        "val": sum(row["kind"] == kind
                                   and row["part"] == "val" for row in rows)}
                 for kind in KINDS},
        "heads": head_vs_head(rows, names) if rows else [],
        "walk": walk(pairs, class_name, head, root),
        "links": links(rows, names) if rows else {},
        "apart": apart(rows, names) if rows else {},
        "rows": rows, "ready": bool(rows),
    }


def show(report: dict) -> None:
    legs = report["legs"]
    print(f"перші {report['head']} подій ноги · ріст {legs['up']['all']} ніг "
          f"(val {legs['up']['val']}) · падіння {legs['down']['all']} "
          f"(val {legs['down']['val']})")

    print("\nознаки початку: ріст проти падіння (за дельтою Кліффа)")
    for one in report["heads"][:12]:
        print(f"  {one['feature']:<18} ріст {one['up']['median']:+.5f} · "
              f"падіння {one['down']['median']:+.5f} · дельта "
              f"{one['delta']:+.3f} · p {one['p']:.1e}")

    print("\nхід усередині початку, рух за ногою")
    for kind in KINDS:
        block = report["walk"][kind]
        line = " ".join(f"{value * 100:+.3f}" for value in block["mean"][:8])
        print(f"  {'ріст' if kind == 'up' else 'падіння':<8} "
              f"{block['legs']:>4} ніг · перші 8 подій, %: {line} · "
              f"сума за {report['head']} подій "
              f"{block['cumulative'][-1] * 100:+.2f} %")

    found = report["links"]
    print(f"\nзвʼязки з рештою ноги: {found['checks']} перевірок, "
          f"поріг Бенʼяміні-Хохберга {found['limit']:.2e}")
    for kind in KINDS:
        block = [one for one in found["by_kind"][kind] if one["held"]]
        print(f"  {'ріст' if kind == 'up' else 'падіння'}: "
              f"{len(block)} звʼязків витримали val")
        for one in block[:8]:
            print(f"    {one['feature']:<18} → {one['target']:<14} "
                  f"train {one['rho']:+.3f} · val {one['val_rho']:+.3f}")

    print("\nмодель нарізно проти спільної, Спірмен на val")
    for target, block in report["apart"].items():
        line = " · ".join(
            f"{'ріст' if kind == 'up' else 'падіння'} "
            f"{block[kind]['apart'].get('spearman', 0):+.3f} проти "
            f"{block[kind]['together'].get('spearman', 0):+.3f}"
            for kind in KINDS)
        print(f"  {target:<14} {line}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--head", type=int, default=HEAD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.head,
                   args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "head_by_kind.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "rows"}
    (args.out / "head_by_kind.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'head_by_kind.json'}")


if __name__ == "__main__":
    main()
