"""Етап 20: сигнал купівлі з видачі мереж етапу 19 і торгівля лише купівлями на val BTC.

Дослідження: research/36-canvas600-pivots/ → Етап 20

## Хід (без заглядання вперед)

1. **Видача** — P(T у зоні дна) кожної епохи кожного прогону етапу 19 на
   кожен T val BTC кожні 10 хв (`results/canvas1100_buy/<прогін>_val.npz`).
2. **Сигнал** — сума видачі в ковзному вікні з `W` останніх кроків T
   (`S[k] = P[k − W + 1] + … + P[k]`); купівля — `S[k] ≥ θ`. `θ` — квантиль
   ряду `S` цієї епохи (шкали мереж різні).
3. **Угода** — лише купівля. Сигнал у T без позиції — вхід ціною open
   наступного запису 100 с після T. Тейк-профіт — найнижча ціна від
   входу (open входу і close записів після нього) + 2 %: ціна після входу
   падає — тейк спускається за нею; стоп-лос — ціна входу − `SL`. Перший
   запис, чий close дійшов до рівня, закриває угоду ціною open наступного
   запису. Сигнали купівлі, поки
   угода відкрита, — підтвердження, дій немає.
4. **Фейк після закритої угоди** — коли вже була закрита угода, сигнал
   ігнорується, якщо найбільший close між попереднім сигналом і поточним
   менший за ціну поточного сигналу × 1.023 (ціна не піднялась на 2.3 %
   між сигналами — те саме дно, яке вже відторговано).
5. **Витрати** — комісія 0.05 % і сліпедж 0.02 % за бік, гроші — `Decimal`,
   старт $1000; угода, відкрита в кінці ряду, закривається останнім записом.
6. **Еталон** — ідеальна торгівля по зігзагу 2.3 % ряду val лише купівлями:
   кожна нога вгору в межах T моделі (вершина після першого T, дно не
   пізніше останнього) — купівля open запису після дна (дно раніше
   першого T — після запису першого T), продаж open запису після вершини,
   ті самі витрати.
7. **Близькість до еталона** — кожна угода моделі належить циклу своєї
   ідеальної угоди: від попередньої вершини до вершини цієї ноги (угоди
   після останньої вершини — у хвіст без еталона). Результат циклу —
   добуток `(1 + r)` угод моделі в ньому мінус 1; розрив — ідеальна
   `R` мінус результат циклу. **Частка еталона** = Σ результатів циклів /
   Σ `R`: хто ближче до еталона (менший сумарний розрив), у того більша
   частка. Рівні — більший PnL, далі менше угод.
8. **Грід** — усі прогони × усі епохи × `WINDOWS` × `QUANTILES` × `STOPS`;
   найкраща комбінація кожної епохи і кожного прогону. ★ зафіксований
   (`STAR`) — переможець підбору з тейком від ціни входу, `BUY_pos` е9:
   вікно 18, квантиль 0.97, стоп 2 %; міряється за поточними правилами і,
   для порівняння, з тейком від ціни входу (`entry`).

Вихід: results/canvas1100_buy/signal_pick.json — еталон, найкраща
комбінація кожної епохи кожного прогону, найкраща епоха кожного прогону,
★ з угодами і таблицею циклів, той самий ★ з тейком від ціни входу (`entry`).

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy_signal.py
"""

from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from decimal import Decimal
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100_random as rnd  # noqa: E402

RESULTS = SCRIPTS.parent / "results" / "canvas1100_buy"
PAIR = "BTC_USDT"
BAR = 100
TAKE = 0.02                       # тейк-профіт від ціни входу
FAKE = 0.023                      # підйом між сигналами, без якого сигнал після угоди — фейк
FEE = Decimal("0.0005")           # taker за бік
SLIP = Decimal("0.0002")          # сліпедж за бік
START = Decimal("1000")
WINDOWS = (1, 2, 3, 6, 12, 18, 24, 36, 48, 72)          # кроків T по 10 хв
QUANTILES = (0.5, 0.7, 0.8, 0.85, 0.9, 0.93, 0.95, 0.97, 0.98, 0.99)
STOPS = (0.005, 0.01, 0.015, 0.02, 0.03, 0.04, 0.05)
# ★ зафіксований: переможець підбору з тейком від ціни входу — прогін, епоха,
# вікно суми, квантиль θ і стоп; далі міряється за поточними правилами угоди
STAR = {"run": "BUY_pos", "epoch": 9, "window": 18, "quantile": 0.97, "stop": 0.02}


def market() -> dict:
    """Записи 100 с val BTC і півоти зігзага 2.3 % на них."""
    one = rnd.series_of(PAIR, "val")
    return {"t": one["t"], "open": one["open"], "close": one["close"],
            "pivot": one["pivots"]["index"], "top": np.asarray(one["pivots"]["top"], dtype=bool)}


def rolling_sum(p: np.ndarray, w: int) -> np.ndarray:
    c = np.concatenate([[0.0], np.cumsum(p)])
    k = np.arange(len(p))
    return c[k + 1] - c[np.maximum(k + 1 - w, 0)]


def ideal(rec: dict, first_t: int, last_t: int) -> list:
    """Еталон: ноги вгору, що йдуть у межах T моделі (вершина після першого T,
    дно не пізніше останнього), — купівля open запису після дна (дно раніше
    першого T — після запису першого T), продаж open запису після вершини."""
    cost = FEE + SLIP
    last = len(rec["t"]) - 1
    first = int(np.searchsorted(rec["t"] + BAR, first_t))
    out = []
    for a, b, top_a, top_b in zip(rec["pivot"][:-1], rec["pivot"][1:], rec["top"][:-1], rec["top"][1:]):
        if top_a or not top_b:
            continue
        if rec["t"][b] + BAR <= first_t or rec["t"][a] + BAR > last_t:
            continue
        start = max(int(a), first)
        buy = Decimal(str(rec["open"][min(start + 1, last)]))
        sell = Decimal(str(rec["open"][min(b + 1, last)]))
        r = (1 - cost) * (sell / buy) * (1 - cost) - 1
        out.append({"bottom": start, "top": int(b), "bottom_t": int(rec["t"][start]),
                    "top_t": int(rec["t"][b]), "buy": float(buy), "sell": float(sell), "r": float(r)})
    return out


class Exits:
    """Вихід угоди, відкритої ціною open запису `i`: тейк — close дійшов до
    найнижчої ціни від входу (open входу і close записів після нього) × (1 + тейк),
    тобто тейк спускається за ціною, поки та падає; стоп — close дійшов до
    ціни входу × (1 − стоп). Кеш на вхід і стоп."""

    def __init__(self, open_: np.ndarray, close: np.ndarray, trail: bool = True):
        self.open = open_
        self.close = close
        self.trail = trail        # False — тейк від ціни входу, нерухомий
        self.cache = {}

    def lows(self, i: int, j: int) -> np.ndarray:
        """База тейку на кожному записі `i … j` включно: найнижча ціна від
        входу, а без `trail` — ціна входу."""
        if not self.trail:
            return np.full(j - i + 1, self.open[i])
        return np.minimum(self.open[i], np.minimum.accumulate(self.close[i:j + 1]))

    def of(self, i: int, stop: float) -> tuple:
        key = (i, stop)
        if key not in self.cache:
            price = self.open[i]
            ahead = self.close[i:]
            low = np.minimum(price, np.minimum.accumulate(ahead)) if self.trail else price
            up = np.flatnonzero(ahead >= low * (1 + TAKE))
            down = np.flatnonzero(ahead <= price * (1 - stop))
            u = up[0] if len(up) else len(ahead)
            d = down[0] if len(down) else len(ahead)
            if u == d == len(ahead):
                self.cache[key] = (len(self.close) - 1, "end")
            elif u <= d:
                self.cache[key] = (i + int(u), "take")
            else:
                self.cache[key] = (i + int(d), "stop")
        return self.cache[key]


def simulate(rec: dict, ends: np.ndarray, fire: np.ndarray, stop: float, exits: Exits,
             peaks) -> dict:
    """Прохід по кроках T. `ends` — запис кожного T, `fire` — сигнал у T."""
    cost = FEE + SLIP
    last = len(rec["t"]) - 1
    money = START
    trades, fakes = [], 0
    busy_until = -1               # запис, на якому закрилась остання угода
    prev = None                   # запис попереднього сигналу
    for k in np.flatnonzero(fire):
        e = int(ends[k])
        was, prev = prev, e
        if e < busy_until:        # угода відкрита — сигнал лише підтвердження
            continue
        if trades and was is not None and peaks(was + 1, e + 1) < rec["close"][e] * (1 + FAKE):
            fakes += 1
            continue
        i = min(e + 1, last)      # вхід — open наступного запису
        x, why = exits.of(i, stop)
        if why == "end":
            j = last
            sell = Decimal(str(rec["close"][last]))
        else:
            j = min(x + 1, last)
            sell = Decimal(str(rec["open"][j]))
        buy = Decimal(str(rec["open"][i]))
        r = (1 - cost) * (sell / buy) * (1 - cost) - 1
        money *= 1 + r
        trades.append({"signal": e, "open": i, "close": j, "why": why, "r": float(r)})
        busy_until = j
    return {"trades": trades, "final": money, "fakes": fakes}


def score(trades: list, legs: list) -> dict:
    """Близькість до еталона: результат кожного циклу і частка еталона."""
    cycles = [{"r": leg["r"], "got": 1.0, "n": 0} for leg in legs]
    tail = {"got": 1.0, "n": 0}
    tops = [leg["top"] for leg in legs]
    for one in trades:
        c = int(np.searchsorted(tops, one["open"], side="right"))
        box = cycles[c] if c < len(cycles) else tail
        box["got"] *= 1 + one["r"]
        box["n"] += 1
    got = [c["got"] - 1 for c in cycles]
    ideal_sum = sum(c["r"] for c in cycles)
    captured = sum(got) + (tail["got"] - 1)
    return {"share": captured / ideal_sum if ideal_sum else 0.0,
            "gap": ideal_sum - captured,
            "cycles": [{"r": c["r"], "got": g, "n": c["n"]} for c, g in zip(cycles, got)],
            "tail": {"got": tail["got"] - 1, "n": tail["n"]}}


def peaks_of(close: np.ndarray):
    """Найбільший close на відрізку записів — розріджена таблиця."""
    table = [close]
    n = len(close)
    j = 1
    while 2 * j <= n:
        prev = table[-1]
        table.append(np.maximum(prev[:-j], prev[j:]))
        j *= 2

    def peak(a: int, b: int) -> float:
        if b <= a:
            return -np.inf
        level = (b - a).bit_length() - 1
        return float(max(table[level][a], table[level][b - (1 << level)]))
    return peak


def better(a: dict, b: dict | None) -> bool:
    if b is None:
        return True
    return (a["share"], a["pnl"], -a["trades"]) > (b["share"], b["pnl"], -b["trades"])


def evaluate(run: str, epoch: int, window: int, quantile: float, stop: float, trail: bool = True) -> dict:
    """Одна комбінація — рядок тієї самої форми, що в гріді."""
    rec = market()
    with np.load(RESULTS / f"{run}_val.npz") as store:
        epochs, prob, stamps = store["epochs"], store["prob"], store["t"]
    n = int(np.flatnonzero(epochs == epoch)[0])
    s = rolling_sum(np.nan_to_num(prob[n].astype(float)), window)
    theta = float(np.quantile(s, quantile))
    fire = s >= theta
    ends = np.searchsorted(rec["t"] + BAR, stamps)
    got = simulate(rec, ends, fire, stop, Exits(rec["open"], rec["close"], trail), peaks_of(rec["close"]))
    sc = score(got["trades"], ideal(rec, int(stamps[0]), int(stamps[-1])))
    return {"run": run, "epoch": int(epoch), "window": window, "quantile": quantile, "theta": theta,
            "stop": stop, "share": sc["share"], "gap": sc["gap"], "pnl": float(got["final"] - START),
            "final": float(got["final"]), "trades": len(got["trades"]), "fakes": got["fakes"],
            "signals": int(fire.sum()), "take": sum(t["why"] == "take" for t in got["trades"]),
            "stops": sum(t["why"] == "stop" for t in got["trades"])}


def one_run(path: str) -> dict:
    """Грід на всіх епохах одного прогону."""
    rec = market()
    with np.load(path) as store:
        epochs, prob, stamps = store["epochs"], store["prob"], store["t"]
    ends = np.searchsorted(rec["t"] + BAR, stamps)
    legs = ideal(rec, int(stamps[0]), int(stamps[-1]))
    exits = Exits(rec["open"], rec["close"])
    peak = peaks_of(rec["close"])
    run = Path(path).name.replace("_val.npz", "")
    out = []
    for n, epoch in enumerate(epochs):
        p = np.nan_to_num(prob[n].astype(float))
        best = None
        for w in WINDOWS:
            s = rolling_sum(p, w)
            for q in QUANTILES:
                theta = float(np.quantile(s, q))
                fire = s >= theta
                for stop in STOPS:
                    got = simulate(rec, ends, fire, stop, exits, peak)
                    sc = score(got["trades"], legs)
                    row = {"run": run, "epoch": int(epoch), "window": w, "quantile": q,
                           "theta": theta, "stop": stop, "share": sc["share"], "gap": sc["gap"],
                           "pnl": float(got["final"] - START), "final": float(got["final"]),
                           "trades": len(got["trades"]), "fakes": got["fakes"],
                           "signals": int(fire.sum()),
                           "take": sum(t["why"] == "take" for t in got["trades"]),
                           "stops": sum(t["why"] == "stop" for t in got["trades"])}
                    if better(row, best):
                        best = row
        out.append(best)
    return {"run": run, "epochs": out}


def detail(best: dict, rec: dict, trail: bool = True) -> dict:
    """Угоди і цикли ★ — для файлу й вкладки."""
    with np.load(RESULTS / f"{best['run']}_val.npz") as store:
        epochs, prob, stamps = store["epochs"], store["prob"], store["t"]
    n = int(np.flatnonzero(epochs == best["epoch"])[0])
    p = np.nan_to_num(prob[n].astype(float))
    s = rolling_sum(p, best["window"])
    ends = np.searchsorted(rec["t"] + BAR, stamps)
    legs = ideal(rec, int(stamps[0]), int(stamps[-1]))
    exits = Exits(rec["open"], rec["close"], trail)
    got = simulate(rec, ends, s >= best["theta"], best["stop"], exits, peaks_of(rec["close"]))
    sc = score(got["trades"], legs)
    t = rec["t"]

    def take_path(x: dict) -> list:
        """Рівень тейку в часі: [час, рівень] на кожній зміні найнижчої ціни."""
        low = exits.lows(x["open"], x["close"])
        keep = np.r_[0, np.flatnonzero(np.diff(low)) + 1]
        return [[int(t[x["open"] + k]), float(low[k] * (1 + TAKE))] for k in keep]

    trades = [{"signal_t": int(t[x["signal"]] + BAR), "open_t": int(t[x["open"]]),
               "open_price": float(rec["open"][x["open"]]), "close_t": int(t[x["close"]]),
               "close_price": float(rec["open"][x["close"]] if x["why"] != "end" else rec["close"][x["close"]]),
               "why": x["why"], "r": x["r"], "take": take_path(x)} for x in got["trades"]]
    cycles = [{**{k: leg[k] for k in ("bottom_t", "top_t", "buy", "sell", "r")}, **c}
              for leg, c in zip(legs, sc["cycles"])]
    return {"trades": trades, "cycles": cycles, "tail": sc["tail"],
            "t": stamps.astype(int).tolist(), "sum": s.tolist(),
            "close": rec["close"][ends].astype(float).tolist()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    paths = sorted(str(p) for p in RESULTS.glob("BUY_*_val.npz"))
    with ProcessPoolExecutor(args.workers) as pool:
        runs = list(pool.map(one_run, paths))
    rec = market()
    with np.load(paths[0]) as store:
        stamps = store["t"]
    legs = ideal(rec, int(stamps[0]), int(stamps[-1]))
    for one in runs:
        one["best"] = None
        for row in one["epochs"]:
            if better(row, one["best"]):
                one["best"] = row
        print(one["run"], {k: one["best"][k] for k in ("epoch", "window", "quantile", "stop", "share",
                                                         "pnl", "trades")}, flush=True)
    top = None
    for one in runs:
        if better(one["best"], top):
            top = one["best"]
    star = evaluate(**STAR)
    entry = evaluate(**STAR, trail=False)
    cost = FEE + SLIP
    hold = float(START * (1 - cost) * (Decimal(str(rec["close"][-1]))
                                       / Decimal(str(rec["open"][int(np.searchsorted(rec["t"] + BAR, stamps[0])) + 1])))
                 * (1 - cost))
    out = {"config": {"take": TAKE, "fake": FAKE, "fee": str(FEE), "slip": str(SLIP), "start": str(START),
                      "windows": WINDOWS, "quantiles": QUANTILES, "stops": STOPS, "step_minutes": 10},
           "ideal": {"legs": legs, "sum": sum(leg["r"] for leg in legs),
                     "final": float(np.prod([1 + leg["r"] for leg in legs]) * float(START))},
           "hold": hold, "runs": runs, "top": top, "star": star, "detail": detail(star, rec),
           "entry": {"star": entry, "detail": detail(entry, rec, trail=False)}}
    (RESULTS / "signal_pick.json").write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    print("найкращий у гріді", top)
    print("★", star)
    print("★ з тейком від входу", entry)


if __name__ == "__main__":
    main()
