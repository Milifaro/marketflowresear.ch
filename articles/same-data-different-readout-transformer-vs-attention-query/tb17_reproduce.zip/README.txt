Reproduction kit — Same Data, Different Readout — How a Transformer Fails Differently From an Attention Query
https://marketflowresear.ch/articles/same-data-different-readout-transformer-vs-attention-query/

research/17-zigzag23-transformer/17-zigzag23-transformer.md
    The research log (Ukrainian). Goal, data, plan, the exact scripts and command lines,
    every confirmed stage with its tables, and the conclusion. It is written so that the
    study can be rerun from scratch and give the same numbers.
research/17-zigzag23-transformer/scripts/
    Scripts of this study, as referenced from the log.
rules/
    Project rules the log relies on: data and classes (01), labeling and zigzag legs (02),
    models and storage (03), trading (04), charts (05); rules/scripts holds the base
    scripts that build every class and dataset.
scripts/
    Shared helper scripts of the project.

Not included: the raw data. Every study reads second-by-second Binance order-book snapshots
(8 features + price, 6 coins, Feb 2026 onward) laid out as
DATA/<year>/<month>/<PAIR>/1S_<YYYY-MM-DD>_<PAIR>.csv — see rules/01-data-and-db.md for the
schema. Paths inside the scripts point to the original machine; change them to your copy.
Research, not financial advice.
