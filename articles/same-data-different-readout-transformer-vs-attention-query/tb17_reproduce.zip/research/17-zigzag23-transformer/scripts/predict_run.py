"""Видача моделі на всьому датасеті: ціна, зігзаг, ціль, прогноз, зони.

Дослідження: research/17-zigzag23-transformer/

Той самий `predict.py`, що в дослідженні 16, над збереженою моделлю
цього дослідження. Метрики рахуються по вікнах прогону
(`train | val | test` підряд за часом).

Вихід: results/predict_2_3.json

Запуск:
    python3 research/17-zigzag23-transformer/scripts/predict_run.py
"""

from __future__ import annotations

import argparse
from pathlib import Path

import base

# видача йде з **кращої** моделі дослідження — тієї, що на
# підібраних ручках розділу 2 (`losses_run.py --tag picked`)
DEFAULT_RUN = "picked_model"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default=base.THRESHOLD)
    parser.add_argument("--run", default=DEFAULT_RUN)
    parser.add_argument("--out", type=Path, default=base.RESULTS)
    args = parser.parse_args()

    payload = base.predict.build(args.pair, args.target, run=args.run,
                                 out=args.out)
    base.write(payload, f"predict_{args.target.replace('.', '_')}.json",
               args.out)


if __name__ == "__main__":
    main()
