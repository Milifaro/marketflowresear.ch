"""Невідомий відрізок: дані після кінця датасету, яких не бачив ніхто.

Дослідження: research/17-zigzag23-transformer/

Той самий `fresh.py`, що в дослідженні 16: сирі CSV проходять увесь
ланцюг класів, модель і скейлер беруться збережені з навчання.

Вихід: results/fresh_2_3.json, results/fresh_<прогін>_2_3.json

Запуск:
    python3 research/17-zigzag23-transformer/scripts/fresh_run.py
    python3 research/17-zigzag23-transformer/scripts/fresh_run.py \
        --run final_fill_ема20_k10
"""

from __future__ import annotations

import argparse
from pathlib import Path

import base

# видача йде з **кращої** моделі дослідження — тієї, що на
# підібраних ручках розділу 2 (`losses_run.py --tag picked`)
DEFAULT_RUN = "picked_model"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default=base.THRESHOLD)
    parser.add_argument("--from", dest="begin", default=base.fresh.DEFAULT_FROM)
    parser.add_argument("--to", dest="end", default=base.fresh.DEFAULT_TO)
    parser.add_argument("--warmup-from", dest="warmup",
                        default=base.fresh.DEFAULT_WARMUP)
    parser.add_argument("--run", default=DEFAULT_RUN)
    parser.add_argument("--out", type=Path, default=base.RESULTS)
    args = parser.parse_args()

    payload = base.fresh.build(args.pair, args.target, args.begin, args.end,
                               args.warmup, run=args.run, out=args.out)
    tail = args.target.replace(".", "_")
    tag = "" if args.run == DEFAULT_RUN else f"_{args.run}"
    base.write(payload, f"fresh{tag}_{tail}.json", args.out)


if __name__ == "__main__":
    main()
