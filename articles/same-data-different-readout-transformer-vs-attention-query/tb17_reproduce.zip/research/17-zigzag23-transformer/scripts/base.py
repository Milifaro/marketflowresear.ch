"""Спільна основа дослідження: та сама постановка, інша родина.

Дослідження: research/17-zigzag23-transformer/

Питання дослідження — **тільки мережа**. Дані, мітка, нога, зона півота,
згладжування цілі, функція втрат, розбиття, скейлер, seed і всі метрики
беруться з дослідження 16 без правок, тому й код кроків береться звідти
ж: переписаний він дав би ті самі числа з ризиком розійтись у дрібниці.

Підміна одна: модуль `nets` — родина цього дослідження
(`transformer`, `nets.py` поруч). Скрипти дослідження 16 звертаються до
родини тільки через `import nets`, тому підміна в `sys.modules` міняє
рівно те, що треба, і нічого більше. Шляхи звітів і ваг переводяться на
папку цього дослідження (`RESEARCH_DIR`, `RESULTS`).

Ціль розділу 4 — згладжений ряд `smooth.py` дослідження 16; його файли
скопійовані в `results/` цього дослідження, щоб воно відтворювалось
цілком зі своєї папки.
"""

from __future__ import annotations

import sys
from pathlib import Path

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
SOURCE = PROJECT_ROOT / "research" / "16-zigzag23-wattn" / "scripts"
RESULTS = RESEARCH_DIR / "results"
MODELS_DIR = RESEARCH_DIR / "models"

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import nets  # noqa: E402
# скрипти дослідження 16 імпортують родину як `nets` — віддаємо їм свою
sys.modules["nets"] = nets

sys.path.insert(0, str(SOURCE))

import final_models  # noqa: E402
import fresh  # noqa: E402
import predict  # noqa: E402
import saved  # noqa: E402
import vertex  # noqa: E402
import wattn_losses  # noqa: E402
import windows  # noqa: E402

# Звіти й ваги пишуться в папку цього дослідження, а не дослідження 16.
for module in (final_models, fresh, predict, wattn_losses, windows):
    module.RESEARCH_DIR = RESEARCH_DIR
    module.RESULTS = RESULTS

THRESHOLD = "2.3"
TAIL = THRESHOLD.replace(".", "_")


def write(payload: dict, name: str, out: Path = RESULTS) -> Path:
    """Звіт кроку у `results/` цього дослідження."""
    out.mkdir(parents=True, exist_ok=True)
    path = out / name
    path.write_text(__import__("json").dumps(payload, indent=2,
                                             ensure_ascii=False,
                                             allow_nan=False),
                    encoding="utf-8")
    print(f"записано {path}")
    return path


def picked(out: Path = RESULTS) -> dict:
    """Ручки мережі під роботу: вибір розділу 2 (`grid.py`).

    `picked_2_3.json` пише крок `epochs`: конфігурація точного гріду й
    терпіння ранньої зупинки. Поки розділу 2 немає, беруться типові
    значення родини — те саме, з чим працює розділ 1.
    """
    import json

    path = out / f"picked_{TAIL}.json"
    if not path.exists():
        return {"config": dict(nets.CONFIG), "patience": nets.PATIENCE,
                "from": "типові значення родини"}
    return json.loads(path.read_text(encoding="utf-8"))
