"""Розділ 1: `transformer` під штрафом за розмах.

Дослідження: research/17-zigzag23-transformer/ (розділ 1)

Той самий прогін, що розділ 2 дослідження 16
(`wattn_losses.py`), з однією різницею — родина. Ручки стоять на типових
значеннях (`nets.CONFIG`), щоб перший рядок порівнювався з `wattn`
числом у число; підбір ручок іде далі, у розділі 2 (`grid.py`).

`--tag picked` проганяє те саме на **підібраних** ручках розділу 2:
звіт лягає окремим файлом, ваги — окремою текою, і саме ця модель іде
у видачу (`predict_run.py`, `fresh_run.py`).

    L = WMSE + λ·(σ_цілі − σ_прогнозу)²,   λ = 1,  w = 1 + α·|y|^β

Ваги моделі й скейлер її train зберігаються у
`models/transformer_2_3_spread_v1/` — ними рахується видача
(`predict_run.py`, `fresh_run.py`).

Вихід: results/losses_transformer_2_3.json

Запуск:
    python3 research/17-zigzag23-transformer/scripts/losses_run.py
"""

from __future__ import annotations

import argparse
import shutil
import tempfile
from pathlib import Path

import base
import nets

TAGS = ("base", "picked")


def aside(report: dict, tag: str, temp: Path) -> dict:
    """Ваги прогону — окремою текою, щоб прогони не затирали один одного."""
    folder = base.MODELS_DIR / f"{nets.NAME}_{base.TAIL}_spread_{tag}_v1"
    if folder.exists():
        shutil.rmtree(folder)
    folder.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(temp / "models" / Path(report["model_path"]).name),
                str(folder))
    path = str(folder.relative_to(base.PROJECT_ROOT))
    report["model_path"] = path
    report["rows"][0]["model_path"] = path
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default=base.THRESHOLD)
    parser.add_argument("--tag", default="base", choices=TAGS)
    parser.add_argument("--epochs", type=int, default=nets.EPOCHS)
    parser.add_argument("--out", type=Path, default=base.RESULTS)
    args = parser.parse_args()

    if args.tag == "picked":
        picked = base.picked(args.out)
        config, patience = picked["config"], picked["patience"]
    else:
        config, patience = dict(nets.CONFIG), nets.PATIENCE

    # ваги пишуться в тимчасову теку **всередині проєкту** (шлях у звіті
    # рахується від його кореня) і вже звідти лягають під своїм тегом
    temp = Path(tempfile.mkdtemp(dir=base.RESEARCH_DIR, prefix=".run_"))
    keep = base.wattn_losses.RESEARCH_DIR
    base.wattn_losses.RESEARCH_DIR = temp
    try:
        report = base.wattn_losses.build(args.pair, args.target,
                                         epochs=args.epochs, config=config,
                                         patience=patience)
    finally:
        base.wattn_losses.RESEARCH_DIR = keep
    report["tag"] = args.tag
    report = aside(report, args.tag, temp)
    shutil.rmtree(temp, ignore_errors=True)

    tail = args.target.replace(".", "_")
    name = (f"losses_{report['model']}_{tail}.json" if args.tag == "base"
            else f"picked_model_{tail}.json")
    base.write(report, name, args.out)


if __name__ == "__main__":
    main()
