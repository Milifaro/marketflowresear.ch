"""Розділ 2: ручки мережі — грубий грід, точний грід, тривалість навчання.

Дослідження: research/17-zigzag23-transformer/ (розділ 2)
Правила: rules/03-models.md → Типи мереж → Тестові

Розділ 1 узяв типові ручки родини. Тут вони підбираються — стандартом
дослідження 12, у три кроки:

    --step coarse   грубий грід з великим кроком: 24 конфігурації
    --step fine     точний грід в **околі** кращої з грубого
    --step epochs   тривалість навчання: терпіння ранньої зупинки

Вибір скрізь **тільки по val**: test у підборі не бере участі й
відкривається один раз — на обраній конфігурації (`losses_run.py`,
`predict_run.py`). Мірка вибору та сама, що в дослідженні 16, —
**влучання в зону півота** (`vertex.hits.recall`), за рівних — менший MAE.

Дані, ціль, розбиття, скейлер, штраф і seed — ті самі, що в розділі 1.

Вихід: results/grid_coarse_2_3.json, results/grid_fine_2_3.json,
results/epochs_2_3.json, results/picked_2_3.json

Запуск:
    python3 research/17-zigzag23-transformer/scripts/grid.py --step coarse
    python3 research/17-zigzag23-transformer/scripts/grid.py --step fine
    python3 research/17-zigzag23-transformer/scripts/grid.py --step epochs
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import base  # noqa: F401  (підміна родини і шляхи)
import nets

import split_time
import vertex
import walk_forward
from data import PICKED
from final_models import recall_of, run_config
from losses import variants
from train import SEED
from walk_forward import MIN_GAP, human, merged, pivot_index
from wattn_losses import LOSSES, to_pivot

RESULTS = base.RESULTS
GRID_EPOCHS, GRID_PATIENCE = 200, 20
HEADS = 4                       # width має ділитись на heads

# Крок 2 стандарту: грубий грід з великим кроком по всіх ручках родини.
COARSE = [{"model": nets.NAME,
           "params": {"width": width, "heads": HEADS, "layers": layers,
                      "dropout": dropout},
           "lr": lr, "alpha": nets.CONFIG["alpha"],
           "beta": nets.CONFIG["beta"]}
          for width in (16, 32, 64)
          for layers in (1, 2)
          for dropout in (0.1, 0.3)
          for lr in (3e-4, 1e-3)]

WIDTHS = (8, 16, 24, 32, 48, 64, 96, 128)
DROPOUTS = (0.0, 0.05, 0.1, 0.2, 0.3, 0.4)
RATES = (1e-4, 3e-4, 5e-4, 1e-3, 3e-3)
PATIENCES = (10, 30, 60)        # крок 3 стандарту: тривалість навчання


def around(value, ladder):
    """Три сусіди по драбині значень: менший, сам, більший."""
    index = ladder.index(value)
    return sorted({ladder[max(index - 1, 0)], value,
                   ladder[min(index + 1, len(ladder) - 1)]})


def fine_grid(best: dict) -> list[dict]:
    """Окіл кращої конфігурації: ширина × dropout × lr, шари від кращої."""
    params = best["params"]
    return [{"model": nets.NAME,
             "params": {"width": width, "heads": HEADS,
                        "layers": params["layers"], "dropout": dropout},
             "lr": lr, "alpha": best["alpha"], "beta": best["beta"]}
            for width in around(params["width"], WIDTHS)
            for dropout in around(params["dropout"], DROPOUTS)
            for lr in around(best["lr"], RATES)]


def prepare(pair: str, threshold: str, root: Path | None = None,
            scale: str = "quantile", leg: str = "minmax") -> dict:
    """Дані розділу 1: розбиття по часу, скейлер train, відстані до півотів.

    У підбір ідуть тільки `train` і `val`: test не рахується взагалі.
    """
    period = walk_forward.target_period(threshold, "ema")
    x, y, stamps, price = merged(pair, threshold, period, root, "ema", leg)
    pivots = pivot_index(price, period, threshold, "ema")
    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    parts, scaler = walk_forward.fold_parts(fold, x, y, scale)
    parts = {name: parts[name] for name in ("train", "val")}
    gaps = {name: to_pivot(part.timestamp, pivots)
            for name, part in parts.items()}
    bounds = {name: {"from_utc": human(stamps[index[0]]),
                     "to_utc": human(stamps[index[-1]])}
              for name, index in (("train", fold.train), ("val", fold.val))}
    return {"parts": parts, "gaps": gaps, "bounds": bounds, "period": period,
            "scale": scale, "leg": leg, "fold": fold, "scaler": scaler}


def head(pair: str, threshold: str, data: dict, step: str) -> dict:
    return {
        "pair": pair,
        "threshold": threshold,
        "step": step,
        "model": nets.NAME,
        "family": nets.NAME,
        "target": walk_forward.target_title(threshold, "ema", data["leg"]),
        "target_kind": "ema",
        "target_leg": data["leg"],
        "target_period": data["period"],
        "scale": data["scale"],
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "events": {name: len(part) for name, part in data["parts"].items()},
        "bounds": data["bounds"],
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW},
        "seed": SEED,
        "picked_by": "влучання в зону на val (recall), за рівних — MAE",
    }


def variant_of():
    return next(item for item in variants(nets.CONFIG["alpha"],
                                          nets.CONFIG["beta"])
                if item.id == LOSSES[0])


def sweep(configs, data, epochs: int, patience: int, log=print) -> list[dict]:
    """Прогін кожної конфігурації на одному розбитті."""
    variant = variant_of()
    rows = []
    for index, config in enumerate(configs, 1):
        report, _, marks = run_config(config, data["parts"], data["gaps"],
                                      variant, epochs, patience)
        val = marks["val"]
        rows.append({"config": config, "parameters": report["parameters"],
                     "best_epoch": report["best_epoch"],
                     "patience": patience, "epochs": epochs,
                     "seconds": report["seconds"], "metrics": marks})
        log(f"      {index}/{len(configs)} ширина {config['params']['width']}, "
            f"{config['params']['layers']} шар(и), dropout "
            f"{config['params']['dropout']}, lr {config['lr']}: val MAE "
            f"{val['mae']}, знак {val['sign_accuracy']}, Пірсон "
            f"{val['pearson']}, влучань {val['vertex']['hits']['hits']} з "
            f"{val['vertex']['hits']['inside']} ({recall_of(val)}), епоха "
            f"{report['best_epoch']}, {report['seconds']} с")
    rows.sort(key=lambda row: (-recall_of(row["metrics"]["val"]),
                               row["metrics"]["val"]["mae"]))
    return rows


def coarse(pair: str = "BTC_USDT", threshold: str = base.THRESHOLD,
           out: Path = RESULTS, log=print) -> dict:
    """Грубий грід: ширина × шари × dropout × lr, великий крок."""
    data = prepare(pair, threshold)
    log(f"[1/2] грубий грід: {len(COARSE)} конфігурацій, train "
        f"{len(data['parts']['train'])} / val {len(data['parts']['val'])}")
    rows = sweep(COARSE, data, GRID_EPOCHS, GRID_PATIENCE, log)
    best = rows[0]["config"]
    log(f"[2/2] краща: {best['params']} lr {best['lr']} — влучань "
        f"{recall_of(rows[0]['metrics']['val'])}")
    return {**head(pair, threshold, data, "грубий грід по ручках родини"),
            "loss": variant_of().name, "epochs": GRID_EPOCHS,
            "patience": GRID_PATIENCE, "configs": len(COARSE),
            "rows": rows, "top": [row["config"] for row in rows[:3]],
            "picked": best}


def fine(pair: str = "BTC_USDT", threshold: str = base.THRESHOLD,
         out: Path = RESULTS, log=print) -> dict:
    """Точний грід в околі кращої конфігурації грубого."""
    tail = threshold.replace(".", "_")
    source = json.loads((out / f"grid_coarse_{tail}.json")
                        .read_text(encoding="utf-8"))
    configs = fine_grid(source["picked"])
    data = prepare(pair, threshold)
    log(f"[1/2] точний грід в околі {source['picked']['params']} lr "
        f"{source['picked']['lr']}: {len(configs)} конфігурацій")
    rows = sweep(configs, data, GRID_EPOCHS, GRID_PATIENCE, log)
    best = rows[0]["config"]
    log(f"[2/2] краща: {best['params']} lr {best['lr']} — влучань "
        f"{recall_of(rows[0]['metrics']['val'])}")
    return {**head(pair, threshold, data, "точний грід в околі кращої"),
            "loss": variant_of().name, "epochs": GRID_EPOCHS,
            "patience": GRID_PATIENCE, "configs": len(configs),
            "around": source["picked"], "rows": rows,
            "top": [row["config"] for row in rows[:3]], "picked": best}


def epochs(pair: str = "BTC_USDT", threshold: str = base.THRESHOLD,
           out: Path = RESULTS, log=print) -> dict:
    """Тривалість навчання: скільки чекати після кращої епохи.

    Рання зупинка повертає ваги **кращої** епохи по val, тому питання тут
    одне — чи не обривається навчання зарано. Терпіння перебирається на
    обраній конфігурації, бюджет епох повний (`nets.EPOCHS`).
    """
    tail = threshold.replace(".", "_")
    config = json.loads((out / f"grid_fine_{tail}.json")
                        .read_text(encoding="utf-8"))["picked"]
    data = prepare(pair, threshold)
    variant = variant_of()
    log(f"[1/2] терпіння {PATIENCES} на {config['params']} lr {config['lr']}")

    rows = []
    for patience in PATIENCES:
        report, _, marks = run_config(config, data["parts"], data["gaps"],
                                      variant, nets.EPOCHS, patience)
        val = marks["val"]
        rows.append({"patience": patience, "epochs": nets.EPOCHS,
                     "config": config, "parameters": report["parameters"],
                     "best_epoch": report["best_epoch"],
                     "seconds": report["seconds"], "metrics": marks})
        log(f"      терпіння {patience:>2}: краща епоха "
            f"{report['best_epoch']}, val MAE {val['mae']}, влучань "
            f"{val['vertex']['hits']['hits']} з "
            f"{val['vertex']['hits']['inside']} ({recall_of(val)}), "
            f"{report['seconds']} с")
    rows.sort(key=lambda row: (-recall_of(row["metrics"]["val"]),
                               row["metrics"]["val"]["mae"]))
    best = rows[0]
    log(f"[2/2] краще терпіння {best['patience']}, епоха "
        f"{best['best_epoch']}")
    return {**head(pair, threshold, data, "тривалість навчання"),
            "loss": variant.name, "config": config,
            "patiences": list(PATIENCES), "rows": rows,
            "picked": config, "picked_patience": best["patience"],
            "picked_epoch": best["best_epoch"]}


STEPS = {"coarse": coarse, "fine": fine, "epochs": epochs}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default=base.THRESHOLD,
                        choices=tuple(PICKED))
    parser.add_argument("--step", default="coarse", choices=tuple(STEPS))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = STEPS[args.step](args.pair, args.target, out=args.out)
    tail = args.target.replace(".", "_")
    name = ("epochs" if args.step == "epochs" else f"grid_{args.step}")
    base.write(report, f"{name}_{tail}.json", args.out)
    if args.step == "epochs":
        base.write({"pair": args.pair, "threshold": args.target,
                    "model": nets.NAME, "config": report["picked"],
                    "patience": report["picked_patience"],
                    "epochs": nets.EPOCHS,
                    "best_epoch": report["picked_epoch"],
                    "from": ["grid_coarse", "grid_fine", "epochs"],
                    "picked_by": report["picked_by"]},
                   f"picked_{tail}.json", args.out)


if __name__ == "__main__":
    main()
