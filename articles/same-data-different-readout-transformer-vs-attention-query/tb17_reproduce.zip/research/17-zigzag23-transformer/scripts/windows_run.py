"""Розділ 3: пачка подій — вікно з K подій поспіх, K = 5 … 50.

Дослідження: research/17-zigzag23-transformer/ (розділ 3)

Той самий перебір, що розділ 3 дослідження 16 (`windows.py`), на тій
самій родині — увага по осі **подій**, зчитування `mean`
(`nets.WindowTransformer`). Ручки беруться підібрані розділом 2
(`picked_2_3.json`), а не типові — з однією поправкою: у вікні перший
шар бере **цілу подію** (13 × 4 = 52 числа), тому ширина піднімається до
тієї, що вміщує її повністю. Вужчий шар стиснув би подію ще до мережі, і
частина даних у неї не потрапила б.

Захист від витоку потрійний і незмінний: вікно тільки з подій підряд,
цілком в одній вибірці, проміжок між вибірками ≥ 130 подій.

Вихід: results/windows_2_3.json (сирий датасет),
results/windows_fill_2_3.json (із заповненими пропусками часу)

Запуск:
    python3 research/17-zigzag23-transformer/scripts/windows_run.py
    python3 research/17-zigzag23-transformer/scripts/windows_run.py \
        --pair BTC_USDT_fill
"""

from __future__ import annotations

import argparse
from pathlib import Path

import base
import nets


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default=base.THRESHOLD)
    parser.add_argument("--sizes",
                        default=",".join(str(k) for k in base.windows.SIZES))
    parser.add_argument("--epochs", type=int, default=nets.EPOCHS)
    parser.add_argument("--out", type=Path, default=base.RESULTS)
    args = parser.parse_args()

    picked = base.picked(args.out)
    # у вікні перший шар бере цілу подію — 52 числа, тому ширина
    # піднімається до тієї, що вміщує її повністю (`nets.window_config`)
    config = nets.window_config(picked["config"])
    sizes = tuple(int(item) for item in args.sizes.split(","))
    report = base.windows.build(args.pair, args.target, sizes=sizes,
                                epochs=args.epochs,
                                patience=picked["patience"],
                                config=config)
    tag = "_fill" if args.pair.endswith("_fill") else ""
    base.write(report, f"windows{tag}_{args.target.replace('.', '_')}.json",
               args.out)


if __name__ == "__main__":
    main()
