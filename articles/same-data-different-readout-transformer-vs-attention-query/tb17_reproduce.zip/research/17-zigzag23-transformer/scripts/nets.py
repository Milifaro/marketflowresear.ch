"""Мережа `transformer`: увага по осі ЕМА-періодів з усередненим зчитуванням.

Дослідження: research/17-zigzag23-transformer/
Правила: rules/03-models.md → Типи мереж

Родина береться **готовою** з дослідження 12 (`train.MODELS`), а не
пишеться заново: у цьому й питання дослідження — та сама постановка, що
в 16, але на трансформері.

Подія — `(13, 4)`: 13 періодів ЕМА × 4 фічі. Крок послідовності — один
період ЕМА (10 … 130), позиція кроку вчиться окремим параметром.

Відмінність від `wattn` дослідження 16 — **зчитування**:

    wattn        ваги = softmax(q · h / √width);  вихід = голова(Σ ваг · h)
    transformer  вихід = голова(mean(h))

Тобто трансформер розмазує відповідь по всіх 13 періодах рівно, а
`wattn` вирішує навченим запитом, з яких періодів її брати.

Дві форми однієї родини: `Transformer` — увага по осі періодів ЕМА
однієї події, `WindowTransformer` — та сама увага по осі **подій**, коли
на вхід іде вікно з K подій поспіль (розділ 3).

`WindowTransformer` у загальний перелік `train.MODELS` не додається: вона
йде в прогін окремим `factory`, тому переліки дослідження 12 лишаються
такими, як були.
"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch import nn

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))

from train import FEATURES, MODELS, PERIODS, flat  # noqa: E402

NAME = "transformer"

# Скільки чисел приходить у перший шар на один крок послідовності.
# `Transformer` подає крок як одну ЕМА (4 фічі), `WindowTransformer` —
# цілу подію (13 × 4 = 52 числа). Перший шар не має бути вужчим за свій
# вхід: інакше він стискає подію ще до того, як мережа щось побачила, і
# частина даних у модель не потрапляє взагалі.
STEP_INPUT = FEATURES                    # одна подія: крок — період ЕМА
WINDOW_STEP_INPUT = PERIODS * FEATURES   # вікно: крок — уся подія, 52 числа

# Одноподієва форма — та сама, що в переліку дослідження 12.
Transformer = MODELS[NAME]


class WindowTransformer(nn.Module):
    """Увага по осі **подій**: вікно з K подій поспіль, зчитування `mean`.

    Крок послідовності — ціла подія, розгорнута в 52 значення
    (13 періодів ЕМА × 4 фічі). Позиція кроку вчиться, відповідь —
    середнє по кроках, як в одноподієвому `transformer`. Ціль вікна —
    ціль його **останньої** події.

    K не ручка навчання, а параметр досліду: він перебирається зовні
    (`windows.py` дослідження 16), і кожне K — свій прогін.
    """

    def __init__(self, k: int, width=64, heads=4, layers=2, dropout=0.1,
                 outputs=1):
        super().__init__()
        if width % heads:
            raise ValueError("width має ділитись на heads")
        if width < WINDOW_STEP_INPUT:
            raise ValueError(f"width {width} вужчий за подію "
                             f"({WINDOW_STEP_INPUT} чисел): частина даних "
                             "не дійшла б до мережі")
        self.k = k
        self.outputs = outputs
        self.into = nn.Linear(PERIODS * FEATURES, width)
        self.place = nn.Parameter(torch.zeros(1, k, width))
        layer = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=width * 4,
            dropout=dropout, batch_first=True, norm_first=True)
        self.net = nn.TransformerEncoder(layer, num_layers=layers,
                                         enable_nested_tensor=False)
        self.head = nn.Linear(width, outputs)

    def forward(self, x):
        flat_x = x.reshape(x.shape[0], self.k, PERIODS * FEATURES)
        out = self.net(self.into(flat_x) + self.place)      # (N, K, width)
        return flat(self.head(out.mean(dim=1)), self.outputs)


# Родина підставляється в прогін замість пошуку в `train.MODELS`
# (`train.run(..., factory=nets.FACTORY)`) — так само, як у дослідженні 16.
FACTORY = Transformer
WINDOW_NAME = "transformer-вікно"


def window_width(width: int, heads: int = 4) -> int:
    """Найближча зверху ширина, яка вміщує подію цілком і ділиться на heads."""
    step = max(heads, 1)
    return max(int(width), -(-WINDOW_STEP_INPUT // step) * step)


def window_config(config: dict) -> dict:
    """Та сама конфігурація, але з шириною під вхід вікна.

    Ручки підбирає розділ 2 на **одній події**, де в перший шар приходить
    4 числа. У вікні той самий шар бере 52 — тому вузька ширина тут не
    просто гірша, вона втрачає дані; піднімаємо її до найближчої, яка
    вміщує подію.
    """
    params = dict(config["params"])
    params["width"] = window_width(params["width"], params.get("heads", 4))
    return {**config, "params": params}


def window_factory(k: int):
    """Фабрика вікна: K фіксується дослідом, решта ручок — як у розділі 2."""
    def make(**params):
        return WindowTransformer(k=k, **params)
    return make


# Стартові ручки розділу 1 — типові значення родини (ті самі, що в кроці
# «підбір технології» дослідження 12 і в дослідженні 16), щоб перший
# прогін порівнювався з `wattn` числом у число. Ручки під роботу
# підбирає розділ 2 (`grid.py`) і кладе їх у `PICKED`.
CONFIG = {"model": NAME,
          "params": {"width": 32, "heads": 4, "layers": 2, "dropout": 0.1},
          "lr": 1e-3, "alpha": 3.0, "beta": 2.0}
PATIENCE = 30
EPOCHS = 400

# Заповнюється розділом 2: `results/grid_fine_2_3.json` → `picked`.
PICKED_FILE = "grid_fine_2_3.json"
