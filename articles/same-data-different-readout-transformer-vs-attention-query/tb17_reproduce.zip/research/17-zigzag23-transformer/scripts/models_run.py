"""Розділ 4: моделі на згладженій цілі — грід, фінальна, викидання фіч.

Дослідження: research/17-zigzag23-transformer/ (розділ 4)

Ті самі кроки, що розділ 4 дослідження 16 (`final_models.py`): ціль
згладжена `ема20` між зонами півотів, датасет із заповненими пропусками
часу, вхід — вікно з K подій, розбиття `train | val`, а роль test грає
невідомий відрізок після кінця датасету.

Ширини гріду тут починаються з тієї, що вміщує подію цілком: у вікні в
перший шар приходить 13 × 4 = 52 числа, і вужчий шар частину з них у
мережу не пустив би.

Згладжений ряд береться зі звіту `smooth.py` дослідження 16
(`results/smooth_fill_2_3.npz`, скопійований у це дослідження): він
залежить від даних, а не від мережі, тому рахувати його вдруге немає
чого.

Вихід: results/{grid,final,ablation}_fill_ема20_k<K>_2_3.json

Запуск:
    python3 research/17-zigzag23-transformer/scripts/models_run.py \
        --pair BTC_USDT_fill --way ема20 --k 10 --step grid
"""

from __future__ import annotations

import argparse
from pathlib import Path

import base
import nets


def window_grid(widths=(64, 96, 128)) -> list[dict]:
    """Грід розділу 4 під вхід вікна: 24 конфігурації, як у дослідженні 16.

    Ширини зсунуті вгору — у вікні в перший шар приходить 52 числа на
    подію (13 ЕМА × 4 фічі), і ширина 16 чи 32 частину з них у мережу не
    пустила б. Драбина починається з першої, що вміщує подію цілком.

    `widths` звужує грід: на довгих вікнах ширина 96 і 128 коштує
    10–20 хвилин на конфігурацію, і перебір стає дорожчим за все інше
    дослідження разом.
    """
    return [{"model": nets.NAME,
             "params": {"width": width, "heads": 4, "layers": layers,
                        "dropout": dropout},
             "lr": lr, "alpha": nets.CONFIG["alpha"],
             "beta": nets.CONFIG["beta"]}
            for width in widths
            for layers in (1, 2)
            for dropout in (0.1, 0.3)
            for lr in (3e-4, 1e-3)]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT_fill")
    parser.add_argument("--target", default=base.THRESHOLD)
    parser.add_argument("--way", default="ема20")
    parser.add_argument("--step", default="grid",
                        choices=tuple(base.final_models.STEPS))
    parser.add_argument("--steps", type=int,
                        default=base.final_models.ABLATION_STEPS)
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--widths", default="64,96,128",
                        help="ширини гріду; кожна має вміщувати подію")
    parser.add_argument("--out", type=Path, default=base.RESULTS)
    args = parser.parse_args()

    extra = {"steps": args.steps} if args.step == "ablation" else {}
    if args.step == "grid" and args.k > 1:
        extra["configs"] = window_grid(tuple(
            int(item) for item in args.widths.split(",")))
    report = base.final_models.STEPS[args.step](args.pair, args.target,
                                                args.way, out=args.out,
                                                k=args.k, **extra)
    name = base.final_models.name_of(args.way, args.k, args.pair)
    base.write(report,
               f"{args.step}_{name}_{args.target.replace('.', '_')}.json",
               args.out)


if __name__ == "__main__":
    main()
