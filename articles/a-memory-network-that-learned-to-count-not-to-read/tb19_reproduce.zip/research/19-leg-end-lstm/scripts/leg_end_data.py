"""Ноги зігзага 2.3 % як послідовності подій і мітка «кінець ноги».

Дослідження: research/19-leg-end-lstm/
Правила: rules/01-data-and-db.md → клас210х14х4ц, Скейлери
         rules/02-markup.md → Порядок орієнтовної розмітки

Одиниця навчання тут — **нога**, а не подія: мережа отримує ногу подія
за подією від її початку і має сказати, де вона закінчується. Кінець
ноги і є розворот.

## Вхід

`клас210х14х4ц`, подія `(15, 4)` — 15 блоків по 14 секунд × 4 фічі,
у мережу заходить 60 чисел на крок. Скейлер — **розподіл**, тобто сирі
значення: фічі вже безрозмірні в `[-1, 1]`, рангове перетворення тільки
з'їло б сенс країв (`±1` — працює тільки одна сторона). Пропуск у фічі
(`NaN`) заходить нулем — нуль тут і є «немає перекосу».

## Дві мітки на вибір

`--mode zone` — **зона кінця ноги**, один клас: 10 % ноги по часу разом
з 10 % по ціні.

`--mode decile` — **десятина ноги**, десять класів: `1` — перші 10 %
подій ноги, `2` — 11-20 %, ... `10` — 91-100 %. Місце міряється часом
(номером події в нозі), нога ділиться на рівні десять частин.

## Мітка `zone`: 10 % ноги по часу і 10 % по ціні

    ема90(price_open) -> півоти зігзага 2.3 % -> ноги -> зона кінця ноги

Кожна нога міряється **сама собою**, а не спільним порогом:

    по часу:  останні 10 % подій ноги
    по ціні:  суцільний окіл півота, де ціна не далі за 10 % розмаху ноги
    мітка 1 = обидві множини разом (об'єднання)

- Розмах ноги — `|ціна півота − ціна попереднього півота|`, тому «10 %
  по ціні» на довгій нозі ширше, ніж на короткій, — рівно як і «10 %
  по часу».
- Окіл по ціні саме **суцільний**: ціна може вернутись на той самий
  рівень і в середині ноги, але то вже інше місце.
- Зона обрізається початком своєї ноги і самим півотом, тому нога
  читається `0 … 0 1 … 1` і завжди починається з нуля. Події після
  півота належать уже наступній нозі.

## Послідовності й памʼять

Одна нога — одна послідовність своєї власної довжини. Паддинг **правий**
і в мережу не заходить взагалі (`pack_padded_sequence`), тому памʼять
на початку ноги завжди чиста: `h0 = c0 = 0`. Нога, довша за `LENGTH`,
лишає останні `LENGTH` подій — відповідь стоїть у кінці.

## Розбиття за датою

    ноги, що закінчились до CUT  ->  train
    ноги після CUT               ->  val

Нога цілком лежить по один бік межі: у train потрапляє нога, чий півот
не пізніший за `CUT`. Валідація — свіжий відрізок часу, якого модель не
бачила.

Запуск:
    python3 research/19-leg-end-lstm/scripts/leg_end_data.py
    python3 research/19-leg-end-lstm/scripts/leg_end_data.py --mode decile
    python3 research/19-leg-end-lstm/scripts/leg_end_data.py --period 10
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from class210ema4 import ema  # noqa: E402
from zigzag import Pivot, zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

DATASET = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
PARTS = ("train", "val", "test")
CLASS = "class210x14x4c"
PAIR = "BTC_USDT_29"       # той самий BTC_USDT, зібраний до 2026-08-29
# Монети, чиї ноги йдуть **тільки в train** і тільки до межі. Беруться
# із заповненими пропусками часу: без заповнення в альткоїнів лишається
# 4-9 тисяч подій з 60 тисяч (`rules/01` → Пропуски часу).
EXTRA_PAIRS = ("ETH_USDT_fill", "SOL_USDT_fill", "XRP_USDT_fill",
               "BNB_USDT_fill", "DOGE_USDT_fill")
EVENT_SECONDS = 210

THRESHOLD = "2.3"          # зігзаг, ногами якого йде навчання
PERIOD = 90                # ема ціни, на якій стоять півоти (дослідження 16-18)
SHARE = 0.10               # 10 % ноги: і по часу, і по ціні
PARTS_OF_LEG = 10          # десятин ноги у мітці `decile`
MODES = ("zone", "decile")

# Кожна пара «мітка × період ЕМА» — свій прогін і свої файли. Тег стоїть
# у назві кожного файлу результатів, тому прогони не перетираються.
TAGS = {("zone", 90): "_2_3", ("decile", 90): "_dec_2_3",
        ("zone", 10): "_ema10_2_3", ("decile", 10): "_dec_ema10_2_3"}
# Прогін зі сходинками вчиться на ногах усіх монет, тому має свій тег.
STEPS_TAG = "_steps_ema10_2_3"


LENGTH = 3000              # стеля довжини ноги, довша лишає свій кінець
FEATURES = 60              # 15 блоків × 4 фічі
CUT = "2026-08-14 15:27"   # межа train | val, UTC


def tag_of(mode: str = "zone", period: int = PERIOD,
           extra: tuple = ()) -> str:
    """Суфікс файлів прогону: мітка × період ЕМА × чи є інші монети."""
    if extra:
        return STEPS_TAG
    return TAGS.get((mode, int(period)), f"_{mode}_ema{int(period)}_2_3")


def top_class(mode: str) -> float:
    """Клас «кінець ноги»: `1` у зоні, `10` у десятинах."""
    return 1.0 if mode == "zone" else float(PARTS_OF_LEG)


def cut_stamp(when: str = CUT) -> int:
    """Межа розбиття як timestamp UTC."""
    moment = dt.datetime.strptime(when, "%Y-%m-%d %H:%M")
    return int(moment.replace(tzinfo=dt.timezone.utc).timestamp())


def utc(stamp: int) -> str:
    return dt.datetime.fromtimestamp(int(stamp), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M")


def series(pair: str = PAIR, root: Path | None = None) -> dict:
    """Усі події класу одним рядом за часом.

    Власний поділ датасету перемішаний (`rules/01` → Підготовка), тому
    вибірки зшиваються і сортуються за `timestamp`.
    """
    folder = (root or DATASET) / pair / CLASS
    x, stamps, price = [], [], []
    for part in PARTS:
        with np.load(folder / f"{part}.npz", allow_pickle=False) as data:
            x.append(np.asarray(data["x"], dtype=np.float32))
            stamps.append(np.asarray(data["timestamp"], dtype=np.int64))
            price.append(np.asarray(data["price_open"], dtype=float))
    x = np.concatenate(x)
    stamps = np.concatenate(stamps)
    price = np.concatenate(price)
    order = np.argsort(stamps, kind="stable")
    return {"x": x[order], "t": stamps[order], "price": price[order]}


def band_run(values: np.ndarray, index: int, width: float,
             floor: int) -> tuple:
    """Суцільний окіл `index`, де ціна не далі за `width` від нього.

    `floor` — куди не заходити ліворуч (початок своєї ноги). Праворуч
    окіл не потрібен: події після півота належать наступній нозі.
    """
    price = float(values[index])
    start = index
    while start > floor and abs(values[start - 1] - price) <= width:
        start -= 1
    return start, index


def label_of(values: np.ndarray, pivots: list[Pivot],
             share: float = SHARE) -> tuple[np.ndarray, list]:
    """Мітка «кінець ноги»: 10 % ноги по часу разом з 10 % по ціні.

    Повертає ряд `0/1` на кожну подію і опис зони кожної ноги: скільки
    подій дала кожна умова окремо і скільки їх разом.
    """
    y = np.zeros(len(values), dtype=np.float32)
    zones = []
    for index, (previous, pivot) in enumerate(zip(pivots, pivots[1:])):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        length = last - first + 1
        span = abs(float(values[last]) - float(values[previous.index]))
        by_time = max(last - math.ceil(length * share) + 1, first)
        by_price, _ = band_run(values, last, span * share, first)
        start = min(by_time, by_price)
        y[start:last + 1] = 1.0
        zones.append({"leg": index, "events": int(length),
                      "by_time": int(last - by_time + 1),
                      "by_price": int(last - by_price + 1),
                      "ones": int(last - start + 1),
                      "span": round(span, 2),
                      "width": round(span * share, 2)})
    return y, zones


def decile_of(pivots: list[Pivot], count: int,
              parts: int = PARTS_OF_LEG) -> tuple[np.ndarray, list]:
    """Мітка `decile`: у якій десятині своєї ноги стоїть подія.

    `1` — перші 10 % подій ноги, `10` — останні 10 %. Місце міряється
    часом: нога ділиться на `parts` рівних частин за кількістю подій.
    Поза ногами — `0`, такої події в навчанні немає.
    """
    y = np.zeros(count, dtype=np.float32)
    zones = []
    for index, (previous, pivot) in enumerate(zip(pivots, pivots[1:])):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        length = last - first + 1
        place = np.arange(length) / length          # 0 ... майже 1
        y[first:last + 1] = np.minimum(
            np.floor(place * parts) + 1, parts).astype(np.float32)
        zones.append({"leg": index, "events": int(length),
                      "by_time": int(np.ceil(length / parts)),
                      "by_price": 0,
                      "ones": int((y[first:last + 1] == parts).sum()),
                      "span": 0.0, "width": 0.0})
    return y, zones


def legs_of(data: dict, pivots: list[Pivot], y: np.ndarray,
            length: int = LENGTH, top: float = 1.0) -> list[dict]:
    """Ноги як послідовності подій: індекси, довжина, мітка.

    Нога — відрізок від події після попереднього півота до самого півота
    включно. Довша за `length` лишає останні `length` подій: відповідь
    стоїть у кінці.
    """
    legs = []
    for index, (previous, pivot) in enumerate(zip(pivots, pivots[1:])):
        start, stop = previous.index + 1, pivot.index
        if stop <= start:
            continue
        cut = max(start, stop - length + 1)
        events = np.arange(cut, stop + 1)
        legs.append({"leg": index, "events": events,
                     "full": int(stop - start + 1),
                     "kept": int(len(events)),
                     "cut": int(cut - start),
                     "kind": pivot.kind,
                     "ones": int((y[events] == top).sum()),
                     "from": int(data["t"][events[0]]),
                     "to": int(data["t"][events[-1]])})
    return legs


def split_legs(legs: list[dict], cut: int | None = None) -> dict:
    """Розбиття за датою: нога цілком по один бік межі.

    Нога йде в `train`, якщо її півот не пізніший за межу; решта — `val`.
    """
    edge = cut_stamp() if cut is None else cut
    train = [index for index, leg in enumerate(legs) if leg["to"] <= edge]
    val = [index for index, leg in enumerate(legs) if leg["to"] > edge]
    return {"train": train, "val": val}


def tensors(sources: dict, legs: list[dict]) -> dict:
    """Ноги в один масив: паддинг **правий**, довжина кожної ноги окремо.

    `sources` — по монеті на ключ: її події, мітка і ряд. Нога знає свою
    монету (`leg["pair"]`), тому ноги різних монет лежать в одному
    масиві, але жодна не змішується з чужою.

    Паддинг у мережу не заходить — LSTM іде по `lengths`
    (`pack_padded_sequence`), увага його не бачить, штраф його не
    рахує. Тому памʼять на початку кожної ноги чиста.
    """
    count = len(legs)
    width = max((leg["kept"] for leg in legs), default=0)
    x = np.zeros((count, width, FEATURES), dtype=np.float32)
    target = np.zeros((count, width), dtype=np.float32)
    mask = np.zeros((count, width), dtype=bool)
    index = np.full((count, width), -1, dtype=np.int64)
    lengths = np.zeros(count, dtype=np.int64)
    flat = {name: np.nan_to_num(one["data"]["x"]
                                .reshape(len(one["data"]["x"]), -1), nan=0.0)
            for name, one in sources.items()}
    for row, leg in enumerate(legs):
        events = leg["events"]
        size = len(events)
        own = leg.get("pair", next(iter(sources)))
        x[row, :size] = flat[own][events]
        target[row, :size] = sources[own]["label"][events]
        mask[row, :size] = True
        index[row, :size] = events
        lengths[row] = size
    return {"x": x, "y": target, "mask": mask, "index": index,
            "lengths": lengths}


def prepare(pair: str, root: Path | None, length: int, share: float,
            mode: str, period: int) -> dict:
    """Одна монета: ряд, півоти, мітка, ноги. Без розбиття й тензорів."""
    data = series(pair, root)
    smooth = ema(data["price"], period)
    pivots = zigzag(smooth, THRESHOLDS[THRESHOLD])
    if mode == "zone":
        y, zones = label_of(smooth, pivots, share)
    else:
        y, zones = decile_of(pivots, len(smooth))
    legs = legs_of(data, pivots, y, length, top_class(mode))
    for leg in legs:
        leg["pair"] = pair
    return {"pair": pair, "data": data, "ema": smooth, "pivots": pivots,
            "label": y, "legs": legs, "zones": zones}


def build(pair: str = PAIR, root: Path | None = None, length: int = LENGTH,
          share: float = SHARE, cut: str = CUT, mode: str = "zone",
          period: int = PERIOD, extra: tuple = (), log=print) -> dict:
    """Дані дослідження: ряд, півоти, мітка, ноги, розбиття, тензори.

    `extra` — монети, чиї ноги додаються **тільки в train** і тільки ті,
    що закінчились до межі. Вікно ніколи не переходить з монети на
    монету: кожна нога цілком належить своїй.
    """
    if mode not in MODES:
        raise SystemExit(f"мітка має бути з {MODES}")
    main = prepare(pair, root, length, share, mode, period)
    data, smooth = main["data"], main["ema"]
    pivots, y, zones = main["pivots"], main["label"], main["zones"]
    legs = list(main["legs"])
    parts = split_legs(legs, cut_stamp(cut))
    sources = {pair: main}
    coins = [{"pair": pair, "legs": len(legs),
              "train": len(parts["train"]), "val": len(parts["val"])}]
    for name in extra:
        one = prepare(name, root, length, share, mode, period)
        sources[name] = one
        taken = [leg for leg in one["legs"] if leg["to"] <= cut_stamp(cut)]
        parts["train"].extend(range(len(legs), len(legs) + len(taken)))
        legs.extend(taken)
        coins.append({"pair": name, "legs": len(one["legs"]),
                      "train": len(taken), "val": 0})
    packed = tensors(sources, legs)
    kind = (f"зона {share:.0%} по часу і по ціні" if mode == "zone"
            else f"{PARTS_OF_LEG} десятин ноги")
    if extra:
        log("монети train: " + " · ".join(f"{item['pair']} {item['train']}"
                                          for item in coins))
    last = float((y == PARTS_OF_LEG).sum()) if mode == "decile" \
        else float(y.sum())
    log(f"{pair}: {len(data['x'])} подій, {len(pivots)} півотів, "
        f"{len(legs)} ніг, ема{period}, мітка — {kind}, "
        f"подій у крайньому класі {int(last)} "
        f"({last / max(len(y), 1) * 100:.2f} %)")
    log("  ноги: " + " · ".join(f"{name} {len(items)}"
                                for name, items in parts.items())
        + f" · межа {cut} UTC")
    return {"pair": pair, "class": "клас210х14х4ц", "scaler": "розподіл",
            "threshold": THRESHOLD, "period": period, "share": share,
            "mode": mode, "classes": PARTS_OF_LEG if mode == "decile" else 1,
            "tag": tag_of(mode, period, extra), "coins": coins,
            "extra": list(extra), "sources": sources,
            "length": length, "features": FEATURES, "cut": cut,
            "event_seconds": EVENT_SECONDS,
            "data": data, "ema": smooth, "pivots": pivots, "label": y,
            "legs": legs, "parts": parts, "zones": zones, **packed}


def report_of(built: dict) -> dict:
    """Розмітка числами — те, що йде у звіт і на вкладку."""
    legs, parts, zones = built["legs"], built["parts"], built["zones"]
    lengths = np.array([leg["kept"] for leg in legs])
    by_time = np.array([zone["by_time"] for zone in zones])
    by_price = np.array([zone["by_price"] for zone in zones])
    ones = np.array([zone["ones"] for zone in zones])
    return {
        "pair": built["pair"], "class": built["class"],
        "scaler": built["scaler"],
        "target": f"зігзаг {built['threshold']} % на ема{built['period']}",
        "mode": built["mode"], "classes": built["classes"],
        "period": built["period"], "tag": built["tag"],
        "coins": built["coins"], "extra": built["extra"],
        "share": built["share"], "cut": built["cut"],
        "length": built["length"], "features": built["features"],
        "event_seconds": EVENT_SECONDS,
        "events": int(len(built["label"])),
        "from_utc": utc(built["data"]["t"][0]),
        "to_utc": utc(built["data"]["t"][-1]),
        "pivots": len(built["pivots"]),
        "legs": len(legs),
        "ones": int((built["label"] == top_class(built["mode"])).sum()),
        "ones_share": round(float(
            (built["label"] == top_class(built["mode"])).mean()), 5),
        "leg_events": {"median": int(np.median(lengths)),
                       "mean": int(lengths.mean()),
                       "min": int(lengths.min()),
                       "max": int(lengths.max())},
        "capped": int(sum(1 for leg in legs if leg["cut"] > 0)),
        "zone": {"by_time_median": int(np.median(by_time)),
                 "by_price_median": int(np.median(by_price)),
                 "ones_median": int(np.median(ones)),
                 "price_wider": int((by_price > by_time).sum()),
                 "legs": len(zones)},
        "zones": zones,
        "parts": {name: {"legs": len(items),
                         "events": int(sum(legs[i]["kept"] for i in items)),
                         "ones": int(sum(legs[i]["ones"] for i in items)),
                         "from_utc": utc(legs[items[0]]["from"]),
                         "to_utc": utc(legs[items[-1]]["to"])}
                  for name, items in parts.items() if items},
        "rows": [{"leg": leg["leg"], "kind": leg["kind"],
                  "pair": leg.get("pair", built["pair"]),
                  "events": leg["kept"], "full": leg["full"],
                  "ones": leg["ones"], "from_utc": utc(leg["from"]),
                  "to_utc": utc(leg["to"]),
                  "part": next((name for name, items in parts.items()
                                if leg["leg"] in items), "—")}
                 for leg in legs],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--share", type=float, default=SHARE)
    parser.add_argument("--cut", default=CUT)
    parser.add_argument("--mode", default="zone", choices=MODES,
                        help="zone — зона кінця ноги; decile — десятини")
    parser.add_argument("--period", type=int, default=PERIOD,
                        help="період ЕМА ціни, на якій стоїть зігзаг")
    parser.add_argument("--extra", nargs="*", default=[],
                        help="монети, чиї ноги йдуть тільки в train; "
                             f"`всі` — {', '.join(EXTRA_PAIRS)}")
    parser.add_argument("--length", type=int, default=LENGTH)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    extra = tuple(EXTRA_PAIRS if args.extra == ["всі"] else args.extra)
    built = build(args.pair, length=args.length, share=args.share,
                  cut=args.cut, mode=args.mode, period=args.period,
                  extra=extra)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"legs{tag_of(args.mode, args.period, extra)}.json"
    path.write_text(json.dumps(report_of(built), ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
