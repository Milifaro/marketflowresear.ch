"""Розділ 11: мережа сама знаходить півот і сама обнуляє памʼять.

Дослідження: research/19-leg-end-lstm/
Правила: rules/03-models.md → Правила навчання

У розділі 10 памʼять обнуляв **зігзаг**: ряд різався на ноги по півотах,
і кожна нога заходила в мережу з чистим станом. Півот зігзага
підтверджується заднім числом, тому «чистий старт рівно на першій події
ноги» — це знання, якого наживо немає.

Тут його немає і в моделі. Мережа йде рядом монети **підряд**, від
першої події вікна до останньої, і сама вирішує, де кінець ноги:

    крок t -> LSTM(стан) -> причинна увага на памʼять від обнулення
           -> сказаний клас десятини 1 ... 10
    сказала 10  ->  тут півот  ->  h, c = 0, памʼять порожня
                    наступна подія починає нову ногу з класу 1

Мітка не міняється: перші 10 % подій ноги — клас 1, 10-20 % — клас 2,
і так далі; останні 10 % — клас 10. Окіл кожного класу — його власна
десятина.

Зігзаг лишається **тільки правдою для оцінки**: у вхід моделі він не
заходить взагалі. Порівнюється, де мережа обнулилась і де насправді
стоїть півот.

## Де рахується

Хід іде по одній події, тому прискорювач тільки заважає: кожен крок —
окремий запуск ядра. Прогін стоїть на CPU, ваги ті самі.

## Запобіжник

Якщо мережа не скаже 10 ніколи, памʼять не обнулиться сама. Тому стоїть
стеля `LENGTH` подій: обнулення примусове і рахується окремо від своїх.

## Крок у крок дорівнює прогону цілим відрізком

Ходок веде LSTM по одній події і тримає буфер виходів від останнього
обнулення; увага дивиться рівно на цей буфер. Це та сама причинна
увага, що і в `LegEnd.forward` на цілому відрізку, тому обидва шляхи
дають однакові числа (`tests/test_leg23.py`).

Запуск:

    python3 research/19-leg-end-lstm/scripts/leg_end_walk.py
    python3 research/19-leg-end-lstm/scripts/leg_end_walk.py \
        --from "2026-08-20 00:00" --pairs BTC_USDT_now
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module        # noqa: E402
import leg_end_fresh as fresh_module      # noqa: E402
import leg_end_train as train_module      # noqa: E402
import leg_end_net as net_module          # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "walk_steps_ema10_2_3.json"

FROM = fresh_module.FROM
TO = fresh_module.TO
WALK_PAIRS = fresh_module.FRESH_PAIRS
MODE = fresh_module.MODE
TAG = fresh_module.TAG


# ---------- крок мережі ----------

def look_back_step(model, now: torch.Tensor,
                   memory: torch.Tensor) -> torch.Tensor:
    """Увага одного кроку на памʼять від обнулення: запит — сам крок."""
    size = model.hidden // model.heads
    q = model.query(now).view(1, 1, model.heads, size).transpose(1, 2)
    k = model.key(memory).view(1, -1, model.heads, size).transpose(1, 2)
    v = model.value(memory).view(1, -1, model.heads, size).transpose(1, 2)
    out = torch.nn.functional.scaled_dot_product_attention(q, k, v)
    return model.mix(out.transpose(1, 2).reshape(1, 1, model.hidden))


@torch.no_grad()
def walk(model, x: np.ndarray, classes: int, smooth: int, cap: int,
         start: int = 0) -> dict:
    """Один прохід рядом: видача на кожній події і власні обнулення.

    `start` — звідки починати хід. Ліворуч від нього видачі немає:
    памʼять моделі порожня на першій пройденій події, тому перед вікном
    береться розгін завдовжки `cap` подій — далі стан однаково
    обнулиться стелею.

    Повертає ряди по подіях (`p`, `cls`, `place` — номер події від
    останнього обнулення) і список обнулень: індекс події і чому.
    """
    device = next(model.parameters()).device
    was_training = model.training
    model.eval()
    steps = torch.tensor(np.nan_to_num(x.reshape(len(x), -1), nan=0.0),
                         dtype=torch.float32, device=device)
    levels = torch.arange(1, classes + 1, device=device, dtype=torch.float32)
    alpha = 2.0 / (smooth + 1.0) if smooth > 1 else 1.0

    zero = lambda: torch.zeros(1, 1, model.hidden, device=device)  # noqa: E731
    state = (zero(), zero())
    memory = torch.zeros(1, cap, model.hidden, device=device)
    held = 0                       # скільки подій у памʼяті від обнулення
    run_p = run_cls = None
    prob = np.zeros(len(x), dtype=np.float32)
    said = np.zeros(len(x), dtype=np.float32)
    place = np.zeros(len(x), dtype=np.int64)
    resets = []

    for index in range(start, len(x)):
        out, state = model.lstm(steps[index].view(1, 1, -1), state)
        now = model.norm(out)
        memory[0, held] = now[0, 0]
        held += 1
        if model.attention:
            feature = torch.cat(
                [now, look_back_step(model, now, memory[:, :held])], dim=-1)
        else:
            feature = now
        logit = model.head(model.drop(feature))[0, 0]
        spread = torch.softmax(logit, dim=-1)
        step_p = float(spread[-1])
        step_cls = float((spread * levels).sum())

        run_p = step_p if run_p is None else alpha * step_p + (1 - alpha) * run_p
        run_cls = step_cls if run_cls is None \
            else alpha * step_cls + (1 - alpha) * run_cls
        prob[index] = run_p
        said[index] = min(max(round(run_cls), 1), classes)
        place[index] = held

        forced = held >= cap
        if said[index] == classes or forced:
            resets.append({"at": index, "after": held,
                           "kind": "стеля" if forced and said[index] != classes
                                   else "клас 10"})
            state = (zero(), zero())
            held = 0
            run_p = run_cls = None

    if was_training:
        model.train()
    return {"p": prob, "cls": said, "place": place, "resets": resets,
            "start": start}


# ---------- оцінка проти зігзага ----------

def true_legs(one: dict, first: int, last: int) -> list[dict]:
    """Ноги зігзага цілком у вікні: межі за індексами ряду і зона кінця."""
    stamps = one["data"]["t"]
    out = []
    for index, (previous, pivot) in enumerate(zip(one["pivots"],
                                                  one["pivots"][1:])):
        start, stop = previous.index + 1, pivot.index
        if stop <= start:
            continue
        if stamps[stop] < first or stamps[start] > last:
            continue
        events = stop - start + 1
        zone = stop - int(np.ceil(events / 10)) + 1   # остання десятина
        out.append({"leg": index, "from": int(start), "to": int(stop),
                    "events": int(events), "zone": int(max(zone, start)),
                    "kind": pivot.kind, "seen": None,
                    "stamps": (int(stamps[start]), int(stamps[stop])),
                    "from_utc": legs_module.utc(int(stamps[start])),
                    "to_utc": legs_module.utc(int(stamps[stop]))})
    return out


def mark_seen(legs: list[dict], coin: str, seen: dict) -> None:
    """Ноги train і val розділу 9 — та сама пара «початок, кінець», що там.

    Вікно починається лівіше за межу train, тому в нього потрапляють
    ноги, на яких модель вчилась. У метрики ходу вони не йдуть — інакше
    це витік навчальних даних у результат.
    """
    for leg in legs:
        key = leg["stamps"]
        if key in seen.get("train", {}).get(coin, ()):
            leg["seen"] = "train"
        elif key in seen.get("val", {}).get(coin, ()):
            leg["seen"] = "val"


def match_resets(legs: list[dict], resets: list[dict],
                 span: tuple[int, int]) -> dict:
    """Кожне обнулення — до найближчого півота; кожна нога — своє обнулення.

    Обнулення «в зоні», якщо воно стоїть в останній десятині своєї ноги.
    Відстань міряється до півота в подіях: `+` — після півота.
    """
    inside = [item for item in resets
              if span[0] <= item["at"] <= span[1]]
    rows = []
    for leg in [leg for leg in legs if leg["seen"] is None]:
        own = [item for item in inside
               if leg["from"] <= item["at"] <= leg["to"]]
        first = own[0] if own else None
        rows.append({"leg": leg["leg"], "events": leg["events"],
                     "resets": len(own),
                     "at": first["at"] if first else None,
                     "in_zone": bool(first and first["at"] >= leg["zone"]),
                     "distance": (first["at"] - leg["to"]) if first else None,
                     "from_utc": leg["from_utc"], "to_utc": leg["to_utc"]})
    hit = [row for row in rows if row["in_zone"]]
    silent = [row for row in rows if row["resets"] == 0]
    distances = [abs(row["distance"]) for row in rows
                 if row["distance"] is not None]
    return {
        "legs": len(rows), "seen": sum(1 for leg in legs if leg["seen"]),
        "resets": len(inside),
        "own": sum(1 for item in inside if item["kind"] == "клас 10"),
        "forced": sum(1 for item in inside if item["kind"] == "стеля"),
        "in_zone": len(hit),
        "zone_share": train_module.number(len(hit) / len(rows)) if rows else None,
        "silent": len(silent),
        "per_leg": train_module.number(len(inside) / len(rows)) if rows else None,
        "distance_median": train_module.number(
            float(np.median(distances))) if distances else None,
        "rows": rows,
    }


def walk_pair(model, pair: str, report: dict, first: int, last: int,
              cap: int, seen: dict, log=print) -> dict:
    """Одна монета: прохід рядом, обнулення мережі проти півотів зігзага."""
    classes = report["classes"]
    smooth = report["config"]["smooth"]
    one = legs_module.prepare(pair, None, report["length"], report["share"],
                              MODE, report["period"])
    stamps = one["data"]["t"]
    span = np.flatnonzero((stamps >= first) & (stamps <= last))
    if not len(span):
        return {"pair": pair, "coin": fresh_module.coin_of(pair), "events": 0}

    # Розгін перед вікном: памʼять стартує порожньою, і без розгону
    # перші події вікна читались би з чистого стану — це вже не хід.
    lead = max(int(span[0]) - cap, 0)
    out = walk(model, one["data"]["x"], classes, smooth, cap, lead)
    legs = true_legs(one, first, last)
    mark_seen(legs, fresh_module.coin_of(pair), seen)
    scored = match_resets(legs, out["resets"], (int(span[0]), int(span[-1])))

    window = slice(int(span[0]), int(span[-1]) + 1)
    said = out["cls"][window][None, :]
    mask = np.ones_like(said, dtype=bool)
    truth = one["label"][window][None, :]
    # Події ніг, які модель уже бачила, з метрик виключені — як у розділі 10.
    fresh = np.zeros(len(one["label"]), dtype=bool)
    for leg in legs:
        if leg["seen"] is None:
            fresh[leg["from"]:leg["to"] + 1] = True
    known = (truth > 0) & fresh[window][None, :]
    scores = train_module.class_scores(truth, said, known, classes)
    steps = train_module.step_scores(said, mask, classes)

    log(f"  {fresh_module.coin_of(pair)}: {len(span)} подій вікна · "
        f"свіжих ніг {scored['legs']} (бачених {scored['seen']}) · "
        f"обнулень {scored['resets']} "
        f"(своїх {scored['own']}, стеля {scored['forced']}) · "
        f"у зоні {scored['in_zone']} · без обнулення {scored['silent']} · "
        f"влучність класу {scores['accuracy']} · відстань {scores['distance']}")
    return {
        "pair": pair, "coin": fresh_module.coin_of(pair),
        "events": int(len(span)), "labelled": int(known.sum()),
        "classes": scores, "steps": steps, "resets": scored,
        "series": {
            "events": int(len(span)),
            "from_utc": legs_module.utc(int(stamps[span[0]])),
            "to_utc": legs_module.utc(int(stamps[span[-1]])),
            "t": stamps[window].astype(int).tolist(),
            "price": [round(float(value), 4)
                      for value in one["data"]["price"][window]],
            "ema": [round(float(value), 4) for value in one["ema"][window]],
            "cls": [float(value) for value in out["cls"][window]],
            "p": [round(float(value), 6) for value in out["p"][window]],
            "since": out["place"][window].astype(int).tolist(),
            "resets": [item["at"] - int(span[0]) for item in out["resets"]
                       if span[0] <= item["at"] <= span[-1]],
            "pivots": [{"t": int(stamps[leg["to"]]),
                        "price": round(float(one["data"]["price"][leg["to"]]), 4),
                        "ema": round(float(one["ema"][leg["to"]]), 4),
                        "kind": leg["kind"]} for leg in legs],
            "seen": ({"to_utc": legs_module.utc(
                max(leg["stamps"][1] for leg in legs if leg["seen"])),
                "legs": sum(1 for leg in legs if leg["seen"])}
                if any(leg["seen"] for leg in legs) else None),
        },
    }


def totals_of(coins: list) -> dict:
    """Разом по монетах: обнулення, зона, влучність класу, сходинки."""
    live = [coin for coin in coins if coin.get("events")]
    legs = sum(coin["resets"]["legs"] for coin in live)
    resets = sum(coin["resets"]["resets"] for coin in live)
    in_zone = sum(coin["resets"]["in_zone"] for coin in live)
    silent = sum(coin["resets"]["silent"] for coin in live)
    events = sum(coin["events"] for coin in live)
    weight = sum(coin["labelled"] for coin in live)
    accuracy = sum(coin["classes"]["accuracy"] * coin["labelled"]
                   for coin in live) / weight if weight else None
    distance = sum(coin["classes"]["distance"] * coin["labelled"]
                   for coin in live) / weight if weight else None
    steps = {key: sum(coin["steps"][key] or 0 for coin in live)
             for key in ("up", "jump", "down", "legs_with_down")}
    total = steps["up"] + steps["jump"] + steps["down"]
    steps["clean"] = train_module.number(steps["up"] / total) if total else None
    return {
        "coins": len(live), "events": events, "legs": legs,
        "resets": resets,
        "own": sum(coin["resets"]["own"] for coin in live),
        "forced": sum(coin["resets"]["forced"] for coin in live),
        "in_zone": in_zone, "silent": silent,
        "zone_share": train_module.number(in_zone / legs) if legs else None,
        "per_leg": train_module.number(resets / legs) if legs else None,
        "accuracy": train_module.number(accuracy) if accuracy else None,
        "distance": train_module.number(distance) if distance else None,
        "steps": steps,
        "se": train_module.number(0.5 / np.sqrt(legs)) if legs else None,
    }


def build_report(pairs=WALK_PAIRS, when=(FROM, TO), weights: Path | None = None,
                 log=print) -> dict:
    """Прохід усіма монетами готовою моделлю.

    `weights` — які ваги брати. Типово це модель розділу 9 дослідження
    19; будь-який інший `model.pt` тієї самої мережі теж підходить —
    так перевіряються моделі дослідження 20.
    """
    report = json.loads((RESULTS / f"train{TAG}.json").read_text("utf-8"))
    config = report["config"]
    # Хід — по одній події, а не батчем: на прискорювачі кожен крок
    # коштує запуску ядра і виходить у 25 разів довше за CPU. Ваги ті
    # самі, мережа маленька.
    device = "cpu"
    model = net_module.LegEnd(features=report["features"],
                              hidden=config["hidden"],
                              heads=max(config["heads"], 1),
                              attention=config["attention"],
                              outputs=report["classes"]).to(device)
    weights = weights or fresh_module.MODELS / f"leg_end{TAG}" / "model.pt"
    model.load_state_dict(torch.load(weights, map_location=device))
    model.eval()
    log(f"модель {report['label']} · {report['net']['params']} ваг · "
        f"епоха {report['best_epoch']}")
    first, last = fresh_module.stamp_of(when[0]), fresh_module.stamp_of(when[1])
    log(f"вікно {when[0]} … {when[1]} UTC · {len(pairs)} монет · "
        f"стеля памʼяті {report['length']} подій")
    training = fresh_module.training_table(report["cut"], lambda *_: None)
    seen = training.pop("seen")
    coins = [walk_pair(model, pair, report, first, last, report["length"],
                       seen, log)
             for pair in pairs]
    return {
        "from_utc": when[0], "to_utc": when[1],
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "pairs": list(pairs), "weights": str(weights),
        "training": training,
        "model": {"label": report["label"], "tag": TAG,
                  "path": report["model_path"],
                  "params": report["net"]["params"],
                  "best_epoch": report["best_epoch"],
                  "config": config, "target": report["target"],
                  "class": report["class"], "scaler": report["scaler"],
                  "period": report["period"], "classes": report["classes"],
                  "event_seconds": report["event_seconds"],
                  "features": report["features"], "device": device,
                  "cap": report["length"]},
        "totals": totals_of(coins),
        "coins": coins,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--from", dest="start", default=FROM)
    parser.add_argument("--to", dest="stop", default=TO)
    parser.add_argument("--pairs", nargs="+", default=list(WALK_PAIRS))
    parser.add_argument("--weights", type=Path, default=None,
                        help="ваги іншої моделі тієї самої мережі")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()

    report = build_report(tuple(args.pairs), (args.start, args.stop),
                          args.weights)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
