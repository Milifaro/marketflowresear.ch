"""Навчання мережі з памʼяттю на ноги зігзага 2.3 % і грід її ручок.

Дослідження: research/19-leg-end-lstm/
Правила: rules/03-models.md → Правила навчання, Метрики, Типи мереж

Одна нога — один приклад. Мережа ([`leg_end_net.py`](leg_end_net.py))
йде ногою подія за подією і на кожному кроці каже, де вона в нозі.
Мітка й нарізка ніг — [`leg_end_data.py`](leg_end_data.py).

## Сходинки: штраф за стрибок і за пониження

Мітка `decile` іде **сходинками**: клас росте від 1 до 10 і ніколи не
падає. Того самого вимагаємо від видачі — вона має ходити по `+1`:

    E_t = Σ_i p_i · i                очікуваний клас, диференційований
    Δ_t = E_t − E_{t−1}

    стрибок  = max(Δ − 1, 0)         сказала +2, +3, +4 — великий штраф
    пониження = max(−Δ, 0)           сказала «вниз» — штраф ще більший

    L = CE + JUMP·сер(стрибок²) + DOWN·сер(пониження²),  DOWN > JUMP

Обидва штрафи рахуються тільки по сусідніх кроках усередині ноги;
паддинг у них не входить. Видача додатково згладжується причинною ЕМА
(`--smooth`), тому одна смикана подія не робить сходинку.

## Дві мітки, два штрафи

| Мітка | Вихід | Штраф |
| ----- | ----- | ----- |
| `zone` — зона кінця ноги | один логіт | зважена BCE, `pos_weight` з train |
| `decile` — десятина ноги | 10 логітів | перехресна ентропія по 10 класах |

    zone:    L = Σ_маска w·BCE(логіт, мітка) / Σ_маска,  w = pos_weight
    decile:  L = Σ_маска CE(логіти, клас) / Σ_маска

`pos_weight` — відношення нулів до одиниць у train; рахується **тільки
на train**, як усе, що агрегує датасет. Десятини рівні за побудовою,
тому ваг класів там немає.

## Грід

Перебираються ручки, які міняють саму мережу: ширина, швидкість
навчання і наявність уваги взагалі. Кожен прогін іде під однаковим
бюджетом і однаковим seed, тому порівнюються рівно ці ручки. Краща
модель обирається **на val**: спершу скільки ніг вона вгадала, потім F1
по подіях.

## Що міряється

Метрики — на train і val. Одиниця — **нога**, не подія
(`rules/03` → Розмір вибірки в незалежних одиницях):

    сигнал        перший крок ноги, де p(кінець) >= поріг
    влучив        сигнал стоїть усередині зони кінця
    пік у зоні    найбільша ймовірність ноги припала на зону (без порога)
    мовчала       нога, на якій сигналу не було зовсім

«Кінець» для `zone` — це мітка `1`, для `decile` — клас `10`
(остання десятина ноги), тому таблиці обох міток читаються поруч. Для
`decile` додатково рахується влучність по всіх десяти класах і середня
відстань у класах.

Поріг береться той, що дає найкращу F1 **на train**, і застосовується
до val як є. Поруч стоїть базовий прогноз: «кінець, щойно нога
перевищила медіанну довжину train».

Запуск:
    python3 research/19-leg-end-lstm/scripts/leg_end_train.py
    python3 research/19-leg-end-lstm/scripts/leg_end_train.py --mode decile
    python3 research/19-leg-end-lstm/scripts/leg_end_train.py --period 10
    python3 research/19-leg-end-lstm/scripts/leg_end_train.py --one
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_end_data as legs_module  # noqa: E402
import leg_end_net as net_module  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

SEED = 0                     # rules/03-models.md → Правила навчання
EPOCHS = 20                  # стеля епох; рання зупинка по val
PATIENCE = 8                 # епох без покращення val
BATCH = 8                    # ніг у батчі; батч збирається з близьких довжин
LR = 1e-3
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)   # сітка порогу

# Сходинки: ціна стрибка через клас і ціна руху вниз. Вниз дорожче —
# правильний клас, раз названий, понижуватись не має.
JUMP = 5.0
DOWN = 25.0
SMOOTH = 10                  # причинна ЕМА видачі, подій
MEMORY_NEED = 2400.0         # МБ вільної памʼяті, без яких не починаємо

# Грід ручок. Вісім прогонів: ширина × швидкість × увага. Голови не
# перебираються — на кількох десятках ніг train різницю між 2 і 4
# головами не видно, а кожен прогін коштує хвилини.
GRID = {"hidden": (32, 64), "heads": (2,), "lr": (1e-3, 3e-4)}


def device_name() -> str:
    """Відеопамʼять, якщо є; інакше процесор (rules/03 → Правила навчання)."""
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def number(value, digits: int = 4):
    """Число для JSON: NaN і нескінченність стають `null`."""
    if value is None:
        return None
    value = float(value)
    return round(value, digits) if np.isfinite(value) else None


def configs(grid: dict = GRID) -> list[dict]:
    """Перелік прогонів гріда: спершу з увагою, ширші йдуть першими.

    Порядок має значення: `--configs N` бере перші `N`, і коли бюджету
    на весь грід немає (сотні ніг у train), першими мають іти найсильніші
    ручки, а не найдешевші.
    """
    out = []
    for hidden, heads, lr in itertools.product(sorted(grid["hidden"],
                                                      reverse=True),
                                               grid["heads"], grid["lr"]):
        out.append({"hidden": hidden, "heads": heads, "lr": lr,
                    "attention": True})
    for hidden, lr in itertools.product(sorted(grid["hidden"], reverse=True),
                                        grid["lr"]):
        out.append({"hidden": hidden, "heads": 0, "lr": lr,
                    "attention": False})
    return out


# ---------- батчі ----------

def batches(lengths: np.ndarray, rows: list, size: int,
            generator: np.random.Generator, budget: int = 0) -> list:
    """Батчі з ніг близької довжини: паддингу в батчі майже немає.

    Порядок самих батчів перемішується щоепохи, а склад — ні: він і є
    те, що робить батч дешевим.

    `budget` — стеля подій у батчі. Причинна увага квадратична по
    довжині ноги: батч із восьми ніг по 3000 подій дає матрицю
    `8 × голови × 3000 × 3000` — 549 МБ на один крок, і машина йде в
    підкачку (`rules/03-models.md` → Навчання без свопа). З бюджетом
    довгі ноги йдуть по одній, короткі — як раніше вісімками:

        ніг у батчі = min(size, max(1, budget // довжина найдовшої))

    `0` лишає старий поділ рівно по `size` — саме під ним навчений
    розділ 9 дослідження 19.
    """
    order = sorted(rows, key=lambda index: int(lengths[index]))
    chunks, start = [], 0
    while start < len(order):
        if budget:
            width = int(lengths[order[start]])
            count = min(size, max(1, budget // max(width, 1)))
            # ширина батча — це його найдовша нога, тому беремо стільки,
            # скільки вміщується вже з урахуванням її довжини
            while count > 1:
                width = int(lengths[order[min(start + count - 1,
                                              len(order) - 1)]])
                if count * width <= budget:
                    break
                count = min(count - 1, max(1, budget // max(width, 1)))
        else:
            count = size
        chunks.append(order[start:start + count])
        start += count
    return [chunks[index] for index in generator.permutation(len(chunks))]


def trim(x, y, mask, lengths, rows, device: str | None = None):
    """Батч обрізається до найдовшої своєї ноги.

    Масиви можуть бути numpy — тоді на пристрій їде **тільки обрізаний
    батч**, а цілий датасет лишається в оперативній памʼяті
    (`rules/03-models.md` → Навчання без свопа). Тензори на вході
    повертаються як є: старий шлях працює незмінно.
    """
    width = int(np.asarray(lengths)[rows].max())
    parts = (x[rows, :width], y[rows, :width], mask[rows, :width],
             np.asarray(lengths)[rows] if not torch.is_tensor(lengths)
             else lengths[rows])
    if torch.is_tensor(x) or device is None:
        return parts
    return tuple(torch.as_tensor(np.ascontiguousarray(part), device=device)
                 for part in parts)


def memory_now() -> dict:
    """Скільки памʼяті вільно і скільки свопу зайнято, МБ.

    Зайнятий своп сам по собі нічого не забороняє: macOS не віддає його
    назад після того, як памʼять звільнили. Вирішує **вільна памʼять**
    — саме вона визначає, чи піде прогін у підкачку.
    """
    import re
    import subprocess
    out = {"free": None, "swap": 0.0}
    try:
        stat = subprocess.run(["vm_stat"], capture_output=True, text=True,
                              timeout=5).stdout
        page = int(re.search(r"page size of (\d+)", stat).group(1))
        rows = {key.strip(): int(value.strip().rstrip("."))
                for key, value in (line.split(":") for line in stat.splitlines()
                                   if ":" in line and "page size" not in line)}
        out["free"] = (rows["Pages free"] + rows["Pages inactive"]
                       + rows.get("Pages purgeable", 0)) * page / 2 ** 20
        usage = subprocess.run(["sysctl", "-n", "vm.swapusage"],
                               capture_output=True, text=True,
                               timeout=5).stdout.replace("=", " ").split()
        for index, word in enumerate(usage):
            if word == "used" and index + 1 < len(usage):
                out["swap"] = float(usage[index + 1].rstrip("M"))
    except (OSError, ValueError, KeyError, AttributeError,
            subprocess.SubprocessError):
        return out
    return out


def no_swap(need: float = MEMORY_NEED, force: bool = False,
            log=print) -> None:
    """Навчання не починається, коли памʼяті не вистачить без підкачки.

    `rules/03-models.md` → Навчання без свопа. Прогін у підкачці і
    рахується в рази довше, і тягне за собою всю машину: прогін
    дослідження 20 на завантаженому свопі йшов 20 хвилин замість 5.6.
    """
    now = memory_now()
    free = now["free"]
    if free is None or free >= need or force:
        log(f"памʼять: вільно {free if free is None else round(free)} МБ, "
            f"своп {now['swap']:.0f} МБ (потрібно {need:.0f})")
        return
    raise SystemExit(
        f"вільної памʼяті {free:.0f} МБ при потрібних {need:.0f} — "
        "навчання не починається (rules/03-models.md → Навчання без свопа). "
        "Закрийте зайве або запустіть з --force.")


# ---------- штраф ----------

def masked_loss(out, true, mask, pos_weight, classes: int,
                jump: float = 0.0, down: float = 0.0,
                ordinal: float = 0.0, reach: float = 0.0):
    """Штраф по справжніх кроках; паддинг у знаменник не входить.

    Для десятин до перехресної ентропії додаються чотири члени:

    | Ручка | Що карає |
    | ----- | -------- |
    | `jump` | стрибок через клас: `Δ` більше за `+1` |
    | `down` | будь-яке пониження видачі |
    | `ordinal` | відстань очікуваного класу до правди — `(e − y)²` |
    | `reach` | недохід до останнього класу на подіях цього класу |

    `ordinal` і `reach` зʼявились у дослідженні 20: без них мінімум
    досягається на будь-якій неспадній послідовності з кроком не
    більшим за `1`, зокрема на **сталій** — стояти на місці коштує
    нуль. `ordinal` дає ентропії відстань, якої в ній немає (сказати
    9 замість 10 дешевше, ніж 1), `reach` вимагає дійти до кінця.

    Нуль на обох ручках лишає рівно ту втрату, під якою навчений
    розділ 9 дослідження 19.
    """
    if classes == 1:
        raw = nn.functional.binary_cross_entropy_with_logits(
            out, true, pos_weight=pos_weight, reduction="none")
        return (raw * mask).sum() / mask.sum()
    target = (true.long() - 1).clamp(min=0)
    raw = nn.functional.cross_entropy(
        out.reshape(-1, classes), target.reshape(-1), reduction="none"
    ).reshape(true.shape)
    loss = (raw * mask).sum() / mask.sum()
    if not (jump or down or ordinal or reach):
        return loss
    levels = torch.arange(1, classes + 1, device=out.device,
                          dtype=out.dtype)
    expected = (torch.softmax(out, dim=-1) * levels).sum(-1)
    if ordinal:                                # відстань до правди у класах
        gap = (expected - true).pow(2) * mask
        loss = loss + ordinal * gap.sum() / mask.sum()
    if reach:                                  # недохід у зоні кінця ноги
        zone = mask * (true == float(classes))
        short = (float(classes) - expected).clamp(min=0.0)
        loss = loss + reach * (short.pow(2) * zone).sum() / zone.sum().clamp(
            min=1.0)
    if not (jump or down) or out.shape[1] < 2:
        return loss
    delta = expected[:, 1:] - expected[:, :-1]
    pairs = (mask[:, 1:] * mask[:, :-1])
    over = (delta - 1.0).clamp(min=0.0)        # +2, +3, +4 ...
    back = (-delta).clamp(min=0.0)             # будь-яке «вниз»
    steps = (jump * over.pow(2) + down * back.pow(2)) * pairs
    return loss + steps.sum() / pairs.sum().clamp(min=1.0)


def smooth_causal(values: np.ndarray, lengths: np.ndarray,
                  period: int) -> np.ndarray:
    """Причинна ЕМА видачі по кроках ноги; паддинг не згладжується."""
    if period <= 1:
        return values
    alpha = 2.0 / (period + 1.0)
    out = values.copy()
    for row, size in enumerate(lengths):
        run = float(values[row, 0])
        for step in range(int(size)):
            run = values[row, step] if step == 0 \
                else alpha * values[row, step] + (1 - alpha) * run
            out[row, step] = run
    return out


def predict(model, x, y, mask, lengths, rows, classes: int,
            size: int = BATCH, smooth: int = 0, device: str | None = None):
    """Ймовірність «кінець» і сказаний клас — батчами, без градієнтів.

    Для десятин сказаний клас — це **очікуваний** клас `Σ p_i·i`,
    згладжений причинною ЕМА і округлений: сходинка має бути рівною, а
    не смикатись через одну подію.
    """
    model.eval()
    top = np.zeros((len(rows), x.shape[1]), dtype=np.float32)
    said = np.zeros((len(rows), x.shape[1]), dtype=np.float32)
    with torch.no_grad():
        for start in range(0, len(rows), size):
            chunk = rows[start:start + size]
            piece = trim(x, y, mask, lengths, chunk, device)
            out = model(piece[0], piece[2], piece[3])
            if classes == 1:
                probability = torch.sigmoid(out)
                cls = (probability >= 0.5).float()
            else:
                spread = torch.softmax(out, dim=-1)
                probability = spread[..., -1]        # клас 10 — кінець ноги
                levels = torch.arange(1, classes + 1, device=out.device,
                                      dtype=out.dtype)
                cls = (spread * levels).sum(-1)      # очікуваний клас
            width = probability.shape[1]
            top[start:start + len(chunk), :width] = probability.cpu().numpy()
            said[start:start + len(chunk), :width] = cls.cpu().numpy()
    model.train()
    own = np.asarray([int(lengths[index]) for index in rows])
    if smooth > 1:
        top = smooth_causal(top, own, smooth)
        said = smooth_causal(said, own, smooth)
    if classes > 1:
        said = np.clip(np.round(said), 1, classes)
    return {"p": top, "cls": said}


# ---------- метрики ----------

def event_scores(true, prob, mask, threshold: float) -> dict:
    """Точність, повнота і F1 по подіях «кінець ноги» при заданому порозі."""
    hit = (prob >= threshold) & mask
    one = (np.asarray(true, dtype=float) > 0.5) & mask
    tp = int((hit & one).sum())
    fp = int((hit & ~one).sum())
    fn = int((~hit & one).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) \
        if precision + recall else 0.0
    return {"threshold": float(threshold), "tp": tp, "fp": fp, "fn": fn,
            "precision": number(precision), "recall": number(recall),
            "f1": number(f1)}


def pick_threshold(true, prob, mask) -> dict:
    """Поріг із найкращою F1 — рахується тільки на train."""
    grid = [event_scores(true, prob, mask, value) for value in THRESHOLDS]
    return max(grid, key=lambda item: item["f1"])


def class_scores(true, said, mask, classes: int) -> dict:
    """Влучність по всіх класах: скільки вгадано і на скільки промах.

    Для `decile` мітка — номер десятини, тому промах міряється **у
    класах**: сказати 8 замість 10 — це два класи, а не «не вгадала».
    """
    real = true[mask]
    guess = said[mask]
    rows = []
    for value in range(1, classes + 1):
        support = int((real == value).sum())
        picked = int((guess == value).sum())
        both = int(((real == value) & (guess == value)).sum())
        precision = both / picked if picked else 0.0
        recall = both / support if support else 0.0
        rows.append({"class": value, "support": support, "said": picked,
                     "hit": both, "precision": number(precision),
                     "recall": number(recall),
                     "f1": number(2 * precision * recall
                                  / (precision + recall)
                                  if precision + recall else 0.0)})
    return {"accuracy": number(float((real == guess).mean())),
            "distance": number(float(np.abs(real - guess).mean()), 3),
            "macro_f1": number(float(np.mean([row["f1"] or 0.0
                                              for row in rows]))),
            "rows": rows}


def step_scores(said, mask, classes: int) -> dict:
    """Сходинки видачі: скільки кроків угору, скільки через клас, скільки вниз."""
    up = jump = down = 0
    legs_down = 0
    for row in range(said.shape[0]):
        good = np.flatnonzero(mask[row])
        if len(good) < 2:
            continue
        delta = np.diff(said[row][good])
        up += int((delta == 1).sum())
        jump += int((delta >= 2).sum())
        moves = int((delta < 0).sum())
        down += moves
        legs_down += int(moves > 0)
    total = up + jump + down
    return {"up": up, "jump": jump, "down": down,
            "legs_with_down": legs_down,
            "clean": number(up / total) if total else None}


def leg_rows(prob, true, mask, legs, rows, threshold: float,
             seconds: int) -> list:
    """Сигнал на кожній нозі: де сказала, чи влучила, за скільки до півота."""
    out = []
    for place, index in enumerate(rows):
        leg = legs[index]
        good = np.flatnonzero(mask[place])
        p = prob[place]
        last = int(good[-1])                    # крок півота
        top = int(good[int(np.argmax(p[good]))])
        fired = [int(i) for i in good if p[i] >= threshold]
        item = {"leg": leg["leg"], "kind": leg["kind"],
                "events": leg["kept"], "ones": leg["ones"],
                "peak": number(float(p[good].max())),
                "peak_at": int(last - top),
                "peak_hit": bool(true[place, top] > 0.5)}
        if fired:
            first = fired[0]
            item.update({"signal": True, "before": int(last - first),
                         "hours": number((last - first) * seconds / 3600, 2),
                         "hit": bool(true[place, first] > 0.5),
                         "fired": len(fired)})
        else:
            item.update({"signal": False, "before": None, "hours": None,
                         "hit": False, "fired": 0})
        out.append(item)
    return out


def leg_scores(rows: list) -> dict:
    """Підсумок по ногах: скільки сигналів, скільки влучань, як рано."""
    fired = [row for row in rows if row["signal"]]
    hit = [row for row in fired if row["hit"]]
    miss = [row for row in fired if not row["hit"]]
    peaks = [row for row in rows if row.get("peak_hit")]
    before = [row["before"] for row in fired]
    return {"legs": len(rows), "signal": len(fired), "hit": len(hit),
            "peak_hit": len(peaks), "false": len(miss),
            "silent": len(rows) - len(fired),
            "hit_share": number(len(hit) / len(rows)) if rows else None,
            "peak_share": number(len(peaks) / len(rows)) if rows else None,
            "before_median": number(float(np.median(before)), 1)
            if before else None,
            "se": number(0.5 / np.sqrt(len(rows))) if rows else None}


def baseline_rows(legs, rows, mask, after: int, true, seconds: int) -> list:
    """Базовий прогноз: «кінець», щойно нога перетнула медіанну довжину."""
    out = []
    for place, index in enumerate(rows):
        leg = legs[index]
        good = np.flatnonzero(mask[place])
        last = int(good[-1])
        item = {"leg": leg["leg"], "kind": leg["kind"],
                "events": leg["kept"], "ones": leg["ones"],
                "peak": None, "peak_at": None, "peak_hit": False}
        if leg["kept"] > after:
            first = int(good[after])
            item.update({"signal": True, "before": int(last - first),
                         "hours": number((last - first) * seconds / 3600, 2),
                         "hit": bool(true[place, first] > 0.5), "fired": 1})
        else:
            item.update({"signal": False, "before": None, "hours": None,
                         "hit": False, "fired": 0})
        out.append(item)
    return out


# ---------- прогін ----------

def run(built: dict, config: dict, epochs: int = EPOCHS,
        batch: int = BATCH, patience: int = PATIENCE, seed: int = SEED,
        jump: float = 0.0, down: float = 0.0, smooth: int = 0,
        ordinal: float = 0.0, reach: float = 0.0, start: dict | None = None,
        budget: int = 0, log=print) -> dict:
    """Один прогін: навчання на train, рання зупинка і метрики по val."""
    torch.manual_seed(seed)
    generator = np.random.default_rng(seed)
    device = device_name()
    classes = built["classes"]
    top = legs_module.top_class(built["mode"])
    # Датасет лишається в оперативній памʼяті; на пристрій їде тільки
    # обрізаний батч (rules/03 → Навчання без свопа). Цілий `x` — це
    # сотні мегабайт паддингу, і на пристрої він не потрібен.
    x, y = built["x"], built["y"]
    mask = built["mask"]              # логічна: увага множить її на causal
    lengths = built["lengths"]
    train_rows, val_rows = built["parts"]["train"], built["parts"]["val"]

    pos_weight = None
    if classes == 1:
        ones = float(built["y"][train_rows][built["mask"][train_rows]].sum())
        total = float(built["mask"][train_rows].sum())
        pos_weight = torch.tensor((total - ones) / max(ones, 1.0),
                                  device=device)

    model = net_module.LegEnd(features=built["features"],
                              hidden=config["hidden"],
                              heads=max(config["heads"], 1),
                              attention=config["attention"],
                              outputs=classes).to(device)
    if start is not None:            # донавчання: ваги готової моделі
        model.load_state_dict(start)
    optimizer = torch.optim.Adam(model.parameters(), lr=config["lr"])
    spec = net_module.spec_of(model, int(built["lengths"].max()),
                              built["features"])

    curve, best, best_state, started = [], None, None, time.time()
    for epoch in range(1, epochs + 1):
        losses = []
        for chunk in batches(built["lengths"], train_rows, batch,
                             generator, budget):
            piece = trim(x, y, mask, lengths, chunk, device)
            optimizer.zero_grad()
            loss = masked_loss(model(piece[0], piece[2], piece[3]), piece[1],
                               piece[2], pos_weight, classes, jump, down,
                               ordinal, reach)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))
        model.eval()
        with torch.no_grad():
            values = []
            for chunk in batches(built["lengths"], val_rows, batch,
                                        generator, budget):
                piece = trim(x, y, mask, lengths, chunk, device)
                values.append(float(masked_loss(
                    model(piece[0], piece[2], piece[3]), piece[1], piece[2],
                    pos_weight, classes, jump, down, ordinal,
                    reach).item()))
        model.train()
        val = float(np.mean(values))
        curve.append({"epoch": epoch, "train": number(np.mean(losses)),
                      "val": number(val)})
        if best is None or val < best["val"]:
            best = {"epoch": epoch, "val": val}
            best_state = {key: value.detach().cpu().clone()
                          for key, value in model.state_dict().items()}
        if epoch - best["epoch"] >= patience:
            break
    minutes = (time.time() - started) / 60
    model.load_state_dict(best_state)

    seconds = built["event_seconds"]
    probs = {name: predict(model, x, y, mask, lengths, rows, classes, batch,
                           smooth, device)
             for name, rows in (("train", train_rows), ("val", val_rows))}
    picked = pick_threshold(built["y"][train_rows] == top,
                            probs["train"]["p"], built["mask"][train_rows])
    after = int(np.median([built["legs"][i]["kept"] for i in train_rows]))

    measured = {}
    for name, rows in (("train", train_rows), ("val", val_rows)):
        true, part_mask = built["y"][rows] == top, built["mask"][rows]
        signals = leg_rows(probs[name]["p"], true, part_mask, built["legs"],
                           rows, picked["threshold"], seconds)
        measured[name] = {
            "events": event_scores(true, probs[name]["p"], part_mask,
                                   picked["threshold"]),
            "legs": leg_scores(signals),
            "baseline": leg_scores(baseline_rows(built["legs"], rows,
                                                 part_mask, after, true,
                                                 seconds)),
            "rows": signals,
        }
        if classes > 1:
            measured[name]["classes"] = class_scores(
                built["y"][rows], probs[name]["cls"], part_mask, classes)
            measured[name]["steps"] = step_scores(probs[name]["cls"],
                                                  part_mask, classes)
    extra = ""
    if classes > 1:
        steps = measured["val"]["steps"]
        extra = (f" · влучність по 10 класах "
                 f"{measured['val']['classes']['accuracy']} · відстань "
                 f"{measured['val']['classes']['distance']}"
                 f" · сходинки +1 {steps['up']} / стрибків {steps['jump']}"
                 f" / вниз {steps['down']}")
    log(f"  {label_of(config)}: {spec['params']} ваг · епох {len(curve)} "
        f"(краща {best['epoch']}) · {minutes:.1f} хв · "
        f"val F1 {measured['val']['events']['f1']} · "
        f"влучила {measured['val']['legs']['hit']} з "
        f"{measured['val']['legs']['legs']} · "
        f"пік у зоні {measured['val']['legs']['peak_hit']}" + extra)

    return {"model": model, "spec": spec, "curve": curve, "best": best,
            "minutes": minutes, "threshold": picked, "probs": probs,
            "measured": measured, "baseline_after": after,
            "pos_weight": number(float(pos_weight.item())) if pos_weight
            is not None else None,
            "device": device, "epochs": epochs, "batch": batch,
            "seed": seed, "config": config, "jump": jump, "down": down,
            "smooth": smooth, "ordinal": ordinal, "reach": reach,
            "budget": budget, "from_weights": start is not None}


def label_of(config: dict) -> str:
    """Підпис прогону: ручки, які його відрізняють."""
    return (f"ширина {config['hidden']} · "
            + (f"увага {config['heads']} гол." if config["attention"]
               else "без уваги")
            + f" · lr {config['lr']:g}")


def rank_of(result: dict) -> tuple:
    """Чим кращий прогін: спершу влучання на val, потім F1 по подіях."""
    legs = result["measured"]["val"]["legs"]
    return (legs["hit"], legs["peak_hit"] or 0,
            result["measured"]["val"]["events"]["f1"] or 0.0)


# ---------- звіти ----------

def part_series(built: dict, result: dict, name: str) -> dict:
    """Ряди однієї вибірки: свій відрізок часу, своє полотно.

    Кожна вибірка малюється окремо (`train` і `val`), тому ряд ріжеться
    по її ногах: від першої події першої ноги до півота останньої.

    Малюється **головна монета**: ноги інших монет живуть у своєму
    часі й у своєму ціновому ряду, тому на це полотно вони не лягають.
    """
    own_pair = built["pair"]
    rows = [index for index in built["parts"][name]
            if built["legs"][index].get("pair", own_pair) == own_pair]
    if not rows:
        return {"events": 0, "t": [], "price": [], "ema": [], "y": [],
                "p": [], "cls": [], "pivots": []}
    events = np.concatenate([built["legs"][index]["events"]
                             for index in rows])
    first, last = int(events[0]), int(events[-1])
    span = np.arange(first, last + 1)
    prob = np.full(len(built["label"]), np.nan)
    said = np.full(len(built["label"]), np.nan)
    place_of = {index: place
                for place, index in enumerate(built["parts"][name])}
    for index in rows:
        own = built["legs"][index]["events"]
        place = place_of[index]
        prob[own] = result["probs"][name]["p"][place][:len(own)]
        said[own] = result["probs"][name]["cls"][place][:len(own)]
    stamps = built["data"]["t"]
    return {
        "events": int(len(span)),
        "from_utc": legs_module.utc(stamps[first]),
        "to_utc": legs_module.utc(stamps[last]),
        "t": [int(value) for value in stamps[span]],
        "price": [round(float(value), 2)
                  for value in built["data"]["price"][span]],
        "ema": [round(float(value), 2) for value in built["ema"][span]],
        "y": [float(value) for value in built["label"][span]],
        "p": [None if not np.isfinite(value) else round(float(value), 4)
              for value in prob[span]],
        "cls": [None if not np.isfinite(value) else float(value)
                for value in said[span]],
        "pivots": [{"t": int(stamps[item.index]),
                    "price": round(float(built["data"]["price"][item.index]), 2),
                    "ema": round(float(built["ema"][item.index]), 2),
                    "kind": item.kind}
                   for item in built["pivots"]
                   if first <= item.index <= last],
    }


def report_of(built: dict, result: dict, grid: list | None = None) -> dict:
    """Звіт кращого прогону — те, що читає вкладка."""
    base = legs_module.report_of(built)
    keep = ("pair", "class", "scaler", "target", "mode", "classes", "period",
            "tag", "coins", "extra", "share", "cut", "length", "features",
            "event_seconds", "events", "from_utc", "to_utc", "legs", "ones",
            "ones_share", "leg_events", "capped", "zone", "zones", "parts",
            "rows")
    return {
        **{key: base[key] for key in keep},
        "split": "за датою: ноги до межі — train, після — val",
        "net": result["spec"],
        "config": {**result["config"], "epochs": result["epochs"],
                   "batch": result["batch"], "seed": result["seed"],
                   "pos_weight": result["pos_weight"],
                   "device": result["device"], "jump": result["jump"],
                   "down": result["down"], "smooth": result["smooth"],
                   "ordinal": result["ordinal"], "reach": result["reach"],
                   "budget": result["budget"],
                   "from_weights": result["from_weights"]},
        "label": label_of(result["config"]),
        "minutes": number(result["minutes"], 2),
        "epochs_run": len(result["curve"]),
        "best_epoch": result["best"]["epoch"],
        "curve": result["curve"],
        "threshold": result["threshold"],
        "baseline_after": result["baseline_after"],
        "measured": result["measured"],
        "grid": grid or [],
        "series": {name: part_series(built, result, name)
                   for name in ("train", "val")},
    }


def grid_row(result: dict) -> dict:
    """Рядок гріда: ручки прогону і його метрики на обох вибірках."""
    row = {"label": label_of(result["config"]), **result["config"],
           "params": result["spec"]["params"],
           "epochs": len(result["curve"]),
           "best_epoch": result["best"]["epoch"],
           "minutes": number(result["minutes"], 2),
           "val_loss": number(result["best"]["val"]),
           "threshold": result["threshold"]["threshold"]}
    for name in ("train", "val"):
        part = result["measured"][name]
        row[name] = {"f1": part["events"]["f1"],
                     **{key: part["legs"][key]
                        for key in ("legs", "hit", "peak_hit", "false",
                                    "silent")}}
        if "classes" in part:
            row[name]["accuracy"] = part["classes"]["accuracy"]
            row[name]["distance"] = part["classes"]["distance"]
        if "steps" in part:
            row[name]["down"] = part["steps"]["down"]
            row[name]["jump"] = part["steps"]["jump"]
    return row


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=legs_module.PAIR)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--batch", type=int, default=BATCH)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--share", type=float, default=legs_module.SHARE)
    parser.add_argument("--cut", default=legs_module.CUT)
    parser.add_argument("--mode", default="zone", choices=legs_module.MODES)
    parser.add_argument("--period", type=int, default=legs_module.PERIOD)
    parser.add_argument("--extra", nargs="*", default=[],
                        help="монети, чиї ноги йдуть тільки в train; "
                             "`всі` — усі пʼять")
    parser.add_argument("--jump", type=float, default=0.0,
                        help=f"ціна стрибка через клас, типово {JUMP} "
                             "у прогоні зі сходинками")
    parser.add_argument("--down", type=float, default=0.0,
                        help=f"ціна пониження видачі, типово {DOWN}")
    parser.add_argument("--smooth", type=int, default=0,
                        help=f"причинна ЕМА видачі, подій (типово {SMOOTH})")
    parser.add_argument("--steps", action="store_true",
                        help="прогін зі сходинками: усі монети в train, "
                             f"штрафи {JUMP}/{DOWN}, ЕМА {SMOOTH}")
    parser.add_argument("--configs", type=int, default=0,
                        help="скільки прогонів гріда взяти (0 — усі)")
    parser.add_argument("--one", action="store_true",
                        help="один прогін ручками за замовчуванням, без гріда")
    parser.add_argument("--force", action="store_true",
                        help="почати навчання навіть при зайнятому свопі")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    no_swap(force=args.force)

    if args.steps:                       # готовий набір прогону сходинок
        args.mode, args.period = "decile", 10
        args.extra = args.extra or ["всі"]
        args.jump = args.jump or JUMP
        args.down = args.down or DOWN
        args.smooth = args.smooth or SMOOTH
    extra = tuple(legs_module.EXTRA_PAIRS if args.extra == ["всі"]
                  else args.extra)
    built = legs_module.build(args.pair, share=args.share, cut=args.cut,
                              mode=args.mode, period=args.period, extra=extra)
    tag = legs_module.tag_of(args.mode, args.period, extra)
    plan = ([{"hidden": net_module.HIDDEN, "heads": net_module.HEADS,
              "lr": LR, "attention": True}] if args.one else configs())
    if args.configs:
        plan = plan[:args.configs]
    print(f"грід{tag}: {len(plan)} прогонів по {args.epochs} епох "
          f"(рання зупинка {args.patience})")

    rows, best, started = [], None, time.time()
    for index, config in enumerate(plan, 1):
        print(f"[{index}/{len(plan)}]", end=" ")
        result = run(built, config, args.epochs, args.batch, args.patience,
                     jump=args.jump, down=args.down, smooth=args.smooth)
        rows.append(grid_row(result))
        if best is None or rank_of(result) > rank_of(best):
            best = result
    minutes = (time.time() - started) / 60

    rows.sort(key=lambda row: (row["val"]["hit"], row["val"]["peak_hit"],
                               row["val"]["f1"] or 0), reverse=True)
    args.out.mkdir(parents=True, exist_ok=True)
    folder = MODELS / f"leg_end{tag}"
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(best["model"].state_dict(), folder / "model.pt")

    report = report_of(built, best, rows)
    report["model_path"] = str(folder.relative_to(PROJECT_ROOT))
    report["grid_minutes"] = number(minutes, 2)
    (args.out / f"train{tag}.json").write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    (args.out / f"grid{tag}.json").write_text(
        json.dumps({"rows": rows, "minutes": number(minutes, 2),
                    "epochs": args.epochs, "patience": args.patience,
                    "mode": args.mode, "period": args.period,
                    "classes": built["classes"], "jump": args.jump,
                    "down": args.down, "smooth": args.smooth,
                    "coins": built["coins"],
                    "best": label_of(best["config"]),
                    "grid": {key: list(value) for key, value in GRID.items()}},
                   ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(f"грід {minutes:.1f} хв · краща модель: {label_of(best['config'])}")
    print(f"записано {args.out / f'train{tag}.json'} і "
          f"{args.out / f'grid{tag}.json'}")


if __name__ == "__main__":
    main()
