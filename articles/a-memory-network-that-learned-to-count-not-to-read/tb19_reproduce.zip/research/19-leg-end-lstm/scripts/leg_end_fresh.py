"""Модель розділу 9 на свіжому відрізку: усі шість монет, без навчання.

Дослідження: research/19-leg-end-lstm/
Правила: rules/03-models.md → Метрики, Відображення результатів
         rules/05-visualization.md → Полотна, масштаб

Ваги беруться готові — `models/leg_end_steps_ema10_2_3/model.pt`, та сама
краща модель розділу 9 (`ширина 64 · увага 2 гол. · lr 1e-3`, епоха 4).
Тут **нічого не вчиться**: модель тільки читає відрізок, якого не бачила.

## Два питання

1. **На яких відрізках часу вона вчилась.** Ноги train розділу 9
   перераховуються тим самим викликом, що й там, і зводяться в таблицю
   по монетах: скільки ніг, скільки подій, від якої дати до якої.

2. **Що вона каже на свіжому відрізку.** Вікно
   `2026-08-14 14:00 … 2026-09-02 00:00` UTC на **кожній** з шести
   монет, зібраних наново по поточний час (`<PAIR>_now`).

## Ноги вікна

Нога заходить у мережу **цілком від свого початку** — інакше памʼять
почалась би з середини, а модель веде ногу від півота. Показується з неї
тільки частина, що лежить у вікні.

Крім закритих ніг береться **відкрита**: події після останнього півота,
кінець яких ще не настав. Мітки в неї немає, тому в метрики по класах
вона не входить — тільки у видачу на полотні.

## Що вважається свіжим

Вікно починається за півтори години до межі train, тому в нього
потрапляють і ноги, які модель **бачила**:

    нога train розділу 9   ->  на ній рахувався градієнт
    нога val розділу 9     ->  на ній обиралась епоха і конфігурація

Обидві впізнаються за парою «початок, кінець» ноги і **в метрики
свіжого відрізка не йдуть**. На полотні вони лишаються — інакше ціна
мала б розрив, — і межа побаченого малюється пунктиром (`series.seen`).

## Масштаб полотен

Ймовірність класу 10 живе біля порога `0.10`, а сказаний клас — у
кількох сусідніх десятинах, тому шкала `0 … 1` і `1 … 10` показала б
пряму лінію. Обидва полотна масштабуються **під свій ряд**:

    видача:       від floor(min) - 0.5 до ceil(max) + 0.5, у межах 0.5 … 10.5
    ймовірність:  [min, max] + 5 % запасу з кожного боку,
                  поріг завжди всередині, ширина не менша за 0.02

Запуск:
    python3 research/19-leg-end-lstm/scripts/leg_end_fresh.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_end_data as legs_module  # noqa: E402
import leg_end_net as net_module  # noqa: E402
import leg_end_train as train_module  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
TAG = legs_module.STEPS_TAG          # _steps_ema10_2_3

# Свіжий відрізок: від межі train розділу 9 до кінця зібраних даних.
FROM = "2026-08-14 14:00"
TO = "2026-09-02 00:00"
# Монети, зібрані наново по поточний час. BTC — без заповнення, як
# `BTC_USDT_29` розділу 9; альткоїни — із заповненням, як `*_USDT_fill`.
FRESH_PAIRS = ("BTC_USDT_now", "ETH_USDT_now", "SOL_USDT_now",
               "XRP_USDT_now", "BNB_USDT_now", "DOGE_USDT_now")
MODE = "decile"
PERIOD = 10
PAD = 0.05                           # запас шкали ймовірності з кожного боку
MIN_SPAN = 0.02                      # найвужча шкала ймовірності


def coin_of(pair: str) -> str:
    """Монета без суфікса збірки: `BTC_USDT_now` → `BTC_USDT`."""
    for suffix in ("_now", "_fill", "_29"):
        if pair.endswith(suffix):
            return pair[: -len(suffix)]
    return pair


def stamp_of(when: str) -> int:
    moment = dt.datetime.strptime(when, "%Y-%m-%d %H:%M")
    return int(moment.replace(tzinfo=dt.timezone.utc).timestamp())


def days_between(first: int, last: int) -> float:
    return round((last - first) / 86400, 1)


# ---------- де вона вчилась ----------

def training_table(cut: str = legs_module.CUT, log=print) -> dict:
    """Відрізки часу train розділу 9 — по монеті на рядок.

    Ноги перераховуються тим самим викликом, що й у розділі 9, тому
    таблиця описує рівно ту вибірку, на якій стоять ваги.
    """
    built = legs_module.build(legs_module.PAIR, mode=MODE, period=PERIOD,
                              extra=legs_module.EXTRA_PAIRS, cut=cut,
                              log=lambda *_: None)
    rows = []
    for name in (legs_module.PAIR, *legs_module.EXTRA_PAIRS):
        own = [built["legs"][i] for i in built["parts"]["train"]
               if built["legs"][i]["pair"] == name]
        if not own:
            continue
        first = min(leg["from"] for leg in own)
        last = max(leg["to"] for leg in own)
        events = sum(leg["kept"] for leg in own)
        rows.append({"pair": name, "coin": coin_of(name),
                     "legs": len(own), "events": events,
                     "ones": sum(leg["ones"] for leg in own),
                     "from_utc": legs_module.utc(first),
                     "to_utc": legs_module.utc(last),
                     "days": days_between(first, last),
                     "median_leg": int(np.median([leg["kept"]
                                                  for leg in own]))})
    total = {"legs": sum(row["legs"] for row in rows),
             "events": sum(row["events"] for row in rows),
             "ones": sum(row["ones"] for row in rows),
             "from_utc": min(row["from_utc"] for row in rows),
             "to_utc": max(row["to_utc"] for row in rows)}
    val = [built["legs"][i] for i in built["parts"]["val"]]
    # Ноги, які модель уже бачила, — за парою «початок, кінець». Вікно
    # розділу 10 стоїть майже на межі, тому кілька його ніг можуть бути
    # тими самими: їх треба впізнати і не рахувати як свіжі.
    seen = {"train": {}, "val": {}}
    for part in ("train", "val"):
        for index in built["parts"][part]:
            leg = built["legs"][index]
            seen[part].setdefault(coin_of(leg["pair"]), set()).add(
                (leg["from"], leg["to"]))
    log("train розділу 9: " + " · ".join(
        f"{row['coin']} {row['legs']} ніг {row['from_utc'][:10]}"
        f"…{row['to_utc'][:10]}" for row in rows))
    return {"cut": cut, "rows": rows, "total": total, "seen": seen,
            "val": {"pair": legs_module.PAIR,
                    "coin": coin_of(legs_module.PAIR),
                    "legs": len(val),
                    "events": sum(leg["kept"] for leg in val),
                    "from_utc": legs_module.utc(min(leg["from"]
                                                    for leg in val)),
                    "to_utc": legs_module.utc(max(leg["to"] for leg in val))}}


# ---------- ноги вікна ----------

def open_leg(data: dict, pivots: list, count: int, length: int) -> dict | None:
    """Відкрита нога: події після останнього півота, кінець не настав."""
    if not pivots:
        return None
    start, stop = pivots[-1].index + 1, count - 1
    if stop <= start:
        return None
    cut = max(start, stop - length + 1)
    events = np.arange(cut, stop + 1)
    return {"leg": -1, "events": events, "full": int(stop - start + 1),
            "kept": int(len(events)), "cut": int(cut - start), "kind": "open",
            "ones": 0, "open": True,
            "from": int(data["t"][events[0]]),
            "to": int(data["t"][events[-1]])}


def window_legs(one: dict, first: int, last: int, length: int) -> list[dict]:
    """Ноги, які торкаються вікна, плюс відкрита нога в кінці ряду."""
    legs = [dict(leg, open=False) for leg in one["legs"]
            if leg["to"] >= first and leg["from"] <= last]
    tail = open_leg(one["data"], one["pivots"], len(one["label"]), length)
    if tail is not None and tail["to"] >= first and tail["from"] <= last:
        tail["pair"] = one["pair"]
        legs.append(tail)
    return legs


# ---------- масштаб ----------

def class_range(values: np.ndarray, classes: int) -> dict:
    """Шкала сказаного класу: цілі десятини навколо ряду."""
    good = values[np.isfinite(values)]
    if not len(good):
        return {"low": 0.5, "high": classes + 0.5}
    low = max(math.floor(float(good.min())) - 0.5, 0.5)
    high = min(math.ceil(float(good.max())) + 0.5, classes + 0.5)
    if high - low < 1.0:
        low, high = max(low - 0.5, 0.5), min(high + 0.5, classes + 0.5)
    return {"low": round(low, 2), "high": round(high, 2)}


def prob_range(values: np.ndarray, threshold: float) -> dict:
    """Шкала ймовірності: під свій ряд, поріг завжди всередині."""
    good = values[np.isfinite(values)]
    if not len(good):
        return {"low": 0.0, "high": 1.0}
    low = min(float(good.min()), threshold)
    high = max(float(good.max()), threshold)
    span = max(high - low, MIN_SPAN)
    pad = span * PAD
    return {"low": round(max(low - pad, 0.0), 4),
            "high": round(min(high + pad, 1.0), 4)}


# ---------- прогін по монеті ----------

def mark_seen(legs: list, coin: str, seen: dict) -> np.ndarray:
    """Чи модель уже бачила цю ногу: `train`, `val` розділу 9 або нічого.

    Вікно починається за півтори години до межі, тому в нього
    потрапляють і ноги, на яких модель вчилась, і ноги, на яких їй
    обирали епоху. У метрики свіжого відрізка вони не йдуть.
    """
    marks = []
    for leg in legs:
        key = (leg["from"], leg["to"])
        if key in seen.get("train", {}).get(coin, ()):
            marks.append("train")
        elif key in seen.get("val", {}).get(coin, ()):
            marks.append("val")
        else:
            marks.append(None)
    for leg, mark in zip(legs, marks):
        leg["seen"] = mark
    return np.array([mark is None for mark in marks])


def run_pair(model, pair: str, report: dict, first: int, last: int,
             seen: dict, log=print) -> dict:
    """Одна монета: ноги вікна, видача моделі, метрики і ряд для полотна."""
    classes = report["classes"]
    threshold = report["threshold"]["threshold"]
    smooth = report["config"]["smooth"]
    length = report["length"]
    one = legs_module.prepare(pair, None, length, report["share"],
                              MODE, report["period"])
    legs = window_legs(one, first, last, length)
    if not legs:
        return {"pair": pair, "coin": coin_of(pair), "legs": [], "events": 0}

    packed = legs_module.tensors({pair: one}, legs)
    device = train_module.device_name()
    rows = list(range(len(legs)))
    probs = train_module.predict(
        model, torch.tensor(packed["x"], device=device),
        torch.tensor(packed["y"], device=device),
        torch.tensor(packed["mask"], device=device),
        torch.tensor(packed["lengths"], device=device),
        rows, classes, report["config"]["batch"], smooth)

    stamps = one["data"]["t"]
    top = float(classes)
    known = np.array([not leg["open"] for leg in legs])
    unseen = mark_seen(legs, coin_of(pair), seen)
    fresh = known & unseen          # закрита нога, якої модель не бачила
    true = packed["y"] == top
    signals = train_module.leg_rows(probs["p"], true, packed["mask"],
                                    legs, rows, threshold,
                                    report["event_seconds"])
    closed = [row for row, keep in zip(signals, fresh) if keep]
    baseline = train_module.baseline_rows(
        legs, [i for i in rows if fresh[i]],
        packed["mask"][fresh], report["baseline_after"], true[fresh],
        report["event_seconds"])

    # Події вікна: усі йдуть на полотно, у метрики — тільки свіжі.
    inside = np.zeros_like(packed["mask"])
    for row, leg in enumerate(legs):
        take = (stamps[leg["events"]] >= first) & (stamps[leg["events"]] <= last)
        inside[row, :len(take)] = take
    labelled = inside & fresh[:, None]
    scores = train_module.class_scores(packed["y"], probs["cls"], labelled,
                                       classes)
    steps = train_module.step_scores(probs["cls"], inside & unseen[:, None],
                                     classes)
    events = train_module.event_scores(true, probs["p"], labelled, threshold)

    series = pair_series(one, legs, probs, inside, first, last, threshold)
    was_seen = [leg for leg in legs if leg["seen"]]
    if was_seen:                    # межа побаченого — на полотні пунктиром
        series["seen"] = {"to": max(leg["to"] for leg in was_seen),
                          "to_utc": legs_module.utc(
                              max(leg["to"] for leg in was_seen)),
                          "legs": len(was_seen)}
    log(f"  {coin_of(pair)}: {len(legs)} ніг "
        f"({int(fresh.sum())} свіжих закритих, "
        f"{len(was_seen)} уже бачених), {series['events']} подій вікна · "
        f"влучність класу {scores['accuracy']} · відстань "
        f"{scores['distance']} · сходинки +1 {steps['up']} / стрибків "
        f"{steps['jump']} / вниз {steps['down']}")
    return {
        "pair": pair, "coin": coin_of(pair),
        "events": series["events"],
        "legs_total": len(legs), "legs_closed": int(fresh.sum()),
        "legs_open": int((~known & unseen).sum()),
        "legs_seen": {"train": sum(1 for leg in legs
                                   if leg["seen"] == "train"),
                      "val": sum(1 for leg in legs if leg["seen"] == "val")},
        "classes": scores, "steps": steps, "events_scores": events,
        "legs": train_module.leg_scores(closed) if closed else None,
        "baseline": train_module.leg_scores(baseline) if baseline else None,
        "rows": [{**row, "open": bool(legs[place]["open"]),
                  "seen": legs[place]["seen"],
                  "from_utc": legs_module.utc(legs[place]["from"]),
                  "to_utc": legs_module.utc(legs[place]["to"])}
                 for place, row in enumerate(signals)],
        "series": series,
    }


def pair_series(one: dict, legs: list, probs: dict, inside: np.ndarray,
                first: int, last: int, threshold: float) -> dict:
    """Ряд вікна однієї монети: ціна, ема, мітка, видача, ймовірність."""
    stamps = one["data"]["t"]
    span = np.flatnonzero((stamps >= first) & (stamps <= last))
    if not len(span):
        return {"events": 0, "t": [], "price": [], "ema": [], "y": [],
                "p": [], "cls": [], "pivots": [], "scale": {}}
    prob = np.full(len(stamps), np.nan)
    said = np.full(len(stamps), np.nan)
    label = np.full(len(stamps), np.nan)
    for row, leg in enumerate(legs):
        own = leg["events"]
        take = inside[row, :len(own)]
        prob[own[take]] = probs["p"][row][:len(own)][take]
        said[own[take]] = probs["cls"][row][:len(own)][take]
        if not leg["open"]:
            label[own[take]] = one["label"][own[take]]
    first_i, last_i = int(span[0]), int(span[-1])
    return {
        "events": int(len(span)),
        "from_utc": legs_module.utc(stamps[first_i]),
        "to_utc": legs_module.utc(stamps[last_i]),
        "t": [int(value) for value in stamps[span]],
        "price": [round(float(value), 6)
                  for value in one["data"]["price"][span]],
        "ema": [round(float(value), 6) for value in one["ema"][span]],
        "y": [None if not np.isfinite(value) else float(value)
              for value in label[span]],
        "p": [None if not np.isfinite(value) else round(float(value), 4)
              for value in prob[span]],
        "cls": [None if not np.isfinite(value) else float(value)
                for value in said[span]],
        "pivots": [{"t": int(stamps[item.index]),
                    "price": round(float(one["data"]["price"][item.index]), 6),
                    "ema": round(float(one["ema"][item.index]), 6),
                    "kind": item.kind}
                   for item in one["pivots"]
                   if first_i <= item.index <= last_i],
        "scale": {"cls": class_range(said[span], 10),
                  "p": prob_range(prob[span], threshold)},
    }


# ---------- звіт ----------

def totals_of(coins: list) -> dict:
    """Разом по шести монетах: класи, сходинки, ноги."""
    weight = [coin["classes"]["rows"] for coin in coins]
    support = [sum(row["support"] for row in rows) for rows in weight]
    hit = [sum(row["hit"] for row in rows) for rows in weight]
    total = sum(support)
    steps = {key: sum(coin["steps"][key] or 0 for coin in coins)
             for key in ("up", "jump", "down", "legs_with_down")}
    clean = steps["up"] / max(steps["up"] + steps["jump"] + steps["down"], 1)
    return {
        "coins": len(coins),
        "events": sum(coin["events"] for coin in coins),
        "legs_closed": sum(coin["legs_closed"] for coin in coins),
        "legs_open": sum(coin["legs_open"] for coin in coins),
        "legs_seen": {part: sum(coin["legs_seen"][part] for coin in coins)
                      for part in ("train", "val")},
        "labelled": total,
        "accuracy": train_module.number(sum(hit) / max(total, 1)),
        "distance": train_module.number(
            float(np.average([coin["classes"]["distance"] or 0
                              for coin in coins],
                             weights=[max(one, 1) for one in support])), 3),
        "hit": sum((coin["legs"] or {}).get("hit", 0) for coin in coins),
        "peak_hit": sum((coin["legs"] or {}).get("peak_hit", 0)
                        for coin in coins),
        "signal": sum((coin["legs"] or {}).get("signal", 0) for coin in coins),
        "silent": sum((coin["legs"] or {}).get("silent", 0) for coin in coins),
        "baseline_hit": sum((coin["baseline"] or {}).get("hit", 0)
                            for coin in coins),
        "steps": {**steps, "clean": train_module.number(clean)},
        "se": train_module.number(
            0.5 / math.sqrt(max(sum(coin["legs_closed"] for coin in coins), 1))),
    }


def build_report(pairs=FRESH_PAIRS, when=(FROM, TO), log=print) -> dict:
    """Увесь розділ: де вчилась, що каже на свіжому відрізку."""
    report = json.loads((RESULTS / f"train{TAG}.json").read_text("utf-8"))
    config = report["config"]
    device = train_module.device_name()
    model = net_module.LegEnd(features=report["features"],
                              hidden=config["hidden"],
                              heads=max(config["heads"], 1),
                              attention=config["attention"],
                              outputs=report["classes"]).to(device)
    weights = MODELS / f"leg_end{TAG}" / "model.pt"
    model.load_state_dict(torch.load(weights, map_location=device))
    model.eval()

    first, last = stamp_of(when[0]), stamp_of(when[1])
    log(f"модель {report['label']} · {report['net']['params']} ваг · "
        f"епоха {report['best_epoch']} · поріг {report['threshold']['threshold']}")
    log(f"вікно {when[0]} … {when[1]} UTC · {len(pairs)} монет")

    training = training_table(report["cut"], log)
    seen = training.pop("seen")     # множини ніг — робоче, у звіт не йде
    started = time.time()
    coins = [run_pair(model, pair, report, first, last, seen, log)
             for pair in pairs]
    coins = [coin for coin in coins if coin.get("events")]
    minutes = (time.time() - started) / 60
    # Шкала ймовірності спільна на всі монети: інакше однакова видача
    # виглядала б по-різному від монети до монети.
    lows = [coin["series"]["scale"]["p"]["low"] for coin in coins]
    highs = [coin["series"]["scale"]["p"]["high"] for coin in coins]
    shared = prob_range(np.array(lows + highs),
                        report["threshold"]["threshold"])
    for coin in coins:
        coin["series"]["scale"]["p"] = shared
    return {
        "from_utc": when[0], "to_utc": when[1],
        "days": days_between(first, last),
        # Момент прогону: датасети зібрані по поточний час, тому правий
        # край полотен — це останні секунди джерела саме на цю мить.
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "pairs": list(pairs),
        "model": {"label": report["label"], "tag": TAG,
                  "path": report["model_path"],
                  "params": report["net"]["params"],
                  "best_epoch": report["best_epoch"],
                  "threshold": report["threshold"]["threshold"],
                  "baseline_after": report["baseline_after"],
                  "config": config, "target": report["target"],
                  "class": report["class"], "scaler": report["scaler"],
                  "share": report["share"], "period": report["period"],
                  "classes": report["classes"],
                  "event_seconds": report["event_seconds"],
                  "features": report["features"], "device": device},
        "training": training,
        "coins": coins,
        "totals": totals_of(coins),
        "minutes": train_module.number(minutes, 2),
        "scale": {"pad": PAD, "min_span": MIN_SPAN, "shared_p": shared},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from", dest="start", default=FROM)
    parser.add_argument("--to", dest="stop", default=TO)
    parser.add_argument("--pairs", nargs="*", default=list(FRESH_PAIRS))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build_report(tuple(args.pairs), (args.start, args.stop))
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"fresh{TAG}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
