"""Мережа з памʼяттю: LSTM уздовж ноги плюс причинна увага на свою памʼять.

Дослідження: research/19-leg-end-lstm/
Правила: rules/03-models.md → Правила навчання

Задача послідовнісна: мережа йде ногою подія за подією і на **кожному**
кроці каже одне число — ймовірність того, що нога тут закінчується.

    вхід  (B, L, 60)   ->  LSTM(60 -> hidden)  памʼять: стан несе всю ногу
          (B, L, h)    ->  причинна увага      погляд назад на всі події
          (B, L, 2h)   ->  Linear(2h -> C)     логіти кроку

`C` — скільки класів у мітці: `1` для зони кінця ноги (один логіт,
сигмоїда) і `10` для десятин ноги (софтмакс по десяти).

## Памʼять обнуляється на кожній нозі

Кожна нога — окрема послідовність із `h0 = c0 = 0`, стан з ноги в ногу
не переноситься. Паддинг у LSTM **не заходить взагалі**:
`pack_padded_sequence` веде рекурсію рівно по `lengths`, тому перша
подія ноги завжди бачить чисту памʼять, скільки б паддингу не стояло
поруч у батчі.

## Увага

Причинна: крок `t` бачить кроки `1 … t` і жодного правішого; паддинг у
ключі не потрапляє. Інакше в мітку кроку заходило б майбутнє тієї самої
ноги, і на живому ринку модель так працювати не змогла б.

`attention=False` лишає ту саму мережу без уваги — це один із варіантів
гріда, а не окремий скрипт.
"""

from __future__ import annotations

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

HIDDEN = 64
HEADS = 2
DROPOUT = 0.1


class LegEnd(nn.Module):
    """LSTM + причинна увага; вихід — логіт на кожен крок ноги."""

    def __init__(self, features: int = 60, hidden: int = HIDDEN,
                 layers: int = 1, heads: int = HEADS,
                 dropout: float = DROPOUT, attention: bool = True,
                 outputs: int = 1):
        super().__init__()
        if attention and hidden % heads:
            raise ValueError("ширина має ділитись на кількість голів")
        self.hidden, self.heads, self.attention = hidden, heads, attention
        self.layers, self.outputs = layers, outputs
        self.lstm = nn.LSTM(features, hidden, num_layers=layers,
                            batch_first=True,
                            dropout=dropout if layers > 1 else 0.0)
        self.norm = nn.LayerNorm(hidden)
        if attention:
            self.query = nn.Linear(hidden, hidden)
            self.key = nn.Linear(hidden, hidden)
            self.value = nn.Linear(hidden, hidden)
            self.mix = nn.LayerNorm(hidden)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden * (2 if attention else 1), outputs)

    def memory(self, x: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
        """Стан LSTM по кроках ноги; паддинг у рекурсію не входить."""
        packed = pack_padded_sequence(x, lengths.cpu(), batch_first=True,
                                      enforce_sorted=False)
        out, _ = self.lstm(packed)
        out, _ = pad_packed_sequence(out, batch_first=True,
                                     total_length=x.shape[1])
        return self.norm(out)

    def look_back(self, h: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """Причинна увага на власні виходи: крок `t` бачить `1 … t`."""
        batch, length, _ = h.shape
        size = self.hidden // self.heads
        shape = (batch, length, self.heads, size)
        q = self.query(h).view(shape).transpose(1, 2)
        k = self.key(h).view(shape).transpose(1, 2)
        v = self.value(h).view(shape).transpose(1, 2)
        causal = torch.ones(length, length, dtype=torch.bool,
                            device=h.device).tril()
        allowed = (causal.unsqueeze(0) & mask[:, None, :]).unsqueeze(1)
        # Крок паддингу не має жодного ключа; без цього softmax по
        # порожньому рядку дав би NaN. Йому дозволяється він сам.
        empty = ~allowed.any(dim=-1, keepdim=True)
        allowed = allowed | (empty & torch.eye(length, dtype=torch.bool,
                                               device=h.device))
        out = torch.nn.functional.scaled_dot_product_attention(
            q, k, v, attn_mask=allowed)
        return self.mix(out.transpose(1, 2).reshape(batch, length,
                                                    self.hidden))

    def forward(self, x: torch.Tensor, mask: torch.Tensor,
                lengths: torch.Tensor) -> torch.Tensor:
        h = self.memory(x, lengths)
        if self.attention:
            h = torch.cat([h, self.look_back(h, mask)], dim=-1)
        out = self.head(self.drop(h))
        return out.squeeze(-1) if self.outputs == 1 else out


def parameters_of(model: nn.Module) -> int:
    return sum(item.numel() for item in model.parameters())


def spec_of(model: LegEnd, length: int, features: int) -> dict:
    """Опис мережі числами — для звіту і вкладки."""
    hidden = model.hidden
    rows = [{"step": "вхід: нога з подій", "shape": [length, features],
             "params": 0},
            {"step": f"LSTM({features} → {hidden}) × {model.layers}"
                     " + LayerNorm, паддинг не заходить",
             "shape": [length, hidden],
             "params": sum(item.numel()
                           for part in (model.lstm, model.norm)
                           for item in part.parameters())}]
    if model.attention:
        rows.append({"step": f"причинна увага, {model.heads} голови, "
                             f"матриця {length} × {length}",
                     "shape": [length, hidden],
                     "params": sum(item.numel() for part in
                                   (model.query, model.key, model.value,
                                    model.mix)
                                   for item in part.parameters())})
    rows.append({"step": f"голова Linear({hidden * (2 if model.attention else 1)}"
                         f" → {model.outputs}) на кожен крок",
                 "shape": [length, model.outputs],
                 "params": sum(item.numel()
                               for item in model.head.parameters())})
    return {"hidden": hidden, "heads": model.heads if model.attention else 0,
            "layers": model.layers, "attention": model.attention,
            "outputs": model.outputs,
            "length": length, "features": features,
            "params": parameters_of(model), "rows": rows}
