"""Вікна ноги на канві 500: чи корелюють ноги по рівних частках і надлишках.

Дослідження: research/35-leg-fullness/ → Етап 6

## Хід

1. Ноги й записи 30 с — етап 3 (`data/bars30/legs.json`,
   `<PAIR>_<part>.npz`). Нога довжини `L` записів.
2. **Вікно** частки `q` — записи від першого після півота, `n = round(q·L)`.
   `q ≤ 1` — префікс ноги; `q > 1` — уся нога і `n − L` записів
   наступної. Вікно не виходить за кінець наступної ноги: такі `q` у
   нозі не беруться, в останньої ноги частини `q > 1` немає.
3. **Канва вікна** — той самий хід, що в етапі 3, але на самому вікні:
   500 відрізків, клас, `500 × F`. **Нормування — тільки на вікно**
   (правило дослідження): медіана → `sign·log1p` → 99-й перцентиль по
   живих рядках вікна.
4. **Кореляція Пірсона між вікнами різних ніг** — по живих у **обох**
   рядках (мертві рядки короткого вікна не роблять вікна схожими
   формально); вікно стандартизоване по своїх живих числах. Пари однієї
   ноги не беруть участі. Пара з менш ніж `MIN_COLIVE` спільних живих
   рядків дає 0.
5. **Матриця `M[a, b]`** — середня кореляція вікон частки `a` з
   вікнами частки `b` інших ніг. **Розрив частки** `a` =
   `M[a, a] − середнє M[a, b≠a]`: наскільки вікна однієї частки схожі
   між собою більше, ніж на інші частки. Звід — середній розрив по
   рівних частках (`q < 1`), по надлишках (`q > 1`) і по всіх.
6. **Влучність** — вікну дається частка, з вікнами якої в інших ногах
   у нього найбільша середня кореляція: точна частка, сусідня (±1
   щабель), три зони (`< 0.98`, `0.98 … 1.0`, `> 1.0`) і середня
   похибка `|q̂ − q|`.
7. **Підлога** — 200 перемішувань (seed 36): у кожній нозі частки її
   вікон переставляються між собою. 95-й перцентиль розриву й
   влучності, 5-й — похибки.
8. Групи ніг: усі, вгору, вниз (напрямок першої ноги вікна). Train і
   val окремо.

Запуск:
    python3 research/35-leg-fullness/scripts/windows30.py
    python3 research/35-leg-fullness/scripts/windows30.py --classes x10m1x7dd

Вихід: data/bars30/windows_<part>_<клас>.npz — канви вікон (вхід для
мережі); results/windows30.json — звід.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import (BAR, DATA, PARTS, RESULTS, ROWS, canvas_blocks,  # noqa: E402
                    normalize, place, read_seconds)

SHARES = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.98, 1.0,
          1.1, 1.2, 1.3, 1.4, 1.5)
FULL = (0.98, 1.0)             # зона «нога подана повністю»
MIN_COLIVE = 50                # спільних живих рядків, щоб пара бралась
SHUFFLES = 200
SEED = 36
GROUPS = ("all", "up", "down")
CHUNK = 1024


def window_bars(leg: dict, following: dict | None, share: float) -> int | None:
    """Записів у вікні частки `share`; `None`, коли вікна не буде.

    `q > 1` потребує наступної ноги впритул, і вікно не виходить за її
    кінець."""
    count = max(2, int(round(share * leg["bars"])))
    if count <= leg["bars"]:
        return count
    if following is None or following["first"] != leg["last"] + 1:
        return None
    if leg["first"] + count - 1 > following["last"]:
        return None
    return count


def window_canvas(holder, stamps: np.ndarray, key: str,
                  rows: int = ROWS) -> tuple:
    """Канва одного вікна: `rows × F` після нормування на саме вікно."""
    block, _, step = canvas_blocks(holder, stamps, int(stamps[-1]) + BAR - 1,
                                   rows)
    x, mask = place(classes30.features(key, block), block, rows)
    net = normalize(x[None], mask[None])[0].astype(np.float32)
    return net, mask, step


def build_windows(table: dict, part: str, key: str, data: Path = DATA,
                  root: Path | None = None, shares=SHARES, log=print) -> dict:
    """Канви вікон усіх ніг частини на одному класі."""
    out = {"net": [], "mask": [], "share": [], "leg": [], "kind": [],
           "key": [], "bars": [], "step": []}
    number = 0
    for pair, parts in table["legs"].items():
        legs = parts.get(part, [])
        if not legs:
            continue
        with np.load(data / f"{pair}_{part}.npz") as store:
            stamps = store["t"]
        cache = {}
        for index, leg in enumerate(legs):
            following = legs[index + 1] if index + 1 < len(legs) else None
            counts = {share: window_bars(leg, following, share)
                      for share in shares}
            longest = max(count for count in counts.values() if count)
            holder = read_seconds(pair, leg["from"],
                                  int(stamps[leg["first"] + longest - 1])
                                  + BAR - 1, cache, root)
            for share, count in counts.items():
                if count is None:
                    continue
                net, mask, step = window_canvas(
                    holder, stamps[leg["first"]:leg["first"] + count], key)
                out["net"].append(net)
                out["mask"].append(mask)
                out["share"].append(share)
                out["leg"].append(number)
                out["kind"].append(leg["kind"])
                out["key"].append(f"{pair}·{leg['leg']}")
                out["bars"].append(count)
                out["step"].append(step)
            number += 1
        log(f"{pair} {part}: ніг {len(legs)}, вікон {len(out['share'])}")
    return {name: np.asarray(value) for name, value in out.items()}


def standardize_live(net: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Вікно `(N, rows, F)` → вектор з нульовим середнім і одиничним
    розкидом по своїх живих числах; мертві рядки — 0."""
    x = net.reshape(len(net), -1).astype(np.float32)
    live = np.repeat(mask, net.shape[2], axis=1).astype(np.float32)
    count = np.maximum(live.sum(axis=1, keepdims=True), 1)
    mean = (x * live).sum(axis=1, keepdims=True) / count
    x = (x - mean) * live
    std = np.sqrt((x ** 2).sum(axis=1, keepdims=True) / count)
    return np.divide(x, std, out=np.zeros_like(x), where=std > 0), live


def correlations(z: np.ndarray, live: np.ndarray, rows: slice,
                 features: int, min_colive: int = MIN_COLIVE) -> np.ndarray:
    """Кореляції рядків `rows` з усіма вікнами — по спільних живих числах."""
    z2 = z ** 2
    num = z[rows] @ z.T
    left = z2[rows] @ live.T
    right = live[rows] @ z2.T
    both = live[rows] @ live.T
    denom = np.sqrt(left * right)
    out = np.divide(num, denom, out=np.zeros_like(num), where=denom > 0)
    out[both < min_colive * features] = 0.0
    return out


def permutations(leg: np.ndarray, share_index: np.ndarray, shuffles: int,
                 rng) -> np.ndarray:
    """Мітки часток `(N, shuffles + 1)`: перший стовпчик — справжні, далі —
    переставлені всередині кожної ноги."""
    out = np.repeat(share_index[:, None], shuffles + 1, axis=1)
    for one in np.unique(leg):
        where = np.flatnonzero(leg == one)
        for column in range(1, shuffles + 1):
            out[where, column] = share_index[rng.permutation(where)]
    return out


def scores(net: np.ndarray, mask: np.ndarray, share: np.ndarray,
           leg: np.ndarray, shares=SHARES, shuffles: int = SHUFFLES,
           seed: int = SEED, chunk: int = CHUNK) -> dict:
    """Матриця частка × частка, розриви й влучність з підлогою."""
    shares = np.asarray(shares)
    k = len(shares)
    index = np.searchsorted(shares, share)
    total = len(net)
    if len(np.unique(leg)) < 3:
        return {"windows": int(total)}
    z, live = standardize_live(net, mask)
    labels = permutations(leg, index, shuffles, np.random.default_rng(seed))
    variants = labels.shape[1]
    onehot = np.zeros((total, variants * k), dtype=np.float32)
    columns = labels + np.arange(variants)[None, :] * k
    onehot[np.arange(total)[:, None], columns] = 1.0
    # пар на кожну клітинку однакові в усіх перемішуваннях: у нозі
    # переставляються лише її власні частки
    present = np.zeros((leg.max() + 1, k))
    present[leg, index] = 1.0
    size = present.sum(axis=0)
    pairs = np.outer(size, size) - present.T @ present
    sums = np.zeros((variants, k, k))
    best = np.zeros((total, variants), dtype=np.int64)
    for start in range(0, total, chunk):
        part = slice(start, min(start + chunk, total))
        gram = correlations(z, live, part, net.shape[2])
        rows = np.arange(part.start, part.stop)
        gram[leg[rows][:, None] == leg[None, :]] = 0.0
        vote = (gram @ onehot).reshape(len(rows), variants, k)
        mine = onehot[rows].reshape(len(rows), variants, k)
        sums += np.einsum("rva,rvb->vab", mine, vote)
        # своя нога не голосує: з кожної частки мінус вікно своєї ноги
        others = size[None, :] - present[leg[rows]]
        mean = np.divide(vote, others[:, None, :],
                         out=np.full_like(vote, -np.inf),
                         where=others[:, None, :] > 0)
        best[rows] = mean.argmax(axis=2)
    matrix = np.divide(sums, pairs[None], out=np.zeros_like(sums),
                       where=pairs[None] > 0)
    diag = np.einsum("vaa->va", matrix)
    off = (matrix.sum(axis=2) - diag) / (k - 1)
    gap = diag - off
    below, above = shares < 1, shares > 1
    guess = shares[best]
    truth = shares[labels]
    zone = lambda q: np.where(q < FULL[0], 0, np.where(q > FULL[1], 2, 1))
    exact = np.mean(best == labels, axis=0)
    near = np.mean(np.abs(best - labels) <= 1, axis=0)
    zones = np.mean(zone(guess) == zone(truth), axis=0)
    error = np.mean(np.abs(guess - truth), axis=0)

    def with_floor(values, lower=False):
        floor = np.percentile(values[1:], 5 if lower else 95)
        worse = values[1:] <= values[0] if lower else values[1:] >= values[0]
        return {"value": float(values[0]), "floor": float(floor),
                "p": float((1 + np.sum(worse)) / (1 + shuffles))}

    return {"windows": int(total), "legs": int(len(np.unique(leg))),
            "by_share": {f"{q:g}": int(n) for q, n in zip(shares, size)},
            "matrix": matrix[0].round(5).tolist(),
            "gap": {f"{q:g}": with_floor(gap[:, a])
                    for a, q in enumerate(shares)},
            "gap_below": with_floor(gap[:, below].mean(axis=1)),
            "gap_above": with_floor(gap[:, above].mean(axis=1)),
            "gap_all": with_floor(gap.mean(axis=1)),
            "exact": with_floor(exact), "near": with_floor(near),
            "zones": with_floor(zones),
            "error": with_floor(error, lower=True),
            "chance": {"exact": 1 / k}}


def measure(windows: dict, shuffles: int = SHUFFLES) -> dict:
    out = {}
    for group in GROUPS:
        pick = (windows["kind"] == group) if group != "all" else \
            np.ones(len(windows["kind"]), dtype=bool)
        _, leg = np.unique(windows["leg"][pick], return_inverse=True)
        out[group] = scores(windows["net"][pick], windows["mask"][pick],
                            windows["share"][pick], leg, shuffles=shuffles)
    return out


def build(keys: list | None = None, data: Path = DATA,
          root: Path | None = None, shuffles: int = SHUFFLES,
          log=print) -> dict:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    keys = list(keys or [classes30.DEFAULT])
    report = {"shares": list(SHARES), "full": list(FULL), "rows": ROWS,
              "min_colive": MIN_COLIVE, "shuffles": shuffles, "seed": SEED,
              "groups": list(GROUPS), "parts": list(PARTS), "classes": {}}
    for key in keys:
        one = classes30.BY_KEY[key]
        report["classes"][key] = {"name": one["name"],
                                  "features": list(one["features"])}
        for part in PARTS:
            windows = build_windows(table, part, key, data, root, log=log)
            np.savez(data / f"windows_{part}_{key}.npz", **windows)
            report["classes"][key][part] = measure(windows, shuffles)
            got = report["classes"][key][part]["all"]
            log(f"{one['name']} {part}: вікон {got.get('windows')}, розрив "
                f"рівних {got['gap_below']['value']:.4f} (підлога "
                f"{got['gap_below']['floor']:.4f}), надлишків "
                f"{got['gap_above']['value']:.4f} (підлога "
                f"{got['gap_above']['floor']:.4f}), точна частка "
                f"{got['exact']['value']:.3f} (підлога "
                f"{got['exact']['floor']:.3f})")
            del windows
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--classes", nargs="+", default=None)
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--root", type=Path, default=None,
                        help="тека посекундної робочої копії")
    parser.add_argument("--shuffles", type=int, default=SHUFFLES)
    parser.add_argument("--out", type=Path,
                        default=RESULTS / "windows30.json")
    args = parser.parse_args()
    report = build(args.classes, args.data, args.root, args.shuffles)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=1))
    print(args.out)


if __name__ == "__main__":
    main()
