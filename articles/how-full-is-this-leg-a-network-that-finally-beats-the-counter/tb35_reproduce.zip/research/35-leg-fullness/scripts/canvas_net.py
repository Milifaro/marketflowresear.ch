"""Мережа на канві ноги: чи нога повна і наскільки.

Дослідження: research/35-leg-fullness/
Правила: rules/03-models.md → Розбиття по часу, Навчання без свопа

## Вхід

Канва [`canvas_data.py`](canvas_data.py): сформована частина ноги,
підігнана під `ROWS × 9 × 7` — усі числа класу, без згорток у середні.
Плюс маска живих рядків і пʼять скалярів (скільки подій, крок канви,
пройдений рух, підтверджених корекцій позаду, частка живих рядків).

## Мережа

    (63 канали + маска) -> 4 блоки згортки зі stride 2 -> 32 кроки
                        -> 2 шари уваги на 4 голови
                        -> увага-пулінг -> вектор 128
                        -> разом зі скалярами -> дві голови

Голови: `повна` (логіт) і `частка` (сигмоїда). Згортка з увагою, а не
щільний шар: вагів на 500 × 63 входів у нас немає — ніг у train 603.

## Контроль «хвіст»

`--tail N` лишає в канві тільки останні `N` рядків, решта йде маскою.
Якщо повна канва не бʼє хвіст, форма ноги не несе нічого — і це теж
результат.

## Розбиття

Прикладів на ногу багато (один позитив і `cuts` обривів), тому
відкладений шматок ріжеться **по ногах**, а не по прикладах: інакше
префікси тієї самої ноги стоять по обидва боки розбиття. Епоха й поріг
беруться з відкладеного шматка train, val лишається незайманим до
останнього заміру (`rules/03-models.md`).

Запуск:
    python3 research/35-leg-fullness/scripts/canvas_net.py
    python3 research/35-leg-fullness/scripts/canvas_net.py --tail 16 \\
        --tag tail
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
for extra in (PROJECT_ROOT / "rules" / "scripts",
              PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts",
              Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from leg_end_train import no_swap  # noqa: E402

DATA = RESEARCH_DIR / "data"
RESULTS = RESEARCH_DIR / "results"
ROWS = 500
SEED = 0
HOLDOUT = 0.2              # яка частка ніг train іде у відкладений шматок
EPOCHS = 24
BATCH = 48
LR = 1e-3
WIDTH = 128                # ширина стовбура
HEADS = 4
SHARE = 1.0                # вага голови «частка» у втраті
# Канва читається memmap, тому в памʼяті лежить батч, а не датасет:
# 48 прикладів × 500 × 63 — це 6 МБ. Межа з запасом на ваги й пристрій.
MEMORY_NEED = 900


def device_of(name: str = "auto") -> torch.device:
    if name != "auto":
        return torch.device(name)
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load(folder: Path, part: str) -> dict:
    """Канви однієї частини разом із підписами прикладів.

    Сама канва читається **memmap**: у памʼяті лежить тільки батч, а не
    всі 494 МБ (rules/03-models.md → Навчання без свопа).
    """
    with np.load(folder / f"{part}.npz") as store:
        data = {key: store[key] for key in store.files}
    data["x"] = np.load(folder / f"{part}_x.npy", mmap_mode="r")
    data["notes"] = json.loads((folder / f"{part}_notes.json").read_text())
    return data


def scalars_of(raw: np.ndarray) -> np.ndarray:
    """Скаляри в шкалі, придатній для мережі: довжини — логарифмом."""
    events, step, move, seen, filled = raw.T
    return np.stack([np.log1p(events) / 8.0, np.log1p(step) / 8.0,
                     move * 10.0, seen / 10.0, filled], axis=1)


class Canvas(nn.Module):
    """Згортка зі stride 2, увага поверх неї, дві голови."""

    def __init__(self, channels: int, scalars: int, width: int = WIDTH,
                 heads: int = HEADS):
        super().__init__()
        sizes = [channels + 1, 64, 96, width, width]
        self.trunk = nn.Sequential(*[
            layer for number in range(4) for layer in (
                nn.Conv1d(sizes[number], sizes[number + 1], 5, stride=2,
                          padding=2),
                nn.GroupNorm(8, sizes[number + 1]),
                nn.GELU())])
        block = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=2 * width,
            dropout=0.0, batch_first=True, norm_first=True)
        self.attention = nn.TransformerEncoder(block, num_layers=2)
        self.query = nn.Parameter(torch.randn(1, 1, width) * 0.02)
        self.pool = nn.MultiheadAttention(width, heads, batch_first=True)
        self.head = nn.Sequential(nn.Linear(width + scalars, 64), nn.GELU(),
                                  nn.Linear(64, 2))

    def forward(self, x, mask, numbers):
        # x: (B, rows, channels), mask: (B, rows), numbers: (B, scalars)
        joined = torch.cat([x, mask.unsqueeze(2)], dim=2)
        trunk = self.trunk(joined.transpose(1, 2)).transpose(1, 2)
        seen = self.attention(trunk)
        query = self.query.expand(seen.shape[0], -1, -1)
        vector, _ = self.pool(query, seen, seen)
        out = self.head(torch.cat([vector.squeeze(1), numbers], dim=1))
        return out[:, 0], torch.sigmoid(out[:, 1])


def batches(count: int, size: int, rng, shuffle: bool = True):
    order = rng.permutation(count) if shuffle else np.arange(count)
    for start in range(0, count, size):
        yield order[start:start + size]


def feed(data: dict, index: np.ndarray, device, tail: int = 0) -> tuple:
    """Батч на пристрій: канва, маска, скаляри, мітки."""
    x = torch.from_numpy(
        data["x"][index].astype(np.float32).reshape(len(index), ROWS, -1))
    mask = torch.from_numpy(data["mask"][index].astype(np.float32))
    if tail:
        keep = torch.zeros_like(mask)
        keep[:, -tail:] = 1.0
        mask = mask * keep
        x = x * mask.unsqueeze(2)
    numbers = torch.from_numpy(scalars_of(data["scalars"][index]))
    y = torch.from_numpy(data["y"][index])
    return (x.to(device), mask.to(device), numbers.to(device), y.to(device))


def auc(score: np.ndarray, truth: np.ndarray) -> float:
    """AUC: чи стоїть позитив вище за негатив."""
    truth = truth.astype(bool)
    if not truth.any() or truth.all():
        return float("nan")
    order = np.argsort(score, kind="stable")
    ranks = np.empty(len(score), dtype=float)
    ranks[order] = np.arange(1, len(score) + 1)
    values = score[order]
    start = 0
    for stop in range(1, len(values) + 1):
        if stop == len(values) or values[stop] != values[start]:
            ranks[order[start:stop]] = ranks[order[start:stop]].mean()
            start = stop
    left = int(truth.sum())
    total = ranks[truth].sum()
    return float((total - left * (left + 1) / 2) / (left * (len(score) - left)))


def spearman_in_legs(share: np.ndarray, truth: np.ndarray,
                     legs: np.ndarray) -> float:
    """Спірмен усередині кожної ноги, середнє по ногах."""
    out = []
    for name in np.unique(legs):
        pick = legs == name
        if pick.sum() < 4:
            continue
        left = np.argsort(np.argsort(share[pick])).astype(float)
        right = np.argsort(np.argsort(truth[pick])).astype(float)
        left -= left.mean()
        right -= right.mean()
        bottom = np.sqrt((left ** 2).sum() * (right ** 2).sum())
        if bottom:
            out.append(float((left * right).sum() / bottom))
    return float(np.mean(out)) if out else float("nan")


def measure(score: np.ndarray, share: np.ndarray, data: dict,
            index: np.ndarray, median: float) -> dict:
    """Числа одного шматка: повнота, частка і базові рівні поруч."""
    notes = [data["notes"][number] for number in index]
    y = data["y"][index]
    complete, truth = y[:, 0], y[:, 1]
    kind = np.array([note["cut"] for note in notes])
    legs = np.array([f"{note['pair']}·{note['leg']}" for note in notes])
    events = data["scalars"][index][:, 0]
    counter = np.clip(events / median, 0, 1)

    def pair(name: str) -> float:
        pick = (complete == 1) | (kind == name)
        return auc(score[pick], complete[pick])

    return {
        "examples": int(len(index)), "legs": int(len(np.unique(legs))),
        "complete": int(complete.sum()),
        "auc_complete": auc(score, complete),
        "auc_hard": pair("корекція"), "auc_easy": pair("випадкова"),
        "auc_counter": auc(counter, complete),
        "share_mae": float(np.abs(share - truth).mean()),
        "share_mae_counter": float(np.abs(counter - truth).mean()),
        "share_mae_const": float(np.abs(0.5 - truth).mean()),
        "share_spearman": spearman_in_legs(share, truth, legs),
        "share_spearman_counter": spearman_in_legs(counter, truth, legs),
        "auc_last_tenth": auc(share, (truth >= 0.9).astype(float)),
        "auc_last_tenth_counter": auc(counter, (truth >= 0.9).astype(float)),
    }


def predict(model, data: dict, index: np.ndarray, device, tail: int,
            batch: int = 128) -> tuple:
    model.eval()
    scores, shares = [], []
    with torch.no_grad():
        for piece in batches(len(index), batch, np.random.default_rng(0),
                             shuffle=False):
            x, mask, numbers, _ = feed(data, index[piece], device, tail)
            logit, share = model(x, mask, numbers)
            scores.append(logit.float().cpu().numpy())
            shares.append(share.float().cpu().numpy())
    return np.concatenate(scores), np.concatenate(shares)


def leg_split(data: dict, share: float, seed: int) -> tuple:
    """Відкладений шматок train ріжеться по ногах, не по прикладах."""
    names = np.array([f"{note['pair']}·{note['leg']}"
                      for note in data["notes"]])
    unique = np.unique(names)
    rng = np.random.default_rng(seed)
    held = set(rng.choice(unique, size=max(int(len(unique) * share), 1),
                          replace=False).tolist())
    keep = np.array([name not in held for name in names])
    return np.where(keep)[0], np.where(~keep)[0]


def train(folder: Path, tail: int, epochs: int, batch: int, lr: float,
          seed: int, device, log=print) -> dict:
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    data = {part: load(folder, part) for part in ("train", "val")}
    inside, held = leg_split(data["train"], HOLDOUT, seed)
    median = float(np.median([note["length"] for note in data["train"]["notes"]
                              if note["cut"] == "кінець"]))
    channels = data["train"]["x"].shape[2] * data["train"]["x"].shape[3]
    model = Canvas(channels, 5).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    weight = torch.tensor(
        [(data["train"]["y"][inside, 0] == 0).sum()
         / max((data["train"]["y"][inside, 0] == 1).sum(), 1)],
        dtype=torch.float32, device=device)
    bce = nn.BCEWithLogitsLoss(pos_weight=weight)
    history, best = [], None
    for epoch in range(1, epochs + 1):
        model.train()
        started, total = time.time(), 0.0
        for piece in batches(len(inside), batch, rng):
            x, mask, numbers, y = feed(data["train"], inside[piece], device,
                                       tail)
            logit, share = model(x, mask, numbers)
            loss = bce(logit, y[:, 0]) + SHARE * ((share - y[:, 1]) ** 2).mean()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total += float(loss.detach()) * len(piece)
        score, share = predict(model, data["train"], held, device, tail)
        step = measure(score, share, data["train"], held, median)
        step.update({"epoch": epoch, "loss": total / len(inside),
                     "seconds": round(time.time() - started, 1)})
        history.append(step)
        log(f"епоха {epoch:2d}: втрата {step['loss']:.4f}, "
            f"відкладені AUC {step['auc_complete']:.3f} "
            f"(важкі {step['auc_hard']:.3f}), "
            f"частка MAE {step['share_mae']:.3f}, {step['seconds']} c")
        if best is None or step["auc_complete"] > best["auc_complete"]:
            best = step
            torch.save(model.state_dict(), folder / f"best_{tail}.pt")
    model.load_state_dict(torch.load(folder / f"best_{tail}.pt"))
    out = {"epochs": history, "best_epoch": best["epoch"], "median": median,
           "tail": tail, "seed": seed}
    for name, part, index in (("train", "train", inside),
                              ("holdout", "train", held),
                              ("val", "val",
                               np.arange(len(data["val"]["y"])))):
        score, share = predict(model, data[part], index, device, tail)
        out[name] = measure(score, share, data[part], index, median)
        if name == "val":
            out["val_series"] = [
                {"pair": note["pair"], "leg": note["leg"], "cut": note["cut"],
                 "events": note["events"], "length": note["length"],
                 "true": float(data["val"]["y"][number, 1]),
                 "complete": float(data["val"]["y"][number, 0]),
                 "score": float(score[position]),
                 "share": float(share[position])}
                for position, number in enumerate(index)
                for note in [data["val"]["notes"][number]]]
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--folder", type=Path, default=DATA / f"canvas_{ROWS}")
    parser.add_argument("--tail", type=int, default=0,
                        help="лишити в канві тільки останні N рядків")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--batch", type=int, default=BATCH)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--tag", default="canvas")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    no_swap(MEMORY_NEED, args.force)
    device = device_of(args.device)
    print(f"пристрій {device}, канва {args.folder.name}, хвіст {args.tail}")
    out = train(args.folder, args.tail, args.epochs, args.batch, args.lr,
                args.seed, device)
    out["tag"] = args.tag
    path = args.out or RESULTS / f"{args.tag}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, ensure_ascii=False, indent=1))
    for name in ("train", "holdout", "val"):
        one = out[name]
        print(f"[{name}] ніг {one['legs']}, прикладів {one['examples']}: "
              f"AUC повноти {one['auc_complete']:.3f} "
              f"(важкі {one['auc_hard']:.3f}, легкі {one['auc_easy']:.3f}, "
              f"лічильник {one['auc_counter']:.3f}), "
              f"частка MAE {one['share_mae']:.3f} проти "
              f"{one['share_mae_counter']:.3f} у лічильника")
    print(path)


if __name__ == "__main__":
    main()
