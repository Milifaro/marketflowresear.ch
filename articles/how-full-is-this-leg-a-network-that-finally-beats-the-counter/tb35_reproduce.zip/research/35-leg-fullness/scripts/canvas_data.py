"""Канва ноги: неповна нога цілком, підігнана під сталу матрицю.

Дослідження: research/35-leg-fullness/
Клас: `клас210х10-1х7д/д` (`class210x10m1x7dd`)
Правила: rules/01-data-and-db.md → Класи, rules/02-markup.md

## Що це

Сформована частина ноги — від підтвердженого півота до поточної
події — подається мережі **цілком**, усіма своїми числами, а не
згорткою в середні. Щоб матриця була сталою, нога перераховується на
свій крок:

    префікс ноги: n подій, це n · 210 секунд
    канва: ROWS рядків, крок рядка s = n · 210 / ROWS секунд
    блок = s / 10 секунд, як і в звичайній події

`n > ROWS` — рядок покриває **більше** секунд за звичайну подію
(нога стискається), `n < ROWS` — менше (нога роздувається). Кількість
фіч не міняється: ті самі 9 блоків × 7 фіч класу, тільки пораховані на
своєму кроці. Нічого не інтерполюється: кожен рядок — справжня подія
класу, зібрана з посекундних даних `data/`.

## Межа роздування

Блок коротший за `MIN_BLOCK` секунд не має сенсу: у ньому просто немає
секунд, і похідна виродиться. Тому крок знизу обмежений, а префікс, для
якого й цього замало, лягає в **хвіст** канви, а початок іде маскою.

## Причинність

У канві немає нічого, крім секунд, які вже пройшли. Розмітка (де
справжній кінець ноги) у входи не заходить — вона лише мітка. Краї
корекцій 0.8 беруться тільки для **вибору точок обриву** префікса, а не
як канал.

## Мітка

    complete = 1, якщо префікс закінчується на справжньому кінці ноги
    share    = (e − first) / (last − first) — яку частку ноги пройдено

Запуск:
    python3 research/35-leg-fullness/scripts/canvas_data.py
    python3 research/35-leg-fullness/scripts/canvas_data.py --pairs BTC_USDT \
        --rows 500 --cuts 16

Вихід: data/canvas_<rows>/<part>.npz — канви (float16), маски, скаляри,
мітки й підпис кожного прикладу.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RULES_SCRIPTS = PROJECT_ROOT / "rules" / "scripts"
for extra in (RULES_SCRIPTS, Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

import roles  # noqa: E402
from build_class210x10x7dc import PAIRS, PARTS  # noqa: E402
from class210x10x9 import FEATURES as RAW_FEATURES  # noqa: E402
from class210x10m1x7dd import FEATURES  # noqa: E402

WORK = PROJECT_ROOT / "data"
DATA = RESEARCH_DIR / "data"

ROWS = 500                 # рядків у канві
BLOCKS = 10                # блоків у рядку — як у звичайній події
STEP = 210                 # секунд на подію сітки класу
MIN_BLOCK = 3              # коротший блок не будується: секунд у ньому немає
CUTS = 16                  # скільки обривів (негативів) береться на ногу
HOLE = 60                  # пропуск, з якого блок вважається дірявим
FILL = 0.5                 # частка присутніх секунд, з якої блок живий
SEED = 0

# Сирі колонки, з яких збирається рядок канви: ті самі 9 фіч клас210х10х9.
RAW = list(RAW_FEATURES)


def day_paths(pair: str, first: int, last: int,
              root: Path | None = None) -> list:
    """Файли робочої копії, що покривають відрізок часу."""
    days = pd.date_range(pd.to_datetime(first, unit="s", utc=True).floor("D"),
                         pd.to_datetime(last, unit="s", utc=True).floor("D"),
                         freq="D")
    out = []
    for day in days:
        path = ((root or WORK) / f"{day.year:04d}" / f"{day.month:02d}"
                / pair / f"1S_{day.strftime('%Y-%m-%d')}_{pair}.csv")
        if path.exists():
            out.append(path)
    return out


class Seconds:
    """Посекундний відрізок монети з кумулятивними сумами.

    Кумулятивна сума дає суму будь-якого блоку двома звертаннями, тому
    канва будь-якого кроку збирається без проходу по секундах.
    """

    def __init__(self, first: int, last: int):
        self.first = int(first)
        self.last = int(last)
        span = self.last - self.first + 1
        self.sums = np.zeros((len(RAW), span + 1), dtype=np.float64)
        self.count = np.zeros(span + 1, dtype=np.int32)

    def put(self, frame: pd.DataFrame) -> None:
        """Секунди одного файлу лягають на свої місця."""
        stamps = frame["timestamp"].to_numpy(dtype=np.int64)
        keep = (stamps >= self.first) & (stamps <= self.last)
        if not keep.any():
            return
        index = stamps[keep] - self.first
        for number, name in enumerate(RAW):
            values = frame[name].to_numpy(dtype=np.float64)[keep]
            self.sums[number, index + 1] += np.nan_to_num(values)
        self.count[index + 1] += 1

    def close(self) -> None:
        """Кумулятивні суми — після того, як усі файли лягли."""
        self.sums = np.cumsum(self.sums, axis=1)
        self.count = np.cumsum(self.count)

    def blocks(self, edges: np.ndarray) -> tuple:
        """Суми й кількість секунд у кожному блоці за межами `edges`."""
        index = np.clip(edges - self.first, 0, len(self.count) - 1)
        counts = np.diff(self.count[index])
        sums = np.diff(self.sums[:, index], axis=1)
        return sums, counts


# Доба, вже прочитана з робочої копії. Ноги йдуть по порядку, тому
# сусідні беруть ті самі файли — без кешу вони читались би заново.
DAYS: dict = {}
DAYS_KEEP = 14


def read_day(path: Path) -> pd.DataFrame:
    """Доба робочої копії: тільки потрібні колонки, з кешем на `DAYS_KEEP`."""
    key = str(path)
    frame = DAYS.pop(key, None)
    if frame is None:
        frame = pd.read_csv(path, usecols=["timestamp"] + RAW)
    DAYS[key] = frame
    while len(DAYS) > DAYS_KEEP:
        DAYS.pop(next(iter(DAYS)))
    return frame


def read_seconds(pair: str, first: int, last: int,
                 root: Path | None = None) -> Seconds | None:
    """Посекундний відрізок із робочої копії. Немає файлів — немає канви."""
    paths = day_paths(pair, first, last, root)
    if not paths:
        return None
    holder = Seconds(first, last)
    for path in paths:
        holder.put(read_day(path))
    holder.close()
    return holder


def edges_of(first: int, last: int, rows: int = ROWS,
             blocks: int = BLOCKS) -> np.ndarray:
    """Межі блоків канви: `rows × blocks` рівних шматків відрізка."""
    return np.linspace(first, last + 1, rows * blocks + 1).astype(np.int64)


def levels(sums: np.ndarray, counts: np.ndarray) -> np.ndarray:
    """Блок сирих сум → сім фіч `клас210х10х7`.

    Ділення рівня на обʼєм свого блоку не залежить від довжини блоку:
    і чисельник, і знаменник — середні по тих самих секундах.
    """
    live = counts > 0
    means = np.zeros((len(RAW), len(counts)))
    means[:, live] = sums[:, live] / counts[live]
    take = {name: means[number] for number, name in enumerate(RAW)}
    with np.errstate(invalid="ignore", divide="ignore"):
        out = np.stack([
            np.where(take["vol_buy"] != 0,
                     take["const_resist"] / take["vol_buy"], np.nan),
            np.where(take["vol_buy"] != 0,
                     (take["resist_plus"] - take["resist_minus"])
                     / take["vol_buy"], np.nan),
            np.where(take["vol_sell"] != 0,
                     take["const_support"] / take["vol_sell"], np.nan),
            np.where(take["vol_sell"] != 0,
                     (take["support_plus"] - take["support_minus"])
                     / take["vol_sell"], np.nan),
            take["vol_buy"], take["vol_sell"], take["price_avg"]])
    out[:, ~live] = np.nan
    return out


def ratios(plates: np.ndarray) -> np.ndarray:
    """Девʼять похідних по блоках → сім фіч `клас210х10-1х7д/д`.

    `plates` — `(7, rows, blocks)`. Перша плашка кожного рядка йде на
    похідну і в клас не потрапляє: це і є `10-1`.
    """
    step = np.diff(plates, axis=2)                 # (7, rows, blocks - 1)
    name = {title: number for number, title
            in enumerate(["resist", "bal_resist", "support", "bal_support",
                          "vol_buy", "vol_sell", "price_avg"])}

    def over(top: str, bottom: str) -> np.ndarray:
        with np.errstate(invalid="ignore", divide="ignore"):
            low = step[name[bottom]]
            return np.where(low != 0, step[name[top]] / low, np.nan)

    out = np.stack([over("vol_buy", "resist"), over("vol_sell", "support"),
                    over("resist", "vol_buy"), over("bal_resist", "vol_buy"),
                    over("support", "vol_sell"),
                    over("bal_support", "vol_sell"),
                    step[name["price_avg"]]])
    return np.moveaxis(out, 0, 2)                  # (rows, blocks - 1, 7)


def canvas(holder: Seconds, first: int, last: int, rows: int = ROWS,
           blocks: int = BLOCKS) -> tuple:
    """Відрізок часу → канва `(rows, 9, 7)` і маска живих рядків."""
    edges = edges_of(first, last, rows, blocks)
    sums, counts = holder.blocks(edges)
    plates = levels(sums, counts).reshape(7, rows, blocks)
    x = ratios(plates)
    length = np.diff(edges).reshape(rows, blocks)
    alive = (counts.reshape(rows, blocks) >= np.maximum(length * FILL, 1))
    mask = alive.all(axis=1)
    x[~mask] = 0.0
    return x.astype(np.float32), mask


def padded(holder: Seconds, first: int, last: int, rows: int,
           blocks: int, min_block: int) -> tuple:
    """Канва з межею роздування: закороткий префікс лягає у хвіст.

    Поки на рядок припадає менше за `min_block · blocks` секунд, крок
    тримається на цій межі, канва будується коротшою й стає **хвостом**
    матриці, а початок лишається порожнім під маскою.
    """
    span = last - first + 1
    least = min_block * blocks
    fit = min(rows, max(int(span // least), 1))
    if fit == rows:
        return canvas(holder, first, last, rows, blocks) + (rows,)
    piece, alive = canvas(holder, first, last, fit, blocks)
    x = np.zeros((rows, piece.shape[1], piece.shape[2]), dtype=np.float32)
    mask = np.zeros(rows, dtype=bool)
    x[rows - fit:] = piece
    mask[rows - fit:] = alive
    return x, mask, fit


def cut_points(leg: dict, marks: list, cuts: int, rng) -> list:
    """Де обривати ногу: спершу краї корекцій, потім випадкові точки.

    Край корекції — найважчий негатив: етап 1 показав, що підпис там
    той самий, що на справжньому кінці ноги, тільки слабший.
    """
    first, last = leg["first"], leg["last"]
    hard = [pivot["index"] for pivot in marks if first < pivot["index"] < last]
    rng.shuffle(hard)
    picked = hard[:cuts]
    room = [step for step in range(first + 1, last)
            if step not in set(picked)]
    if room and len(picked) < cuts:
        extra = rng.choice(room, size=min(cuts - len(picked), len(room)),
                           replace=False)
        picked += [int(step) for step in extra]
    kinds = ["корекція"] * min(len(hard), cuts) \
        + ["випадкова"] * (len(picked) - min(len(hard), cuts))
    return list(zip(picked, kinds))


def confirmed(marks: list, smooth: np.ndarray, end: int,
              threshold: float = roles.INNER_THRESHOLD,
              span: int = roles.SNAP_SPAN) -> int:
    """Скільки корекцій **видно** на події `end` — тільки підтверджені.

    Півот 0.8 стає півотом лише тоді, коли ема відійшла від нього на
    0.8 %, а його точна позиція (`snap`) відома ще через `span` подій.
    Тому корекція йде в лік, коли обидва вікна вже в минулому:

        підтвердження(p) = перша c > p, де |ема[c] / ема[p] − 1| ≥ 0.8 %
        видно на e, якщо  c ≤ e  і  p + span ≤ e

    Рахувати за самою позицією півота (`p ≤ e`) — це заглядання вперед.
    """
    count = 0
    for pivot in marks:
        index = pivot["index"]
        if index + span > end:
            continue
        piece = smooth[index + 1:end + 1]
        if len(piece) and (np.abs(piece / smooth[index] - 1) >= threshold).any():
            count += 1
    return count


def build_pair(pair: str, part: str, rows: int, cuts: int, blocks: int,
               min_block: int, rng, root: Path | None = None,
               work: Path | None = None) -> dict:
    """Канви всіх прикладів однієї монети однієї частини."""
    row = roles.load(pair, part, root)
    legs, smooth = roles.legs_of(row)
    canvases, masks, scalars, labels, notes = [], [], [], [], []
    skipped = 0
    for number, leg in enumerate(legs, start=1):
        first, last = leg["first"], leg["last"]
        marks = roles.corrections(leg, smooth, row["close"])
        holder = read_seconds(pair, int(row["t"][first]),
                              int(row["t"][last]) + STEP - 1, work)
        if holder is None:
            skipped += 1
            continue
        points = [(last, "кінець")] + cut_points(leg, marks, cuts, rng)
        for end, kind in points:
            x, mask, fit = padded(holder, int(row["t"][first]),
                                  int(row["t"][end]) + STEP - 1,
                                  rows, blocks, min_block)
            events = end - first + 1
            seen = confirmed(marks, smooth, end)
            move = float(np.log(row["close"][end] / row["open"][first]))
            canvases.append(x)
            masks.append(mask)
            scalars.append([events, events * STEP / rows, move, seen,
                            float(mask.sum()) / rows])
            labels.append([1.0 if end == last else 0.0,
                           (end - first) / max(last - first, 1)])
            notes.append({"pair": pair, "part": part, "leg": number,
                          "kind": leg["kind"], "cut": kind,
                          "events": int(events), "length": int(last - first + 1),
                          "t_end": int(row["t"][end]), "fit": int(fit)})
    return {"x": compress(np.asarray(canvases, dtype=np.float32)),
            "mask": np.asarray(masks, dtype=bool),
            "scalars": np.asarray(scalars, dtype=np.float32),
            "y": np.asarray(labels, dtype=np.float32),
            "notes": notes, "legs": len(legs), "skipped": skipped}


def compress(x: np.ndarray) -> np.ndarray:
    """Лог-модуль зі знаком: `sign(v) · log1p(|v|)`, у `float16`.

    Фіча класу — відношення похідних, і в ряді трапляються значення до
    `1e21`: у `float16` вони перетворюються на нескінченність, а в
    `float32` забирають удвічі більше памʼяті. Логарифм модуля лишає
    і знак, і порядок (перетворення строго зростає), а найбільше число
    датасету стає меншим за 50. `NaN` — нульовий знаменник — лягає
    нулем: руху не було.
    """
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return (np.sign(clean) * np.log1p(np.abs(clean))).astype(np.float16)


def scales_of(x: np.ndarray, mask: np.ndarray, steps: np.ndarray,
              buckets: int = 12) -> dict:
    """Одиниця каналу на кожен кошик кроку: 99-й перцентиль |v| на train.

    Крок міняє величину похідної, тому один спільний масштаб склеїв би
    короткі ноги з довгими. Кошики — рівні за логарифмом кроку. Числа
    вже стиснуті `compress`, тому це одиниця в лог-шкалі.
    """
    edges = np.quantile(np.log(steps), np.linspace(0, 1, buckets + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    table = []
    for low, high in zip(edges[:-1], edges[1:]):
        pick = (np.log(steps) >= low) & (np.log(steps) < high)
        if not pick.any():
            table.append(np.ones(x.shape[2] * x.shape[3]))
            continue
        piece = x[pick][mask[pick]].astype(np.float32)
        piece = piece.reshape(-1, x.shape[2] * x.shape[3])
        good = np.where(np.isfinite(piece), np.abs(piece), np.nan)
        scale = np.nanpercentile(good, 99, axis=0)
        table.append(np.where(np.isfinite(scale) & (scale > 0), scale, 1.0))
    return {"edges": edges.tolist(), "scale": np.asarray(table, dtype=float)}


def normalize(x: np.ndarray, steps: np.ndarray, scales: dict) -> np.ndarray:
    """Лог-модуль ділиться на одиницю свого кошика кроку.

    Ділення в лог-шкалі не міняє порядку значень усередині каналу, але
    ставить канали одного кошика в одну шкалу — і прибирає зсув, який
    дає сам крок канви: похідна за 23 секунди більша за похідну за 17.
    """
    edges = np.asarray(scales["edges"])
    scale = np.asarray(scales["scale"])
    slot = np.clip(np.searchsorted(edges, np.log(steps), side="right") - 1,
                   0, len(scale) - 1)
    flat = np.nan_to_num(x.reshape(x.shape[0], x.shape[1], -1)
                         .astype(np.float32))
    return (flat / scale[slot][:, None, :]).reshape(x.shape).astype(np.float16)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--rows", type=int, default=ROWS)
    parser.add_argument("--cuts", type=int, default=CUTS)
    parser.add_argument("--blocks", type=int, default=BLOCKS)
    parser.add_argument("--min-block", type=int, default=MIN_BLOCK)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--root", type=Path, default=None,
                        help="тека датасетів класу")
    parser.add_argument("--work", type=Path, default=None,
                        help="тека посекундної робочої копії")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    out = args.out or DATA / f"canvas_{args.rows}"
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    built, report = {}, {"rows": args.rows, "blocks": args.blocks,
                         "cuts": args.cuts, "min_block": args.min_block,
                         "seed": args.seed, "features": list(FEATURES),
                         "scalars": ["events", "step", "move", "corrections",
                                     "filled"],
                         "pairs": args.pairs, "parts": list(PARTS)}
    for part in PARTS:
        pieces = [build_pair(pair, part, args.rows, args.cuts, args.blocks,
                             args.min_block, rng, args.root, args.work)
                  for pair in args.pairs]
        built[part] = {
            "x": np.concatenate([one["x"] for one in pieces]),
            "mask": np.concatenate([one["mask"] for one in pieces]),
            "scalars": np.concatenate([one["scalars"] for one in pieces]),
            "y": np.concatenate([one["y"] for one in pieces]),
            "notes": [note for one in pieces for note in one["notes"]]}
        report[part] = {"examples": len(built[part]["y"]),
                        "legs": sum(one["legs"] for one in pieces),
                        "skipped": sum(one["skipped"] for one in pieces),
                        "complete": int(built[part]["y"][:, 0].sum())}
        print(f"[{part}] прикладів {report[part]['examples']}, "
              f"ніг {report[part]['legs']}, "
              f"повних {report[part]['complete']}, "
              f"без сирих даних {report[part]['skipped']}")

    scales = scales_of(built["train"]["x"], built["train"]["mask"],
                       built["train"]["scalars"][:, 1])
    for part, piece in built.items():
        # Канва лягає окремим .npy: так прогін читає її memmap і тримає
        # у памʼяті лише батч (rules/03-models.md → Навчання без свопа).
        np.save(out / f"{part}_x.npy",
                normalize(piece["x"], piece["scalars"][:, 1], scales))
        np.savez(out / f"{part}.npz", mask=piece["mask"],
                 scalars=piece["scalars"], y=piece["y"])
        (out / f"{part}_notes.json").write_text(
            json.dumps(piece["notes"], ensure_ascii=False))
    # Крайні межі кошиків — ±нескінченність; у JSON пишуться тільки
    # внутрішні, щоб файл лишався строгим JSON.
    report["scales"] = {"inner_edges_log_step": scales["edges"][1:-1],
                        "buckets": len(scales["scale"])}
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False,
                                                indent=1))
    print(out)


if __name__ == "__main__":
    main()
