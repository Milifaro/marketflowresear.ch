"""Стандарт 30 с: записи, ноги, фічі ходом клас210х10-1х7д/д і канва 500.

Дослідження: research/35-leg-fullness/ → Етап 3
Правила: rules/01-data-and-db.md → Класи, rules/02-markup.md → Точка кінця ноги

## Хід

1. Секунди робочої копії (стандартний `data_source.load_day`: без `NaN`,
   з дублікатів — перший) сумуються в записи на сітці UTC, кратній
   30 с: суми девʼяти колонок і кількість секунд `n`.
2. Півоти на ряді записів **без ема**: зігзаг 2.3 % прямо по
   `price_open` записів → точка кінця ноги: екстремум `price_close` у
   ±25 записах. Частини ріжуться окремо.
3. Фічі — хід `клас210х10-1х7д/д`, де блоком є запис: середні → рівні на
   обʼєм свого запису → похідна до попереднього запису, лише коли він
   впритул → шість відношень похідних плюс `d_price_avg`.
4. Канва: проміжок ноги — 500 рівних відрізків, відрізок — сума секунд
   (при ≥ 500 записах межі на межах записів), той самий хід → `500 × 7`.

Запуск:
    python3 research/35-leg-fullness/scripts/bars30.py
    python3 research/35-leg-fullness/scripts/bars30.py --pairs BTC_USDT

Вихід: data/bars30/<PAIR>_<part>.npz — записи й фічі; data/bars30/
legs.json — ноги; data/bars30/canvas_<part>.npz — канва кожної ноги;
results/bars30.json — звід для вкладки.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
for extra in (PROJECT_ROOT / "rules" / "scripts",
              Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210x10m1x7dd import FEATURES  # noqa: E402
from class210x10x9 import FEATURES as RAW  # noqa: E402
import classes30  # noqa: E402
from classes30 import LEVELS, over  # noqa: E402
from data_source import load_day  # noqa: E402
from zigzag import OUTER_THRESHOLD, SNAP_SPAN, snap, zigzag  # noqa: E402

WORK = PROJECT_ROOT / "data"
DATA = RESEARCH_DIR / "data" / "bars30"
RESULTS = RESEARCH_DIR / "results"

BAR = 30                       # секунд у записі
ROWS = 500                     # рядків канви
MIN_SLICE = 3                  # коротший відрізок канви не будується
CUT = "2026-08-14"             # межа train | val, UTC
END = "2026-09-22"             # остання повна доба val, UTC
PARTS = ("train", "val")

# Алгоритм пунктами — те, що вкладка показує над графіками. Повний
# промпт — у файлі дослідження, етап 3.
STEPS = [
    "секунди робочої копії читаються стандартно (без NaN, з дублікатів "
    "timestamp лишається перший) і сумуються в записи по 30 с на сітці UTC",
    "півоти на записах без ема: зігзаг 2.3 % прямо по price_open записів → "
    "точка кінця ноги: екстремум price_close у ±25 записах",
    "частини ріжуться окремо: train — до 14.08, val — 14.08 … 22.09",
    "фічі — обраний клас проєкту (18 класів rules/01-data-and-db.md), де "
    "блоком є запис: формули класу ті самі, подією класів з одним блоком "
    "стає запис, ЕМА — по ряду записів, похідна — лише до запису впритул; "
    "нульовий знаменник дає 0",
    "канва: проміжок ноги ділиться на 500 відрізків — від 500 записів межі "
    "на межах записів (стиск), менше — рівні відрізки з секунд (розтяг, не "
    "коротші за 3 с); на відрізках той самий хід класу → 500 × фічі класу",
    "вхід мережі — кожна нога ізольовано, кожен канал окремо: v ділиться "
    "на медіану |v| ненульових живих рядків ноги → sign(v)·log1p(|v|) → "
    "ділиться на 99-й перцентиль |v| живих рядків ноги; маска рядків і "
    "скаляри: записів у нозі, крок відрізка, рух від півота",
]


def day_files(pair: str, first: str, last: str,
              root: Path | None = None) -> list:
    """Доби робочої копії пари між двома датами включно."""
    files = sorted((root or WORK).glob(f"*/*/{pair}/1S_*_{pair}.csv"))
    return [path for path in files
            if first <= path.name.split("_")[1] <= last]


def part_range(part: str, pair: str, root: Path | None = None) -> tuple:
    """Перша й остання доба частини."""
    files = sorted((root or WORK).glob(f"*/*/{pair}/1S_*_{pair}.csv"))
    first = files[0].name.split("_")[1] if files else CUT
    if part == "train":
        last = (pd.Timestamp(CUT) - pd.Timedelta(days=1)).strftime("%Y-%m-%d")
        return first, last
    return CUT, END


def bars_of_frame(frame: pd.DataFrame, bar: int = BAR) -> dict:
    """Секунди однієї доби → записи: суми колонок, `n`, перша й остання
    ціна, сума і сума модулів посекундних змін ціни всередині запису."""
    stamps = frame["timestamp"].to_numpy(dtype=np.int64)
    slot = stamps // bar * bar
    keys, start = np.unique(slot, return_index=True)
    stop = np.append(start[1:], len(slot))
    sums = np.stack([np.add.reduceat(frame[name].to_numpy(dtype=np.float64),
                                     start) for name in RAW])
    price = frame["price_avg"].to_numpy(dtype=np.float64)
    move = np.zeros(len(price))
    if len(price) > 1:
        inside = (np.diff(stamps) == 1) & (np.diff(slot) == 0)
        move[1:] = np.where(inside, np.diff(price), 0.0)
    return {"t": keys, "n": (stop - start).astype(np.int32), "sums": sums,
            "open": price[start], "close": price[stop - 1],
            "net": np.add.reduceat(move, start),
            "absm": np.add.reduceat(np.abs(move), start)}


def read_bars(pair: str, part: str, root: Path | None = None) -> dict:
    """Усі записи частини: доба за добою, стандартне читання секунд."""
    first, last = part_range(part, pair, root)
    pieces = []
    for path in day_files(pair, first, last, root):
        frame, _ = load_day(path)
        if len(frame):
            pieces.append(bars_of_frame(frame))
    return {"t": np.concatenate([one["t"] for one in pieces]),
            "n": np.concatenate([one["n"] for one in pieces]),
            "sums": np.concatenate([one["sums"] for one in pieces], axis=1),
            "open": np.concatenate([one["open"] for one in pieces]),
            "close": np.concatenate([one["close"] for one in pieces]),
            "net": np.concatenate([one["net"] for one in pieces]),
            "absm": np.concatenate([one["absm"] for one in pieces])}


def levels(sums: np.ndarray, counts: np.ndarray) -> np.ndarray:
    """Крок 1–2 класу: середні запису → сім рівнів `клас210х10х7`, `(7, N)`.

    Нульовий обʼєм у знаменнику дає **0**, а не пропуск: там, де 0, так
    і лишається 0 (рішення користувача 2026-09-23).
    """
    return classes30.x10x7({"sums": sums, "n": counts}).T


def derivative(plates: np.ndarray, adjacent: np.ndarray) -> np.ndarray:
    """Крок 3 класу: `d[j] = x[j] − x[j−1]`, лише коли попередній впритул.

    Перший запис і запис після розриву похідної не мають (`NaN`) — це
    `-1` класу: плашки, що тягнеться в чужий відрізок, у класі немає.
    """
    return classes30.derivative(plates.T, adjacent).T


def block_of(sums: np.ndarray, counts: np.ndarray, adjacent: np.ndarray,
             first=None, net=None, absm=None) -> dict:
    """Ряд блоків для `classes30`; ціни немає — нулі."""
    zero = np.zeros(len(counts))
    return {"sums": sums, "n": counts, "adjacent": adjacent,
            "first": zero if first is None else first,
            "net": zero if net is None else net,
            "absm": zero if absm is None else absm}


def chain(sums: np.ndarray, counts: np.ndarray,
          adjacent: np.ndarray) -> np.ndarray:
    """Увесь хід `клас210х10-1х7д/д` на ряді блоків: суми → сім фіч."""
    return classes30.features("x10m1x7dd", block_of(sums, counts, adjacent))


def features_of(bars: dict, key: str = classes30.DEFAULT,
                bar: int = BAR) -> np.ndarray:
    """Фічі класу на кожному записі; впритул — сусід рівно за `bar` с."""
    adjacent = np.zeros(len(bars["t"]), dtype=bool)
    adjacent[1:] = np.diff(bars["t"]) == bar
    return classes30.features(key, block_of(
        bars["sums"], bars["n"], adjacent, bars.get("open"),
        bars.get("net"), bars.get("absm")))


def legs_of(bars: dict, threshold: float = OUTER_THRESHOLD,
            span: int = SNAP_SPAN) -> list:
    """Ноги на записах: зігзаг прямо по ціні запису, без ема, і точка кінця ноги.

    Згладжування тут немає (рішення користувача 2026-09-23): записи 30 с
    — уже самі по собі одиниця ряду.
    """
    pivots = snap(zigzag(bars["open"], threshold), bars["close"], span)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        legs.append({"leg": len(legs) + 1,
                     "kind": "up" if pivot.kind == "high" else "down",
                     "first": int(first), "last": int(last),
                     "bars": int(last - first + 1),
                     "from": int(bars["t"][first]),
                     "to": int(bars["t"][last]) + BAR - 1,
                     "move": float(np.log(bars["close"][last]
                                          / bars["open"][first]))})
    return legs


class Seconds:
    """Посекундні суми відрізка з кумулятивними сумами (як у етапі 2)."""

    def __init__(self, first: int, last: int):
        self.first, self.last = int(first), int(last)
        span = self.last - self.first + 1
        self.sums = np.zeros((len(RAW), span + 1))
        self.count = np.zeros(span + 1, dtype=np.int64)
        self.move = np.zeros(span + 1)
        self.absm = np.zeros(span + 1)

    def put(self, frame: pd.DataFrame) -> None:
        stamps = frame["timestamp"].to_numpy(dtype=np.int64)
        keep = (stamps >= self.first) & (stamps <= self.last)
        index = stamps[keep] - self.first + 1
        for number, name in enumerate(RAW):
            self.sums[number, index] = frame[name].to_numpy(dtype=np.float64)[keep]
        self.count[index] = 1

    def close(self) -> None:
        # Зміна ціни стоїть на пізнішій секунді пари сусідніх секунд.
        price = self.sums[RAW.index("price_avg")]
        present = self.count > 0
        step = np.zeros(len(price))
        pair = present[1:] & present[:-1]
        step[1:][pair] = np.diff(price)[pair]
        self.price, self.present = price.copy(), present.copy()
        self.sums = np.cumsum(self.sums, axis=1)
        self.count = np.cumsum(self.count)
        self.move = np.cumsum(step)
        self.absm = np.cumsum(np.abs(step))

    def slices(self, edges: np.ndarray) -> tuple:
        index = np.clip(edges - self.first, 0, len(self.count) - 1)
        return np.diff(self.sums[:, index], axis=1), np.diff(self.count[index])

    def block(self, edges: np.ndarray) -> dict:
        """Ряд відрізків `[edges[i], edges[i+1])` для `classes30`."""
        sums, counts = self.slices(edges)
        index = np.clip(edges - self.first, 0, len(self.count) - 1)
        # зміни всередині відрізка — без зміни на його першій секунді
        inner = np.clip(index[:-1] + 1, 0, len(self.count) - 1)
        net = self.move[index[1:]] - self.move[inner]
        absm = self.absm[index[1:]] - self.absm[inner]
        where = np.flatnonzero(self.present)
        found = np.searchsorted(where, index[:-1] + 1)
        first = self.price[where[np.clip(found, 0, max(len(where) - 1, 0))]] \
            if len(where) else np.zeros(len(counts))
        adjacent = np.ones(len(counts), dtype=bool)
        adjacent[0] = False
        adjacent[1:] &= (counts[1:] > 0) & (counts[:-1] > 0)
        return {"sums": sums, "n": counts, "adjacent": adjacent,
                "first": np.where(counts > 0, first, 0.0), "net": net,
                "absm": absm}


def read_seconds(pair: str, first: int, last: int, cache: dict,
                 root: Path | None = None) -> Seconds:
    """Секунди проміжку; доби читаються стандартно і тримаються в кеші."""
    holder = Seconds(first, last)
    days = pd.date_range(pd.to_datetime(first, unit="s").floor("D"),
                         pd.to_datetime(last, unit="s").floor("D"), freq="D")
    for day in days:
        name = day.strftime("%Y-%m-%d")
        if name not in cache:
            found = day_files(pair, name, name, root)
            cache[name] = load_day(found[0])[0] if found else None
            while len(cache) > 6:
                cache.pop(next(iter(cache)))
        if cache[name] is not None:
            holder.put(cache[name])
    holder.close()
    return holder


def edges_of(stamps: np.ndarray, last: int, rows: int = ROWS,
             min_slice: int = MIN_SLICE) -> tuple:
    """Межі відрізків канви і скільки рядків реально будується.

    `stamps` — початки записів ноги. Записів ≥ `rows` — межі стають на
    початки записів (стиск цілими записами; розрив у ряді лишається
    всередині свого відрізка). Менше — проміжок ноги ділиться на рівні
    часові відрізки з секунд (розтяг), не коротші за `min_slice` с;
    тоді рядків може бути менше, і вони йдуть у хвіст канви.
    """
    first = int(stamps[0])
    if len(stamps) >= rows:
        cells = np.round(np.linspace(0, len(stamps), rows + 1)).astype(np.int64)
        return np.append(stamps[cells[:-1]], last + 1).astype(np.int64), rows
    span = last - first + 1
    fit = int(min(rows, max(span // min_slice, 1)))
    return np.linspace(first, last + 1, fit + 1).astype(np.int64), fit


def canvas_blocks(holder: Seconds, stamps: np.ndarray, last: int,
                  rows: int = ROWS) -> tuple:
    """Відрізки канви ноги: ряд блоків, скільки рядків живе, середній відрізок."""
    edges, fit = edges_of(stamps, last, rows)
    return holder.block(edges), fit, float((last - int(stamps[0]) + 1) / fit)


def place(piece: np.ndarray, block: dict, rows: int = ROWS) -> tuple:
    """Фічі відрізків → канва `rows × F` і маска; короткі — у хвіст.

    Рядок живий, коли у відрізку є секунди і клас дав хоча б одне
    значення; мертвий рядок — нулі."""
    fit = len(piece)
    x = np.zeros((rows, piece.shape[1]), dtype=np.float32)
    mask = np.zeros(rows, dtype=bool)
    live = (block["n"] > 0) & np.isfinite(piece).any(axis=1)
    x[rows - fit:] = np.nan_to_num(piece, nan=0.0, posinf=0.0, neginf=0.0)
    mask[rows - fit:] = live
    x[~mask] = 0.0
    return x, mask


def canvas_of(holder: Seconds, stamps: np.ndarray, last: int,
              rows: int = ROWS, key: str = classes30.DEFAULT) -> tuple:
    """Канва ноги одного класу: `rows × F`, маска живих рядків, відрізок, с."""
    block, _, step = canvas_blocks(holder, stamps, last, rows)
    x, mask = place(classes30.features(key, block), block, rows)
    return x, mask, step


def compress(x: np.ndarray) -> np.ndarray:
    """`sign(v) · log1p(|v|)` — той самий крок, що в етапі 2."""
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return np.sign(clean) * np.log1p(np.abs(clean))


def leg_unit(rows: np.ndarray, q: float, nonzero: bool) -> np.ndarray:
    """Одиниця кожного каналу ноги: `q`-й перцентиль |v| живих рядків;
    з `nonzero` — лише ненульових. Порожньо або 0 — одиниця 1."""
    unit = np.ones(rows.shape[1])
    for channel in range(rows.shape[1]):
        column = np.abs(rows[:, channel])
        if nonzero:
            column = column[column > 0]
        if len(column):
            value = np.percentile(column, q)
            unit[channel] = value if value > 0 else 1.0
    return unit


def normalize(x: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Кожна нога нормується ізольовано, кожен канал окремо:
    сире значення ділиться на медіану |v| ненульових живих рядків своєї
    ноги → `sign(v)·log1p(|v|)` → ділиться на 99-й перцентиль |v| живих
    рядків своєї ноги. Спершу медіана — щоб `log1p` стискав однаково на
    будь-якому масштабі монети."""
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    out = np.zeros(clean.shape, dtype=np.float64)
    for number in range(len(clean)):
        live = mask[number]
        if not live.any():
            continue
        scaled = compress(clean[number] / leg_unit(clean[number][live], 50,
                                                   True))
        out[number] = scaled / leg_unit(scaled[live], 99, False)
        out[number][~live] = 0.0
    return out


def build(pairs: list, root: Path | None = None, out: Path = DATA,
          log=print, keys: list | None = None) -> dict:
    """Записи, ноги й канви всіх монет обох частин — на кожному класі."""
    keys = list(keys or [one["key"] for one in classes30.CLASSES])
    out.mkdir(parents=True, exist_ok=True)
    report = {"steps": STEPS, "bar": BAR, "period": None,
              "threshold": OUTER_THRESHOLD,
              "span": SNAP_SPAN, "rows": ROWS, "min_slice": MIN_SLICE,
              "cut": CUT, "end": END, "default": classes30.DEFAULT,
              "classes": [{"key": one["key"], "name": one["name"],
                           "rule": one["rule"],
                           "features": list(one["features"])}
                          for one in classes30.CLASSES
                          if one["key"] in keys],
              "features": list(FEATURES),
              "pairs": list(pairs), "rows_by": [], "legs": {}}
    canvases = {part: {"x": {key: [] for key in keys}, "mask": {key: []
                       for key in keys}, "step": [], "key": []}
                for part in PARTS}
    for pair in pairs:
        report["legs"][pair] = {}
        for part in PARTS:
            bars = read_bars(pair, part, root)
            legs = legs_of(bars)
            np.savez(out / f"{pair}_{part}.npz", t=bars["t"], n=bars["n"],
                     open=bars["open"], close=bars["close"],
                     price=bars["sums"][RAW.index("price_avg")] / bars["n"])
            nan_share = {}
            for key in keys:
                feats = features_of(bars, key)
                np.savez(out / f"{pair}_{part}_{key}.npz",
                         x=feats.astype(np.float32))
                nan_share[key] = float(np.isnan(feats).any(axis=1).mean())
                del feats
            cache = {}
            for leg in legs:
                holder = read_seconds(pair, leg["from"], leg["to"], cache, root)
                block, fit, step = canvas_blocks(
                    holder, bars["t"][leg["first"]:leg["last"] + 1], leg["to"])
                alive = {}
                for key in keys:
                    x, mask = place(classes30.features(key, block), block)
                    canvases[part]["x"][key].append(x)
                    canvases[part]["mask"][key].append(mask)
                    alive[key] = int(mask.sum())
                canvases[part]["step"].append(step)
                canvases[part]["key"].append(f"{pair}·{leg['leg']}")
                leg["step"] = step
                leg["alive"] = alive
            report["legs"][pair][part] = legs
            count = np.array([leg["bars"] for leg in legs], dtype=float)
            report["rows_by"].append({
                "pair": pair, "part": part, "bars": int(len(bars["t"])),
                "from": int(bars["t"][0]), "to": int(bars["t"][-1]),
                "seconds": int(bars["n"].sum()),
                "gaps": int((np.diff(bars["t"]) != BAR).sum()),
                "legs": len(legs),
                "up": sum(leg["kind"] == "up" for leg in legs),
                "median_bars": float(np.median(count)) if len(count) else None,
                "median_hours": float(np.median(count) * BAR / 3600)
                if len(count) else None,
                "median_move": float(np.median([abs(leg["move"])
                                                for leg in legs]))
                if legs else None,
                "nan_share": nan_share})
            log(f"{pair} {part}: записів {len(bars['t'])}, ніг {len(legs)}, "
                f"медіана {report['rows_by'][-1]['median_bars']} записів")
    for part, piece in canvases.items():
        step, names = np.asarray(piece["step"]), np.asarray(piece["key"])
        for key in keys:
            raw = np.asarray(piece["x"].pop(key))
            mask = np.asarray(piece["mask"].pop(key))
            np.savez(out / f"canvas_{part}_{key}.npz", raw=raw,
                     net=normalize(raw, mask).astype(np.float32),
                     mask=mask, step=step, key=names)
            del raw, mask
    (out / "legs.json").write_text(json.dumps(report, ensure_ascii=False))
    return report


def summary(report: dict) -> dict:
    """Звід для вкладки: без переліку ніг, щоб відповідь була легкою."""
    out = {key: value for key, value in report.items() if key != "legs"}
    out["counts"] = {pair: {part: len(legs) for part, legs in one.items()}
                     for pair, one in report["legs"].items()}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--root", type=Path, default=None,
                        help="тека посекундної робочої копії")
    parser.add_argument("--out", type=Path, default=DATA)
    parser.add_argument("--report", type=Path,
                        default=RESULTS / "bars30.json")
    parser.add_argument("--classes", nargs="+", default=None,
                        help="ключі класів classes30 (типово — усі)")
    args = parser.parse_args()
    report = build(args.pairs, args.root, args.out, keys=args.classes)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(summary(report), ensure_ascii=False,
                                      indent=1))
    print(args.report)


if __name__ == "__main__":
    main()
