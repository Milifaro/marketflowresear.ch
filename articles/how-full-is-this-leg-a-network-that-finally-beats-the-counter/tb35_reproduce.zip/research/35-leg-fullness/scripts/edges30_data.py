"""Етап 8: вікна з ногою цілком — півоти всередині канви, зони влучання.

Дослідження: research/35-leg-fullness/ → Етап 8

## Хід

1. Записи 30 с і ноги — етап 3 (`data/bars30/legs.json`,
   `<PAIR>_<part>.npz`); train до 2026-08-14, val 14.08 … 22.09.
   Півоти — кінці ніг (`last`) і початок першої ноги (`first − 1`),
   ціна півота — `close` запису.
2. **Вікно навколо ноги** `k` довжини `L` записів від півота `s` до
   півота `e`: початок `s − a·L`, кінець `e + b·L`, `a ~ U[−0.4, 0.6]`,
   `b ~ U[−0.6, 0.6]`, `PER_LEG` вікон на ногу. Від'ємні `a`, `b` —
   вікно починається всередині ноги або кінчається до її кінця: у
   канві буває 0, 1, 2 чи 3 півоти, на будь-яких рядках.
3. **Канва** — `windows30.window_canvas`: вікно → 500 відрізків, клас
   `клас210х10-1х7д/д`, нормування тільки на вікно; вхід без маски.
   Скаляри: `log1p(n)`, `log1p(крок відрізка, с)`,
   `log(close / open)` вікна, частка живих рядків.
4. **Ціль «нога завершилась»** — зона півота `p`, що закінчує ногу
   довжини `L` записів і цінової довжини `M = |close[p] − close[p₋]|`:
   перетин двох множин — **за часом** 95 … 105 % тривалості ноги
   (записи `p ± 0.05·L`) і **за ціною** ближче за 10 % `M` до ціни
   півота (вершина — `max close рядка ≥ close[p] − 0.1·M`, дно —
   `min close рядка ≤ close[p] + 0.1·M`). У першого півота ряду
   попередньої ноги немає — береться наступна.
5. **Мітка рядка**: `1` — у зоні півота, що стоїть **у канві**; `0` —
   поза зонами; `−1` — у зоні півота поза канвою (рядок не штрафується
   і не нагороджується: півота мережа не бачить). **Відстань** рядка
   поза зоною — на скільки зон він далі від найближчого півота своєї
   ноги: більше з двох — за часом (у `0.05·L`) і за ціною (у `0.1·M`);
   штраф у втраті росте з нею.

6. **Ряд val** (`--series`) — ковзні вікна без розмітки: `SERIES_BARS`
   записів, крок `SERIES_STEP`, по всьому ряду val кожної монети; для
   кожного рядка — його перший і останній запис (видача рядка лягає на
   свої записи).

Запуск:
    python3 research/35-leg-fullness/scripts/edges30_data.py
    python3 research/35-leg-fullness/scripts/edges30_data.py --series

Вихід: data/edges30/<part>_x.npy (memmap `N × 500 × 7`), <part>.npz —
маска, мітка й відстань рядків, скаляри, нога, межі вікна.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import BAR, DATA, PARTS, ROWS, edges_of, read_seconds  # noqa: E402
from windows30 import window_canvas  # noqa: E402

OUT = SCRIPTS.parent / "data" / "edges30"
KEY = classes30.DEFAULT
PER_LEG = 16
BEFORE = (-0.4, 0.6)
AFTER = (-0.6, 0.6)
ZONE = 0.10                   # частка цінової довжини попередньої ноги
SPAN = 0.05                   # частка тривалості ноги в кожен бік від півота
MIN_BARS = 20                 # коротше вікно не береться
SERIES_BARS = 2000            # записів у вікні ряду val
SERIES_STEP = 250             # крок вікон ряду val
SEED = 8


def pivots_of(legs: list, close: np.ndarray) -> dict:
    """Півоти частини монети: запис, вершина / дно, ширина зони."""
    index, top = [], []
    for leg in legs:
        start = leg["first"] - 1
        if start >= 0 and (not index or index[-1] != start):
            index.append(start)
            top.append(leg["kind"] == "down")      # нога вниз з вершини
        index.append(leg["last"])
        top.append(leg["kind"] == "up")
    index = np.asarray(index, dtype=np.int64)
    top = np.asarray(top, dtype=bool)
    price = close[index]
    move = np.abs(np.diff(price))
    before = np.concatenate([[move[0] if len(move) else 0.0], move])
    length = np.diff(index).astype(float)
    span = np.concatenate([[length[0] if len(length) else 0.0], length])
    return {"index": index, "top": top, "price": price,
            "zone": ZONE * before, "span": SPAN * span}


def row_records(stamps: np.ndarray, edges: np.ndarray, fit: int,
                rows: int = ROWS) -> tuple:
    """Для кожного рядка канви — перший і останній запис вікна в ньому.

    Відрізок коротший за запис (розтяг) лежить усередині одного запису."""
    lo = np.searchsorted(stamps, edges[:-1], side="right") - 1
    hi = np.searchsorted(stamps, edges[1:], side="left") - 1
    lo = np.clip(lo, 0, len(stamps) - 1)
    hi = np.clip(np.maximum(hi, lo), 0, len(stamps) - 1)
    first = np.full(rows, -1, dtype=np.int64)
    last = np.full(rows, -1, dtype=np.int64)
    first[rows - fit:] = lo[:fit]
    last[rows - fit:] = hi[:fit]
    return first, last


def row_targets(start: int, first: np.ndarray, last: np.ndarray,
                close: np.ndarray, pivots: dict, end: int) -> tuple:
    """Мітка (1 / 0 / −1), відстань і власник зони кожного рядка вікна
    `[start, end]`. `first`, `last` — записи рядка відносно `start`;
    власник — номер півота вікна (0, 1, …) для рядків з міткою 1."""
    rows = len(first)
    label = np.zeros(rows, dtype=np.int8)
    owner = np.full(rows, -1, dtype=np.int8)
    distance = np.full(rows, np.inf)
    index = pivots["index"]
    live = np.flatnonzero(first >= 0)
    a = first + start
    b = last + start
    high = np.full(rows, -np.inf)
    low = np.full(rows, np.inf)
    if len(live):
        # рядки йдуть підряд: відрізок рядка — від його першого запису до
        # першого запису наступного (розтяг — той самий запис)
        piece = close[:b[live[-1]] + 1]
        starts = a[live]
        high[live] = np.maximum.reduceat(piece, starts)
        low[live] = np.minimum.reduceat(piece, starts)
        same = np.append(starts[1:] == starts[:-1], False)
        high[live[same]] = close[starts[same]]
        low[live[same]] = close[starts[same]]
    alive = first >= 0
    seen = 0
    for number, p in enumerate(index):
        left = index[number - 1] if number else 0
        right = index[number + 1] if number + 1 < len(index) else len(close) - 1
        near = alive & (b >= left) & (a <= right)
        if not near.any():
            continue
        width = max(pivots["zone"][number], 1e-12)
        gap = (pivots["price"][number] - high if pivots["top"][number]
               else low - pivots["price"][number])
        gap = np.maximum(gap, 0.0) / width
        # за часом: на скільки `0.05·L` рядок далі від півота
        reach = max(pivots["span"][number], 0.5)
        late = np.maximum(np.maximum(p - b, a - p), 0) / reach
        gap = np.maximum(gap, late)
        zone = near & (gap <= 1.0)
        if start <= p <= end:
            label[zone] = 1
            owner[zone] = seen
            seen += 1
        else:
            label[zone & (label != 1)] = -1
        distance[near] = np.minimum(distance[near], gap[near] - 1.0)
    distance = np.where(np.isfinite(distance), np.maximum(distance, 0.0), 0.0)
    return label, distance.astype(np.float32), owner


def draw(legs: list, size: int, rng, per_leg: int = PER_LEG) -> list:
    """Межі вікон `[start, end]` у записах частини."""
    out = []
    for number, leg in enumerate(legs):
        s, e, length = leg["first"] - 1, leg["last"], leg["bars"]
        for _ in range(per_leg):
            start = int(round(s - rng.uniform(*BEFORE) * length))
            end = int(round(e + rng.uniform(*AFTER) * length))
            start, end = max(start, 0), min(end, size - 1)
            if end - start + 1 >= MIN_BARS:
                out.append((number, start, end))
    return out


def canvas_of(holder, stamps: np.ndarray, closes: np.ndarray,
              opens: np.ndarray, start: int, end: int,
              pivots: dict | None = None, key: str = KEY) -> dict:
    """Канва вікна `[start, end]`, скаляри і, з `pivots`, мітки рядків."""
    window = stamps[start:end + 1]
    net, mask, step = window_canvas(holder, window, key)
    edges, fit = edges_of(window, int(window[-1]) + BAR - 1, ROWS)
    first, last = row_records(window, edges, fit)
    out = {"net": net, "mask": mask, "first": first, "last": last,
           "scalars": np.array([
               np.log1p(len(window)), np.log1p(step),
               float(np.log(closes[end] / opens[start])),
               float(mask.mean())], dtype=np.float32)}
    if pivots is not None:
        out["label"], out["distance"], out["owner"] = row_targets(
            start, first, last, closes, pivots, end)
    return out


def build(part: str, data: Path = DATA, out: Path = OUT,
          root: Path | None = None, seed: int = SEED, log=print) -> dict:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(seed)
    plan = {}
    for pair, parts in table["legs"].items():
        legs = parts.get(part, [])
        if not legs:
            continue
        with np.load(data / f"{pair}_{part}.npz") as store:
            size = len(store["t"])
        plan[pair] = draw(legs, size, rng)
    total = sum(len(one) for one in plan.values())
    out.mkdir(parents=True, exist_ok=True)
    features = len(classes30.BY_KEY[KEY]["features"])
    canvas = np.lib.format.open_memmap(out / f"{part}_x.npy", mode="w+",
                                       dtype=np.float32,
                                       shape=(total, ROWS, features))
    keep = {"mask": [], "label": [], "distance": [], "owner": [],
            "scalars": [],
            "leg": [], "pair": [], "start": [], "end": [], "pivots": []}
    position, leg_base = 0, 0
    for pair, windows in plan.items():
        legs = table["legs"][pair][part]
        with np.load(data / f"{pair}_{part}.npz") as store:
            stamps, opens, closes = store["t"], store["open"], store["close"]
        pivots = pivots_of(legs, closes)
        cache = {}
        by_leg = {}
        for number, start, end in windows:
            by_leg.setdefault(number, []).append((start, end))
        for number, spans in by_leg.items():
            low = min(start for start, _ in spans)
            high = max(end for _, end in spans)
            holder = read_seconds(pair, int(stamps[low]),
                                  int(stamps[high]) + BAR - 1, cache, root)
            for start, end in spans:
                got = canvas_of(holder, stamps, closes, opens, start, end,
                                pivots)
                canvas[position] = got["net"]
                for name in ("mask", "label", "distance", "owner",
                             "scalars"):
                    keep[name].append(got[name])
                keep["leg"].append(leg_base + number)
                keep["pair"].append(pair)
                keep["start"].append(start)
                keep["end"].append(end)
                keep["pivots"].append(int(((pivots["index"] >= start)
                                           & (pivots["index"] <= end)).sum()))
                position += 1
        leg_base += len(legs)
        log(f"{pair} {part}: ніг {len(legs)}, вікон {position}")
    canvas.flush()
    del canvas
    arrays = {name: np.asarray(value) for name, value in keep.items()}
    np.savez(out / f"{part}.npz", **arrays)
    return {"windows": position, "legs": leg_base}


def build_series(data: Path = DATA, out: Path = OUT,
                 root: Path | None = None, bars: int = SERIES_BARS,
                 step: int = SERIES_STEP, log=print) -> dict:
    """Ковзні вікна ряду val без розмітки."""
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    plan = {}
    for pair in table["legs"]:
        path = data / f"{pair}_val.npz"
        if not path.exists():
            continue
        with np.load(path) as store:
            size = len(store["t"])
        starts = list(range(0, max(size - bars, 0) + 1, step))
        if starts and starts[-1] + bars < size:
            starts.append(size - bars)
        plan[pair] = [(start, min(start + bars, size) - 1) for start in starts]
    total = sum(len(one) for one in plan.values())
    out.mkdir(parents=True, exist_ok=True)
    features = len(classes30.BY_KEY[KEY]["features"])
    canvas = np.lib.format.open_memmap(out / "series_x.npy", mode="w+",
                                       dtype=np.float32,
                                       shape=(total, ROWS, features))
    keep = {"mask": [], "scalars": [], "pair": [], "start": [], "end": [],
            "first": [], "last": []}
    position = 0
    for pair, windows in plan.items():
        with np.load(data / f"{pair}_val.npz") as store:
            stamps, opens, closes = store["t"], store["open"], store["close"]
        cache = {}
        for start, end in windows:
            holder = read_seconds(pair, int(stamps[start]),
                                  int(stamps[end]) + BAR - 1, cache, root)
            got = canvas_of(holder, stamps, closes, opens, start, end)
            canvas[position] = got["net"]
            for name in ("mask", "scalars", "first", "last"):
                keep[name].append(got[name])
            keep["pair"].append(pair)
            keep["start"].append(start)
            keep["end"].append(end)
            position += 1
        log(f"{pair} ряд val: вікон {len(windows)}")
    canvas.flush()
    del canvas
    np.savez(out / "series.npz",
             **{name: np.asarray(value) for name, value in keep.items()})
    return {"windows": position}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--series", action="store_true",
                        help="ковзні вікна ряду val без розмітки")
    args = parser.parse_args()
    if args.series:
        print(f"ряд val: {build_series(args.data, args.out, args.root)}")
        return
    for part in PARTS:
        print(f"{part}: {build(part, args.data, args.out, args.root)}")


if __name__ == "__main__":
    main()
