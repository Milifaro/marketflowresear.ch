"""UMAP ніг на канві 500: кожна нога — точка, вгору зелена, вниз червона.

Дослідження: research/35-leg-fullness/ → Етап 5
Правила: rules/05-visualization.md → UMAP

## Хід

1. Вхід — канва етапу 4 (`net` після нормування на свою ногу) кожного
   класу, ті самі ноги, що в заміру голови й хвоста (`head_tail30.windows`:
   живих рядків ≥ 90 % канви).
2. Три вектори на ногу: **нога** — уся канва `500 × F`, **голова** —
   перші 25 живих рядків, **хвіст** — останні 25 живих рядків.
3. UMAP у 2д, три метрики (`cosine`, `euclidean`, `manhattan`),
   однакові параметри й seed на всіх картах; train і val окремо.
4. На точці — ключ ноги, напрямок, рух від півота до півота (насиченість
   кольору) і час.

Запуск:
    python3 research/35-leg-fullness/scripts/umap_legs30.py
    python3 research/35-leg-fullness/scripts/umap_legs30.py --classes x10m1x7dd

Вихід: results/umap_legs30/<клас>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import DATA, PARTS, RESULTS  # noqa: E402
from head_tail30 import windows  # noqa: E402

METRICS = ("cosine", "euclidean", "manhattan")
VIEWS = ("leg", "head", "tail")
N_NEIGHBORS = 15
MIN_DIST = 0.1
SEED = 42
OUT = RESULTS / "umap_legs30"


def embed(x: np.ndarray, metric: str) -> np.ndarray:
    """2д-проєкція; сталі вектори cosine не приймає — лишаються як є."""
    import umap
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        reducer = umap.UMAP(n_components=2, n_neighbors=N_NEIGHBORS,
                            min_dist=MIN_DIST, metric=metric,
                            random_state=SEED)
        return reducer.fit_transform(x.astype(np.float32))


def legs_table(data: Path) -> dict:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    return {part: {f"{pair}·{leg['leg']}": leg
                   for pair, parts in table["legs"].items()
                   for leg in parts.get(part, [])} for part in PARTS}


def one_class(key: str, data: Path, legs: dict, log=print) -> dict:
    out = {"key": key, "name": classes30.BY_KEY[key]["name"],
           "params": {"n_components": 2, "n_neighbors": N_NEIGHBORS,
                      "min_dist": MIN_DIST, "random_state": SEED},
           "metrics": list(METRICS), "views": list(VIEWS)}
    for part in PARTS:
        with np.load(data / f"canvas_{part}_{key}.npz") as store:
            net, mask, names = store["net"], store["mask"], store["key"]
        cut = windows(net, mask)
        keep = cut["keep"]
        vectors = {"leg": net[keep].reshape(keep.sum(), -1),
                   "head": cut["head"][keep].reshape(keep.sum(), -1),
                   "tail": cut["tail"][keep].reshape(keep.sum(), -1)}
        info = [legs[part][str(name)] for name in names[keep]]
        one = {"legs": [str(name) for name in names[keep]],
               "kind": [leg["kind"] for leg in info],
               "move": [round(float(leg["move"]), 5) for leg in info],
               "from": [int(leg["from"]) for leg in info],
               "to": [int(leg["to"]) for leg in info],
               "dim": {view: int(value.shape[1])
                       for view, value in vectors.items()},
               "maps": {}}
        for view, x in vectors.items():
            one["maps"][view] = {}
            for metric in METRICS:
                xy = embed(x, metric)
                one["maps"][view][metric] = np.round(xy, 3).tolist()
        out[part] = one
        log(f"{out['name']} {part}: ніг {len(info)}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--classes", nargs="+", default=None)
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args()
    legs = legs_table(args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    for key in args.classes or [one["key"] for one in classes30.CLASSES]:
        report = one_class(key, args.data, legs)
        (args.out / f"{key}.json").write_text(
            json.dumps(report, ensure_ascii=False), encoding="utf-8")
    print(args.out)


if __name__ == "__main__":
    main()
