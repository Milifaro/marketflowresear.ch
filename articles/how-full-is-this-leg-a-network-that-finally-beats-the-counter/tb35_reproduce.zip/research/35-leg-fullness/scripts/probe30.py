"""Подача і видача мережі етапу 6 на одній нозі val.

Дослідження: research/35-leg-fullness/ → Етап 6, вкладка `/fullness30`

## Хід

1. Нога `number` (з 1) монети `pair` у val — `data/bars30/legs.json`.
2. Вікно — записи від першого після півота, `n = max(2, round(p · L))`,
   `p` — частка ноги з комірки (0.1 … 2.0); записів не більше, ніж є в
   ряду val. Мітка `q = n / L`.
3. Вхід — той самий, що у вікон навчання (`fullness_data30.build`):
   канва `windows30.window_canvas` (нормування тільки на вікно), маска,
   чотири скаляри.
4. Видача — модель `models/fullness30_v1/epoch_NN.pt` або, з `--run`,
   прогін кола 4 (`d1` — 250 кроків уваги, `d0` — 500, `raw` — 500
   сирих фіч без згортки, `flat` — канва одним вектором без уваги,
   `g12` — трансформер кола 12 етапу 7 на 500 рядках без стовпця маски) з
   `data/fullness30/x10m1x7dd/runs/<тег>.pt`: 16 сходинок
   `P(q ≥ c)` і 500 рядків `P(рядок — наступна нога)`, після сигмоїди.
5. Правда — `targets(q)` на сходинках, `row_labels` на рядках (рядок
   від першої секунди наступної ноги й далі).

Запуск (перевірка однієї ноги):
    python3 research/35-leg-fullness/scripts/probe30.py BTC_USDT 3 1.2
    python3 research/35-leg-fullness/scripts/probe30.py BTC_USDT 3 1.2 --run d0
"""

from __future__ import annotations

import argparse
import json
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import BAR, DATA, read_seconds  # noqa: E402
from fullness_data30 import row_labels  # noqa: E402
from windows30 import window_canvas  # noqa: E402

MODEL = SCRIPTS.parent / "models" / "fullness30_v1"
RUNS_DIR = SCRIPTS.parent / "data" / "fullness30" / "x10m1x7dd" / "runs"
SHARE_MIN, SHARE_MAX = 0.1, 2.0
# коло 4: ті самі ручки, що в обраної моделі, інший стовбур; ваги —
# найкраща за відкладеними епоха прогону (`fullness_net30.py --grid 4`)
RUNS = {"d1": ("g4_w128_d1_l2_lr0.001_do0_rw3_e12_t0", {"down": 1}),
        "d0": ("g4_w128_d0_l2_lr0.001_do0_rw3_e12_t0", {"down": 0}),
        "raw": ("g4_w128_d0_l2_lr0.001_do0_rw3_e12_t0_raw",
                {"down": 0, "trunk": "raw"}),
        "flat": ("g4_w256_d2_l2_lr0.001_do0_rw3_e12_t0_flat",
                 {"trunk": "flat", "width": 256}),
        # етап 7, коло 12: трансформер на 500 рядках, 8 голів × 4 шари,
        # вхід 500 × 7 без стовпця маски
        "g12": ("g12_w64_d2_l4_lr0.001_do0_rw3_e50_t0_tf_h8_pt2_nc",
                {"trunk": "tf", "width": 64, "heads": 8, "layers": 4,
                 "no_column": True})}


def window_of(leg: dict, share: float, records: int) -> int:
    """Записів у вікні частки `share`, не більше, ніж є в ряду."""
    count = max(2, int(round(share * leg["bars"])))
    return int(min(count, records - leg["first"]))


def weights_of(epoch: int, folder: Path = MODEL, run: str = "") -> Path:
    """Файл ваг: епоха обраної моделі, прогін кола 4 (найкраща епоха) або
    епоха прогону з вагами кожної епохи (`epoch` > 0)."""
    if run:
        runs = folder.parent.parent / RUNS_DIR.relative_to(SCRIPTS.parent)
        if epoch:
            return runs / f"{RUNS[run][0]}_epochs" / f"epoch_{epoch:02d}.pt"
        return runs / f"{RUNS[run][0]}.pt"
    return folder / f"epoch_{epoch:02d}.pt"


@lru_cache(maxsize=8)
def model_of(epoch: int, folder: Path = MODEL, run: str = ""):
    """Модель епохи (або прогону `run` кола 4) з її конфігом; torch —
    тільки тут."""
    import torch
    from fullness_net30 import net_of
    config = json.loads((folder / "config.json").read_text(encoding="utf-8"))
    one = {**config["config"], **(RUNS[run][1] if run else {})}
    config = {**config, "config": one}
    features = len(classes30.BY_KEY[config["key"]]["features"])
    model = net_of(features, one)
    model.load_state_dict(torch.load(weights_of(epoch, folder, run),
                                     map_location="cpu"))
    model.eval()
    return model, config


def probe(pair: str, number: int, share: float, epoch: int,
          data: Path = DATA, folder: Path = MODEL,
          root: Path | None = None, run: str = "") -> dict:
    """Вхід і вихід мережі на вікні однієї ноги val."""
    import torch
    from fullness_net30 import scalars_of, targets
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    legs = table["legs"].get(pair, {}).get("val", [])
    leg = legs[number - 1]
    following = legs[number] if number < len(legs) else None
    model, config = model_of(epoch, folder, run)
    key = config["key"]
    with np.load(data / f"{pair}_val.npz") as store:
        stamps, opens, closes = store["t"], store["open"], store["close"]
        price = store["price"]
    count = window_of(leg, share, len(stamps))
    window = stamps[leg["first"]:leg["first"] + count]
    end = leg["first"] + count - 1
    holder = read_seconds(pair, leg["from"], int(stamps[end]) + BAR - 1, {},
                          root)
    net, mask, step = window_canvas(holder, window, key)
    next_start = (int(stamps[following["first"]])
                  if following is not None
                  and following["first"] == leg["last"] + 1 else None)
    rows_true = row_labels(window, next_start) * mask
    q = count / leg["bars"]
    scalars = np.array([[np.log1p(count), np.log1p(step),
                         float(np.log(closes[end] / opens[leg["first"]])),
                         float(mask.mean())]], dtype=np.float32)
    with torch.no_grad():
        ladder, rows = model(torch.from_numpy(net[None]),
                             torch.from_numpy(mask[None].astype(np.float32)),
                             torch.from_numpy(scalars_of(scalars)))
    # межі відрізків канви — щоб рядок мав свій час на осі ціни
    from bars30 import edges_of
    edges, fit = edges_of(window, int(window[-1]) + BAR - 1)
    centers = np.full(len(mask), np.nan)
    centers[len(mask) - fit:] = (edges[:-1] + edges[1:]) / 2
    # ціна: нога, вікно й наступна нога, щоб видно було межу
    stop = max(end, following["last"] if following is not None
               and following["first"] == leg["last"] + 1 else leg["last"])
    return {"pair": pair, "number": number, "count": len(legs),
            "epoch": epoch, "run": run, "share": share, "leg": leg,
            "bars": count,
            "q": q, "step": step, "key": key,
            "features": classes30.BY_KEY[key]["features"],
            "net": net, "mask": mask, "centers": centers,
            "scalars": scalars[0], "scalars_in": scalars_of(scalars)[0],
            "ladder": torch.sigmoid(ladder)[0].numpy(),
            "rows": torch.sigmoid(rows)[0].numpy(),
            "ladder_true": targets(np.array([q]))[0], "rows_true": rows_true,
            "thresholds": config["thresholds"], "names": config["names"],
            "window_end": int(stamps[end]) + BAR - 1,
            "t": stamps[leg["first"]:stop + 1],
            "price": price[leg["first"]:stop + 1],
            "next": following if next_start is not None else None}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("pair")
    parser.add_argument("number", type=int)
    parser.add_argument("share", type=float)
    parser.add_argument("--epoch", type=int, default=None)
    parser.add_argument("--run", choices=sorted(RUNS), default="")
    args = parser.parse_args()
    # з `--run` без `--epoch` — найкраща епоха прогону
    epoch = args.epoch or (0 if args.run else json.loads(
        (MODEL / "config.json").read_text(encoding="utf-8"))["best_epoch"])
    got = probe(args.pair, args.number, args.share, epoch, run=args.run)
    print(f"{args.pair} нога {args.number}: записів {got['bars']}, "
          f"q {got['q']:.3f}")
    for name, value, truth in zip(got["names"], got["ladder"],
                                  got["ladder_true"]):
        print(f"  {name:>5}: {value:.3f}  правда {int(truth)}")


if __name__ == "__main__":
    main()
