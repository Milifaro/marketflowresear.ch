"""Мережа етапу 6: яку частку ноги подано у вікні, і де в ньому півот.

Дослідження: research/35-leg-fullness/ → Етап 6
Правила: rules/03-models.md → Розбиття по часу, Навчання без свопа

## Вхід

Вікна [`fullness_data30.py`](fullness_data30.py): канва `500 × F` вікна
від півота до `t` (нормування тільки на вікно), маска живих рядків і
чотири причинні скаляри.

## Мережа

    (F каналів + маска) -> DOWN блоків Conv1d(5, stride 2) + GroupNorm + GELU
                        -> T кроків × WIDTH -> LAYERS шарів уваги, 4 голови
       вихід 1: увага-пулінг + скаляри -> 64 -> 16 логітів P(q ≥ c)
       вихід 2: кожен крок -> 1 логіт -> лінійно до 500 рядків

## Виходи

1. **Сходинки** — 16 логітів, сигмоїда дає `P(q ≥ c)` на порогах
   `THRESHOLDS`; `1.0⁺` — `q > 1`, у вікні є запис наступної ноги.
2. **Рядки** — 500 логітів, сигмоїда дає ймовірність, що рядок уже
   належить наступній нозі.

Обидва виходи пишуться сирими; формула, що зводить їх у відповідь, —
потім.

## Втрата

`BCE(сходинки)` — середнє по 16 порогах, `+ ROW_WEIGHT · BCE(рядки)` по
живих рядках.

## Розбиття

train — ноги до 2026-08-14, val — 14.08 … 22.09. Відкладений шматок —
20 % **ніг** train (seed); епоха вибирається за найменшою втратою на
ньому, val у виборі не бере участі.

## Грід

`--grid 1` — архітектура (ширина × глибина згортки × шари уваги);
`--grid 2` — від кращого кола 1 по одній ручці: lr, dropout, вага
рядків; `--grid 3` — тривалість кращого; `--grid 4` — від обраної
моделі 250 і 500 кроків уваги, сирі фічі без згортки і вся канва одним
вектором у повнозвʼязну мережу без уваги, `--only d1|d0|raw|flat`; `--grid 5` / `--grid 6` — flat повним
перебором ширини × dropout × weight decay і далі по одній ручці від
кращого, `--grid 7` / `--grid 8` — те саме на MLP-Mixer; `--grid 9` —
двонапрямний LSTM, `--grid 10` — трансформер, обидва на всіх 500 кроках;
`--grid 11` — обрана модель і кращі LSTM, трансформер і Mixer без маски
на вході (прогін, що вже має результат, пропускається)
— один прогін кола (500 кроків уваги вчаться батчем 64 шматками по 32:
той самий градієнт, пік MPS ~1.2 GB замість 2.4);
`--tail 16` — контроль «хвіст».

Запуск:
    python3 research/35-leg-fullness/scripts/fullness_net30.py --grid 1
    python3 research/35-leg-fullness/scripts/fullness_net30.py --grid 2
    python3 research/35-leg-fullness/scripts/fullness_net30.py --grid 3
    python3 research/35-leg-fullness/scripts/fullness_net30.py --grid 4 --only raw
    python3 research/35-leg-fullness/scripts/fullness_net30.py --final
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
for extra in (PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts",
              Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from leg_end_train import no_swap  # noqa: E402

DATA = RESEARCH_DIR / "data" / "fullness30"
RESULTS = RESEARCH_DIR / "results" / "fullness30"
MODELS = RESEARCH_DIR / "models"
KEY = "x10m1x7dd"
ROWS = 500
THRESHOLDS = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.98, 1.0,
              1.1, 1.2, 1.3, 1.4, 1.5)
NAMES = [f"{c:g}" for c in THRESHOLDS[:10]] + ["1.0+"] + \
    [f"{c:g}" for c in THRESHOLDS[11:]]
SEED = 0
HOLDOUT = 0.2
BASE = {"width": 64, "down": 2, "layers": 1, "lr": 1e-3, "dropout": 0.0,
        "row_weight": 1.0, "batch": 64, "epochs": 12, "tail": 0}
GRID1 = [{"width": w, "down": d, "layers": l}
         for w in (64, 128) for d in (2, 3) for l in (1, 2)]
# коло 4 — від обраної моделі: скільки кроків бачить увага. 250 і 500
# кроків зі згорткою і 500 кроків сирих фіч без згортки.
# `flat` — уся канва 500 × 8 одним вектором у повнозвʼязну мережу
# 4000 → 256 → 256, без уваги
GRID4 = [{"down": 1}, {"down": 0}, {"down": 0, "trunk": "raw"},
         {"trunk": "flat", "width": 256}]
GRID4_NAMES = ("d1", "d0", "raw", "flat")
# кола 5–8 — уся канва одним входом, від ручок обраної моделі (lr 1e-3,
# вага рядків 3, батч 64), по 20 епох: з регуляризацією мережа вчиться
# повільніше. 5 — flat: ширина × dropout × weight decay повним перебором;
# 6 — від кращого кола 5 по одній ручці: lr, шари, dropout входу,
# канва 50 × 8; 7 — Mixer: канали × приховане уздовж рядків × шари ×
# dropout повним перебором; 8 — від кращого кола 7: weight decay, lr,
# dropout входу, канва 50 × 8.
LONG_WHOLE = 20
GRID5 = [{"trunk": "flat", "width": w, "dropout": d, "wd": wd}
         for w in (64, 128, 256) for d in (0.0, 0.3, 0.5)
         for wd in (0.0, 1e-2, 1e-1)]
GRID6 = [{"lr": 3e-4}, {"lr": 3e-3}, {"layers": 1}, {"layers": 3},
         {"in_drop": 0.1}, {"in_drop": 0.3}, {"pool": 10}]
GRID7 = [{"trunk": "mixer", "width": c, "tokens": t, "layers": b,
          "dropout": d}
         for c in (32, 64) for t in (64, 256) for b in (2, 4)
         for d in (0.0, 0.3)]
GRID8 = [{"wd": 1e-2}, {"wd": 1e-1}, {"lr": 3e-4}, {"lr": 3e-3},
         {"in_drop": 0.1}, {"pool": 10}]
# кола 9–10 — уся канва 500 × 8 послідовністю без стиснення, від ручок
# обраної моделі, по 10 епох: 9 — двонапрямний LSTM (ширина × шари),
# 10 — трансформер на 500 кроках (ширина), батч 64 шматками по 32
LONG_SEQ = 10
GRID9 = [{"trunk": "lstm", "width": 128, "layers": 1},
         {"trunk": "lstm", "width": 128, "layers": 2},
         {"trunk": "lstm", "width": 256, "layers": 1}]
GRID10 = [{"trunk": "tf", "width": 64, "layers": 2},
          {"trunk": "tf", "width": 128, "layers": 2}]
# коло 11 — чи потрібна маска: обрана модель (12 епох, як у колі 4), кращі
# LSTM, трансформер і Mixer (кола 9, 10, 8) без маски на вході, решта та
# сама
# коло 12 — трансформер кола 10 (ширина 64) глибший: 8 голів, 4 шари;
# на вхід канва 500 × 7 без стовпця маски; батч 64 шматками по 16;
# вчиться до перенавчання: стоп, коли 2 епохи поспіль відкладена втрата
# не краща за найкращу (стеля 50 епох)
GRID12 = [{"trunk": "tf", "width": 64, "heads": 8, "layers": 4,
           "no_column": True, "epochs": 50, "patience": 2}]
CHUNK_DEEP = 16
GRID2 = [{"lr": 3e-4}, {"lr": 3e-3}, {"dropout": 0.1},
         {"row_weight": 0.3}, {"row_weight": 3.0}]
LONG = 30
# канва читається memmap: у памʼяті батч (64 × 500 × 7), ваги й пристрій
MEMORY_NEED = 1200
# увага на 500 кроках: матриця 500 × 500 на голову й вікно — замір одного
# кроку batch 64 на MPS дав 2.3–2.4 GB, плюс процес з даними
MEMORY_NEED_500 = 3500
# ... або батч 64 шматками по 32 з одним кроком оптимізатора: градієнт
# той самий, пік MPS ~1.2 GB — тоді вистачає звичайного запасу
CHUNK_500 = 32


def clean(value):
    """`NaN` → `None` для JSON: AUC сходинки без жодного позитиву не
    визначена, а `NaN` — не JSON."""
    if isinstance(value, float):
        return value if np.isfinite(value) else None
    if isinstance(value, dict):
        return {key: clean(one) for key, one in value.items()}
    if isinstance(value, list):
        return [clean(one) for one in value]
    return value


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(clean(value), ensure_ascii=False, indent=1,
                               allow_nan=False))


def device_of(name: str = "auto") -> torch.device:
    if name != "auto":
        return torch.device(name)
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def targets(q: np.ndarray) -> np.ndarray:
    """Мітки сходинок `(N, 16)`: `q ≥ c`, на `1.0⁺` — `q > 1`."""
    out = q[:, None] >= np.asarray(THRESHOLDS)[None, :] - 1e-9
    out[:, THRESHOLDS.index(1.0)] = q > 1 + 1e-9
    return out.astype(np.float32)


def load(folder: Path, part: str) -> dict:
    with np.load(folder / f"{part}.npz") as store:
        data = {key: store[key] for key in store.files}
    data["x"] = np.load(folder / f"{part}_x.npy", mmap_mode="r")
    data["ladder"] = targets(data["q"])
    return data


class Window(nn.Module):
    def __init__(self, channels: int, scalars: int, width: int, down: int,
                 layers: int, dropout: float, heads: int = 4,
                 trunk: str = "conv", in_drop: float = 0.0, pool: int = 1):
        super().__init__()
        self.flat = None
        if trunk == "flat":
            # без уваги: уся канва з маскою одним вектором 500 × 8 = 4000
            # у повнозвʼязну мережу; `layers` шарів по `width`. `in_drop`
            # гасить числа самого входу, `pool` усереднює канву по `pool`
            # рядків (10 → 50 × 8 = 400 чисел)
            self.in_drop, self.pool_rows = nn.Dropout(in_drop), pool
            sizes = [ROWS // pool * (channels + 1)] + [width] * layers
            blocks = []
            for number in range(layers):
                blocks += [nn.Linear(sizes[number], sizes[number + 1]),
                           nn.GELU(), nn.Dropout(dropout)]
            self.flat = nn.Sequential(*blocks)
            self.ladder = nn.Sequential(
                nn.Linear(width + scalars, 64), nn.GELU(),
                nn.Dropout(dropout), nn.Linear(64, len(THRESHOLDS)))
            self.rows = nn.Linear(width, ROWS)
            return
        blocks = []
        if trunk == "raw":
            # без згортки: фічі й маска рядка — прямо в увагу, 500 кроків
            width, down = channels + 1, 0
        elif down == 0:
            # згортка без кроку: 500 кроків по `width`
            blocks = [nn.Conv1d(channels + 1, width, 5, padding=2),
                      nn.GroupNorm(8, width), nn.GELU()]
        sizes = [channels + 1] + [width] * down
        for number in range(down):
            blocks += [nn.Conv1d(sizes[number], sizes[number + 1], 5,
                                 stride=2, padding=2),
                       nn.GroupNorm(8, sizes[number + 1]), nn.GELU()]
        self.trunk = nn.Sequential(*blocks)
        block = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=2 * width,
            dropout=dropout, batch_first=True, norm_first=True)
        self.attention = nn.TransformerEncoder(block, num_layers=layers,
                                               enable_nested_tensor=False)
        self.position = nn.Parameter(torch.zeros(1, ROWS // 2 ** down + 1,
                                                 width))
        self.query = nn.Parameter(torch.randn(1, 1, width) * 0.02)
        self.pool = nn.MultiheadAttention(width, heads, batch_first=True)
        self.ladder = nn.Sequential(nn.Linear(width + scalars, 64), nn.GELU(),
                                    nn.Dropout(dropout),
                                    nn.Linear(64, len(THRESHOLDS)))
        self.rows = nn.Linear(width, 1)

    def forward(self, x, mask, numbers):
        joined = torch.cat([x, mask.unsqueeze(2)], dim=2)
        if self.flat is not None:
            if self.pool_rows > 1:
                joined = joined.reshape(len(joined), -1, self.pool_rows,
                                        joined.shape[2]).mean(2)
            vector = self.flat(self.in_drop(joined).flatten(1))
            ladder = self.ladder(torch.cat([vector, numbers], dim=1))
            return ladder, self.rows(vector)
        trunk = self.trunk(joined.transpose(1, 2)).transpose(1, 2)
        trunk = trunk + self.position[:, :trunk.shape[1]]
        seen = self.attention(trunk)
        query = self.query.expand(seen.shape[0], -1, -1)
        vector, _ = self.pool(query, seen, seen)
        ladder = self.ladder(torch.cat([vector.squeeze(1), numbers], dim=1))
        rows = self.rows(seen).transpose(1, 2)
        rows = F.interpolate(rows, size=ROWS, mode="linear",
                             align_corners=False).squeeze(1)
        return ladder, rows


class MixerBlock(nn.Module):
    """Шар MLP-Mixer: спершу MLP уздовж рядків (один на всі канали), потім
    MLP уздовж каналів (один на всі рядки); обидва з залишком."""

    def __init__(self, rows: int, width: int, tokens: int, dropout: float):
        super().__init__()
        self.norm_rows = nn.LayerNorm(width)
        self.along_rows = nn.Sequential(
            nn.Linear(rows, tokens), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(tokens, rows), nn.Dropout(dropout))
        self.norm_channels = nn.LayerNorm(width)
        self.along_channels = nn.Sequential(
            nn.Linear(width, 2 * width), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(2 * width, width), nn.Dropout(dropout))

    def forward(self, x):
        x = x + self.along_rows(self.norm_rows(x).transpose(1, 2)) \
            .transpose(1, 2)
        return x + self.along_channels(self.norm_channels(x))


class Mixer(nn.Module):
    """Уся канва 500 × 8 одним входом без уваги й згортки: рядок →
    `width` каналів, `layers` шарів Mixer, середнє по рядках → сходинки,
    кожен рядок → свій логіт «наступна нога»."""

    def __init__(self, channels: int, scalars: int, width: int, layers: int,
                 dropout: float, tokens: int, in_drop: float = 0.0,
                 pool: int = 1):
        super().__init__()
        self.in_drop, self.pool_rows = nn.Dropout(in_drop), pool
        rows = ROWS // pool
        self.embed = nn.Linear(channels + 1, width)
        self.blocks = nn.Sequential(*[MixerBlock(rows, width, tokens, dropout)
                                      for _ in range(layers)])
        self.norm = nn.LayerNorm(width)
        self.ladder = nn.Sequential(nn.Linear(width + scalars, 64), nn.GELU(),
                                    nn.Dropout(dropout),
                                    nn.Linear(64, len(THRESHOLDS)))
        self.rows = nn.Linear(width, 1)

    def forward(self, x, mask, numbers):
        joined = torch.cat([x, mask.unsqueeze(2)], dim=2)
        if self.pool_rows > 1:
            joined = joined.reshape(len(joined), -1, self.pool_rows,
                                    joined.shape[2]).mean(2)
        seen = self.norm(self.blocks(self.embed(self.in_drop(joined))))
        ladder = self.ladder(torch.cat([seen.mean(1), numbers], dim=1))
        rows = self.rows(seen).transpose(1, 2)
        if self.pool_rows > 1:
            rows = F.interpolate(rows, size=ROWS, mode="linear",
                                 align_corners=False)
        return ladder, rows.squeeze(1)


class Sequence(nn.Module):
    """Уся канва 500 × 8 послідовністю з 500 кроків, без стиснення:

    * `lstm` — двонапрямний LSTM, `layers` шарів, по `width / 2` на
      напрям: кожен крок знає всю канву зліва і справа;
    * `tf` — трансформер: рядок → `width` лінійно, позиція кроку,
      `layers` шарів уваги по 4 голови на всіх 500 кроках.

    Голови — як у `Window`: запит збирає увагою 500 кроків в один
    вектор + 4 скаляри → 16 сходинок; кожен крок → свій логіт рядка."""

    def __init__(self, channels: int, scalars: int, width: int, layers: int,
                 dropout: float, kind: str, heads: int = 4,
                 mask_column: bool = True):
        super().__init__()
        self.kind = kind
        self.mask_column = mask_column
        inputs = channels + 1 if mask_column else channels
        if kind == "lstm":
            self.body = nn.LSTM(inputs, width // 2, layers,
                                batch_first=True, bidirectional=True,
                                dropout=dropout if layers > 1 else 0.0)
        else:
            self.embed = nn.Linear(inputs, width)
            self.position = nn.Parameter(torch.zeros(1, ROWS, width))
            block = nn.TransformerEncoderLayer(
                d_model=width, nhead=heads, dim_feedforward=2 * width,
                dropout=dropout, batch_first=True, norm_first=True)
            self.body = nn.TransformerEncoder(block, num_layers=layers,
                                              enable_nested_tensor=False)
        self.query = nn.Parameter(torch.randn(1, 1, width) * 0.02)
        self.pool = nn.MultiheadAttention(width, heads, batch_first=True)
        self.ladder = nn.Sequential(nn.Linear(width + scalars, 64), nn.GELU(),
                                    nn.Dropout(dropout),
                                    nn.Linear(64, len(THRESHOLDS)))
        self.rows = nn.Linear(width, 1)

    def forward(self, x, mask, numbers):
        joined = (torch.cat([x, mask.unsqueeze(2)], dim=2)
                  if self.mask_column else x)
        if self.kind == "lstm":
            seen, _ = self.body(joined)
        else:
            seen = self.body(self.embed(joined) + self.position)
        query = self.query.expand(seen.shape[0], -1, -1)
        vector, _ = self.pool(query, seen, seen)
        ladder = self.ladder(torch.cat([vector.squeeze(1), numbers], dim=1))
        return ladder, self.rows(seen).squeeze(2)


class NoMask(nn.Module):
    """Та сама мережа без маски на вході: 8-й канал — нулі, скаляр частки
    живих рядків — нуль. Втрата рядків і далі рахується по живих рядках —
    маска лишається мірою, а не входом."""

    def __init__(self, inner: nn.Module):
        super().__init__()
        self.inner = inner

    def forward(self, x, mask, numbers):
        numbers = numbers.clone()
        numbers[:, 3] = 0.0
        return self.inner(x, torch.zeros_like(mask), numbers)


def net_of(channels: int, config: dict) -> nn.Module:
    """Мережа за конфігом; `no_mask` — вона ж без маски на вході."""
    net = _net_of(channels, config)
    return NoMask(net) if config.get("no_mask") else net


def _net_of(channels: int, config: dict) -> nn.Module:
    """Мережа за конфігом: `trunk` conv / raw / flat — `Window`, mixer —
    `Mixer`."""
    extra = {"in_drop": config.get("in_drop", 0.0),
             "pool": config.get("pool", 1)}
    if config.get("trunk") in ("lstm", "tf"):
        return Sequence(channels, 4, config["width"], config["layers"],
                        config["dropout"], config["trunk"],
                        heads=config.get("heads", 4),
                        mask_column=not config.get("no_column"))
    if config.get("trunk") == "mixer":
        return Mixer(channels, 4, config["width"], config["layers"],
                     config["dropout"], config["tokens"], **extra)
    if config.get("trunk") != "flat":
        extra = {}
    return Window(channels, 4, config["width"], config["down"],
                  config["layers"], config["dropout"],
                  trunk=config.get("trunk", "conv"), **extra)


def optimizer_of(model: nn.Module, config: dict):
    """Adam; з `wd` — AdamW з цим weight decay."""
    if config.get("wd"):
        return torch.optim.AdamW(model.parameters(), lr=config["lr"],
                                 weight_decay=config["wd"])
    return torch.optim.Adam(model.parameters(), lr=config["lr"])


def scalars_of(raw: np.ndarray) -> np.ndarray:
    count, step, move, live = raw.T
    return np.stack([count / 8.0, step / 8.0, move * 10.0, live],
                    axis=1).astype(np.float32)


def feed(data: dict, index: np.ndarray, device, tail: int = 0) -> tuple:
    index = np.sort(index)
    x = torch.from_numpy(np.asarray(data["x"][index], dtype=np.float32))
    mask = torch.from_numpy(data["mask"][index].astype(np.float32))
    if tail:
        keep = torch.zeros_like(mask)
        keep[:, -tail:] = 1.0
        mask = mask * keep
        x = x * mask.unsqueeze(2)
    numbers = torch.from_numpy(scalars_of(data["scalars"][index]))
    ladder = torch.from_numpy(data["ladder"][index])
    rows = torch.from_numpy(data["rows"][index].astype(np.float32))
    return index, tuple(one.to(device) for one in
                        (x, mask, numbers, ladder, rows))


def losses(ladder, rows, mask, y_ladder, y_rows, row_weight: float):
    first = F.binary_cross_entropy_with_logits(ladder, y_ladder)
    each = F.binary_cross_entropy_with_logits(rows, y_rows, reduction="none")
    second = (each * mask).sum() / mask.sum().clamp(min=1)
    return first + row_weight * second, first, second


def step_loss(model, x, mask, numbers, y_ladder, y_rows, row_weight: float,
              chunk: int = 0) -> float:
    """Втрата батча з `backward`. З `chunk` батч іде шматками по `chunk`
    вікон з одним кроком оптимізатора: кожен шматок несе свою частку тієї
    самої суми, що й `losses` на всьому батчі, — градієнт той самий, а
    памʼяті на увагу треба в `batch / chunk` разів менше."""
    if not chunk or chunk >= len(x):
        loss, _, _ = losses(*model(x, mask, numbers), mask, y_ladder,
                            y_rows, row_weight)
        loss.backward()
        return float(loss.detach())
    live = mask.sum().clamp(min=1)
    total = 0.0
    for start in range(0, len(x), chunk):
        part = slice(start, start + chunk)
        ladder, rows = model(x[part], mask[part], numbers[part])
        first = F.binary_cross_entropy_with_logits(
            ladder, y_ladder[part], reduction="sum") / y_ladder.numel()
        each = F.binary_cross_entropy_with_logits(rows, y_rows[part],
                                                  reduction="none")
        loss = first + row_weight * (each * mask[part]).sum() / live
        loss.backward()
        total += float(loss.detach())
    return total


def eval_batch(config: dict) -> int:
    """Вікон на прохід без градієнта: 256 на 125 кроках уваги, на довших
    — 32, щоб матриця уваги не виходила за пік навчання."""
    # LSTM і трансформер ідуть по всіх 500 рядках без стиснення
    steps = ROWS if config.get("trunk") in ("raw", "tf", "lstm") \
        else ROWS // 2 ** config["down"]
    return 256 if steps <= 125 else 32


def batches(count: int, size: int, rng, shuffle: bool = True):
    order = rng.permutation(count) if shuffle else np.arange(count)
    for start in range(0, count, size):
        yield order[start:start + size]


def predict(model, data: dict, index: np.ndarray, device, tail: int,
            batch: int = 256) -> dict:
    """Сирі виходи обох голів (логіти) для вікон `index` у їхньому порядку."""
    model.eval()
    index = np.sort(index)
    ladders, rows = [], []
    with torch.no_grad():
        for start in range(0, len(index), batch):
            _, (x, mask, numbers, _, _) = feed(
                data, index[start:start + batch], device, tail)
            ladder, row = model(x, mask, numbers)
            ladders.append(ladder.float().cpu().numpy())
            rows.append(row.float().cpu().numpy())
    if device.type == "mps":
        # кеш MPS після проходу без градієнта — інакше він лишається
        # зайнятим поверх памʼяті навчання
        torch.mps.empty_cache()
    return {"index": index, "ladder": np.concatenate(ladders),
            "rows": np.concatenate(rows)}


def auc(score: np.ndarray, truth: np.ndarray) -> float:
    truth = truth.astype(bool)
    if not truth.any() or truth.all():
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(len(score))
    sorted_score = score[order]
    _, start, counts = np.unique(sorted_score, return_index=True,
                                 return_counts=True)
    mean_rank = start + (counts + 1) / 2
    ranks[order] = np.repeat(mean_rank, counts)
    left = truth.sum()
    return float((ranks[truth].sum() - left * (left + 1) / 2)
                 / (left * (len(score) - left)))


def bce_np(logit: np.ndarray, y: np.ndarray) -> np.ndarray:
    return np.maximum(logit, 0) - logit * y + np.log1p(np.exp(-np.abs(logit)))


def measure(out: dict, data: dict, median: float, row_weight: float) -> dict:
    """Числа одного шматка: втрати, AUC кожної сходинки, AUC рядків,
    і ті самі AUC у лічильника — `n / медіана L train`."""
    index = out["index"]
    y = data["ladder"][index]
    q = data["q"][index]
    counter = data["bars"][index] / median
    mask = data["mask"][index]
    rows = data["rows"][index]
    ladder_loss = float(bce_np(out["ladder"], y).mean())
    row_loss = float((bce_np(out["rows"], rows) * mask).sum() / mask.sum())
    steps = {}
    for column, name in enumerate(NAMES):
        steps[name] = {"auc": auc(out["ladder"][:, column], y[:, column]),
                       "counter": auc(counter, y[:, column]),
                       "share": float(y[:, column].mean())}
    # рядки: лічильник ставить півот на рядок 500 · медіана / n
    where = (np.arange(ROWS)[None, :] / ROWS
             - 1 / np.maximum(counter, 1e-9)[:, None])
    live = mask.astype(bool)
    legs = np.unique(data["leg"][index])
    return {"windows": int(len(index)), "legs": int(len(legs)),
            "loss": ladder_loss + row_weight * row_loss,
            "ladder_loss": ladder_loss, "row_loss": row_loss,
            "steps": steps,
            "ladder_auc": float(np.nanmean([one["auc"]
                                            for one in steps.values()])),
            "ladder_auc_counter": float(np.nanmean(
                [one["counter"] for one in steps.values()])),
            "row_auc": auc(out["rows"][live], rows[live]),
            "row_auc_counter": auc(where[live], rows[live]),
            "row_share": float(rows[live].mean()),
            "q_mean": float(q.mean())}


def leg_split(data: dict, share: float, seed: int) -> tuple:
    legs = np.unique(data["leg"])
    rng = np.random.default_rng(seed)
    held = rng.choice(legs, size=max(int(len(legs) * share), 1),
                      replace=False)
    pick = np.isin(data["leg"], held)
    return np.flatnonzero(~pick), np.flatnonzero(pick)


def train(config: dict, data: dict, device, tag: str, seed: int = SEED,
          keep_outputs: bool = False, every: Path | None = None,
          log=print, stop_after: int = 0) -> dict:
    """Один прогін; з `every` ваги кожної епохи лягають у цю теку.

    Після кожної епохи повний стан — ваги, оптимізатор, генератори
    випадкових чисел, історія й найкраща епоха — лягає в
    `runs/<тег>.state.pt`; прогін з тим самим тегом продовжує з нього
    так, ніби не зупинявся. `stop_after` — зупинитись після цієї епохи
    (повертає `None`), стан лишається для продовження."""
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    inside, held = leg_split(data["train"], HOLDOUT, seed)
    # медіана довжини ноги — по одній на ногу, лише ноги навчання
    _, first = np.unique(data["train"]["leg"][inside], return_index=True)
    median = float(np.median(data["train"]["length"][inside][first]))
    channels = data["train"]["x"].shape[2]
    model = net_of(channels, config).to(device)
    optimizer = optimizer_of(model, config)
    history, best = [], None
    path = DATA / KEY / "runs" / f"{tag}.pt"
    path.parent.mkdir(parents=True, exist_ok=True)
    state_path = path.with_suffix(".state.pt")
    start = 1
    if state_path.exists():
        state = torch.load(state_path, map_location=device,
                           weights_only=False)
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        torch.set_rng_state(state["torch"])
        rng.bit_generator.state = state["numpy"]
        history, best = state["history"], state["best"]
        start = len(history) + 1
        log(f"{tag}: продовження з епохи {start}")
    for epoch in range(start, config["epochs"] + 1):
        model.train()
        started, total = time.time(), 0.0
        for piece in batches(len(inside), config["batch"], rng):
            _, (x, mask, numbers, y_ladder, y_rows) = feed(
                data["train"], inside[piece], device, config["tail"])
            optimizer.zero_grad()
            loss = step_loss(model, x, mask, numbers, y_ladder, y_rows,
                             config["row_weight"], config.get("chunk", 0))
            optimizer.step()
            total += loss * len(piece)
        got = measure(predict(model, data["train"], held, device,
                              config["tail"], eval_batch(config)),
                      data["train"], median, config["row_weight"])
        step = {"epoch": epoch, "train_loss": total / len(inside),
                "holdout_loss": got["loss"], "ladder_auc": got["ladder_auc"],
                "row_auc": got["row_auc"],
                "seconds": round(time.time() - started, 1)}
        history.append(step)
        log(f"{tag} епоха {epoch:2d}: втрата {step['train_loss']:.4f}, "
            f"відкладені {got['loss']:.4f}, AUC сходинок "
            f"{got['ladder_auc']:.3f} (лічильник "
            f"{got['ladder_auc_counter']:.3f}), AUC рядків "
            f"{got['row_auc']:.3f}, {step['seconds']} c")
        if every is not None:
            every.mkdir(parents=True, exist_ok=True)
            torch.save(model.state_dict(), every / f"epoch_{epoch:02d}.pt")
        if best is None or got["loss"] < best["holdout_loss"]:
            best = step
            torch.save(model.state_dict(), path)
        torch.save({"model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "torch": torch.get_rng_state(),
                    "numpy": rng.bit_generator.state,
                    "history": history, "best": best}, state_path)
        if config.get("patience") and \
                epoch - best["epoch"] >= config["patience"]:
            log(f"{tag}: {config['patience']} епохи без покращення — стоп, "
                f"найкраща {best['epoch']}")
            break
        if stop_after and epoch >= stop_after and epoch < config["epochs"]:
            log(f"{tag}: пауза після епохи {epoch}, стан — {state_path.name}")
            return None, model
    state_path.unlink(missing_ok=True)
    model.load_state_dict(torch.load(path, map_location=device))
    out = {"tag": tag, "config": config, "seed": seed, "median": median,
           "epochs": history, "best_epoch": best["epoch"],
           "parameters": int(sum(p.numel() for p in model.parameters()))}
    val_index = np.arange(len(data["val"]["q"]))
    for name, part, index in (("train", "train", inside),
                              ("holdout", "train", held),
                              ("val", "val", val_index)):
        raw = predict(model, data[part], index, device, config["tail"],
                      eval_batch(config))
        out[name] = measure(raw, data[part], median, config["row_weight"])
        if keep_outputs:
            out.setdefault("raw", {})[name] = raw
    return out, model


def run_one(config: dict, data: dict, device, tag: str, log=print,
            stop_after: int = 0, every: Path | None = None) -> dict:
    RESULTS.mkdir(parents=True, exist_ok=True)
    out, _ = train(config, data, device, tag, log=log, stop_after=stop_after,
                   every=every)
    if out is None:
        return None
    write_json(RESULTS / f"{tag}.json", out)
    one = out["holdout"]
    log(f"== {tag}: епоха {out['best_epoch']}, відкладені втрата "
        f"{one['loss']:.4f}, AUC сходинок {one['ladder_auc']:.3f}, "
        f"рядків {one['row_auc']:.3f}; val втрата {out['val']['loss']:.4f}")
    return out


def plain_loss(run: dict) -> float:
    """Відкладена втрата з вагою рядків 1: прогони з різною `row_weight`
    зводяться на одну шкалу — інакше мала вага виграє саму себе."""
    return run["holdout"]["ladder_loss"] + run["holdout"]["row_loss"]


def best_of(prefix: str) -> dict:
    """Кращий прогін кола — за незваженою втратою на відкладених ногах."""
    runs = [json.loads(path.read_text()) for path in
            sorted(RESULTS.glob(f"{prefix}*.json"))]
    return min(runs, key=plain_loss)


def tag_of(prefix: str, config: dict) -> str:
    return (f"{prefix}_w{config['width']}_d{config['down']}_l"
            f"{config['layers']}_lr{config['lr']:g}_do{config['dropout']:g}"
            f"_rw{config['row_weight']:g}_e{config['epochs']}"
            f"_t{config['tail']}"
            + (f"_{config['trunk']}" if config.get("trunk") in
               ("raw", "flat", "mixer", "lstm", "tf") else "")
            + "".join(f"_{short}{config[key]:g}" for key, short in
                      (("tokens", "tk"), ("wd", "wd"), ("in_drop", "id"),
                       ("pool", "p"), ("heads", "h"), ("patience", "pt"))
                      if config.get(key))
            + ("_nm" if config.get("no_mask") else "")
            + ("_nc" if config.get("no_column") else ""))


AROUND = 2                 # епох по кожен бік від найкращої на вкладці
SERIES_BINS = 50           # рядки канви у ряді — по 10 рядків у клітинці


def pair_of(data: dict) -> np.ndarray:
    return np.array([str(name).split("·")[0] for name in data["name"]])


def by_pair(raw: dict, data: dict, median: float, row_weight: float) -> dict:
    """Числа val кожної монети окремо і всіх разом."""
    pairs = pair_of(data)[raw["index"]]
    out = {"all": measure(raw, data, median, row_weight)}
    for pair in np.unique(pairs):
        pick = pairs == pair
        out[str(pair)] = measure({key: value[pick] for key, value in
                                  raw.items()}, data, median, row_weight)
    return out


def series_outputs(raw: dict) -> dict:
    """Ряд для вкладки: сходинки ймовірностями, рядки — середня
    ймовірність у кожній з `SERIES_BINS` клітинок канви."""
    ladder = 1 / (1 + np.exp(-raw["ladder"]))
    rows = 1 / (1 + np.exp(-raw["rows"]))
    rows = rows.reshape(len(rows), SERIES_BINS, -1).mean(axis=2)
    return {"index": raw["index"], "ladder": ladder.astype(np.float16),
            "rows": rows.astype(np.float16)}


def save_final(out: dict, config: dict, every: Path, data: dict,
               series: dict | None, device, log=print) -> Path:
    """Фінальна модель: найкраща епоха і по `AROUND` з кожного боку —
    ваги, налаштування, числа val по монетах і сирі виходи."""
    folder = MODELS / "fullness30_v1"
    folder.mkdir(parents=True, exist_ok=True)
    best = out["best_epoch"]
    keep = [epoch for epoch in range(best - AROUND, best + AROUND + 1)
            if 1 <= epoch <= config["epochs"]]
    model = net_of(data["train"]["x"].shape[2], config).to(device)
    report = {"best_epoch": best, "epochs": keep, "val": {}}
    for epoch in keep:
        state = torch.load(every / f"epoch_{epoch:02d}.pt",
                           map_location=device)
        torch.save(state, folder / f"epoch_{epoch:02d}.pt")
        model.load_state_dict(state)
        raw = predict(model, data["val"], np.arange(len(data["val"]["q"])),
                      device, config["tail"])
        report["val"][str(epoch)] = by_pair(raw, data["val"], out["median"],
                                            config["row_weight"])
        np.savez(RESULTS / f"final_outputs_val_e{epoch:02d}.npz",
                 index=raw["index"], ladder=raw["ladder"].astype(np.float32),
                 rows=raw["rows"].astype(np.float16))
        if series is not None:
            got = series_outputs(predict(model, series,
                                         np.arange(len(series["q"])),
                                         device, config["tail"]))
            np.savez(RESULTS / f"series_val_e{epoch:02d}.npz", **got)
        log(f"епоха {epoch}: val AUC сходинок "
            f"{report['val'][str(epoch)]['all']['ladder_auc']:.3f}, "
            f"рядків {report['val'][str(epoch)]['all']['row_auc']:.3f}")
    torch.save(torch.load(folder / f"epoch_{best:02d}.pt"), folder / "model.pt")
    (folder / "config.json").write_text(json.dumps(
        {"config": config, "key": KEY, "thresholds": list(THRESHOLDS),
         "names": NAMES, "rows": ROWS, "median": out["median"],
         "best_epoch": best, "epochs": keep, "seed": out["seed"]},
        ensure_ascii=False, indent=1))
    write_json(RESULTS / "final_epochs.json", report)
    return folder


def epochs_of(tag: str) -> Path:
    """Тека з вагами кожної епохи прогону."""
    return DATA / KEY / "runs" / f"{tag}_epochs"


def save_run_outputs(tag: str, data: dict, series: dict, device,
                     log=print) -> None:
    """Видача прогону `tag` на val для вкладки `/seq30` — найкраща епоха
    і по `AROUND` з кожного боку (ваги з `runs/<тег>_epochs/`, якщо
    їх немає — тільки найкраща з `runs/<тег>.pt`): числа по монетах і ряд
    val кожної епохи — ті самі файли, що `save_final` пише для обраної
    моделі."""
    run = json.loads((RESULTS / f"{tag}.json").read_text())
    config = run["config"]
    best = run["best_epoch"]
    folder = epochs_of(tag)
    done = len(run["epochs"])
    keep = [epoch for epoch in range(best - AROUND, best + AROUND + 1)
            if 1 <= epoch <= done
            and (folder / f"epoch_{epoch:02d}.pt").exists()] or [best]
    model = net_of(data["val"]["x"].shape[2], config).to(device)
    batch = eval_batch(config)
    report = {"tag": tag, "best_epoch": best, "epochs": keep, "val": {}}
    for epoch in keep:
        weights = folder / f"epoch_{epoch:02d}.pt"
        if not weights.exists():
            weights = DATA / KEY / "runs" / f"{tag}.pt"
        model.load_state_dict(torch.load(weights, map_location=device))
        raw = predict(model, data["val"], np.arange(len(data["val"]["q"])),
                      device, config["tail"], batch=batch)
        val = by_pair(raw, data["val"], run["median"], config["row_weight"])
        report["val"][str(epoch)] = val
        got = series_outputs(predict(model, series,
                                     np.arange(len(series["q"])),
                                     device, config["tail"], batch=batch))
        np.savez(RESULTS / f"seq30_{tag}_series_val_e{epoch:02d}.npz", **got)
        log(f"{tag} епоха {epoch}: val AUC сходинок "
            f"{val['all']['ladder_auc']:.3f}, рядків {val['all']['row_auc']:.3f}")
    write_json(RESULTS / f"seq30_{tag}.json", report)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--grid", type=int, choices=range(1, 13),
                        default=None)
    parser.add_argument("--only", choices=GRID4_NAMES, default=None)
    parser.add_argument("--final", action="store_true")
    parser.add_argument("--stop-after", type=int, default=0,
                        help="пауза після цієї епохи (коло 12)")
    parser.add_argument("--outputs", default=None,
                        help="тег прогону: видача на val для /seq30")
    parser.add_argument("--tail", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    picked = [change for name, change in zip(GRID4_NAMES, GRID4)
              if args.only in (None, name)]
    wide = args.grid == 4 and any(change.get("down") == 0
                                  for change in picked)
    no_swap(MEMORY_NEED_500 if wide and not CHUNK_500 else MEMORY_NEED,
            args.force)
    device = device_of(args.device)
    data = {part: load(DATA / KEY, part) for part in ("train", "val")}
    print(f"пристрій {device}, вікон train {len(data['train']['q'])}, "
          f"val {len(data['val']['q'])}", flush=True)
    log = lambda text: print(text, flush=True)
    if args.outputs:
        series = load(DATA / KEY, "series_val")
        save_run_outputs(args.outputs, data, series, device, log)
    elif args.grid == 1:
        for change in GRID1:
            config = {**BASE, **change}
            run_one(config, data, device, tag_of("g1", config), log)
    elif args.grid == 2:
        base = best_of("g1")["config"]
        for change in GRID2:
            config = {**base, **change}
            run_one(config, data, device, tag_of("g2", config), log)
    elif args.grid == 3:
        base = min((best_of("g1"), best_of("g2")), key=plain_loss)["config"]
        config = {**base, "epochs": LONG}
        run_one(config, data, device, tag_of("g3", config), log)
    elif args.grid == 4:
        base = json.loads((MODELS / "fullness30_v1" / "config.json")
                          .read_text())["config"]
        for change in picked:
            config = {**base, "epochs": BASE["epochs"], **change}
            if change.get("down") == 0:
                # 500 кроків уваги: батч 64 двома шматками по 32
                config["chunk"] = CHUNK_500
            run_one(config, data, device, tag_of("g4", config), log)
    elif args.grid in (5, 7):
        base = {**json.loads((MODELS / "fullness30_v1" / "config.json")
                             .read_text())["config"], "epochs": LONG_WHOLE}
        for change in GRID5 if args.grid == 5 else GRID7:
            config = {**base, **change}
            tag = tag_of(f"g{args.grid}", config)
            if (RESULTS / f"{tag}.json").exists():
                continue
            run_one(config, data, device, tag, log)
    elif args.grid in (6, 8):
        base = best_of(f"g{args.grid - 1}_")["config"]
        for change in GRID6 if args.grid == 6 else GRID8:
            config = {**base, **change}
            tag = tag_of(f"g{args.grid}", config)
            if (RESULTS / f"{tag}.json").exists():
                continue
            run_one(config, data, device, tag, log)
    elif args.grid in (9, 10):
        base = {**json.loads((MODELS / "fullness30_v1" / "config.json")
                             .read_text())["config"], "epochs": LONG_SEQ}
        for change in GRID9 if args.grid == 9 else GRID10:
            config = {**base, **change}
            if change["trunk"] == "tf":
                config["chunk"] = CHUNK_500
            tag = tag_of(f"g{args.grid}", config)
            if (RESULTS / f"{tag}.json").exists():
                continue
            run_one(config, data, device, tag, log)
    elif args.grid == 11:
        chosen = json.loads((MODELS / "fullness30_v1" / "config.json")
                            .read_text())["config"]
        bases = [{**chosen, "epochs": BASE["epochs"]}] + [
            best_of(prefix)["config"] for prefix in ("g9_", "g10_", "g8_")
            if list(RESULTS.glob(f"{prefix}*.json"))]
        for base in bases:
            config = {**base, "no_mask": True}
            if config.get("trunk") == "tf":
                config["chunk"] = CHUNK_500
            tag = tag_of("g11", config)
            if (RESULTS / f"{tag}.json").exists():
                continue
            run_one(config, data, device, tag, log)
    elif args.grid == 12:
        base = {**json.loads((MODELS / "fullness30_v1" / "config.json")
                             .read_text())["config"], "epochs": LONG_SEQ}
        for change in GRID12:
            config = {**base, **change, "chunk": CHUNK_DEEP}
            tag = tag_of("g12", config)
            if (RESULTS / f"{tag}.json").exists():
                continue
            # ваги кожної епохи — для видачі найкращої ± AROUND на /seq30
            run_one(config, data, device, tag, log, args.stop_after,
                    every=epochs_of(tag))
    elif args.tail:
        base = json.loads((MODELS / "fullness30_v1" / "config.json")
                          .read_text())["config"]
        config = {**base, "tail": args.tail}
        run_one(config, data, device, tag_of("tail", config), log)
    elif args.final:
        chosen = min((best_of("g1"), best_of("g2"), best_of("g3")),
                     key=plain_loss)
        # на AROUND епох далі за найкращу — щоб вкладка бачила і їх
        config = {**chosen["config"],
                  "epochs": chosen["best_epoch"] + AROUND}
        every = DATA / KEY / "runs" / "final_epochs"
        out, _ = train(config, data, device, "final", every=every, log=log)
        write_json(RESULTS / "final.json", out)
        series_path = DATA / KEY / "series_val.npz"
        series = load(DATA / KEY, "series_val") if series_path.exists() \
            else None
        folder = save_final(out, config, every, data, series, device, log)
        log(f"фінальна модель: {folder}")


if __name__ == "__main__":
    main()
