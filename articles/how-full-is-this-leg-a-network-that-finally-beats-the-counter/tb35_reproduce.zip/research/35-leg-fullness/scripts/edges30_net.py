"""Етап 8: мережа знаходить на канві півоти зігзага 2.3 % — рядок за рядком.

Дослідження: research/35-leg-fullness/ → Етап 8

## Хід

1. Вікна — `edges30_data.py` (`data/edges30/<part>_x.npy`, `<part>.npz`):
   канва 500 × 7 без стовпця маски, чотири скаляри, мітка рядка
   (1 — нога завершилась: 95 … 105 % тривалості ноги і ціна ближче 10 %
   її цінової довжини до півота в канві; 0 — поза зонами; −1 — зона
   півота поза канвою) і відстань рядка від зони.
2. **Мережа** — трансформер на 500 рядках, як на `/seq30`: рядок + 4
   скаляри → лінійно в ширину 64, вивчена позиція кожного рядка, 2 шари
   уваги по 4 голови (norm first, ff 128, dropout 0) → на кожен рядок
   один логіт «тут півот».
3. **Втрата** — BCE по живих рядках з вагами: рядок зони — `POS_WEIGHT`,
   рядок поза зонами — `1 + min(відстань, PENALTY_CAP)`: що далі за ціною
   від зони, то дорожче; рядок з міткою −1 і мертвий рядок — 0.
4. **Сигнал** — пік видачі: рядок з імовірністю ≥ порогу, найбільшою в
   ±`PEAK` рядках. Сигнал **добрий**, коли рядок у зоні півота канви.
   Точність — частка добрих сигналів; повнота — частка півотів канви,
   у зоні яких є сигнал; F1. Поріг — найкращий F1 на відкладених ногах.
5. **Відкладені** — 20 % ніг train (seed 0), за ними епоха й поріг; val —
   тільки замір. Adam lr 1e-3, батч 64, до перенавчання: стоп після 2
   епох без покращення втрати на відкладених, стеля 30.
6. **Видача на val** (`--outputs`) — найкраща епоха ± 2: міри по
   монетах на вікнах val і ряд val — ковзні вікна без розмітки
   (`edges30_data.py --series`), імовірність запису — найбільша з вікон,
   сигнали — піки ряду.

Запуск:
    python3 research/35-leg-fullness/scripts/edges30_net.py
    python3 research/35-leg-fullness/scripts/edges30_net.py --outputs
    python3 research/35-leg-fullness/scripts/edges30_net.py --grid

Грід штрафів (`--grid`): з ваг епохи `GRID_FROM` донавчання на кожній парі
`pos` (вага рядка зони — ціна пропуску) × `slope` (вага хибного рядка
`1 + slope · min(відстань, 9)`), lr 3e-4, до 4 епох, стоп після 2 без
покращення F1 на відкладених; епоха й поріг — за F1 відкладених, val —
тільки замір. Вихід: models/edges30/grid/<ім'я>/epoch_NN.pt,
results/edges30/grid.json.

Вихід: models/edges30/epoch_NN.pt, history.json; results/edges30/
val_eNN.json, series_<PAIR>_eNN.npz.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
for extra in (PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts",
              Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

DATA = RESEARCH_DIR / "data" / "edges30"
MODELS = RESEARCH_DIR / "models" / "edges30"
RESULTS = RESEARCH_DIR / "results" / "edges30"
ROWS = 500
WIDTH, HEADS, LAYERS = 64, 4, 2
LR, BATCH = 1e-3, 64
EPOCHS, PATIENCE = 30, 2
POS_WEIGHT = 3.0
PENALTY_CAP = 9.0
PEAK = 10                       # рядків з кожного боку піку
PEAK_BARS = 60                  # записів з кожного боку піку на ряді
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
HOLDOUT, SEED = 0.2, 0
AROUND = 2
MEMORY_NEED = 1200
# грід штрафів з найкращої епохи: ціна пропуску зони × ціна хибного рядка
GRID_FROM = 6
GRID_POS = (1.0, 3.0, 10.0, 30.0)
GRID_SLOPE = (0.0, 1.0, 3.0)
GRID_LR = 3e-4
GRID_EPOCHS = 4


class Finder(nn.Module):
    """Трансформер на 500 рядках канви: на кожен рядок — логіт «тут півот»."""

    def __init__(self, channels: int = 7, scalars: int = 4,
                 width: int = WIDTH, heads: int = HEADS,
                 layers: int = LAYERS):
        super().__init__()
        self.embed = nn.Linear(channels + scalars, width)
        self.position = nn.Parameter(torch.randn(1, ROWS, width) * 0.02)
        layer = nn.TransformerEncoderLayer(width, heads, 2 * width,
                                           dropout=0.0, batch_first=True,
                                           norm_first=True)
        self.trunk = nn.TransformerEncoder(layer, layers,
                                           enable_nested_tensor=False)
        self.norm = nn.LayerNorm(width)
        self.head = nn.Linear(width, 1)

    def forward(self, x: torch.Tensor, numbers: torch.Tensor) -> torch.Tensor:
        joined = torch.cat([x, numbers[:, None, :].expand(-1, x.shape[1], -1)],
                           dim=2)
        h = self.trunk(self.embed(joined) + self.position[:, :x.shape[1]])
        return self.head(self.norm(h)).squeeze(2)


def scalars_of(raw: np.ndarray) -> np.ndarray:
    count, step, move, live = np.asarray(raw, dtype=np.float32).T
    return np.stack([count / 8.0, step / 8.0, move * 10.0, live],
                    axis=1).astype(np.float32)


def weights_of(label: np.ndarray, distance: np.ndarray,
               mask: np.ndarray, pos: float = POS_WEIGHT,
               slope: float = 1.0, cap: float = PENALTY_CAP) -> np.ndarray:
    """Вага рядка у втраті: зона — `pos`, поза зонами — `1 + slope ·
    min(відстань, cap)`, зона півота поза канвою й мертвий рядок — 0."""
    out = np.where(label == 1, pos,
                   np.where(label == 0,
                            1.0 + slope * np.minimum(distance, cap), 0.0))
    return (out * mask).astype(np.float32)


def loss_of(logits: torch.Tensor, label: torch.Tensor,
            weight: torch.Tensor) -> torch.Tensor:
    each = F.binary_cross_entropy_with_logits(
        logits, (label == 1).float(), reduction="none")
    return (each * weight).sum() / weight.sum().clamp(min=1e-6)


def peaks(prob: np.ndarray, mask: np.ndarray, threshold: float,
          span: int = PEAK) -> np.ndarray:
    """Піки видачі `(N, 500)` → булева матриця сигналів: імовірність ≥
    порогу і найбільша в ±`span` рядках; з рівних — перший."""
    p = np.where(mask, prob, -1.0)
    padded = np.pad(p, ((0, 0), (span, span)), constant_values=-1.0)
    view = np.lib.stride_tricks.sliding_window_view(padded, 2 * span + 1,
                                                    axis=1)
    top = view.max(axis=2)
    first = view.argmax(axis=2) == span
    return (p >= threshold) & (p >= top) & first


def score(signal: np.ndarray, label: np.ndarray, owner: np.ndarray) -> dict:
    """Точність, повнота й F1 сигналів на вікнах."""
    signals = int(signal.sum())
    good = int((signal & (label == 1)).sum())
    total = found = 0
    for row_signal, row_owner in zip(signal, owner):
        owners = set(row_owner[row_owner >= 0].tolist())
        total += len(owners)
        found += len(owners & set(row_owner[row_signal].tolist()))
    precision = good / signals if signals else float("nan")
    recall = found / total if total else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if signals and total and precision + recall > 0 else 0.0)
    return {"signals": signals, "good": good, "pivots": total,
            "found": found, "precision": precision, "recall": recall,
            "f1": f1, "per_window": signals / max(len(signal), 1)}


def best_threshold(prob: np.ndarray, data: dict) -> tuple:
    scores = {float(t): score(peaks(prob, data["mask"], t), data["label"],
                              data["owner"]) for t in THRESHOLDS}
    best = max(scores, key=lambda t: scores[t]["f1"])
    return best, scores[best]


def load(part: str, folder: Path = DATA) -> dict:
    store = np.load(folder / f"{part}.npz")
    out = {name: store[name] for name in store.files}
    out["x"] = np.load(folder / f"{part}_x.npy", mmap_mode="r")
    out["numbers"] = scalars_of(out["scalars"])
    if "label" in out:
        out["weight"] = weights_of(out["label"], out["distance"],
                                   out["mask"])
    return out


def split(legs: np.ndarray, share: float = HOLDOUT, seed: int = SEED) -> tuple:
    unique = np.unique(legs)
    rng = np.random.default_rng(seed)
    held = set(rng.choice(unique, int(round(share * len(unique))),
                          replace=False).tolist())
    mask = np.array([leg in held for leg in legs])
    return np.flatnonzero(~mask), np.flatnonzero(mask)


def device_of(name: str = "auto") -> torch.device:
    if name != "auto":
        return torch.device(name)
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def predict(model: Finder, x: np.ndarray, numbers: np.ndarray,
            device: torch.device, batch: int = 128) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(x), batch):
            logits = model(
                torch.from_numpy(np.asarray(x[start:start + batch])).to(device),
                torch.from_numpy(numbers[start:start + batch]).to(device))
            out.append(torch.sigmoid(logits).float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS), np.float32)


def part_loss(model: Finder, data: dict, index: np.ndarray,
              device: torch.device) -> tuple:
    """Зважена втрата і видача на вікнах `index` (упорядкованих)."""
    index = np.sort(index)
    prob = predict(model, data["x"][index], data["numbers"][index], device)
    p = np.clip(prob, 1e-6, 1 - 1e-6)
    target = data["label"][index] == 1
    each = -(target * np.log(p) + (~target) * np.log(1 - p))
    weight = data["weight"][index]
    return float((each * weight).sum() / weight.sum()), prob, index


def subset(data: dict, index: np.ndarray) -> dict:
    return {name: data[name][index] for name in ("mask", "label", "owner")}


def train(data: dict, device: torch.device, log=print,
          epochs: int = EPOCHS, patience: int = PATIENCE,
          folder: Path = MODELS) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    inside, held = split(data["train"]["leg"])
    folder.mkdir(parents=True, exist_ok=True)
    model = Finder().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    train_part = data["train"]
    history, best = [], None
    for epoch in range(1, epochs + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for start in range(0, len(order), BATCH):
            pick = np.sort(order[start:start + BATCH])
            x = torch.from_numpy(np.asarray(train_part["x"][pick])).to(device)
            numbers = torch.from_numpy(train_part["numbers"][pick]).to(device)
            label = torch.from_numpy(train_part["label"][pick]).to(device)
            weight = torch.from_numpy(train_part["weight"][pick]).to(device)
            loss = loss_of(model(x, numbers), label, weight)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total += float(loss) * len(pick)
            count += len(pick)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        held_loss, held_prob, held_index = part_loss(model, train_part, held,
                                                     device)
        threshold, held_score = best_threshold(
            held_prob, subset(train_part, held_index))
        val = data["val"]
        val_loss, val_prob, _ = part_loss(model, val,
                                          np.arange(len(val["label"])), device)
        val_score = score(peaks(val_prob, val["mask"], threshold),
                          val["label"], val["owner"])
        step = {"epoch": epoch, "train_loss": total / count,
                "holdout_loss": held_loss, "threshold": threshold,
                "holdout": held_score, "val_loss": val_loss, "val": val_score,
                "seconds": round(time.time() - started, 1)}
        history.append(step)
        log(f"епоха {epoch:2d}: втрата {step['train_loss']:.4f}, відкладені "
            f"{held_loss:.4f} (поріг {threshold:.2f}: точність "
            f"{held_score['precision']:.3f}, повнота {held_score['recall']:.3f}, "
            f"F1 {held_score['f1']:.3f}), val {val_loss:.4f} (точність "
            f"{val_score['precision']:.3f}, повнота {val_score['recall']:.3f}, "
            f"F1 {val_score['f1']:.3f}), {step['seconds']} c")
        if best is None or held_loss < best["holdout_loss"]:
            best = step
        write_history(folder, history, best)
        if epoch - best["epoch"] >= patience:
            log(f"{patience} епохи без покращення — стоп, найкраща "
                f"{best['epoch']}")
            break
    return {"history": history, "best": best}


def clean(value):
    if isinstance(value, float):
        return value if np.isfinite(value) else None
    if isinstance(value, dict):
        return {key: clean(one) for key, one in value.items()}
    if isinstance(value, list):
        return [clean(one) for one in value]
    return value


def write_history(folder: Path, history: list, best: dict) -> None:
    (folder / "history.json").write_text(json.dumps(clean({
        "config": {"width": WIDTH, "heads": HEADS, "layers": LAYERS,
                   "lr": LR, "batch": BATCH, "pos_weight": POS_WEIGHT,
                   "penalty_cap": PENALTY_CAP, "peak": PEAK,
                   "patience": PATIENCE, "epochs": EPOCHS, "seed": SEED},
        "best_epoch": best["epoch"], "history": history}),
        ensure_ascii=False, indent=1), encoding="utf-8")


def model_of(epoch: int, device: torch.device,
             folder: Path = MODELS) -> Finder:
    model = Finder().to(device)
    model.load_state_dict(torch.load(folder / f"epoch_{epoch:02d}.pt",
                                     map_location=device))
    model.eval()
    return model


def record_zones(close: np.ndarray, pivots: dict) -> np.ndarray:
    """Номер півота, у зоні якого запис (95 … 105 % тривалості ноги і
    ціна ближче 10 % її цінової довжини); −1 — поза зонами."""
    owner = np.full(len(close), -1, dtype=np.int64)
    for number, p in enumerate(pivots["index"]):
        reach = int(np.floor(max(pivots["span"][number], 0.5)))
        span = np.arange(max(p - reach, 0), min(p + reach, len(close) - 1) + 1)
        gap = (pivots["price"][number] - close[span] if pivots["top"][number]
               else close[span] - pivots["price"][number])
        owner[span[gap <= pivots["zone"][number]]] = number
    return owner


def series_signals(prob: np.ndarray, threshold: float,
                   span: int = PEAK_BARS) -> np.ndarray:
    """Піки ряду: запис з імовірністю ≥ порогу, найбільшою в ±`span`."""
    mask = np.isfinite(prob)[None]
    return np.flatnonzero(peaks(np.nan_to_num(prob, nan=-1.0)[None], mask,
                                threshold, span)[0])


def outputs(device: torch.device, log=print, folder: Path = MODELS,
            data_dir: Path = DATA, results: Path = RESULTS) -> None:
    """Видача найкращої епохи ± 2 на val: міри по монетах і ряд val."""
    import edges30_data as d
    from bars30 import DATA as BARS
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    best = history["best_epoch"]
    epochs = [one["epoch"] for one in history["history"]
              if abs(one["epoch"] - best) <= AROUND]
    thresholds = {one["epoch"]: one["threshold"] for one in history["history"]}
    val = load("val", data_dir)
    series = load("series", data_dir) if (data_dir / "series.npz").exists() \
        else None
    table = json.loads((BARS / "legs.json").read_text(encoding="utf-8"))
    results.mkdir(parents=True, exist_ok=True)
    report = {"best_epoch": best, "epochs": epochs, "val": {}}
    for epoch in epochs:
        model = model_of(epoch, device, folder)
        threshold = thresholds[epoch]
        prob = predict(model, val["x"], val["numbers"], device)
        signal = peaks(prob, val["mask"], threshold)
        by_pair = {"all": score(signal, val["label"], val["owner"])}
        for pair in np.unique(val["pair"]):
            pick = val["pair"] == pair
            by_pair[str(pair)] = score(signal[pick], val["label"][pick],
                                       val["owner"][pick])
        report["val"][str(epoch)] = {"threshold": threshold,
                                     "by_pair": by_pair}
        if series is not None:
            sprob = predict(model, series["x"], series["numbers"], device)
            for pair in np.unique(series["pair"]):
                pick = np.flatnonzero(series["pair"] == pair)
                with np.load(BARS / f"{pair}_val.npz") as store:
                    stamps, close = store["t"], store["close"]
                curve = np.full(len(stamps), np.nan)
                for one in pick:
                    start = series["start"][one]
                    rows = series["first"][one] >= 0
                    for row in np.flatnonzero(rows):
                        a = start + series["first"][one][row]
                        b = start + series["last"][one][row]
                        value = sprob[one][row]
                        current = curve[a:b + 1]
                        curve[a:b + 1] = np.where(
                            np.isnan(current) | (current < value), value,
                            current)
                pivots = d.pivots_of(table["legs"][str(pair)]["val"], close)
                zones = record_zones(close, pivots)
                signals = series_signals(curve, threshold)
                owner = zones[signals]
                total = len(pivots["index"])
                found = len(set(owner[owner >= 0].tolist()))
                good = int((owner >= 0).sum())
                precision = good / len(signals) if len(signals) else float("nan")
                recall = found / total if total else float("nan")
                report["val"][str(epoch)].setdefault("series", {})[str(pair)] = {
                    "signals": int(len(signals)), "good": good,
                    "pivots": total, "found": found, "precision": precision,
                    "recall": recall,
                    "f1": (2 * precision * recall / (precision + recall)
                           if len(signals) and precision + recall > 0 else 0.0)}
                np.savez_compressed(
                    results / f"series_{pair}_e{epoch:02d}.npz",
                    prob=curve.astype(np.float16), signals=signals,
                    good=owner >= 0, pivots=pivots["index"],
                    top=pivots["top"], zone=pivots["zone"],
                    span=pivots["span"],
                    threshold=np.float32(threshold))
        log(f"епоха {epoch}: val F1 {by_pair['all']['f1']:.3f}")
    (results / "val.json").write_text(json.dumps(clean(report),
                                                 ensure_ascii=False, indent=1),
                                      encoding="utf-8")


def grid_name(pos: float, slope: float) -> str:
    return f"pos{pos:g}_slope{slope:g}"


def tune(data: dict, device: torch.device, pos: float, slope: float,
         folder: Path, log=print, start: int = GRID_FROM,
         epochs: int = GRID_EPOCHS, patience: int = PATIENCE) -> dict:
    """Донавчання з епохи `start` на втраті з вагами `pos` і `slope`;
    епоха — найкращий F1 на відкладених ногах, val — тільки замір."""
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    train_part, val = data["train"], data["val"]
    inside, held = split(train_part["leg"])
    weight = weights_of(train_part["label"], train_part["distance"],
                        train_part["mask"], pos, slope)
    folder.mkdir(parents=True, exist_ok=True)
    model = model_of(start, device)
    optimizer = torch.optim.Adam(model.parameters(), lr=GRID_LR)
    history, best = [], None
    for epoch in range(1, epochs + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for first in range(0, len(order), BATCH):
            pick = np.sort(order[first:first + BATCH])
            x = torch.from_numpy(np.asarray(train_part["x"][pick])).to(device)
            numbers = torch.from_numpy(train_part["numbers"][pick]).to(device)
            label = torch.from_numpy(train_part["label"][pick]).to(device)
            w = torch.from_numpy(weight[pick]).to(device)
            loss = loss_of(model(x, numbers), label, w)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total += float(loss) * len(pick)
            count += len(pick)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        held_index = np.sort(held)
        held_prob = predict(model, train_part["x"][held_index],
                            train_part["numbers"][held_index], device)
        threshold, held_score = best_threshold(
            held_prob, subset(train_part, held_index))
        val_prob = predict(model, val["x"], val["numbers"], device)
        val_score = score(peaks(val_prob, val["mask"], threshold),
                          val["label"], val["owner"])
        step = {"epoch": epoch, "train_loss": total / count,
                "threshold": threshold, "holdout": held_score,
                "val": val_score,
                "val_p99": float(np.percentile(val_prob[val["mask"]], 99)),
                "val_max": float(val_prob[val["mask"]].max()),
                "seconds": round(time.time() - started, 1)}
        history.append(step)
        log(f"{grid_name(pos, slope)} епоха {epoch}: поріг {threshold:.2f}, "
            f"відкладені F1 {held_score['f1']:.3f}, val точність "
            f"{val_score['precision']:.3f} повнота {val_score['recall']:.3f} "
            f"F1 {val_score['f1']:.3f}, p99 {step['val_p99']:.3f}, "
            f"{step['seconds']} c")
        if best is None or held_score["f1"] > best["holdout"]["f1"]:
            best = step
        if epoch - best["epoch"] >= patience:
            break
    return {"pos": pos, "slope": slope, "best_epoch": best["epoch"],
            "history": history}


def grid(data: dict, device: torch.device, log=print,
         folder: Path = MODELS / "grid", results: Path = RESULTS) -> dict:
    """Грід штрафів `GRID_POS × GRID_SLOPE` з епохи `GRID_FROM`."""
    results.mkdir(parents=True, exist_ok=True)
    path = results / "grid.json"
    report = (json.loads(path.read_text(encoding="utf-8")) if path.exists()
              else {"runs": {}})
    report["config"] = {"from": GRID_FROM, "pos": list(GRID_POS),
                        "slope": list(GRID_SLOPE), "cap": PENALTY_CAP,
                        "lr": GRID_LR, "epochs": GRID_EPOCHS,
                        "patience": PATIENCE, "seed": SEED}
    for pos in GRID_POS:
        for slope in GRID_SLOPE:
            name = grid_name(pos, slope)
            if name in report["runs"]:
                continue
            report["runs"][name] = tune(data, device, pos, slope,
                                        folder / name, log)
            path.write_text(json.dumps(clean(report), ensure_ascii=False,
                                       indent=1), encoding="utf-8")
    return report


def grid_models(folder: Path = MODELS, results: Path = RESULTS) -> list:
    """Варіанти гріду штрафів з найкращою епохою кожного і її порогом."""
    path = results / "grid.json"
    if not path.exists():
        return []
    report = json.loads(path.read_text(encoding="utf-8"))
    out = []
    for name, run in report["runs"].items():
        best = next(one for one in run["history"]
                    if one["epoch"] == run["best_epoch"])
        weights = folder / "grid" / name / f"epoch_{run['best_epoch']:02d}.pt"
        if weights.exists():
            out.append({"name": name, "pos": run["pos"], "slope": run["slope"],
                        "epoch": run["best_epoch"],
                        "threshold": best["threshold"],
                        "holdout_f1": best["holdout"]["f1"],
                        "weights": weights})
    return out


def probe(pair: str, first: int, last: int, epoch: int,
          data: Path | None = None, folder: Path = MODELS,
          root: Path | None = None, results: Path = RESULTS) -> dict:
    """Канва з відрізка val `[first, last]` (секунди UTC), обраного руками,
    і видача на ній мережі епохи `epoch` і кожного варіанта гріду штрафів;
    правда — півоти розмітки в канві і їхні зони."""
    import edges30_data as d
    from bars30 import BAR, DATA as BARS, read_seconds
    data = data or BARS
    with np.load(data / f"{pair}_val.npz") as store:
        stamps, opens, close = store["t"], store["open"], store["close"]
    start = int(np.searchsorted(stamps, first, side="left"))
    end = int(np.searchsorted(stamps, last, side="right")) - 1
    start, end = max(start, 0), min(end, len(stamps) - 1)
    if end - start + 1 < d.MIN_BARS:
        raise ValueError("відрізок коротший за 20 записів")
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    pivots = d.pivots_of(table["legs"][pair]["val"], close)
    holder = read_seconds(pair, int(stamps[start]),
                          int(stamps[end]) + BAR - 1, {}, root)
    got = d.canvas_of(holder, stamps, close, opens, start, end, pivots)
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    threshold = next(one["threshold"] for one in history["history"]
                     if one["epoch"] == epoch)
    device = torch.device("cpu")
    model = model_of(epoch, device, folder)
    prob = predict(model, got["net"][None], scalars_of(got["scalars"][None]),
                   device)[0]
    live = got["first"] >= 0
    signal = peaks(prob[None], got["mask"][None], threshold)[0]
    grid = []
    for run in grid_models(folder, results):
        one = Finder().to(device)
        one.load_state_dict(torch.load(run["weights"], map_location=device))
        one_prob = predict(one, got["net"][None],
                           scalars_of(got["scalars"][None]), device)[0]
        one_signal = peaks(one_prob[None], got["mask"][None],
                           run["threshold"])[0]
        grid.append({key: run[key] for key in
                     ("name", "pos", "slope", "epoch", "threshold",
                      "holdout_f1")} | {
            "prob": one_prob, "signal": np.flatnonzero(one_signal),
            "good": got["label"][one_signal] == 1})
    inside = (pivots["index"] >= start) & (pivots["index"] <= end)
    row_start = np.where(live, stamps[start + np.maximum(got["first"], 0)], 0)
    row_end = np.where(live, stamps[start + np.maximum(got["last"], 0)] + BAR, 0)
    return {"pair": pair, "epoch": epoch, "threshold": threshold,
            "start": start, "end": end, "t": stamps[start:end + 1],
            "close": close[start:end + 1], "prob": prob, "live": live,
            "row_start": row_start, "row_end": row_end,
            "label": got["label"], "signal": np.flatnonzero(signal),
            "good": got["label"][signal] == 1,
            "pivots": pivots["index"][inside] - start,
            "pivot_t": stamps[pivots["index"][inside]],
            "pivot_price": pivots["price"][inside],
            "top": pivots["top"][inside], "zone": pivots["zone"][inside],
            "span": pivots["span"][inside], "grid": grid}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--outputs", action="store_true")
    parser.add_argument("--grid", action="store_true")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    from leg_end_train import no_swap
    no_swap(MEMORY_NEED, args.force)
    device = device_of(args.device)
    if args.outputs:
        outputs(device)
        return
    data = {part: load(part) for part in ("train", "val")}
    data["train"]["x"] = np.asarray(data["train"]["x"])
    data["val"]["x"] = np.asarray(data["val"]["x"])
    print(f"пристрій {device}, вікон train {len(data['train']['label'])}, "
          f"val {len(data['val']['label'])}")
    if args.grid:
        grid(data, device, lambda text: print(text, flush=True))
        return
    got = train(data, device)
    print(f"найкраща епоха {got['best']['epoch']}")


if __name__ == "__main__":
    main()
