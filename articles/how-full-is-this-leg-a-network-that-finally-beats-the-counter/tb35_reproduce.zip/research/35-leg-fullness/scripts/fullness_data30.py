"""Навчальні вікна етапу 6: випадкова частка ноги, мітки сходинок і рядків.

Дослідження: research/35-leg-fullness/ → Етап 6

## Хід

1. Ноги й записи 30 с — етап 3 (`data/bars30/legs.json`,
   `<PAIR>_<part>.npz`); train до 2026-08-14, val 14.08 … 22.09.
2. На кожну ногу `PER_LEG` вікон від першого запису після півота:
   `UNIFORM` — частка `q` рівномірно на `[0.05, q_max]`, `EDGE` — біля
   кінця ноги, `q` на `[0.9, 1.1]`. `q_max` = 1.5, але вікно не
   виходить за кінець наступної ноги; в останньої ноги частини
   `q_max` = 1. Записів у вікні `n = max(2, round(q · L))`, мітка
   `q = n / L`.
3. Канва вікна — `windows30.window_canvas`: хід етапу 3 на самому вікні,
   нормування тільки на вікно.
4. **Мітка рядка** — 1, коли середина відрізка рядка лежить не раніше
   першої секунди наступної ноги; мертві рядки — під маскою.
5. **Скаляри** (причинні): `log1p(n)`, `log1p(крок відрізка, с)`, рух
   ціни від першого запису вікна до останнього (`log(close / open)`),
   частка живих рядків.

6. **Ряд val** (`--series`) — на кожній нозі val вікна з часткою від
   0.025 до стелі кроком 0.025: на кожному записі видно і вікно від
   поточного півота, і вікно від попереднього.

Запуск:
    python3 research/35-leg-fullness/scripts/fullness_data30.py
    python3 research/35-leg-fullness/scripts/fullness_data30.py --series

Вихід: data/fullness30/<клас>/<part>_x.npy (memmap `N × 500 × F`), <part>.npz —
маска, мітки рядків, `q`, скаляри, нога, напрямок.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import BAR, DATA, PARTS, ROWS, edges_of, read_seconds  # noqa: E402
from windows30 import window_canvas  # noqa: E402

OUT = SCRIPTS.parent / "data" / "fullness30"
UNIFORM = 18
EDGE = 6
PER_LEG = UNIFORM + EDGE
Q_MIN, Q_MAX = 0.05, 1.5
EDGE_RANGE = (0.9, 1.1)
SEED = 6
SERIES_STEP = 0.025            # крок частки у вікнах ряду val


def q_ceiling(leg: dict, following: dict | None) -> float:
    """Найбільша частка вікна: 1.5, не далі за кінець наступної ноги."""
    if following is None or following["first"] != leg["last"] + 1:
        return 1.0
    return min(Q_MAX, (following["last"] - leg["first"] + 1) / leg["bars"])


def draw_shares(ceiling: float, rng, uniform: int = UNIFORM,
                edge: int = EDGE) -> np.ndarray:
    """Частки вікон однієї ноги: рівномірні і біля кінця ноги."""
    low, high = EDGE_RANGE
    return np.concatenate([rng.uniform(Q_MIN, ceiling, uniform),
                           rng.uniform(low, min(high, ceiling), edge)])


def series_shares(ceiling: float, step: float = SERIES_STEP) -> np.ndarray:
    """Частки вікон ряду: від `step` до стелі з кроком `step`."""
    return np.arange(step, ceiling + 1e-9, step)


def row_labels(stamps: np.ndarray, next_start: int | None,
               rows: int = ROWS) -> np.ndarray:
    """Рядок канви належить наступній нозі, коли середина його відрізка
    лежить не раніше першої секунди наступної ноги."""
    edges, fit = edges_of(stamps, int(stamps[-1]) + BAR - 1, rows)
    out = np.zeros(rows, dtype=np.float32)
    if next_start is None:
        return out
    middle = (edges[:-1] + edges[1:]) / 2
    out[rows - fit:] = middle[:fit] >= next_start
    return out


def build(part: str, key: str = classes30.DEFAULT, data: Path = DATA,
          out: Path = OUT, root: Path | None = None, seed: int = SEED,
          per_leg: tuple = (UNIFORM, EDGE), series: bool = False,
          log=print) -> dict:
    """Вікна частини; з `series` — сітка часток `SERIES_STEP` на кожній
    нозі (ряд для вкладки), інакше випадкові частки навчання."""
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(seed)
    features = len(classes30.BY_KEY[key]["features"])
    total = sum(len(parts.get(part, [])) for parts in table["legs"].values())
    name = f"series_{part}" if series else part
    shares_of = {}
    for pair, parts in table["legs"].items():
        legs = parts.get(part, [])
        for index, leg in enumerate(legs):
            following = legs[index + 1] if index + 1 < len(legs) else None
            ceiling = q_ceiling(leg, following)
            shares_of[(pair, index)] = (series_shares(ceiling) if series
                                        else draw_shares(ceiling, rng,
                                                         *per_leg))
    size = sum(len(one) for one in shares_of.values())
    out = out / key
    out.mkdir(parents=True, exist_ok=True)
    canvas = np.lib.format.open_memmap(out / f"{name}_x.npy", mode="w+",
                                       dtype=np.float32,
                                       shape=(size, ROWS, features))
    keep = {"mask": [], "rows": [], "q": [], "scalars": [], "leg": [],
            "kind": [], "name": [], "bars": [], "length": [], "end": []}
    number, position = 0, 0
    for pair, parts in table["legs"].items():
        legs = parts.get(part, [])
        if not legs:
            continue
        with np.load(data / f"{pair}_{part}.npz") as store:
            stamps, opens, closes = store["t"], store["open"], store["close"]
        cache = {}
        for index, leg in enumerate(legs):
            following = legs[index + 1] if index + 1 < len(legs) else None
            ceiling = q_ceiling(leg, following)
            shares = shares_of[(pair, index)]
            counts = np.maximum(2, np.round(shares * leg["bars"])).astype(int)
            counts = np.minimum(counts, int(round(ceiling * leg["bars"])))
            last = leg["first"] + counts.max() - 1
            holder = read_seconds(pair, leg["from"],
                                  int(stamps[last]) + BAR - 1, cache, root)
            next_start = (int(stamps[following["first"]])
                          if following is not None
                          and following["first"] == leg["last"] + 1 else None)
            for count in counts:
                window = stamps[leg["first"]:leg["first"] + count]
                net, mask, step = window_canvas(holder, window, key)
                canvas[position] = net
                end = leg["first"] + count - 1
                keep["mask"].append(mask)
                keep["rows"].append(row_labels(window, next_start) * mask)
                keep["q"].append(count / leg["bars"])
                keep["scalars"].append([
                    np.log1p(count), np.log1p(step),
                    float(np.log(closes[end] / opens[leg["first"]])),
                    float(mask.mean())])
                keep["leg"].append(number)
                keep["kind"].append(leg["kind"])
                keep["name"].append(f"{pair}·{leg['leg']}")
                keep["bars"].append(count)
                keep["length"].append(leg["bars"])
                keep["end"].append(int(stamps[end]) + BAR - 1)
                position += 1
            number += 1
        log(f"{pair} {part}: ніг {len(legs)}, вікон {position}")
    canvas.flush()
    del canvas
    arrays = {name: np.asarray(value) for name, value in keep.items()}
    arrays["scalars"] = arrays["scalars"].astype(np.float32)
    np.savez(out / f"{name}.npz", **arrays)
    return {"windows": position, "legs": number}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--classes", default=classes30.DEFAULT)
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--series", action="store_true",
                        help="ряд val: сітка часток на кожній нозі")
    args = parser.parse_args()
    for part in (("val",) if args.series else PARTS):
        got = build(part, args.classes, args.data, args.out, args.root,
                    series=args.series)
        print(f"{part}: {got}")


if __name__ == "__main__":
    main()
