"""Класи проєкту на блоках довільної довжини: запис 30 с або відрізок канви.

Дослідження: research/35-leg-fullness/ → Етап 4
Правила: rules/01-data-and-db.md → Класи (події)

Кожен клас `rules/01-data-and-db.md` тут — **алгоритм перетворення ряду
блоків**: блоком є запис 30 с (ряд записів) або відрізок канви (ряд
500 відрізків ноги). Формули класу ті самі, міняється лише блок:

- класи з блоками всередині події (`х14`, `х10`) — блоком стає запис;
- класи з одним блоком на подію (`х210х210`) — подією стає запис, і
  середнє по одному блоку дорівнює самому блоку;
- ЕМА-класи — ЕМА по ряду блоків, період у блоках;
- похідні — до попереднього блоку, лише коли він стоїть впритул.

Нульовий знаменник дає **0** в усіх класах (рішення користувача
2026-09-23). Блок без жодної секунди значень не має (`NaN`).

Блок описується словником:
`sums` — суми девʼяти колонок `клас210х10х9`, `(9, N)`; `n` — секунд;
`first` — `price_avg` першої секунди; `net`, `absm` — сума і сума
модулів посекундних змін `price_avg` усередині блоку (лише між сусідніми
секундами); `adjacent` — попередній блок стоїть впритул.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT / "rules" / "scripts") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from class210ema4 import DEFAULT_PERIOD, ema  # noqa: E402
from class210x10x9 import FEATURES as RAW  # noqa: E402
from class210x4bema10x10x130 import PERIODS  # noqa: E402

LEVELS = ["resist", "bal_resist", "support", "bal_support", "vol_buy",
          "vol_sell", "price_avg"]
BOOK = RAW[:8]                           # вісім фіч клас210х8
SEAM_BLOCKS = 3                          # похідні, що заступають першу


def over(top: np.ndarray, bottom: np.ndarray) -> np.ndarray:
    """Ділення, де нульовий знаменник дає 0."""
    out = np.zeros(np.broadcast(top, bottom).shape)
    np.divide(top, bottom, out=out, where=bottom != 0)
    return out


def balance(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Нормована різниця `(a − b) / (|a| + |b|)`; нульовий знаменник — 0."""
    return over(a - b, np.abs(a) + np.abs(b))


def means(block: dict) -> dict:
    """Середні блоку по кожній з девʼяти колонок; порожній блок — 0."""
    live = block["n"] > 0
    out = np.zeros(block["sums"].shape)
    out[:, live] = block["sums"][:, live] / block["n"][live]
    return {name: out[number] for number, name in enumerate(RAW)}


def sums(block: dict) -> dict:
    return {name: block["sums"][number] for number, name in enumerate(RAW)}


# ---------- клас210х8 → клас210х14х4 → … → клас210х4бема10х10х130 ----------

def x8(block: dict) -> np.ndarray:
    """`клас210х8`: вісім колонок стакана й обʼємів — середні блоку."""
    mean = means(block)
    return np.stack([mean[name] for name in BOOK], axis=1)


def x14x4(block: dict) -> np.ndarray:
    """`клас210х14х4`: Σ блоку / середній обʼєм події; подія — сам блок."""
    total, mean = sums(block), means(block)
    return np.stack([
        over(total["const_resist"], mean["vol_buy"]),
        over(total["resist_plus"] - total["resist_minus"], mean["vol_buy"]),
        over(total["const_support"], mean["vol_sell"]),
        over(total["support_plus"] - total["support_minus"],
             mean["vol_sell"])], axis=1)


def volume_balance(block: dict) -> np.ndarray:
    total = sums(block)
    return over(total["vol_buy"] - total["vol_sell"],
                total["vol_buy"] + total["vol_sell"])


def price_balance(block: dict) -> np.ndarray:
    """`(кінець − початок) / Σ|посекундних змін|` усередині блоку."""
    return over(block["net"], block["absm"])


def x14x2(block: dict) -> np.ndarray:
    four = x14x4(block)
    return np.stack([balance(four[:, 0], four[:, 2]),
                     balance(four[:, 1], four[:, 3])], axis=1)


def x14x5(block: dict) -> np.ndarray:
    return np.column_stack([x14x4(block), volume_balance(block)])


def x14x3(block: dict) -> np.ndarray:
    return np.column_stack([x14x2(block), volume_balance(block)])


def x14x4c(block: dict) -> np.ndarray:
    return np.column_stack([x14x3(block), price_balance(block)])


def emas(values: np.ndarray, period: int) -> np.ndarray:
    return np.stack([ema(values[:, column], period)
                     for column in range(values.shape[1])], axis=1)


def ema4(block: dict) -> np.ndarray:
    """`клас210ема4`: ЕМА ціни відкриття і трьох фіч `клас210х210х3`."""
    return emas(np.column_stack([block["first"], empty(block, x14x3(block))]),
                DEFAULT_PERIOD)


def ema4c(block: dict) -> np.ndarray:
    return emas(empty(block, x14x4c(block)), DEFAULT_PERIOD)


def bema(block: dict) -> np.ndarray:
    """`клас210х4бема10х10х130`: 13 періодів × 4 фічі, рядок — період."""
    base = empty(block, x14x4c(block))
    return np.concatenate([emas(base, period) for period in PERIODS], axis=1)


# ---------- клас210х10х9 → клас210х10х7 → похідні ----------

def x10x9(block: dict) -> np.ndarray:
    mean = means(block)
    return np.stack([mean[name] for name in RAW], axis=1)


def x10x7(block: dict) -> np.ndarray:
    """Рівні на обʼєм **свого** блоку, обʼєми й ціна як є."""
    mean = means(block)
    return np.stack([
        over(mean["const_resist"], mean["vol_buy"]),
        over(mean["resist_plus"] - mean["resist_minus"], mean["vol_buy"]),
        over(mean["const_support"], mean["vol_sell"]),
        over(mean["support_plus"] - mean["support_minus"], mean["vol_sell"]),
        mean["vol_buy"], mean["vol_sell"], mean["price_avg"]], axis=1)


def derivative(plates: np.ndarray, adjacent: np.ndarray) -> np.ndarray:
    """`d[j] = x[j] − x[j−1]`, лише коли попередній блок впритул; `(N, F)`."""
    out = np.full(plates.shape, np.nan)
    out[1:] = plates[1:] - plates[:-1]
    out[~adjacent] = np.nan
    return out


def seam(step: np.ndarray, adjacent: np.ndarray) -> np.ndarray:
    """Блок без сусіда впритул — середнє трьох наступних похідних
    (правило першого блоку `клас210х10х7дц`); немає їх — `NaN`."""
    out = step.copy()
    for index in np.flatnonzero(~adjacent):
        ahead = step[index + 1:index + 1 + SEAM_BLOCKS]
        ahead = ahead[np.isfinite(ahead).all(axis=1)]
        if len(ahead) == SEAM_BLOCKS:
            out[index] = ahead.mean(axis=0)
    return out


def x10x7dc(block: dict) -> np.ndarray:
    return seam(derivative(x10x7(block), block["adjacent"]),
                block["adjacent"])


def x10m1x7dc(block: dict) -> np.ndarray:
    return derivative(x10x7(block), block["adjacent"])


def keep_gaps(out: np.ndarray, step: np.ndarray) -> np.ndarray:
    """Блок без похідної лишається без значення — ділити там нічого."""
    out[~np.isfinite(step).all(axis=1)] = np.nan
    return out


def x10m1x3p1dc(block: dict) -> np.ndarray:
    """Нормована різниця **модулів** пар «опір проти підтримки» + ціна."""
    step = x10m1x7dc(block)
    clean = np.nan_to_num(step)
    name = {title: number for number, title in enumerate(LEVELS)}
    pairs = [("resist", "support"), ("bal_resist", "bal_support"),
             ("vol_buy", "vol_sell")]
    out = np.column_stack(
        [balance(np.abs(clean[:, name[a]]), np.abs(clean[:, name[b]]))
         for a, b in pairs] + [clean[:, name["price_avg"]]])
    return keep_gaps(out, step)


def ratio_columns(step: np.ndarray, couples: list) -> np.ndarray:
    name = {title: number for number, title in enumerate(LEVELS)}
    clean = np.nan_to_num(step)
    return np.column_stack([over(clean[:, name[top]], clean[:, name[bottom]])
                            for top, bottom in couples])


UP_DOWN = [("vol_buy", "resist"), ("vol_sell", "support")]
BACK = [("resist", "vol_buy"), ("bal_resist", "vol_buy"),
        ("support", "vol_sell"), ("bal_support", "vol_sell")]


def x10m1x2d(block: dict) -> np.ndarray:
    step = x10m1x7dc(block)
    return keep_gaps(ratio_columns(step, UP_DOWN), step)


def x10m1x7dd(block: dict) -> np.ndarray:
    step = x10m1x7dc(block)
    out = np.column_stack([ratio_columns(step, UP_DOWN + BACK),
                           np.nan_to_num(step[:, LEVELS.index("price_avg")])])
    return keep_gaps(out, step)


def empty(block: dict, values: np.ndarray) -> np.ndarray:
    """Блок без секунд — без значення."""
    values = np.array(values, dtype=float)
    values[block["n"] <= 0] = np.nan
    return values


D = [f"d_{name}" for name in LEVELS]
X14X4 = ["resist", "d_resist", "support", "d_support"]
X14X3 = ["balance", "d_balance", "vol_balance"]
X14X4C = X14X3 + ["price_balance"]

# Порядок — як у таблиці класів rules/01-data-and-db.md.
CLASSES = [
    {"key": "x8", "rule": "середні запису восьми колонок стакана й обʼємів",
     "name": "клас210х8", "make": x8, "features": BOOK},
    {"key": "x14x4", "rule": "Σ запису рівня / середній обʼєм запису: resist, d_resist = Σ(plus − minus), support, d_support",
     "name": "клас210х14х4", "make": x14x4,
     "features": X14X4},
    {"key": "x14x2", "rule": "нормовані різниці (a − b)/(|a| + |b|) пар клас210х14х4: balance, d_balance",
     "name": "клас210х14х2", "make": x14x2,
     "features": ["balance", "d_balance"]},
    {"key": "x14x5", "rule": "клас210х14х4 + vol_balance = (Σvol_buy − Σvol_sell)/(Σvol_buy + Σvol_sell)",
     "name": "клас210х14х5", "make": x14x5,
     "features": X14X4 + ["vol_balance"]},
    {"key": "x14x3", "rule": "balance, d_balance, vol_balance на записі",
     "name": "клас210х14х3", "make": x14x3,
     "features": X14X3},
    {"key": "x14x4c", "rule": "клас210х14х3 + price_balance = Σ змін ціни / Σ|змін| усередині запису",
     "name": "клас210х14х4ц", "make": x14x4c,
     "features": X14X4C},
    {"key": "x210x3", "rule": "середнє клас210х14х3 по події з одного блоку — на записі збігається з клас210х14х3",
     "name": "клас210х210х3", "make": x14x3,
     "features": X14X3},
    {"key": "x210x4c", "rule": "середнє клас210х14х4ц по події з одного блоку — на записі збігається з клас210х14х4ц",
     "name": "клас210х210х4ц", "make": x14x4c,
     "features": X14X4C},
    {"key": "ema4", "rule": "ЕМА200 записів: ціна першої секунди запису і три фічі клас210х210х3",
     "name": "клас210ема4", "make": ema4,
     "features": ["ema_price"] + [f"ema_{name}" for name in X14X3]},
    {"key": "ema4c", "rule": "ЕМА200 записів чотирьох фіч клас210х210х4ц",
     "name": "клас210ема4ц", "make": ema4c,
     "features": [f"ema_{name}" for name in X14X4C]},
    {"key": "bema", "rule": "ЕМА 10, 20 … 130 записів чотирьох фіч клас210х210х4ц — 13 × 4 = 52 канали",
     "name": "клас210х4бема10х10х130", "make": bema,
     "features": [f"{name}·ема{period}" for period in PERIODS
                  for name in X14X4C]},
    {"key": "x10x9", "rule": "середні запису девʼяти колонок, з ціною",
     "name": "клас210х10х9", "make": x10x9, "features": RAW},
    {"key": "x10x7", "rule": "рівні на обʼєм свого запису, обʼєми й ціна як є",
     "name": "клас210х10х7", "make": x10x7,
     "features": LEVELS},
    {"key": "x10x7dc", "rule": "похідна клас210х10х7 до запису впритул; запис без сусіда — середнє трьох наступних похідних",
     "name": "клас210х10х7дц", "make": x10x7dc,
     "features": D},
    {"key": "x10m1x7dc", "rule": "похідна клас210х10х7 лише до запису впритул, інакше без значення",
     "name": "клас210х10-1х7дц", "make": x10m1x7dc,
     "features": D},
    {"key": "x10m1x3p1dc", "rule": "(|a| − |b|)/(|a| + |b|) трьох пар похідних «опір проти підтримки» + d_price_avg",
     "name": "клас210х10-1х3+1дц", "make": x10m1x3p1dc,
     "features": ["b_resist_support", "b_bal_resist_support",
                  "b_vol_buy_sell", "d_price_avg"]},
    {"key": "x10m1x2d", "rule": "d_up = d_vol_buy / d_resist, d_down = d_vol_sell / d_support",
     "name": "клас210х10-1х2д", "make": x10m1x2d,
     "features": ["d_up", "d_down"]},
    {"key": "x10m1x7dd", "rule": "шість відношень похідних клас210х10-1х7дц + d_price_avg",
     "name": "клас210х10-1х7д/д", "make": x10m1x7dd,
     "features": ["d_up", "d_down", "d_resist_buy", "d_bal_resist_buy",
                  "d_support_sell", "d_bal_support_sell", "d_price_avg"]},
]
BY_KEY = {one["key"]: one for one in CLASSES}
DEFAULT = "x10m1x7dd"


def features(key: str, block: dict) -> np.ndarray:
    """Фічі класу на ряді блоків, `(N, F)`; блок без секунд — `NaN`."""
    one = BY_KEY[key]
    out = empty(block, one["make"](block))
    if out.shape[1] != len(one["features"]):
        raise ValueError(f"{one['name']}: {out.shape[1]} колонок замість "
                         f"{len(one['features'])}")
    return out
