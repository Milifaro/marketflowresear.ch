"""Звід прогонів етапу 2: числа обох мереж і похибка по ногах.

Дослідження: research/35-leg-fullness/
Правила: rules/03-models.md → Розмір вибірки в незалежних одиницях

Одиниця вибірки — **нога**, а не приклад: усі префікси однієї ноги
зроблені з того самого шматка ряду. Тому похибка рахується
перевибіркою **ніг** (bootstrap): нога береться цілком, з усіма своїми
префіксами, і на кожній вибірці міра рахується заново.

Різниця двох прогонів читається тим самим способом: на кожній
перевибірці рахується різниця, і з неї береться інтервал. Якщо
інтервал накриває нуль — прогони не відрізняються.

Запуск:
    python3 research/35-leg-fullness/scripts/report.py
    python3 research/35-leg-fullness/scripts/report.py --runs canvas tail

Вихід: results/fullness_runs.json — числа для вкладки `/fullness`.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
RESULTS = RESEARCH_DIR / "results"
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from canvas_net import auc  # noqa: E402

DRAWS = 1000
SEED = 0
PARTS = ("train", "holdout", "val")


def frame(series: list) -> dict:
    """Ряд прикладів val у колонки."""
    return {"leg": np.array([f"{one['pair']}·{one['leg']}" for one in series]),
            "pair": np.array([one["pair"] for one in series]),
            "cut": np.array([one["cut"] for one in series]),
            "complete": np.array([one["complete"] for one in series]),
            "true": np.array([one["true"] for one in series]),
            "score": np.array([one["score"] for one in series]),
            "share": np.array([one["share"] for one in series]),
            "events": np.array([one["events"] for one in series]),
            "length": np.array([one["length"] for one in series])}


def numbers(data: dict, index: np.ndarray, median: float) -> dict:
    """Три міри на одній вибірці прикладів."""
    complete = data["complete"][index]
    if complete.sum() == 0 or complete.sum() == len(index):
        return {"auc_complete": np.nan, "auc_hard": np.nan, "share_mae": np.nan}
    hard = (complete == 1) | (data["cut"][index] == "корекція")
    counter = np.clip(data["events"][index] / median, 0, 1)
    out = {"auc_complete": auc(data["score"][index], complete),
           "auc_hard": auc(data["score"][index][hard], complete[hard]),
           "share_mae": float(np.abs(data["share"][index]
                                     - data["true"][index]).mean()),
           "auc_counter": auc(counter, complete),
           "mae_counter": float(np.abs(counter - data["true"][index]).mean())}
    # Наскільки мережа краща за лічильник — на тій самій перевибірці, а
    # не різницею двох окремих інтервалів.
    out["auc_over_counter"] = out["auc_complete"] - out["auc_counter"]
    out["mae_over_counter"] = out["mae_counter"] - out["share_mae"]
    return out


def draw(data: dict, legs: np.ndarray, rng) -> np.ndarray:
    """Перевибірка ніг: нога заходить цілком, з усіма префіксами."""
    picked = rng.choice(legs, size=len(legs), replace=True)
    return np.concatenate([np.where(data["leg"] == name)[0]
                           for name in picked])


def spread(values: list) -> dict:
    """Точка й межі: 5-й і 95-й перцентилі перевибірок."""
    clean = np.array([one for one in values if np.isfinite(one)])
    if not len(clean):
        return {}
    return {"low": float(np.percentile(clean, 5)),
            "high": float(np.percentile(clean, 95))}


def bootstrap(runs: dict, median: float, draws: int, seed: int) -> dict:
    """Похибка кожної міри й різниці прогонів — перевибіркою ніг."""
    data = {tag: frame(run["val_series"]) for tag, run in runs.items()}
    first = next(iter(data.values()))
    legs = np.unique(first["leg"])
    rng = np.random.default_rng(seed)
    keys = ("auc_complete", "auc_hard", "share_mae", "auc_counter",
            "mae_counter", "auc_over_counter", "mae_over_counter")
    pile = {tag: {key: [] for key in keys} for tag in data}
    gap = {key: [] for key in keys}
    tags = list(data)
    for _ in range(draws):
        index = draw(first, legs, rng)
        step = {}
        for tag in tags:
            step[tag] = numbers(data[tag], index, median)
            for key in keys:
                pile[tag][key].append(step[tag][key])
        if len(tags) == 2:
            for key in keys:
                gap[key].append(step[tags[0]][key] - step[tags[1]][key])
    out = {"legs": int(len(legs)), "draws": draws,
           "runs": {tag: {key: spread(pile[tag][key]) for key in keys}
                    for tag in tags}}
    if len(tags) == 2:
        out["gap"] = {"left": tags[0], "right": tags[1],
                      "keys": {key: spread(gap[key]) for key in keys}}
    return out


def scatter(series: list, step: int = 1) -> list:
    """Точки «сказана частка проти справжньої» для вкладки."""
    return [{"true": round(one["true"], 4), "share": round(one["share"], 4),
             "score": round(one["score"], 3), "cut": one["cut"],
             "pair": one["pair"], "events": one["events"],
             "length": one["length"]}
            for one in series[::step]]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--runs", nargs="+", default=["canvas", "tail"])
    parser.add_argument("--draws", type=int, default=DRAWS)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--dir", type=Path, default=RESULTS)
    parser.add_argument("--out", type=Path,
                        default=RESULTS / "fullness_runs.json")
    args = parser.parse_args()

    runs = {tag: json.loads((args.dir / f"{tag}.json").read_text())
            for tag in args.runs}
    median = next(iter(runs.values()))["median"]
    report = {"runs": {}, "median": median, "seed": args.seed}
    for tag, run in runs.items():
        report["runs"][tag] = {
            "tail": run["tail"], "best_epoch": run["best_epoch"],
            "epochs": [{"epoch": one["epoch"], "loss": one["loss"],
                        "auc_complete": one["auc_complete"],
                        "auc_hard": one["auc_hard"],
                        "share_mae": one["share_mae"]}
                       for one in run["epochs"]],
            **{part: run[part] for part in PARTS}}
    report["error"] = bootstrap(runs, median, args.draws, args.seed)
    report["scatter"] = scatter(runs[args.runs[0]]["val_series"])
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=1))

    error = report["error"]
    print(f"перевибірок {error['draws']} по {error['legs']} ногах val")
    for tag, cell in error["runs"].items():
        print(f"  {tag:7s} AUC повноти {report['runs'][tag]['val']['auc_complete']:.3f} "
              f"[{cell['auc_complete']['low']:.3f}; {cell['auc_complete']['high']:.3f}], "
              f"важкі {report['runs'][tag]['val']['auc_hard']:.3f} "
              f"[{cell['auc_hard']['low']:.3f}; {cell['auc_hard']['high']:.3f}], "
              f"частка MAE {report['runs'][tag]['val']['share_mae']:.3f} "
              f"[{cell['share_mae']['low']:.3f}; {cell['share_mae']['high']:.3f}]")
    for tag, cell in error["runs"].items():
        print(f"  {tag:7s} проти лічильника: AUC "
              f"[{cell['auc_over_counter']['low']:+.3f}; "
              f"{cell['auc_over_counter']['high']:+.3f}], "
              f"MAE виграш [{cell['mae_over_counter']['low']:+.3f}; "
              f"{cell['mae_over_counter']['high']:+.3f}]")
    if "gap" in error:
        gap = error["gap"]
        print(f"  різниця {gap['left']} − {gap['right']}: "
              + ", ".join(f"{key} [{one['low']:.3f}; {one['high']:.3f}]"
                          for key, one in gap["keys"].items()))
    print(args.out)


if __name__ == "__main__":
    main()
