"""Ролі подій у нозі: початок, кінець і краї внутрішніх корекцій.

Дослідження: research/35-leg-fullness/
Клас: `клас210х10-1х7д/д` (`class210x10m1x7dd`)
Правила: rules/01-data-and-db.md → Класи, rules/02-markup.md → Точка кінця ноги

## Питання

Нога зігзага 2.3 % складається не з однорідних подій: у ній є початок,
кінець і внутрішні корекції. Корекція має два краї — подія, де нога
спинилась (той самий бік, що й кінець ноги), і подія, де вона рушила
далі (той самий бік, що й початок). Питання одне: **чи відрізняються
ці краї від справжніх країв ноги** за самими фічами класу.

Якщо не відрізняються — мережа, яка каже «нога повна», в принципі не
може відрізнити корекцію від розвороту за однією подією, і повноту
треба питати з послідовності.

## Розмітка

    ряд подій частини -> ема10(price_open) -> півоти зігзага 2.3
        -> точка кінця ноги (екстремум price_close, ±25 подій) -> ноги
    усередині кожної ноги -> зігзаг 0.8 по тій самій ема
        -> та сама точка кінця ноги -> краї корекцій

Обидва зігзаги проходять крок `snap` — це стандарт розмітки для порогу
будь-якого розміру (rules/02-markup.md → Точка кінця ноги).

## Ролі

Якорі беруться з розмітки, група — якір ± `--width` подій усередині
своєї ноги:

| Роль | Якір | Бік |
| ---- | ---- | --- |
| `початок` | перша подія ноги | низ ноги вгору, верх ноги вниз |
| `кінець` | остання подія ноги (півот 2.3) | верх ноги вгору, низ ноги вниз |
| `корекція-як-кінець` | внутрішній півот 0.8 того самого боку, що кінець | нога спинилась |
| `корекція-як-початок` | внутрішній півот 0.8 того самого боку, що початок | нога рушила далі |
| `тіло` | подія, далі ніж `--body` від усіх якорів | — |

## Числа

Фіча класу — відношення похідних, тому всі міри **рангові**
(rules/01-data-and-db.md → `клас210х10-1х7д/д`). Кожна з 7 фіч
згортається по 9 блоках події у три числа (середнє, розкид, остання
плашка) — 21 колонка, кожна переводиться в ранг усередині монети, база
рангу — події `train` цієї ж монети.

Порівнюються пари ролей: AUC кожної колонки на об'єднаних монетах.
Підлога — та сама AUC на **перемішаних** мітках ролі (той самий розмір
груп, той самий seed), стеля похибки — розкид по монетах і кількість
ніг.

Запуск:
    python3 research/35-leg-fullness/scripts/roles.py
    python3 research/35-leg-fullness/scripts/roles.py --pairs BTC_USDT --width 0

Вихід: results/roles.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RULES_SCRIPTS = PROJECT_ROOT / "rules" / "scripts"
if str(RULES_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(RULES_SCRIPTS))

from build_class210x10x7dc import PAIRS, PARTS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import INNER_THRESHOLD, OUTER_THRESHOLD, SNAP_SPAN, snap, zigzag  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
PERIOD = 10                # ема ціни, на якій стоять півоти
WIDTH = 2                  # скільки подій навколо якоря входить у роль
BODY = 10                  # далі за стільки подій від усіх якорів — тіло
SHUFFLES = 20              # скільки перестановок мітки дають підлогу
STATS = ("mean", "std", "last")
SEED = 0

ROLES = ("початок", "кінець", "корекція-як-початок", "корекція-як-кінець",
         "тіло")

# Пари ролей, заради яких усе рахується.
COUPLES = (
    ("кінець", "корекція-як-кінець"),
    ("початок", "корекція-як-початок"),
    ("кінець", "тіло"),
    ("початок", "тіло"),
    ("корекція-як-кінець", "тіло"),
    ("корекція-як-початок", "тіло"),
    ("кінець", "початок"),
    ("корекція-як-кінець", "корекція-як-початок"),
)


def load(pair: str, part: str, root: Path | None = None) -> dict:
    """Події однієї частини однієї монети: фічі, час і ціни."""
    path = (root or DATASETS) / pair / CLASS / f"{part}.npz"
    with np.load(path) as store:
        x = store["x"].astype(np.float64)
        t = store["t_start"].astype(np.int64)
        opens = store["price_open"].astype(float)
        closes = store["price_close"].astype(float)
        names = [str(name) for name in store["features"]]
    order = np.argsort(t, kind="stable")
    return {"pair": pair, "part": part, "x": x[order], "t": t[order],
            "open": opens[order], "close": closes[order], "features": names}


def columns(x: np.ndarray, names: list) -> tuple:
    """Подія → 21 число: середнє, розкид і остання плашка кожної фічі."""
    with np.errstate(invalid="ignore"):
        pieces = {"mean": np.nanmean(x, axis=1), "std": np.nanstd(x, axis=1),
                  "last": x[:, -1, :]}
    table = np.concatenate([pieces[stat] for stat in STATS], axis=1)
    titles = [f"{name}·{stat}" for stat in STATS for name in names]
    return table, titles


def ranked(table: np.ndarray, base: np.ndarray) -> np.ndarray:
    """Ранг кожної колонки в межах монети; база рангу — події `train`."""
    out = np.full(table.shape, 0.5)
    for column in range(table.shape[1]):
        values = table[:, column]
        sample = base[:, column]
        sample = np.sort(sample[np.isfinite(sample)])
        if not len(sample):
            continue
        good = np.isfinite(values)
        low = np.searchsorted(sample, values[good], side="left")
        high = np.searchsorted(sample, values[good], side="right")
        out[good, column] = (low + high) / (2 * len(sample))
    return out


def legs_of(row: dict, threshold: float = OUTER_THRESHOLD,
            span: int = SNAP_SPAN) -> list:
    """Ноги частини: відрізки між сусідніми півотами зігзага 2.3."""
    smooth = ema(row["open"], PERIOD)
    pivots = snap(zigzag(smooth, threshold), row["close"], span)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        legs.append({"first": int(first), "last": int(last),
                     "kind": "up" if pivot.kind == "high" else "down",
                     "end_kind": pivot.kind,
                     "start_kind": previous.kind})
    return legs, smooth


def corrections(leg: dict, smooth: np.ndarray, closes: np.ndarray,
                threshold: float = INNER_THRESHOLD,
                span: int = SNAP_SPAN) -> list:
    """Краї внутрішніх корекцій: зігзаг 0.8 усередині однієї ноги."""
    first, last = leg["first"], leg["last"]
    chunk = smooth[first:last + 1]
    if len(chunk) < 3:
        return []
    inner = snap(zigzag(chunk, threshold), closes[first:last + 1], span)
    out = []
    for pivot in inner:
        index = first + pivot.index
        if first < index < last:
            out.append({"index": int(index), "kind": pivot.kind})
    return out


def mark(row: dict, width: int = WIDTH, body: int = BODY) -> dict:
    """Роль кожної події ряду і скільки ніг та корекцій у ній знайшлось."""
    legs, smooth = legs_of(row)
    count = len(row["t"])
    role = np.full(count, "", dtype=object)
    distance = np.full(count, np.inf)
    inside = np.zeros(count, dtype=bool)
    found = 0

    def put(index: int, name: str, low: int, high: int, back: bool) -> None:
        """Якір і `width` подій з одного боку, не виходячи за межі ноги.

        Роль «нога спинилась» (кінець ноги, верх корекції в нозі вгору)
        дивиться **назад**: у неї заходить підхід до якоря. Роль «нога
        рушила» (початок ноги, вихід із корекції) дивиться **вперед**.
        Так обидві групи однакового розміру і обидві причинні.
        """
        left = max(index - width, low) if back else index
        right = index if back else min(index + width, high)
        for step in range(left, right + 1):
            if role[step] == "":
                role[step] = name
        near = np.abs(np.arange(low, high + 1) - index)
        distance[low:high + 1] = np.minimum(distance[low:high + 1], near)

    for leg in legs:
        low, high = leg["first"], leg["last"]
        inside[low:high + 1] = True
        marks = corrections(leg, smooth, row["close"])
        found += len(marks)
        # Спершу краї ноги: вони головні й не поступаються корекції.
        put(high, "кінець", low, high, True)
        put(low, "початок", low, high, False)
        for pivot in marks:
            stop = pivot["kind"] == leg["end_kind"]
            name = "корекція-як-кінець" if stop else "корекція-як-початок"
            put(pivot["index"], name, low, high, stop)

    empty = (role == "") & inside & (distance > body)
    role[empty] = "тіло"
    return {"role": role, "legs": legs, "corrections": found,
            "inside": int(inside.sum())}


def shape(row: dict, width: int = WIDTH) -> dict:
    """Скільки корекцій у нозі, де вони стоять і що з них видно про повноту.

    Питання просте: чи каже **число корекцій, що вже сталися**, яку
    частку ноги пройдено. Якщо каже — це готовий вхід фіксованої
    довжини замість самої послідовності.
    """
    legs, smooth = legs_of(row)
    lengths, counts, spots, pace = [], [], [], []
    share, seen, step = [], [], []
    for leg in legs:
        low, high = leg["first"], leg["last"]
        length = high - low + 1
        marks = corrections(leg, smooth, row["close"])
        lengths.append(length)
        counts.append(len(marks))
        for number, pivot in enumerate(marks, start=1):
            spots.append((pivot["index"] - low) / max(length - 1, 1))
            pace.append(number)
        edges = np.array([pivot["index"] for pivot in marks], dtype=int)
        index = np.arange(low, high + 1)
        done = np.searchsorted(edges, index, side="right") if len(edges) else \
            np.zeros(len(index), dtype=int)
        share.append((index - low) / max(length - 1, 1))
        seen.append(done)
        step.append(index - low)
    share = np.concatenate(share) if share else np.zeros(0)
    seen = np.concatenate(seen) if seen else np.zeros(0)
    step = np.concatenate(step) if step else np.zeros(0)
    out = {"legs": len(legs), "length": spread_of(np.array(lengths, float)),
           "corrections": spread_of(np.array(counts, float)),
           "spot": spread_of(np.array(spots, float)),
           "share_by_count": float(spearman(seen, share)) if len(share) else None,
           "share_by_step": float(spearman(step, share)) if len(share) else None}
    by = {}
    for number in range(0, 6):
        mask = seen == number
        if mask.sum() > 30:
            by[str(number)] = {"events": int(mask.sum()),
                               "share": spread_of(share[mask])}
    out["by_count"] = by
    return out


def spread_of(values: np.ndarray) -> dict:
    """Пʼять чисел розподілу — ті самі, що в `leg_markup.spread`."""
    values = values[np.isfinite(values)]
    if not len(values):
        return {}
    return {"n": int(len(values)), "min": float(values.min()),
            "q25": float(np.percentile(values, 25)),
            "median": float(np.median(values)),
            "q75": float(np.percentile(values, 75)),
            "max": float(values.max()), "mean": float(values.mean())}


def spearman(first: np.ndarray, second: np.ndarray) -> float:
    """Спірмен: Пірсон на рангах."""
    left, right = rankdata(first), rankdata(second)
    left = left - left.mean()
    right = right - right.mean()
    bottom = np.sqrt((left ** 2).sum() * (right ** 2).sum())
    return float((left * right).sum() / bottom) if bottom else float("nan")


def auc_of(ranks: np.ndarray, mask: np.ndarray) -> float:
    """AUC з готових рангів: чи стоїть група `mask` вище за решту."""
    left = int(mask.sum())
    right = len(mask) - left
    if not left or not right:
        return float("nan")
    total = float(ranks[mask].sum())
    return (total - left * (left + 1) / 2) / (left * right)


def couple(table: np.ndarray, role: np.ndarray, titles: list,
           left: str, right: str, seed: int = SEED,
           shuffles: int = SHUFFLES) -> dict:
    """AUC кожної колонки на парі ролей і підлога на перемішаних мітках.

    Ранги колонки рахуються **один раз**: перестановка мітки їх не
    міняє, вона міняє тільки те, чия сума береться. Підлога — не одна
    перестановка, а `shuffles` перестановок при тих самих розмірах
    груп: з них береться найбільший відхід від 0.5. Колонка, чия AUC не
    виходить за цю підлогу, нічого не показала.
    """
    mask_left, mask_right = role == left, role == right
    if not mask_left.sum() or not mask_right.sum():
        return {}
    picked = mask_left | mask_right
    truth = mask_left[picked]
    values = table[picked]
    rng = np.random.default_rng(seed)
    draws = [rng.permutation(truth) for _ in range(shuffles)]
    out = {}
    for column, title in enumerate(titles):
        series = values[:, column]
        good = np.isfinite(series)
        ranks = rankdata(series[good])
        noise = [auc_of(ranks, draw[good]) for draw in draws]
        gap = max(abs(value - 0.5) for value in noise)
        out[title] = {"auc": auc_of(ranks, truth[good]),
                      "floor_low": 0.5 - gap, "floor_high": 0.5 + gap}
    return {"left": left, "right": right, "n_left": int(mask_left.sum()),
            "n_right": int(mask_right.sum()), "columns": out}


def medians(table: np.ndarray, role: np.ndarray, titles: list) -> dict:
    """Медіана рангу кожної колонки в кожній ролі."""
    out = {}
    for name in ROLES:
        mask = role == name
        if not mask.sum():
            continue
        out[name] = {title: float(np.nanmedian(table[mask, column]))
                     for column, title in enumerate(titles)}
    return out


def gather(pairs: list, width: int, body: int,
           root: Path | None = None) -> dict:
    """Ранги, ролі й облік по всіх монетах; train і val окремо."""
    parts = {part: {"table": [], "role": [], "coin": [], "rows": []}
             for part in PARTS}
    titles = None
    for pair in pairs:
        base = None
        for part in PARTS:
            row = load(pair, part, root)
            table, titles = columns(row["x"], row["features"])
            if part == "train":
                base = table
            marked = mark(row, width, body)
            ranks = ranked(table, base if base is not None else table)
            keep = marked["role"] != ""
            parts[part]["table"].append(ranks[keep])
            parts[part]["role"].append(marked["role"][keep])
            parts[part]["coin"].append(np.full(int(keep.sum()), pair))
            counts = {name: int((marked["role"] == name).sum())
                      for name in ROLES}
            parts[part]["rows"].append(
                {"pair": pair, "part": part, "events": len(row["t"]),
                 "inside": marked["inside"], "legs": len(marked["legs"]),
                 "corrections": marked["corrections"], "roles": counts,
                 "shape": shape(row, width)})
    out = {}
    for part in PARTS:
        out[part] = {
            "table": np.concatenate(parts[part]["table"]),
            "role": np.concatenate(parts[part]["role"]),
            "coin": np.concatenate(parts[part]["coin"]),
            "rows": parts[part]["rows"]}
    return out, titles


def measure(part: dict, titles: list, seed: int = SEED) -> dict:
    """Пари ролей: AUC на всіх монетах разом і по кожній монеті окремо."""
    table, role, coin = part["table"], part["role"], part["coin"]
    couples = []
    for left, right in COUPLES:
        shared = couple(table, role, titles, left, right, seed)
        if not shared:
            continue
        spread = {}
        for pair in sorted(set(coin.tolist())):
            mask = coin == pair
            one = couple(table[mask], role[mask], titles, left, right, seed)
            if one:
                spread[pair] = {title: one["columns"][title]["auc"]
                                for title in titles}
        shared["coins"] = spread
        couples.append(shared)
    return {"couples": couples,
            "medians": medians(table, role, titles),
            "rows": part["rows"]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--width", type=int, default=WIDTH,
                        help="скільки подій навколо якоря входить у роль")
    parser.add_argument("--body", type=int, default=BODY,
                        help="далі за стільки подій від якорів — тіло")
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS / "roles.json")
    args = parser.parse_args()

    parts, titles = gather(args.pairs, args.width, args.body, args.root)
    report = {"class": CLASS, "pairs": args.pairs, "width": args.width,
              "body": args.body, "seed": args.seed, "period": PERIOD,
              "shuffles": SHUFFLES,
              "outer": OUTER_THRESHOLD, "inner": INNER_THRESHOLD,
              "span": SNAP_SPAN, "stats": list(STATS), "columns": titles,
              "roles": list(ROLES)}
    for name, part in parts.items():
        report[name] = measure(part, titles, args.seed)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=1))

    for name in PARTS:
        rows = report[name]["rows"]
        print(f"[{name}] ніг {sum(r['legs'] for r in rows)}, "
              f"корекцій {sum(r['corrections'] for r in rows)}, "
              f"подій у ногах {sum(r['inside'] for r in rows)}")
        for pick in report[name]["couples"][:2]:
            best = max(pick["columns"].items(),
                       key=lambda item: abs(item[1]["auc"] - 0.5))
            print(f"  {pick['left']} проти {pick['right']}: "
                  f"{pick['n_left']} / {pick['n_right']}, "
                  f"найсильніша {best[0]} AUC {best[1]['auc']:.3f} "
                  f"(підлога {best[1]['floor_low']:.3f}"
                  f" … {best[1]['floor_high']:.3f})")
    print(args.out)


if __name__ == "__main__":
    main()
