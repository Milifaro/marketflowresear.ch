"""Початок і кінець ноги на канві 500: чи відрізняються, і на яких фічах.

Дослідження: research/35-leg-fullness/ → Етап 5

## Хід

1. Вхід — канва етапу 4 кожного класу (`canvas_<part>_<клас>.npz`,
   масив `net`: `500 × F` після нормування на свою ногу).
2. **Голова** ноги — перші 5 % канви (25 **живих** рядків), **хвіст** —
   останні 25 живих рядків. Вікно — `25 × F` чисел, розгорнуте в
   вектор. Мертві рядки (перший рядок похідної, голова короткої ноги)
   у вікна не йдуть — інакше нулі на одному місці роблять голови
   схожими між собою формально. Нога береться, коли живих рядків
   ≥ 90 % канви.
3. Кореляція Пірсона **між ногами**: кожне вікно з кожним вікном інших
   ніг. Середні:
   - `голова–голова` — голови різних ніг між собою;
   - `хвіст–хвіст` — хвости різних ніг між собою;
   - `голова–хвіст` — голова однієї ноги з хвостом іншої;
   - `своя` — голова і хвіст тієї самої ноги;
   - **розрив** = `(голова–голова + хвіст–хвіст) / 2 − голова–хвіст`:
     наскільки початки схожі на початки, а кінці на кінці, більше, ніж
     початок на кінець.
4. **Влучність**: вікно відноситься до голів або хвостів за середньою
   кореляцією з головами й хвостами **інших** ніг (своя нога не бере
   участі); частка правильних.
5. **Підлога** — 200 перемішувань: у кожній нозі голова й хвіст
   міняються місцями з імовірністю ½; 95-й перцентиль розриву й
   влучності на перемішаних мітках. Вище підлоги — різниця справжня.
6. Те саме **по кожній фічі окремо** (вікно `25 × 1`) і AUC рівня фічі —
   середнє вікна голови проти хвоста по ногах, з підлогою тим самим
   перемішуванням.
7. **Контроль** — ті самі заміри на двох вікнах із середини ноги (з
   30-го і 65-го відсотка живих рядків): розрив має бути на рівні
   підлоги, інакше метод бачить різницю там, де її немає.
8. Групи ніг: усі, вгору, вниз — ноги різних напрямків дзеркальні,
   і в спільній групі знаки гасять один одного. Train і val окремо.

Запуск:
    python3 research/35-leg-fullness/scripts/head_tail30.py
    python3 research/35-leg-fullness/scripts/head_tail30.py --classes x10m1x7dd

Вихід: results/head_tail30.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classes30  # noqa: E402
from bars30 import DATA, PARTS, RESULTS, ROWS  # noqa: E402

SHARE = 0.05                   # частка канви на голову і на хвіст
LIVE = 0.9                     # живих рядків у вікні, щоб нога бралась
SHUFFLES = 200
SEED = 35
GROUPS = ("all", "up", "down")


def windows(net: np.ndarray, mask: np.ndarray, share: float = SHARE,
            live: float = LIVE) -> dict:
    """Вікна ніг по `w = share · rows` **живих** рядків, `(L, w, F)`:
    голова — перші живі рядки, хвіст — останні, контроль — два вікна
    всередині ноги (з 30-го і з 65-го відсотка живих рядків). Мертві
    рядки (перший рядок похідної, голова короткої ноги) у вікна не
    йдуть. Нога береться, коли живих рядків ≥ `live · rows`."""
    rows = net.shape[1]
    width = max(1, int(round(rows * share)))
    keep = mask.sum(axis=1) >= live * rows
    out = {name: np.zeros((len(net), width, net.shape[2]), dtype=net.dtype)
           for name in ("head", "tail", "middle_a", "middle_b")}
    for leg in np.flatnonzero(keep):
        index = np.flatnonzero(mask[leg])
        count = len(index)
        starts = {"head": 0, "tail": count - width,
                  "middle_a": int(count * 0.30), "middle_b": int(count * 0.65)}
        for name, start in starts.items():
            out[name][leg] = net[leg, index[start:start + width]]
    out["keep"] = keep
    out["width"] = width
    return out


def standardize(x: np.ndarray) -> np.ndarray:
    """Рядки з нульовим середнім і одиничною довжиною; сталий рядок — 0."""
    x = x - x.mean(axis=1, keepdims=True)
    norm = np.linalg.norm(x, axis=1, keepdims=True)
    return np.divide(x, norm, out=np.zeros_like(x), where=norm > 0)


def labels(legs: int, shuffles: int, rng) -> np.ndarray:
    """Мітки «голова» для 2L вікон: перший стовпчик — справжні, далі —
    перемішані (у кожній нозі голова й хвіст міняються з імовірністю ½)."""
    swap = np.zeros((legs, shuffles + 1), dtype=bool)
    swap[:, 1:] = rng.random((legs, shuffles)) < 0.5
    return np.concatenate([~swap, swap]).astype(float)


def scores(head: np.ndarray, tail: np.ndarray, shuffles: int = SHUFFLES,
           seed: int = SEED) -> dict:
    """Кореляції між ногами, розрив і влучність з підлогою.

    `head`, `tail` — `(L, d)`. Вікна: спершу L голів, потім L хвостів.
    """
    legs = len(head)
    if legs < 3:
        return {"legs": legs}
    z = standardize(np.concatenate([head, tail]).astype(np.float64))
    gram = z @ z.T
    own = float(np.mean(np.einsum("ij,ij->i", z[:legs], z[legs:])))
    # пари всередині однієї ноги й діагональ не беруть участі
    index = np.arange(legs)
    gram[np.arange(2 * legs), np.arange(2 * legs)] = 0.0
    gram[index, index + legs] = 0.0
    gram[index + legs, index] = 0.0
    a = labels(legs, shuffles, np.random.default_rng(seed))
    b = 1.0 - a
    ga, gb = gram @ a, gram @ b
    pairs = legs * (legs - 1)
    hh = np.sum(a * ga, axis=0) / pairs
    tt = np.sum(b * gb, axis=0) / pairs
    ht = np.sum(a * gb, axis=0) / pairs
    gap = (hh + tt) / 2 - ht
    # вікно — до голів, коли воно ближче до голів інших ніг, ніж до хвостів
    guess = (ga - gb) > 0
    right = np.mean(guess == (a > 0.5), axis=0)
    return {"legs": legs, "hh": float(hh[0]), "tt": float(tt[0]),
            "ht": float(ht[0]), "own": own, "gap": float(gap[0]),
            "gap_floor": float(np.percentile(gap[1:], 95)),
            "gap_p": float((1 + np.sum(gap[1:] >= gap[0])) / (1 + shuffles)),
            "acc": float(right[0]),
            "acc_floor": float(np.percentile(right[1:], 95)),
            "acc_p": float((1 + np.sum(right[1:] >= right[0]))
                           / (1 + shuffles))}


def auc(positive: np.ndarray, negative: np.ndarray) -> float:
    """AUC Манна — Вітні, ранги з середніми для рівних."""
    ranks = rankdata(np.concatenate([positive, negative]))
    n = len(positive)
    return float((ranks[:n].sum() - n * (n + 1) / 2) / (n * len(negative)))


def level_auc(head: np.ndarray, tail: np.ndarray, shuffles: int = SHUFFLES,
              seed: int = SEED) -> dict:
    """AUC рівня фічі (середнє вікна) голова проти хвоста, з підлогою:
    `|AUC − 0.5|` на перемішаних у нозі мітках, 95-й перцентиль."""
    rng = np.random.default_rng(seed)
    real = auc(head, tail)
    floor = []
    for _ in range(shuffles):
        swap = rng.random(len(head)) < 0.5
        floor.append(abs(auc(np.where(swap, tail, head),
                             np.where(swap, head, tail)) - 0.5))
    return {"auc": real, "auc_floor": float(0.5 + np.percentile(floor, 95))}


def measure(net: np.ndarray, mask: np.ndarray, kinds: np.ndarray,
            features: list, shuffles: int = SHUFFLES) -> dict:
    """Усі заміри одного класу на одній частині по трьох групах ніг.

    Поруч із головою й хвостом — **контроль**: ті самі заміри на двох
    вікнах із середини ноги. Метод без упередження дає на ньому розрив
    на рівні підлоги."""
    cut = windows(net, mask)
    out = {}
    for group in GROUPS:
        pick = cut["keep"] & ((kinds == group) if group != "all" else True)
        h, t = cut["head"][pick], cut["tail"][pick]
        a, b = cut["middle_a"][pick], cut["middle_b"][pick]
        one = {"all": scores(h.reshape(len(h), -1), t.reshape(len(t), -1),
                             shuffles),
               "control": scores(a.reshape(len(a), -1),
                                 b.reshape(len(b), -1), shuffles),
               "features": {}}
        for column, name in enumerate(features):
            item = scores(h[:, :, column], t[:, :, column], shuffles)
            if len(h) >= 3:
                item.update(level_auc(h[:, :, column].mean(axis=1),
                                      t[:, :, column].mean(axis=1), shuffles))
                item["control_gap"] = scores(a[:, :, column], b[:, :, column],
                                             shuffles).get("gap")
            one["features"][name] = item
        out[group] = one
    return out


def kinds_of(keys: np.ndarray, table: dict, part: str) -> np.ndarray:
    """Напрямок кожної ноги канви за ключем `<PAIR>·<N>`."""
    kind = {f"{pair}·{leg['leg']}": leg["kind"]
            for pair, parts in table["legs"].items()
            for leg in parts.get(part, [])}
    return np.array([kind[str(key)] for key in keys])


def build(keys: list | None = None, data: Path = DATA,
          shuffles: int = SHUFFLES, log=print) -> dict:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    keys = list(keys or [one["key"] for one in classes30.CLASSES])
    report = {"share": SHARE, "rows": ROWS,
              "width": int(round(ROWS * SHARE)), "live": LIVE,
              "shuffles": shuffles, "seed": SEED, "groups": list(GROUPS),
              "control": [0.30, 0.65],
              "parts": list(PARTS), "classes": {}}
    for key in keys:
        one = classes30.BY_KEY[key]
        report["classes"][key] = {"name": one["name"],
                                  "features": list(one["features"])}
        for part in PARTS:
            with np.load(data / f"canvas_{part}_{key}.npz") as store:
                net, mask, names = store["net"], store["mask"], store["key"]
            report["classes"][key][part] = measure(
                net, mask, kinds_of(names, table, part), one["features"],
                shuffles)
            got = report["classes"][key][part]["all"]["all"]
            log(f"{one['name']} {part}: ніг {got.get('legs')}, розрив "
                f"{got.get('gap', float('nan')):.4f} (підлога "
                f"{got.get('gap_floor', float('nan')):.4f}), влучність "
                f"{got.get('acc', float('nan')):.3f}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--classes", nargs="+", default=None)
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--shuffles", type=int, default=SHUFFLES)
    parser.add_argument("--out", type=Path,
                        default=RESULTS / "head_tail30.json")
    args = parser.parse_args()
    report = build(args.classes, args.data, args.shuffles)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=1))
    print(args.out)


if __name__ == "__main__":
    main()
