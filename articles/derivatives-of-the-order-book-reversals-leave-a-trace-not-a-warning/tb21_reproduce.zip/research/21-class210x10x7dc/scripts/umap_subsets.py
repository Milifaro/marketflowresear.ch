"""UMAP підмножин фіч: кожна фіча окремо і будь-яка їх комбінація.

Дослідження: research/21-class210x10x7dc/
Правила: rules/05-visualization.md → UMAP

Розділи 1 і 5 будували карту по **всіх** фічах разом. Тут карта будується
по будь-якій підмножині: одна фіча, дві, три … усі сім. Так видно, яка
саме фіча тримає структуру, а яка нічого не додає.

## Точка карти

Точка — **пачка**, розмічена так само, як у розділі 9 (`reversal_batches`):

    нижній розворот   у межах пачки стоїть півот low
    верхній розворот  у межах пачки стоїть півот high
    інша              півота в пачці немає

Пачки не перекриваються, довжини дві: `W = 5` і `W = 20`.

## Вектор точки

Фіча в пачці — це ряд з `9W` блоків, тому в число вона зводиться
згорткою. Беруться **всі вісім** згорток (`pivot_compare.AGGREGATES`),
тому підмножина з `k` фіч дає вектор у `8k` значень: одна фіча — 8,
усі сім — 56.

## Вибірка

Одна на всі підмножини й обидві метрики довжини — інакше карти не
порівнюються. Вибірка **розшарована**: усі пачки з розворотом і випадкова
решта до `SAMPLE`, бо розворотів менше відсотка.

`NaN` відкидається **на кожній підмножині окремо**: карта по ціні втрачає
кілька пачок, карта по стакану — багато, бо блок з нульовим обʼємом дає
`NaN` саме там. Скільки відкинуто — у `meta.dropped_nan` кожної карти.

## Метрика

Підмножин 127, і на трьох метриках це вісім сотень карт. Вісь, уздовж
якої тут дивляться, — **набір фіч**, а не метрика, тому карти будуються
`cosine`: rules/05 називає її основною для читання. Три метрики
лишаються на картах класів (розділ 1 вкладки).

## Класи

Скрипт працює з кількома класами події, і кожен пише в свої файли:

| `--class` | Клас | фіч | наборів | префікс файлів |
| --------- | ---- | --- | ------- | -------------- |
| `x7` | `клас210х10-1х7дц` | 7 | 127 | `umapf_` |
| `x3p1` | `клас210х10-1х3+1дц` | 4 | 15 | `umapg_` |
| `x2d` | `клас210х10-1х2д` | 2 | 3 | `umaph_` |
| `x7dd` | `клас210х10-1х7д/д` | 7 | 127 | `umapi_` |

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/umap[f|g]_w<W>_<набір>.json — точки й meta однієї карти
       results/umap_subsets[31].json        — перелік наборів і карт

Запуск:
    python3 research/21-class210x10x7dc/scripts/umap_subsets.py
    python3 research/21-class210x10x7dc/scripts/umap_subsets.py --class x3p1
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x10m1x2d  # noqa: E402
import class210x10m1x3p1dc  # noqa: E402
import class210x10m1x7dc  # noqa: E402
import class210x10m1x7dd  # noqa: E402
import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import reversal_batches as reversal  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
BATCHES = (5, 20)
METRIC = "cosine"
DIMS = 3
SAMPLE = 6000
SEED = 0
N_NEIGHBORS = 30
MIN_DIST = 0.1

# Клас події: модуль, тека датасету, префікс файлів карт і імʼя індексу.
CLASSES = {
    "x7": {"module": class210x10m1x7dc, "folder": "class210x10m1x7dc",
           "title": "клас210х10-1х7дц", "prefix": "umapf",
           "index": "umap_subsets.json"},
    "x3p1": {"module": class210x10m1x3p1dc, "folder": "class210x10m1x3p1dc",
             "title": "клас210х10-1х3+1дц", "prefix": "umapg",
             "index": "umap_subsets31.json"},
    "x2d": {"module": class210x10m1x2d, "folder": "class210x10m1x2d",
            "title": "клас210х10-1х2д", "prefix": "umaph",
            "index": "umap_subsets2d.json"},
    "x7dd": {"module": class210x10m1x7dd, "folder": "class210x10m1x7dd",
             "title": "клас210х10-1х7д/д", "prefix": "umapi",
             "index": "umap_subsets7dd.json"},
}
DEFAULT_CLASS = "x7"
# Порядок класів там, де вони показані разом (теплові карти, хід по нозі):
# спершу повний клас, далі похідні від нього — новий клас іде в кінець.
ORDER = ("x7", "x3p1", "x2d", "x7dd")


def short(name: str) -> str:
    """`d_bal_resist` -> `bal_resist`: у ключі набору префікс зайвий."""
    return name[2:] if name.startswith("d_") else name


def key_of(picked: tuple, features: list) -> str:
    """Ключ набору: `all` для повного, інакше короткі імена через дефіс."""
    return "all" if len(picked) == len(features) else "-".join(
        short(features[index]) for index in picked)


def subsets(features: list) -> list:
    """Усі непорожні підмножини фіч, від однієї до всіх."""
    out = []
    for size in range(1, len(features) + 1):
        for picked in itertools.combinations(range(len(features)), size):
            out.append({"key": key_of(picked, features), "size": size,
                        "features": [features[index] for index in picked],
                        "index": list(picked)})
    return out


def batch_points(state: dict, size: int) -> dict:
    """Пачки train усіх монет: колонки, мітка, час, монета."""
    edge = stamp(CUT)
    cols, label, stamps, coin = [], [], [], []
    for index, one in enumerate(state["coins"]):
        part = reversal.coin_batches(one, size)
        keep = part["t_end"] < edge
        cols.append(part["cols"][keep])
        label.append(part["label"][keep])
        stamps.append(part["t_start"][keep])
        coin.append(np.full(int(keep.sum()), index, dtype=np.int16))
    return {"cols": np.concatenate(cols), "label": np.concatenate(label),
            "t": np.concatenate(stamps), "coin": np.concatenate(coin)}


def columns_for(names: list, features: list) -> list:
    """Індекси колонок усіх восьми згорток заданих фіч."""
    wanted = set(features)
    return [index for index, column in enumerate(names)
            if column["kind"] == "agg" and column["feature"] in wanted]


def run(data: dict, picked: dict, names: list, size: int, out_dir: Path,
        sample: np.ndarray, metric: str = METRIC, dims: int = DIMS,
        seed: int = SEED, prefix: str = "umapf") -> dict:
    import umap  # важкий імпорт: тільки коли справді рахуємо

    columns = columns_for(names, picked["features"])
    flat = data["cols"][sample][:, columns]
    finite = np.isfinite(flat).all(axis=1)
    index = sample[finite]
    flat = flat[finite]
    mean, std = flat.mean(axis=0), flat.std(axis=0)
    std[std == 0] = 1.0

    started = time.time()
    coords = umap.UMAP(n_components=dims, n_neighbors=N_NEIGHBORS,
                       min_dist=MIN_DIST, metric=metric, random_state=seed,
                       verbose=False).fit_transform((flat - mean) / std)
    elapsed = time.time() - started

    label = data["label"][index]
    meta = {
        "batch": size, "key": picked["key"], "size": picked["size"],
        "features": list(picked["features"]), "dims": dims, "metric": metric,
        "pairs": list(PAIRS), "events": int(len(index)),
        "batches": int(len(data["label"])), "sample": int(len(sample)),
        "dropped_nan": int((~finite).sum()),
        "vector_size": int(flat.shape[1]),
        "params": {"n_components": dims, "n_neighbors": N_NEIGHBORS,
                   "min_dist": MIN_DIST, "metric": metric,
                   "random_state": seed, "sample": SAMPLE},
        "seconds": round(elapsed, 1),
        "labels": list(reversal.LABELS),
        "by_label": {str(one["id"]): int((label == one["id"]).sum())
                     for one in reversal.LABELS},
        "stratified": True,
    }
    body = dict(meta)
    coords = np.asarray(coords, dtype=float)
    for axis, name in enumerate(("x", "y", "z")[:dims]):
        body[name] = [round(float(value), 3) for value in coords[:, axis]]
    body["t"] = [int(value) for value in data["t"][index]]
    body["g"] = [int(value) for value in label]
    body["c"] = [int(value) for value in data["coin"][index]]
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{prefix}_w{size}_{picked['key']}.json").write_text(
        json.dumps(body, ensure_ascii=False), encoding="utf-8")
    return meta


def write_index(out_dir: Path, kind: dict, class_id: str, features: list,
                sample: int, maps: list) -> None:
    """Перелік готових карт. Пишеться після кожної карти, а не в кінці:
    прогін на 127 наборів іде довго, і вкладка має показувати те, що
    вже пораховано. Довжини пачки в переліку — тільки ті, у яких карти
    вже є, інакше кнопка вела б у порожнечу."""
    sizes = sorted({one["batch"] for one in maps})
    (out_dir / kind["index"]).write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/umap_subsets.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   f"umap_subsets.py --class {class_id}",
        "class": kind["folder"], "class_id": class_id,
        "class_title": kind["title"], "prefix": kind["prefix"],
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "features": features, "aggregates": pivot.AGGREGATES,
        "labels": list(reversal.LABELS), "batches": sizes,
        "default_batch": sizes[0] if sizes else None,
        "metric": METRIC, "dims": DIMS,
        "sample": sample, "event_seconds": EVENT_LENGTH,
        "maps": [{key: one[key] for key in
                  ("batch", "key", "size", "features", "events",
                   "dropped_nan", "vector_size", "by_label", "seconds")}
                 for one in maps],
        "ready": bool(maps)}, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--sample", type=int, default=SAMPLE)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--size", type=int, action="append", default=None,
                        help="лишити тільки набори такого розміру")
    parser.add_argument("--class", dest="class_id", default=DEFAULT_CLASS,
                        choices=sorted(CLASSES))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    kind = CLASSES[args.class_id]
    sizes = tuple(args.batch) if args.batch else BATCHES
    state = pivot.collect(args.data, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None,
                          module=kind["module"], folder_name=kind["folder"])
    names = pivot.column_names(state["features"])
    picked = subsets(state["features"])
    if args.size:
        picked = [one for one in picked if one["size"] in set(args.size)]

    maps, made = [], 0
    for size in sizes:
        data = batch_points(state, size)
        sample = reversal.np.sort(
            run_sample(data["label"], args.sample, args.seed))
        print(f"[пачка {size}] пачок train {len(data['label'])}, "
              f"вибірка {len(sample)}, наборів {len(picked)}")
        for one in picked:
            meta = run(data, one, names, size, args.out, sample,
                       seed=args.seed, prefix=kind["prefix"])
            maps.append(meta)
            made += 1
            write_index(args.out, kind, args.class_id, state["features"],
                        args.sample, maps)
            if made % 20 == 0 or one is picked[-1]:
                print(f"      {made} карт готово, остання "
                      f"{one['key']} за {meta['seconds']} с")
    print(f"записано {len(maps)} карт у {args.out}")


def run_sample(label, size: int, seed: int):
    """Розшарована вибірка: всі пачки з розворотом і випадкова решта."""
    import run_umap_reversal
    return run_umap_reversal.sample_index(label, size, seed)


if __name__ == "__main__":
    main()
