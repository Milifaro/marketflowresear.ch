"""UMAP пачок «розворот був»: 2д і 3д × три метрики.

Дослідження: research/21-class210x10x7dc/
Правила: rules/05-visualization.md → UMAP

Карта будується на **всіх пачках train усіх шести монет** — тих самих, на
які датасет порізаний у `reversal_batches.py`. Вектор пачки — її згортки:
вісім способів звести ряд у число × сім фіч, разом 56 значень.

    пачки train (6 монет) -> вибірка SAMPLE, seed 0
    -> 56 згорток -> z-score на вибірці -> UMAP

Вибірка **розшарована**: беруться **всі** пачки з розворотом і випадкова
решта до `SAMPLE`. Пачок з розворотом менше відсотка, і на випадковій
вибірці їх лишилось би кілька десятків. Через це щільність точок на карті
вже не відповідає щільності в датасеті — карта читається як сусідство,
а не як «де густіше».

Пачка з `NaN` хоч в одній згортці не проєктується (rules/05); скільки
таких — у `meta.dropped_nan`.

Кожна точка несе мітку пачки: `0` інша, `1` нижній розворот, `2` верхній.
Розфарбування на вкладці — за нею: зелене вгору, червоне вниз, сіре без
розвороту.

Вхід : results/reversal_batches.npz  (reversal_batches.py)
Вихід: results/umapr_train_<metric>.{json,meta.json,npz}      — 2д
       results/umapr3d_train_<metric>.{json,meta.json,npz}    — 3д

Запуск:
    python3 research/21-class210x10x7dc/scripts/run_umap_reversal.py
    python3 research/21-class210x10x7dc/scripts/run_umap_reversal.py \
        --metric cosine --dims 3
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pivot_compare as pivot  # noqa: E402
import reversal_batches as reversal  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
METRICS = ("cosine", "euclidean", "manhattan")
DIMS = (2, 3)
SAMPLE = 30000
SEED = 0
N_NEIGHBORS = 30
MIN_DIST = 0.1


def stem(metric: str, dims: int = 2) -> str:
    """Імʼя файлів карти. `r` — пачки розворотів, щоб не змішатись з рештою."""
    return f"umapr_train_{metric}" if dims == 2 \
        else f"umapr{dims}d_train_{metric}"


def load(path: Path | None = None) -> dict:
    """Пачки train усіх монет одним набором."""
    source = path or RESULTS / "reversal_batches.npz"
    if not source.exists():
        raise SystemExit(f"немає {source}: спершу reversal_batches.py")
    with np.load(source, allow_pickle=False) as data:
        pairs = [str(one) for one in data["pairs"]]
        columns = [json.loads(one) for one in data["columns"]]
        x = np.concatenate([data[f"{pair}_x"] for pair in pairs])
        y = np.concatenate([data[f"{pair}_y"] for pair in pairs])
        t = np.concatenate([data[f"{pair}_t"] for pair in pairs])
        coin = np.concatenate([np.full(len(data[f"{pair}_y"]), index,
                                       dtype=np.int16)
                               for index, pair in enumerate(pairs)])
        batch = int(data["batch"])
    keep = [index for index, column in enumerate(columns)
            if column["kind"] == "agg"]
    return {"x": np.asarray(x, dtype=np.float64)[:, keep], "y": y, "t": t,
            "coin": coin, "pairs": pairs, "batch": batch,
            "columns": [columns[index] for index in keep]}


def sample_index(label: np.ndarray, size: int = SAMPLE, seed: int = SEED
                 ) -> np.ndarray:
    """Розшарована вибірка: усі пачки з розворотом і випадкова решта.

    Та сама для всіх метрик і вимірностей — один seed на всі.
    """
    label = np.asarray(label)
    marked = np.flatnonzero(label > 0)
    rest = np.flatnonzero(label == 0)
    if size >= len(label):
        return np.arange(len(label))
    room = max(size - len(marked), 0)
    rng = np.random.default_rng(seed)
    picked = rng.choice(rest, size=min(room, len(rest)), replace=False)
    return np.sort(np.concatenate([marked, picked]))


def run(data: dict, metric: str, dims: int, out_dir: Path,
        size: int = SAMPLE, seed: int = SEED, n_neighbors: int = N_NEIGHBORS,
        min_dist: float = MIN_DIST) -> dict:
    import umap  # важкий імпорт: тільки коли справді рахуємо

    picked = sample_index(data["y"], size, seed)
    tag = f"{metric} {dims}D"
    print(f"[1/4] {tag}: пачок train {len(data['y'])}, вибірка {len(picked)}")

    flat = data["x"][picked]
    finite = np.isfinite(flat).all(axis=1)
    dropped = int((~finite).sum())
    index = picked[finite]
    flat = flat[finite]
    print(f"[2/4] {tag}: вектор пачки {flat.shape[1]} згорток, "
          f"пачок з NaN відкинуто {dropped}")

    mean = flat.mean(axis=0)
    std = flat.std(axis=0)
    std[std == 0] = 1.0
    started = time.time()
    reducer = umap.UMAP(n_components=dims, n_neighbors=n_neighbors,
                        min_dist=min_dist, metric=metric, random_state=seed,
                        verbose=False)
    coords = reducer.fit_transform((flat - mean) / std).astype(np.float32)
    elapsed = time.time() - started
    print(f"[3/4] {tag}: готово {coords.shape} за {elapsed:.0f} с")

    label = data["y"][index]
    coin = data["coin"][index]
    stamps = data["t"][index]
    out_dir.mkdir(parents=True, exist_ok=True)
    name = stem(metric, dims)
    meta = {
        "source": "results/reversal_batches.npz",
        "class_name": pivot.CLASS, "class_title": "клас210х10-1х7дц",
        "dims": dims, "batch": data["batch"], "pairs": data["pairs"],
        "events": int(len(index)), "train_batches": int(len(data["y"])),
        "sample": int(len(picked)), "dropped_nan": dropped,
        "stratified": True,
        "vector_size": int(flat.shape[1]),
        "features": [f"{one['agg']}·{one['feature']}"
                     for one in data["columns"]],
        "params": {"n_components": dims, "n_neighbors": n_neighbors,
                   "min_dist": min_dist, "metric": metric,
                   "random_state": seed, "sample": size},
        "seconds": round(elapsed, 1),
        "labels": list(reversal.LABELS),
        "by_label": {str(one["id"]): int((label == one["id"]).sum())
                     for one in reversal.LABELS},
        "by_pair": {pair: int((coin == index).sum())
                    for index, pair in enumerate(data["pairs"])},
    }
    keys = ("x", "y", "z")
    payload = dict(meta)
    payload["points"] = [
        {**{keys[i]: round(float(value), 3) for i, value in enumerate(point)},
         "t": int(ts), "g": int(mark), "c": int(one)}
        for point, ts, mark, one in zip(coords, stamps, label, coin)]
    (out_dir / f"{name}.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    (out_dir / f"{name}.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    np.savez_compressed(out_dir / f"{name}.npz", coords=coords,
                        timestamp=stamps, coin=coin, label=label)
    print(f"[4/4] {tag}: записано в {out_dir}")
    return meta


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metric", default=None, choices=METRICS)
    parser.add_argument("--dims", type=int, default=None, choices=DIMS)
    parser.add_argument("--sample", type=int, default=SAMPLE)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--input", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    data = load(args.input)
    metrics = [args.metric] if args.metric else list(METRICS)
    dims = [args.dims] if args.dims else list(DIMS)
    maps = [run(data, metric, size, args.out, args.sample, args.seed)
            for metric in metrics for size in dims]
    (args.out / "umapr_maps.json").write_text(
        json.dumps({"script": "research/21-class210x10x7dc/scripts/"
                              "run_umap_reversal.py",
                    "command": "python3 research/21-class210x10x7dc/scripts/"
                               "run_umap_reversal.py",
                    "maps": maps, "ready": True},
                   indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
