"""Десятини ніг зігзага 2.3 % на ема10 — когорта кожної події.

Дослідження: research/21-class210x10x7dc/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки
         rules/05-visualization.md → Кольори

Той самий зігзаг, що у дослідженні 19 (вкладка `/leg23`): півоти стоять
на `ема10` ціни події, поріг 2.3 %.

    ема10(price_open) -> півоти зігзага 2.3 % -> ноги -> десятини

Нога — відрізок від події після попереднього півота до самого півота
включно. Нога ділиться на **десять рівних частин за кількістю подій**:
`1` — перші 10 % подій ноги, `10` — останні 10 %. Місце міряється часом,
не ціною.

Напрямок ноги — за півотом, яким вона закінчується: півот зверху
(`high`) закриває ногу **вгору**, півот знизу (`low`) — ногу **вниз**.

Когорта події кодується одним числом:

    0            подія поза ногами (до першого півота і після останнього)
    1 … 10       десятина ноги вгору
    11 … 20      десятина ноги вниз

Вхід : data/datasets/<PAIR>/class210x10x7/{train,val}.npz
Вихід: results/deciles.npz          — когорта кожної події кожної монети
       results/legs_2_3.json        — скільки ніг і подій у кожній когорті
       results/legs_<PAIR>.json     — ряд для графіка: ціна, ема, півоти

Запуск:
    python3 research/21-class210x10x7dc/scripts/leg_deciles.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x10x7  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, PARTS, stamp  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import Pivot, zigzag  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"

THRESHOLD = 0.023          # зігзаг 2.3 %
PERIOD = 10                # ема ціни, на якій стоять півоти
DECILES = 10               # на скільки частин ділиться нога
CHART_POINTS = 4000        # скільки точок лишається на графіку ряду


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def series(pair: str, root: Path | None = None) -> dict:
    """Усі події монети одним рядом за часом: train і val разом."""
    folder = (root or DATASETS) / pair / "class210x10x7"
    t, price = [], []
    for part in PARTS:
        dataset = class210x10x7.load(folder / f"{part}.npz")
        t.append(dataset.t_start)
        price.append(dataset.price_open)
    t = np.concatenate(t)
    price = np.concatenate(price)
    order = np.argsort(t, kind="stable")
    return {"t": t[order].astype(np.int64), "price": price[order].astype(float)}


def cohorts(pivots: list[Pivot], count: int, parts: int = DECILES
            ) -> tuple[np.ndarray, list]:
    """Когорта кожної події: 0 поза ногами, 1…10 вгору, 11…20 вниз."""
    group = np.zeros(count, dtype=np.int16)
    legs = []
    for index, (previous, pivot) in enumerate(zip(pivots, pivots[1:])):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        length = last - first + 1
        place = np.arange(length) / length
        decile = np.minimum(np.floor(place * parts) + 1, parts).astype(np.int16)
        up = pivot.kind == "high"
        group[first:last + 1] = decile + (0 if up else parts)
        legs.append({"leg": index, "kind": "up" if up else "down",
                     "events": int(length), "from": int(first),
                     "to": int(last)})
    return group, legs


def chart(data: dict, smooth: np.ndarray, pivots: list[Pivot],
          group: np.ndarray, points: int = CHART_POINTS) -> dict:
    """Ряд для графіка: ціна, ема і півоти. Довгий ряд проріджується."""
    step = max(1, len(data["t"]) // points)
    keep = np.arange(0, len(data["t"]), step)
    return {
        "step": int(step),
        "points": [{"t": int(data["t"][i]), "p": round(float(data["price"][i]), 6),
                    "e": round(float(smooth[i]), 6), "g": int(group[i])}
                   for i in keep],
        "pivots": [{"t": int(data["t"][p.index]),
                    "e": round(float(smooth[p.index]), 6), "k": p.kind}
                   for p in pivots],
    }


def build_pair(pair: str, root: Path | None = None, period: int = PERIOD,
               threshold: float = THRESHOLD) -> dict:
    data = series(pair, root)
    smooth = ema(data["price"], period)
    pivots = zigzag(smooth, threshold)
    group, legs = cohorts(pivots, len(smooth))
    return {"pair": pair, "data": data, "ema": smooth, "pivots": pivots,
            "group": group, "legs": legs}


def summary(one: dict, cut: str = CUT, end: str = END) -> dict:
    group, data = one["group"], one["data"]
    edge = stamp(cut)
    train = data["t"] < edge
    counts = []
    for value in range(1, DECILES * 2 + 1):
        picked = group == value
        counts.append({
            "group": value,
            "kind": "up" if value <= DECILES else "down",
            "decile": value if value <= DECILES else value - DECILES,
            "events": int(picked.sum()),
            "train": int((picked & train).sum()),
            "val": int((picked & ~train).sum()),
        })
    return {
        "pair": one["pair"],
        "events": int(len(group)),
        "period": {"from_utc": utc(data["t"][0]), "to_utc": utc(data["t"][-1])},
        "pivots": len(one["pivots"]),
        "legs": {"total": len(one["legs"]),
                 "up": sum(1 for leg in one["legs"] if leg["kind"] == "up"),
                 "down": sum(1 for leg in one["legs"] if leg["kind"] == "down"),
                 "shortest": min((leg["events"] for leg in one["legs"]),
                                 default=0),
                 "longest": max((leg["events"] for leg in one["legs"]),
                                default=0),
                 "median": int(np.median([leg["events"]
                                          for leg in one["legs"]]))
                 if one["legs"] else 0},
        "outside": int((group == 0).sum()),
        "cohorts": counts,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--period", type=int, default=PERIOD)
    parser.add_argument("--threshold", type=float, default=THRESHOLD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    pairs = args.pair or list(PAIRS)
    args.out.mkdir(parents=True, exist_ok=True)
    arrays, reports = {}, []
    for pair in pairs:
        one = build_pair(pair, args.data, args.period, args.threshold)
        arrays[f"{pair}_t"] = one["data"]["t"]
        arrays[f"{pair}_g"] = one["group"]
        reports.append(summary(one))
        (args.out / f"legs_{pair}.json").write_text(
            json.dumps({"pair": pair, "threshold": args.threshold,
                        "period": args.period,
                        **chart(one["data"], one["ema"], one["pivots"],
                                one["group"])},
                       ensure_ascii=False), encoding="utf-8")
        print(f"[{pair}] подій {reports[-1]['events']}, "
              f"ніг {reports[-1]['legs']['total']}, "
              f"поза ногами {reports[-1]['outside']}")
    np.savez_compressed(args.out / "deciles.npz", **arrays)
    (args.out / "legs_2_3.json").write_text(
        json.dumps({
            "script": "research/21-class210x10x7dc/scripts/leg_deciles.py",
            "command": "python3 research/21-class210x10x7dc/scripts/"
                       "leg_deciles.py",
            "threshold": args.threshold, "period": args.period,
            "deciles": DECILES, "class": "class210x10x7",
            "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
            "pairs": reports, "ready": True}, indent=2, ensure_ascii=False),
        encoding="utf-8")
    print(f"записано в {args.out}")


if __name__ == "__main__":
    main()
