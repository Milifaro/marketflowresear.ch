"""UMAP чотирьох класів вкладки: 2д і 3д × три метрики.

Дослідження: research/21-class210x10x7dc/
Правила: rules/05-visualization.md → UMAP

Карта будується на **вибірці train усіх шести монет** — тій самій для
всіх чотирьох класів і всіх метрик, щоб карти порівнювались між собою.

    усі події train (6 монет) -> випадкова вибірка SAMPLE, seed 0
    -> вектор події (блоки × фічі) -> z-score на вибірці -> UMAP

Подія з `NaN` хоч в одному значенні не проєктується (rules/05): скільки
таких — у `meta.dropped_nan`.

Кожна точка несе:

    d   зміна ціни за подію, частками — розфарбування розділу 1
    g   когорта десятини ноги зігзага 2.3 % — розфарбування розділу 2
        (0 поза ногами, 1…10 нога вгору, 11…20 нога вниз)
    c   індекс монети в `pairs`

Вхід : data/datasets/<PAIR>/<клас>/train.npz
       results/deciles.npz  (leg_deciles.py)
Вихід: results/umap_train_<metric>_<клас>.{json,meta.json}      — 2д
       results/umap3d_train_<metric>_<клас>.{json,meta.json}     — 3д

Запуск:
    python3 research/21-class210x10x7dc/scripts/run_umap7dc.py
    python3 research/21-class210x10x7dc/scripts/run_umap7dc.py \
        --class class210x10x7dc --metric cosine --dims 3
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x10m1x2d  # noqa: E402
import class210x10m1x3p1dc  # noqa: E402
import class210x10m1x7dc  # noqa: E402
import class210x10m1x7dd  # noqa: E402
import class210x10x7  # noqa: E402
import class210x10x7dc  # noqa: E402
import class210x10x9  # noqa: E402
from build_class210x10x7dc import PAIRS  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"

CLASSES = {"class210x10x9": class210x10x9,
           "class210x10x7": class210x10x7,
           "class210x10x7dc": class210x10x7dc,
           "class210x10m1x7dc": class210x10m1x7dc,
           "class210x10m1x3p1dc": class210x10m1x3p1dc,
           "class210x10m1x2d": class210x10m1x2d,
           "class210x10m1x7dd": class210x10m1x7dd}
TITLES = {"class210x10x9": "клас210х10х9",
          "class210x10x7": "клас210х10х7",
          "class210x10x7dc": "клас210х10х7дц",
          "class210x10m1x7dc": "клас210х10-1х7дц",
          "class210x10m1x3p1dc": "клас210х10-1х3+1дц",
          "class210x10m1x2d": "клас210х10-1х2д",
          "class210x10m1x7dd": "клас210х10-1х7д/д"}

METRICS = ("cosine", "euclidean", "manhattan")
DIMS = (2, 3)
SAMPLE = 30000             # подій на карту: одна вибірка на всі класи
SEED = 0
N_NEIGHBORS = 30
MIN_DIST = 0.1


def stem(metric: str, class_name: str, dims: int = 2) -> str:
    """Імʼя файлів карти — те саме правило, що у дослідженні 01."""
    prefix = "umap_train" if dims == 2 else f"umap{dims}d_train"
    return f"{prefix}_{metric}_{class_name}"


def deciles(path: Path | None = None) -> dict:
    """Когорта кожної події кожної монети: (pair, t) -> група."""
    source = path or RESULTS / "deciles.npz"
    if not source.exists():
        raise SystemExit(f"немає {source}: спершу leg_deciles.py")
    out = {}
    with np.load(source, allow_pickle=False) as data:
        for pair in PAIRS:
            out[pair] = dict(zip(data[f"{pair}_t"].tolist(),
                                 data[f"{pair}_g"].tolist()))
    return out


def sample_index(counts: list[int], size: int = SAMPLE,
                 seed: int = SEED) -> np.ndarray:
    """Ті самі позиції вибірки для будь-якого класу: один seed на всі."""
    total = sum(counts)
    rng = np.random.default_rng(seed)
    if size >= total:
        return np.arange(total)
    return np.sort(rng.choice(total, size=size, replace=False))


def collect(class_name: str, root: Path | None = None) -> dict:
    """train усіх монет одним набором: події, час, ціна, монета."""
    module = CLASSES[class_name]
    x, t, po, pc, coin = [], [], [], [], []
    counts = []
    for index, pair in enumerate(PAIRS):
        dataset = module.load((root or DATASETS) / pair / class_name
                              / "train.npz")
        x.append(np.asarray(dataset.x, dtype=np.float64))
        t.append(dataset.t_start)
        po.append(dataset.price_open)
        pc.append(dataset.price_close)
        coin.append(np.full(len(dataset), index, dtype=np.int16))
        counts.append(len(dataset))
    return {"x": np.concatenate(x), "t": np.concatenate(t),
            "price_open": np.concatenate(po), "price_close": np.concatenate(pc),
            "coin": np.concatenate(coin), "counts": counts,
            "features": list(module.FEATURES)}


def flatten(x: np.ndarray) -> np.ndarray:
    """(N, B, F) -> (N, B * F). Порядок: фіча за фічею."""
    if x.ndim != 3:
        raise ValueError("очікується масив (N, B, F)")
    return x.transpose(0, 2, 1).reshape(len(x), -1)


def standardize(x: np.ndarray) -> np.ndarray:
    """z-score на цій же вибірці — без витоку з інших відрізків."""
    mean = x.mean(axis=0)
    std = x.std(axis=0)
    std[std == 0] = 1.0
    return (x - mean) / std


def run(class_name: str, metric: str, dims: int, out_dir: Path,
        root: Path | None = None, size: int = SAMPLE, seed: int = SEED,
        n_neighbors: int = N_NEIGHBORS, min_dist: float = MIN_DIST) -> dict:
    import umap  # важкий імпорт: тільки коли справді рахуємо

    groups = deciles()
    data = collect(class_name, root)
    picked = sample_index(data["counts"], size, seed)
    tag = f"{class_name} {metric} {dims}D"
    print(f"[1/4] {tag}: подій train {len(data['t'])}, вибірка {len(picked)}")

    flat = flatten(data["x"][picked])
    finite = np.isfinite(flat).all(axis=1)
    dropped = int((~finite).sum())
    index = picked[finite]
    flat = flat[finite]
    print(f"[2/4] {tag}: вектор події {flat.shape[1]} значень, "
          f"подій з NaN відкинуто {dropped}")

    started = time.time()
    reducer = umap.UMAP(n_components=dims, n_neighbors=n_neighbors,
                        min_dist=min_dist, metric=metric, random_state=seed,
                        verbose=False)
    coords = reducer.fit_transform(standardize(flat)).astype(np.float32)
    elapsed = time.time() - started
    print(f"[3/4] {tag}: готово {coords.shape} за {elapsed:.0f} с")

    price_open = data["price_open"][index]
    delta = (data["price_close"][index] - price_open) / price_open
    stamps = data["t"][index]
    coin = data["coin"][index]
    group = np.array([groups[PAIRS[c]].get(int(ts), 0)
                      for c, ts in zip(coin, stamps)], dtype=np.int16)

    out_dir.mkdir(parents=True, exist_ok=True)
    name = stem(metric, class_name, dims)
    meta = {
        "source": f"data/datasets/<PAIR>/{class_name}/train.npz",
        "class_name": class_name,
        "class_title": TITLES[class_name],
        "dims": dims,
        "pairs": list(PAIRS),
        "events": int(len(index)),
        "train_events": int(len(data["t"])),
        "sample": int(len(picked)),
        "dropped_nan": dropped,
        "vector_size": int(flat.shape[1]),
        "features": data["features"],
        "params": {"n_components": dims, "n_neighbors": n_neighbors,
                   "min_dist": min_dist, "metric": metric,
                   "random_state": seed, "sample": size},
        "seconds": round(elapsed, 1),
        "price_change": {"min": float(delta.min()), "max": float(delta.max()),
                         "mean": float(delta.mean()),
                         "std": float(delta.std())},
        "by_pair": {pair: int((coin == i).sum())
                    for i, pair in enumerate(PAIRS)},
        "by_group": {str(value): int((group == value).sum())
                     for value in range(0, 21)},
    }
    keys = ("x", "y", "z")
    payload = dict(meta)
    payload["points"] = [
        {**{keys[i]: round(float(value), 3) for i, value in enumerate(point)},
         "t": int(ts), "d": round(float(dd), 6), "g": int(gg), "c": int(cc)}
        for point, ts, dd, gg, cc in zip(coords, stamps, delta, group, coin)]
    (out_dir / f"{name}.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    (out_dir / f"{name}.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    np.savez_compressed(out_dir / f"{name}.npz", coords=coords,
                        timestamp=stamps, coin=coin, group=group,
                        price_change=delta.astype(np.float32))
    print(f"[4/4] {tag}: записано в {out_dir}")
    return meta


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--class", dest="class_name", default=None,
                        choices=sorted(CLASSES))
    parser.add_argument("--metric", default=None, choices=METRICS)
    parser.add_argument("--dims", type=int, default=None, choices=DIMS)
    parser.add_argument("--sample", type=int, default=SAMPLE)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    classes = [args.class_name] if args.class_name else list(CLASSES)
    metrics = [args.metric] if args.metric else list(METRICS)
    dims = [args.dims] if args.dims else list(DIMS)
    for class_name in classes:
        for metric in metrics:
            for size in dims:
                run(class_name, metric, size, args.out, args.data,
                    args.sample, args.seed)
    # Перелік збирається з `meta.json` усіх готових карт теки, а не з цього
    # прогону: прогін одного класу не стирає з переліку решту.
    maps = []
    for class_name in CLASSES:
        for metric in METRICS:
            for size in DIMS:
                meta = args.out / f"{stem(metric, class_name, size)}.meta.json"
                if meta.exists():
                    maps.append(json.loads(meta.read_text(encoding="utf-8")))
    (args.out / "umap_maps.json").write_text(
        json.dumps({"script": "research/21-class210x10x7dc/scripts/"
                              "run_umap7dc.py",
                    "command": "python3 research/21-class210x10x7dc/scripts/"
                               "run_umap7dc.py",
                    "maps": maps, "ready": True},
                   indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
