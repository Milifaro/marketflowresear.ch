"""Подія «розворот був»: датасет, порізаний на пачки, і вибір довжини пачки.

Дослідження: research/21-class210x10x7dc/
Правила: rules/01-data-and-db.md → клас210х10-1х7дц
         rules/02-markup.md → зігзаг
         rules/05-visualization.md → Кольори

Етап 8 показав, що фічі **реагують** на розворот: уся різниця сидить у
першій десятині ноги, тобто одразу після півота. Тут ця реакція стає
власною подією.

## Розмітка

Датасет ріжеться на **пачки, що не перекриваються**: усередині кожного
суцільного відрізка монети беруться `W` подій підряд, потім наступні `W`
і так далі. Неповний хвіст відрізка відкидається, через розрив даних
пачка не будується.

Кожна пачка дістає одну з трьох міток:

    нижній розворот   у межах пачки стоїть півот `low`   — зелена
    верхній розворот  у межах пачки стоїть півот `high`  — червона
    інша              півота в пачці немає

Кольори — за напрямком руху, який розворот відкриває
(`rules/05-visualization.md` → Кольори): нижній півот починає рух угору,
тому зелений; верхній починає рух униз, тому червоний.

Пачка, у якій опинилось кілька півотів (нога коротша за `W`), бере
**останній** — саме він лишається чинним на кінець пачки.

Півот усередині пачки стоїть **де завгодно**: у короткій пачці він
припадає на її кінець, у довгій — куди трапиться, і тоді половина пачки
описує ще попередню ногу. Через це в довжини пачки є максимум: коротка
пачка бачить мало реакції, довга розмиває її сусідніми подіями.

## Вибір довжини

    W = 1, 2, 3, 5, 10, 20, 40, 80        пачка = 3.5 хв … 4.7 год

На кожній довжині рахується `AUC` кожної колонки між пачками «розворот
був» і «інша» — **на кожній монеті окремо**, і по монетах береться
медіана. Так масштаб фічі й монета не змішуються в спільному ранзі
(різниця, яку показав етап 7 на `d_price_avg`).

Разом з нею рахуються ще три питання:

| Міра | Питання |
| ---- | ------- |
| `any` | чи був розворот узагалі |
| `low` | чи був **нижній** розворот (проти пачок без розвороту) |
| `high` | чи був **верхній** розворот (проти пачок без розвороту) |
| `low_high` | чи можна відрізнити нижній розворот від верхнього |

Оптимальна довжина береться за питанням `any`: це та, де **середнє
`|AUC − 0.5|` пʼяти найсильніших колонок** найбільше. Пʼять, а не одна —
щоб довжину не обирала одна колонка, яка випадково стрибнула.

Разом із силою рахується **частка живих пачок** — тих, у яких усі 56
згорток скінченні. Блок з нульовим обʼємом дає `NaN` у колонках стакана,
і що довша пачка, то більша ймовірність, що такий блок у ній трапиться:
на 720 блоках він майже неминучий. Пачка з `NaN` не потрапляє ні на карту
(rules/05: пропуски не проєктуються), ні в жоден замір, який вимагає
повного вектора.

Тому довжина обирається **серед тих, де живих пачок не менше `MIN_ALIVE`**:
інакше карта будується на зовсім іншому датасеті, ніж підбір.

Вхід : data/datasets/<PAIR>/class210x10m1x7dc/{train,val}.npz
       півоти — leg_deciles.py, згортки — pivot_compare.py
Вихід: results/reversal_pick.json      — таблиця вибору довжини
       results/reversal_<PAIR>.json    — ряд монети для графіка
       results/reversal_batches.npz    — пачки train для UMAP

Запуск:
    python3 research/21-class210x10x7dc/scripts/reversal_batches.py
    python3 research/21-class210x10x7dc/scripts/reversal_batches.py --pick 10
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402
from class210ema4 import ema  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

WINDOWS = (1, 2, 3, 5, 10, 20, 40, 80)
LABELS = ({"id": 0, "key": "none", "name": "інша пачка"},
          {"id": 1, "key": "low", "name": "нижній розворот"},
          {"id": 2, "key": "high", "name": "верхній розворот"})
CHART_POINTS = 4000
TOP_COLUMNS = 5        # скільки найсильніших колонок вирішують довжину
MIN_ALIVE = 0.70       # частка пачок з повним вектором, нижче якої не беремо


def tiles_of(t: np.ndarray, size: int,
             event_seconds: int = EVENT_LENGTH) -> np.ndarray:
    """Індекси кінців пачок, що не перекриваються: (M,).

    Пачка складається з `size` подій підряд усередині одного суцільного
    відрізка; неповний хвіст відрізка відкидається.
    """
    t = np.asarray(t, dtype=np.int64)
    if not len(t):
        return np.empty(0, dtype=np.int64)
    breaks = np.flatnonzero(np.diff(t) != event_seconds) + 1
    bounds = np.concatenate(([0], breaks, [len(t)]))
    ends = []
    for lo, hi in zip(bounds[:-1], bounds[1:]):
        ends.extend(range(lo + size - 1, hi, size))
    return np.asarray(ends, dtype=np.int64)


def label_of(ends: np.ndarray, pivots: list, size: int) -> np.ndarray:
    """Мітка кожної пачки: 0 інша, 1 нижній розворот, 2 верхній.

    Пачка з кількома півотами бере **останній** — саме він лишається
    чинним на її кінець.
    """
    label = np.zeros(len(ends), dtype=np.int8)
    if not len(ends):
        return label
    place = {int(p.index): (1 if p.kind == "low" else 2) for p in pivots}
    for row, end in enumerate(ends):
        for index in range(int(end), int(end) - size, -1):
            if index in place:
                label[row] = place[index]
                break
    return label


def auc_of(values: np.ndarray, left: np.ndarray,
           right: np.ndarray) -> float:
    """AUC однієї колонки між двома групами. NaN не рахується."""
    finite = np.isfinite(values)
    a, b = values[left & finite], values[right & finite]
    if not len(a) or not len(b):
        return float("nan")
    ranks = rankdata(np.concatenate([a, b]))
    return (float(ranks[:len(a)].sum()) - len(a) * (len(a) + 1) / 2) \
        / (len(a) * len(b))


def coin_batches(coin: dict, size: int) -> dict:
    """Пачки монети: колонки, мітка, час, вибірка."""
    ends = tiles_of(coin["t"], size)
    mask = np.zeros(len(coin["t"]), dtype=bool)
    mask[ends] = True
    cols = pivot.columns_of(coin["x"], mask, size)[ends]
    return {"ends": ends, "cols": cols,
            "label": label_of(ends, coin["pivots"], size),
            "t_start": coin["t"][ends - size + 1],
            "t_end": coin["t"][ends],
            "train": coin["t"][ends] < stamp(CUT)}


def measure(state: dict, windows, log=print) -> list:
    """AUC кожної колонки на кожній довжині пачки: медіана по монетах."""
    names = pivot.column_names(state["features"])
    rows = []
    keep_columns = [index for index, column in enumerate(names)
                    if column["kind"] == "agg"]
    for size in windows:
        parts = [coin_batches(coin, size) for coin in state["coins"]]
        counts = {"batches": 0, "low": 0, "high": 0, "alive": 0}
        per_coin = {key: [[] for _ in names]
                    for key in ("any", "low", "high", "low_high")}
        for part in parts:
            keep = part["train"]
            label = part["label"][keep]
            cols = part["cols"][keep]
            counts["batches"] += int(keep.sum())
            counts["low"] += int((label == 1).sum())
            counts["high"] += int((label == 2).sum())
            counts["alive"] += int(np.isfinite(cols[:, keep_columns])
                                   .all(axis=1).sum())
            groups = {"any": (label > 0, label == 0),
                      "low": (label == 1, label == 0),
                      "high": (label == 2, label == 0),
                      "low_high": (label == 1, label == 2)}
            for index in range(len(names)):
                column = cols[:, index]
                for key, (left, right) in groups.items():
                    per_coin[key][index].append(auc_of(column, left, right))
        for index, column in enumerate(names):
            if column["kind"] != "agg":
                continue
            row = {"batch": size, "agg": column["agg"],
                   "feature": column["feature"]}
            for key in ("any", "low", "high", "low_high"):
                values = np.asarray(per_coin[key][index], dtype=float)
                good = values[np.isfinite(values)]
                row[key] = (round(float(np.median(good)), 4) if len(good)
                            else None)
                row[f"{key}_coins"] = [None if not np.isfinite(one)
                                       else round(float(one), 4)
                                       for one in values]
            rows.append(row)
        best = max((row for row in rows if row["batch"] == size
                    and row["any"] is not None),
                   key=lambda row: abs(row["any"] - 0.5), default=None)
        counts["alive_share"] = round(counts["alive"] / counts["batches"], 4) \
            if counts["batches"] else 0.0
        log(f"      пачка {size}: {counts['batches']} пачок train, "
            f"живих {100 * counts['alive_share']:.0f}%, "
            f"нижніх {counts['low']}, верхніх {counts['high']}"
            + (f", найкраща колонка {best['agg']}·{best['feature']} "
               f"AUC {best['any']:.3f}" if best else ""))
        for row in rows:
            if row["batch"] == size:
                row["counts"] = dict(counts)
    return rows


def chart(coin: dict, part: dict, size: int,
          points: int = CHART_POINTS) -> dict:
    """Ряд монети для графіка: ема ціни, мітка пачки, півоти. Тільки train."""
    keep = part["train"]
    edge = stamp(CUT)
    inside = coin["t"] < edge
    place = np.full(len(coin["t"]), 0, dtype=np.int8)
    for end, mark in zip(part["ends"][keep], part["label"][keep]):
        place[end - size + 1:end + 1] = mark
    index = np.flatnonzero(inside)
    step = max(1, len(index) // points)
    # Проріджування не має зʼїдати кольорові пачки: краї кожної лишаються
    # завжди, інакше коротка пачка на графіку просто зникає.
    edges = [end - size + 1 for end, mark in
             zip(part["ends"][keep], part["label"][keep]) if mark]
    edges += [end for end, mark in
              zip(part["ends"][keep], part["label"][keep]) if mark]
    picked = np.union1d(index[::step], np.asarray(edges, dtype=np.int64))
    picked = picked[inside[picked]]
    return {
        "step": int(step), "batch": int(size),
        "points": [{"t": int(coin["t"][i]), "e": round(float(coin["ema"][i]), 6),
                    "g": int(place[i])} for i in picked],
        "pivots": [{"t": int(coin["t"][p.index]),
                    "e": round(float(coin["ema"][p.index]), 6), "k": p.kind}
                   for p in coin["pivots"] if coin["t"][p.index] < edge],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--window", type=int, action="append", default=None)
    parser.add_argument("--pick", type=int, default=None,
                        help="взяти цю довжину замість підібраної")
    parser.add_argument("--min-alive", type=float, default=MIN_ALIVE,
                        help="частка пачок з повним вектором")
    parser.add_argument("--period", type=int, default=leg_deciles.PERIOD)
    parser.add_argument("--threshold", type=float,
                        default=leg_deciles.THRESHOLD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    windows = tuple(args.window) if args.window else WINDOWS
    state = pivot.collect(args.data, args.period, args.threshold, (10,),
                          log=lambda *a: None)
    for coin, pair in zip(state["coins"], PAIRS):
        one = leg_deciles.build_pair(pair, args.data, args.period,
                                     args.threshold)
        coin["ema"] = one["ema"]
    rows = measure(state, windows)

    scored, strength, alive = {}, {}, {}
    for size in windows:
        found = sorted((row for row in rows if row["batch"] == size
                        and row["any"] is not None),
                       key=lambda row: -abs(row["any"] - 0.5))
        if not found:
            continue
        scored[size] = found[0]
        top = found[:TOP_COLUMNS]
        strength[size] = round(sum(abs(row["any"] - 0.5) for row in top)
                               / len(top), 4)
        alive[size] = found[0]["counts"]["alive_share"]
    usable = [size for size in strength if alive[size] >= args.min_alive]
    if not usable:
        usable = list(strength)
    picked = args.pick or max(usable, key=lambda size: strength[size])
    span = max(strength.values()) - min(strength.values())
    print(f"сила довжини (середнє |AUC−0.5| по {TOP_COLUMNS} колонках): "
          + ", ".join(f"{size}:{value:.3f}" for size, value in
                      sorted(strength.items())))
    print("живих пачок: "
          + ", ".join(f"{size}:{100 * alive[size]:.0f}%"
                      for size in sorted(alive)))
    print(f"придатні довжини (живих >= {100 * args.min_alive:.0f}%): "
          + ", ".join(str(size) for size in sorted(usable)))
    print(f"розкид по всій сітці {span:.3f} — "
          + ("довжина майже не впливає" if span < 0.05 else "довжина важлива"))
    print(f"обрана довжина пачки: {picked} "
          f"({picked * EVENT_LENGTH / 60:.0f} хв), найкраща колонка "
          f"{scored[picked]['agg']}·{scored[picked]['feature']} "
          f"AUC {scored[picked]['any']:.3f}")

    args.out.mkdir(parents=True, exist_ok=True)
    arrays, series = {}, {}
    for coin, pair in zip(state["coins"], PAIRS):
        part = coin_batches(coin, picked)
        keep = part["train"]
        arrays[f"{pair}_x"] = part["cols"][keep].astype(np.float32)
        arrays[f"{pair}_y"] = part["label"][keep]
        arrays[f"{pair}_t"] = part["t_start"][keep]
        (args.out / f"reversal_{pair}.json").write_text(
            json.dumps({"pair": pair, "threshold": args.threshold,
                        "period": args.period,
                        **chart(coin, part, picked)}, ensure_ascii=False),
            encoding="utf-8")
        series[pair] = {"batches": int(keep.sum()),
                        "low": int((part["label"][keep] == 1).sum()),
                        "high": int((part["label"][keep] == 2).sum())}
        print(f"  [{pair}] пачок train {series[pair]['batches']}, "
              f"нижніх {series[pair]['low']}, верхніх {series[pair]['high']}")
    np.savez_compressed(args.out / "reversal_batches.npz",
                        columns=np.array([json.dumps(one, ensure_ascii=False)
                                          for one in
                                          pivot.column_names(state["features"])]),
                        pairs=np.array(list(PAIRS)), batch=np.int64(picked),
                        **arrays)

    (args.out / "reversal_pick.json").write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/reversal_batches.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "reversal_batches.py",
        "class": pivot.CLASS, "class_title": "клас210х10-1х7дц",
        "threshold": args.threshold, "period": args.period,
        "cut_utc": f"{CUT} 00:00:00", "pairs": list(PAIRS),
        "features": state["features"], "aggregates": pivot.AGGREGATES,
        "families": pivot.FAMILIES, "labels": list(LABELS),
        "windows": list(windows), "picked": int(picked),
        "strength": {str(size): value for size, value in strength.items()},
        "alive": {str(size): alive[size] for size in alive},
        "usable": sorted(usable), "min_alive": args.min_alive,
        "top_columns": TOP_COLUMNS,
        "event_seconds": EVENT_LENGTH, "rows": rows, "by_pair": series,
        "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано в {args.out}")


if __name__ == "__main__":
    main()
