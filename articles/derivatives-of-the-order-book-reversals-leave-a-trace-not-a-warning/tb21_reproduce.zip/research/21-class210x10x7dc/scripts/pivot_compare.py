"""Події `клас210х10-1х7дц` біля півотів проти решти подій ніг.

Дослідження: research/21-class210x10x7dc/
Правила: rules/01-data-and-db.md → клас210х10-1х7дц
         rules/02-markup.md → зігзаг

Питання розділу: **чим події біля розвороту відрізняються від решти ноги** —
де фічі стоять, як вони коливаються всередині події й як співвідносяться
одна з одною.

## Дві когорти

Півоти — ті самі, що в розділі 2: зігзаг 2.3 % на `ема10` ціни події.

    біля півота  подія не далі за K подій від найближчого півота
    решта ноги   решта подій, що лежать усередині ніг

- Відстань міряється **номером події в ряду своєї монети**, як горизонти
  в дослідженнях 19 і 20, а не годинами: подія — 210 секунд, але пропуски
  часу роблять крок нерівним.
- Окіл симетричний і перетинає півот: він бере і кінець ноги, і початок
  наступної — розворот лежить між ними.
- Події **поза ногами** (до першого півота і після останнього) не беруть
  участі в жодній когорті.
- Вікна `K`: 5, 10, 20, 40, 80 подій. Вікно 10 ≈ 35 хвилин по обидва боки.

## Пачки подій

Подія коротка — 210 секунд, девʼять блоків по 21. Тому все міряється не
тільки на одній події, а й на **пачках із W подій підряд**:

    W = 1, 2, 3, 5, 10, 20        пачка = 3.5 хв … 70 хв

Пачка **закінчується** своєю подією і бере `W - 1` попередніх, тобто дивиться
тільки назад. Ряд блоків пачки — це `9 * W` значень підряд, зшитих через межі
подій. Пачка існує тільки якщо всі `W` подій ідуть **впритул** (крок 210
секунд); на початку ряду й після розриву даних пачки немає, і подія в замір
не входить.

Когорту («біля півота» чи «решта») задає **остання подія пачки** — та, на
якій пачка закінчується.

## Вісім згорток

На кожну фічу пачка дає ряд `v[1] … v[9W]`. Щоб фіча дала одне число, ряд
згортається вісьмома способами. Перші дві кажуть, **де фіча стоїть**,
решта — **як вона поводиться всередині пачки**:

    mean      mean(v)                        куди тягне, зі знаком
    abs       mean(|v|)                      наскільки взагалі рухалась

    range     max(v) − min(v)                розмах коливань
    std       σ(v)                           розкид
    step      mean(|v[j+1] − v[j]|)          середній крок між блоками
    straight  |v[кінець] − v[початок]|
              / Σ|v[j+1] − v[j]|             прямота ходу, [0, 1]
    acf1      corr(v[1…n−1], v[2…n])         звʼязність сусідніх блоків
    signs     скільки разів v міняє знак     0 … 9W−1

`range`, `std` і `step` відповідають на питання «чи більші коливання»;
`straight`, `acf1` і `signs` — на питання «чи плавніше». `straight` = 1 —
ряд ішов в один бік без відкатів, 0 — вернувся туди, звідки вийшов; це те
саме правило, що в ціновій фічі `клас210х14х4ц`. Високий `acf1` і мало змін
знаку — плавний ряд; відʼємний `acf1` — пила.

Ряд, що не рухався жодного разу, дає нульовий знаменник у `straight` і
`acf1` — там `NaN`, і подія в цій колонці не рахується.

## Як фічі співвідносяться між собою

Два різні питання, обидва в замірі:

**Усередині пачки.** На кожну пару фіч рахується кореляція Пірсона по
блоках цієї ж пачки — 21 пара, одне число на пару на подію. Далі когорти
порівнюються тим самим `AUC`: чи ходять фічі разом біля розвороту інакше,
ніж у решті ноги.

**Між подіями.** У кожній когорті окремо будується матриця кореляцій
Спірмена 7 × 7 між згортками фіч по всіх подіях когорти. Спірмен — бо
похідні мають важкі хвости. Різниця двох матриць показує, які пари фіч
міняють звʼязок біля розвороту.

## Чим міряється різниця

| Міра | Що каже |
| ---- | ------- |
| `AUC` | ймовірність, що випадкова подія біля півота має **більше** значення, ніж випадкова подія решти ноги. `0.5` — різниці немає, `1.0` — повний розділ |
| `d` Коена | різниця середніх у спільних сигмах |
| медіани й σ | самі числа обох когорт |

`AUC` рахується рангами (`scipy.stats.rankdata`), тому важкі хвости похідних
його не зсувають — на відміну від середніх. Вибірки тут у сотні тисяч подій,
тому будь-яка різниця «статистично значуща»: читається **величина** ефекту,
а не значущість.

## Два заміри: пулом і всередині ноги

Пулове порівняння має вбудований перекіс: **біля кожного півота стоїть рівно
`2K+1` подія**, скільки б не тривала нога. Тому когорта «біля півота» набирає
події з періодів, де розвороти часті, а «решта ноги» — переважно з довгих
спокійних ніг. Різниця між когортами може виявитись різницею **режимів**, а не
місця події в нозі.

Тому той самий замір робиться вдруге — **усередині кожної ноги окремо**:
`AUC` рахується тільки серед подій однієї ноги, і по всіх ногах беруться
медіана й квартилі. Так режим ноги скорочується: обидві когорти взяті з тієї
самої ноги, того самого відрізка часу й тієї самої монети.

- Нога бере участь, якщо в ній є хоча б `MIN_SIDE` подій у кожній когорті.
- Читається **медіана по ногах** і частка ніг, де `AUC > 0.5`: якщо ефект
  тримається в більшості ніг, він про місце в нозі, а не про режим.

Вхід : data/datasets/<PAIR>/class210x10m1x7dc/{train,val}.npz
       ноги й півоти — leg_deciles.py (перераховуються тут же)
Вихід: results/pivot_compare.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/pivot_compare.py
    python3 research/21-class210x10x7dc/scripts/pivot_compare.py --batch 1 --batch 10
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x10m1x7dc  # noqa: E402
import leg_deciles  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, PARTS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dc"

WINDOWS = (5, 10, 20, 40, 80)
DEFAULT_WINDOW = 10
BATCHES = (1, 2, 3, 5, 10, 20)
DEFAULT_BATCH = 1
CHUNK = 4096          # подій за раз при збиранні пачок
MIN_SIDE = 5          # подій у кожній когорті, щоб нога пішла в замір
BINS = 64
CLIP = 0.005

# Згортка ряду пачки в одне число на фічу. `family` групує кнопки на
# вкладці, `higher` каже, що означає більше значення, — щоб AUC читався
# без здогадок.
AGGREGATES = [
    {"id": "mean", "family": "місце", "name": "середнє по блоках",
     "formula": "mean(v)", "higher": "більше зі знаком"},
    {"id": "abs", "family": "місце", "name": "середній модуль блоків",
     "formula": "mean(|v|)", "higher": "сильніший рух"},
    {"id": "range", "family": "коливання", "name": "розмах",
     "formula": "max(v) − min(v)", "higher": "ширші коливання"},
    {"id": "std", "family": "коливання", "name": "розкид",
     "formula": "σ(v)", "higher": "ширші коливання"},
    {"id": "step", "family": "коливання", "name": "середній крок",
     "formula": "mean(|v[j+1] − v[j]|)", "higher": "різкіші переходи"},
    {"id": "straight", "family": "плавність", "name": "прямота ходу",
     "formula": "|v[кінець] − v[початок]| / Σ|v[j+1] − v[j]|",
     "higher": "рівніший хід в один бік"},
    {"id": "acf1", "family": "плавність", "name": "звʼязність сусідів",
     "formula": "corr(v[1…n−1], v[2…n])", "higher": "плавніший ряд"},
    {"id": "signs", "family": "плавність", "name": "зміни знаку",
     "formula": "скільки разів v міняє знак", "higher": "більше сіпань"},
]
FAMILIES = [{"id": "місце", "name": "де фіча стоїть"},
            {"id": "коливання", "name": "чи більші коливання"},
            {"id": "плавність", "name": "чи плавніше"}]
# Згортки, для яких має сенс AUC по кожному блоку події окремо: тільки ті,
# що читають сам блок, а не поведінку ряду. Рахуються при пачці 1.
BLOCK_AGGREGATES = ("mean", "abs")


def series(pair: str, root: Path | None = None, module=class210x10m1x7dc,
           folder_name: str = CLASS) -> dict:
    """Події класу одним рядом за часом: train і val разом.

    `module` і `folder_name` дають той самий замір іншому класу події —
    так розділ 8 бере `клас210х10-1х3+1дц`, нічого більше не міняючи.
    """
    folder = (root or DATASETS) / pair / folder_name
    x, t = [], []
    for part in PARTS:
        dataset = module.load(folder / f"{part}.npz")
        x.append(np.asarray(dataset.x, dtype=np.float32))
        t.append(dataset.t_start)
    x = np.concatenate(x)
    t = np.concatenate(t)
    order = np.argsort(t, kind="stable")
    return {"x": x[order], "t": t[order].astype(np.int64),
            "features": list(module.FEATURES)}


def near_pivot(count: int, pivots: list, window: int) -> np.ndarray:
    """(N,) bool: подія не далі за `window` подій від якогось півота."""
    mask = np.zeros(count, dtype=bool)
    for pivot in pivots:
        low = max(pivot.index - window, 0)
        high = min(pivot.index + window + 1, count)
        mask[low:high] = True
    return mask


def batch_ready(t: np.ndarray, size: int,
                event_seconds: int = EVENT_LENGTH) -> np.ndarray:
    """(N,) bool: у події є повна пачка з `size` подій підряд перед нею."""
    t = np.asarray(t, dtype=np.int64)
    linked = np.zeros(len(t), dtype=bool)
    if len(t) > 1:
        linked[1:] = np.diff(t) == event_seconds
    ready = np.zeros(len(t), dtype=bool)
    run = 0
    for index, step in enumerate(linked):
        run = run + 1 if step else 1
        ready[index] = run >= size
    return ready


def fold(v: np.ndarray, how: str) -> np.ndarray:
    """(N, B, F) ряд пачки -> (N, F) однією зі згорток AGGREGATES."""
    v = np.asarray(v, dtype=np.float64)
    if how == "mean":
        return v.mean(axis=1)
    if how == "abs":
        return np.abs(v).mean(axis=1)
    if how == "range":
        return v.max(axis=1) - v.min(axis=1)
    if how == "std":
        return v.std(axis=1)
    if how == "signs":
        return (np.diff(np.sign(v), axis=1) != 0).sum(axis=1).astype(float)
    if how == "acf1":
        left, right = v[:, :-1], v[:, 1:]
        a = left - left.mean(axis=1, keepdims=True)
        b = right - right.mean(axis=1, keepdims=True)
        top = (a * b).sum(axis=1)
        bottom = np.sqrt((a ** 2).sum(axis=1) * (b ** 2).sum(axis=1))
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(bottom > 0, top / bottom, np.nan)
    steps = np.abs(np.diff(v, axis=1))
    if how == "step":
        return steps.mean(axis=1)
    if how == "straight":
        walked = steps.sum(axis=1)
        moved = np.abs(v[:, -1] - v[:, 0])
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(walked > 0, moved / walked, np.nan)
    raise ValueError(f"невідома згортка: {how}")


def feature_pairs(width: int) -> list:
    """Усі пари фіч у сталому порядку."""
    return [(a, b) for a in range(width) for b in range(a + 1, width)]


def pair_correlation(v: np.ndarray) -> np.ndarray:
    """Кореляція Пірсона кожної пари фіч по блоках пачки: (N, пар).

    Фіча, що не рухалась у пачці жодного блоку, дає нульовий знаменник
    і `NaN`.
    """
    v = np.asarray(v, dtype=np.float64)
    centred = v - v.mean(axis=1, keepdims=True)
    norm = np.sqrt((centred ** 2).sum(axis=1))
    pairs = feature_pairs(v.shape[2])
    if not pairs:
        return np.empty((len(v), 0))
    values = []
    for a, b in pairs:
        bottom = norm[:, a] * norm[:, b]
        top = (centred[:, :, a] * centred[:, :, b]).sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            values.append(np.where(bottom > 0, top / bottom, np.nan))
    return np.stack(values, axis=1)


def columns_of(x: np.ndarray, ready: np.ndarray, size: int,
               chunk: int = CHUNK) -> np.ndarray:
    """Усі колонки заміру для пачок довжини `size`: (N, 8 * F + пар).

    Пачка закінчується своєю подією і бере `size - 1` попередніх. Подія
    без повної пачки дає рядок з `NaN`. Пачки збираються порціями, щоб
    не тримати `(N, 9 * size, F)` цілком у памʼяті.
    """
    count, blocks, width = x.shape
    total = len(AGGREGATES) * width + len(feature_pairs(width))
    out = np.full((count, total), np.nan, dtype=np.float64)
    positions = np.flatnonzero(ready)
    for start in range(0, len(positions), chunk):
        index = positions[start:start + chunk]
        window = np.empty((len(index), blocks * size, width), dtype=np.float32)
        for offset in range(size):
            piece = x[index - (size - 1 - offset)]
            window[:, offset * blocks:(offset + 1) * blocks] = piece
        parts = [fold(window, item["id"]) for item in AGGREGATES]
        parts.append(pair_correlation(window))
        out[index] = np.concatenate(parts, axis=1)
    return out


def column_names(features: list) -> list:
    """Підписи колонок у тому ж порядку, що їх кладе `columns_of`."""
    names = [{"kind": "agg", "agg": item["id"], "feature": name}
             for item in AGGREGATES for name in features]
    names += [{"kind": "pair", "a": features[a], "b": features[b]}
              for a, b in feature_pairs(len(features))]
    return names


def auc_columns(values: np.ndarray, near: np.ndarray) -> np.ndarray:
    """AUC на кожну колонку одразу: (n, C) і мітка (n,) -> (C,).

    `NaN` викидається по кожній колонці окремо, тому колонки з різною
    кількістю пропусків лишаються порівнюваними всередині себе.
    """
    finite = np.isfinite(values)
    ranks = rankdata(values, axis=0, nan_policy="omit")
    ranks = np.where(finite, ranks, 0.0)
    a = (finite & near[:, None]).sum(axis=0)
    b = (finite & ~near[:, None]).sum(axis=0)
    total = np.where(near[:, None], ranks, 0.0).sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        auc = (total - a * (a + 1) / 2) / (a * b)
    return np.where((a > 0) & (b > 0), auc, np.nan)


def auc_of(ranks: np.ndarray, near: np.ndarray) -> float:
    """AUC однієї колонки за готовими рангами."""
    a = int(near.sum())
    b = int(len(ranks) - a)
    if not a or not b:
        return float("nan")
    return (float(ranks[near].sum()) - a * (a + 1) / 2) / (a * b)


def cohen_d(near: np.ndarray, rest: np.ndarray) -> float:
    """Різниця середніх у спільних сигмах."""
    if len(near) < 2 or len(rest) < 2:
        return float("nan")
    var = ((len(near) - 1) * near.var(ddof=1)
           + (len(rest) - 1) * rest.var(ddof=1)) / (len(near) + len(rest) - 2)
    if var <= 0:
        return float("nan")
    return float((near.mean() - rest.mean()) / np.sqrt(var))


def summary(values: np.ndarray) -> dict:
    return {"n": int(len(values)),
            "mean": float(values.mean()) if len(values) else None,
            "median": float(np.median(values)) if len(values) else None,
            "std": float(values.std()) if len(values) else None}


def histogram(values: np.ndarray, low: float, high: float) -> list[int]:
    counts, _ = np.histogram(values, bins=BINS, range=(low, high))
    return [int(v) for v in counts]


def spearman_matrix(values: np.ndarray) -> list:
    """Матриця кореляцій Спірмена між колонками. Рядки з NaN відкидаються."""
    values = np.asarray(values, dtype=np.float64)
    width = values.shape[1]
    keep = np.isfinite(values).all(axis=1)
    clean = values[keep]
    if len(clean) < 3:
        return [[None] * width for _ in range(width)]
    ranks = rankdata(clean, axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        matrix = np.corrcoef(ranks, rowvar=False)
    return [[None if not np.isfinite(value) else round(float(value), 4)
             for value in row] for row in np.atleast_2d(matrix)]


def collect(root: Path | None, period: int, threshold: float,
            windows=WINDOWS, log=print, module=class210x10m1x7dc,
            folder_name: str = CLASS) -> dict:
    """Ряди всіх монет: значення класу, когорти й розбиття за датою."""
    edge, right = stamp(CUT), stamp(END)
    coins, features = [], None
    for pair in PAIRS:
        data = series(pair, root, module, folder_name)
        legs = leg_deciles.build_pair(pair, root, period, threshold)
        if len(legs["group"]) != len(data["t"]):
            raise SystemExit(f"{pair}: ряди класів різної довжини")
        features = data["features"]
        part = np.where(data["t"] < edge, "train",
                        np.where(data["t"] < right, "val", "поза"))
        coins.append({
            "pair": pair, "x": data["x"], "t": data["t"],
            "pivots": legs["pivots"], "in_leg": legs["group"] != 0,
            "part": part,
            "near": {size: near_pivot(len(data["t"]), legs["pivots"], size)
                     for size in windows}})
        log(f"[{pair}] подій {len(data['t'])}, "
            f"у ногах {int(coins[-1]['in_leg'].sum())}, "
            f"півотів {len(legs['pivots'])}")
    return {"coins": coins, "features": features}


def pooled(state: dict, batch: int, windows, log=print) -> dict:
    """Замір пулом на одній довжині пачки: рядки, монети, гістограми."""
    features = state["features"]
    names = column_names(features)
    coins = state["coins"]
    for coin in coins:
        ready = batch_ready(coin["t"], batch)
        coin["ready"] = ready
        coin["cols"] = columns_of(coin["x"], ready, batch)
    log(f"      пачка {batch}: колонки зібрані")

    rows, by_pair, hists, corr = [], [], [], []
    counts = {}
    for part in ("train", "val"):
        keep = [coin["in_leg"] & (coin["part"] == part) & coin["ready"]
                for coin in coins]
        values = np.concatenate([coin["cols"][one]
                                 for coin, one in zip(coins, keep)])
        counts[part] = {"in_legs": int(len(values)),
                        "near": {}}
        for size in windows:
            near = np.concatenate([coin["near"][size][one]
                                   for coin, one in zip(coins, keep)])
            counts[part]["near"][str(size)] = int(near.sum())
            auc = auc_columns(values, near)
            for index, column in enumerate(names):
                data = values[:, index]
                finite = np.isfinite(data)
                left, right_side = data[finite & near], data[finite & ~near]
                row = {"part": part, "batch": batch, "window": size,
                       "near": summary(left), "rest": summary(right_side),
                       "auc": float(auc[index]),
                       "cohen_d": cohen_d(left, right_side),
                       "nan": int((~finite).sum()), **column}
                rows.append(row)
            if part == "train":
                for item in AGGREGATES:
                    picked = [i for i, column in enumerate(names)
                              if column["kind"] == "agg"
                              and column["agg"] == item["id"]]
                    block = values[:, picked]
                    corr.append({"batch": batch, "window": size,
                                 "agg": item["id"], "cohort": "near",
                                 "matrix": spearman_matrix(block[near])})
                    corr.append({"batch": batch, "window": size,
                                 "agg": item["id"], "cohort": "rest",
                                 "matrix": spearman_matrix(block[~near])})
        log(f"      пачка {batch}: {part} готовий")

    # окремо кожна монета — чи це не артефакт однієї з них
    for coin in coins:
        keep = coin["in_leg"] & (coin["part"] == "train") & coin["ready"]
        values = coin["cols"][keep]
        for size in windows:
            auc = auc_columns(values, coin["near"][size][keep])
            for index, column in enumerate(names):
                if column["kind"] != "agg":
                    continue
                by_pair.append({"pair": coin["pair"], "batch": batch,
                                "window": size, "agg": column["agg"],
                                "feature": column["feature"],
                                "auc": float(auc[index])})

    # гістограми когорт на train: спільні біни, кожна нормується на вкладці
    keep = [coin["in_leg"] & (coin["part"] == "train") & coin["ready"]
            for coin in coins]
    values = np.concatenate([coin["cols"][one]
                             for coin, one in zip(coins, keep)])
    for size in windows:
        near = np.concatenate([coin["near"][size][one]
                               for coin, one in zip(coins, keep)])
        for index, column in enumerate(names):
            if column["kind"] != "agg":
                continue
            data = values[:, index]
            finite = np.isfinite(data)
            clean = data[finite]
            if not len(clean):
                continue
            low = float(np.quantile(clean, CLIP))
            high = float(np.quantile(clean, 1 - CLIP))
            if high <= low:
                high = low + 1e-12
            hists.append({"batch": batch, "window": size,
                          "agg": column["agg"], "feature": column["feature"],
                          "from": low, "to": high, "bins": BINS,
                          "near": histogram(clean[near[finite]], low, high),
                          "rest": histogram(clean[~near[finite]], low, high)})
    return {"rows": rows, "by_pair": by_pair, "hist": hists, "corr": corr,
            "counts": counts}


def within_legs(state: dict, batch: int, windows, min_side: int = MIN_SIDE,
                log=print) -> list:
    """AUC усередині кожної ноги: медіана й квартилі по ногах, train.

    Обидві когорти беруться з однієї ноги, тому режим ноги — той самий
    для обох, і різниця лишається різницею місця в нозі.
    """
    edge = stamp(CUT)
    names = column_names(state["features"])
    gathered = {size: [] for size in windows}
    for coin in state["coins"]:
        pivots = coin["pivots"]
        for previous, pivot in zip(pivots, pivots[1:]):
            first, last = previous.index + 1, pivot.index
            if last <= first or coin["t"][last] >= edge:
                continue
            events = np.arange(first, last + 1)
            events = events[coin["ready"][events]]
            if len(events) < 2 * min_side:
                continue
            values = coin["cols"][events]
            for size in windows:
                near = coin["near"][size][events]
                if int(near.sum()) < min_side or int((~near).sum()) < min_side:
                    continue
                gathered[size].append(auc_columns(values, near))
    rows = []
    for size in windows:
        if not gathered[size]:
            continue
        block = np.vstack(gathered[size])
        for index, column in enumerate(names):
            values = block[:, index]
            values = values[np.isfinite(values)]
            if not len(values):
                continue
            rows.append({"batch": batch, "window": size,
                         "legs": int(len(values)),
                         "median": float(np.median(values)),
                         "q25": float(np.quantile(values, 0.25)),
                         "q75": float(np.quantile(values, 0.75)),
                         "above_half": float((values > 0.5).mean()),
                         **column})
        log(f"      пачка {batch}: ноги, вікно {size} — "
            f"{len(gathered[size])} ніг")
    return rows


def block_grids(state: dict, windows, log=print) -> list:
    """AUC по кожному блоку події окремо — тільки для згорток блоку."""
    features = state["features"]
    grids = []
    for part in ("train", "val"):
        keep = [coin["in_leg"] & (coin["part"] == part)
                for coin in state["coins"]]
        raw = np.concatenate([coin["x"][one]
                              for coin, one in zip(state["coins"], keep)])
        near_all = {size: np.concatenate(
            [coin["near"][size][one]
             for coin, one in zip(state["coins"], keep)]) for size in windows}
        for item in BLOCK_AGGREGATES:
            values = np.abs(raw) if item == "abs" else raw
            for index, name in enumerate(features):
                grid = {"part": part, "agg": item, "feature": name,
                        "auc": {str(size): [] for size in windows}}
                for block in range(raw.shape[1]):
                    column = values[:, block, index].astype(np.float64)
                    finite = np.isfinite(column)
                    ranks = rankdata(column[finite])
                    for size in windows:
                        grid["auc"][str(size)].append(
                            auc_of(ranks, near_all[size][finite]))
                grids.append(grid)
        log(f"      блоки: {part} готовий")
    return grids


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--window", type=int, action="append", default=None)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--period", type=int, default=leg_deciles.PERIOD)
    parser.add_argument("--threshold", type=float,
                        default=leg_deciles.THRESHOLD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    windows = tuple(args.window) if args.window else WINDOWS
    batches = tuple(args.batch) if args.batch else BATCHES
    state = collect(args.data, args.period, args.threshold, windows)

    rows, by_leg, by_pair, hists, corr = [], [], [], [], []
    counts = {}
    for batch in batches:
        body = pooled(state, batch, windows)
        rows += body["rows"]
        by_pair += body["by_pair"]
        hists += body["hist"]
        corr += body["corr"]
        counts[str(batch)] = body["counts"]
        by_leg += within_legs(state, batch, windows)
    grids = block_grids(state, windows)

    payload = {
        "script": "research/21-class210x10x7dc/scripts/pivot_compare.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "pivot_compare.py",
        "class": CLASS, "class_title": "клас210х10-1х7дц",
        "threshold": args.threshold, "period": args.period,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "features": state["features"],
        "windows": list(windows), "default_window": DEFAULT_WINDOW,
        "batches": list(batches), "default_batch": DEFAULT_BATCH,
        "event_seconds": EVENT_LENGTH,
        "blocks": int(state["coins"][0]["x"].shape[1]),
        "aggregates": AGGREGATES, "families": FAMILIES,
        "block_aggregates": list(BLOCK_AGGREGATES),
        "feature_pairs": [{"a": state["features"][a], "b": state["features"][b]}
                          for a, b in feature_pairs(len(state["features"]))],
        "counts": counts, "rows": rows, "by_leg": by_leg, "by_pair": by_pair,
        "hist": hists, "corr": corr, "grids": grids, "ready": True}
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "pivot_compare.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    window = DEFAULT_WINDOW if DEFAULT_WINDOW in windows else windows[0]
    for batch in batches:
        one = counts[str(batch)]["train"]
        print(f"пачка {batch}: подій {one['in_legs']}, "
              f"біля півота {one['near'][str(window)]}")
    inside = {(row["batch"], row.get("agg"), row.get("feature")): row
              for row in by_leg if row["window"] == window
              and row["kind"] == "agg"}
    top = sorted((row for row in rows
                  if row["part"] == "train" and row["window"] == window
                  and row["batch"] == DEFAULT_BATCH and row["kind"] == "agg"),
                 key=lambda row: -abs(row["auc"] - 0.5))
    print(f"найсильніші колонки при пачці {DEFAULT_BATCH}, вікні ±{window}:")
    for row in top[:8]:
        one = inside.get((row["batch"], row["agg"], row["feature"]))
        print(f"  {row['agg']:9s} {row['feature']:14s} пулом {row['auc']:.4f}"
              + (f"  у нозі {one['median']:.4f} "
                 f"({one['above_half'] * 100:.0f}% ніг)" if one else ""))
    print(f"записано в {args.out}/pivot_compare.json")


if __name__ == "__main__":
    main()
