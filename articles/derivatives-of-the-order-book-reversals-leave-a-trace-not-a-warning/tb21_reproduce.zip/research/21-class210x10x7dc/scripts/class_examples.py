"""Справжні приклади класів вкладки — одна подія з датасету наскрізь.

Дослідження: research/21-class210x10x7dc/

Береться одна подія `BTC_USDT` і показується так, як вона проходить
пайплайн: `клас210х10х9` -> `клас210х10х7` -> `клас210х10х7дц` ->
`клас210х10-1х7дц`. Разом з нею йде остання плашка **попередньої**
події — та, з якої рахується перша похідна.

Другий приклад — подія на **розриві** (`seam`): попередньої події немає,
тому перша похідна дорівнює середньому трьох наступних.

Числа беруться з готових датасетів, нічого не перераховується.

Вхід : data/datasets/BTC_USDT/{class210x10x9,class210x10x7,
       class210x10x7dc,class210x10m1x7dc}/train.npz
Вихід: results/examples.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/class_examples.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x10m1x7dc  # noqa: E402
import class210x10x7  # noqa: E402
import class210x10x7dc  # noqa: E402
import class210x10x9  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
DIGITS = 6

ORDER = [("class210x10x9", "клас210х10х9", class210x10x9),
         ("class210x10x7", "клас210х10х7", class210x10x7),
         ("class210x10x7dc", "клас210х10х7дц", class210x10x7dc),
         ("class210x10m1x7dc", "клас210х10-1х7дц", class210x10m1x7dc)]


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def cell(value: float) -> float | None:
    """Число для JSON: NaN не серіалізується, тому йде як null."""
    value = float(value)
    return None if not np.isfinite(value) else round(value, DIGITS)


def table(x: np.ndarray, features: list[str], first_block: int = 1) -> dict:
    return {"features": list(features),
            "blocks": [{"block": first_block + i,
                        "values": [cell(v) for v in row]}
                       for i, row in enumerate(x)]}


def load_all(pair: str, root: Path | None = None) -> dict:
    return {name: module.load((root or DATASETS) / pair / name / "train.npz")
            for name, _, module in ORDER}


def one(sets: dict, index: int, pair: str) -> dict:
    """Подія наскрізь по всіх чотирьох класах."""
    nine = sets["class210x10x9"]
    derived = sets["class210x10x7dc"]
    seam = bool(derived.seam[index])
    seven = sets["class210x10x7"]
    body = {
        "pair": pair,
        "index": int(index),
        "t_start": int(nine.t_start[index]),
        "t_end": int(nine.t_end[index]),
        "from_utc": utc(nine.t_start[index]),
        "to_utc": utc(nine.t_end[index]),
        "price_open": cell(nine.price_open[index]),
        "price_close": cell(nine.price_close[index]),
        "seam": seam,
        "tables": {name: table(sets[name].x[index], sets[name].features,
                               2 if name == "class210x10m1x7dc" else 1)
                   for name, _, _ in ORDER},
    }
    if not seam and index > 0:
        body["previous"] = {
            "t_start": int(nine.t_start[index - 1]),
            "from_utc": utc(nine.t_start[index - 1]),
            "last_block": [cell(v) for v in seven.x[index - 1, -1]],
            "features": list(seven.features),
        }
    return body


def pick(sets: dict) -> tuple[int, int]:
    """Індекси прикладів: звичайна подія і подія на розриві.

    Звичайна — перша подія без `NaN`, у якої попередня теж без `NaN`.
    На розриві — перша подія з прапорцем `seam` і без `NaN`, що стоїть
    не на самому початку ряду: розрив у даних показовіший за перший
    рядок, хоч правило для них одне.
    """
    derived = sets["class210x10x7dc"]
    clean = np.isfinite(derived.x.reshape(len(derived.x), -1)).all(axis=1)
    normal = np.flatnonzero(clean & ~derived.seam)
    normal = normal[normal > 0]
    normal = normal[clean[normal - 1]]
    seam = np.flatnonzero(clean & derived.seam)
    seam = seam[seam > 0] if (seam > 0).any() else seam
    if not len(normal) or not len(seam):
        raise SystemExit("не знайшлось прикладів без NaN")
    return int(normal[0]), int(seam[0])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sets = load_all(args.pair, args.data)
    normal, seam = pick(sets)
    payload = {
        "script": "research/21-class210x10x7dc/scripts/class_examples.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "class_examples.py",
        "pair": args.pair,
        "classes": [{"id": name, "name": title} for name, title, _ in ORDER],
        "normal": one(sets, normal, args.pair),
        "seam": one(sets, seam, args.pair),
        "ready": True,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "examples.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"приклади: подія {normal}, розрив {seam} -> {args.out}/examples.json")


if __name__ == "__main__":
    main()
