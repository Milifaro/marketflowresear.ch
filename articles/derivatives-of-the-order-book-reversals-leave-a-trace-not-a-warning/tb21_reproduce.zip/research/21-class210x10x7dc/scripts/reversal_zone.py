"""Розворот у нозі: перші 5 % і останні 10 % проти решти ноги.

Дослідження: research/21-class210x10x7dc/
Правила: rules/02-markup.md → зігзаг
         rules/05-visualization.md → Кольори

Етап 14 вів ногу по сітці й дивився на середній ранг клітинки. Тут з
ноги вирізається **зона розвороту** — початок і кінець руху, — і питання
ставиться прямо: чи можна відрізнити подію цієї зони від решти подій
**тієї самої ноги**.

## Зона

    місце події = (номер у нозі) / (довжина ноги)      0 … 1
    розворот    = місце < 0.05  або  місце >= 0.90

Перші 5 % — хвіст щойно відбутого розвороту, останні 10 % — підхід до
наступного. Разом це ≈ 15 % подій ноги. Місце міряється **по подіях**,
як усюди в цьому дослідженні, а не по пройденій ціні.

Нога бере участь, тільки якщо в ній щонайменше `MIN_EVENTS` придатних
подій: інакше в 5 % не влучає жодна. Придатна подія — та, у якої є повна
пачка з `W` подій підряд.

## Міри

| Міра | Що каже |
| ---- | ------- |
| **AUC усередині ноги** | зона проти решти **тієї самої** ноги; медіана по ногах монети, потім по монетах |
| **початок / кінець** | те саме, але зона розрізана навпіл: перші 5 % окремо, останні 10 % окремо |
| **модель** | логістична регресія на всіх колонках: навчена на ногах train, заміряна на ногах val |

Усе рангове: клас — відношення двох похідних, у нього важкі хвости.
Колонки для моделі беруться рангом усередині своєї ноги, тому монета,
режим і масштаб фічі скорочуються так само, як у мірі AUC.

## Класи

Замір іде на кожному класі з `CLASS_IDS` і в кожного свої колонки:
`клас210х10-1х2д` дає 2 фічі × 8 згорток = 16, `клас210х10-1х7д/д` —
7 × 8 = 56. Класи лежать в одному файлі й перемикаються на вкладці.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/reversal_zone.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/reversal_zone.py
    python3 research/21-class210x10x7dc/scripts/reversal_zone.py --batch 5
    python3 research/21-class210x10x7dc/scripts/reversal_zone.py --class x7dd
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import umap_subsets  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS_IDS = ("x2d", "x7dd")   # класи заміру, у порядку показу
BATCHES = (1, 5, 20)
LEAD = 0.05                # перші 5 % ноги
TAIL = 0.10                # останні 10 % ноги
MIN_EVENTS = 20            # інакше в 5 % не влучає жодна подія
SEED = 0
ZONES = ({"id": "all", "name": "зона розвороту"},
         {"id": "start", "name": "перші 5 %"},
         {"id": "end", "name": "останні 10 %"})


def cell(value: float):
    value = float(value)
    return None if not np.isfinite(value) else round(value, 4)


def zone_of(place: np.ndarray, lead: float = LEAD,
            tail: float = TAIL) -> dict:
    """Місце в нозі -> три маски: початок, кінець, решта."""
    start = place < lead
    end = place >= 1.0 - tail
    return {"start": start, "end": end, "rest": ~(start | end)}


def legs_of(coin: dict, batch: int, lead: float, tail: float,
            least: int) -> list:
    """Ноги монети: події, маски зони й частина датасету."""
    edge, right = stamp(CUT), stamp(END)
    out = []
    for previous, point in zip(coin["pivots"], coin["pivots"][1:]):
        first, last = previous.index + 1, point.index
        if last <= first:
            continue
        events = np.arange(first, last + 1)
        events = events[coin["ready"][events]]
        if len(events) < least:
            continue
        if coin["t"][last] < edge:
            part = "train"
        elif coin["t"][first] >= edge and coin["t"][last] < right:
            part = "val"
        else:
            continue
        place = (events - first) / (last - first + 1)
        masks = zone_of(place, lead, tail)
        if not masks["start"].any() or not masks["end"].any():
            continue
        out.append({"events": events, "part": part, "masks": masks,
                    "kind": "up" if point.kind == "high" else "down"})
    return out


def leg_auc(values: np.ndarray, masks: dict) -> dict:
    """AUC усередині однієї ноги на три постановки зони."""
    both = masks["start"] | masks["end"]
    out = {}
    for name, near in (("all", both), ("start", masks["start"]),
                       ("end", masks["end"])):
        keep = near | masks["rest"]
        out[name] = pivot.auc_columns(values[keep], near[keep])
    return out


def leg_ranks(values: np.ndarray) -> np.ndarray:
    """Ранг кожної колонки всередині ноги, приведений до [0, 1]."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        ranks = rankdata(values, axis=0, nan_policy="omit")
    ranks = np.where(np.isfinite(values), ranks, np.nan)
    middle = (len(values) + 1) / 2
    ranks = np.where(np.isnan(ranks), middle, ranks)
    return (ranks - 0.5) / len(values)


def model_auc(train: tuple, val: tuple, seed: int = SEED) -> dict:
    """Логістична регресія на рангах колонок: train -> val."""
    from sklearn.linear_model import LogisticRegression

    x_train, y_train = train
    x_val, y_val = val
    if not len(x_train) or not len(x_val) or len(set(y_val)) < 2:
        return {}
    model = LogisticRegression(max_iter=2000, random_state=seed)
    model.fit(x_train, y_train)
    score = {}
    for name, (x, y) in (("train", train), ("val", val)):
        if len(set(y)) < 2:
            continue
        ranks = rankdata(model.decision_function(x))
        score[name] = cell(pivot.auc_of(ranks, y.astype(bool)))
    return {"auc": score,
            "weights": [round(float(one), 3) for one in model.coef_[0]]}


def one_batch(state: dict, batch: int, lead: float, tail: float, least: int,
              log=print) -> dict:
    """Одна довжина пачки: AUC усередині ніг, по монетах і модель."""
    names = pivot.column_names(state["features"])
    keep = [index for index, column in enumerate(names)
            if column["kind"] == "agg"]
    columns = [{"key": f'{names[index]["agg"]}|{names[index]["feature"]}',
                "agg": names[index]["agg"],
                "feature": names[index]["feature"]} for index in keep]

    by_coin, counts = {}, {"legs": {"train": 0, "val": 0}, "events": 0,
                           "start": 0, "end": 0, "rest": 0}
    sets = {"train": {"x": [], "y": []}, "val": {"x": [], "y": []}}
    for coin in state["coins"]:
        coin["ready"] = pivot.batch_ready(coin["t"], batch)
        coin["cols"] = pivot.columns_of(coin["x"], coin["ready"],
                                        batch)[:, keep]
        gathered = {one["id"]: [] for one in ZONES}
        for leg in legs_of(coin, batch, lead, tail, least):
            values = coin["cols"][leg["events"]]
            counts["legs"][leg["part"]] += 1
            if leg["part"] == "train":
                counts["events"] += len(leg["events"])
                for name in ("start", "end", "rest"):
                    counts[name] += int(leg["masks"][name].sum())
                for name, auc in leg_auc(values, leg["masks"]).items():
                    gathered[name].append(auc)
            near = leg["masks"]["start"] | leg["masks"]["end"]
            sets[leg["part"]]["x"].append(leg_ranks(values))
            sets[leg["part"]]["y"].append(near)
        by_coin[coin["pair"]] = {
            name: [cell(value) for value in
                   np.nanmedian(np.vstack(rows), axis=0)]
            for name, rows in gathered.items() if rows}
        log(f"      {coin['pair']}: ніг train "
            f"{len(gathered['all'])}, колонок {len(columns)}")

    within = {}
    for one in ZONES:
        block = np.array([by_coin[pair][one["id"]] for pair in by_coin
                          if one["id"] in by_coin[pair]], dtype=float)
        within[one["id"]] = [cell(value) for value in
                             np.nanmedian(block, axis=0)]

    parts = {name: (np.vstack(body["x"]), np.concatenate(body["y"]))
             for name, body in sets.items() if body["x"]}
    model = model_auc(parts["train"], parts["val"]) if len(parts) == 2 else {}
    if model:
        best = max(range(len(columns)),
                   key=lambda index: abs((within["all"][index] or 0.5) - 0.5))
        ranks = rankdata(parts["val"][0][:, best])
        model["best_column"] = {
            "key": columns[best]["key"],
            "val_auc": cell(pivot.auc_of(ranks, parts["val"][1].astype(bool))),
            "within_auc": within["all"][best]}
        model["events"] = {name: int(len(body[1])) for name, body in
                           parts.items()}
    return {"batch": batch, "columns": columns, "counts": counts,
            "within": within, "by_coin": by_coin, "model": model}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--class", dest="class_id", action="append",
                        default=None, choices=sorted(umap_subsets.CLASSES))
    parser.add_argument("--lead", type=float, default=LEAD)
    parser.add_argument("--tail", type=float, default=TAIL)
    parser.add_argument("--least", type=int, default=MIN_EVENTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    ids = args.class_id or list(CLASS_IDS)
    sizes = tuple(args.batch) if args.batch else BATCHES
    cards, classes = [], []
    for class_id in ids:
        kind = umap_subsets.CLASSES[class_id]
        state = pivot.collect(args.data, leg_deciles.PERIOD,
                              leg_deciles.THRESHOLD, (10,),
                              log=lambda *a: None, module=kind["module"],
                              folder_name=kind["folder"])
        classes.append({"id": class_id, "title": kind["title"],
                        "folder": kind["folder"],
                        "features": state["features"]})
        for size in sizes:
            print(f"[{kind['title']} · пачка {size}]")
            card = one_batch(state, size, args.lead, args.tail, args.least)
            cards.append(dict(card, class_id=class_id,
                              class_title=kind["title"]))

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "reversal_zone.json").write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/reversal_zone.py",
        "command": "research/21-class210x10x7dc/scripts/reversal_zone.py",
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "aggregates": pivot.AGGREGATES,
        "families": pivot.FAMILIES, "zones": list(ZONES),
        "classes": classes, "default_class": ids[0],
        "lead": args.lead, "tail": args.tail, "min_events": args.least,
        "batches": list(sizes), "default_batch": sizes[min(1, len(sizes) - 1)],
        "event_seconds": EVENT_LENGTH, "seed": SEED,
        "cards": cards, "ready": True}, ensure_ascii=False), encoding="utf-8")

    for card in cards:
        best = max(range(len(card["columns"])),
                   key=lambda index: abs((card["within"]["all"][index] or 0.5)
                                         - 0.5))
        model = card["model"].get("auc", {})
        print(f"{card['class_title']:20s} W={card['batch']:<3d} ніг train "
              f"{card['counts']['legs']['train']}"
              f", val {card['counts']['legs']['val']} · найсильніша колонка "
              f"{card['columns'][best]['key']} "
              f"{card['within']['all'][best]:.3f} · модель train "
              f"{model.get('train')} val {model.get('val')}")
    print(f"записано {args.out}/reversal_zone.json")


if __name__ == "__main__":
    main()
