"""Ряд монети для графіка: ціна із зігзагом і кожна фіча класу під ним.

Дослідження: research/21-class210x10x7dc/
Правила: rules/05-visualization.md → Обовʼязкова компоновка

Верхнє полотно — `ема10` ціни події із зігзагом 2.3 % поверх; під ним,
на **спільній осі X**, іде обрана фіча `клас210х10-1х7дц`. Подія — це
девʼять блоків на фічу, тому в ряд вона зводиться згорткою: тими самими
вісьмома, що в етапах 7–9 (`pivot_compare.AGGREGATES`).

## Проріджування

Ряд монети — близько 70 тисяч подій, і повністю в браузер він не їде.
Береться кожна `step`-та подія так, щоб лишилось не більше `POINTS`
точок. Проріджування **рівномірне**: воно може пропустити одиничний
сплеск, тому короткі викиди на графіку читати не можна — для них є
заміри етапів 7–9.

**Події півотів лишаються завжди**: вони додаються до проріджених, щоб
зігзаг на графіку стояв рівно там, де його порахували на повному ряду,
а не на найближчій уцілілій події.

Вихід — **по файлу на монету й згортку**: разом усі вісім згорток дають
вісім мегабайт на монету, і вкладка тягла б їх усі заради однієї.

Вхід : data/datasets/<PAIR>/class210x10m1x7dc/{train,val}.npz
       ема й півоти — leg_deciles.py, згортки — pivot_compare.py
Вихід: results/chart_<PAIR>.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/feature_chart.py
    python3 research/21-class210x10x7dc/scripts/feature_chart.py --points 8000
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
POINTS = 12000         # скільки точок лишається на монету
DIGITS = 6


def cell(value: float):
    """Число для JSON: NaN не серіалізується, тому йде як null."""
    value = float(value)
    if not np.isfinite(value):
        return None
    return round(value, DIGITS) if abs(value) < 1e6 else round(value, 1)


def build_pair(coin: dict, names: list, points: int = POINTS) -> dict:
    """Ряд однієї монети: час, ема, півоти й усі згортки всіх фіч."""
    count = len(coin["t"])
    step = max(1, count // points)
    pivots = np.array([one.index for one in coin["pivots"]], dtype=np.int64)
    pivots = pivots[(pivots >= 0) & (pivots < count)]
    keep = np.union1d(np.arange(0, count, step), pivots)
    place = {int(one): index for index, one in enumerate(coin["t"][keep])}
    edge = stamp(CUT)
    shared = {
        "pair": coin["pair"], "events": int(len(keep)), "step": int(step),
        "full_events": int(count),
        "t": [int(one) for one in coin["t"][keep]],
        "price": [cell(one) for one in coin["ema"][keep]],
        "cut": int(edge),
        "pivots": [{"t": int(coin["t"][one.index]),
                    "ema": cell(coin["ema"][one.index]), "kind": one.kind}
                   for one in coin["pivots"]
                   if int(coin["t"][one.index]) in place],
        "pivots_total": len(coin["pivots"]),
    }
    by_agg = {}
    for index, column in enumerate(names):
        if column["kind"] != "agg":
            continue
        by_agg.setdefault(column["agg"], {})[column["feature"]] = [
            cell(value) for value in coin["cols"][keep, index]]
    return shared, by_agg


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--points", type=int, default=POINTS)
    parser.add_argument("--batch", type=int, default=1,
                        help="довжина пачки для згорток; 1 — одна подія")
    parser.add_argument("--period", type=int, default=leg_deciles.PERIOD)
    parser.add_argument("--threshold", type=float,
                        default=leg_deciles.THRESHOLD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    pairs = args.pair or list(PAIRS)
    state = pivot.collect(args.data, args.period, args.threshold, (10,),
                          log=lambda *a: None)
    names = pivot.column_names(state["features"])
    args.out.mkdir(parents=True, exist_ok=True)
    made = []
    for coin, pair in zip(state["coins"], PAIRS):
        if pair not in pairs:
            continue
        coin["pair"] = pair
        coin["ema"] = leg_deciles.build_pair(pair, args.data, args.period,
                                             args.threshold)["ema"]
        coin["ready"] = pivot.batch_ready(coin["t"], args.batch)
        coin["cols"] = pivot.columns_of(coin["x"], coin["ready"], args.batch)
        shared, by_agg = build_pair(coin, names, args.points)
        shared.update({"threshold": args.threshold, "period": args.period,
                       "batch": args.batch, "event_seconds": EVENT_LENGTH,
                       "features": state["features"],
                       "script": "research/21-class210x10x7dc/scripts/"
                                 "feature_chart.py"})
        size = 0
        for agg, columns in by_agg.items():
            path = args.out / f"chart_{pair}_{agg}.json"
            path.write_text(json.dumps({**shared, "agg": agg,
                                        "cols": columns}, ensure_ascii=False),
                            encoding="utf-8")
            size += path.stat().st_size
        made.append(pair)
        print(f"[{pair}] {shared['full_events']} подій -> {shared['events']} "
              f"точок (крок {shared['step']}), півотів "
              f"{shared['pivots_total']}, {len(by_agg)} файлів по "
              f"{size / len(by_agg) / 1e6:.1f} МБ")
    (args.out / "charts.json").write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/feature_chart.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "feature_chart.py",
        "class": pivot.CLASS, "class_title": "клас210х10-1х7дц",
        "threshold": args.threshold, "period": args.period,
        "points": args.points, "batch": args.batch,
        "features": state["features"], "aggregates": pivot.AGGREGATES,
        "families": pivot.FAMILIES, "pairs": made,
        "event_seconds": EVENT_LENGTH, "ready": True},
        indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
