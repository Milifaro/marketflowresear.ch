"""Хід фіч від півота до півота: два класи × дві довжини пачки.

Дослідження: research/21-class210x10x7dc/
Правила: rules/02-markup.md → зігзаг
         rules/05-visualization.md → Обовʼязкова компоновка

Етап 8 ділив ногу на десять частин і брав початок кожної. Тут нога
проходиться **цілком**: від півота, яким вона почалась, до півота, яким
скінчилась, і дивиться, як фіча міняється по дорозі. Ноги росту й ноги
падіння рахуються **нарізно** — і потім порівнюються між собою.

## Сітка ноги

Ноги різної довжини, тому кожна розтягується на спільну сітку з `BINS`
клітинок:

    місце події = (номер у нозі) / (довжина ноги)      0 … 1
    клітинка    = floor(місце × BINS)                  0 … BINS-1

Значення клітинки — середнє згортки по подіях, що в неї потрапили. Нога
бере участь, тільки якщо **жодна клітинка не порожня**: інакше її хід не
порівнюється з іншими. При `BINS = 20` це означає ногу щонайменше в 20
придатних подій.

Придатна подія — та, у якої є повна пачка з `W` подій підряд, як в
етапах 7–9. Довжини дві: `W = 5` і `W = 20`.

## Що міряється

Усе рахується **всередині ноги**: у ноги `BINS` своїх чисел на кожну
колонку, і між собою порівнюються тільки вони. Це прибирає монету, режим
і масштаб фічі — лишається чистий хід.

| Міра | Що каже |
| ---- | ------- |
| **середній ранг** | клітинка ранжується серед `BINS` своїх, ранг усереднюється по ногах. Немає ходу — усі клітинки біля `(BINS+1)/2` |
| **вгору проти вниз** | `AUC` рангів клітинки між ногами росту й ногами падіння. `0.5` — хід однаковий |

Ранг уже нормований усередині своєї ноги, тому ноги різних напрямків
порівнюються напряму.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_track.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/leg_track.py
    python3 research/21-class210x10x7dc/scripts/leg_track.py --bins 10
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import leg_profile  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import umap_subsets  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
BATCHES = umap_subsets.BATCHES         # 5, 20
BINS = 20                              # клітинок на ногу, по 5 % кожна
DIRECTIONS = leg_profile.DIRECTIONS     # усі / вгору / вниз


def cell(value: float):
    value = float(value)
    return None if not np.isfinite(value) else round(value, 4)


def leg_track(coin: dict, bins: int) -> tuple[np.ndarray, list]:
    """Хід кожної ноги на спільній сітці: (L, bins, C) і напрямки.

    Нога, у якої хоч одна клітинка порожня, відкидається цілком.
    """
    edge = stamp(CUT)
    ready = coin["ready"]
    rows, kinds = [], []
    for previous, pivot_point in zip(coin["pivots"], coin["pivots"][1:]):
        first, last = previous.index + 1, pivot_point.index
        if last <= first or coin["t"][last] >= edge:
            continue
        events = np.arange(first, last + 1)
        events = events[ready[events]]
        if len(events) < bins:
            continue
        place = (events - first) / (last - first + 1)
        slot = np.minimum((place * bins).astype(int), bins - 1)
        block = np.empty((bins, coin["cols"].shape[1]))
        whole = True
        for index in range(bins):
            picked = events[slot == index]
            if not len(picked):
                whole = False
                break
            with np.errstate(invalid="ignore"), warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                block[index] = np.nanmean(coin["cols"][picked], axis=0)
        if whole:
            rows.append(block)
            kinds.append("up" if pivot_point.kind == "high" else "down")
    if not rows:
        return np.empty((0, bins, coin["cols"].shape[1])), kinds
    return np.stack(rows), kinds


def one_class(kind: dict, size: int, bins: int, root: Path | None,
              log=print) -> dict:
    """Одна комбінація «клас × довжина пачки»: хід по всіх монетах."""
    state = pivot.collect(root, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None,
                          module=kind["module"], folder_name=kind["folder"])
    features = state["features"]
    names = pivot.column_names(features)
    keep = [index for index, column in enumerate(names)
            if column["kind"] == "agg"]
    columns = [names[index] for index in keep]

    blocks, kinds = [], []
    for coin in state["coins"]:
        coin["ready"] = pivot.batch_ready(coin["t"], size)
        coin["cols"] = pivot.columns_of(coin["x"], coin["ready"], size)[:, keep]
        block, way = leg_track(coin, bins)
        if len(block):
            blocks.append(block)
            kinds += way
    values = np.concatenate(blocks) if blocks else np.empty((0, bins,
                                                             len(columns)))
    kinds = np.array(kinds)
    log(f"      {kind['folder']} W={size}: ніг {len(values)} "
        f"({int((kinds == 'up').sum())} вгору, "
        f"{int((kinds == 'down').sum())} вниз)")

    ranks, track, legs = {}, {}, {}
    for way in DIRECTIONS:
        mask = (np.ones(len(kinds), dtype=bool) if way["kind"] is None
                else kinds == way["kind"])
        part = values[mask]
        if not len(part):
            continue
        ranks[way["id"]] = leg_profile.leg_ranks(part)
        mean, counted = leg_profile.mean_ranks(part)
        track[way["id"]] = {
            f'{column["agg"]}|{column["feature"]}': {
                "ranks": [cell(mean[step, index]) for step in range(bins)],
                "legs": int(counted[index])}
            for index, column in enumerate(columns)}
        legs[way["id"]] = int(mask.sum())

    compare = {}
    if "up" in ranks and "down" in ranks:
        auc = leg_profile.rank_auc(ranks["up"], ranks["down"])
        compare = {f'{column["agg"]}|{column["feature"]}':
                   [cell(auc[step, index]) for step in range(bins)]
                   for index, column in enumerate(columns)}
    return {"class_id": kind["id"], "class_title": kind["title"],
            "batch": size, "features": features,
            "folds": [item["id"] for item in pivot.AGGREGATES],
            "legs": legs, "track": track, "compare": compare}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--class", dest="class_id", action="append",
                        default=None, choices=sorted(umap_subsets.CLASSES))
    parser.add_argument("--bins", type=int, default=BINS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sizes = tuple(args.batch) if args.batch else BATCHES
    ids = args.class_id or list(umap_subsets.ORDER)
    cards = []
    for class_id in ids:
        kind = dict(umap_subsets.CLASSES[class_id], id=class_id)
        for size in sizes:
            cards.append(one_class(kind, size, args.bins, args.data))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_track.json").write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/leg_track.py",
        "command": "python3 research/21-class210x10x7dc/scripts/leg_track.py",
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "pairs": list(PAIRS),
        "aggregates": pivot.AGGREGATES, "families": pivot.FAMILIES,
        "directions": [{"id": one["id"], "name": one["name"]}
                       for one in DIRECTIONS],
        "default_direction": "all", "bins": args.bins,
        "batches": list(sizes), "default_batch": sizes[0],
        "classes": [{"id": class_id,
                     "title": umap_subsets.CLASSES[class_id]["title"],
                     "folder": umap_subsets.CLASSES[class_id]["folder"]}
                    for class_id in ids],
        "default_class": ids[0], "event_seconds": EVENT_LENGTH,
        "cards": cards, "ready": True}, ensure_ascii=False), encoding="utf-8")

    middle = (args.bins + 1) / 2
    for card in cards:
        best = max(((key, values["ranks"])
                    for key, values in card["track"]["all"].items()),
                   key=lambda one: max(abs(value - middle)
                                       for value in one[1]
                                       if value is not None))
        span = max(best[1]) - min(best[1])
        print(f"{card['class_title']:22s} W={card['batch']:<3d} "
              f"ніг {card['legs']['all']:3d} · найрухливіша колонка "
              f"{best[0]} · розмах рангу {span:.2f}")
    print(f"записано {args.out}/leg_track.json")


if __name__ == "__main__":
    main()
