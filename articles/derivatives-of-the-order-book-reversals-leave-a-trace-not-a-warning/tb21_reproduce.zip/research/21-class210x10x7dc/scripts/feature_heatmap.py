"""Теплові карти фіч: два класи × дві довжини пачки.

Дослідження: research/21-class210x10x7dc/
Правила: rules/05-visualization.md → Кольори

Дві карти на кожну комбінацію «клас × довжина пачки»:

**Фіча × згортка.** У клітинці — `AUC` цієї колонки між пачками
«розворот був» і «інша». Рахується **на кожній монеті окремо**, у
клітинку йде медіана: інакше масштаб фічі й монета змішуються в спільному
ранзі. `0.5` — колонка когорти не розрізняє, вище — біля розвороту
значення більші, нижче — менші. Питань три:

    any    чи був розворот узагалі
    low    чи був нижній розворот (проти пачок без розвороту)
    high   чи був верхній розворот

**Фіча × фіча.** У клітинці — кореляція Спірмена між фічами по всіх
пачках train, окремо на кожну згортку. Спірмен — бо похідні мають важкі
хвости. Питання: які фічі несуть одне й те саме.

Розмітка пачок і сама їх нарізка — ті самі, що в `reversal_batches.py`:
пачки не перекриваються, мітку задає півот зігзага 2.3 % на ема10 в її
межах.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/heatmap.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/feature_heatmap.py
    python3 research/21-class210x10x7dc/scripts/feature_heatmap.py --batch 5
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import reversal_batches as reversal  # noqa: E402
import umap_subsets  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
BATCHES = umap_subsets.BATCHES         # 5, 20
QUESTIONS = ({"id": "any", "name": "розворот був"},
             {"id": "low", "name": "нижній розворот"},
             {"id": "high", "name": "верхній розворот"})


def cell(value: float):
    value = float(value)
    return None if not np.isfinite(value) else round(value, 4)


def one_class(kind: dict, size: int, root: Path | None, log=print) -> dict:
    """Одна комбінація «клас × довжина пачки»: обидві карти й лічильники."""
    state = pivot.collect(root, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None,
                          module=kind["module"], folder_name=kind["folder"])
    features = state["features"]
    names = pivot.column_names(features)
    folds = [item["id"] for item in pivot.AGGREGATES]
    place = {(column["agg"], column["feature"]): index
             for index, column in enumerate(names) if column["kind"] == "agg"}

    edge = stamp(CUT)
    per_coin = {item["id"]: {key: [] for key in place} for item in QUESTIONS}
    pooled, counts = [], {"batches": 0, "low": 0, "high": 0, "alive": 0}
    keep_columns = [place[key] for key in place]
    for coin in state["coins"]:
        part = reversal.coin_batches(coin, size)
        keep = part["t_end"] < edge
        label = part["label"][keep]
        cols = part["cols"][keep]
        counts["batches"] += int(keep.sum())
        counts["low"] += int((label == 1).sum())
        counts["high"] += int((label == 2).sum())
        counts["alive"] += int(np.isfinite(cols[:, keep_columns])
                               .all(axis=1).sum())
        groups = {"any": (label > 0, label == 0),
                  "low": (label == 1, label == 0),
                  "high": (label == 2, label == 0)}
        for key, index in place.items():
            column = cols[:, index]
            for question, (left, right) in groups.items():
                per_coin[question][key].append(
                    reversal.auc_of(column, left, right))
        pooled.append(cols)
    pooled = np.concatenate(pooled)
    log(f"      {kind['folder']} W={size}: пачок {counts['batches']}, "
        f"живих {100 * counts['alive'] / counts['batches']:.0f}%, "
        f"нижніх {counts['low']}, верхніх {counts['high']}")

    auc = {}
    for question in QUESTIONS:
        rows = []
        for feature in features:
            line = []
            for fold in folds:
                values = np.asarray(per_coin[question["id"]][(fold, feature)],
                                    dtype=float)
                good = values[np.isfinite(values)]
                line.append(cell(np.median(good)) if len(good) else None)
            rows.append(line)
        auc[question["id"]] = rows

    correlation = {}
    for fold in folds:
        block = pooled[:, [place[(fold, name)] for name in features]]
        correlation[fold] = pivot.spearman_matrix(block)
    return {"class_id": kind["id"], "class_title": kind["title"],
            "batch": size, "features": features, "folds": folds,
            "counts": counts, "auc": auc, "correlation": correlation}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--class", dest="class_id", action="append",
                        default=None, choices=sorted(umap_subsets.CLASSES))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sizes = tuple(args.batch) if args.batch else BATCHES
    ids = args.class_id or list(umap_subsets.ORDER)
    cards = []
    for class_id in ids:
        kind = dict(umap_subsets.CLASSES[class_id], id=class_id)
        for size in sizes:
            cards.append(one_class(kind, size, args.data))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "heatmap.json").write_text(json.dumps({
        "script": "research/21-class210x10x7dc/scripts/feature_heatmap.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "feature_heatmap.py",
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "pairs": list(PAIRS),
        "aggregates": pivot.AGGREGATES, "families": pivot.FAMILIES,
        "questions": list(QUESTIONS), "batches": list(sizes),
        "default_batch": sizes[0], "classes": [
            {"id": class_id, "title": umap_subsets.CLASSES[class_id]["title"],
             "folder": umap_subsets.CLASSES[class_id]["folder"]}
            for class_id in ids],
        "default_class": ids[0], "event_seconds": EVENT_LENGTH,
        "cards": cards, "ready": True}, ensure_ascii=False), encoding="utf-8")

    for card in cards:
        best = max(((feature, fold, card["auc"]["any"][i][j])
                    for i, feature in enumerate(card["features"])
                    for j, fold in enumerate(card["folds"])
                    if card["auc"]["any"][i][j] is not None),
                   key=lambda one: abs(one[2] - 0.5))
        print(f"{card['class_title']:22s} W={card['batch']:<3d} "
              f"найсильніша клітинка {best[1]}·{best[0]} AUC {best[2]:.3f}")
    print(f"записано {args.out}/heatmap.json")


if __name__ == "__main__":
    main()
