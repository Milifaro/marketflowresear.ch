"""Фічі `клас210х10-1х7дц` уздовж ноги: десятина за десятиною.

Дослідження: research/21-class210x10x7dc/
Правила: rules/01-data-and-db.md → клас210х10-1х7дц
         rules/02-markup.md → зігзаг

Питання розділу: **чи залежать фічі від того, де в нозі стоїть подія.**
Розділ 3 порівнював окіл півота з рештою ноги; тут нога ділиться на всі
десять частин, і кожна порівнюється з кожною.

## Що з чого береться

Ноги й десятини — ті самі, що в розділі 2: зігзаг 2.3 % на `ема10`, нога
ділиться на десять рівних частин за кількістю подій.

З кожної десятини береться **початок** — перші `m` подій цієї десятини:

    m = 1, 2, 3, 5, 10        подій з початку кожної десятини

`m = 1` — рівно перша подія десятини, далі вибірка росте. Значення
десятини — середнє згортки по цих `m` подіях. Нога бере участь, тільки
якщо **в кожній з десяти десятин** знайшлось `m` придатних подій: інакше
десять чисел ноги не порівнюються між собою.

Придатна подія — та, у якої є повна пачка з `W` подій підряд
(`pivot_compare.batch_ready`), бо згортки рахуються на пачках так само,
як у розділі 3: `W = 1, 2, 3, 5, 10, 20`.

## Як міряється залежність

Усе рахується **всередині ноги**: у ноги десять своїх чисел на кожну
колонку, і між собою порівнюються тільки вони. Це прибирає і монету, і
режим, і масштаб фічі — лишається чисте місце в нозі.

| Міра | Що каже |
| ---- | ------- |
| **середній ранг** | десятина ранжується серед десяти своїх, ранг усереднюється по ногах. Немає залежності — усі десять близькі до 5.5 |
| **нахил** | кореляція Спірмена між номером десятини й значенням усередині ноги; медіана по ногах і частка ніг з додатним нахилом |
| **матриця** | частка ніг, де десятина `i` більша за десятину `j`. `0.5` — різниці немає, `1.0` — `i` більша завжди |

Матриця — це парне порівняння: обидві десятини беруться з тієї самої ноги,
тому воно читається як знаковий тест, а не як порівняння двох вибірок.

Вхід : data/datasets/<PAIR>/class210x10m1x7dc/{train,val}.npz
       ноги, десятини й згортки — leg_deciles.py, pivot_compare.py
Вихід: results/leg_profile.json

Запуск:
    python3 research/21-class210x10x7dc/scripts/leg_profile.py
    python3 research/21-class210x10x7dc/scripts/leg_profile.py --batch 1 --start 3
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
from build_class210x10x7dc import CUT, PAIRS, stamp  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

DECILES = leg_deciles.DECILES          # 10
BATCHES = pivot.BATCHES                # 1, 2, 3, 5, 10, 20
DEFAULT_BATCH = pivot.DEFAULT_BATCH
STARTS = (1, 2, 3, 5, 10)              # подій з початку кожної десятини
DEFAULT_START = 1

# Нога вгору і нога вниз міряються нарізно й порівнюються між собою:
# напрямок задає півот, яким нога закінчується (rules/02 → зігзаг).
DIRECTIONS = ({"id": "all", "name": "усі ноги", "kind": None},
              {"id": "up", "name": "ноги вгору", "kind": "up"},
              {"id": "down", "name": "ноги вниз", "kind": "down"})
DEFAULT_DIRECTION = "all"


def decile_of(group: np.ndarray) -> np.ndarray:
    """Когорта 1…20 -> номер десятини 1…10, поза ногами -> 0."""
    group = np.asarray(group)
    return np.where(group == 0, 0,
                    np.where(group <= DECILES, group, group - DECILES))


def leg_values(coin: dict, start: int) -> tuple[np.ndarray, list]:
    """Значення десяти десятин кожної придатної ноги: (L, 10, C).

    З кожної десятини беруться перші `start` придатних подій, значення —
    середнє їх колонок. Нога, у якої хоч в одній десятині подій менше,
    відкидається цілком.
    """
    edge = stamp(CUT)
    decile = decile_of(coin["group"])
    ready = coin["ready"]
    rows, kinds = [], []
    pivots = coin["pivots"]
    for previous, pivot_point in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot_point.index
        if last <= first or coin["t"][last] >= edge:
            continue
        events = np.arange(first, last + 1)
        block = np.empty((DECILES, coin["cols"].shape[1]))
        whole = True
        for step in range(DECILES):
            picked = events[decile[events] == step + 1]
            picked = picked[ready[picked]][:start]
            if len(picked) < start:
                whole = False
                break
            with np.errstate(invalid="ignore"), warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                block[step] = np.nanmean(coin["cols"][picked], axis=0)
        if whole:
            rows.append(block)
            kinds.append("up" if pivot_point.kind == "high" else "down")
    if not rows:
        return np.empty((0, DECILES, coin["cols"].shape[1])), kinds
    return np.stack(rows), kinds


def leg_ranks(values: np.ndarray) -> np.ndarray:
    """Ранг кожної десятини серед десяти своїх: (L, 10, C).

    Ранг рахується всередині **своєї** ноги, тому масштаб фічі й монета
    скорочуються. Нога, у якої в цій колонці є `NaN`, дає `NaN` цілком —
    десять її чисел уже не повний набір.
    """
    ranks = np.full(values.shape, np.nan)
    for index in range(len(values)):
        ranks[index] = rankdata(values[index], axis=0, nan_policy="omit")
    finite = np.isfinite(values).all(axis=1)          # (L, C)
    return np.where(finite[:, None, :], ranks, np.nan)


def mean_ranks(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Середній ранг кожної десятини по ногах: (10, C) і скільки ніг (C,)."""
    ranks = leg_ranks(values)
    finite = np.isfinite(values).all(axis=1)
    with np.errstate(invalid="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mean = np.nanmean(ranks, axis=0)
    return mean, finite.sum(axis=0)


def rank_auc(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """AUC рангів двох груп ніг по кожній десятині: (10, C).

    Ранг уже нормований усередині ноги, тому ноги вгору й ноги вниз
    порівнюються між собою напряму: `0.5` — розподіли рангів однакові.
    """
    deciles, width = left.shape[1], left.shape[2]
    out = np.full((deciles, width), np.nan)
    for step in range(deciles):
        for column in range(width):
            a = left[:, step, column]
            b = right[:, step, column]
            a, b = a[np.isfinite(a)], b[np.isfinite(b)]
            if not len(a) or not len(b):
                continue
            ranks = rankdata(np.concatenate([a, b]))
            out[step, column] = ((ranks[:len(a)].sum()
                                  - len(a) * (len(a) + 1) / 2)
                                 / (len(a) * len(b)))
    return out


def slope(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Нахил профілю: медіана Спірмена по ногах і частка додатних.

    Спірмен береться між номером десятини (1…10) і значенням усередині
    ноги — тобто «фіча росте вздовж ноги чи спадає».
    """
    legs, deciles, width = values.shape
    place = np.arange(1, deciles + 1, dtype=float)
    place = (place - place.mean())
    denominator = np.sqrt((place ** 2).sum())
    rho = np.full((legs, width), np.nan)
    for index in range(legs):
        ranks = rankdata(values[index], axis=0, nan_policy="omit")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            centred = ranks - np.nanmean(ranks, axis=0)
        bottom = np.sqrt(np.nansum(centred ** 2, axis=0)) * denominator
        with np.errstate(invalid="ignore", divide="ignore"):
            rho[index] = np.where(bottom > 0,
                                  (centred * place[:, None]).sum(axis=0) / bottom,
                                  np.nan)
    finite = np.isfinite(values).all(axis=1) & np.isfinite(rho)
    rho = np.where(finite, rho, np.nan)
    counted = finite.sum(axis=0)
    with np.errstate(invalid="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        median = np.nanmedian(rho, axis=0)
        # частка рахується тільки серед ніг, де нахил є: інакше нога без
        # нахилу (NaN) мовчки йде в «нижче нуля»
        above = np.where(counted > 0,
                         np.nansum(rho > 0, axis=0) / np.maximum(counted, 1),
                         np.nan)
    return median, above


def pair_matrix(values: np.ndarray) -> np.ndarray:
    """Частка ніг, де десятина `i` більша за десятину `j`: (10, 10, C)."""
    legs, deciles, width = values.shape
    out = np.full((deciles, deciles, width), np.nan)
    for i in range(deciles):
        for j in range(deciles):
            if i == j:
                out[i, j] = 0.5
                continue
            left, right = values[:, i], values[:, j]
            good = np.isfinite(left) & np.isfinite(right)
            wins = (left > right).astype(float) + 0.5 * (left == right)
            with np.errstate(invalid="ignore"):
                out[i, j] = np.where(good.sum(axis=0) > 0,
                                     np.nansum(np.where(good, wins, 0), axis=0)
                                     / np.maximum(good.sum(axis=0), 1), np.nan)
    return out


def build(root: Path | None, period: int, threshold: float, batches,
          starts, log=print) -> dict:
    state = pivot.collect(root, period, threshold, (10,), log=lambda *a: None)
    features = state["features"]
    names = pivot.column_names(features)
    for coin, pair in zip(state["coins"], PAIRS):
        one = leg_deciles.build_pair(pair, root, period, threshold)
        coin["group"] = one["group"]

    def number(value):
        return None if not np.isfinite(value) else round(float(value), 4)

    profile, trend, matrix, compare, legs_count = [], [], [], [], {}
    for batch in batches:
        for coin in state["coins"]:
            coin["ready"] = pivot.batch_ready(coin["t"], batch)
            coin["cols"] = pivot.columns_of(coin["x"], coin["ready"], batch)
        legs_count[str(batch)] = {}
        for start in starts:
            blocks, kinds = [], []
            for coin in state["coins"]:
                block, kind = leg_values(coin, start)
                if len(block):
                    blocks.append(block)
                    kinds += kind
            values = np.concatenate(blocks) if blocks else np.empty(
                (0, DECILES, len(names)))
            kinds = np.array(kinds)
            legs_count[str(batch)][str(start)] = {
                "legs": int(len(values)),
                "up": int((kinds == "up").sum()),
                "down": int((kinds == "down").sum()),
                "events": int(len(values) * DECILES * start)}
            if not len(values):
                continue
            ranks_all = {}
            for way in DIRECTIONS:
                mask = (np.ones(len(kinds), dtype=bool) if way["kind"] is None
                        else kinds == way["kind"])
                part = values[mask]
                if not len(part):
                    continue
                ranks_all[way["id"]] = leg_ranks(part)
                mean, counted = mean_ranks(part)
                median, above = slope(part)
                wins = pair_matrix(part)
                for index, column in enumerate(names):
                    if column["kind"] != "agg":
                        continue
                    tag = {"batch": batch, "start": start, "dir": way["id"],
                           "agg": column["agg"], "feature": column["feature"]}
                    profile.append({
                        **tag, "legs": int(counted[index]),
                        "ranks": [number(mean[step, index])
                                  for step in range(DECILES)]})
                    trend.append({**tag, "rho": number(median[index]),
                                  "above_zero": number(above[index]),
                                  "legs": int(counted[index])})
                    matrix.append({**tag, "wins": [
                        [number(wins[i, j, index]) for j in range(DECILES)]
                        for i in range(DECILES)]})
            if "up" in ranks_all and "down" in ranks_all:
                auc = rank_auc(ranks_all["up"], ranks_all["down"])
                for index, column in enumerate(names):
                    if column["kind"] != "agg":
                        continue
                    compare.append({
                        "batch": batch, "start": start,
                        "agg": column["agg"], "feature": column["feature"],
                        "auc": [number(auc[step, index])
                                for step in range(DECILES)]})
            log(f"      пачка {batch}, початок {start}: "
                f"{len(values)} ніг готово")
    return {"features": features, "profile": profile, "trend": trend,
            "matrix": matrix, "compare": compare, "legs": legs_count}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--start", type=int, action="append", default=None)
    parser.add_argument("--period", type=int, default=leg_deciles.PERIOD)
    parser.add_argument("--threshold", type=float,
                        default=leg_deciles.THRESHOLD)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    batches = tuple(args.batch) if args.batch else BATCHES
    starts = tuple(args.start) if args.start else STARTS
    body = build(args.data, args.period, args.threshold, batches, starts)
    payload = {
        "script": "research/21-class210x10x7dc/scripts/leg_profile.py",
        "command": "python3 research/21-class210x10x7dc/scripts/"
                   "leg_profile.py",
        "class": pivot.CLASS, "class_title": "клас210х10-1х7дц",
        "threshold": args.threshold, "period": args.period,
        "cut_utc": f"{CUT} 00:00:00", "pairs": list(PAIRS),
        "deciles": DECILES, "batches": list(batches),
        "default_batch": DEFAULT_BATCH, "starts": list(starts),
        "default_start": DEFAULT_START,
        "directions": [{"id": way["id"], "name": way["name"]}
                       for way in DIRECTIONS],
        "default_direction": DEFAULT_DIRECTION,
        "aggregates": pivot.AGGREGATES, "families": pivot.FAMILIES,
        "event_seconds": pivot.EVENT_LENGTH, "ready": True, **body}
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_profile.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    start = DEFAULT_START if DEFAULT_START in starts else starts[0]
    for batch in batches:
        one = payload["legs"][str(batch)][str(start)]
        print(f"пачка {batch}: ніг {one['legs']} "
              f"({one['up']} вгору, {one['down']} вниз)")
    print(f"перша десятина, пачка {batches[-1]}, початок {start}, "
          f"згортка abs:")
    for name in payload["features"]:
        line = f"  {name:14s}"
        for way in DIRECTIONS:
            row = next((one for one in payload["profile"]
                        if one["batch"] == batches[-1] and one["start"] == start
                        and one["agg"] == "abs" and one["feature"] == name
                        and one["dir"] == way["id"]), None)
            if row and row["ranks"][0] is not None:
                line += f"  {way['id']} {row['ranks'][0]:5.2f} ({row['legs']})"
        one = next((row for row in payload["compare"]
                    if row["batch"] == batches[-1] and row["start"] == start
                    and row["agg"] == "abs" and row["feature"] == name), None)
        if one and one["auc"][0] is not None:
            line += f"  вгору проти вниз AUC {one['auc'][0]:.3f}"
        print(line)
    print(f"записано в {args.out}/leg_profile.json")


if __name__ == "__main__":
    main()
