"""Мережа з памʼяттю на повноту ноги: чи бачить вона кінець ноги.

Дослідження: research/26-leg-share-filter/
Правила: rules/01-data-and-db.md → Скейлери
         rules/03-models.md → Навчання моделей

Етап 1 показав дві речі. Ідея фільтра правильна: на **справжній** частці
ноги точність драбини росте з 51 % до 92.7 % без втрати жодного влучного
сигналу. Оцінювач — ні: дерева на агрегатах події дають на val `MAE`
гірший за константу і `AUC` останньої десятини всього 0.656.

Дерево бачить одну подію. Частка ноги — властивість **усього руху**: щоб
сказати «ми в кінці», треба памʼятати, де нога почалась і скільки таких
ніг уже було. Тут те саме питання ставиться мережі з памʼяттю.

## Вікно

| Вікно, подій | Годин | Діб | Півотів: медіана | чверть | три чверті |
| -----------: | ----: | --: | ---------------: | -----: | ---------: |
| 1000 | 58 | 2.4 | 1 | 1 | 2 |
| 1500 | 88 | 3.6 | 2 | 1 | 3 |
| 2000 | 117 | 4.9 | 3 | 2 | 4 |
| 2500 | 146 | 6.1 | 4 | 3 | 6 |
| **5000** | **292** | **12.2** | **8** | **5** | **11** |

Узято `5000` подій — дванадцять діб, у медіані вісім півотів. Подавати
їх подія за подією немає сенсу й немає можливості, тому вікно
**проріджується**: `LENGTH = 500` кроків через `STEP = 10` подій. Ці
ручки, як і `HIDDEN = 64`, один шар і `rate = 3e-4`, узяті з гріду
([`grid_share.py`](grid_share.py)).

Памʼять вікна val вільно дістає з train — це минуле, і саме так мережа
працює наживо. Тому видача є на кожній події val, і фільтр міряється на
всьому val, як у дерев етапу 1.

## Приклад і мітка

Вікно кінчається на події `e`, мітка та сама, що в етапі 1:

    частка = i / L,  де i — місце події в нозі, L — довжина ноги

У навчання йде кожна `EVERY`-та подія: сусідні вікна перекриваються на
99.6 %, і вчити на всіх — платити за ту саму інформацію сто разів. Числа
на хвості train і на val, як і видача для фільтра, рахуються на **кожній**
події.

## Набори каналів

| Набір | Каналів | Що подається |
| ----- | ------: | ------------ |
| `елапс` | 1 | причинний лічильник подій від підтвердженого півота |
| `вікна+елапс` | 21 | пʼять чисел контексту на чотирьох вікнах плюс лічильник |
| `вікна+елапс+клас` | 84 | плюс 63 числа класу події |

Ті самі набори, що в етапі 1, — щоб різниця була тільки в моделі.

## Скейлер

Кожен канал переводиться в квантиль свого ряду
([`rules/scripts/scalers.py`](../../rules/scripts/scalers.py)), скейлер
рахується на подіях `train` **своєї монети**.

## Вибір епохи

Мережа запамʼятовує навчання, тому епоха обирається не за val і не за
train, а за **внутрішнім хвостом**: останні `INNER` діб перед `CUT` у
навчанні не беруть участі. Val у виборі не бере участі взагалі.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/share_lstm.json     — числа навчання й фільтра
       results/mem_<PAIR>.json     — оцінка мережі на ряді val монети

Запуск:
    python3 research/26-leg-share-filter/scripts/share_lstm.py
    python3 research/26-leg-share-filter/scripts/share_lstm.py --sets елапс
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "24-val-check" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "23-reversal-signal"
                       / "scripts"))

import scalers  # noqa: E402
import signal_data as legs  # noqa: E402
import leg_context  # noqa: E402
import pivot_delay  # noqa: E402
import val_check  # noqa: E402
import leg_share  # noqa: E402
from signal_data import CUT, END, PAIRS, stamp  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LENGTH = 500               # кроків у вікні
STEP = 10                  # подій між кроками: памʼять на 5000 подій
EVERY = 10                 # кожен який приклад іде в навчання
HIDDEN = 64
LAYERS = 1
DROPOUT = 0.1
BATCH = 128
EPOCHS = 8
RATE = 3e-4
INNER = 7                  # діб train у хвості: вибір епохи
SETS = ("елапс", "вікна+елапс", "вікна+елапс+клас")
PARTS = {"елапс": ("елапс",),
         "вікна+елапс": ("вікна", "елапс"),
         "вікна+елапс+клас": ("вікна", "елапс", "клас")}
SEED = legs.SEED
MEMORY = LENGTH * STEP     # скільки подій лежить у памʼяті


def device_of():
    import torch

    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def width_of(channels: dict, name: str) -> int:
    return sum(channels[one].shape[1] for one in PARTS[name])


def coin_channels(coin: dict) -> dict:
    """Канали монети: вікна контексту, лічильник і клас, у квантилі.

    Канали від довжини вікна не залежать, тому рахуються раз на монету й
    лишаються при ній: грід ручок будує стан під кожне вікно наново.
    """
    if "channels" in coin:
        return coin["channels"]
    windows = []
    for look in pivot_delay.LOOKS:
        found = dict(legs.context_of(coin["ema"], coin["pivots"], look))
        found["move"] = np.maximum(found["run"], found["draw"])
        windows.append(np.column_stack([found[name]
                                        for name in leg_context.CONTEXT]))
    raw = {"вікна": np.hstack(windows),
           "елапс": leg_share.confirmed_elapsed(
               coin["ema"], coin["pivots"]).reshape(-1, 1),
           "клас": coin["x"].reshape(len(coin["t"]), -1).astype(np.float64)}
    train = coin["t"] < stamp(CUT)
    out = {}
    for name, values in raw.items():
        scaled = np.empty(values.shape, dtype=np.float32)
        for index in range(values.shape[1]):
            column = values[:, index].astype(np.float64)
            fit = scalers.quantile_fit(column[train])
            scaled[:, index] = scalers.quantile_apply(column, fit)
        out[name] = np.nan_to_num(scaled, nan=0.0, posinf=0.0, neginf=0.0)
    coin["channels"] = out
    coin.pop("x", None)          # фічі більше не потрібні: є канали
    return out


def windows_of(coin: dict, length: int = LENGTH, step: int = STEP,
               inner: int = INNER) -> dict:
    """Кінці вікон, мітка й частина ряду.

    Частина береться за **кінцем** вікна. Вікно train цілком лежить у
    train: воно тягнеться назад, а назад від межі — тільки train. Вікно
    val кінчається у val, але памʼять йому вільно діставати з train: це
    минуле, і саме так мережа працює наживо. Тому в навчання жодна подія
    val не потрапляє, а видача є на **кожній** події val — з першої.

    Хвіст train завдовжки `inner` діб іде на вибір епохи й у навчанні
    участі не бере.
    """
    t = coin["t"]
    edge, right = stamp(CUT), stamp(END)
    reach = (length - 1) * step
    ends = np.arange(reach, len(t))
    last = t[ends]
    part = np.where(last < edge, "train",
                    np.where(last < right, "val", "поза"))
    part = np.where((part == "train") & (last >= edge - inner * 86400),
                    "хвіст", part)
    share, _ = leg_share.leg_share(coin)
    return {"ends": ends, "y": share[ends].astype(np.float32), "part": part}


def collect(coins: list, length: int = LENGTH, step: int = STEP,
            every: int = EVERY, log=print) -> dict:
    """Канали, кінці вікон і мітки всіх монет.

    У навчання й вибір епохи йде кожна `every`-та подія, у видачу — усі.
    """
    body = []
    for number, coin in enumerate(coins):
        channels = coin_channels(coin)
        found = windows_of(coin, length, step)
        keep = np.isfinite(found["y"])          # поза ногами мітки немає
        thin = np.zeros(len(found["ends"]), dtype=bool)
        thin[::every] = True
        body.append({"pair": coin["pair"], "coin": number,
                     "channels": channels, "ends": found["ends"],
                     "y": np.nan_to_num(found["y"]), "part": found["part"],
                     "label": keep, "thin": thin})
        log(f"      {coin['pair']}: вікон {len(found['ends'])}, у навчання "
            f"{int((thin & keep & (found['part'] == 'train')).sum())}, "
            f"хвіст {int((thin & keep & (found['part'] == 'хвіст')).sum())}, "
            f"val {int((keep & (found['part'] == 'val')).sum())}")
    return {"coins": body, "length": length, "step": step}


def rows_of(state: dict, part: str, thin: bool = True,
            label: bool = True) -> np.ndarray:
    """(монета, місце) кожного вікна частини — у порядку подачі в мережу."""
    rows = []
    for one in state["coins"]:
        mask = one["part"] == part
        if thin:
            mask = mask & one["thin"]
        if label:
            mask = mask & one["label"]
        rows.extend((one["coin"], index) for index in np.flatnonzero(mask))
    return np.array(rows, dtype=np.int64).reshape(-1, 2)


def batches(state: dict, name: str, rows: np.ndarray, batch: int = BATCH,
            shuffle: bool = False, seed: int = SEED):
    """Пачки вікон одного набору каналів: (batch, length, канали)."""
    if shuffle:
        rows = rows.copy()
        np.random.default_rng(seed).shuffle(rows)
    length, step = state["length"], state["step"]
    reach = (length - 1) * step
    width = width_of(state["coins"][0]["channels"], name)
    for start in range(0, len(rows), batch):
        block = rows[start:start + batch]
        x = np.empty((len(block), length, width), dtype=np.float32)
        y = np.empty(len(block), dtype=np.float32)
        for place, (number, index) in enumerate(block):
            coin = state["coins"][number]
            end = int(coin["ends"][index])
            spot = np.arange(end - reach, end + 1, step)
            at = 0
            for part in PARTS[name]:
                values = coin["channels"][part]
                x[place, :, at:at + values.shape[1]] = values[spot]
                at += values.shape[1]
            y[place] = coin["y"][index]
        yield x, y


def build(channels: int, hidden: int = HIDDEN, layers: int = LAYERS,
          dropout: float = DROPOUT, seed: int = SEED):
    import torch
    from torch import nn

    torch.manual_seed(seed)

    class Share(nn.Module):
        """LSTM по вікну подій -> частка ноги на останньому стані."""

        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(channels, hidden, layers, batch_first=True)
            self.norm = nn.LayerNorm(hidden)
            self.drop = nn.Dropout(dropout)
            self.head = nn.Linear(hidden, 1)

        def forward(self, x):
            out, _ = self.lstm(x)
            return self.head(self.drop(self.norm(out[:, -1]))).squeeze(-1)

    return Share()


def predict(model, state: dict, name: str, rows: np.ndarray, device,
            batch: int = BATCH) -> tuple:
    import torch

    model.eval()
    out, want = [], []
    with torch.no_grad():
        for x, y in batches(state, name, rows, batch):
            found = model(torch.from_numpy(x).to(device))
            out.append(torch.sigmoid(found).float().cpu().numpy())
            want.append(y)
    if not out:
        return np.empty(0), np.empty(0)
    return np.concatenate(out), np.concatenate(want)


def train_once(state: dict, name: str, epochs: int = EPOCHS,
               rate: float = RATE, seed: int = SEED, log=print) -> dict:
    """Навчання на train і оцінки після кожної епохи."""
    import torch
    from torch import nn

    device = device_of()
    width = width_of(state["coins"][0]["channels"], name)
    model = build(width, seed=seed).to(device)
    loss = nn.L1Loss()
    tune = torch.optim.Adam(model.parameters(), lr=rate)
    fit = rows_of(state, "train")
    look = {"хвіст": rows_of(state, "хвіст", thin=False),
            "val": rows_of(state, "val", thin=False)}
    history, started, best = [], time.time(), None
    for epoch in range(1, epochs + 1):
        model.train()
        total, seen = 0.0, 0
        for x, y in batches(state, name, fit, shuffle=True, seed=seed + epoch):
            found = torch.sigmoid(model(torch.from_numpy(x).to(device)))
            step = loss(found, torch.from_numpy(y).to(device))
            tune.zero_grad()
            step.backward()
            tune.step()
            total += float(step.detach()) * len(y)
            seen += len(y)
        row = {"epoch": epoch, "loss": legs.cell(total / max(seen, 1))}
        for key, rows in look.items():
            said, want = predict(model, state, name, rows, device)
            row[key] = leg_share.measure_share(want, said)
        history.append(row)
        log(f"      {name} епоха {epoch:>2}: втрата {row['loss']}, хвіст MAE "
            f"{row['хвіст']['mae']}, val MAE {row['val']['mae']}, val AUC "
            f"останньої {row['val']['auc_last']}")
        if best is None or row["хвіст"]["mae"] < best["хвіст"]["mae"]:
            best = row
            torch.save(model.state_dict(), RESULTS / f"share_{name}.pt")
    model.load_state_dict(torch.load(RESULTS / f"share_{name}.pt"))
    return {"history": history, "best": best, "model": model,
            "device": str(device), "channels": width,
            "parameters": int(sum(one.numel() for one in model.parameters())),
            "seconds": round(time.time() - started, 1)}


def said_by_event(model, state: dict, name: str, coins: list,
                  part: str = "val", thin: bool = False) -> list:
    """Оцінена частка ноги на кожній події частини `part` кожної монети."""
    device = device_of()
    out = [np.full(len(coin["t"]), np.nan, dtype=np.float32)
           for coin in coins]
    rows = rows_of(state, part, thin=thin, label=False)
    said, _ = predict(model, state, name, rows, device)
    for (number, index), value in zip(rows, said):
        out[number][int(state["coins"][number]["ends"][index])] = value
    return out


def coin_share(coin: dict, line: np.ndarray, name: str) -> dict:
    """Оцінка мережі на ті самі події, що й ряд `leg_share.coin_series`."""
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return {"pair": coin["pair"], "events": 0, "ready": False}
    index = np.arange(int(inside[0]), int(inside[-1]) + 1)
    return {"pair": coin["pair"], "ready": True, "events": int(len(index)),
            "t": coin["t"][index].astype(int).tolist(),
            "memory": [None if not np.isfinite(one) else round(float(one), 4)
                       for one in line[index]],
            "memory_set": name, "memory_events": MEMORY}


def rank_line(base: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Ранг оцінки в її власному розподілі на train.

    Мережа вчиться під `L1` і тримає видачу біля середини: сказати «0.95»
    їй невигідно, тому поріг на самій оцінці ріже все. Ранг прибирає
    шкалу й лишає порядок: поріг `0.9` означає «верхні 10 % оцінок», а
    для справжньої частки це рівно те саме — остання десятина ноги.
    """
    base = np.sort(base[np.isfinite(base)])
    out = np.full(len(values), np.nan, dtype=np.float32)
    good = np.isfinite(values)
    if not len(base):
        return out
    out[good] = np.searchsorted(base, values[good], side="right") / len(base)
    return out


def ready_events(state: dict, coins: list) -> list:
    """Події val, на яких вікно мережі цілком лежить після межі навчання."""
    out = []
    for number, coin in enumerate(coins):
        line = np.zeros(len(coin["t"]), dtype=bool)
        one = state["coins"][number]
        line[one["ends"][one["part"] == "val"]] = True
        out.append(line)
    return out


def filter_part(coins: list, boards: list, lag: int, ready: list,
                said: list, trees: list, base: dict, seed: int = SEED,
                log=print) -> dict:
    """Фільтр: мережа, дерева і справжня частка на тих самих сигналах.

    Памʼять вікна val дістає з train, тому відповідь мережі є на кожній
    події val і всі три способи міряються на всьому val.

    Кожен оцінювач іде двічі: на своїй шкалі і на **рангу** свого
    розподілу train (`rank_line`). Ранг потрібен, бо поріг `0.9` на
    справжній частці означає останню десятину — рівно 10 % подій, — а на
    стиснутій видачі моделі те саме число означає «майже ніколи».
    """
    found = leg_share.rung_rows(coins, boards, lag)
    packs = found["packs"]
    score, edge = leg_share.rung_score(packs, seed=seed)
    val = packs["part"] == "val"
    here, net, tree, real = [], [], [], []
    for number, (coin, one) in enumerate(zip(coins, found["rows"])):
        spot = np.clip(one["ends"] - lag, 0, len(coin["t"]) - 1)
        here.append(ready[number][one["ends"]])
        net.append(said[number][spot])
        tree.append(trees[number][spot])
        real.append(leg_share.leg_share(coin)[0][spot])
    keep = val & np.concatenate(here)
    days = int(keep.sum()) * legs.EVENT_LENGTH / 86400
    fired = (score >= edge) & keep
    body = {"lag": lag, "minutes": round(lag * legs.EVENT_LENGTH / 60, 1),
            "edge": legs.cell(edge), "set": leg_share.SIGNAL_SET,
            "val": {"packs": int(keep.sum()),
                    "reversal": int(packs["y"][keep].sum()),
                    "days": legs.cell(days)}}
    net, tree, real = (np.concatenate(net), np.concatenate(tree),
                       np.concatenate(real))
    for name, line in (("мережа", net), ("дерева", tree),
                       ("мережа, ранг", rank_line(base["мережа"], net)),
                       ("дерева, ранг", rank_line(base["дерева"], tree)),
                       ("справжня", real)):
        body[name] = leg_share.gate_curve(packs["y"][keep], fired[keep],
                                          line[keep], days)
        top = [one for one in body[name] if one["gate"] == 0.9][0]
        log(f"      N {lag:>3} {name:<13}: без фільтра "
            f"{body[name][0]['precision']} -> поріг 0.9 {top['precision']} "
            f"(взято {top['taken']}, хибних {top['false']})")
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sets", nargs="+", default=list(SETS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--lags", type=int, nargs="+",
                        default=list(leg_share.LAGS))
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    print("[монети]")
    coins = legs.collect(args.data)
    boards = [pivot_delay.coin_board(coin, part="all") for coin in coins]
    print("[дерева етапу 1]")
    rows = [leg_share.coin_rows(coin, board)
            for coin, board in zip(coins, boards)]
    packs = leg_share.gather(rows)
    trees = leg_share.share_by_event(coins, rows, packs,
                                     leg_share.SHARE_SET, args.seed)
    print("[вікна]")
    state = collect(coins, log=print)
    ready = ready_events(state, coins)

    print("[навчання]")
    body, best = [], None
    for name in args.sets:
        got = train_once(state, name, args.epochs, seed=args.seed)
        said = said_by_event(got["model"], state, name, coins)
        base = said_by_event(got["model"], state, name, coins,
                             part="train", thin=True)
        row = {"set": name, "channels": got["channels"],
               "parameters": got["parameters"], "device": got["device"],
               "seconds": got["seconds"],
               "history": [{key: one[key] for key in
                            ("epoch", "loss", "хвіст", "val")}
                           for one in got["history"]],
               "best": {key: got["best"][key] for key in
                        ("epoch", "loss", "хвіст", "val")}}
        body.append(row)
        if best is None or (row["best"]["хвіст"]["mae"]
                            < best[2]["best"]["хвіст"]["mae"]):
            best = (said, base, row)

    print("[фільтр]")
    base = {"мережа": np.concatenate(best[1]),
            "дерева": np.concatenate(
                [one[coin["part"] == "train"]
                 for one, coin in zip(trees, coins)])}
    rungs = [filter_part(coins, boards, lag, ready, best[0], trees, base,
                         args.seed)
             for lag in args.lags]

    print("[ряди монет]")
    for coin, line in zip(coins, best[0]):
        body_one = coin_share(coin, line, best[2]["set"])
        (args.out / f"mem_{coin['pair']}.json").write_text(
            json.dumps(body_one, ensure_ascii=False), encoding="utf-8")
        print(f"      {coin['pair']}: подій {body_one['events']}, з оцінкою "
              f"{sum(one is not None for one in body_one.get('memory', []))}")

    (args.out / "share_lstm.json").write_text(json.dumps({
        "script": "research/26-leg-share-filter/scripts/share_lstm.py",
        "command": "python3 research/26-leg-share-filter/scripts/"
                   "share_lstm.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "sets": list(args.sets), "picked": best[2]["set"],
        "length": LENGTH, "step": STEP, "memory": MEMORY, "every": EVERY,
        "hidden": HIDDEN, "layers": LAYERS, "dropout": DROPOUT,
        "batch": BATCH, "rate": RATE, "epochs": args.epochs,
        "inner_days": INNER, "scaler": "quantile", "seed": args.seed,
        "epoch_by": "хвіст train", "loss": "L1",
        "lags": list(args.lags), "grid": list(leg_share.GRID),
        "signal_set": leg_share.SIGNAL_SET,
        "kinds": ["мережа", "дерева", "мережа, ранг", "дерева, ранг",
                  "справжня"],
        "tree_set": leg_share.SHARE_SET, "recall": leg_share.RECALL,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "rows": body, "rungs": rungs, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/share_lstm.json")


if __name__ == "__main__":
    main()
