"""Повнота ноги як фільтр хибних сигналів розвороту.

Дослідження: research/26-leg-share-filter/
Правила: rules/03-models.md → Навчання моделей

Драбина дослідження 23 відповідає «півот був `N` подій тому» і на val
дає 50 % точності: половина сигналів хибна. Питання цього дослідження —
**чи можна скасувати хибні другим сигналом**: подія, на яку показує
драбина, або стоїть у кінці ноги, або ні.

## Дві частини

1. **Оцінювач повноти ноги.** На кожній події питаємо, яку частку своєї
   ноги вона пройшла: `0.0` — початок, `1.0` — кінець. Мітка береться
   заднім числом із зігзага, входи — тільки причинні.
2. **Фільтр.** Сигнал драбини приймається, лише коли оцінена частка ноги
   на події, куди він показує, не менша за поріг `g`. Міряється, скільки
   хибних сигналів це прибирає і скільки влучних коштує.

## Мітка: частка ноги

Нога — відрізок між двома сусідніми півотами зігзага 2.3 % на ема10
(`leg_deciles.cohorts`). Для події на місці `i` всередині ноги довжини
`L`:

    частка = i / L        десятина = 1 + ⌊10 · частка⌋

Довжина ноги відома лише заднім числом, тому це **мітка**, а не вхід.

## Входи: усе причинне

| Набір | Входів | Що подається |
| ----- | -----: | ------------ |
| `елапс` | 1 | тільки лічильник подій від підтвердженого півота |
| `вікна` | 20 | пʼять чисел контексту на чотирьох вікнах: 200, 400, 800, 1600 |
| `вікна+елапс` | 21 | те саме плюс лічильник |
| `вікна+елапс+клас` | 83 | плюс 62 ознаки пачки, що закінчилась **зараз** |

Лічильник рахується від **підтвердженого** півота, а не від справжнього:
зігзаг ставить півот заднім числом, і онлайн ми дізнаємось про нього
тільки тоді, коли ціна відійшла на 2.3 %. `since_pivot` дослідження 23 —
підказка з майбутнього, і тут його немає.

`елапс` — базовий рівень: дослідження 20 показало, що на десятині ноги
простий лічильник б'є мережу. Він має стояти в таблиці.

## Стеля

Разом із оцінкою фільтр міряється на **справжній** частці ноги —
підказці із зігзага. Це стеля: якщо навіть вона не прибирає хибних,
шукати кращий оцінювач немає сенсу.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/leg_share.json      — числа обох частин
       results/share_<PAIR>.json   — ряд val однієї монети

Запуск:
    python3 research/26-leg-share-filter/scripts/leg_share.py
    python3 research/26-leg-share-filter/scripts/leg_share.py --lags 43
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "research" / "23-reversal-signal"
                       / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "24-val-check" / "scripts"))

import signal_data as legs  # noqa: E402
import leg_context  # noqa: E402
import pivot_delay  # noqa: E402
import val_check  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LOOKS = pivot_delay.LOOKS
DECILES = 10
# набір: (імʼя, вікна, лічильник, клас)
SETS = (("елапс", False, True, False),
        ("вікна", True, False, False),
        ("вікна+елапс", True, True, False),
        ("вікна+елапс+клас", True, True, True))
LAGS = (43, 103)
GRID = (0.0, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95)   # пороги фільтра
SIGNAL_SET = "вікна+клас"    # яким набором стріляє драбина
SHARE_SET = "вікна+елапс"    # яким набором оцінюється повнота ноги
RECALL = 0.3                 # повнота, на якій стоїть поріг драбини
PANEL_LAG = 43               # щабель, який малюється в плашці монети
PANEL_GATE = 0.5             # поріг фільтра за замовчуванням
SEED = legs.SEED
MARKS = ("hit", "false", "cuthit", "cutfalse", "miss")


def confirmed_elapsed(ema: np.ndarray, pivots: list,
                      threshold: float = legs.THRESHOLD) -> np.ndarray:
    """Події від останнього **підтвердженого** півота.

    Зігзаг ставить півот заднім числом: подія `p` стає півотом лише тоді,
    коли ціна відійшла від неї на `threshold`. До того ряд вважає, що
    попередня нога триває. Тут рахується саме те, що видно онлайн: на
    події `e` лічильник іде від останнього півота, **підтвердження**
    якого вже сталося.
    """
    count = len(ema)
    out = np.arange(count, dtype=np.float32)      # доки півотів немає
    spots = []
    for point in pivots:
        place = point.index
        if place >= count:
            break
        level = ema[place] if abs(ema[place]) > legs.EPS else legs.EPS
        move = np.abs(ema[place:] / level - 1.0)
        later = np.flatnonzero(move >= threshold)
        if not len(later):
            continue
        spots.append((place + int(later[0]), place))
    for confirm, place in sorted(spots):
        if confirm >= count:
            continue
        out[confirm:] = np.arange(confirm, count) - place
    return out


def leg_share(coin: dict) -> tuple:
    """Частка ноги на кожній події і маска подій усередині ніг.

    Та сама нарізка, що в `leg_deciles.cohorts`: подія на місці `i`
    всередині ноги довжини `L` пройшла `i / L` ноги.
    """
    count = len(coin["t"])
    share = np.full(count, np.nan, dtype=np.float32)
    for leg in coin["legs"]:
        first, last = int(leg["from"]), int(leg["to"])
        length = last - first + 1
        share[first:last + 1] = np.arange(length, dtype=np.float32) / length
    return share, np.isfinite(share)


def decile_of(share: np.ndarray, parts: int = DECILES) -> np.ndarray:
    """Десятина за часткою: 1 — перші 10 % подій ноги, 10 — останні."""
    return np.minimum(np.floor(np.asarray(share) * parts) + 1,
                      parts).astype(np.int16)


def coin_rows(coin: dict, board: dict) -> dict:
    """Числа кожної події монети: вікна, лічильник, клас і мітка."""
    ends = board["ends"]
    windows = []
    for look in LOOKS:
        found = dict(legs.context_of(coin["ema"], coin["pivots"], look))
        found["move"] = np.maximum(found["run"], found["draw"])
        windows.append(np.column_stack([found[name][ends]
                                        for name in leg_context.CONTEXT]))
    share, inside = leg_share(coin)
    return {"pair": coin["pair"], "ends": ends,
            "windows": np.hstack(windows).astype(np.float32),
            "elapsed": confirmed_elapsed(coin["ema"],
                                         coin["pivots"])[ends].reshape(-1, 1),
            "class": board["marks"][ends],
            "y": share[ends], "inside": inside[ends],
            "part": val_check.span_part(coin, ends, 0)}


def gather(rows: list) -> dict:
    """Події всіх монет одним потоком; поза ногами подій немає."""
    keep = [one["inside"] for one in rows]
    body = {"windows": np.vstack([one["windows"][mask]
                                  for one, mask in zip(rows, keep)]),
            "elapsed": np.vstack([one["elapsed"][mask]
                                  for one, mask in zip(rows, keep)]),
            "class": np.vstack([one["class"][mask]
                                for one, mask in zip(rows, keep)]),
            "y": np.concatenate([one["y"][mask]
                                 for one, mask in zip(rows, keep)]),
            "part": np.concatenate([one["part"][mask]
                                    for one, mask in zip(rows, keep)])}
    body["coin"] = np.concatenate(
        [np.full(int(mask.sum()), number, dtype=np.int16)
         for number, mask in enumerate(keep)])
    return body


def inputs(packs: dict, wide: bool, counter: bool, klass: bool) -> np.ndarray:
    """Матриця входів одного набору."""
    parts = []
    if wide:
        parts.append(packs["windows"])
    if counter:
        parts.append(packs["elapsed"])
    if klass:
        parts.append(packs["class"])
    return np.nan_to_num(np.hstack(parts), nan=0.0, posinf=0.0, neginf=0.0)


def fit_share(x: np.ndarray, y: np.ndarray, seed: int = SEED):
    from sklearn.ensemble import HistGradientBoostingRegressor

    model = HistGradientBoostingRegressor(
        max_iter=leg_context.MAX_ITER, learning_rate=leg_context.RATE,
        max_leaf_nodes=leg_context.LEAVES, random_state=seed)
    model.fit(x, y)
    return model


def honest_share(x: np.ndarray, y: np.ndarray, coin: np.ndarray,
                 seed: int = SEED) -> np.ndarray:
    """Оцінка кожної події моделлю, що її монети не бачила."""
    out = np.full(len(y), np.nan, dtype=np.float32)
    for number in np.unique(coin):
        away = coin == number
        model = fit_share(x[~away], y[~away], seed)
        out[away] = model.predict(x[away])
    return out


def measure_share(y: np.ndarray, said: np.ndarray) -> dict:
    """Наскільки оцінка близька до частки ноги.

    `mae` — середній модуль похибки за часткою; `similar` — частка подій,
    де сказана десятина промахнулась не більше ніж на одну; `auc_last` —
    чи ставить оцінка подію останньої десятини вище за решту.
    """
    from sklearn.metrics import roc_auc_score

    said = np.clip(said, 0.0, 1.0)
    last = (y >= 0.9).astype(np.int8)
    body = {"mae": legs.cell(float(np.mean(np.abs(said - y)))),
            "similar": legs.cell(float(np.mean(
                np.abs(decile_of(said).astype(int)
                       - decile_of(y).astype(int)) <= 1))),
            "events": int(len(y))}
    body["auc_last"] = (legs.cell(float(roc_auc_score(last, said)))
                        if 0 < last.sum() < len(last) else None)
    return body


def share_part(packs: dict, sets=SETS, seed: int = SEED, log=print) -> dict:
    """Частина 1: оцінювач повноти ноги на кожному наборі входів."""
    train = packs["part"] == "train"
    val = packs["part"] == "val"
    body = {"train": {"events": int(train.sum())},
            "val": {"events": int(val.sum())}, "sets": [],
            "constant": measure_share(packs["y"][val],
                                      np.full(int(val.sum()), 0.5))}
    for name, wide, counter, klass in sets:
        started = time.time()
        x = inputs(packs, wide, counter, klass)
        honest = np.full(len(x), np.nan, dtype=np.float32)
        honest[train] = honest_share(x[train], packs["y"][train],
                                     packs["coin"][train], seed)
        model = fit_share(x[train], packs["y"][train], seed)
        said = model.predict(x).astype(np.float32)
        found = {"set": name, "columns": int(x.shape[1]),
                 "train": measure_share(packs["y"][train], honest[train]),
                 "val": measure_share(packs["y"][val], said[val]),
                 "seconds": round(time.time() - started, 1)}
        body["sets"].append(found)
        log(f"      {name:<18}: train MAE {found['train']['mae']}, val MAE "
            f"{found['val']['mae']}, схожість {found['val']['similar']}, "
            f"AUC останньої {found['val']['auc_last']} — "
            f"{found['seconds']} с")
    return body


def share_by_event(coins: list, rows: list, packs: dict, name: str,
                   seed: int = SEED) -> list:
    """Оцінена частка ноги на **кожній** події ряду кожної монети.

    Модель навчена на train усіх монет; поза ногами оцінки немає — там,
    де зігзаг ще не почав ногу, питати нема про що.
    """
    found = [one for one in SETS if one[0] == name][0]
    train = packs["part"] == "train"
    x = inputs(packs, *found[1:])
    model = fit_share(x[train], packs["y"][train], seed)
    out = []
    for coin, one in zip(coins, rows):
        line = np.full(len(coin["t"]), np.nan, dtype=np.float32)
        here = one["inside"]
        if here.any():
            block = inputs({"windows": one["windows"][here],
                            "elapsed": one["elapsed"][here],
                            "class": one["class"][here]}, *found[1:])
            line[one["ends"][here]] = np.clip(model.predict(block), 0.0, 1.0)
        out.append(line)
    return out


def rung_rows(coins: list, boards: list, lag: int) -> dict:
    """Приклади драбини на щаблі `lag`, як у дослідженні 24."""
    rows, parts = [], []
    for coin, board in zip(coins, boards):
        found = pivot_delay.lag_rows(board, lag)
        rows.append(found)
        parts.append(val_check.span_part(coin, found["ends"], lag))
    packs = {"coin": np.concatenate(
                 [np.full(len(one["y"]), number, dtype=np.int16)
                  for number, one in enumerate(rows)]),
             "marks": np.vstack([one["marks"] for one in rows]),
             "context": {look: np.vstack([one["context"][look]
                                          for one in rows])
                         for look in rows[0]["context"]},
             "y": np.concatenate([one["y"] for one in rows]),
             "part": np.concatenate(parts),
             "ends": np.concatenate([one["ends"] for one in rows])}
    return {"rows": rows, "packs": packs}


def rung_score(packs: dict, name: str = SIGNAL_SET,
               seed: int = SEED) -> tuple:
    """Сигнал драбини на val і поріг із чесних оцінок train."""
    _, wide, looks = [one for one in pivot_delay.SETS if one[0] == name][0]
    columns = [packs["context"][look] for look in looks]
    if wide:
        columns.insert(0, packs["marks"])
    x = np.nan_to_num(np.hstack(columns), nan=0.0, posinf=0.0, neginf=0.0)
    train = packs["part"] == "train"
    model = val_check.fit(x[train], packs["y"][train], seed)
    score = model.predict_proba(x)[:, 1]
    honest = leg_context.out_of_coin(x[train], packs["y"][train],
                                     packs["coin"][train], seed)
    edge = float(np.quantile(honest[packs["y"][train] == 1], 1.0 - RECALL))
    return score, edge


def gate_curve(y: np.ndarray, fired: np.ndarray, share: np.ndarray,
               days: float, grid=GRID) -> list:
    """Що робить фільтр на кожному порозі повноти ноги.

    Поріг `0` — це рядок **без фільтра**: проходить усе, що вистрелило,
    навіть сигнал у подію поза ногами, де частки немає зовсім.
    """
    out = []
    line = np.nan_to_num(share, nan=-1.0)   # поза ногою частки немає
    for gate in grid:
        keep = fired if gate <= 0 else fired & (line >= gate)
        taken = int((keep & (y == 1)).sum())
        false = int((keep & (y == 0)).sum())
        out.append({"gate": legs.cell(gate), "taken": taken, "false": false,
                    "precision": legs.cell(taken / max(taken + false, 1)),
                    "recall": legs.cell(taken / max(int((y == 1).sum()), 1)),
                    "cut_false": int((fired & (y == 0)).sum()) - false,
                    "cut_hit": int((fired & (y == 1)).sum()) - taken,
                    "per_day": legs.cell((taken + false) / max(days, legs.EPS))})
    return out


def one_rung(coins: list, found: dict, score: np.ndarray, edge: float,
             lag: int, share: list, log=print) -> dict:
    """Частина 2: фільтр на одному щаблі драбини.

    `score` — сигнал драбини на кожному прикладі, `edge` — його поріг із
    чесних оцінок train. Фільтр дивиться на частку ноги **тієї події,
    куди сигнал показує**, тобто на `e − N`.
    """
    packs = found["packs"]
    val = packs["part"] == "val"
    days = int(val.sum()) * legs.EVENT_LENGTH / 86400
    said, real = [], []
    for number, (coin, one) in enumerate(zip(coins, found["rows"])):
        spot = np.clip(one["ends"] - lag, 0, len(coin["t"]) - 1)
        said.append(share[number][spot])
        real.append(leg_share(coin)[0][spot])
    said = np.concatenate(said)
    real = np.concatenate(real)
    fired = (score >= edge) & val
    body = {"lag": lag, "minutes": round(lag * legs.EVENT_LENGTH / 60, 1),
            "edge": legs.cell(edge), "set": SIGNAL_SET,
            "val": {"packs": int(val.sum()),
                    "reversal": int(packs["y"][val].sum()),
                    "days": legs.cell(days)},
            "said": gate_curve(packs["y"][val], fired[val], said[val], days),
            "real": gate_curve(packs["y"][val], fired[val], real[val], days)}
    base, top = body["said"][0], body["said"][-1]
    log(f"      N {lag:>3}: без фільтра {base['precision']} "
        f"({base['taken']} з {body['val']['reversal']}, хибних "
        f"{base['false']}); поріг {top['gate']} — {top['precision']} "
        f"({top['taken']}, хибних {top['false']})")
    return body


def rung_panel(coins: list, found: dict, score: np.ndarray, lag: int,
               share: list) -> list:
    """Сигнал драбини й обидві частки ноги — по кожній монеті окремо.

    Мітки в плашці рахуються з цього порогом сигналу й порогом фільтра,
    які рухають руками, тому готових смуг тут немає.
    """
    out, place = [], 0
    val = found["packs"]["part"] == "val"
    for number, (coin, one) in enumerate(zip(coins, found["rows"])):
        count = len(one["y"])
        block = slice(place, place + count)
        place += count
        here = val[block]
        spot = np.clip(one["ends"] - lag, 0, len(coin["t"]) - 1)
        kind = np.where(one["y"] == 1, legs.PIVOT, legs.PLAIN)
        kind = np.where(here, kind, legs.NO_COUNT).astype(np.int8)
        out.append({"pair": coin["pair"], "ends": one["ends"],
                    "value": score[block], "kind": kind,
                    "said": share[number][spot],
                    "real": leg_share(coin)[0][spot]})
    return out


def gate_counts(kind, score, gate_line, edge: float, gate: float) -> dict:
    """Мітки на порозі сигналу `edge` і порозі фільтра `gate`.

    Та сама арифметика, що в плашці дашборду, де обидва пороги рухають
    рукою; тут вона потрібна, щоб числа за замовчуванням у файлі
    збігалися з намальованими.
    """
    out = {name: 0 for name in MARKS}
    for one, value, share in zip(kind, score, gate_line):
        if one is None or one == legs.NO_COUNT:
            continue
        fired = value is not None and value >= edge
        if not fired:
            out["miss"] += one == legs.PIVOT
            continue
        kept = share is not None and share >= gate
        if one == legs.PIVOT:
            out["hit" if kept else "cuthit"] += 1
        else:
            out["false" if kept else "cutfalse"] += 1
    return {name: int(value) for name, value in out.items()}


def coin_series(coin: dict, share: np.ndarray, panel: dict, edge: float,
                lag: int, gate: float = PANEL_GATE) -> dict:
    """Ряд val однієї монети: ціна, дві частки ноги й сигнал драбини."""
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return {"pair": coin["pair"], "events": 0, "ready": False}
    low, high = int(inside[0]), int(inside[-1])
    index = np.arange(low, high + 1)
    spot = {value: number for number, value in enumerate(index)}
    real = leg_share(coin)[0]

    def cell(values):
        return [None if not np.isfinite(one) else round(float(one), 4)
                for one in values]

    body = {"pair": coin["pair"], "ready": True, "events": int(len(index)),
            "from_utc": legs.leg_deciles.utc(coin["t"][low]),
            "to_utc": legs.leg_deciles.utc(coin["t"][high]),
            "t": coin["t"][index].astype(int).tolist(),
            "price": [round(float(one), 6) for one in coin["ema"][index]],
            "period": legs.PERIOD, "threshold": legs.THRESHOLD,
            "event_seconds": legs.EVENT_LENGTH, "lag": lag,
            "edge": legs.cell(edge), "gate": legs.cell(gate),
            "share_set": SHARE_SET, "signal_set": SIGNAL_SET,
            "pivots": [{"t": int(coin["t"][point.index]),
                        "ema": round(float(coin["ema"][point.index]), 6),
                        "kind": point.kind}
                       for point in coin["pivots"]
                       if low <= point.index <= high],
            "real": cell(real[index]), "said": cell(share[index])}
    score = [None] * len(index)
    kind = [legs.NO_COUNT] * len(index)
    said = [None] * len(index)
    truth = [None] * len(index)
    for end, value, mark, one, two in zip(panel["ends"], panel["value"],
                                          panel["kind"], panel["said"],
                                          panel["real"]):
        if end not in spot:
            continue
        number = spot[end]
        score[number] = round(float(value), 4)
        kind[number] = int(mark)
        said[number] = None if not np.isfinite(one) else round(float(one), 4)
        truth[number] = None if not np.isfinite(two) else round(float(two), 4)
    body.update({"score": score, "kind": kind, "gate_said": said,
                 "gate_real": truth,
                 "counts": gate_counts(kind, score, said, edge, gate)})
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lags", type=int, nargs="+", default=list(LAGS))
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    boards = [pivot_delay.coin_board(coin, part="all") for coin in coins]
    rows = [coin_rows(coin, board) for coin, board in zip(coins, boards)]
    packs = gather(rows)
    print(f"      подій усередині ніг: train "
          f"{int((packs['part'] == 'train').sum())}, val "
          f"{int((packs['part'] == 'val').sum())}")

    print("[повнота ноги]")
    part_one = share_part(packs, seed=args.seed)
    share = share_by_event(coins, rows, packs, SHARE_SET, args.seed)

    print("[фільтр]")
    rungs, panels = [], {}
    for lag in args.lags:
        found = rung_rows(coins, boards, lag)
        score, edge = rung_score(found["packs"], seed=args.seed)
        rungs.append(one_rung(coins, found, score, edge, lag, share))
        if lag == PANEL_LAG:
            panels = {one["pair"]: one
                      for one in rung_panel(coins, found, score, lag, share)}

    args.out.mkdir(parents=True, exist_ok=True)
    print("[плашки монет]")
    for coin, line in zip(coins, share):
        panel = panels.get(coin["pair"])
        if panel is None:
            continue
        body = coin_series(coin, line, panel,
                           [one for one in rungs
                            if one["lag"] == PANEL_LAG][0]["edge"], PANEL_LAG)
        body.update({"script": "research/26-leg-share-filter/scripts/"
                               "leg_share.py",
                     "cut_utc": f"{CUT} 00:00:00",
                     "end_utc": f"{END} 00:00:00", "marks": list(MARKS)})
        (args.out / f"share_{coin['pair']}.json").write_text(
            json.dumps(body, ensure_ascii=False), encoding="utf-8")
        print(f"      {coin['pair']}: подій {body['events']}, півотів "
              f"{len(body['pivots'])} — {body['counts']}")

    (args.out / "leg_share.json").write_text(json.dumps({
        "script": "research/26-leg-share-filter/scripts/leg_share.py",
        "command": "python3 research/26-leg-share-filter/scripts/leg_share.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "lags": list(args.lags),
        "sets": [name for name, _, _, _ in SETS], "looks": list(LOOKS),
        "grid": list(GRID), "deciles": DECILES, "recall": RECALL,
        "signal_set": SIGNAL_SET, "share_set": SHARE_SET,
        "panel_lag": PANEL_LAG, "panel_gate": PANEL_GATE,
        "size": legs.SIZE, "lead": legs.LEAD, "tail": legs.TAIL,
        "look": legs.LOOK, "seed": args.seed,
        "max_iter": leg_context.MAX_ITER, "leaves": leg_context.LEAVES,
        "rate": leg_context.RATE,
        "context_names": list(leg_context.CONTEXT),
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "marks": list(MARKS),
        "share": part_one, "rungs": rungs, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/leg_share.json")


if __name__ == "__main__":
    main()
