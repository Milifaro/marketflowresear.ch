"""Грід ручок мережі з памʼяттю на повноту ноги.

Дослідження: research/26-leg-share-filter/
Правила: rules/03-models.md → Навчання моделей

Етап 2 узяв ручки на око: `LENGTH = 250`, `HIDDEN = 96`, один шар,
`rate = 1e-3`. Етап 4 показав, що функція втрат нічого не міняє, — отже
питати треба саму мережу. Тут перебираються її ручки, історія подвоєна
до **5000 подій**, і памʼять вікна val дістає з train
([`share_lstm.py`](share_lstm.py) → `windows_of`).

## Ручки

| Ручка | Значення | Про що |
| ----- | -------- | ------ |
| `крок` | `(250, 20)`, `(500, 10)` | ті самі 5000 подій: рідше й довше проти частіше й коротше |
| `hidden` | 64, 96, 160 | ширина стану |
| `layers` | 1, 2 | глибина |
| `rate` | 1e-3, 3e-4 | крок навчання |

Разом 24 точки. Кожна вчиться `EPOCHS` епох, і в точки береться її
краща епоха за **`MAE` хвоста train** — правило етапу 4.

## Вибір

Точка обирається за **хвостом train**, не за val: val тут для показу.
Але одна точка — це 1722 вікна хвоста, і її `MAE` шумить. Тому ручки
беруться по **маргінальних середніх**: для кожного значення ручки
береться середній `MAE` хвоста по всіх точках, де вона так стоїть, і
перемагає значення з найменшим. Так за кожним числом стоїть вісім-
дванадцять прогонів, а не один.

Найкраща **одна** точка хвоста лишається у файлі окремо (`by_point`),
як і найкраща за val (`by_val`) — щоб розбіжність між правилами було
видно.

## Контроль на старій памʼяті

Щоб побачити, що дало саме подвоєння історії, у той самий файл доливається
точка зі старим вікном `250 × 10` і ручками етапу 2:

    python3 research/26-leg-share-filter/scripts/grid_share.py \
        --windows 250x10 --hidden 96 --layers 1 --rates 0.001 --append

Вона міряється на тому самому повному val, що й решта гріду, тому числа
порівнянні.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/grid_share.json — числа кожної точки гріду

Запуск:
    python3 research/26-leg-share-filter/scripts/grid_share.py
    python3 research/26-leg-share-filter/scripts/grid_share.py --epochs 2
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "23-reversal-signal"
                       / "scripts"))

import signal_data as legs  # noqa: E402
import leg_share  # noqa: E402
import share_lstm as memory  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
SET = "вікна+елапс"
EPOCHS = 3
WINDOWS = ((250, 20), (500, 10))     # (кроків, подій між кроками)
HIDDEN = (64, 96, 160)
LAYERS = (1, 2)
RATES = (1e-3, 3e-4)


def points(windows=WINDOWS, hidden=HIDDEN, layers=LAYERS,
           rates=RATES) -> list:
    """Усі точки гріду, згруповані за вікном: стан будується раз на вікно."""
    out = []
    for length, step in windows:
        for wide in hidden:
            for deep in layers:
                for rate in rates:
                    out.append({"length": length, "step": step,
                                "memory": length * step, "hidden": wide,
                                "layers": deep, "rate": rate})
    return out


KNOBS = ("window", "hidden", "layers", "rate")


def knob_of(row: dict, name: str):
    return (row["length"], row["step"]) if name == "window" else row[name]


def marginals(rows: list) -> dict:
    """Середнє по кожному значенню ручки — і на хвості, і на val.

    Одна точка гріду — це 1722 вікна хвоста, і її `MAE` шумить. Середнє
    по всіх точках, де ручка стоїть у цьому значенні, спирається на
    вісім-дванадцять прогонів і тому стійкіше.
    """
    out = {}
    for name in KNOBS:
        body = []
        for value in sorted({knob_of(one, name) for one in rows}):
            here = [one["best"] for one in rows
                    if knob_of(one, name) == value]
            body.append({
                "value": list(value) if isinstance(value, tuple) else value,
                "points": len(here),
                "хвіст_mae": legs.cell(float(np.mean(
                    [one["хвіст"]["mae"] for one in here]))),
                "val_mae": legs.cell(float(np.mean(
                    [one["val"]["mae"] for one in here]))),
                "val_auc": legs.cell(float(np.mean(
                    [one["val"]["auc_last"] for one in here])))})
        out[name] = body
    return out


def pick_by_marginals(rows: list, found: dict) -> dict:
    """Точка, зібрана з найкращих значень кожної ручки за хвостом.

    Якщо такої точки в гріді немає, береться найближча: та, що збігається
    з нею в найбільшій кількості ручок, а за рівності — з меншим `MAE`
    хвоста.
    """
    want = {name: min(found[name], key=lambda one: one["хвіст_mae"])["value"]
            for name in KNOBS}
    def same(row):
        return sum(knob_of(row, name) == (tuple(want[name])
                                          if name == "window" else want[name])
                   for name in KNOBS)
    return max(rows, key=lambda one: (same(one), -one["best"]["хвіст"]["mae"]))


def train_point(state: dict, point: dict, epochs: int = EPOCHS,
                seed: int = legs.SEED, log=print) -> dict:
    """Одна точка гріду: навчання й числа після кожної епохи."""
    import torch
    from torch import nn

    device = memory.device_of()
    width = memory.width_of(state["coins"][0]["channels"], SET)
    model = memory.build(width, hidden=point["hidden"],
                         layers=point["layers"], seed=seed).to(device)
    loss = nn.L1Loss()
    tune = torch.optim.Adam(model.parameters(), lr=point["rate"])
    fit = memory.rows_of(state, "train")
    look = {"хвіст": memory.rows_of(state, "хвіст", thin=False),
            "val": memory.rows_of(state, "val", thin=False)}
    history, started = [], time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        total, seen = 0.0, 0
        for x, y in memory.batches(state, SET, fit, shuffle=True,
                                   seed=seed + epoch):
            found = torch.sigmoid(model(torch.from_numpy(x).to(device)))
            step = loss(found, torch.from_numpy(y).to(device))
            tune.zero_grad()
            step.backward()
            tune.step()
            total += float(step.detach()) * len(y)
            seen += len(y)
        row = {"epoch": epoch, "loss": legs.cell(total / max(seen, 1))}
        for key, rows in look.items():
            said, want = memory.predict(model, state, SET, rows, device)
            row[key] = leg_share.measure_share(want, said)
        history.append(row)
        log(f"      {point['length']}×{point['step']} h{point['hidden']} "
            f"l{point['layers']} r{point['rate']:g} епоха {epoch}: хвіст MAE "
            f"{row['хвіст']['mae']}, val MAE {row['val']['mae']}, val AUC "
            f"{row['val']['auc_last']}")
    best = min(history, key=lambda one: one["хвіст"]["mae"])
    return {"history": history, "best": best,
            "parameters": int(sum(one.numel() for one in model.parameters())),
            "device": str(device), "seconds": round(time.time() - started, 1)}


def window_of(text: str) -> tuple:
    """`250x20` -> (250, 20)."""
    length, step = text.lower().split("x")
    return int(length), int(step)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--windows", nargs="+", type=window_of,
                        default=list(WINDOWS))
    parser.add_argument("--hidden", nargs="+", type=int, default=list(HIDDEN))
    parser.add_argument("--layers", nargs="+", type=int, default=list(LAYERS))
    parser.add_argument("--rates", nargs="+", type=float, default=list(RATES))
    parser.add_argument("--append", action="store_true",
                        help="долити точки в готовий grid_share.json")
    parser.add_argument("--repick", action="store_true",
                        help="лише перерахувати вибір за готовими точками")
    parser.add_argument("--seed", type=int, default=legs.SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    if args.repick:
        args.windows, args.append = [], True

    coins = []
    if args.windows:
        print("[монети]")
        coins = legs.collect(args.data)

    rows = []
    if args.append:
        path = args.out / "grid_share.json"
        if path.exists():
            rows = json.loads(path.read_text(encoding="utf-8"))["rows"]
    grid = points(args.windows, args.hidden, args.layers, args.rates)
    for length, step in args.windows:
        print(f"[вікно {length}×{step} = {length * step} подій]")
        state = memory.collect(coins, length, step, log=print)
        for point in [one for one in grid
                      if one["length"] == length and one["step"] == step]:
            got = train_point(state, point, args.epochs, seed=args.seed)
            rows.append(dict(point, **{
                "parameters": got["parameters"], "device": got["device"],
                "seconds": got["seconds"], "history": got["history"],
                "best": got["best"]}))

    found = marginals(rows)
    picked = pick_by_marginals(rows, found)
    by_point = min(rows, key=lambda one: one["best"]["хвіст"]["mae"])
    by_val = max(rows, key=lambda one: one["best"]["val"]["auc_last"])
    print("[вибір]")
    print(f"      одна точка хвоста: {by_point['length']}×{by_point['step']}, "
          f"hidden {by_point['hidden']}, шарів {by_point['layers']}, rate "
          f"{by_point['rate']:g} — хвіст MAE "
          f"{by_point['best']['хвіст']['mae']}, val AUC "
          f"{by_point['best']['val']['auc_last']}")
    print(f"      маргінали:  {picked['length']}×{picked['step']}, "
          f"hidden {picked['hidden']}, шарів {picked['layers']}, rate "
          f"{picked['rate']:g} — хвіст MAE {picked['best']['хвіст']['mae']}, "
          f"val AUC {picked['best']['val']['auc_last']}")
    print(f"      за val:     {by_val['length']}×{by_val['step']}, "
          f"hidden {by_val['hidden']}, шарів {by_val['layers']}, rate "
          f"{by_val['rate']:g} — val AUC {by_val['best']['val']['auc_last']}")

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "grid_share.json").write_text(json.dumps({
        "script": "research/26-leg-share-filter/scripts/grid_share.py",
        "command": "python3 research/26-leg-share-filter/scripts/"
                   "grid_share.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "set": SET, "epochs": args.epochs, "seed": args.seed,
        "epoch_by": "MAE хвоста train",
        "picked_by": "маргінальні середні MAE хвоста train",
        "marginals": found,
        "by_point": {key: by_point[key] for key in
                     ("length", "step", "memory", "hidden", "layers",
                      "rate")},
        "windows": sorted({(one["length"], one["step"]) for one in rows}),
        "hidden": sorted({one["hidden"] for one in rows}),
        "layers": sorted({one["layers"] for one in rows}),
        "rates": sorted({one["rate"] for one in rows}),
        "every": memory.EVERY, "dropout": memory.DROPOUT,
        "batch": memory.BATCH, "inner_days": memory.INNER,
        "scaler": "quantile", "loss": "L1",
        "picked": {key: picked[key] for key in
                   ("length", "step", "memory", "hidden", "layers", "rate")},
        "by_val": {key: by_val[key] for key in
                   ("length", "step", "memory", "hidden", "layers", "rate")},
        "constant": {"mae": 0.2484, "auc_last": 0.5},
        "cut_utc": f"{legs.CUT} 00:00:00", "end_utc": f"{legs.END} 00:00:00",
        "pairs": list(legs.PAIRS), "event_seconds": legs.EVENT_LENGTH,
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/grid_share.json")


if __name__ == "__main__":
    main()
