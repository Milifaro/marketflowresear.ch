"""Два сигнали разом: драбина щабля `N` і мережа констатації розвороту.

Дослідження: research/26-leg-share-filter/
Правила: rules/03-models.md → Навчання моделей

Драбина дослідження 23 питає «півот був `N` подій тому» і показує на
подію `c = e − N`. Мережа дослідження 25 питає те саме на щаблі `N = 3`,
тобто **констатує** розворот майже одразу після нього. Для одного й того
самого півота `c` вона висловлюється на події `c + 3`, а драбина — на
події `c + N`. Обидва голоси про той самий момент, і другий приходить
пізніше, тому підтвердження першим **не заглядає в майбутнє**.

## Правило разом

Сигнал драбини на події `e` приймається, лише коли мережа десь у вікні
`±W` навколо `c + 3` теж піднялась вище свого порога:

    брати(e) = драбина(e) ≥ край  і  max мережа[c + 3 − W … c + 3 + W] ≥ поріг

Вікно `W` обмежене причинністю: `c + 3 + W ≤ e`, тобто `W ≤ N − 3`.

## Мережа

Береться найкращий набір дослідження 25 за `AP` на val
([`lstm_pivot.py`](../../25-leg-lstm/scripts/lstm_pivot.py)). Його видача
на кожній події val уже збережена в `results/lstm_<PAIR>.json`, тому
мережа тут не перенавчається — читається готовий ряд.

Вхід : research/25-leg-lstm/results/lstm_<PAIR>.json — ряд мережі
       data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/two_signals.json  — числа обох сигналів разом
       results/two_<PAIR>.json   — ряд мережі під ряд вкладки

Запуск:
    python3 research/26-leg-share-filter/scripts/two_signals.py
    python3 research/26-leg-share-filter/scripts/two_signals.py --lags 43
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "23-reversal-signal"
                       / "scripts"))

import signal_data as legs  # noqa: E402
import pivot_delay  # noqa: E402
import leg_share  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
NET_DIR = PROJECT_ROOT / "research" / "25-leg-lstm" / "results"
NET_LAG = 3                       # щабель мережі дослідження 25
WINDOWS = (0, 5, 10, 20, 40)      # ± подій навколо `c + NET_LAG`
EDGES = (0.0, 0.5, 0.8, 0.9, 0.95, 0.99)
PANEL_WINDOW = 20                 # вікно, з яким малюється плашка


def relative(path: Path) -> str:
    """Шлях від кореня проєкту, якщо він там; інакше — як є."""
    try:
        return str(path.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def pick_net(root: Path = NET_DIR) -> dict:
    """Найкращий набір мережі дослідження 25: більший `AP` на val."""
    path = root / "lstm_pivot.json"
    body = json.loads(path.read_text(encoding="utf-8"))
    best = max(body["rows"], key=lambda one: one["best"]["val"]["ap"])
    return {"set": best["set"], "edge": float(best["marks"]["edge"]),
            "lag": int(body["lag"]), "length": int(body["length"]),
            "val": best["best"]["val"], "sets": list(body["sets"]),
            "source": relative(path)}


def net_lines(coins: list, name: str, root: Path = NET_DIR) -> list:
    """Видача мережі на кожній події монети, `NaN` поза її рядом val."""
    out = []
    for coin in coins:
        line = np.full(len(coin["t"]), np.nan, dtype=np.float64)
        path = root / f"lstm_{coin['pair']}.json"
        if path.exists():
            body = json.loads(path.read_text(encoding="utf-8"))
            found = body["sets"].get(name)
            if found is not None:
                place = np.searchsorted(coin["t"], np.array(body["t"]))
                place = np.clip(place, 0, len(coin["t"]) - 1)
                good = coin["t"][place] == np.array(body["t"])
                value = np.array([np.nan if one is None else one
                                  for one in found["score"]], dtype=np.float64)
                line[place[good]] = value[good]
        out.append(line)
    return out


def said_before(line: np.ndarray, spot: np.ndarray, window: int,
                lag: int = NET_LAG) -> np.ndarray:
    """Найгучніше слово мережі у вікні `±window` навколо `spot + lag`.

    Вікно обрізається праворуч подією `spot + lag + window`, і викликати
    це з `window > N − lag` не можна: тоді вікно зайде в майбутнє.
    """
    out = np.full(len(spot), np.nan, dtype=np.float64)
    count = len(line)
    for number, place in enumerate(spot):
        low = max(int(place) + lag - window, 0)
        high = min(int(place) + lag + window + 1, count)
        if low >= high:
            continue
        piece = line[low:high]
        piece = piece[np.isfinite(piece)]
        if len(piece):
            out[number] = piece.max()
    return out


def pair_rows(y: np.ndarray, fired: np.ndarray, said: np.ndarray,
              days: float, grid=EDGES) -> list:
    """Що дає підтвердження мережею на кожному її порозі."""
    line = np.nan_to_num(said, nan=-1.0)     # мережа не сказала нічого
    out = []
    for edge in grid:
        keep = fired if edge <= 0 else fired & (line >= edge)
        taken = int((keep & (y == 1)).sum())
        false = int((keep & (y == 0)).sum())
        out.append({"edge": legs.cell(edge), "taken": taken, "false": false,
                    "precision": legs.cell(taken / max(taken + false, 1)),
                    "recall": legs.cell(taken / max(int((y == 1).sum()), 1)),
                    "cut_false": int((fired & (y == 0)).sum()) - false,
                    "cut_hit": int((fired & (y == 1)).sum()) - taken,
                    "per_day": legs.cell((taken + false)
                                         / max(days, legs.EPS))})
    return out


def one_rung(coins: list, found: dict, score: np.ndarray, edge: float,
             lag: int, lines: list, windows=WINDOWS, log=print) -> dict:
    """Один щабель драбини під підтвердженням мережі, вікно за вікном."""
    packs = found["packs"]
    val = packs["part"] == "val"
    days = int(val.sum()) * legs.EVENT_LENGTH / 86400
    fired = (score >= edge) & val
    body = {"lag": lag, "minutes": round(lag * legs.EVENT_LENGTH / 60, 1),
            "edge": legs.cell(edge), "set": leg_share.SIGNAL_SET,
            "val": {"packs": int(val.sum()),
                    "reversal": int(packs["y"][val].sum()),
                    "days": legs.cell(days)},
            "windows": []}
    for window in windows:
        if window > lag - NET_LAG:          # вікно зайшло б у майбутнє
            continue
        said = np.concatenate(
            [said_before(lines[number], np.clip(one["ends"] - lag, 0,
                                                len(coins[number]["t"]) - 1),
                         window)
             for number, one in enumerate(found["rows"])])
        rows = pair_rows(packs["y"][val], fired[val], said[val], days)
        body["windows"].append({"window": window, "rows": rows})
        base, top = rows[0], rows[3]
        log(f"      N {lag:>3} вікно ±{window:>2}: без мережі "
            f"{base['precision']} ({base['taken']} з "
            f"{body['val']['reversal']}, хибних {base['false']}); поріг "
            f"{top['edge']} — {top['precision']} ({top['taken']}, хибних "
            f"{top['false']})")
    return body


def coin_net(coin: dict, line: np.ndarray, edge: float, name: str,
             window: int = PANEL_WINDOW) -> dict:
    """Ряд мережі під ряд вкладки: ті самі події, що у `leg_share`."""
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return {"pair": coin["pair"], "events": 0, "ready": False}
    index = np.arange(int(inside[0]), int(inside[-1]) + 1)
    return {"pair": coin["pair"], "ready": True, "events": int(len(index)),
            "t": coin["t"][index].astype(int).tolist(),
            "net": [None if not np.isfinite(one) else round(float(one), 4)
                    for one in line[index]],
            "net_edge": legs.cell(edge), "net_set": name,
            "net_lag": NET_LAG, "net_window": window}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lags", type=int, nargs="+",
                        default=list(leg_share.LAGS))
    parser.add_argument("--seed", type=int, default=leg_share.SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--net", type=Path, default=NET_DIR)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[мережа]")
    net = pick_net(args.net)
    print(f"      набір {net['set']}, поріг {net['edge']}, val AUC "
          f"{net['val']['auc']}, AP {net['val']['ap']}")
    print("[монети]")
    coins = legs.collect(args.data)
    boards = [pivot_delay.coin_board(coin, part="all") for coin in coins]
    lines = net_lines(coins, net["set"], args.net)
    for coin, line in zip(coins, lines):
        print(f"      {coin['pair']}: подій мережі "
              f"{int(np.isfinite(line).sum())}")

    print("[разом]")
    rungs = []
    for lag in args.lags:
        found = leg_share.rung_rows(coins, boards, lag)
        score, edge = leg_share.rung_score(found["packs"], seed=args.seed)
        rungs.append(one_rung(coins, found, score, edge, lag, lines))

    args.out.mkdir(parents=True, exist_ok=True)
    for coin, line in zip(coins, lines):
        body = coin_net(coin, line, net["edge"], net["set"])
        path = args.out / f"two_{coin['pair']}.json"
        path.write_text(json.dumps(body, ensure_ascii=False), encoding="utf-8")
    body = {"script": "research/26-leg-share-filter/scripts/two_signals.py",
            "command": "python3 research/26-leg-share-filter/scripts/"
                       "two_signals.py",
            "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
            "net": net, "net_lag": NET_LAG, "windows": list(WINDOWS),
            "grid": list(EDGES), "panel_window": PANEL_WINDOW,
            "signal_set": leg_share.SIGNAL_SET, "recall": leg_share.RECALL,
            "cut_utc": legs.CUT, "end_utc": legs.END,
            "pairs": list(legs.PAIRS), "threshold": legs.THRESHOLD,
            "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
            "rungs": rungs, "ready": True}
    path = args.out / "two_signals.json"
    path.write_text(json.dumps(body, ensure_ascii=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
