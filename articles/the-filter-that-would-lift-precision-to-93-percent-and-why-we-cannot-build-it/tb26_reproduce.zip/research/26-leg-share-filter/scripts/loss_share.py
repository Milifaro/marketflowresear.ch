"""Функція втрат для частки ноги: перебір варіантів на тій самій мережі.

Дослідження: research/26-leg-share-filter/
Правила: rules/03-models.md → Навчання моделей

Етап 2 навчав мережу під `L1` і видача вийшла **стиснутою**: розмах
0.186 проти 0.294 у мітки, від першої десятини до останньої середнє
проходить лише 0.38 → 0.59. `L1` тягне до умовної медіани, а мітка
всередині ноги майже рівномірна — медіана й виявляється серединою.

Тут та сама мережа, ті самі канали, розбиття й seed, міняється **тільки
функція втрат**. Ручки — етапу 2 (`250 × 10`, `hidden 96`, один шар,
`rate = 1e-3`): перебір робився на них і лишається на них, щоб числа
відтворювались після того, як грід
([`grid_share.py`](grid_share.py)) поміняв ручки основної мережі. Питання одне: чи можна нею дістати те, що потрібно
фільтру, — порядок подій за близькістю до кінця ноги (`AUC` останньої
десятини).

## Що перебирається

| Втрата | Голів | Ідея |
| ------ | ----: | ---- |
| `L1` | 1 | базова: умовна медіана |
| `MSE` | 1 | умовне середнє |
| `Huber` | 1 | між ними, `δ = 0.2` |
| `десятини` | 10 | розподіл по десятинах, видача — очікувана десятина |
| `сходинки` | 9 | порядкові голови «частка ≥ k/10», видача — середнє |
| `ранг` | 1 | пари всередині пачки: хто ближче до кінця ноги |
| `сходинки+ранг` | 9 | порядок і пороги разом |
| `край` | 1 | своя: `L1` з вагою на краях ноги |
| `розмах` | 1 | своя: `L1` зі штрафом за стиснуту видачу |
| `край+ранг` | 1 | своя: вага краю плюс пари |

**`край`** — вага росте до обох кінців ноги:

    w(y) = 1 + A · |2y − 1| ^ P,   A = 3, P = 2

Середина ноги коштує 1, самий край — 4. Це відповідь на те, що фільтру
потрібні саме краї, а `L1` рівно платить за всі десятини.

**`розмах`** — до `L1` додається штраф за те, що видача вужча за мітку:

    втрата = L1 + λ · relu( std(y) − std(ŝ) ),   λ = 1

Стиснення міряється в тій самій пачці, тому штраф не дає мережі сховатись
у середині.

**`ранг`** — усі пари пачки, де мітки різняться більше ніж на `MARGIN`:

    втрата = BCE( ŝᵢ − ŝⱼ,  [yᵢ > yⱼ] )

Це прямо та величина, яку міряє `AUC`, і вона не залежить від шкали.

## Вибір епохи

Епоха береться за **`MAE` хвоста train**, як в етапі 2. Правило «епоха за
`AUC` хвоста» перевірено й відкинуте: хвіст — це 1722 вікна, його `AUC`
скаче, і воно раз за разом обирає пізні епохи, гірші на val на 0.05–0.14.
Обидва числа лишаються у файлі, щоб це було видно.

## Калібрування

Разом із сирою видачею кожна втрата міряється **після калібрування**:
видача val переганяється через свій розподіл на train у розподіл мітки
на train. Це монотонне перетворення — `AUC` від нього не міняється, а
`MAE` показує, скільки з похибки було просто стисненням шкали.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/loss_share.json — числа кожної втрати по епохах

Запуск:
    python3 research/26-leg-share-filter/scripts/loss_share.py
    python3 research/26-leg-share-filter/scripts/loss_share.py --losses L1 край
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "23-reversal-signal"
                       / "scripts"))

import signal_data as legs  # noqa: E402
import leg_share  # noqa: E402
import share_lstm as memory  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
SET = "вікна+елапс"          # набір каналів етапу 2
LENGTH = 250                 # ручки етапу 2: перебір робився на них,
STEP = 10                    # і лишається на них, щоб числа відтворювались
HIDDEN = 96
LAYERS = 1
RATE = 1e-3
MEMORY = LENGTH * STEP
EPOCHS = 8
EDGE_WEIGHT = 3.0            # A у вазі краю
EDGE_POWER = 2.0             # P у вазі краю
SPREAD = 1.0                 # λ у штрафі за стиснення
MARGIN = 0.05                # наскільки мітки мають різнитись у парі
HUBER = 0.2
STEPS = 9                    # порогів у порядкових головах
BINS = 10                    # десятин у розподілі
LOSSES = ("L1", "MSE", "Huber", "десятини", "сходинки", "ранг",
          "сходинки+ранг", "край", "розмах", "край+ранг")
HEADS = {"десятини": BINS, "сходинки": STEPS, "сходинки+ранг": STEPS}


def head_of(name: str) -> int:
    return HEADS.get(name, 1)


def build(channels: int, out: int, seed: int = legs.SEED):
    """Та сама мережа етапу 2, але голова може бути ширшою за одне число."""
    import torch
    from torch import nn

    torch.manual_seed(seed)

    class Share(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(channels, HIDDEN, LAYERS, batch_first=True)
            self.norm = nn.LayerNorm(HIDDEN)
            self.drop = nn.Dropout(memory.DROPOUT)
            self.head = nn.Linear(HIDDEN, out)

        def forward(self, x):
            found, _ = self.lstm(x)
            return self.head(self.drop(self.norm(found[:, -1])))

    return Share()


def estimate(name: str, raw):
    """Видача мережі -> частка ноги в [0, 1]."""
    import torch

    if name == "десятини":
        weight = (torch.arange(BINS, device=raw.device, dtype=raw.dtype)
                  + 0.5) / BINS
        return (torch.softmax(raw, dim=1) * weight).sum(dim=1)
    if name.startswith("сходинки"):
        return torch.sigmoid(raw).mean(dim=1)
    return torch.sigmoid(raw.squeeze(-1))


def rank_loss(said, want, margin: float = MARGIN):
    """Пари всередині пачки: хто з двох ближче до кінця ноги."""
    import torch
    from torch import nn

    gap = want.unsqueeze(0) - want.unsqueeze(1)
    keep = gap.abs() > margin
    if not bool(keep.any()):
        return said.sum() * 0.0
    diff = said.unsqueeze(0) - said.unsqueeze(1)
    target = (gap > 0).to(said.dtype)
    return nn.functional.binary_cross_entropy_with_logits(
        diff[keep], target[keep])


def loss_of(name: str, raw, want):
    """Втрата за назвою. Видача скрізь у [0, 1], мітка теж."""
    import torch
    from torch import nn

    said = estimate(name, raw)
    if name == "MSE":
        return nn.functional.mse_loss(said, want)
    if name == "Huber":
        return nn.functional.huber_loss(said, want, delta=HUBER)
    if name == "десятини":
        place = torch.clamp((want * BINS).long(), 0, BINS - 1)
        return nn.functional.cross_entropy(raw, place)
    if name.startswith("сходинки"):
        edges = (torch.arange(STEPS, device=raw.device, dtype=raw.dtype)
                 + 1.0) / BINS
        target = (want.unsqueeze(1) >= edges.unsqueeze(0)).to(raw.dtype)
        body = nn.functional.binary_cross_entropy_with_logits(raw, target)
        if name.endswith("ранг"):
            body = body + rank_loss(torch.logit(said.clamp(1e-4, 1 - 1e-4)),
                                    want)
        return body
    if name == "ранг":
        return rank_loss(raw.squeeze(-1), want)
    if name.startswith("край"):
        weight = 1.0 + EDGE_WEIGHT * (2.0 * want - 1.0).abs() ** EDGE_POWER
        body = ((said - want).abs() * weight).sum() / weight.sum()
        if name.endswith("ранг"):
            body = body + rank_loss(raw.squeeze(-1), want)
        return body
    if name == "розмах":
        body = nn.functional.l1_loss(said, want)
        return body + SPREAD * torch.relu(want.std() - said.std())
    return nn.functional.l1_loss(said, want)


def predict(model, state: dict, name: str, rows: np.ndarray, device,
            batch: int = memory.BATCH) -> tuple:
    import torch

    model.eval()
    out, want = [], []
    with torch.no_grad():
        for x, y in memory.batches(state, SET, rows, batch):
            found = model(torch.from_numpy(x).to(device))
            out.append(estimate(name, found).float().cpu().numpy())
            want.append(y)
    if not out:
        return np.empty(0), np.empty(0)
    return np.concatenate(out), np.concatenate(want)


def calibrate(base: np.ndarray, want: np.ndarray,
              said: np.ndarray) -> np.ndarray:
    """Видачу val — у розподіл мітки train через її розподіл на train.

    Монотонне перетворення: порядок, а з ним і `AUC`, не міняється.
    """
    base = np.sort(base[np.isfinite(base)])
    want = np.sort(want[np.isfinite(want)])
    if not len(base) or not len(want):
        return said
    place = np.searchsorted(base, said, side="right") / len(base)
    return np.quantile(want, np.clip(place, 0.0, 1.0))


def measure(said: np.ndarray, want: np.ndarray, base: tuple) -> dict:
    """Числа сирої видачі, плюс `MAE` після калібрування й розмах."""
    body = leg_share.measure_share(want, said)
    fixed = calibrate(base[0], base[1], said)
    body["mae_fixed"] = legs.cell(float(np.mean(np.abs(fixed - want))))
    body["spread"] = legs.cell(float(np.std(said)))
    return body


def train_once(state: dict, name: str, epochs: int = EPOCHS,
               seed: int = legs.SEED, log=print) -> dict:
    """Навчання під однією втратою і числа після кожної епохи."""
    import torch

    device = memory.device_of()
    width = memory.width_of(state["coins"][0]["channels"], SET)
    model = build(width, head_of(name), seed=seed).to(device)
    tune = torch.optim.Adam(model.parameters(), lr=RATE)
    fit = memory.rows_of(state, "train")
    look = {"хвіст": memory.rows_of(state, "хвіст", thin=False),
            "val": memory.rows_of(state, "val", thin=False)}
    history, started = [], time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        total, seen = 0.0, 0
        for x, y in memory.batches(state, SET, fit, shuffle=True,
                                   seed=seed + epoch):
            want = torch.from_numpy(y).to(device)
            step = loss_of(name, model(torch.from_numpy(x).to(device)), want)
            tune.zero_grad()
            step.backward()
            tune.step()
            total += float(step.detach()) * len(y)
            seen += len(y)
        said, want = predict(model, state, name, fit, device)
        base = (said, want)
        row = {"epoch": epoch, "loss": legs.cell(total / max(seen, 1))}
        for key, rows in look.items():
            row[key] = measure(*predict(model, state, name, rows, device),
                               base=base)
        history.append(row)
        log(f"      {name} епоха {epoch:>2}: втрата {row['loss']}, хвіст AUC "
            f"{row['хвіст']['auc_last']}, val AUC {row['val']['auc_last']}, "
            f"val MAE {row['val']['mae']} -> {row['val']['mae_fixed']}, "
            f"розмах {row['val']['spread']}")
    def by(key):
        best = max(history, key=lambda one: one["хвіст"][key]) \
            if key == "auc_last" else min(history,
                                          key=lambda one: one["хвіст"][key])
        return best
    return {"history": history, "by_auc": by("auc_last"), "by_mae": by("mae"),
            "device": str(device), "channels": width, "heads": head_of(name),
            "parameters": int(sum(one.numel() for one in model.parameters())),
            "seconds": round(time.time() - started, 1)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--losses", nargs="+", default=list(LOSSES))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--seed", type=int, default=legs.SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[вікна]")
    state = memory.collect(coins, LENGTH, STEP, log=print)

    print("[втрати]")
    rows = []
    for name in args.losses:
        got = train_once(state, name, args.epochs, seed=args.seed)
        rows.append({"loss": name, "heads": got["heads"],
                     "parameters": got["parameters"], "device": got["device"],
                     "seconds": got["seconds"], "history": got["history"],
                     "by_auc": got["by_auc"], "by_mae": got["by_mae"]})
        best = got["by_mae"]
        print(f"      {name:<14}: краща епоха {best['epoch']}, val AUC "
              f"{best['val']['auc_last']}, val MAE {best['val']['mae']} -> "
              f"{best['val']['mae_fixed']}, розмах {best['val']['spread']}")

    picked = max(rows, key=lambda one: one["by_mae"]["val"]["auc_last"])
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "loss_share.json").write_text(json.dumps({
        "script": "research/26-leg-share-filter/scripts/loss_share.py",
        "command": "python3 research/26-leg-share-filter/scripts/"
                   "loss_share.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "set": SET, "losses": list(args.losses), "picked": picked["loss"],
        "epochs": args.epochs, "seed": args.seed,
        "epoch_by": "MAE хвоста train",
        "picked_by": "епоха за MAE хвоста, втрата за AUC на val",
        "length": LENGTH, "step": STEP,
        "memory": MEMORY, "every": memory.EVERY,
        "hidden": HIDDEN, "layers": LAYERS,
        "dropout": memory.DROPOUT, "batch": memory.BATCH,
        "rate": RATE, "scaler": "quantile",
        "edge_weight": EDGE_WEIGHT, "edge_power": EDGE_POWER,
        "spread": SPREAD, "margin": MARGIN, "huber": HUBER,
        "steps": STEPS, "bins": BINS,
        "constant": {"mae": 0.2484, "auc_last": 0.5},
        "cut_utc": f"{legs.CUT} 00:00:00", "end_utc": f"{legs.END} 00:00:00",
        "pairs": list(legs.PAIRS), "event_seconds": legs.EVENT_LENGTH,
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/loss_share.json")


if __name__ == "__main__":
    main()
