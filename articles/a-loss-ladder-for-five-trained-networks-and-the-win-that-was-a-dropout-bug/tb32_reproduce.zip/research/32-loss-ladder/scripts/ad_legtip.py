"""Адаптер драбини: «сигнал кінця ноги» (дослідження 29, етап 5).

Одобрена версія — `research/29-class7dd-legs/models/legtip_blocks4_gauss_clock_bce/`:
та сама мережа, що в етапі 4 (LSTM 32 з причинною увагою, 415 каналів,
чотири ноги в памʼяті), але ціль — мітка «останні 5 % подій ноги».
Втрата `bce` з вагою позитиву 19, краща епоха 20 з 26, `AP` 0.151 при
рівні сигналу 0.05.

## Нерухома міра

`AP` — середня влучність, площа під кривою влучність-повнота. Вона
рангова: рівень видачі їй байдужий, важить порядок. Саме тому вона
годиться на всю драбину — скільки б не мінялась вага позитиву, `AP`
міряє те саме.

## Драбина

Три ручки штрафу, по черзі й разом:

    тиша       перші `HUSH` подій після півота сигналу практично не
               буває (0.3 % подій), і хибний сплеск там дорожчає ×4 → ×16
    вага краю  помилка біля межі сигналу (останні 10-20 % ноги) дорожча
    фокус      `(1 − p_t) ** γ` гасить легкі негативи, яких 95 %
    вага позитиву   10 → 19 → 30: скільки коштує пропуск сигналу
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LEG29 = PROJECT_ROOT / "research" / "29-class7dd-legs" / "scripts"
LEG19 = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
sys.path.insert(0, str(LEG29))
sys.path.insert(0, str(LEG19))

import legtip_train as base                        # noqa: E402
import legleft_train as core                       # noqa: E402
from legleft_data import DATA                      # noqa: E402

NAME = "legtip"
TITLE = "Сигнал кінця ноги"
SOURCE = "research/29-class7dd-legs/29-class7dd-legs.md → етап 5"
ABOUT = ("Та сама мережа, що веде ногу, але питання двійкове: «ми вже в "
         "кінці?». Сигнал — останні 5 % подій ноги, тобто 19-20 подій на "
         "нозі медіанної довжини; від видачі просять пік саме там.")
METRIC = "AP"
METRIC_DIR = "max"
METRIC_ABOUT = ("середня влучність — площа під кривою влучність-повнота; "
                "рангова, тому не залежить від ваги позитиву. Рівень "
                "сигналу 0.05, більше краще")
MARGIN = 0.001
EXTRA = [{"key": "auc", "title": "AUC", "dir": "max"},
         {"key": "top", "title": "влучність @5 %", "dir": "max",
          "percent": True},
         {"key": "peak", "title": "пік у зоні", "dir": "max",
          "percent": True}]

# `legtip_train.precision_at` віддає цілу плашку — частку, події, поріг,
# влучність, повноту й підйом. У драбину йде одне число з неї: влучність
# на найгучніших 5 % подій.
TOP_KEY = "precision"

TAG = "blocks4_gauss_clock"
APPROVED = (PROJECT_ROOT / "research" / "29-class7dd-legs" / "models"
            / f"legtip_{TAG}_bce")
HIDDEN = 32
HEADS = 2
LR = 1e-3

# Штраф одобреної версії: `bce`, вага позитиву 19, без тиші й без фокусу.
STEP = {"pos": 19.0, "hush": 0, "hush_cost": 1.0, "gamma": 0.0,
        "close": ()}


def rungs() -> list:
    """Щаблі драбини; крок навчання спадає вниз по ній."""
    def rung(name: str, lr: float = LR, **change) -> dict:
        return {"name": name, "step": {**STEP, **change}, "lr": lr,
                "show": {"lr": lr,
                         **{key: (list(value) if isinstance(value, tuple)
                                  else value)
                            for key, value in change.items()}}}

    return [
        rung("той самий штраф"),
        rung("тиша 50 подій ×4", hush=50, hush_cost=4.0),
        rung("тиша ×8", hush=50, hush_cost=8.0),
        rung("той самий штраф · крок ×0.3", lr=3e-4),
        rung("тиша 80 подій ×8", lr=3e-4, hush=80, hush_cost=8.0),
        rung("вага краю ×2/×4", lr=3e-4, close=((0.8, 2.0), (0.9, 4.0))),
        rung("тиша ×8 · край ×2/×4", lr=3e-4, hush=50, hush_cost=8.0,
             close=((0.8, 2.0), (0.9, 4.0))),
        rung("фокус γ1 · тиша ×4", lr=3e-4, gamma=1.0, hush=50,
             hush_cost=4.0),
        rung("вага позитиву 10 · тиша ×8", lr=3e-4, pos=10.0, hush=50,
             hush_cost=8.0),
        rung("тиша ×12", lr=1e-4, hush=50, hush_cost=12.0),
        rung("фокус γ2 · тиша ×8", lr=1e-4, gamma=2.0, hush=50,
             hush_cost=8.0),
        rung("вага позитиву 30 · тиша ×8", lr=1e-4, pos=30.0, hush=50,
             hush_cost=8.0),
        rung("край ×3/×6 · тиша ×8", lr=1e-4, hush=50, hush_cost=8.0,
             close=((0.8, 3.0), (0.9, 6.0))),
        rung("тиша 100 подій ×16", lr=1e-4, hush=100, hush_cost=16.0),
        rung("усе разом", lr=1e-4, pos=19.0, hush=80, hush_cost=12.0,
             gamma=1.0, close=((0.8, 2.0), (0.9, 4.0))),
        rung("вага позитиву 5 · тиша ×8", lr=1e-4, pos=5.0, hush=50,
             hush_cost=8.0),
        rung("край ×2/×4 · фокус γ1", lr=1e-4, gamma=1.0,
             close=((0.8, 2.0), (0.9, 4.0))),
    ]


def step_loss(out, true, place, walk, one: dict):
    """Втрата на крок: вага позитиву, тиша на початку, фокус і край.

    Усе — множники на ту саму двійкову ентропію, тому щаблі драбини
    порівнюються між собою: міняється ціна помилки, а не її означення.
    """
    import torch

    raw = torch.nn.functional.binary_cross_entropy_with_logits(
        out, true, reduction="none")
    weight = torch.where(true > 0.5, torch.full_like(true, one["pos"]),
                         torch.ones_like(true))
    if one["hush"]:
        # хибний сплеск на перших подіях ноги дорожчий: сигналу там
        # практично не буває, а межа стоїть на лічильнику, який мережа
        # бачить каналом — вимога причинна
        hush = (walk < one["hush"]) & (true <= 0.5)
        weight = torch.where(hush, weight * one["hush_cost"], weight)
    each = raw * weight
    if one["gamma"]:
        prob = torch.sigmoid(out)
        right = torch.where(true > 0.5, prob, 1.0 - prob)
        each = each * ((1.0 - right).clamp(min=0.0)
                       ** one["gamma"]).detach()
    if one["close"]:
        near = torch.ones_like(place)
        for edge, times in one["close"]:
            near = torch.where(place >= edge,
                               torch.full_like(place, times), near)
        each = each * near
    return each


# ---------- дані й мережа ----------


def prepare(force: bool = False) -> dict:
    from leg_end_train import no_swap

    no_swap(force=force)
    built = core.load(TAG, DATA)
    rows = core.legs_of(built)
    device = core.device_name()
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    meta_path = DATA / f"legleft_{TAG}.meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8")) \
        if meta_path.exists() else {}
    hit = sum(base.tip_of(rows[one]["events"]) for one in train)
    seen = sum(rows[one]["events"] for one in train)
    print(f"ноги: train {len(train)}, val {len(val)}; сигнал у train "
          f"{hit} з {seen} ({hit / seen * 100:.2f} %); пристрій {device}")
    return {"built": built, "rows": rows, "device": device,
            "train": train, "val": val, "meta": meta}


def build(ctx: dict, seed: int):
    import torch
    from leg_end_net import LegEnd

    torch.manual_seed(seed)
    model = LegEnd(features=ctx["built"]["x"].shape[1] + 1, hidden=HIDDEN,
                   heads=HEADS, attention=True,
                   outputs=1).to(ctx["device"])
    return model, optimizer(ctx, model)


def optimizer(ctx: dict, model):
    import torch

    return torch.optim.AdamW(model.parameters(), lr=LR)


def start_from(ctx: dict, model, tune) -> dict:
    import torch

    path = APPROVED / "model.pt"
    if not path.exists():
        raise SystemExit(f"немає одобрених ваг: {path}")
    model.load_state_dict(torch.load(path, map_location="cpu"))
    lifted = (APPROVED / "tune.pt").exists()
    if lifted:
        tune.load_state_dict(torch.load(APPROVED / "tune.pt",
                                        map_location="cpu"))
    print(f"старт із {APPROVED.name}: стан оптимізатора "
          f"{'піднято' if lifted else 'набереться заново'}")
    return {"config": {"hidden": HIDDEN, "lr": LR, "loss": "bce",
                       "pos_weight": STEP["pos"],
                       "from": str(APPROVED.relative_to(PROJECT_ROOT))}}


def train_epoch(ctx: dict, model, tune, rung: dict, seed: int,
                attempt: int = 1) -> float:
    """Епоха під штрафом щабля; повторна спроба — вдвічі меншим кроком."""
    import torch

    built, rows, device = ctx["built"], ctx["rows"], ctx["device"]
    one = rung["step"]
    rate = rung.get("lr", LR) / (2 ** (attempt - 1))
    for group in tune.param_groups:
        group["lr"] = rate
    model.train()
    total, seen = 0.0, 0

    def feed(picked: list, scale=None):
        x, y, mask, lengths, own, place, walk = base.tensors(
            built, rows, picked, device)
        share = own.float()
        if scale is None:
            scale = share.sum()
        out = model(x, mask, lengths)
        piece = (step_loss(out, y, place, walk, one) * share).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum()), scale

    def learn(picked: list, scale=None):
        try:
            return feed(picked, scale)
        except RuntimeError as error:
            if len(picked) == 1 or not core.out_of_memory(error):
                raise
            core.free_of(device)
            if scale is None:
                scale = base.tensors(built, rows, picked,
                                     device)[4].float().sum()
            half = len(picked) // 2
            first = learn(picked[:half], scale)
            second = learn(picked[half:], scale)
            return first[0] + second[0], first[1] + second[1], scale

    for chunk in core.batches([rows[one_] for one_ in ctx["train"]],
                              seed=seed):
        picked = [ctx["train"][one_] for one_ in chunk]
        tune.zero_grad()
        got, count, _ = learn(picked)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        total += got * count
        seen += count
    return total / max(seen, 1)


# ---------- замір ----------


def evaluate(ctx: dict, model) -> dict:
    built, rows, device = ctx["built"], ctx["rows"], ctx["device"]
    val = ctx["val"]
    block = base.guess(model, built, rows, val, device)
    whole = base.score(block)
    out, place = {}, 0
    pieces = {}
    for one in val:
        count = rows[one]["events"]
        pair = rows[one]["pair"]
        piece = pieces.setdefault(pair, {"said": [], "truth": [],
                                         "decile": [], "legs": []})
        for key in ("said", "truth", "decile", "legs"):
            piece[key].append(block[key][place:place + count])
        place += count
    for pair, piece in pieces.items():
        got = {key: np.concatenate(value) for key, value in piece.items()}
        marks = base.score(got)
        out[pair] = {"mark": marks["ap"], "ap": marks["ap"],
                     "auc": marks["auc"],
                     "top": marks["top"][TOP_KEY],
                     "peak": marks["peak"], "base": marks["base"],
                     "events": marks["events"],
                     "legs": int(len(np.unique(got["legs"])))}
    return {"mark": whole["ap"],
            "metrics": {"ap": whole["ap"], "auc": whole["auc"],
                        "top": whole["top"][TOP_KEY],
                        "lift": whole["top"]["lift"],
                        "peak": whole["peak"],
                        "base": whole["base"], "events": whole["events"],
                        "by_decile": whole["by_decile"]},
            "by_pair": out}


def human(got: dict) -> str:
    one = got["metrics"]
    return (f"AUC {one['auc']:.4f} · влучність@5 % {one['top'] * 100:.1f} % "
            f"· пік {one['peak'] * 100:.0f} %")


def pairs_of(ctx: dict) -> list:
    return sorted({ctx["rows"][one]["pair"] for one in ctx["val"]})


def data_of(ctx: dict) -> dict:
    meta = ctx["meta"]
    return {"tag": TAG, "classes": meta.get("classes", []),
            "channels": int(ctx["built"]["x"].shape[1]) + 1,
            "history": meta.get("history"),
            "val_from": meta.get("val_from"),
            "tip": base.TIP,
            "legs": {"train": len(ctx["train"]), "val": len(ctx["val"])},
            "approved": str(APPROVED.relative_to(PROJECT_ROOT))}
