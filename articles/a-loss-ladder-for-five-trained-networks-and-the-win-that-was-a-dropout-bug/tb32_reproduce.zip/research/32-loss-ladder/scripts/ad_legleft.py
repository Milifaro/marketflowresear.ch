"""Адаптер драбини: «скільки подій до кінця ноги» (дослідження 29, етап 4).

Одобрена версія — `research/29-class7dd-legs/models/legleft_blocks4_gauss_clock_band/`:
LSTM 32 з причинною увагою на 415 каналах семи класів сітки 210 с,
чотири попередні ноги в памʼяті, втрата `band` — коридор довкола цілі
перші 150 подій після півота і мовчання далі. Краща епоха 24 з 32,
міра `0.8373`.

## Нерухома міра

`legleft_train.band_mark` — частка видачі, що лягла в коридор (вузький
`0.9–1.1` і широкий `0.7–1.3` разом), плюс надбавка за балакучість після
вікна відповіді. Менше краще, нуль — ідеал.

Ці числа — **міра**, і драбина їх не чіпає: усі щаблі міряються тим
самим коридором, яким міряли одобрену версію. Міняється тільки те, чим
штрафують: ширина коридору **втрати**, крутість експоненти, ціна
заниження, завищення й балакучості.

## Драбина

Щабель за щаблем штраф росте: коридор втрати вужчає `0.90 → 0.97`, ціна
заниження йде `80 → 400`, ціна мовчання `6 → 24`. Між ними — щаблі, де
міняється **форма**: крутіша експонента, нижча стеля, домішка Хубера в
подіях, важча голова вікна.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LEG29 = PROJECT_ROOT / "research" / "29-class7dd-legs" / "scripts"
LEG19 = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
sys.path.insert(0, str(LEG29))
sys.path.insert(0, str(LEG19))

import legleft_train as base                       # noqa: E402
from legleft_data import DATA                      # noqa: E402

NAME = "legleft"
TITLE = "Скільки подій до кінця ноги"
SOURCE = "research/29-class7dd-legs/29-class7dd-legs.md → етап 4"
ABOUT = ("LSTM 32 з причинною увагою веде ногу зігзага 2.3 % на ема10 "
         "подія за подією на 415 каналах семи класів сітки 210 с і на "
         "кожній каже, скільки подій лишилось до півота. Перші 150 подій "
         "після півота вона відповідає, далі мовчить.")
METRIC = "коридор"
METRIC_DIR = "min"
METRIC_ABOUT = ("частка видачі поза коридором довкола цілі плюс надбавка "
                "за балакучість після вікна відповіді; менше краще")
MARGIN = 0.002
EXTRA = [{"key": "err", "title": "похибка, подій", "dir": "min"},
         {"key": "near", "title": "у коридорі 0.9–1.1", "dir": "max",
          "percent": True},
         {"key": "wide", "title": "у коридорі 0.7–1.3", "dir": "max",
          "percent": True},
         {"key": "loud", "title": "балакучість після вікна", "dir": "min"}]

TAG = "blocks4_gauss_clock"
APPROVED = (PROJECT_ROOT / "research" / "29-class7dd-legs" / "models"
            / f"legleft_{TAG}_band")
HIDDEN = 32
HEADS = 2
LR = 1e-3

# Штраф одобреної версії: від нього рахуються всі множники драбини.
BAND = {"window": 150, "band": (0.90, 1.10), "ceil": 2.2, "grow": 5.0,
        "down": 80.0, "up": 20.0, "quiet": 6.0, "wake": ((0, 1.0),),
        "mix": 0.0}


def rungs() -> list:
    """Щаблі: що саме дорожчає і в скільки разів проти одобреної версії.

    Крок навчання спадає вниз по драбині: одобрена версія стоїть у
    своєму оптимумі на val, і повна епоха кроком `1e-3` з нього просто
    виходить. Тому перші щаблі йдуть її ж кроком, далі — `3e-4` і `1e-4`.
    """
    def rung(name: str, lr: float = LR, **change) -> dict:
        return {"name": name, "band": {**BAND, **change}, "lr": lr,
                "show": {"lr": lr,
                         **{key: (list(value) if isinstance(value, tuple)
                                  else value)
                            for key, value in change.items()}}}

    return [
        rung("той самий штраф"),
        rung("заниження ×1.5", down=120.0, up=30.0),
        rung("коридор 0.93–1.07", band=(0.93, 1.07)),
        rung("той самий штраф · крок ×0.3", lr=3e-4),
        rung("заниження ×2 · тиша ×1.5", lr=3e-4, down=160.0, up=40.0,
             quiet=9.0),
        rung("коридор 0.95–1.05 · ×2", lr=3e-4, band=(0.95, 1.05),
             down=160.0, up=40.0),
        rung("крутіша експонента", lr=3e-4, grow=7.0),
        rung("заниження ×3 · тиша ×2", lr=3e-4, down=240.0, up=60.0,
             quiet=12.0),
        rung("коридор 0.96–1.04 · ×3", lr=3e-4, band=(0.96, 1.04),
             down=240.0, up=60.0),
        rung("важча голова вікна", lr=1e-4, wake=((0, 2.0), (30, 1.0))),
        rung("домішка Хубера в подіях", lr=1e-4, mix=0.3),
        rung("нижча стеля завищення", lr=1e-4, ceil=1.8, up=60.0),
        rung("коридор 0.97–1.03 · ×4", lr=1e-4, band=(0.97, 1.03),
             down=320.0, up=80.0),
        rung("тиша ×4", lr=1e-4, quiet=24.0),
        rung("усе разом ×5", lr=1e-4, band=(0.95, 1.05), down=400.0,
             up=100.0, quiet=18.0, grow=6.0),
        rung("вужче вікно відповіді", lr=1e-4, window=120, down=240.0,
             up=60.0),
        rung("ширше вікно відповіді", lr=1e-4, window=200, down=240.0,
             up=60.0),
    ]


# ---------- втрата щабля ----------


def band_step(out, true, walk, one: dict):
    """Той самий `band`, але всі його числа — параметри щабля.

    Форма не міняється: коридор у частках цілі, експонента на краях,
    модуль видачі після вікна. Міняються ширина коридору, крутість,
    ціни заниження, завищення й балакучості — і, на щаблі домішки,
    додається Хубер у подіях, який тягне видачу до самого числа.
    """
    import torch

    said = torch.expm1(out)
    real = torch.expm1(true).clamp(min=1.0)
    share = (said / real).clamp(min=0.0)
    band, grow, ceil = one["band"], one["grow"], one["ceil"]
    steep = float(np.expm1(grow))
    low = one["down"] * torch.expm1(
        grow * (band[0] - share).clamp(min=0.0) / band[0]) / steep
    high = one["up"] * torch.expm1(
        grow * (share.clamp(max=ceil) - band[1]).clamp(min=0.0)
        / (ceil - band[1])) / steep
    quiet = one["quiet"] * (said / base.MEASURE).abs()
    wake = torch.full_like(walk, one["wake"][0][1])
    for edge, times in one["wake"][1:]:
        wake = torch.where(walk >= edge, torch.full_like(walk, times), wake)
    each = torch.where(walk < one["window"], wake * (low + high), quiet)
    if one["mix"]:
        huber = torch.nn.functional.huber_loss(
            said / base.MEASURE, torch.expm1(true) / base.MEASURE,
            reduction="none")
        each = each + one["mix"] * torch.where(
            walk < one["window"], huber, torch.zeros_like(huber))
    return each


# ---------- дані й мережа ----------


def prepare(force: bool = False) -> dict:
    from leg_end_train import no_swap

    no_swap(force=force)
    built = base.load(TAG, DATA)
    rows = base.legs_of(built)
    device = base.device_name()
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    meta_path = DATA / f"legleft_{TAG}.meta.json"
    import json
    meta = json.loads(meta_path.read_text(encoding="utf-8")) \
        if meta_path.exists() else {}
    print(f"ноги: train {len(train)}, val {len(val)}; "
          f"каналів {built['x'].shape[1] + 1}; пристрій {device}")
    return {"built": built, "rows": rows, "device": device,
            "train": train, "val": val, "meta": meta}


def build(ctx: dict, seed: int):
    import torch
    from leg_end_net import LegEnd

    torch.manual_seed(seed)
    model = LegEnd(features=ctx["built"]["x"].shape[1] + 1, hidden=HIDDEN,
                   heads=HEADS, attention=True,
                   outputs=1).to(ctx["device"])
    return model, optimizer(ctx, model)


def optimizer(ctx: dict, model):
    import torch

    return torch.optim.AdamW(model.parameters(), lr=LR)


def start_from(ctx: dict, model, tune) -> dict:
    """Ваги одобреної версії; стан оптимізатора — якщо лежить поруч."""
    import torch

    path = APPROVED / "model.pt"
    if not path.exists():
        raise SystemExit(f"немає одобрених ваг: {path}")
    model.load_state_dict(torch.load(path, map_location="cpu"))
    lifted = (APPROVED / "tune.pt").exists()
    if lifted:
        tune.load_state_dict(torch.load(APPROVED / "tune.pt",
                                        map_location="cpu"))
    print(f"старт із {APPROVED.name}: стан оптимізатора "
          f"{'піднято' if lifted else 'набереться заново'}")
    return {"config": {"hidden": HIDDEN, "lr": LR, "loss": "band",
                       "from": str(APPROVED.relative_to(PROJECT_ROOT))}}


def train_epoch(ctx: dict, model, tune, rung: dict, seed: int,
                attempt: int = 1) -> float:
    """Одна епоха під штрафом щабля. Батч, що не вліз, ділиться навпіл.

    Повторна спроба того самого щабля йде вдвічі меншим кроком: перша
    не взялась, і та сама відстань при тому самому напрямку — це
    просто перестрибування оптимуму.
    """
    import torch

    built, rows, device = ctx["built"], ctx["rows"], ctx["device"]
    one = rung["band"]
    rate = rung.get("lr", LR) / (2 ** (attempt - 1))
    for group in tune.param_groups:
        group["lr"] = rate
    model.train()
    total, seen = 0.0, 0

    def feed(picked: list, scale=None):
        x, y, mask, lengths, own, _, walk = base.tensors(
            built, rows, picked, device)
        share = own
        if scale is None:
            scale = share.sum()
        out = model(x, mask, lengths)
        piece = (band_step(out, y, walk, one) * share).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum()), scale

    def learn(picked: list, scale=None):
        try:
            return feed(picked, scale)
        except RuntimeError as error:
            if len(picked) == 1 or not base.out_of_memory(error):
                raise
            base.free_of(device)
            if scale is None:
                scale = base.weight_of(built, rows, picked, device, "band")
            half = len(picked) // 2
            first = learn(picked[:half], scale)
            second = learn(picked[half:], scale)
            return first[0] + second[0], first[1] + second[1], scale

    for chunk in base.batches([rows[one_] for one_ in ctx["train"]],
                              seed=seed):
        picked = [ctx["train"][one_] for one_ in chunk]
        tune.zero_grad()
        got, count, _ = learn(picked)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        total += got * count
        seen += count
    return total / max(seen, 1)


# ---------- замір ----------


def marks_of(block: dict, rows: list, picked: list) -> dict:
    """Коридор, широкий коридор, балакучість і сама міра — на одному зрізі."""
    step = np.concatenate([np.arange(rows[one]["events"], dtype=np.float64)
                           for one in picked])
    said = np.asarray(block["said"], dtype=np.float64)
    truth = np.asarray(block["truth"], dtype=np.float64)
    talk = step < base.WINDOW
    if not talk.any():
        return {"mark": float("nan"), "near": 0.0, "wide": 0.0, "loud": 0.0,
                "err": float("nan"), "events": int(said.size)}
    share = said[talk] / np.maximum(truth[talk], 1.0)
    near = float(((share >= base.BAND[0]) & (share <= base.BAND[1])).mean())
    wide = float(((share >= base.WIDE[0]) & (share <= base.WIDE[1])).mean())
    loud = (float(np.median(np.abs(said[~talk]))) / base.MEASURE
            if (~talk).any() else 0.0)
    return {"mark": 1.0 - (near + wide) / 2.0 + loud,
            "near": near, "wide": wide, "loud": loud,
            "err": float(np.median(np.abs(said - truth))),
            "events": int(said.size)}


def evaluate(ctx: dict, model) -> dict:
    """Міра на всьому val і та сама міра окремо по кожній монеті."""
    built, rows, device = ctx["built"], ctx["rows"], ctx["device"]
    val = ctx["val"]
    block = base.guess(model, built, rows, val, device)
    whole = marks_of(block, rows, val)
    by_pair, place = {}, 0
    for one in val:                      # `guess` іде рівно цим порядком
        count = rows[one]["events"]
        pair = rows[one]["pair"]
        by_pair.setdefault(pair, {"said": [], "truth": [], "legs": []})
        by_pair[pair]["said"].append(block["said"][place:place + count])
        by_pair[pair]["truth"].append(block["truth"][place:place + count])
        by_pair[pair]["legs"].append(one)
        place += count
    out = {}
    for pair, got in by_pair.items():
        piece = {"said": np.concatenate(got["said"]),
                 "truth": np.concatenate(got["truth"])}
        marks = marks_of(piece, rows, got["legs"])
        out[pair] = {**marks, "legs": len(got["legs"])}
    return {"mark": whole["mark"],
            "metrics": {key: whole[key] for key in
                        ("err", "near", "wide", "loud", "events")},
            "by_pair": out}


def human(got: dict) -> str:
    one = got["metrics"]
    return (f"коридор {one['near'] * 100:.1f} % · широкий "
            f"{one['wide'] * 100:.1f} % · похибка {one['err']:.0f} подій")


def pairs_of(ctx: dict) -> list:
    return sorted({ctx["rows"][one]["pair"] for one in ctx["val"]})


def data_of(ctx: dict) -> dict:
    meta = ctx["meta"]
    return {"tag": TAG, "classes": meta.get("classes", []),
            "channels": int(ctx["built"]["x"].shape[1]) + 1,
            "history": meta.get("history"),
            "val_from": meta.get("val_from"),
            "legs": {"train": len(ctx["train"]), "val": len(ctx["val"])},
            "approved": str(APPROVED.relative_to(PROJECT_ROOT))}
