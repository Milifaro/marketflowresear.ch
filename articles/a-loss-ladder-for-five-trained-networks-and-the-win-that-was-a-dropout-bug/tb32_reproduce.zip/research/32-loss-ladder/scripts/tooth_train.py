"""Мережа зубців: один сигнал на ногу, і саме в зоні розвороту.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Етап 10 показав, що одна голова не тягне обидві задачі: частота
обнулень не опускається нижче 16 на 1000, скільки на неї не тисни, а
розмах лінії при цьому осідає в нуль. Тому задачі розділені —

    ця мережа каже **де зубець**: один сигнал на ногу, у зоні розвороту
    сусідня веде **частку пройденої ноги** й обнуляється чужим сигналом

## Чим ця ціль відрізняється від `legtip`

`legtip` дослідження 29 має мітку «останні 5 % подій ноги» і вчиться на
ногах, нарізаних блоками. Обидва рішення тут не годяться: нарізка сама
підказує мережі, де кінець (етап 5), а мітка просить сигнал на **всіх**
подіях зони — тобто просить саме той спрей, від якого ми йдемо.

Тут інакше. Рамка — рухомі вікна без розмітки, як у мережі частки. Ціль
формулюється через **максимум**:

    позитив   найгучніша подія зони має бути гучною — по одній на ногу
    негатив   кожна подія поза зоною має бути тихою — щільно

Максимум і є «натисни один раз»: коли одна подія зони вже гучна,
градієнт на решту подій зони не йде, і сигнал не розмазується. А
щільний негатив платить за кожен зайвий натиск окремо.

Зона — **частка ноги** (`SHARE`, з `zone_length.py`) плюс `HEAD` подій
після розвороту, з межами `LOW`…`HIGH`.

Поруч із втратою стоїть ще один доданок — **де саме** в зоні стоїть
максимум: чим далі від самого півота, тим дорожче, драбиною ×`TIMES` на
кожні `PACE` подій. Без нього мережі байдуже, у якому кінці зони
тиснути.

Вхід : датасет `legleft_blocks4_gauss_clock`, тулуб з ваг дослідження 29
Вихід: results/tooth_train.json, models/legtooth/model.pt

Запуск:
    python3 research/32-loss-ladder/scripts/tooth_train.py --epochs 40
    python3 research/32-loss-ladder/scripts/tooth_train.py --epochs 20 --resume
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = SCRIPTS.parents[2]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

NAME = "legtooth"
SEED = 0
EPOCHS = 40
PATIENCE = 12
LR = 3e-4
SHARE = 0.095              # зона до розвороту: частка ноги
LOW, HIGH = 15, 150
HEAD = 15                  # і скільки подій після розвороту
RATES = (1.0, 2.5, 5.0, 10.0, 20.0)
KNOBS = {"hit": 1.0,       # вага позитиву: найгучніша подія зони
         "quiet": 1.0,     # вага негативу: кожна подія поза зоною
         "place": 0.5,     # вага «де саме в зоні стоїть максимум»
         "times": 3.0, "pace": 5.0, "roof": 81.0}
SCRIPT = "research/32-loss-ladder/scripts/tooth_train.py"
OUT = "tooth_train.json"


def sibling(name: str):
    """Сусідній скрипт дослідження — за шляхом файлу, а не за іменем."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


# ------------------------------------------------------------------ втрата

def zone_of(far, past, knobs: dict = None):
    """Чи стоїть подія в зоні розвороту своєї ноги.

    Довжина ноги в кожній події — `far + past + 1`, тому зона рахується
    на місці й розмітки на вхід мережі не додає.
    """
    import torch

    length = far + past + 1.0
    size = torch.clamp(SHARE * length, min=float(LOW), max=float(HIGH))
    return ((far <= size) | (past <= HEAD)), size


def tooth_step(said, far, past, born, own, knobs: dict):
    """Один зубець на ногу: максимум у зоні вгору, решта вниз.

    Позитив береться **максимумом** по зоні кожної ноги, а не сумою й
    не середнім: коли одна подія зони вже гучна, іншим уже нічого не
    треба, і сигнал не розмазується на всі сорок подій.

    Негатив щільний: кожна подія поза зоною платить сама за себе, тому
    зайвий натиск коштує окремо, а не «в середньому».
    """
    import torch

    inside, _ = zone_of(far, past)
    inside = inside & own.bool()
    outside = (~inside) & own.bool()
    safe = said.clamp(1e-6, 1.0 - 1e-6)

    leg = born.cumsum(dim=1).long()
    rows, width = leg.shape[0], int(leg.max().item()) + 1
    place = (torch.arange(rows, device=leg.device).unsqueeze(1) * width
             + leg).reshape(-1)
    # максимум видачі в зоні кожної ноги — через scatter-reduce
    best = torch.full((rows * width,), 0.0, device=said.device,
                      dtype=said.dtype)
    best = best.scatter_reduce(0, place, (safe * inside).reshape(-1),
                               reduce="amax", include_self=True)
    alive = torch.zeros((rows * width,), device=said.device,
                        dtype=said.dtype)
    alive = alive.scatter_reduce(0, place, inside.to(said.dtype).reshape(-1),
                                 reduce="amax", include_self=True)
    hit = -(torch.log(best.clamp(min=1e-6)) * alive).sum() * knobs["hit"]

    quiet = -(torch.log1p(-safe) * outside).sum() * knobs["quiet"]

    # **Де** мережа поклала свій сигнал у зоні. Брати відстань
    # найближчої події зони не можна: сам півот у зоні завжди, і така
    # міра дорівнює нулю на кожній нозі — тобто не каже нічого. Тому
    # відстань зважується тим, скільки сигналу мережа туди поклала:
    # чим гучніша подія далеко від півота, тим дорожче.
    steps = torch.floor(far.clamp(min=0.0) / knobs["pace"])
    ladder = torch.pow(torch.full_like(steps, knobs["times"]),
                       steps.clamp(max=20.0)).clamp(max=knobs["roof"])
    weight = safe * inside
    mass = torch.zeros((rows * width,), device=said.device,
                       dtype=said.dtype).index_add_(0, place,
                                                    weight.reshape(-1))
    cost = torch.zeros((rows * width,), device=said.device,
                       dtype=said.dtype).index_add_(
        0, place, (weight * ladder).reshape(-1))
    where = (knobs["place"] * cost / mass.clamp(min=1e-6) * alive).sum()
    return hit + quiet + where, {"hit": float(hit.detach()),
                                 "quiet": float(quiet.detach()),
                                 "where": float(where.detach())}


# ------------------------------------------------------------------- замір

def build_of(ctx: dict, ad, seed: int):
    """Мережа з **одним** виходом: тулуб одобрений, голова нова."""
    import torch
    from leg_end_net import LegEnd

    torch.manual_seed(seed)
    model = LegEnd(features=ctx["built"]["x"].shape[1] + 1, hidden=ad.HIDDEN,
                   heads=ad.HEADS, attention=True,
                   outputs=1).to(ctx["device"])
    was = torch.load(ad.APPROVED / "model.pt", map_location="cpu")
    model.load_state_dict({key: value for key, value in was.items()
                           if not key.startswith("head.")}, strict=False)
    return model


def score_on(model, built: dict, boxes: list, device: str,
             total: int) -> np.ndarray:
    """Видача на всій стрічці val: одне число на подію."""
    import torch
    import share_train as share

    out = np.full(total, np.nan, dtype=np.float32)
    model.eval()
    for chunk in share.packed(boxes):
        length = max(one["steps"] for one in chunk)
        width = built["x"].shape[1] + 1
        x = np.zeros((len(chunk), length, width), dtype=np.float32)
        mask = np.zeros((len(chunk), length), dtype=bool)
        for number, one in enumerate(chunk):
            steps = one["steps"]
            x[number, :steps, :-1] = share.frame_of(built, one)
            x[number, :steps, -1] = 1.0
            mask[number, :steps] = True
        lengths = torch.tensor([one["steps"] for one in chunk])
        with torch.no_grad():
            raw = model(torch.from_numpy(x).to(device),
                        torch.from_numpy(mask).to(device), lengths)
            said = torch.sigmoid(raw[..., 0] if raw.dim() == 3 else raw)
        piece = said.float().cpu().numpy()
        for number, one in enumerate(chunk):
            keep = slice(one["steps"] - one["events"], one["steps"])
            out[one["first"]:one["last"] + 1] = piece[number, keep]
        share.free_of(device)
    model.train()
    return out


def measure(model, built: dict, rows: list, picked: list, boxes: list,
            seen: np.ndarray, device: str, total: int) -> dict:
    """Та сама лінійка, що й у `tooth_check.py`: підйом і влучність."""
    check = sibling("tooth_check")
    zone = sibling("pivot_zone")
    score = score_on(model, built, boxes, device, total)
    good = seen & np.isfinite(score)
    truth = check.inzone_mask(rows, picked, total)
    out = {"auc": round(zone.auc_of(truth[good].astype(float), score[good]),
                        4), "steps": []}
    for rate in RATES:
        got = check.at_level(score, seen, rows, picked,
                             check.level_for(score, seen, rate))
        got["aim"] = rate
        out["steps"].append(got)
    one = next((two for two in out["steps"] if two["aim"] == 2.5), {})
    out.update({"lift": one.get("lift"), "inzone": one.get("inzone"),
                "missed": one.get("missed"), "delay": one.get("delay")})
    out["each"] = each_leg(score, rows, picked)
    return out


def each_leg(score: np.ndarray, rows: list, picked: list) -> dict:
    """Один натиск на ногу: найгучніша подія ноги — вона в зоні чи ні.

    Спільний поріг на всю стрічку ділить натиски нерівно: на легкій нозі
    мережа тисне тричі, на важкій жодного разу. Але користуватись нею
    будуть інакше — по одному обнуленню на ногу. Тому міряється саме це:
    беремо найгучнішу подію кожної ноги й дивимось, чи влучила вона.
    """
    hit, gaps = 0, []
    for one in picked:
        row = rows[one]
        piece = score[row["first"]:row["last"] + 1]
        good = np.isfinite(piece)
        if not good.any():
            continue
        place = int(np.flatnonzero(good)[np.argmax(piece[good])])
        away = place - (row["last"] - row["first"])
        size = min(max(int(round(row["events"] * SHARE)), LOW), HIGH)
        gaps.append(away)
        if -size <= away <= 0:
            hit += 1
    if not gaps:
        return {}
    return {"legs": len(gaps), "inzone": round(hit / len(gaps), 4),
            "delay": round(float(np.median(gaps)), 1),
            "spread": round(float(np.median(np.abs(gaps))), 1)}


def score_of(one: dict) -> float:
    """Вибір епохи, «менше краще»: ранг сигналу і влучність на одному зубці.

    `AUC` каже, чи взагалі відрізняє мережа зону від решти ноги, а
    влучність при одному натиску на ногу — чи годиться вона на ділі.
    Обидва потрібні: висока `AUC` при нульовій влучності означає, що
    сигнал гарний у середньому й непридатний поодинці.
    """
    auc = float(one.get("auc") or 0.5)
    each = float((one.get("each") or {}).get("inzone") or 0.0)
    return round((1.0 - auc) + (1.0 - each), 4)


# ---------------------------------------------------------------- навчання

def epoch_of(model, tune, built: dict, boxes: list, ahead: np.ndarray,
             back: np.ndarray, truth: np.ndarray, device: str,
             seed: int, knobs: dict) -> tuple:
    """Одна епоха: максимум у зоні вгору, решта вниз."""
    import torch
    import share_train as share

    tools = sibling("zone_train")
    model.train()
    chunks = share.packed(boxes)
    order = list(range(len(chunks)))
    np.random.default_rng(seed).shuffle(order)
    total, seen, parts = 0.0, 0, {"hit": 0.0, "quiet": 0.0, "where": 0.0}

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, far, past, born = tools.tensors_of(
            built, chunk, truth, ahead, back, device)
        if scale is None:
            scale = own.sum()
        raw = model(x, mask, lengths)
        said = torch.sigmoid(raw[..., 0] if raw.dim() == 3 else raw)
        step, got = tooth_step(said, far, past, born, own, knobs)
        piece = step / scale
        piece.backward()
        return float(piece.detach()), int(own.sum().item()), scale, got

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            share.free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2], one[3]

    for number in order:
        tune.zero_grad()
        got, count, _, split = learn(chunks[number])
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        share.free_of(device)
        total += got * count
        seen += count
        for key in parts:
            parts[key] += split[key]
    return total / max(seen, 1), parts


def save(curve: list, best, args, device: str, began: float, win: int,
         warm: int, knobs: dict) -> None:
    """Звіт пишеться після кожної епохи: прогін довгий, і його рвуть."""
    report = {"script": SCRIPT, "ready": True, "model": NAME, "lr": args.lr,
              "win": win, "warm": warm, "share": SHARE, "low": LOW,
              "high": HIGH, "head": HEAD, "rates": list(RATES),
              "knobs": knobs, "device": device,
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "curve": curve, "best": best,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / OUT).write_text(json.dumps(report, ensure_ascii=False),
                               encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--minutes", type=float, default=400.0)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    tools = sibling("zone_train")
    ctx = ad.prepare(force=args.force)
    device, rows, built = ctx["device"], ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    hot = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    was = RESULTS / "zone_train.json"
    older = json.loads(was.read_text(encoding="utf-8")) if was.exists() else {}
    win = int(older.get("win", share.WIN))
    warm = int(older.get("warm", share.WARM))

    first, last = share.edges_of(rows, hot + val, total)
    truth = share.truth_of(first, last)
    ahead, back = tools.steps_of(rows, hot + val, total)
    train_boxes = share.windows(share.spans_of(rows, hot), win, warm)
    val_boxes = share.windows(share.spans_of(rows, val), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in val_boxes:
        seen[one["first"]:one["last"] + 1] = True
    print(f"вікон: train {len(train_boxes)}, val {len(val_boxes)} по {win} "
          f"подій · зона {SHARE:.1%} ноги ({LOW}…{HIGH}) + {HEAD} подій · "
          f"пристрій {device}")

    model = build_of(ctx, ad, SEED)
    keep = MODELS / NAME
    keep.mkdir(parents=True, exist_ok=True)
    tune = torch.optim.AdamW(model.parameters(), lr=args.lr)
    curve, best, stale = [], None, 0
    path = RESULTS / OUT
    if args.resume and path.exists() and (keep / "model.pt").exists():
        older = json.loads(path.read_text(encoding="utf-8"))
        series.lift(model, keep / "model.pt")
        if (keep / "tune.pt").exists():
            tune.load_state_dict(torch.load(keep / "tune.pt",
                                            map_location="cpu"))
        curve, best = list(older.get("curve", [])), older.get("best")
        print(f"продовжую з епохи {len(curve) + 1}")

    began = time.time()
    for number in range(len(curve) + 1, len(curve) + args.epochs + 1):
        loss, parts = epoch_of(model, tune, built, train_boxes, ahead, back,
                               truth, device, SEED + number, KNOBS)
        share.free_of(device)
        now = measure(model, built, rows, val, val_boxes, seen, device, total)
        share.free_of(device)
        spent = (time.time() - began) / 60.0
        step = {"epoch": number, "loss": round(loss, 4),
                "parts": {key: round(value, 1) for key, value in
                          parts.items()},
                **{key: value for key, value in now.items()
                   if key != "steps"}, "steps": now["steps"]}
        step["score"] = score_of(step)
        curve.append({**step, "minutes": round(spent, 1)})
        print(f"  епоха {number:>2} · втрата {loss:.4f} · AUC зони "
              f"{now['auc']} · при 2.5/1000: підйом {now['lift']} · у зоні "
              f"{now['inzone']} · один на ногу: у зоні "
              f"{(now.get('each') or {}).get('inzone')} · зсув "
              f"{(now.get('each') or {}).get('delay')} · оцінка "
              f"{step['score']} · {spent:.1f} хв")
        if best is None or step["score"] < best["score"]:
            best = {key: value for key, value in step.items()}
            stale = 0
            torch.save(model.state_dict(), keep / "model.pt")
            torch.save(tune.state_dict(), keep / "tune.pt")
        else:
            stale += 1
        save(curve, best, args, device, began, win, warm, KNOBS)
        if (args.patience and stale >= args.patience) \
                or spent > args.minutes:
            break
    save(curve, best, args, device, began, win, warm, KNOBS)


if __name__ == "__main__":
    main()
