"""Фальшивий півот: що скаже `legleft`, якщо ногу різати кожні 150 подій.

Дослідження: research/32-loss-ladder/
Правила: rules/05-visualization.md → компоновка

`legleft` не знаходить кінець ноги — їй кажуть, де нога **почалась**.
Півот приходить із розмітки зігзага 2.3 % на ема10 по всьому ряду, і
з нього ростуть чотири канали: напрямок ноги `leg:up`, лічильник
`leg:step`, відповідь лічильника `leg:guess` і вікно відповіді
`leg:open`. Плюс сама нарізка: памʼять LSTM обнуляється на першій події
ноги.

Питання етапу просте: **що лишиться від видачі, якщо півот підробити.**
Ряд val BTC ріжеться на рівні шматки по 150 подій, і мережі кажуть, що
кожен такий шматок — нова нога. Усе інше те саме: ті самі ваги, ті самі
події, той самий клас у 410 каналах.

    розмітка      справжні ноги зігзага, як в одобреній версії
    кожні 150     півот кожні 150 подій, напрямок лишається справжнім
    сліпий        те саме, але й `leg:up` заповнений серединою розподілу:
                  від розмітки не лишається нічого

Міряється все **проти справжньої правди** — скільки подій справді
лишилось до справжнього півота. Нерухома міра та сама, що в драбини
(`ad_legleft.marks_of`): частка видачі в коридорі довкола цілі плюс
надбавка за балакучість. Для фальшивих ніг вікно відповіді рахується
по справжньому лічильнику: інакше ми міряли б інший зріз ряду.

## Чому це не «перенавчання без розмітки»

Мережа лишається тією самою, яку одобрили. Це замір крихкості, а не
новий прогін: скільки з видачі тримається на класі й скільки — на
чотирьох каналах розмітки. Навчання тут немає взагалі.

Замір іде на процесорі з тієї самої причини, що й `val_series.py`.

Вхід : ваги `research/29-class7dd-legs/models/legleft_blocks4_gauss_clock_band/`
       дані `../data/legleft_blocks4_gauss_clock.npy`
Вихід: results/fake_pivot_BTC_USDT.json — ряд для вкладки і три міри

Запуск:
    python3 research/32-loss-ladder/scripts/fake_pivot.py
    python3 research/32-loss-ladder/scripts/fake_pivot.py --step 300
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
SEED = 17
DEVICE = "cpu"                # див. val_series.py → «Чому замір іде на процесорі»
STEP = 150                    # довжина фальшивої ноги: рівно вікно відповіді
DEEP = 4                      # скільки фальшивих ніг заходить у памʼять
HALF = 105                    # пів події сітки 210 с
OUT = f"fake_pivot_{PAIR}.json"
SCRIPT = "research/32-loss-ladder/scripts/fake_pivot.py"
KINDS = ("real", "fake", "blind")
TITLES = {"real": "розмітка", "fake": f"кожні {STEP}", "blind": "сліпий"}


# ------------------------------------------------------------------ дрібниці

def rounded(values, digits: int = 1) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def runs_of(rows: list, picked: list) -> list:
    """Суцільні відрізки подій: ноги через дірку в ряді не зшиваються.

    Сусідні ноги йдуть подія в подію, але там, де в ряді була дірка
    довша за годину, нога викинута — і між її сусідами лишається діра.
    Фальшива нога через таку діру не кладеться: памʼять поїхала б по
    подіях, яких мережа не бачила.
    """
    out = []
    for one in picked:
        row = rows[one]
        if out and out[-1][1] + 1 == row["first"]:
            out[-1] = (out[-1][0], row["last"])
        else:
            out.append((row["first"], row["last"]))
    return [(int(one), int(two)) for one, two in out]


def cut(spans: list, step: int = STEP, deep: int = DEEP) -> list:
    """Фальшиві ноги: рівні шматки по `step` подій усередині відрізка."""
    out = []
    for begin, end in spans:
        start = begin
        while start <= end:
            stop = min(start + step - 1, end)
            out.append({"hist": max(begin, start - deep * step),
                        "first": start, "last": stop,
                        "events": stop - start + 1,
                        "part": "val", "pair": PAIR, "kind": "up",
                        "history": 0,
                        "steps": stop - max(begin, start - deep * step) + 1})
            start = stop + 1
    return out


def clock_table(x, index: np.ndarray, step: np.ndarray) -> dict:
    """Що стоїть у `leg:guess` на кожному номері кроку — з самих даних.

    Відповідь лічильника — медіана залишку серед train-подій із тим
    самим номером кроку, і вона вже порахована при побудові датасету.
    Замість того щоб рахувати її вдруге (і ризикнути розійтись із
    датасетом), вона зчитується з готового каналу: значення однакове
    скрізь, де лічильник однаковий.
    """
    table = {}
    for place, walked in zip(index, step):
        key = int(walked)
        if key not in table:
            table[key] = (float(x[place, -3]), float(x[place, -2]))
    return table


def faked(built: dict, rows: list, picked: list, legs: list, table: dict,
          blind: bool) -> tuple:
    """Копія ряду з підробленими каналами розмітки і ноги з новими межами.

    Зрізається тільки той шматок ряду, який потрібен: від найранішої
    памʼяті до останньої події. Індекси ніг зсуваються на його початок,
    тому `tensors` читає рівно ті самі події.
    """
    low = min(one["hist"] for one in legs)
    high = max(one["last"] for one in legs)
    piece = np.array(built["x"][low:high + 1], dtype=np.float32)
    known = {key: value for key, value in table.items() if key < STEP}
    for one in legs:
        walked = np.arange(one["last"] - one["first"] + 1)
        at = one["first"] - low
        for place, number in enumerate(walked):
            got = known.get(int(number))
            if got is None:
                continue
            piece[at + place, -3] = got[0]      # leg:step
            piece[at + place, -2] = got[1]      # leg:guess
        piece[at:at + len(walked), -1] = 1.0    # leg:open — вікно відкрите
        if blind:
            piece[at:at + len(walked), -4] = 0.0   # leg:up — середина дзвона
    moved = [{**one, "hist": one["hist"] - low, "first": one["first"] - low,
              "last": one["last"] - low} for one in legs]
    return {**built, "x": piece}, moved


# -------------------------------------------------------------------- прохід

def marks(said: np.ndarray, truth: np.ndarray, step: np.ndarray,
          ad) -> dict:
    """Нерухома міра драбини на справжньому вікні відповіді.

    Вікно береться по **справжньому** лічильнику: питання одне й те саме
    для всіх трьох постановок, інакше числа не порівнюються.
    """
    talk = step < ad.base.WINDOW
    share = said[talk] / np.maximum(truth[talk], 1.0)
    near = float(((share >= ad.base.BAND[0])
                  & (share <= ad.base.BAND[1])).mean())
    wide = float(((share >= ad.base.WIDE[0])
                  & (share <= ad.base.WIDE[1])).mean())
    loud = (float(np.median(np.abs(said[~talk]))) / ad.base.MEASURE
            if (~talk).any() else 0.0)
    after = said[~talk] / np.maximum(truth[~talk], 1.0)
    return {"mark": round(1.0 - (near + wide) / 2.0 + loud, 4),
            "near": round(near, 4), "wide": round(wide, 4),
            "loud": round(loud, 4),
            "err": round(float(np.median(np.abs(said[talk] - truth[talk]))), 1),
            "err_all": round(float(np.median(np.abs(said - truth))), 1),
            "said_after": round(float(np.median(said[~talk])), 1)
            if (~talk).any() else None,
            "near_after": round(float(((after >= ad.base.WIDE[0])
                                       & (after <= ad.base.WIDE[1])).mean()), 4)
            if (~talk).any() else None,
            "events": int(said.size), "window": int(talk.sum())}


def main() -> None:
    global STEP
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--step", type=int, default=STEP)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    STEP = args.step
    TITLES["fake"] = f"кожні {STEP}"

    sys.path.insert(0, str(SCRIPTS))
    import ad_legleft as ad
    import val_series as series

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    picked = [one for one, row in enumerate(rows)
              if row["part"] == "val" and row["pair"] == PAIR]
    index = np.concatenate([np.arange(rows[one]["first"],
                                      rows[one]["last"] + 1)
                            for one in picked])
    step = np.concatenate([np.arange(rows[one]["events"])
                           for one in picked])
    model, _ = ad.build(ctx, SEED)
    series.lift(model, ad.APPROVED / "model.pt")

    block = ad.base.guess(model, built, rows, picked, DEVICE)
    got = {"real": {"said": np.asarray(block["said"], dtype=float),
                    "truth": np.asarray(block["truth"], dtype=float)}}
    spans = runs_of(rows, picked)
    legs = cut(spans, STEP)
    table = clock_table(built["x"], index, step)
    for kind, blind in (("fake", False), ("blind", True)):
        cooked, moved = faked(built, rows, picked, legs, table, blind)
        order = list(range(len(moved)))
        block = ad.base.guess(model, cooked, moved, order, DEVICE)
        said = np.asarray(block["said"], dtype=float)
        if len(said) != len(index):
            raise SystemExit(f"{kind}: видача і вісь подій розʼїхались")
        got[kind] = {"said": said}
        del cooked

    truth = got["real"]["truth"]
    counter = np.array([np.expm1(table.get(int(one), (0.0, 0.0))[1]
                                 * np.log1p(3000.0))
                        for one in np.minimum(step, STEP - 1)])
    report = {kind: marks(got[kind]["said"], truth, step, ad)
              for kind in KINDS}
    write(got, truth, step, counter, index, built, legs, report, args.out)


def write(got: dict, truth, step, counter, index, built, legs, report,
          out: Path) -> dict:
    """Кістяк ряду з `val_series`, три лінії видачі і межі фальшивих ніг."""
    import val_series as series

    bones = series.skeleton()
    axis = np.asarray(bones["t"], dtype=np.int64)
    stamps = np.asarray(built["t"][index], dtype=np.int64)
    where = series.nearest(axis, stamps, HALF)
    good = where >= 0
    keep = np.sort(where[good])
    span = slice(int(keep[0]), int(keep[-1]) + 1)
    total = len(axis)

    def lay(values) -> list:
        column = np.full(total, np.nan)
        column[where[good]] = np.asarray(values, dtype=float)[good]
        return rounded(column[span], 1)

    block = {"script": SCRIPT, "ready": True, "pair": PAIR, "model": "legleft",
             "device": DEVICE, "step": STEP, "deep": DEEP,
             "window": 150, "event_seconds": 210,
             "class": bones["class"], "threshold": bones["threshold"],
             "period": bones["period"],
             "events": int(len(axis[span])),
             "from": int(axis[span][0]), "to": int(axis[span][-1]),
             "legs": len(legs), "lost": int((~good).sum()),
             "t": [int(one) for one in axis[span]],
             "price": [round(float(one), 2) for one in bones["price"][span]],
             "ema": [round(float(one), 2) for one in bones["ema"][span]],
             "pivots": [one for one in bones["pivots"]
                        if axis[span][0] <= one["t"] <= axis[span][-1]],
             "cuts": [int(built["t"][one["first"]]) for one in legs],
             "marks": report,
             "lines": [{"key": "truth", "title": "насправді", "kind": "truth"},
                       *({"key": kind, "title": TITLES[kind], "kind": kind}
                         for kind in KINDS),
                       {"key": "counter", "title": "лічильник",
                        "kind": "counter"}]}
    block["truth"] = lay(truth)
    for kind in KINDS:
        block[kind] = lay(got[kind]["said"])
    block["counter"] = lay(counter)
    out.mkdir(parents=True, exist_ok=True)
    path = out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} — {block['events']} подій, "
          f"{len(legs)} фальшивих ніг")
    for kind in KINDS:
        one = report[kind]
        print(f"  {TITLES[kind]:>10}: міра {one['mark']} · коридор "
              f"{one['near']:.3f}/{one['wide']:.3f} · похибка {one['err']} "
              f"подій · після вікна {one['said_after']}")
    return block


if __name__ == "__main__":
    main()
