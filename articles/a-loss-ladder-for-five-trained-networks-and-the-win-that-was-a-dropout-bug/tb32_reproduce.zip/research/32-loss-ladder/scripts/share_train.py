"""Частка ноги без розмітки: мережа сама бачить, що нога скінчилась.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Одна відповідь на кожній події — **скільки ноги пройдено**:

    0.0  нога щойно почалась
    0.5  пройдено половину
    1.0  нога скінчилась

Форма відповіді в часі — пилка: біля нуля на початку, рівний ріст разом
із ногою, одиниця на самому кінці й **обвал у нуль**, який мережа
робить сама, побачивши по фічах, що нога скінчилась.

## Розмітки на вході немає взагалі

Чотири канали розмітки (`leg:up`, `leg:step`, `leg:guess`, `leg:open`)
погашені, а канал «своя нога» стоїть одиницею на всьому ряді. Ряд
ріжеться **не по ногах**, а рівними вікнами `WIN` подій, і перші `WARM`
подій вікна не міряються й не штрафуються: там памʼять LSTM ще
порожня. Тому межа ноги не приходить у мережу ні каналом, ні
нарізкою — її треба вгадати.

Розмітка лишається тільки в **цілі**: частка справжньої ноги зігзага
2.3 % на ема10. Інакше вчити нема на чому.

## Штраф за формою

| Доданок | Що питає | Ціна |
| ------- | -------- | ---- |
| `cliff` | видача висока там, де нога **вже нова** — тобто не впала | найдорожче, ×60 |
| `tail`  | не доросла до одиниці в кінці ноги | заниження ×5 у хвості |
| `fall`  | спуск там, де нога ще йде | ×40 на одиницю падіння |
| коридор | решта відхилень, експонента поза мертвою зоною | вниз ×6, вгору ×2 |

Спуск заборонений **не скрізь**, а рівно там, де правда росте: на
самому півоті падіння — це те, чого від мережі й хочуть. Два доданки
дивляться в різні боки й ніде не перетинаються.

Безштрафова зона звужується з епохами: 20 % на першій, 3 % на шостій.
Спочатку питається форма кривої, потім її точність.

## Чим міряємо

Нерухома міра — коридор довкола справжньої частки:

    mark = 1 − (near + wide) / 2      менше краще
    near  частка видачі ближче за 0.05 до правди
    wide  те саме для 0.15

Краща епоха обирається не самою мірою — рівна лінія посередині дає
пристойний коридор і жодної форми, — а оцінкою `mark + (1 − розмах)/2 +
(1 − обвал)/2`: точність і форма разом.

Поруч — числа **форми**, заради якої все й робиться:

    голова   медіана видачі на перших 10 % ноги      -> має бути ~0
    хвіст    медіана видачі на останніх 10 %         -> має бути ~1
    розмах   хвіст − голова                          -> висота пилки
    обвал    медіана падіння видачі на справжньому півоті
    ріст     медіана кореляції видачі з правдою всередині ноги

Межа знизу — сам лічильник розмітки, `крок / (крок + медіана залишку
train)`. Він рахується без мережі й показує, скільки коштує сама
розмітка; мережа його не бачить.

Вхід : ваги `research/29-class7dd-legs/models/legleft_blocks4_gauss_clock_band/`
       (тулуб мережі; голова нова — відповідь тепер інша)
Вихід: results/share_train.json      — крива, міри, форма
       models/legshare/model.pt      — ваги найкращої епохи

Запуск:
    python3 research/32-loss-ladder/scripts/share_train.py --epochs 6 --force
    python3 research/32-loss-ladder/scripts/share_train.py --epochs 4 --resume
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
NAME = "legshare"
SEED = 0
WIN = 1200                 # подій у вікні: стільки бачить один прохід
WARM = 300                 # з них перші не міряються — памʼять ще порожня
CLOCK = 3000.0             # чим стиснуті канали лічильника (для межі знизу)
EDGE = 0.1                 # що вважається початком і кінцем ноги
BATCH = 4                  # вікон у батчі: дрібніше — більше кроків
BUDGET = 20_000_000        # стеля уваги в батчі: `довжина² × вікон`
LR = 3e-4
EPOCHS = 40                # епоха тут дешева: вікон небагато
PATIENCE = 10
NEAR = 0.05                # вузький коридор міри, у частках ноги
WIDE = 0.15                # широкий
FREE = (0.20, 0.14, 0.10, 0.07, 0.05, 0.03)
STEP = 0.05                # найбільший приріст частки за одну подію
FADE = 0.25                # найбільша частка лінії, що спадає за подію
HOT = 20                   # скільки подій після півота вважати «обнулись»
KNOBS = {"down": 6.0, "up": 2.0, "grow": 5.0, "fall": 120.0, "cliff": 60.0,
         "tail": 4.0, "edge": EDGE, "reset": 3.0, "hot": 10.0,
         "step": STEP, "fade": FADE}
SCRIPT = "research/32-loss-ladder/scripts/share_train.py"


# ------------------------------------------------------------------ правда

def edges_of(rows: list, picked: list, total: int) -> tuple:
    """Початок і кінець справжньої ноги на кожній події ряду."""
    first = np.full(total, -1, dtype=np.int64)
    last = np.full(total, -1, dtype=np.int64)
    for one in picked:
        row = rows[one]
        first[row["first"]:row["last"] + 1] = row["first"]
        last[row["first"]:row["last"] + 1] = row["last"]
    return first, last


def truth_of(first: np.ndarray, last: np.ndarray) -> np.ndarray:
    """Частка ноги: 0 на першій події, 1 на останній, далі знову 0."""
    out = np.full(len(first), np.nan, dtype=np.float32)
    good = first >= 0
    place = np.flatnonzero(good)
    out[good] = ((place - first[good])
                 / np.maximum(last[good] - first[good], 1))
    return out


def counter_line(x, rows: list, picked: list, total: int) -> np.ndarray:
    """Межа знизу: частка з самого лічильника розмітки, без мережі.

    `leg:guess` — медіана залишку train на цьому кроці, стиснута `log1p`
    і поділена на `log1p(CLOCK)` (`legleft_data.clock_of`). Розтискаємо
    її назад у події й ділимо крок на повну довжину. Мережа цього
    каналу не бачить — лінія стоїть у звіті для порівняння.
    """
    scale = float(np.log1p(CLOCK))
    out = np.full(total, np.nan)
    for one in picked:
        row = rows[one]
        piece = slice(row["first"], row["last"] + 1)
        guess = np.expm1(np.asarray(x[piece, -2], dtype=np.float64) * scale)
        walk = np.arange(row["events"], dtype=np.float64)
        out[piece] = walk / np.maximum(walk + guess, 1.0)
    return out


# ------------------------------------------------------------------- рамка

def spans_of(rows: list, picked: list) -> list:
    """Суцільні відрізки подій: через діру в ряді вікно не йде."""
    out = []
    for one in picked:
        row = rows[one]
        if out and out[-1]["pair"] == row["pair"] \
                and out[-1]["end"] + 1 == row["first"]:
            out[-1]["end"] = int(row["last"])
        else:
            out.append({"pair": row["pair"], "begin": int(row["first"]),
                        "end": int(row["last"])})
    return out


def windows(spans: list, win: int = WIN, warm: int = WARM) -> list:
    """Рівні вікна ряду; перші `warm` подій кожного — розігрів памʼяті.

    Вікна йдуть кроком `win − warm`, тому заміряні шматки стикуються
    подія в подію: жодна подія не міряється двічі й жодна не губиться,
    крім перших `warm` подій відрізка, де памʼяті взятись нізвідки.
    """
    out = []
    for one in spans:
        at = one["begin"]
        while at + warm <= one["end"]:
            last = min(at + win - 1, one["end"])
            out.append({"hist": at, "first": at + warm, "last": last,
                        "events": last - (at + warm) + 1,
                        "steps": last - at + 1, "pair": one["pair"]})
            at += win - warm
    return out


def blinded(piece: np.ndarray) -> np.ndarray:
    """Чотири канали розмітки геть: напрямок, лічильник, відповідь, вікно."""
    piece[:, -4:] = 0.0
    return piece


def frame_of(built: dict, one: dict) -> np.ndarray:
    """Канали вікна: клас як є, розмітка погашена."""
    # копія обовʼязкова: `built["x"]` — memmap, і писати в нього не можна
    return blinded(np.array(built["x"][one["hist"]:one["last"] + 1],
                            dtype=np.float32))


def tensors(built: dict, chunk: list, truth: np.ndarray, device: str):
    """Батч вікон: клас без розмітки, ціль — частка справжньої ноги."""
    import torch

    length = max(one["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    own = np.zeros((len(chunk), length), dtype=np.float32)
    hot = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        steps = one["steps"]
        x[number, :steps, :-1] = frame_of(built, one)
        x[number, :steps, -1] = 1.0      # «своя нога» скрізь: межі немає
        piece = truth[one["hist"]:one["last"] + 1]
        good = np.isfinite(piece)
        y[number, :steps] = np.where(good, piece, 0.0)
        mask[number, :steps] = True
        own[number, steps - one["events"]:steps] = \
            good[steps - one["events"]:].astype(np.float32)
        hot[number, :steps] = hot_of(piece, good)
    lengths = torch.tensor([one["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device), torch.from_numpy(y).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(own).to(device),
            torch.from_numpy(hot).to(device))


def hot_of(piece: np.ndarray, good: np.ndarray, hold: int = HOT):
    """Мітка «нога щойно почалась»: сам півот і `hold − 1` подій по ньому.

    Вимагати влучення в саму подію півота безглуздо: у цьому проєкті
    розворот стає видно по фічах через десятки подій після себе
    (дослідження 29, «за скільки подій видно нову ногу»). Обнулитись
    на два десятки подій пізніше — не помилка: правда там ще менша за
    0.03, і лінія просто впаде трохи згодом.
    """
    start = good & (piece == 0.0)
    out = np.zeros(len(piece), dtype=np.float32)
    for back in range(hold):
        if back:
            out[back:] = np.maximum(out[back:], start[:len(start) - back])
        else:
            out[:] = start.astype(np.float32)
    return out


def packed(rows: list, size: int = BATCH, budget: int = BUDGET) -> list:
    """Батчі під стелю уваги: вона росте як `довжина² × вікон у батчі`."""
    out, chunk, longest = [], [], 0
    for row in rows:
        far = max(longest, row["steps"])
        if chunk and (len(chunk) >= size
                      or far * far * (len(chunk) + 1) > budget):
            out.append(chunk)
            chunk, longest = [], 0
            far = row["steps"]
        chunk.append(row)
        longest = far
    if chunk:
        out.append(chunk)
    return out


def free_of(device: str) -> None:
    """Віддати кеш прискорювача: без цього довгі вікна його вичерпують."""
    import torch

    if device == "mps" and hasattr(torch, "mps"):
        torch.mps.empty_cache()
    elif device == "cuda":
        torch.cuda.empty_cache()


def quiet(model):
    """Dropout геть: на `mps` `eval()` його не вимикає після навчання."""
    class Off:
        def __enter__(self):
            self.was = model.drop.p
            model.drop.p = 0.0
            model.eval()
            return model

        def __exit__(self, *_):
            model.drop.p = self.was
    return Off()


# ------------------------------------------------------------------ втрата

def saw_of(out, step: float = STEP, fade: float = FADE,
           dead: float = 0.0):
    """Пилка з двох чисел на подію: «обнулись» і «підрости».

    Мережа більше не каже частку напряму. Вона каже `r` — наскільки
    зараз треба обнулитись — і `g` — наскільки підрости, а сама лінія
    будується накопиченням:

        s(t) = (1 − r) · min(s(t−1) + g, 1)

    Це і є форма, яку від неї хочуть, вбудована в конструкцію: вниз
    лінія не може піти інакше, ніж через власний сигнал обнулення, а
    вгору йде рівно доти, доки мережа додає приріст. Вільна сигмоїда
    цього не тримала: найдешевша її відповідь — рівна лінія посередині,
    і градієнт вів саме туди.

    `g` обмежений `step` згори: нога коротша за `1 / step` подій просто
    не існує, і без стелі мережа могла б стрибати з нуля в одиницю за
    одну подію.

Обнулення **не миттєве**: за одну подію лінія може спасти щонайбільше
    на `fade` своєї висоти. Щоб упасти в нуль, мережа має тримати сигнал
    десятки подій поспіль.

    Це прямо з заміру. Одним натиском не виходило: пущений на волю
    детектор брав 78 % розворотів ціною 42 обнулень на тисячу подій там,
    де справжніх два, а на правильній частоті (пауза в 300 подій) падав
    до 11–17 % влучень. Отже сигнал про кінець ноги в класі **розмазаний
    по десятках подій**, а не стоїть у самому півоті, — і брати його
    треба накопиченням, а не одним рішенням.
    """
    import torch

    reset = torch.sigmoid(out[..., 0])
    grow = torch.sigmoid(out[..., 1]) * step
    # `dead` — поріг рішучості: сигнал слабший за нього лінію не чіпає
    # взагалі, сильний роняє її так само, як і раніше. За нуля все як
    # було — етап 7 від цього не міняється.
    pull = reset if dead <= 0.0 \
        else ((reset - dead) / (1.0 - dead)).clamp(0.0, 1.0)
    share, now = [], torch.zeros_like(reset[:, 0])
    for place in range(reset.shape[1]):
        now = (1.0 - fade * pull[:, place]) \
            * (now + grow[:, place]).clamp(max=1.0)
        share.append(now)
    return torch.stack(share, dim=1), reset


def free_at(number: int, total: int = EPOCHS, ladder=FREE) -> float:
    """Безштрафова зона епохи: 20 % на початку прогону, 3 % у кінці.

    Драбина розтягується на **весь** прогін, а не на перші шість епох:
    інакше при довгому прогоні мережа майже весь час стоїть під
    найвужчою зоною, не встигнувши взяти форму.
    """
    place = int((max(number, 1) - 1) / max(total, 1) * len(ladder))
    return float(ladder[min(place, len(ladder) - 1)])


def score_of(one: dict) -> float:
    """Чим обирається краща епоха: точність **і** форма разом.

    Сама міра-коридор обрала б найрівнішу лінію: стала відповідь
    посередині дає пристойний коридор і жодної пилки. Тому до неї
    додається те, чого від мережі й хочуть, — розмах голова→хвіст і
    обвал на півоті. Обидва «менше краще», обидва в межах одиниці.
    """
    def one_of(key):
        got = one.get(key)
        return 0.0 if got is None else min(max(float(got), 0.0), 1.0)

    return round(one["mark"] + (1.0 - one_of("swing")) / 2.0
                 + (1.0 - one_of("cliff")) / 2.0, 4)


def share_step(said, true, chain, knobs: dict, free: float):
    """Штраф на крок: коридор, обвал, хвіст і спуск.

    `chain` — чи є в кроку попередник у тому самому вікні: на першій
    події падати нема з чого.

    Ключове тут — **де що заборонено**. Спуск карається рівно там, де
    правда росте, тобто всередині ноги. На півоті правда падає з
    одиниці в нуль, і там карається зворотне: видача, яка не впала.
    Два доданки ніде не перетинаються, тому мережа не опиняється між
    двома штрафами водночас.
    """
    import torch

    edge = knobs["edge"]
    gap = ((said - true).abs() - free).clamp(min=0.0)
    steep = float(np.expm1(knobs["grow"]))
    curve = gap + torch.expm1(knobs["grow"] * gap) / steep
    # хвіст ноги: там заниження дорожчає до `down × (1 + tail)`
    high = ((true - (1.0 - edge)) / edge).clamp(0.0, 1.0)
    side = torch.where(said < true,
                       knobs["down"] * (1.0 + knobs["tail"] * high),
                       torch.full_like(said, knobs["up"]))
    hurt = side * curve
    # нога вже нова, а видача висока — тобто не впала. Найдорожчий доданок,
    # і він лінійно згасає від самого півота до `edge` ноги
    low = ((edge - true) / edge).clamp(0.0, 1.0)
    hurt = hurt + knobs["cliff"] * low * (said - true - free).clamp(min=0.0)
    # спуск всередині ноги: частка пройденого вниз не ходить
    fell = torch.zeros_like(said)
    fell[:, 1:] = (said[:, :-1] - said[:, 1:]).clamp(min=0.0)
    rise = torch.ones_like(said)
    rise[:, 1:] = (true[:, 1:] >= true[:, :-1]).to(said.dtype)
    return hurt + knobs["fall"] * fell * chain * rise


def reset_step(reset, hot, knobs: dict):
    """Прямий сигнал «нога скінчилась» на саме обнулення.

    Форму дає конструкція, але натиснути на кнопку обнулення мережа має
    навчитись по фічах. Подія півота одна на сотні звичайних, тому
    позитив важить `hot` разів більше за негатив.
    """
    import torch

    return knobs["reset"] * torch.nn.functional.binary_cross_entropy(
        reset.clamp(1e-6, 1.0 - 1e-6), hot,
        weight=1.0 + (knobs["hot"] - 1.0) * hot, reduction="none")


# -------------------------------------------------------------------- міра

def fell_of(said: np.ndarray, bounds: list) -> float:
    """Частка подій, де видача впала проти попередньої в тій самій нозі."""
    down, count = 0, 0
    for first, stop in bounds:
        piece = said[first:stop + 1]
        piece = piece[np.isfinite(piece)]
        if len(piece) < 2:
            continue
        down += int((np.diff(piece) < 0).sum())
        count += len(piece) - 1
    return round(down / count, 4) if count else 0.0


def shape_of(said: np.ndarray, true: np.ndarray, good: np.ndarray,
             bounds: list, edge: float = EDGE, gap: int = 10) -> dict:
    """Числа форми: голова, хвіст, розмах, обвал і ріст.

    Вони й кажуть, чи зʼявилась пилка. Міра-коридор цього не показує:
    рівна лінія посередині дає непоганий коридор і жодної форми.
    """
    head = said[good & (true < edge)]
    tail = said[good & (true > 1.0 - edge)]
    rises, drops = [], []
    for first, stop in bounds:
        piece, real = said[first:stop + 1], true[first:stop + 1]
        fine = np.isfinite(piece) & np.isfinite(real)
        if fine.sum() > 50 and float(np.std(piece[fine])) > 1e-6:
            rises.append(float(np.corrcoef(real[fine], piece[fine])[0, 1]))
        before = said[max(first - gap, 0):first]
        after = said[first:first + gap]
        before, after = before[np.isfinite(before)], after[np.isfinite(after)]
        if len(before) and len(after):
            drops.append(float(before.max() - after.min()))
    return {"head": round(float(np.median(head)), 4) if len(head) else None,
            "tail": round(float(np.median(tail)), 4) if len(tail) else None,
            "swing": round(float(np.median(tail) - np.median(head)), 4)
            if len(head) and len(tail) else None,
            "cliff": round(float(np.median(drops)), 4) if drops else None,
            "rise": round(float(np.median(rises)), 4) if rises else None}


def marks(said: np.ndarray, true: np.ndarray, seen: np.ndarray,
          bounds: list) -> dict:
    """Нерухома міра плюс числа форми."""
    good = np.isfinite(said) & np.isfinite(true) & seen
    if not good.any():
        return {"mark": float("inf"), "near": 0.0, "wide": 0.0, "err": None,
                "bias": None, "fell": 0.0, "events": 0, "cover": 0.0,
                "head": None, "tail": None, "swing": None, "cliff": None,
                "rise": None}
    gap = np.abs(said[good] - true[good])
    near = float((gap <= NEAR).mean())
    wide = float((gap <= WIDE).mean())
    return {"mark": round(1.0 - (near + wide) / 2.0, 4),
            "near": round(near, 4), "wide": round(wide, 4),
            "err": round(float(np.median(gap)), 4),
            # зсув: куди мережа хилить усією лінією
            "bias": round(float(np.median(said[good] - true[good])), 4),
            "fell": fell_of(said, bounds),
            "cover": round(float(good.sum()) / float(seen.sum()), 4),
            "events": int(good.sum()),
            **shape_of(said, true, good, bounds)}


def said_on(model, built: dict, chunk: list, device: str,
            dead: float = 0.0) -> list:
    """Видача в частках на батчі вікон: сигмоїда, без жодного `expm1`."""
    import torch

    length = max(one["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    for number, one in enumerate(chunk):
        steps = one["steps"]
        x[number, :steps, :-1] = frame_of(built, one)
        x[number, :steps, -1] = 1.0
        mask[number, :steps] = True
    lengths = torch.tensor([one["steps"] for one in chunk])
    with torch.no_grad():
        out, reset = saw_of(model(torch.from_numpy(x).to(device),
                                  torch.from_numpy(mask).to(device), lengths),
                            STEP, FADE, dead)
    return [(out[number, one["steps"] - one["events"]:one["steps"]]
             .float().cpu().numpy(),
             reset[number, one["steps"] - one["events"]:one["steps"]]
             .float().cpu().numpy())
            for number, one in enumerate(chunk)]


def in_chunks(model, built: dict, rows: list, device: str,
              size: int = BATCH, dead: float = 0.0) -> list:
    """Той самий прохід батчами; що не влізло — ділиться навпіл."""
    out = []
    for chunk in packed(rows, size):
        try:
            out.extend(said_on(model, built, chunk, device, dead))
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            out.extend(in_chunks(model, built, chunk, device,
                                 max(1, len(chunk) // 2), dead))
        free_of(device)
    return out


def measure(model, built: dict, rows: list, picked: list, boxes: list,
            true: np.ndarray, seen: np.ndarray, device: str,
            dead: float = 0.0) -> dict:
    """Видача на всіх вікнах val, зібрана назад у ряд."""
    said = np.full(len(true), np.nan)
    fired = np.full(len(true), np.nan)
    with quiet(model):
        for one, got in zip(boxes, in_chunks(model, built, boxes, device,
                                            BATCH, dead)):
            said[one["first"]:one["last"] + 1] = got[0]
            fired[one["first"]:one["last"] + 1] = got[1]
    bounds = [(rows[one]["first"], rows[one]["last"]) for one in picked]
    return {**marks(said, true, seen, bounds),
            **resets_of(fired, true, seen), "said": said, "fired": fired,
            "legs": len(picked), "boxes": len(boxes)}


def resets_of(fired: np.ndarray, true: np.ndarray, seen: np.ndarray,
              near: int = 20, level: float = 0.5) -> dict:
    """Де мережа натиснула «обнулись» і чи влучила в справжні півоти.

    `often` — скільки обнулень на тисячу подій; `found` — частка
    справжніх півотів, біля яких обнулення є; `spare` — частка обнулень,
    біля яких півота немає.
    """
    hit = np.flatnonzero(seen & np.isfinite(fired) & (fired > level))
    pivots = np.flatnonzero(seen & np.isfinite(true) & (true == 0.0))
    total = int(seen.sum())
    out = {"often": round(1000.0 * len(hit) / max(total, 1), 2),
           "resets": int(len(hit))}
    if not len(hit) or not len(pivots):
        return {**out, "found": 0.0, "spare": 1.0 if len(hit) else 0.0}
    gap = np.abs(pivots[:, None] - hit[None, :])
    return {**out,
            "found": round(float((gap.min(axis=1) <= near).mean()), 4),
            "spare": round(float((gap.min(axis=0) > near).mean()), 4)}


# ---------------------------------------------------------------- навчання

def epoch_of(model, tune, built: dict, boxes: list, true: np.ndarray,
             device: str, seed: int, free: float, knobs: dict,
             only: bool = False) -> float:
    """Одна епоха на вікнах ряду.

    `only` — фаза детектора: штрафується сам сигнал «обнулись» і більш
    нічого. Спочатку мережа має навчитись **бачити** кінець ноги, і
    тільки потім будувати з цього лінію: інакше форма тягне ваги в
    один бік, а детектор у другий, і перемагає найдешевша рівна лінія.
    """
    import torch

    model.train()
    chunks = packed(boxes)
    order = list(range(len(chunks)))
    np.random.default_rng(seed).shuffle(order)
    total, seen = 0.0, 0

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, hot = tensors(built, chunk, true, device)
        if scale is None:
            scale = own.sum()
        said, reset = saw_of(model(x, mask, lengths), knobs["step"])
        chain = own.clone()
        chain[:, :1] = 0.0
        chain[:, 1:] = chain[:, 1:] * own[:, :-1]
        step = reset_step(reset, hot, knobs)
        if not only:
            step = step + share_step(said, y, chain, knobs, free)
        piece = (step * own).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum().item()), scale

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2]

    for number in order:
        tune.zero_grad()
        got, count, _ = learn(chunks[number])
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        free_of(device)
        total += got * count
        seen += count
    return total / max(seen, 1)


def build_of(ctx: dict, ad, seed: int):
    """Мережа з **двома** виходами: «обнулись» і «підрости».

    Тулуб береться з одобрених ваг дослідження 29 — він уже вміє вести
    ногу. Голова нова й інша за формою (два числа замість одного),
    тому з одобреного стану вона просто викидається.
    """
    import torch
    from leg_end_net import LegEnd

    torch.manual_seed(seed)
    model = LegEnd(features=ctx["built"]["x"].shape[1] + 1, hidden=ad.HIDDEN,
                   heads=ad.HEADS, attention=True,
                   outputs=2).to(ctx["device"])
    was = torch.load(ad.APPROVED / "model.pt", map_location="cpu")
    model.load_state_dict({key: value for key, value in was.items()
                           if not key.startswith("head.")}, strict=False)
    return model


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--detect", type=int, default=6,
                        help="перші епохи — тільки детектор кінця ноги")
    parser.add_argument("--minutes", type=float, default=200.0)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--win", type=int, default=WIN)
    parser.add_argument("--warm", type=int, default=WARM)
    parser.add_argument("--resume", action="store_true",
                        help="доучити те, що вже лежить у models/")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import val_series as series

    ctx = ad.prepare(force=args.force)
    device, rows, built = ctx["device"], ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    first, last = edges_of(rows, train + val, total)
    true = truth_of(first, last)
    train_boxes = windows(spans_of(rows, train), args.win, args.warm)
    val_boxes = windows(spans_of(rows, val), args.win, args.warm)
    seen = np.zeros(total, dtype=bool)
    for one in val_boxes:
        seen[one["first"]:one["last"] + 1] = True
    print(f"вікон: train {len(train_boxes)}, val {len(val_boxes)} по "
          f"{args.win} подій (розігрів {args.warm}) · пристрій {device}")

    counter = marks(counter_line(built["x"], rows, val, total), true, seen,
                    [(rows[one]["first"], rows[one]["last"]) for one in val])
    print(f"лічильник розмітки: міра {counter['mark']} · коридор "
          f"{counter['near']:.3f}/{counter['wide']:.3f} · голова "
          f"{counter['head']} · хвіст {counter['tail']} · обвал "
          f"{counter['cliff']}")

    model = build_of(ctx, ad, SEED)
    keep = MODELS / NAME
    keep.mkdir(parents=True, exist_ok=True)
    tune = torch.optim.AdamW(model.parameters(), lr=args.lr)
    curve, best, stale = [], None, 0
    path = RESULTS / "share_train.json"
    if args.resume and path.exists() and (keep / "model.pt").exists():
        was = json.loads(path.read_text(encoding="utf-8"))
        series.lift(model, keep / "model.pt")
        if (keep / "tune.pt").exists():
            tune.load_state_dict(torch.load(keep / "tune.pt",
                                            map_location="cpu"))
        curve, best = list(was.get("curve", [])), was.get("best")
        print(f"продовжую з епохи {len(curve) + 1}")

    began = time.time()
    for number in range(len(curve) + 1, len(curve) + args.epochs + 1):
        free = free_at(number, len(curve) + args.epochs)
        only = number <= args.detect
        loss = epoch_of(model, tune, built, train_boxes, true, device,
                        SEED + number, free, KNOBS, only)
        free_of(device)
        now = measure(model, built, rows, val, val_boxes, true, seen, device)
        free_of(device)
        spent = (time.time() - began) / 60.0
        step = {"epoch": number, "loss": round(loss, 4), "free": free,
                "detect": bool(only),
                **{key: value for key, value in now.items()
                   if key not in ("said", "fired")}}
        step["score"] = score_of(step)
        curve.append({**step, "minutes": round(spent, 1)})
        print(f"  епоха {number:>2}{' (детектор)' if only else ''} · "
              f"зона {free:.2f} · втрата {loss:.4f} · "
              f"міра {now['mark']} · коридор {now['near']:.3f}/"
              f"{now['wide']:.3f} · голова {now['head']} · хвіст "
              f"{now['tail']} · обвал {now['cliff']} · ріст {now['rise']} · "
              f"обнулень {now['often']}/1000 (влучила {now['found']}, "
              f"дарма {now['spare']}) · оцінка {step['score']} · "
              f"{spent:.1f} хв")
        # епохи фази детектора у вибір не йдуть: лінію там ніхто не вчив
        if not only and (best is None or step["score"] < best["score"]):
            best = {"epoch": number, "free": free, "score": step["score"],
                    **{key: value for key, value in now.items()
                       if key not in ("said", "fired")}}
            stale = 0
            torch.save(model.state_dict(), keep / "model.pt")
            torch.save(tune.state_dict(), keep / "tune.pt")
        elif not only:
            stale += 1
        save(curve, best, counter, args, ad, device, began)
        if stale >= PATIENCE or spent > args.minutes:
            break
    save(curve, best, counter, args, ad, device, began)


def save(curve: list, best, counter: dict, args, ad, device: str,
         began: float) -> None:
    """Звіт пишеться після кожної епохи: прогін довгий, і його рвуть."""
    report = {"script": SCRIPT, "ready": True, "model": NAME,
              "lr": args.lr, "win": args.win, "warm": args.warm,
              "near": NEAR, "wide": WIDE, "edge": EDGE, "free": list(FREE),
              "knobs": KNOBS, "device": device,
              "approved": str((ad.APPROVED / "model.pt")
                              .relative_to(PROJECT_ROOT)),
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "counter": counter, "curve": curve, "best": best,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    path = RESULTS / "share_train.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
