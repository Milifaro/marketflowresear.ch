#!/bin/sh
# Драбина втрат по всіх одобрених мережах: research/32-loss-ladder/
#
# Прогони йдуть двома чергами, бо вони на різних пристроях і не
# заважають одне одному:
#
#   MPS  legleft -> zone -> legtip      мережі на прискорювачі
#   CPU  hazard100 -> hazard4           мережі дослідження 20, крок по
#                                       одній події — прискорювач тут
#                                       не допомагає
#
# Кожен прогін має свою стелю часу: драбина довга, а машина одна.
#
# Запуск:
#   sh research/32-loss-ladder/scripts/run_all.sh          обидві черги
#   sh research/32-loss-ladder/scripts/run_all.sh mps      тільки перша
#   sh research/32-loss-ladder/scripts/run_all.sh cpu      тільки друга

set -u
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
OUT="$ROOT/research/32-loss-ladder/results"
RUN="python3 -u $ROOT/research/32-loss-ladder/scripts/ladder.py"
QUEUE="${1:-all}"

mps() {
    # zone перший: він найдешевший (епоха 0.7 хв), і його драбина
    # встигає цілком, поки legtip тільки розігрівається
    $RUN --model zone   --minutes 60  --attempts 2 --force > "$OUT/zone.log" 2>&1
    $RUN --model legtip --minutes 110 --attempts 2 --force > "$OUT/legtip.log" 2>&1
}

cpu() {
    $RUN --model hazard100 --minutes 150 --attempts 2 --force > "$OUT/hazard100.log" 2>&1
    $RUN --model hazard4   --minutes 150 --attempts 2 --force > "$OUT/hazard4.log" 2>&1
}

case "$QUEUE" in
    mps) mps ;;
    cpu) cpu ;;
    *)   cpu & mps ; wait ;;
esac
