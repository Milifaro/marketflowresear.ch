"""Своя межа зони кожній нозі — за фічами самої ноги, і перевірка методу.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

`zone_length.py` показав, що зона розвороту стоїть не в подіях, а в
частках ноги: надлишок згасає на 10.0 / 9.5 / 9.2 % довжини на коротких,
середніх і довгих ногах. Але «10 % ноги» — усе ще правило для середнього,
а не для цієї конкретної ноги.

Метод перенесено з дослідження 31 (`zones.py`): межа ставиться **за
фічами**, а не за ціною і не за відсотком —

    від точки розвороту йдемо в бік тіла ноги, поки подія несхожа на
    свою ногу; `patience` звичайних подій поспіль закривають зону.

Несхожість — робастний `z` події проти опори **своєї** ноги:

    z_c(t) = |x_c(t) − медіана_c(тіло)| / IQR_c(тіло)
    d(t)   = медіана по каналах z_c(t),  згладжена ковзною медіаною

Поріг «несхожа» — квантиль `d` самої ноги (`LIMIT`), а не стале число:
розкид `d` у ніг різний, і одне число дало б в одній нозі зону на пів
ноги, а в іншій — жодної події.

## Чому метод треба перевіряти окремо

Зона виділяється за фічами — і порівнювати фічі зони з рештою ноги
після цього означає замкнене коло. Тому поруч стоять чотири перевірки:

| перевірка | що ловить |
| --------- | --------- |
| фальшива точка | та сама процедура з випадкової точки тіла ноги: якщо зона там така сама, метод міряє шум |
| вміст зони | події зони проти тіла, `AUC` на ногах val — проти рівної межі «10 % ноги» з тією самою кількістю подій |
| стійкість | ранги довжин зон при `LIMIT` від 0.5 до 0.9: хитка межа не годиться у штраф |
| звʼязок із ногою | чи росте персональна зона з довжиною ноги — і чи це ті самі 10 % |

Два способи рахувати `d` міряються поруч:

    plain    медіана по всіх 410 каналах класу — рецепт дослідження 31
    learned  зважена сума каналів, ваги — з детектора, навченого на
             ногах train відрізняти події біля розвороту від тіла

`learned` навчається **тільки на train**, а міряється на val: ваги
бачать, які канали взагалі говорять про розворот, і не бачать ніг, на
яких їх перевіряють.

Вхід : датасет `legleft_blocks4_gauss_clock` (дослідження 29)
Вихід: results/zone_own.json — довжини зон, чотири перевірки, порівняння

Запуск:
    python3 research/32-loss-ladder/scripts/zone_own.py
    python3 research/32-loss-ladder/scripts/zone_own.py --limit 0.75
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
RESULTS = RESEARCH_DIR / "results"
sys.path.insert(0, str(SCRIPTS))


def sibling(name: str):
    """Сусідній скрипт дослідження — **за шляхом файлу**, а не за іменем.

    У проєкті є другий `pivot_zone.py` (дослідження 22), і звичайний
    `import` під повним прогоном тестів підхоплює той, чия тека раніше
    лягла в `sys.path`. Шлях файлу такої двозначності не має.
    """
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


zone = sibling("pivot_zone")

SEED = 0
CORE = (0.30, 0.70)        # тіло ноги: звідки береться опора
LIMIT = 0.75               # подія несхожа, поки `d` вище цього квантиля ноги
LIMITS = (0.5, 0.6, 0.7, 0.75, 0.8, 0.9)   # сітка для перевірки стійкості
SMOOTH = 5                 # ковзна медіана `d`, подій
PATIENCE = 3               # скільки звичайних подій поспіль закривають зону
CAP = 0.40                 # стеля зони: частка ноги, далі не йдемо
TOP = 40                   # скільки каналів бере `learned`
LEARN = (0, 9)             # на якій відстані від півота вчиться детектор
FLAT = 0.095               # рівна межа для порівняння: частка ноги
SCRIPT = "research/32-loss-ladder/scripts/zone_own.py"
OUT = "zone_own.json"


def rolling_median(values: np.ndarray, window: int) -> np.ndarray:
    """Ковзна медіана по центру; на краях вікно вкорочується."""
    if window <= 1:
        return values
    half = window // 2
    out = np.full(values.shape, np.nan)
    for index in range(len(values)):
        piece = values[max(0, index - half):index + half + 1]
        piece = piece[np.isfinite(piece)]
        if piece.size:
            out[index] = np.median(piece)
    return out


def core_of(events: int, core: tuple = CORE) -> np.ndarray:
    """Опорні події ноги: її середина, без обох країв."""
    near = np.arange(events) / max(events - 1, 1)
    return (near >= core[0]) & (near <= core[1])


def deviation(levels: np.ndarray, weights: np.ndarray | None = None,
              smooth: int = SMOOTH, core: tuple = CORE) -> np.ndarray:
    """`d` кожної події ноги: несхожість на опору **своєї** ноги.

    Опора — медіана й IQR по середині ноги. `z` робастний, щоб один
    канал, що пішов у хвіст, не робив зону сам; зведення по каналах —
    медіана (`plain`) або зважене середнє (`learned`).
    """
    keep = core_of(levels.shape[0], core)
    piece = levels[keep] if keep.sum() >= 4 else levels
    center = np.nanmedian(piece, axis=0)
    spread = (np.nanquantile(piece, 0.75, axis=0)
              - np.nanquantile(piece, 0.25, axis=0))
    spread = np.where(np.isfinite(spread) & (spread > 1e-9), spread, 1.0)
    z = np.abs(levels - center) / spread
    with np.errstate(invalid="ignore"):
        line = (np.nanmedian(z, axis=1) if weights is None
                else np.nansum(z * weights, axis=1) / max(weights.sum(), 1e-9))
    return rolling_median(line, smooth)


def grow(line: np.ndarray, start: int, step: int, limit: float,
         patience: int = PATIENCE, cap: int = 10 ** 9) -> int:
    """Скільки подій від `start` у бік `step` ще несхожі на ногу.

    Йдемо, поки `d` вище за `limit`; зупиняє `patience` звичайних подій
    поспіль, і повертається довжина **до них**. Нуль означає, що вже
    сусідня подія звичайна.
    """
    taken, calm, index = 0, 0, start
    while 0 <= index < len(line) and taken < cap:
        value = line[index]
        if not np.isfinite(value) or value < limit:
            calm += 1
            if calm >= patience:
                break
        else:
            taken += calm + 1
            calm = 0
        index += step
    return taken


def zones_of(line: np.ndarray, limit: float, cap: float = CAP,
             seed: int = SEED) -> dict:
    """Три довжини на ногу: хвіст, голова і зона з фальшивої точки.

    Фальшива точка — випадкова подія тіла ноги. Це і є головний
    контроль: якщо з неї зона така сама, як з розвороту, метод
    описує не розворот, а те, як взагалі поводиться `d`.
    """
    events = len(line)
    good = line[np.isfinite(line)]
    if not len(good):
        return {}
    # нога без розкиду: поріг вийшов би нульовим, і «несхожою» стала б
    # кожна подія — зони тут немає, а не «зона на всю ногу»
    if float(np.nanmax(good) - np.nanmin(good)) <= 0.0:
        return {"tail": 0, "head": 0, "fake_back": 0, "fake_ahead": 0,
                "level": 0.0, "events": events}
    level = float(np.quantile(good, limit))
    roof = max(int(events * cap), 1)
    rng = np.random.default_rng(seed)
    body = core_of(events)
    spots = np.flatnonzero(body)
    fake = int(rng.choice(spots)) if len(spots) else events // 2
    return {"tail": grow(line, events - 1, -1, level, cap=roof),
            "head": grow(line, 0, +1, level, cap=roof),
            "fake_back": grow(line, fake, -1, level, cap=roof),
            "fake_ahead": grow(line, fake, +1, level, cap=roof),
            "level": round(level, 4), "events": events}


def detector_of(x, rows: list, train: list, seed: int = SEED):
    """Детектор розвороту, навчений на ногах train: сама модель.

    `plain` і `learned` міряють **величину** відхилення каналу від
    свого рівня. Але різниця біля півота — не сплеск в окремому каналі,
    а поворот у просторі каналів: логістика бачить її з `AUC` 0.78, а
    медіана |z| по 410 каналах — ні. Тому третій спосіб бере за `d`
    саму видачу детектора, а поріг лишає персональним: квантиль
    видачі **цієї** ноги.
    """
    from sklearn.linear_model import LogisticRegression

    hot, body, _ = zone.spots_of(rows, train, LEARN[0], LEARN[1], "tail")
    cold = zone.thinned(body, zone.SAMPLE, seed)
    hot = zone.thinned(hot, zone.SAMPLE, seed + 1)
    left = np.concatenate([zone.frame_of(x, hot), zone.frame_of(x, cold)])
    y = np.concatenate([np.ones(len(hot)), np.zeros(len(cold))])
    model = LogisticRegression(max_iter=300, C=0.1, class_weight="balanced")
    model.fit(np.nan_to_num(left, nan=0.0), y)
    return model


def weights_of(x, rows: list, train: list, seed: int = SEED) -> np.ndarray:
    """Ваги каналів: чим канал говорить про розворот, на ногах train.

    Детектор — та сама логістична регресія, що в `pivot_zone.py`:
    події за `LEARN` подій до розвороту проти тіла ноги. Береться не
    видача, а модуль ваги каналу: `learned` потрібні не рішення
    детектора, а те, куди взагалі дивитись.
    """
    from sklearn.linear_model import LogisticRegression

    hot, body, _ = zone.spots_of(rows, train, LEARN[0], LEARN[1], "tail")
    cold = zone.thinned(body, zone.SAMPLE, seed)
    hot = zone.thinned(hot, zone.SAMPLE, seed + 1)
    left = np.concatenate([zone.frame_of(x, hot), zone.frame_of(x, cold)])
    y = np.concatenate([np.ones(len(hot)), np.zeros(len(cold))])
    model = LogisticRegression(max_iter=300, C=0.1, class_weight="balanced")
    model.fit(np.nan_to_num(left, nan=0.0), y)
    weight = np.abs(model.coef_[0])
    keep = np.argsort(weight)[::-1][:TOP]
    out = np.zeros_like(weight)
    out[keep] = weight[keep]
    return out / max(out.sum(), 1e-9)


def ranks(values: np.ndarray) -> np.ndarray:
    """Ранги з середнім на звʼязках — для рангової кореляції."""
    order = np.argsort(values, kind="mergesort")
    out = np.empty(len(values), dtype=float)
    out[order] = np.arange(1, len(values) + 1)
    start = 0
    lined = values[order]
    for stop in range(1, len(lined) + 1):
        if stop == len(lined) or lined[stop] != lined[start]:
            out[order[start:stop]] = out[order[start:stop]].mean()
            start = stop
    return out


def spearman(left: np.ndarray, right: np.ndarray) -> float:
    """Рангова кореляція: довжини зон не мають скінченного розкиду."""
    if len(left) < 3:
        return float("nan")
    one, two = ranks(np.asarray(left, float)), ranks(np.asarray(right, float))
    one, two = one - one.mean(), two - two.mean()
    bottom = float(np.sqrt((one ** 2).sum() * (two ** 2).sum()))
    return float((one * two).sum() / bottom) if bottom > 0 else float("nan")


def lines_of(x, rows: list, picked: list, weights, limit: float,
             seed: int = SEED, model=None) -> dict:
    """`d` і зони кожної ноги вибірки."""
    out = {}
    for one in picked:
        row = rows[one]
        levels = np.array(x[row["first"]:row["last"] + 1, :-zone.MARK],
                          dtype=np.float32)
        if model is not None:
            line = rolling_median(
                model.decision_function(np.nan_to_num(levels, nan=0.0)),
                SMOOTH)
        else:
            line = deviation(levels, weights)
        got = zones_of(line, limit, seed=seed + one)
        if got:
            out[one] = {**got, "leg": row["events"]}
    return out


def spread_of(values: list) -> dict:
    """Коротка довідка про розподіл довжин."""
    if not values:
        return {}
    got = np.asarray(values, dtype=float)
    return {"median": round(float(np.median(got)), 1),
            "low": round(float(np.percentile(got, 10)), 1),
            "high": round(float(np.percentile(got, 90)), 1),
            "mean": round(float(got.mean()), 1), "count": int(len(got))}


def against_fake(found: dict) -> dict:
    """Перевірка 1: зона з розвороту проти зони з випадкової точки."""
    real = [one["tail"] for one in found.values()]
    fake = [one["fake_back"] for one in found.values()]
    if not real:
        return {}
    truth = np.concatenate([np.ones(len(real)), np.zeros(len(fake))])
    said = np.concatenate([np.asarray(real, float), np.asarray(fake, float)])
    return {"real": spread_of(real), "fake": spread_of(fake),
            "auc": round(zone.auc_of(truth, said), 4),
            "longer": round(float(np.mean(np.asarray(real, float)
                                          > np.asarray(fake, float))), 4)}


def against_leg(found: dict) -> dict:
    """Перевірка 4: чи росте персональна зона з довжиною ноги."""
    if len(found) < 3:
        return {}
    legs = np.asarray([one["leg"] for one in found.values()], float)
    tail = np.asarray([one["tail"] for one in found.values()], float)
    share = tail / np.maximum(legs, 1.0)
    return {"spearman": round(spearman(legs, tail), 4),
            "share": spread_of(list(share)),
            "share_spearman": round(spearman(legs, share), 4)}


def inside_of(rows: list, found: dict, side: str = "tail") -> np.ndarray:
    """Події персональної зони — рядами датасету."""
    out = []
    for one, got in found.items():
        row = rows[one]
        size = got[side]
        if size <= 0:
            continue
        if side == "tail":
            out.append(np.arange(row["last"] - size + 1, row["last"] + 1))
        else:
            out.append(np.arange(row["first"], row["first"] + size))
    return np.concatenate(out) if out else np.zeros(0, dtype=np.int64)


def budget_of(rows: list, found: dict, side: str = "tail") -> float:
    """Яку частку ноги персональні межі витрачають у середньому.

    Порівняння «персональна межа проти рівної» чесне лише при **тому
    самому бюджеті подій**: менша вибірка сама собою дає вищий `AUC`.
    Тому рівній межі віддається стільки ж подій, скільки забрали
    персональні, — і питання лишається одне: чи краще ці події
    розкладені.
    """
    spent = sum(one[side] for one in found.values())
    whole = sum(rows[one]["events"] for one in found)
    return spent / whole if whole else 0.0


def flat_of(rows: list, found: dict, share: float = FLAT,
            side: str = "tail") -> np.ndarray:
    """Те саме рівною межею — стала частка ноги, без погляду на фічі."""
    out = []
    for one in found:
        row = rows[one]
        size = max(int(round(row["events"] * share)), 1)
        if side == "tail":
            out.append(np.arange(row["last"] - size + 1, row["last"] + 1))
        else:
            out.append(np.arange(row["first"], row["first"] + size))
    return np.concatenate(out) if out else np.zeros(0, dtype=np.int64)


def body_of(rows: list, found: dict) -> np.ndarray:
    """Тіло ноги: те саме, що в `pivot_zone`."""
    out = []
    for one in found:
        row = rows[one]
        walk = np.arange(row["first"], row["last"] + 1)
        near = (walk - row["first"]) / max(row["events"] - 1, 1)
        out.append(walk[(near >= zone.BODY[0]) & (near <= zone.BODY[1])])
    return np.concatenate(out) if out else np.zeros(0, dtype=np.int64)


def content_of(x, rows: list, train: dict, val: dict,
               seed: int = SEED) -> dict:
    """Перевірка 2: чи добірніші події персональної зони за рівну межу.

    Обидві межі дають свої події, обидві міряються тією самою моделлю
    проти тіла ноги. Якщо персональна межа щось знає — її `AUC` вищий
    при тій самій кількості подій.
    """
    out = {}
    budget = budget_of(rows, train)
    print(f"    бюджет персональних меж: {budget:.2%} ноги")
    ways = (("own", inside_of),
            ("flat", lambda r, f: flat_of(r, f, budget)),
            ("tenth", lambda r, f: flat_of(r, f, FLAT)))
    for name, hot_of in ways:
        hot = zone.thinned(hot_of(rows, train), zone.SAMPLE, seed)
        cold = zone.thinned(body_of(rows, train), zone.SAMPLE, seed + 1)
        vhot = zone.thinned(hot_of(rows, val), zone.SAMPLE, seed + 2)
        vcold = zone.thinned(body_of(rows, val), zone.SAMPLE, seed + 3)
        if len(hot) < 50 or len(vhot) < 20:
            continue
        got = zone.split_fit(x, (hot, cold), (vhot, vcold), seed)
        out[name] = {**got, "over": round(got["auc"] - got["floor"], 4),
                     "val_hot": int(len(vhot)),
                     "share": round(budget if name == "flat"
                                    else FLAT if name == "tenth" else -1, 4)}
        print(f"    {name}: AUC {got['auc']:.4f} · підлога "
              f"{got['floor']:.4f} · подій val {len(vhot)}")
    return out


def steady_of(x, rows: list, picked: list, weights,
              seed: int = SEED, model=None) -> dict:
    """Перевірка 3: чи тримаються ранги довжин при іншому `LIMIT`."""
    kept = {}
    for limit in LIMITS:
        found = lines_of(x, rows, picked, weights, limit, seed, model)
        kept[limit] = found
    base = kept[LIMIT]
    out = {"limits": list(LIMITS), "rows": []}
    for limit, found in kept.items():
        shared = sorted(set(base) & set(found))
        if len(shared) < 3:
            continue
        one = np.asarray([base[two]["tail"] for two in shared], float)
        two_ = np.asarray([found[two]["tail"] for two in shared], float)
        out["rows"].append({"limit": limit,
                            "spearman": round(spearman(one, two_), 4),
                            "median": spread_of(list(two_)).get("median")})
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--limit", type=float, default=LIMIT)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    import ad_legleft as ad

    ctx = ad.prepare(force=args.force)
    rows, built = ctx["rows"], ctx["built"]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"
             and row["events"] >= zone.MIN_LEG]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"
           and row["events"] >= zone.MIN_LEG]
    print(f"ноги довші за {zone.MIN_LEG} подій: train {len(train)}, "
          f"val {len(val)}")

    began = time.time()
    block = {"script": SCRIPT, "ready": True, "limit": args.limit,
             "limits": list(LIMITS), "core": list(CORE), "smooth": SMOOTH,
             "patience": PATIENCE, "cap": CAP, "top": TOP,
             "learn": list(LEARN), "flat": FLAT,
             "legs": {"train": len(train), "val": len(val)}, "kinds": {}}
    learned = weights_of(built["x"], rows, train)
    print(f"ваги каналів: {int((learned > 0).sum())} з {len(learned)}")
    model = detector_of(built["x"], rows, train)

    for name, weights, net in (("plain", None, None),
                               ("learned", learned, None),
                               ("score", None, model)):
        print(f"спосіб {name}")
        found_train = lines_of(built["x"], rows, train, weights, args.limit,
                               SEED, net)
        found_val = lines_of(built["x"], rows, val, weights, args.limit,
                             SEED, net)
        one = {"tail": spread_of([two["tail"] for two in found_val.values()]),
               "head": spread_of([two["head"] for two in found_val.values()]),
               "fake": against_fake(found_val),
               "leg": against_leg(found_val)}
        print(f"    зона хвоста val: медіана {one['tail'].get('median')} "
              f"подій · фальшива {one['fake']['fake'].get('median')} · "
              f"AUC {one['fake'].get('auc')}")
        one["content"] = content_of(built["x"], rows, found_train, found_val)
        one["steady"] = steady_of(built["x"], rows, val, weights,
                                  SEED, net)
        block["kinds"][name] = one

    block["minutes"] = round((time.time() - began) / 60.0, 1)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
