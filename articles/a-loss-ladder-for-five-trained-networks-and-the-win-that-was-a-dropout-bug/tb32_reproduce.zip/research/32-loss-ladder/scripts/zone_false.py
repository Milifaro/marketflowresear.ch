"""Хибні розвороти: чи тисне мережа на корекціях усередині ноги.

Дослідження: research/32-loss-ladder/
Правила: rules/02-markup.md → зігзаг і вкладені зігзаги

Мережа етапу 8 обнуляє лінію 34.7 рази на 1000 подій там, де справжніх
розворотів 2.5. Питання просте: **де саме падають зайві зубці**. Якщо
на корекціях — місцях усередині ноги, де ціна пішла проти неї й
повернулась, — то мережа не помиляється випадково, а плутає корекцію з
кінцем ноги, і лікувати треба саме це.

## Що з чим порівнюється

Корекція — півот **вкладеного** зігзага (`INNER`) на тій самій ема10, що
й розмітка ніг, усередині ноги, не ближче за `EDGE` подій до її країв, і
**того самого боку**, що й кінець ноги: на нозі вгору це вкладений
`high`, тобто місце, яке виглядає як її завершення.

Глибина корекції — рух від неї до наступного вкладеного півота.

Дві частини:

| частина | питання |
| ------- | ------- |
| `split` | чи відрізняє клас події перед справжнім кінцем ноги від подій перед корекцією — `AUC` на ногах val, підлога на перемішаних мітках, окремо по глибині |
| `land`  | куди лягли обнулення мережі на val: на справжній розворот, на корекцію чи в порожнє місце |

`split` перевіряє, чи задача взагалі розвʼязна на цьому вході. Дослідження
30 (етап 5) на одному BTC, семи фічах і 63 півотах знайшло різницю лише
проти дрібної корекції 0.5 % (`AUC` 0.669) і нічого проти 0.8–1.5 %. Тут
той самий замір на 410 каналах, шести монетах і 554 ногах.

`land` міряє не задачу, а мережу: скільки її зубців справді сидять на
корекціях.

Вхід : датасет `legleft_blocks4_gauss_clock`, ваги models/legzone
Вихід: results/zone_false.json

Запуск:
    python3 research/32-loss-ladder/scripts/zone_false.py
    python3 research/32-loss-ladder/scripts/zone_false.py --part split
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = SCRIPTS.parents[2]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))


def sibling(name: str):
    """Сусідній скрипт дослідження — **за шляхом файлу**, а не за іменем.

    У проєкті є другий `pivot_zone.py` (дослідження 22), і звичайний
    `import` під повним прогоном тестів підхоплює той, чия тека раніше
    лягла в `sys.path`. Шлях файлу такої двозначності не має.
    """
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


zone = sibling("pivot_zone")

SEED = 0
OUTER = 0.023              # зігзаг ніг: перевірка, що ціна датасету — та сама
INNER = 0.005              # вкладений зігзаг: що вважати корекцією
EDGE = 40                  # корекція не ближче за стільки подій до країв ноги
REACH = (0, 9)             # події перед кандидатом: те саме вікно, що в зоні
DEPTHS = ((0.005, 0.008), (0.008, 0.010), (0.010, 0.015), (0.015, 10.0))
GRID = ((0.003, 5), (0.003, 10), (0.003, 20), (0.005, 10), (0.005, 20),
        (0.008, 10), (0.008, 20))   # що вважати корекцією × як близько
NEAR = 10                  # обнулення «на корекції»: стільки подій навколо
LEVEL = 0.5                # поріг обнулення на видачі мережі
LEVELS = (0.3, 0.5, 0.7, 0.9, 0.95, 0.99)   # сила натиску: чи є в ній сенс
TAIL_SHARE = 0.095         # зона розвороту: частка ноги (zone_length.py)
HEAD = 15                  # голова зони, подій
SCRIPT = "research/32-loss-ladder/scripts/zone_false.py"
OUT = "zone_false.json"


def coins_of(rows: list) -> dict:
    """Межі кожної монети в спільному ряду подій."""
    out = {}
    for row in rows:
        one = out.setdefault(row["pair"], [row["first"], row["last"]])
        one[0] = min(one[0], row["first"])
        one[1] = max(one[1], row["last"])
    return out


def checked(built: dict, rows: list, coins: dict) -> dict:
    """Чи справді ціна датасету — та ема, на якій стоять ноги.

    Без цієї перевірки вкладений зігзаг рахувався б по чужому ряду.
    Кінці ніг мають лягти рівно на півоти зігзага `OUTER`.
    """
    from zigzag import zigzag

    hit = total = 0
    for pair, (low, high) in coins.items():
        spots = {int(one.index) + low
                 for one in zigzag(built["price"][low:high + 1], OUTER)}
        ends = [row["last"] for row in rows if row["pair"] == pair]
        hit += sum(1 for one in ends if one in spots)
        total += len(ends)
    return {"legs": total, "on_pivots": hit,
            "share": round(hit / total, 4) if total else 0.0}


def corrections_of(built: dict, rows: list, picked: list, coins: dict,
                   inner: float = INNER, edge: int = EDGE) -> list:
    """Корекції: вкладені півоти того самого боку всередині ноги."""
    from zigzag import zigzag

    nested = {}
    for pair, (low, high) in coins.items():
        nested[pair] = [(int(one.index) + low, one.kind)
                        for one in zigzag(built["price"][low:high + 1], inner)]
    out = []
    price = built["price"]
    for one in picked:
        row = rows[one]
        want = "high" if row["kind"] == "up" else "low"
        spots = nested[row["pair"]]
        for place, (index, kind) in enumerate(spots):
            if kind != want:
                continue
            if not (row["first"] + edge <= index <= row["last"] - edge):
                continue
            after = spots[place + 1][0] if place + 1 < len(spots) else None
            depth = (abs(float(price[after]) - float(price[index]))
                     / max(abs(float(price[index])), 1e-9)) \
                if after is not None else 0.0
            out.append({"leg": one, "at": index, "depth": round(depth, 5),
                        "pair": row["pair"], "part": row["part"]})
    return out


def before(spots: list, reach: tuple = REACH) -> np.ndarray:
    """Події за `reach` подій **до** кандидата: причинне вікно."""
    out = []
    for one in spots:
        out.append(np.arange(one - reach[1], one - reach[0] + 1))
    return np.concatenate(out) if out else np.zeros(0, dtype=np.int64)


def split_of(x, rows: list, train: list, val: list, spots: list,
             seed: int = SEED, low: float = 0.0,
             high: float = 10.0) -> dict:
    """Клас перед справжнім кінцем ноги проти класу перед корекцією."""
    picked = [one for one in spots if low <= one["depth"] < high]
    hot_train = [one["at"] for one in picked if one["part"] == "train"]
    hot_val = [one["at"] for one in picked if one["part"] == "val"]
    ends_train = [rows[one]["last"] for one in train]
    ends_val = [rows[one]["last"] for one in val]
    if len(hot_train) < 20 or len(hot_val) < 10:
        return {"corrections": len(picked), "auc": None}
    got = zone.split_fit(x, (before(ends_train), before(hot_train)),
                         (before(ends_val), before(hot_val)), seed)
    return {"corrections": len(picked),
            "train": len(hot_train), "val": len(hot_val),
            **got, "over": round(got["auc"] - got["floor"], 4)}


def zones_of(rows: list, picked: list, share: float = TAIL_SHARE,
             head: int = HEAD) -> list:
    """Зона кожного розвороту: хвіст часткою ноги, голова в подіях."""
    out = []
    for one in picked:
        row = rows[one]
        tail = max(int(round(row["events"] * share)), 1)
        out.append({"at": row["last"], "from": row["last"] - tail,
                    "to": row["last"] + head})
    return out


def land_of(fired: np.ndarray, seen: np.ndarray, rows: list, picked: list,
            spots: list, near: int = NEAR, level: float = LEVEL) -> dict:
    """Куди лягли обнулення: на розворот, на корекцію чи в порожнє."""
    hit = np.flatnonzero(seen & np.isfinite(fired) & (fired > level))
    if not len(hit):
        return {"resets": 0}
    zones = zones_of(rows, picked)
    on_pivot = np.zeros(len(hit), dtype=bool)
    for one in zones:
        on_pivot |= (hit >= one["from"]) & (hit <= one["to"])
    marks = np.asarray([one["at"] for one in spots
                        if seen[one["at"]]], dtype=np.int64)
    on_fix = np.zeros(len(hit), dtype=bool)
    for one in marks:
        on_fix |= np.abs(hit - one) <= near
    empty = ~(on_pivot | on_fix)
    took = np.zeros(len(marks), dtype=bool)
    for place, one in enumerate(marks):
        took[place] = bool(np.any(np.abs(hit - one) <= near))
    found = np.zeros(len(zones), dtype=bool)
    for place, one in enumerate(zones):
        found[place] = bool(np.any((hit >= one["from"]) & (hit <= one["to"])))
    # контроль: вікна самі вкривають частину ряду, і «на корекції» могло б
    # вийти випадковим розкладанням тієї самої кількості обнулень
    where = np.flatnonzero(seen)
    cover_fix = np.zeros(len(where), dtype=bool)
    for one in marks:
        cover_fix |= np.abs(where - one) <= near
    cover_pivot = np.zeros(len(where), dtype=bool)
    for one in zones:
        cover_pivot |= (where >= one["from"]) & (where <= one["to"])
    share_fix = float(cover_fix.mean()) if len(where) else 0.0
    share_pivot = float(cover_pivot.mean()) if len(where) else 0.0
    events = int(seen.sum())
    return {"resets": int(len(hit)), "events": events,
            "pivot_cover": round(share_pivot, 4),
            "correction_cover": round(share_fix, 4),
            "pivot_lift": round(float(on_pivot.mean()) / share_pivot, 2)
            if share_pivot > 0 else None,
            "correction_lift": round(float(on_fix.mean()) / share_fix, 2)
            if share_fix > 0 else None,
            "per_1000": round(len(hit) / max(events, 1) * 1000, 2),
            "on_pivot": round(float(on_pivot.mean()), 4),
            "on_correction": round(float(on_fix.mean()), 4),
            "on_nothing": round(float(empty.mean()), 4),
            "corrections": int(len(marks)),
            "corrections_hit": round(float(took.mean()), 4)
            if len(marks) else None,
            "pivots": int(len(zones)),
            "pivots_found": round(float(found.mean()), 4) if len(zones) else None,
            "near": near, "level": level}


def sharp_of(fired: np.ndarray, seen: np.ndarray, rows: list, picked: list,
             spots: list, levels: tuple = LEVELS) -> list:
    """Чи є сенс у **силі** натиску: те саме по зростаючому порогу.

    Мережа тисне скрізь, але слабко переважає справжній розворот. Якщо
    сильні натиски сидять на розворотах частіше за кволі, то лікувати
    треба ціну натиску, а не місце: досить зробити слабкий сигнал
    дорожчим. Якщо підйом із порогом не росте — сили в сигналі немає.
    """
    out = []
    for level in levels:
        got = land_of(fired, seen, rows, picked, spots, level=level)
        if not got.get("resets"):
            continue
        out.append({"level": level, "per_1000": got["per_1000"],
                    "on_pivot": got["on_pivot"],
                    "pivot_lift": got["pivot_lift"],
                    "pivots_found": got["pivots_found"],
                    "on_correction": got["on_correction"],
                    "correction_lift": got["correction_lift"]})
        print(f"  поріг {level:.2f}: обнулень {got['per_1000']:>6}/1000 · "
              f"на розвороті {got['on_pivot']:.1%} (підйом "
              f"{got['pivot_lift']}) · розворотів знайдено "
              f"{got['pivots_found']:.1%} · на корекції підйом "
              f"{got['correction_lift']}")
    return out


def height_of(said: np.ndarray, fired: np.ndarray, seen: np.ndarray,
              rows: list, picked: list, spots: list, near: int = NEAR,
              level: float = LEVEL) -> dict:
    """Чи вища лінія там, де мережа тисне по ділу.

    Подія розвороту локально не відрізняється від корекції — це показала
    частина `split`. Але **де в нозі** стоїть натиск, лінія знає: біля
    справжнього кінця вона за побудовою встигла дорости. Якщо висота
    лінії на влучних натисках вища, ніж на хибних, то ціну натиску є
    сенс вʼязати саме до неї.
    """
    hit = np.flatnonzero(seen & np.isfinite(fired) & (fired > level))
    if not len(hit):
        return {}
    zones = zones_of(rows, picked)
    on_pivot = np.zeros(len(hit), dtype=bool)
    for one in zones:
        on_pivot |= (hit >= one["from"]) & (hit <= one["to"])
    marks = np.asarray([one["at"] for one in spots if seen[one["at"]]],
                       dtype=np.int64)
    on_fix = np.zeros(len(hit), dtype=bool)
    for one in marks:
        on_fix |= np.abs(hit - one) <= near
    tall = said[hit]
    good = np.isfinite(tall)

    def median(keep):
        piece = tall[keep & good]
        return round(float(np.median(piece)), 4) if len(piece) else None

    rest = ~on_pivot
    return {"pivot": median(on_pivot), "correction": median(on_fix & rest),
            "nothing": median(~(on_pivot | on_fix)),
            "auc": round(zone.auc_of(on_pivot[good].astype(float),
                                     tall[good]), 4),
            "resets": int(len(hit))}


def said_of(ctx: dict, name: str = "legzone", zone: tuple = (50, HEAD)):
    """Видача мережі на всіх вікнах val: беремо `fired` — сигнал обнулення.

    Прохід той самий, що міряє епоху в `zone_train.py`, тому числа тут
    порівнянні з таблицею етапу 8 подія в подію.
    """
    import share_train as share
    import val_series as series
    import zone_train as train

    path = MODELS / name / "model.pt"
    if not path.exists():
        return None, None, None
    built, rows = ctx["built"], ctx["rows"]
    picked = ctx["val"]
    total = built["x"].shape[0]
    was = RESULTS / "zone_train.json"
    older = json.loads(was.read_text(encoding="utf-8")) if was.exists() else {}
    win = int(older.get("win", share.WIN))
    warm = int(older.get("warm", share.WARM))
    model = share.build_of(ctx, __import__("ad_legleft"), share.SEED)
    series.lift(model, path)
    everyone = [one for one, row in enumerate(rows)
                if row["part"] in ("train", "val")]
    first, last = share.edges_of(rows, everyone, total)
    true = share.truth_of(first, last)
    boxes = share.windows(share.spans_of(rows, picked), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in boxes:
        seen[one["first"]:one["last"] + 1] = True
    got = train.measure(model, built, rows, picked, boxes, true, seen,
                        ctx["device"], zone)
    print(f"  вікон {len(boxes)} по {win} подій · міра {got['mark']} · "
          f"обнулень {got['often']}/1000")
    return got.get("fired"), seen, got


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--part", choices=("split", "land", "both"),
                        default="both")
    parser.add_argument("--inner", type=float, default=INNER)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    import ad_legleft as ad

    ctx = ad.prepare(force=args.force)
    rows, built = ctx["rows"], ctx["built"]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    coins = coins_of(rows)

    began = time.time()
    block = {"script": SCRIPT, "ready": True, "inner": args.inner,
             "outer": OUTER, "edge": EDGE, "reach": list(REACH),
             "depths": [list(one) for one in DEPTHS], "near": NEAR,
             "level": LEVEL, "tail_share": TAIL_SHARE, "head": HEAD,
             "legs": {"train": len(train), "val": len(val)}}
    block["price"] = checked(built, rows, coins)
    print(f"ціна датасету: {block['price']['on_pivots']} з "
          f"{block['price']['legs']} кінців ніг лягли на півоти зігзага "
          f"{OUTER:.1%}")

    spots = corrections_of(built, rows, train + val, coins, args.inner)
    block["corrections"] = {
        "total": len(spots),
        "per_leg": round(len(spots) / max(len(train) + len(val), 1), 2),
        "depth_median": round(float(np.median([one["depth"]
                                               for one in spots])), 5)
        if spots else None}
    print(f"корекцій {len(spots)} · на ногу "
          f"{block['corrections']['per_leg']} · медіана глибини "
          f"{block['corrections']['depth_median']}")

    if args.part in ("split", "both"):
        print("частина split: клас перед кінцем ноги проти класу перед корекцією")
        block["split"] = {"all": split_of(built["x"], rows, train, val, spots),
                          "depth": []}
        one = block["split"]["all"]
        print(f"  усі корекції: AUC {one.get('auc')} · підлога "
              f"{one.get('floor')} · корекцій {one.get('corrections')}")
        for low, high in DEPTHS:
            got = split_of(built["x"], rows, train, val, spots,
                           SEED, low, high)
            got.update({"from": low, "to": high})
            block["split"]["depth"].append(got)
            print(f"  глибина {low:.1%}…{high:.1%}: AUC {got.get('auc')} · "
                  f"підлога {got.get('floor')} · корекцій "
                  f"{got.get('corrections')}")

    if args.part in ("land", "both"):
        print("частина land: куди лягли обнулення мережі")
        fired, seen, got = said_of(ctx)
        if fired is None:
            print("  ваги models/legzone не знайдено")
        else:
            block["said"] = {key: value for key, value in got.items()
                             if key not in ("said", "fired")}
            # «порожнє місце» залежить від того, що вважати корекцією:
            # дрібніший вкладений зігзаг і ширше вікно з'їдають порожнечу
            block["grid"] = []
            for inner, near in GRID:
                marks = corrections_of(built, rows, val, coins, inner)
                one = land_of(fired, seen, rows, val, marks, near)
                one.update({"inner": inner, "near": near,
                            "marks": len(marks)})
                block["grid"].append(one)
                print(f"  зігзаг {inner:.1%} ± {near:>2} подій: на корекції "
                      f"{one['on_correction']:.1%} при покритті "
                      f"{one['correction_cover']:.1%} → підйом "
                      f"{one['correction_lift']} · у порожньому "
                      f"{one['on_nothing']:.1%} · розворот: "
                      f"{one['on_pivot']:.1%} при {one['pivot_cover']:.1%} → "
                      f"підйом {one['pivot_lift']}")
            tall = height_of(got.get("said"), fired, seen, rows, val,
                             [one for one in spots
                              if one["part"] == "val"])
            block["height"] = tall
            if tall:
                print(f"  висота лінії на натиску: розворот {tall['pivot']} · "
                      f"корекція {tall['correction']} · порожнє "
                      f"{tall['nothing']} · AUC висоти {tall['auc']}")
            print("  сила натиску:")
            block["sharp"] = sharp_of(fired, seen, rows, val,
                                      [one for one in spots
                                       if one["part"] == "val"])
            block["land"] = next(one for one in block["grid"]
                                 if one["inner"] == args.inner
                                 and one["near"] == NEAR)
            one = block["land"]
            print(f"  обнулень {one['resets']} ({one['per_1000']} на 1000 "
                  f"подій) · розворотів знайдено {one['pivots_found']:.1%} з "
                  f"{one['pivots']}")

    block["minutes"] = round((time.time() - began) / 60.0, 1)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
