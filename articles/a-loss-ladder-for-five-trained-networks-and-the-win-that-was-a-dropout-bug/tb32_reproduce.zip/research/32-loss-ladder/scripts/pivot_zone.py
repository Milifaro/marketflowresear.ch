"""Зона півота: де подія перестає бути схожою на решту ноги.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Питання одне: **скільки подій біля розвороту виглядають інакше**, ніж
подія з тіла ноги, — і з якої відстані ця різниця стає видною моделі.
Відповідь потрібна не заради самої себе: на ній стоїть безштрафова
зона обнулення мережі `legzone`. Штрафувати обнулення там, де подія
ще й сама не відрізняється від сусідніх, немає за що.

## Чому не «5 % ноги»

Відсоток ноги — не подія. П'ять відсотків ноги в 1200 подій це 60
подій, а ноги в 120 подій — шість. Різниця в фічах, якщо вона є,
стоїть у **подіях** від розвороту, а не в частках. Тому міра тут
рахується в подіях, а частка ноги — тільки як довідка.

## Як міряється

Кошик — події на відстані `d` подій від півота. Тіло — середина ноги
(`BODY` частки). На кожен кошик окремо вчиться логістична регресія на
410 каналах класу (розмітка не заходить) на ногах `train` і міряється
`AUC` на ногах `val`: чи відрізнить модель подію кошика від події тіла.

    AUC ≈ 0.5   подія кошика не відрізняється від тіла
    AUC → 1.0   відрізняється завжди

Поруч із кожним кошиком іде **підлога** — той самий прохід з
перемішаними мітками. Вона показує, скільки `AUC` дає сама вибірка.

Межа зони — **половина висоти**: різниця біля розвороту не обривається,
а спадає, і навіть за двісті подій від півота модель ще трохи відрізняє
подію від середини ноги. Тому зоною береться відстань, на якій надлишок
`AUC − підлога` впав удвічі проти найбільшого.

Дві сторони рахуються нарізно:

    хвіст   `d = last − t`   події перед розворотом
    голова  `d = t − first`  події після розвороту (вже нова нога)

Вхід : датасет `legleft_blocks4_gauss_clock` (дослідження 29)
Вихід: results/pivot_zone.json — криві, підлога, межі зони

Запуск:
    python3 research/32-loss-ladder/scripts/pivot_zone.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
RESULTS = RESEARCH_DIR / "results"
SEED = 0
BODY = (0.40, 0.60)        # тіло ноги: звідки беруться «звичайні» події
MIN_LEG = 200              # коротші ноги не дають ні тіла, ні далеких кошиків
SAMPLE = 12000             # стеля подій тіла в одній вибірці
MARK = 4                   # скільки каналів розмітки відрізати з кінця
MARGIN = 0.03              # наскільки AUC має стояти вище підлоги
BAND = 2                   # смуга кошиків: одиночний кошик шумить
STEPS = ((0, 2), (3, 5), (6, 9), (10, 14), (15, 19), (20, 29), (30, 39),
         (40, 49), (50, 69), (70, 99), (100, 149), (150, 199), (200, 299),
         (300, 499))
SCRIPT = "research/32-loss-ladder/scripts/pivot_zone.py"
OUT = "pivot_zone.json"


def spots_of(rows: list, picked: list, low: int, high: int,
             side: str) -> tuple:
    """Події кошика `low…high` подій від краю і події тіла — своїми рядами."""
    bucket, body, coins = [], [], []
    for one in picked:
        row = rows[one]
        events = row["events"]
        if events < MIN_LEG:
            continue
        walk = np.arange(row["first"], row["last"] + 1)
        far = (row["last"] - walk) if side == "tail" else (walk - row["first"])
        near = (walk - row["first"]) / max(events - 1, 1)
        # кошик і тіло не перетинаються: інакше модель ділила б те саме
        outside = (near > BODY[1]) if side == "tail" else (near < BODY[0])
        take = (far >= low) & (far <= high) & outside
        middle = (near >= BODY[0]) & (near <= BODY[1])
        bucket.append(walk[take])
        body.append(walk[middle])
        coins.append(np.full(int(take.sum()), row["pair"]))
    return (np.concatenate(bucket) if bucket else np.zeros(0, dtype=np.int64),
            np.concatenate(body) if body else np.zeros(0, dtype=np.int64),
            np.concatenate(coins) if coins else np.zeros(0, dtype="<U9"))


def thinned(index: np.ndarray, cap: int, seed: int) -> np.ndarray:
    """Вибірка не більша за `cap`: тіло ноги на порядок більше за кошик."""
    if len(index) <= cap:
        return index
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(index, size=cap, replace=False))


def frame_of(x, index: np.ndarray) -> np.ndarray:
    """Канали класу без розмітки: memmap читається рядками кошика."""
    if not len(index):
        return np.zeros((0, x.shape[1] - MARK), dtype=np.float32)
    return np.array(x[index][:, :-MARK], dtype=np.float32)


def auc_of(truth: np.ndarray, said: np.ndarray) -> float:
    """AUC рангами: без sklearn.metrics, щоб не тягти зайве."""
    good, bad = said[truth == 1], said[truth == 0]
    if not len(good) or not len(bad):
        return float("nan")
    order = np.argsort(np.concatenate([good, bad]), kind="mergesort")
    rank = np.empty(len(order), dtype=np.float64)
    rank[order] = np.arange(1, len(order) + 1)
    # середній ранг на звʼязках
    values = np.concatenate([good, bad])[order]
    start = 0
    for stop in range(1, len(values) + 1):
        if stop == len(values) or values[stop] != values[start]:
            rank[order[start:stop]] = rank[order[start:stop]].mean()
            start = stop
    got = (rank[:len(good)].sum() - len(good) * (len(good) + 1) / 2.0) \
        / (len(good) * len(bad))
    return float(got)


def split_fit(x, train: tuple, val: tuple, seed: int) -> dict:
    """Логістична регресія на каналах класу: кошик проти тіла ноги."""
    from sklearn.linear_model import LogisticRegression

    hot, cold = train
    left = np.concatenate([frame_of(x, hot), frame_of(x, cold)])
    y = np.concatenate([np.ones(len(hot)), np.zeros(len(cold))])
    model = LogisticRegression(max_iter=300, C=0.1, class_weight="balanced")
    model.fit(np.nan_to_num(left, nan=0.0), y)
    hot, cold = val
    right = np.concatenate([frame_of(x, hot), frame_of(x, cold)])
    true = np.concatenate([np.ones(len(hot)), np.zeros(len(cold))])
    said = model.decision_function(np.nan_to_num(right, nan=0.0))
    out = {"auc": round(auc_of(true, said), 4),
           "train_events": int(len(y)), "val_events": int(len(true))}
    # підлога: той самий прохід з перемішаними мітками train
    rng = np.random.default_rng(seed + 1)
    shuffled = LogisticRegression(max_iter=300, C=0.1,
                                  class_weight="balanced")
    shuffled.fit(np.nan_to_num(left, nan=0.0), rng.permutation(y))
    out["floor"] = round(auc_of(true, shuffled.decision_function(
        np.nan_to_num(right, nan=0.0))), 4)
    return out


def curve_of(x, rows: list, train: list, val: list, side: str,
             seed: int = SEED) -> list:
    """Крива AUC по відстані від розвороту, кошик за кошиком."""
    out = []
    for number, (low, high) in enumerate(STEPS):
        hot, body, _ = spots_of(rows, train, low, high, side)
        cold = thinned(body, SAMPLE, seed + number)
        hot = thinned(hot, SAMPLE, seed + 100 + number)
        vhot, vbody, coins = spots_of(rows, val, low, high, side)
        vcold = thinned(vbody, SAMPLE, seed + 200 + number)
        vhot = thinned(vhot, SAMPLE, seed + 300 + number)
        if len(hot) < 50 or len(vhot) < 20:
            continue
        began = time.time()
        got = split_fit(x, (hot, cold), (vhot, vcold), seed + number)
        out.append({"from": low, "to": high, "at": (low + high) / 2.0,
                    **got, "seconds": round(time.time() - began, 1)})
        print(f"  {side} {low:>3}…{high:<3} подій · AUC {got['auc']:.4f} · "
              f"підлога {got['floor']:.4f} · подій train "
              f"{got['train_events']}, val {got['val_events']} · "
              f"{out[-1]['seconds']} с")
    return out


def edge_of(curve: list, margin: float = MARGIN) -> dict:
    """Межа зони — половина висоти піка над підлогою.

    Різниця біля розвороту не обривається, а спадає: навіть за двісті
    подій від півота модель ще відрізняє подію від середини ноги, бо
    відстань від краю сама по собі каже, де ти в нозі. Тому межею
    береться не «різниці більше немає», а **половина висоти**: відстань,
    на якій надлишок `AUC − підлога` впав удвічі проти найбільшого.
    Це і є зона, де подія розвороту ще схожа на саму себе.
    """
    live = [one for one in curve
            if np.isfinite(one["auc"]) and np.isfinite(one["floor"])]
    if not live:
        return {"events": 0, "peak": None, "half": None}
    tops = [one["auc"] - one["floor"] for one in live]
    peak = max(tops)
    if peak < margin:
        return {"events": 0, "peak": round(peak, 4), "half": None}
    half = peak / 2.0
    kept = live[0]
    for one in live:
        if one["auc"] - one["floor"] >= half:
            kept = one
        else:
            break
    return {"events": int(kept["to"]) + 1, "auc": kept["auc"],
            "floor": kept["floor"], "peak": round(peak, 4),
            "half": round(half, 4)}


def free_of(sides: list, band: int = BAND) -> dict:
    """Безштрафова зона обнулення: **спільний** поріг на обидва боки.

    Кожен бік має свій пік, і половина висоти свого піка розтягує
    слабший бік на сотні подій. Для штрафу потрібна одна лінійка, тому
    поріг береться від найбільшого надлишку з обох боків, а бік
    рахується до останнього кошика, де смуга з `band` сусідніх кошиків
    ще тримається над цим порогом.
    """
    tops = [one["auc"] - one["floor"] for side in sides
            for one in side["curve"] if np.isfinite(one["auc"])]
    if not tops:
        return {}
    level = max(tops) / 2.0
    out = {"level": round(level, 4), "band": band}
    for side in sides:
        curve = side["curve"]
        kept = 0
        for place, one in enumerate(curve):
            piece = [two["auc"] - two["floor"]
                     for two in curve[max(place - band + 1, 0):place + 1]]
            if float(np.mean(piece)) >= level:
                kept = int(one["to"]) + 1
        out[side["key"]] = kept
    return out


def shares_of(rows: list, picked: list, events: int) -> dict:
    """Скільки це у відсотках ноги: та сама зона на різних ногах."""
    parts = []
    for one in picked:
        row = rows[one]
        if row["events"] >= MIN_LEG:
            parts.append(events / row["events"])
    if not parts:
        return {}
    parts = np.asarray(parts, dtype=float)
    return {"share_median": round(float(np.median(parts)), 4),
            "share_low": round(float(np.percentile(parts, 10)), 4),
            "share_high": round(float(np.percentile(parts, 90)), 4),
            "legs": int(len(parts))}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import ad_legleft as ad

    ctx = ad.prepare(force=args.force)
    rows, built = ctx["rows"], ctx["built"]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    long_train = [one for one in train if rows[one]["events"] >= MIN_LEG]
    long_val = [one for one in val if rows[one]["events"] >= MIN_LEG]
    print(f"ноги довші за {MIN_LEG} подій: train {len(long_train)}, "
          f"val {len(long_val)} · тіло {BODY[0]:.0%}…{BODY[1]:.0%} ноги")

    began = time.time()
    block = {"script": SCRIPT, "ready": True, "body": list(BODY),
             "min_leg": MIN_LEG, "margin": MARGIN, "sample": SAMPLE,
             "steps": [list(one) for one in STEPS],
             "legs": {"train": len(long_train), "val": len(long_val)},
             "sides": []}
    for side, title in (("tail", "хвіст ноги: події перед розворотом"),
                        ("head", "голова ноги: події після розвороту")):
        print(title)
        curve = curve_of(built["x"], rows, long_train, long_val, side)
        edge = edge_of(curve)
        block["sides"].append({"key": side, "title": title, "curve": curve,
                               "edge": {**edge,
                                        **shares_of(rows, long_val,
                                                    edge["events"])}})
        print(f"  зона {side}: {edge['events']} подій")
    block["zone"] = {one["key"]: one["edge"]["events"]
                     for one in block["sides"]}
    block["free"] = free_of(block["sides"])
    print(f"безштрафова зона обнулення: {block['free'].get('tail')} подій до "
          f"розвороту, {block['free'].get('head')} після "
          f"(поріг {block['free'].get('level')})")
    block["minutes"] = round((time.time() - began) / 60.0, 1)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} · {block['minutes']} хв")


if __name__ == "__main__":
    main()
