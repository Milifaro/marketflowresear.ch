"""Ряд val BTC двома мережами поділу: зубці окремо, лінія окремо.

Дослідження: research/32-loss-ladder/
Правила: rules/05-visualization.md → компоновка

Етап 11 розділив задачу на дві мережі, і числа поділу читаються пулом
шести монет. Тут те саме видно очима на одній монеті: що саме кожна з
мереж каже подія за подією.

Під ціною шість ліній на нерухомій шкалі 0…1:

    насправді    частка справжньої ноги зігзага 2.3 % на ема10 — пилка
    лічильник    крок / (крок + медіана залишку train) — межа знизу
    зубці        сира видача `legtooth`: наскільки схоже на кінець ноги
    обнулись     та сама видача порогом, поставленим на ногах train
    лінія        `legline`: веде приріст, а падає від чужого сигналу
    одна голова  `legzone` етапу 8 — для порівняння, стара конструкція

Ряд ріжеться **тими самими вікнами**, що й на навчанні, і замір іде на
процесорі — з тієї самої причини, що в `zone_series.py`.

Поруч із лініями пишеться те, що цю картинку пояснює: скільки зубців
лягло в зону, який у них зсув і який розмах у лінії.

Вхід : models/legtooth/model.pt, models/legline/model.pt,
       models/legzone/model.pt
Вихід: results/split_series_BTC_USDT.json

Запуск:
    python3 research/32-loss-ladder/scripts/split_series.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
PAIR = "BTC_USDT"
SEED = 17
DEVICE = "cpu"
HALF = 105
OUT = f"split_series_{PAIR}.json"
SCRIPT = "research/32-loss-ladder/scripts/split_series.py"


def sibling(name: str):
    """Сусідній скрипт дослідження — за шляхом файлу, а не за іменем."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    tooth = sibling("tooth_train")
    line = sibling("line_train")
    zone = sibling("zone_train")

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    picked = [one for one in val if rows[one]["pair"] == PAIR]
    first, last = share.edges_of(rows, train + val, total)
    truth = share.truth_of(first, last)

    got = json.loads((RESULTS / "line_train.json").read_text(
        encoding="utf-8")) if (RESULTS / "line_train.json").exists() else {}
    win = int(got.get("win", share.WIN))
    warm = int(got.get("warm", share.WARM))
    level = float(got.get("level", 0.5))
    fade = float(got.get("fade", line.FADE))
    boxes = share.windows(share.spans_of(rows, picked), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in boxes:
        seen[one["first"]:one["last"] + 1] = True
    index = np.flatnonzero(seen)
    print(f"вікон {len(boxes)} по {win} подій (розігрів {warm}) · поріг "
          f"чужого сигналу {level:.4f} · розворотів {len(picked)}")

    bounds = [(rows[one]["first"], rows[one]["last"]) for one in picked]
    counter = share.counter_line(built["x"], rows, picked, total)
    report = {"counter": {**share.marks(counter, truth, seen, bounds),
                          "legs": len(picked)}}
    lines = {"counter": counter}

    path = MODELS / "legtooth" / "model.pt"
    press = None
    if path.exists():
        model = tooth.build_of(ctx, ad, SEED)
        model.load_state_dict(torch.load(path, map_location="cpu"))
        model.eval()
        score = tooth.score_on(model, built, boxes, DEVICE, total)
        press = line.pressed(score, level)
        lines["tooth"] = score
        lines["fired"] = press
        each = tooth.each_leg(score, rows, picked)
        report["tooth"] = {**each, "level": round(level, 4),
                           "per_1000": round(float((press[seen] > 0.5).mean())
                                             * 1000, 2),
                           "weights": str(path.relative_to(PROJECT_ROOT))}
        print(f"  зубці: у зоні {each.get('inzone')} з {each.get('legs')} "
              f"ніг · зсув {each.get('delay')} · обнулень "
              f"{report['tooth']['per_1000']}/1000")

    path = MODELS / "legline" / "model.pt"
    if path.exists() and press is not None:
        model = tooth.build_of(ctx, ad, SEED)
        series.lift(model, path)
        now = line.measure(model, built, rows, picked, boxes, press, truth,
                           seen, DEVICE, total, fade)
        lines["line"] = now["said"]
        report["line"] = {key: value for key, value in now.items()
                          if key != "said"}
        report["line"]["weights"] = str(path.relative_to(PROJECT_ROOT))
        one = report["line"]
        print(f"  лінія: міра {one['mark']} · голова {one['head']} · хвіст "
              f"{one['tail']} · розмах {one['swing']}")

    path = MODELS / "legzone" / "model.pt"
    if path.exists():
        model = share.build_of(ctx, ad, SEED)
        series.lift(model, path)
        band = json.loads((RESULTS / "zone_train.json").read_text(
            encoding="utf-8")).get("zone", {}) \
            if (RESULTS / "zone_train.json").exists() else {}
        free = (int(band.get("tail", 50)), int(band.get("head", 15)))
        now = zone.measure(model, built, rows, picked, boxes, truth, seen,
                           DEVICE, free)
        lines["whole"] = now["said"]
        report["whole"] = {key: value for key, value in now.items()
                           if key not in ("said", "fired")}
        report["whole"]["weights"] = str(path.relative_to(PROJECT_ROOT))
        one = report["whole"]
        print(f"  одна голова: міра {one['mark']} · розмах "
              f"{round(one['tail'] - one['head'], 4)} · обнулень "
              f"{one['often']}/1000")

    write(lines, truth, report, index, built, args, win, warm, level, fade)


def write(lines: dict, truth, report: dict, index, built, args, win: int,
          warm: int, level: float, fade: float) -> dict:
    """Кістяк ряду з `val_series` і лінії поділу під ціною."""
    import val_series as series

    bones = series.skeleton()
    axis = np.asarray(bones["t"], dtype=np.int64)
    stamps = np.asarray(built["t"][index], dtype=np.int64)
    where = series.nearest(axis, stamps, HALF)
    good = where >= 0
    keep = np.sort(where[good])
    span = slice(int(keep[0]), int(keep[-1]) + 1)

    def lay(values) -> list:
        column = np.full(len(axis), np.nan)
        column[where[good]] = np.asarray(values, dtype=float)[index][good]
        return rounded(column[span], 4)

    titles = (("truth", "насправді"), ("counter", "лічильник"),
              ("tooth", "зубці"), ("fired", "сигнал «обнулись»"),
              ("line", "лінія поділу"), ("whole", "одна голова"))
    block = {"script": SCRIPT, "ready": True, "pair": PAIR,
             "models": {"tooth": "legtooth", "line": "legline",
                        "whole": "legzone"},
             "device": DEVICE, "event_seconds": 210, "win": win,
             "warm": warm, "level": round(level, 4), "fade": fade,
             "kinds": sorted(lines), "class": bones["class"],
             "threshold": bones["threshold"], "period": bones["period"],
             "events": int(len(axis[span])), "from": int(axis[span][0]),
             "to": int(axis[span][-1]), "lost": int((~good).sum()),
             "t": [int(one) for one in axis[span]],
             "price": [round(float(one), 2) for one in bones["price"][span]],
             "ema": [round(float(one), 2) for one in bones["ema"][span]],
             "pivots": [one for one in bones["pivots"]
                        if axis[span][0] <= one["t"] <= axis[span][-1]],
             "marks": report}
    block["truth"] = lay(truth)
    shown = []
    for key, title in titles:
        if key == "truth":
            shown.append({"key": key, "title": title, "kind": key})
            continue
        if key not in lines:
            continue
        block[key] = lay(lines[key])
        shown.append({"key": key, "title": title, "kind": key})
    block["lines"] = shown
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} — {block['events']} подій")
    return block


if __name__ == "__main__":
    main()
