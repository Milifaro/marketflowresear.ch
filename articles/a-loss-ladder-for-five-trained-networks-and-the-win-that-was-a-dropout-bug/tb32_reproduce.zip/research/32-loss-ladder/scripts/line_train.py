"""Мережа частки: веде лінію, а обнуляє її чужий сигнал.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Друга половина поділу. Етап 10 показав, що одна голова не тягне обидві
задачі: коли та сама мережа і шукає розворот, і веде лінію, вона
розмінює одне на інше — частота обнулень не падає нижче 16 на 1000, а
розмах лінії осідає в нуль.

Тут мережа **не вирішує, коли обнулятись**. Вона каже одне число —
наскільки підрости, — а падіння приходить ззовні, від мережі зубців
(`tooth_train.py`), чиї ваги заморожені:

    s(t) = (1 − fade · натиск_ззовні(t)) · min(s(t−1) + g(t), 1)

Через це у втраті не лишається жодного доданка про обнулення: ні
драбини промаху, ні ціни за натиск, ні бюджету. Лишається сама форма —
коридор навколо правди, дорожче заниження в хвості ноги, заборона
спуску всередині ноги й ціна «не впасти там, де нога вже нова». Мережі
більше нема чим хитрувати: вона не може купити коридор частими
падіннями, бо падіннями не керує.

Сигнал ззовні береться порогом на видачі мережі зубців. Поріг ставиться
**на ногах train** так, щоб вийшло `AIM` обнулень на 1000 подій, і той
самий поріг застосовується до val — інакше val підглядав би за собою.

Вхід : ваги models/legtooth (заморожені), датасет
       `legleft_blocks4_gauss_clock`, тулуб з ваг дослідження 29
Вихід: results/line_train.json, models/legline/model.pt

Запуск:
    python3 research/32-loss-ladder/scripts/line_train.py --epochs 40
    python3 research/32-loss-ladder/scripts/line_train.py --aim 2.5
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = SCRIPTS.parents[2]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

NAME = "legline"
TEETH = "legtooth"
SEED = 0
EPOCHS = 40
PATIENCE = 12
LR = 3e-4
AIM = 2.5                  # обнулень на 1000 подій: одне на ногу
SOFT = 0.05                # мʼякість порога: сигнал не двійковий, а плавний
FADE = 1.0                 # чуже рішення роняє лінію **повністю**, за подію
FREE = (0.10, 0.07, 0.05, 0.03, 0.02)
KNOBS = {"down": 6.0, "up": 2.0, "grow": 5.0, "fall": 120.0, "cliff": 60.0,
         "tail": 4.0, "edge": 0.1}
SCRIPT = "research/32-loss-ladder/scripts/line_train.py"
OUT = "line_train.json"


def sibling(name: str):
    """Сусідній скрипт дослідження — за шляхом файлу, а не за іменем."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


def teeth_of(ctx: dict, ad, boxes: list, total: int) -> np.ndarray:
    """Видача замороженої мережі зубців на всій стрічці."""
    import torch

    tooth = sibling("tooth_train")
    path = MODELS / TEETH / "model.pt"
    if not path.exists():
        raise SystemExit(f"немає ваг мережі зубців: {path}")
    model = tooth.build_of(ctx, ad, SEED)
    model.load_state_dict(torch.load(path, map_location="cpu"))
    model.eval()
    return tooth.score_on(model, ctx["built"], boxes, ctx["device"], total)


def level_for(score: np.ndarray, seen: np.ndarray, aim: float) -> float:
    """Поріг чужого сигналу — **на ногах train**, і той самий для val."""
    live = score[seen & np.isfinite(score)]
    if not len(live):
        return 1.0
    part = min(max(aim / 1000.0, 1.0 / len(live)), 1.0)
    return float(np.quantile(live, 1.0 - part))


def pressed(score: np.ndarray, level: float, soft: float = SOFT):
    """Натиск із чужої видачі: плавна сходинка навколо порога.

    Різкий поріг зробив би лінію рваною й недиференційовною за самим
    порогом; мʼяка сходинка лишає ту саму кількість обнулень, але без
    стрибка на одну соту видачі.
    """
    out = 1.0 / (1.0 + np.exp(-(score - level) / max(soft, 1e-6)))
    return np.where(np.isfinite(score), out, 0.0).astype(np.float32)


def line_of(grow, press, fade: float = FADE):
    """Пилка, де падіння прийшло ззовні: мережа керує тільки приростом.

    `fade` тут **одиниця**, а не 0.35, як у мережі етапу 8. Там сигнал
    був власний і тривав десяток подій поспіль, тому частковий спуск
    складався в повний. Тут сигнал — одна подія й готове рішення «нога
    скінчилась», і спуск на третину лишав би лінію на двох третинах
    висоти: перший прогін дав голову ноги 0.44 замість нуля й розмах
    0.07. Чуже рішення роняє лінію повністю.
    """
    import torch

    out, now = [], torch.zeros_like(grow[:, 0])
    for place in range(grow.shape[1]):
        now = (1.0 - fade * press[:, place]) * (now + grow[:, place]) \
            .clamp(max=1.0)
        out.append(now)
    return torch.stack(out, dim=1)


def tensors_of(built: dict, chunk: list, truth: np.ndarray,
               press: np.ndarray, device: str):
    """Батч вікон: клас без розмітки, правда і **чужий** сигнал натиску."""
    import torch
    import share_train as share

    length = max(one["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    own = np.zeros((len(chunk), length), dtype=np.float32)
    hit = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        steps = one["steps"]
        piece = slice(one["hist"], one["last"] + 1)
        x[number, :steps, :-1] = share.frame_of(built, one)
        x[number, :steps, -1] = 1.0
        told = truth[piece]
        good = np.isfinite(told)
        y[number, :steps] = np.where(good, told, 0.0)
        mask[number, :steps] = True
        own[number, steps - one["events"]:steps] = \
            good[steps - one["events"]:].astype(np.float32)
        hit[number, :steps] = press[piece]
    lengths = torch.tensor([one["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device), torch.from_numpy(y).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(own).to(device),
            torch.from_numpy(hit).to(device))


def said_on(model, built: dict, chunk: list, press: np.ndarray,
            truth: np.ndarray, device: str, fade: float = FADE) -> list:
    """Лінія на батчі вікон: приріст від мережі, падіння ззовні."""
    import torch
    import share_train as share

    x, y, mask, lengths, own, hit = tensors_of(built, chunk, truth, press,
                                               device)
    with torch.no_grad():
        raw = model(x, mask, lengths)
        grow = torch.sigmoid(raw[..., 0] if raw.dim() == 3 else raw) \
            * share.STEP
        said = line_of(grow, hit, fade)
    return [said[number, one["steps"] - one["events"]:one["steps"]]
            .float().cpu().numpy() for number, one in enumerate(chunk)]


def measure(model, built: dict, rows: list, picked: list, boxes: list,
            press: np.ndarray, truth: np.ndarray, seen: np.ndarray,
            device: str, total: int, fade: float = FADE) -> dict:
    """Ті самі числа форми, що й у мережі етапу 7: міра, розмах, обвал."""
    import share_train as share

    said = np.full(total, np.nan, dtype=np.float32)
    model.eval()
    for chunk in share.packed(boxes):
        for one, piece in zip(chunk, said_on(model, built, chunk, press,
                                             truth, device, fade)):
            said[one["first"]:one["last"] + 1] = piece
        share.free_of(device)
    model.train()
    bounds = [(rows[one]["first"], rows[one]["last"]) for one in picked]
    return {**share.marks(said, truth, seen, bounds), "said": said}


def score_of(one: dict) -> float:
    """Вибір епохи: міра-коридор і форма. Обнулень тут мережа не робить."""
    import share_train as share

    return share.score_of(one)


def epoch_of(model, tune, built: dict, boxes: list, truth: np.ndarray,
             press: np.ndarray, device: str, seed: int, free: float,
             knobs: dict) -> float:
    """Одна епоха: сама форма, жодного доданка про обнулення."""
    import torch
    import share_train as share

    model.train()
    chunks = share.packed(boxes)
    order = list(range(len(chunks)))
    np.random.default_rng(seed).shuffle(order)
    total, seen = 0.0, 0

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, hit = tensors_of(built, chunk, truth,
                                                   press, device)
        if scale is None:
            scale = own.sum()
        raw = model(x, mask, lengths)
        grow = torch.sigmoid(raw[..., 0] if raw.dim() == 3 else raw) \
            * share.STEP
        said = line_of(grow, hit, knobs["fade"])
        chain = own.clone()
        chain[:, :1] = 0.0
        chain[:, 1:] = chain[:, 1:] * own[:, :-1]
        step = share.share_step(said, y, chain, knobs, free)
        piece = (step * own).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum().item()), scale

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            share.free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2]

    for number in order:
        tune.zero_grad()
        got, count, _ = learn(chunks[number])
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        share.free_of(device)
        total += got * count
        seen += count
    return total / max(seen, 1)


def save(curve: list, best, counter: dict, args, device: str, began: float,
         win: int, warm: int, level: float, knobs: dict) -> None:
    """Звіт пишеться після кожної епохи."""
    import share_train as share

    report = {"script": SCRIPT, "ready": True, "model": NAME, "teeth": TEETH,
              "lr": args.lr, "win": win, "warm": warm, "aim": args.aim,
              "level": round(level, 4), "soft": SOFT,
              "fade": knobs.get("fade", FADE),
              "near": share.NEAR, "wide": share.WIDE, "edge": share.EDGE,
              "free": list(FREE), "knobs": knobs, "device": device,
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "counter": counter, "curve": curve, "best": best,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / OUT).write_text(json.dumps(report, ensure_ascii=False),
                               encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--minutes", type=float, default=400.0)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--aim", type=float, default=AIM)
    parser.add_argument("--fade", type=float, default=FADE,
                        help="наскільки чужий сигнал роняє лінію")
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    tooth = sibling("tooth_train")
    ctx = ad.prepare(force=args.force)
    device, rows, built = ctx["device"], ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    hot = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    was = RESULTS / "zone_train.json"
    older = json.loads(was.read_text(encoding="utf-8")) if was.exists() else {}
    win = int(older.get("win", share.WIN))
    warm = int(older.get("warm", share.WARM))

    first, last = share.edges_of(rows, hot + val, total)
    truth = share.truth_of(first, last)
    train_boxes = share.windows(share.spans_of(rows, hot), win, warm)
    val_boxes = share.windows(share.spans_of(rows, val), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in val_boxes:
        seen[one["first"]:one["last"] + 1] = True
    hot_seen = np.zeros(total, dtype=bool)
    for one in train_boxes:
        hot_seen[one["first"]:one["last"] + 1] = True

    score = teeth_of(ctx, ad, train_boxes + val_boxes, total)
    level = level_for(score, hot_seen, args.aim)
    press = pressed(score, level)
    rate = float((press[seen] > 0.5).mean()) * 1000
    each = tooth.each_leg(score, rows, val)
    print(f"вікон: train {len(train_boxes)}, val {len(val_boxes)} по {win} "
          f"подій · чужий сигнал: поріг {level:.4f} з ніг train, на val "
          f"{rate:.2f} обнулень на 1000 · один на ногу в зоні "
          f"{each.get('inzone')} · пристрій {device}")

    counter = share.marks(
        share.counter_line(built["x"], rows, val, total), truth, seen,
        [(rows[one]["first"], rows[one]["last"]) for one in val])
    print(f"лічильник розмітки: міра {counter['mark']} · розмах "
          f"{counter['swing']} · обвал {counter['cliff']}")

    knobs = {**KNOBS, "fade": args.fade}
    model = tooth.build_of(ctx, ad, SEED)
    keep = MODELS / NAME
    keep.mkdir(parents=True, exist_ok=True)
    tune = torch.optim.AdamW(model.parameters(), lr=args.lr)
    curve, best, stale = [], None, 0
    path = RESULTS / OUT
    if args.resume and path.exists() and (keep / "model.pt").exists():
        older = json.loads(path.read_text(encoding="utf-8"))
        series.lift(model, keep / "model.pt")
        if (keep / "tune.pt").exists():
            tune.load_state_dict(torch.load(keep / "tune.pt",
                                            map_location="cpu"))
        curve, best = list(older.get("curve", [])), older.get("best")
        print(f"продовжую з епохи {len(curve) + 1}")

    began = time.time()
    last_epoch = len(curve) + args.epochs
    for number in range(len(curve) + 1, last_epoch + 1):
        free = share.free_at(number, last_epoch, FREE)
        loss = epoch_of(model, tune, built, train_boxes, truth, press,
                        device, SEED + number, free, knobs)
        share.free_of(device)
        now = measure(model, built, rows, val, val_boxes, press, truth, seen,
                      device, total, args.fade)
        share.free_of(device)
        spent = (time.time() - began) / 60.0
        step = {"epoch": number, "loss": round(loss, 4), "free": free,
                **{key: value for key, value in now.items()
                   if key != "said"}}
        step["score"] = score_of(step)
        curve.append({**step, "minutes": round(spent, 1)})
        print(f"  епоха {number:>2} · зона {free:.2f} · втрата {loss:.4f} · "
              f"міра {now['mark']} · голова {now['head']} · хвіст "
              f"{now['tail']} · розмах {now['swing']} · обвал "
              f"{now['cliff']} · оцінка {step['score']} · {spent:.1f} хв")
        if best is None or step["score"] < best["score"]:
            best = {key: value for key, value in step.items()}
            stale = 0
            torch.save(model.state_dict(), keep / "model.pt")
            torch.save(tune.state_dict(), keep / "tune.pt")
        else:
            stale += 1
        save(curve, best, counter, args, device, began, win, warm, level,
             knobs)
        if (args.patience and stale >= args.patience) \
                or spent > args.minutes:
            break
    save(curve, best, counter, args, device, began, win, warm, level, KNOBS)


if __name__ == "__main__":
    main()
