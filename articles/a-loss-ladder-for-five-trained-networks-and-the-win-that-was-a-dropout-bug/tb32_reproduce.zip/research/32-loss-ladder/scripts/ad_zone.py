"""Адаптер драбини: «зона півота, зона корекції, звичайна подія»
(дослідження 31, етапи 5–7).

Мережа з памʼяттю йде рядом подій `клас210х10-1х7д/д` і на кожній події
каже, до якого з трьох видів вона належить. Одобрена версія — найсильніший
набір гріду етапу 7: `hidden 128 · 2 шари · lr 0.003 · bce · штраф за
плутанину 0 · памʼять «увесь ряд»`, AUC півота `0.753`, корекції `0.717`.

Ваг від того гріду не лишилось (він міряв ручки, а не зберігав моделі),
тому драбина **спершу вчить одобрену версію заново** тими самими ручками
і на тому самому seed, а вже з неї йде вгору по щаблях. Базові ваги
лягають окремим файлом — `models/zone/base.pt`.

## Нерухома міра

Оцінка етапу 7: `AUC(півот) + AUC(корекція) − плутанина`, де плутанина —
частка подій зони півота, де **ранг** каналу «корекція» вищий за ранг
каналу «півот».

**Умова допуску.** Плутанину легко звести до нуля, зламавши канал
корекції: штраф тисне його вниз, ранги розсипаються, плутанини немає — і
сказати «це корекція» модель більше не може. Тому щабель, у якого AUC
хоч одного каналу нижче `0.6`, не береться, хай би яка була його оцінка.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
ZONE31 = PROJECT_ROOT / "research" / "31-leg-common-part" / "scripts"
LEG19 = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
RULES = PROJECT_ROOT / "rules" / "scripts"
sys.path.insert(0, str(ZONE31))
sys.path.insert(0, str(LEG19))
sys.path.insert(0, str(RULES))

import zone_lstm as base                            # noqa: E402
from zones import MARKS                             # noqa: E402
from leg_common import CLASS, REDUCE                # noqa: E402

NAME = "zone"
TITLE = "Зона півота і зона корекції"
SOURCE = "research/31-leg-common-part/31-leg-common-part.md → етапи 5–7"
ABOUT = ("LSTM у два шари йде рядом подій `клас210х10-1х7д/д` і на кожній "
         "події каже, що це: зона розвороту, зона корекції всередині ноги "
         "чи звичайна подія. Памʼять несе весь ряд, блоки нарізані по "
         "подіях, а не по ногах — інакше обнулення стану саме́ підказує "
         "мережі, де півот.")
METRIC = "оцінка"
METRIC_DIR = "max"
METRIC_ABOUT = ("`AUC(півот) + AUC(корекція) − плутанина`; щабель, у якого "
                "AUC хоч одного каналу нижче 0.6, не береться взагалі — "
                "плутанину можна прибрати, зламавши канал. Більше краще")
MARGIN = 0.003
EXTRA = [{"key": "auc_pivot", "title": "AUC півот", "dir": "max"},
         {"key": "auc_correction", "title": "AUC корекція", "dir": "max"},
         {"key": "mixup", "title": "плутанина", "dir": "min"},
         {"key": "accuracy", "title": "влучність", "dir": "max"}]

# Одобрений набір етапу 7: найсильніші числа гріду.
HIDDEN = 128
LAYERS = 2
LR = 0.003
CHUNK = base.CHUNK
STEP = 0                   # памʼять «увесь ряд»
BASE_EPOCHS = 8            # стільки епох мала одобрена версія
FLOOR = 0.6                # умова допуску: нижче цього канал зламано


def rungs() -> list:
    """Щаблі: прицільний штраф, форма втрати й стеля ваги класу."""
    one = {"loss": "bce", "confuse": 0.0, "gamma": base.GAMMA, "cap": 20.0}

    def rung(name: str, lr: float = LR, **change) -> dict:
        return {"name": name, "step": {**one, **change}, "lr": lr,
                "show": {"lr": lr, **change}}

    return [
        rung("той самий штраф"),
        rung("штраф за плутанину 0.1", confuse=0.1),
        rung("фокус γ2", loss="focal"),
        rung("штраф 0.2", confuse=0.2),
        rung("стеля ваги класу 40", cap=40.0),
        rung("той самий штраф · крок ×0.3", lr=1e-3),
        rung("фокус γ1 · штраф 0.1", lr=1e-3, loss="focal", gamma=1.0,
             confuse=0.1),
        rung("штраф 0.3", lr=1e-3, confuse=0.3),
        rung("стеля ваги класу 10", lr=1e-3, cap=10.0),
        rung("фокус γ2 · штраф 0.2", lr=3e-4, loss="focal", confuse=0.2),
        rung("штраф 0.15 · стеля 40", lr=3e-4, confuse=0.15, cap=40.0),
        rung("штраф 0.5", lr=3e-4, confuse=0.5),
        rung("усе разом", lr=3e-4, loss="focal", gamma=1.0, confuse=0.15,
             cap=40.0),
    ]


# ---------- дані й мережа ----------


def prepare(force: bool = False) -> dict:
    from leg_end_train import no_swap
    from build_class210x10x7dc import PAIRS

    no_swap(force=force)
    device = base.device_name()
    coins = [base.coin_data(one, CLASS, REDUCE, "all", None, None)
             for one in PAIRS]
    for coin in coins:
        for name in ("train", "val"):
            coin[f"blocks_{name}"] = base.blocks_of(
                coin["where"], coin["legs"], coin["t"], coin["cut"],
                STEP, name, "events")
    counts = {name: sum(len(coin[f"blocks_{name}"]) for coin in coins)
              for name in ("train", "val")}
    labels = np.concatenate([coin["labels"][np.concatenate(
        coin["blocks_train"])] for coin in coins])
    print(f"монет {len(coins)} · блоків train {counts['train']}, "
          f"val {counts['val']} · каналів "
          f"{coins[0]['levels'].shape[1]} · пристрій {device}")
    print("зони: " + " · ".join(
        f"{name} {sum(coin['counts'][name] for coin in coins)}"
        for name in ("pivot", "correction")))
    return {"coins": coins, "device": device, "counts": counts,
            "labels": labels,
            "channels": int(coins[0]["levels"].shape[1]),
            "pairs": [coin["pair"] for coin in coins]}


def build(ctx: dict, seed: int):
    model = base.build_net(ctx["channels"], HIDDEN, LAYERS, base.DROPOUT,
                           seed=seed).to(ctx["device"])
    ctx["params"] = sum(one.numel() for one in model.parameters())
    return model, optimizer(ctx, model)


def optimizer(ctx: dict, model):
    import torch

    return torch.optim.Adam(model.parameters(), lr=LR)


def weight_of(ctx: dict, cap: float, head: str):
    return base.class_weight(ctx["labels"], cap=cap,
                             head="softmax" if head == "softmax"
                             else "sigmoid")


def epoch(ctx: dict, model, tune, one: dict, train: bool):
    """Один прохід: `bce` й `focal` читаються сигмоїдою, `softmax` — своєю."""
    head = "softmax" if one["loss"] == "softmax" else one["loss"]
    weight = weight_of(ctx, one["cap"], head)
    return base.run_blocks(model, ctx["coins"],
                           "train" if train else "val", STEP, ctx["device"],
                           CHUNK, train, tune if train else None,
                           weight=weight, head=head,
                           confuse=one["confuse"], gamma=one["gamma"])


def start_from(ctx: dict, model, tune) -> dict:
    """Одобрена версія: ваги з `models/zone/base.pt` або навчання заново.

    Гріди етапу 7 ваг не зберігали, тому базова версія тут вчиться тими
    самими ручками, що виграли грід, і лягає файлом — щоб наступний
    прогін драбини починався з неї, а не вчив її знову.
    """
    import torch

    keep = Path(__file__).resolve().parents[1] / "models" / NAME
    keep.mkdir(parents=True, exist_ok=True)
    path = keep / "base.pt"
    if path.exists():
        model.load_state_dict(torch.load(path, map_location="cpu"))
        print(f"базові ваги підняті з {path.name}")
        return {"config": base_config(trained=False)}
    print(f"одобрених ваг немає: вчу базову версію {BASE_EPOCHS} епох "
          f"на ручках гріду етапу 7")
    one = rungs()[0]["step"]
    best, state = None, None
    for number in range(1, BASE_EPOCHS + 1):
        began = time.time()
        hurt = epoch(ctx, model, tune, one, True)
        got = evaluate(ctx, model)
        print(f"  епоха {number}: втрата {hurt['loss']:.4f} · "
              f"оцінка {got['mark']:.4f} · {human(got)} · "
              f"{(time.time() - began) / 60:.1f} хв")
        if best is None or got["mark"] > best:
            best = got["mark"]
            state = {key: value.detach().to("cpu").clone()
                     for key, value in model.state_dict().items()}
    if state is not None:
        model.load_state_dict(state)
        torch.save(state, path)
        print(f"базова версія: оцінка {best:.4f}, ваги в {path.name}")
    return {"config": base_config(trained=True)}


def base_config(trained: bool) -> dict:
    return {"hidden": HIDDEN, "layers": LAYERS, "lr": LR, "loss": "bce",
            "confuse": 0.0, "memory": "увесь ряд", "epochs": BASE_EPOCHS,
            "trained_here": trained,
            "from": "research/31-leg-common-part → етап 7, найсильніший "
                    "набір гріду"}


def train_epoch(ctx: dict, model, tune, rung: dict, seed: int,
                attempt: int = 1) -> float:
    """Епоха під штрафом щабля; повторна спроба — вдвічі меншим кроком."""
    began = time.time()
    for group in tune.param_groups:
        group["lr"] = rung.get("lr", LR) / (2 ** (attempt - 1))
    got = epoch(ctx, model, tune, rung["step"], True)
    print(f"    епоха пройшла за {(time.time() - began) / 60:.1f} хв")
    return float(got["loss"])


# ---------- замір ----------


def mark_of(block: dict) -> float:
    """Оцінка з допуском: зламаний канал не виграє, хай яка плутанина."""
    pivot = block["by_class"]["pivot"]["auc"]
    correction = block["by_class"]["correction"]["auc"]
    mixup = block["mixup"]["share"]
    if pivot is None or correction is None or mixup is None:
        return float("-inf")
    if min(pivot, correction) < FLOOR:
        return float("-inf")
    return float(pivot + correction - mixup)


def evaluate(ctx: dict, model) -> dict:
    one = rungs()[0]["step"]
    got = epoch(ctx, model, None, one, False)
    block = base.metrics_of(got["truth"], got["proba"])
    by_pair = {}
    for pair, piece in base.by_pair_metrics(ctx["coins"], got).items():
        by_pair[pair] = {"mark": mark_of(piece),
                         "auc_pivot": piece["by_class"]["pivot"]["auc"],
                         "auc_correction":
                             piece["by_class"]["correction"]["auc"],
                         "mixup": piece["mixup"]["share"],
                         "accuracy": piece["accuracy"],
                         "majority": piece["majority"],
                         "events": piece["events"],
                         "zones": {name: piece["by_class"][name]["events"]
                                   for name in MARKS}}
    return {"mark": mark_of(block),
            "metrics": {"auc_pivot": block["by_class"]["pivot"]["auc"],
                        "auc_correction":
                            block["by_class"]["correction"]["auc"],
                        "mixup": block["mixup"]["share"],
                        "accuracy": block["accuracy"],
                        "majority": block["majority"],
                        "events": block["events"],
                        "broken": bool(mark_of(block) == float("-inf"))},
            "by_pair": by_pair}


def human(got: dict) -> str:
    one = got["metrics"]
    def number(value):
        return "—" if value is None else format(value, ".3f")

    return (f"півот {number(one['auc_pivot'])} · корекція "
            f"{number(one['auc_correction'])} · плутанина "
            f"{number(one['mixup'])}"
            + (" · КАНАЛ ЗЛАМАНО" if one["broken"] else ""))


def pairs_of(ctx: dict) -> list:
    return list(ctx["pairs"])


def data_of(ctx: dict) -> dict:
    return {"class": CLASS, "reduce": REDUCE, "marks": list(MARKS),
            "channels": ctx["channels"], "params": ctx.get("params"),
            "blocks": ctx["counts"], "memory": "увесь ряд",
            "shape": {"hidden": HIDDEN, "layers": LAYERS, "lr": LR,
                      "chunk": CHUNK, "floor": FLOOR},
            "approved": "research/31-leg-common-part → етап 7"}
