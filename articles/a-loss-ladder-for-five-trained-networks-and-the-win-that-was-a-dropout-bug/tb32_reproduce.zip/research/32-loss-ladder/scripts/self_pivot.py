"""Сама собі півот: мережа називає довжину ноги і сама ставить її кінець.

Дослідження: research/32-loss-ladder/
Правила: rules/05-visualization.md → компоновка

Замір «Фальшивий півот» показав, що розмітка дає `legleft` головно
**вікно мовчання**, а не саму відповідь. Тут вікно лишається, але ставить
його вже не зігзаг, а сама мережа.

## Правило

Нога почалась. На перших `START` подіях мережа каже, скільки подій до
кінця, — це **сигнали початку**. Їхнє арифметичне середнє і є та
довжина, яку вона собі назвала:

    N = round(mean(сказано на кроках 0 … START−1))

Коли `N` подій минуло, мережі дається сигнал «кінець ноги»: памʼять
обнуляється, лічильник іде з нуля, вікно відповіді відкривається знову.
Наступна нога починається рівно там, і все повторюється. Розмітка в
цьому циклі не бере участі — ні `leg:up`, ні нуль лічильника.

Ніщо тут не заглядає вперед: відповідь на кроці `i` бачить події
`0 … i`, а межа ставиться на `N` кроків **уперед** від уже відомого
початку. Саме тому замір причинний, на відміну від справжнього півота
зігзага, який підтверджується через ~80 подій після себе.

## Два проходи на ногу

Спершу мережа проходить `START` подій — із цього виходить `N`. Далі та
сама нога проходиться цілком, на `N` подій, і саме ця видача лягає в
ряд. Обидва проходи дають на перших `START` кроках **ті самі числа**:
памʼять та сама, увага причинна, а довжина ноги у вхід не заходить
узагалі. Прогін це перевіряє й падає, якщо числа розійшлись.

## Канали

    leg:step   log1p(крок) / log1p(3000) — рахується формулою
    leg:guess  медіана залишку train на цьому кроці — читається з даних
    leg:open   1, поки крок менший за 150, далі 0 — як у справжніх ногах
    leg:up     напрямок ноги: його мережа знати не може, і він гаситься

Вікно мовчання лишається справжнім за формою: мережа відповідає перші
150 подій **своєї** ноги і мовчить далі.

## Дві версії ваг

Прохід робиться двічі: одобреними вагами дослідження 29 і вагами
`self_train.py`, які вчились **у цій самій рамці**. Перші показують, що
буває, коли рамку міняють під готовою мережею; другі — що дає навчання
в ній.

## Що міряється

Нерухома міра драбини на **справжньому** вікні — перші 150 подій після
справжнього півота, проти справжньої правди. Поруч — чи збіглись власні
межі мережі зі справжніми півотами: медіана відстані в подіях в обидва
боки.

Замір іде на процесорі з тієї самої причини, що й `val_series.py`.

Вхід : ваги `research/29-class7dd-legs/models/legleft_blocks4_gauss_clock_band/`
Вихід: results/self_pivot_BTC_USDT.json — ряд для вкладки і міри

Запуск:
    python3 research/32-loss-ladder/scripts/self_pivot.py
    python3 research/32-loss-ladder/scripts/self_pivot.py --start 40
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
SEED = 17
DEVICE = "cpu"
START = 20                    # скільки подій початку йде в середнє
RETRAINED = RESEARCH_DIR / "models" / "legleft_self" / "model.pt"
DEEP = 4                      # скільки попередніх своїх ніг у памʼяті
CLOCK = 3000.0                # чим діляться лічильники (legleft_data.CLOCK)
OPEN = 150                    # вікно відповіді всередині своєї ноги
SHORT = 20                    # коротше за це нога не буває
LONG = 2000                   # і довше теж: стеля лічильника
HALF = 105
OUT = f"self_pivot_{PAIR}.json"
SCRIPT = "research/32-loss-ladder/scripts/self_pivot.py"


# ------------------------------------------------------------------ дрібниці

def rounded(values, digits: int = 1) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def guess_table(x, index: np.ndarray, step: np.ndarray) -> tuple:
    """Відповідь лічильника на кожному кроці — з готового каналу даних.

    `leg:guess` уже порахований при побудові датасету по train-подіях.
    Рахувати його вдруге означало б ризикнути розійтись із тим, на чому
    мережа вчилась, тому він читається як є.
    """
    seen = {}
    for place, walked in zip(index, step):
        seen.setdefault(int(walked), float(x[place, -2]))
    keys = np.array(sorted(seen), dtype=np.int64)
    return keys, np.array([seen[int(one)] for one in keys], dtype=np.float32)


def clock_into(piece: np.ndarray, at: int, count: int, table: tuple) -> None:
    """Три канали лічильника на `count` подій, що йдуть від кроку 0."""
    keys, values = table
    walk = np.arange(count)
    piece[at:at + count, -3] = (np.log1p(walk) / np.log1p(CLOCK))
    place = np.clip(np.searchsorted(keys, walk, side="right") - 1,
                    0, len(keys) - 1)
    piece[at:at + count, -2] = values[place]
    piece[at:at + count, -1] = (walk < OPEN).astype(np.float32)


def said_on(model, ad, piece: np.ndarray, hist: int, first: int,
            count: int) -> np.ndarray:
    """Видача мережі на одній нозі: памʼять `hist … first−1`, ціль далі."""
    row = {"hist": hist, "first": first, "last": first + count - 1,
           "events": count, "history": 0, "part": "val", "pair": PAIR,
           "kind": "up", "steps": first + count - hist}
    block = ad.base.guess(model, {"x": piece}, [row], [0], DEVICE)
    return np.asarray(block["said"], dtype=float)


def length_of(said: np.ndarray, room: int) -> int:
    """Довжина ноги з середнього сигналів початку — і межі здорового глузду."""
    mean = float(np.mean(said))
    if not np.isfinite(mean):
        return min(room, LONG)
    return int(min(max(round(mean), SHORT), LONG, room))


# -------------------------------------------------------------------- прохід

def sequence(model, ad, piece: np.ndarray, table: tuple, start: int,
             deep: int = DEEP) -> dict:
    """Ряд, у якому мережа сама ставить кінець кожної ноги.

    Нога за ногою: канали заповнюються від її початку, перші `start`
    подій дають довжину, далі та сама нога проходиться цілком. Памʼять
    наступної ноги — `deep` попередніх, уже поставлених нею ж.
    """
    total = len(piece)
    said = np.full(total, np.nan)
    bounds, legs, at = [], [], 0
    while at < total:
        room = total - at
        clock_into(piece, at, room, table)
        hist = bounds[-deep][0] if len(bounds) >= deep else (
            bounds[0][0] if bounds else at)
        head = said_on(model, ad, piece, hist, at, min(start, room))
        count = length_of(head, room)
        full = said_on(model, ad, piece, hist, at, count)
        if not np.allclose(full[:len(head)], head, atol=1e-4):
            raise SystemExit("два проходи дали різні числа на початку ноги")
        said[at:at + count] = full
        legs.append({"first": at, "last": at + count - 1, "events": count,
                     "head": round(float(np.mean(head)), 1)})
        bounds.append((at, at + count - 1))
        at += count
    return {"said": said, "legs": legs,
            "cuts": [one[0] for one in bounds]}


def corridor(said: np.ndarray, truth: np.ndarray, talk: np.ndarray,
             ad) -> dict:
    """Коридор на тих подіях, де мережа **відповідає**.

    Вікно береться власне: у версії з розміткою це перші `WINDOW` подій
    після півота зігзага, у власній рамці — перші `OPEN` подій своєї
    ноги. Надбавки за балакучість немає — вона міряє слухняність вікну,
    якого у власної рамки немає, і ховає саму відповідь. Замість неї
    **покриття**: яку частку ряду мережа коментує.
    """
    good = np.isfinite(said) & np.isfinite(truth) & talk
    share = said[good] / np.maximum(truth[good], 1.0)
    near = float(((share >= ad.base.BAND[0])
                  & (share <= ad.base.BAND[1])).mean())
    wide = float(((share >= ad.base.WIDE[0])
                  & (share <= ad.base.WIDE[1])).mean())
    return {"mark": round(1.0 - (near + wide) / 2.0, 4),
            "near": round(near, 4), "wide": round(wide, 4),
            "cover": round(float(good.sum()) / float(len(truth)), 4),
            "err": round(float(np.median(np.abs(said[good] - truth[good]))),
                         1),
            "said_all": round(float(np.median(said[np.isfinite(said)])), 1),
            "events": int(np.isfinite(said).sum()),
            "window": int(good.sum())}


def own_step(cuts: list, lengths: list, total: int) -> np.ndarray:
    """Номер кроку **власної** ноги на кожній події ряду."""
    walk = np.full(total, np.nan)
    for first, count in zip(cuts, lengths):
        walk[first:first + count] = np.arange(count)
    return walk


def hit_of(cuts: np.ndarray, pivots: np.ndarray) -> dict:
    """Чи стоять власні межі мережі там само, де справжні півоти.

    Дві відстані, бо вони різні: від півота до найближчої межі каже,
    чи всі півоти знайдено, а від межі до найближчого півота — чи не
    наставлено зайвих.
    """
    if not len(cuts) or not len(pivots):
        return {"cuts": int(len(cuts)), "pivots": int(len(pivots))}
    gap = np.abs(pivots[:, None] - cuts[None, :])
    to_cut = gap.min(axis=1)
    to_pivot = gap.min(axis=0)
    return {"cuts": int(len(cuts)), "pivots": int(len(pivots)),
            "pivot_to_cut": round(float(np.median(to_cut)), 1),
            "cut_to_pivot": round(float(np.median(to_pivot)), 1),
            "near_40": round(float((to_cut <= 40).mean()), 4),
            "near_100": round(float((to_cut <= 100).mean()), 4)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--start", type=int, default=START)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import ad_legleft as ad
    import val_series as series

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    picked = [one for one, row in enumerate(rows)
              if row["part"] == "val" and row["pair"] == PAIR]
    index = np.concatenate([np.arange(rows[one]["first"],
                                      rows[one]["last"] + 1)
                            for one in picked])
    step = np.concatenate([np.arange(rows[one]["events"])
                           for one in picked])
    truth = np.concatenate([np.arange(rows[one]["events"] - 1, -1, -1)
                            for one in picked]).astype(float)
    model, _ = ad.build(ctx, SEED)
    series.lift(model, ad.APPROVED / "model.pt")

    block = ad.base.guess(model, built, rows, picked, DEVICE)
    walked = {"розмітка": np.asarray(block["said"], dtype=float)}
    report = {"real": {**corridor(walked["розмітка"], truth,
                                  step < ad.base.WINDOW, ad),
                       "legs": len(picked),
                       "median_leg": round(float(np.median(
                           [rows[one]["events"] for one in picked])), 1),
                       "weights": str((ad.APPROVED / "model.pt")
                                      .relative_to(PROJECT_ROOT))}}

    low, high = int(index[0]), int(index[-1])
    piece = np.array(built["x"][low:high + 1], dtype=np.float32)
    piece[:, -4] = 0.0                      # напрямок ноги мережі не дано
    table = guess_table(built["x"], index, step)
    # події, яких у val немає (діра в ряді), з ряду прибираються: мережа
    # не має вести памʼять по подіях, яких вона не бачила
    keep = np.isin(np.arange(low, high + 1), index)
    piece = piece[keep]
    pivots = np.flatnonzero(step == 0)
    runs = {}
    for kind, path in (("base", ad.APPROVED / "model.pt"),
                       ("self", RETRAINED)):
        if not path.exists():
            print(f"немає ваг {path} — пропускаю")
            continue
        series.lift(model, path)
        got = sequence(model, ad, piece.copy(), table, args.start)
        runs[kind] = got
        lengths = [one["events"] for one in got["legs"]]
        walk = own_step(got["cuts"], lengths, len(truth))
        report[kind] = {
            **corridor(got["said"], truth, walk < OPEN, ad),
            "start": args.start, "legs": len(got["legs"]),
            "weights": str(path.relative_to(PROJECT_ROOT)),
            "median_leg": round(float(np.median(lengths)), 1),
            **hit_of(np.array(got["cuts"]), pivots)}
        print(f"  {kind:>5}: {len(got['legs'])} ніг, медіана "
              f"{report[kind]['median_leg']} подій · міра "
              f"{report[kind]['mark']} · коридор "
              f"{report[kind]['near']:.3f}/{report[kind]['wide']:.3f} · "
              f"покриття {report[kind]['cover']:.3f} · півот → межа "
              f"{report[kind]['pivot_to_cut']} подій")
    write(walked, runs, truth, report, index, built, args)


def write(walked: dict, runs: dict, truth, report: dict, index, built,
          args) -> dict:
    """Кістяк ряду з `val_series`, лінії видачі й власні межі мережі."""
    import val_series as series

    bones = series.skeleton()
    axis = np.asarray(bones["t"], dtype=np.int64)
    stamps = np.asarray(built["t"][index], dtype=np.int64)
    where = series.nearest(axis, stamps, HALF)
    good = where >= 0
    keep = np.sort(where[good])
    span = slice(int(keep[0]), int(keep[-1]) + 1)
    total = len(axis)

    def lay(values) -> list:
        column = np.full(total, np.nan)
        column[where[good]] = np.asarray(values, dtype=float)[good]
        return rounded(column[span], 1)

    shown = "self" if "self" in runs else "base"
    lines = [{"key": "truth", "title": "насправді", "kind": "truth"},
             {"key": "real", "title": "розмітка", "kind": "real"}]
    block = {"script": SCRIPT, "ready": True, "pair": PAIR, "model": "legleft",
             "device": DEVICE, "deep": DEEP, "window": OPEN, "shown": shown,
             "start": args.start, "kinds": sorted(runs), "event_seconds": 210,
             "class": bones["class"], "threshold": bones["threshold"],
             "period": bones["period"],
             "events": int(len(axis[span])),
             "from": int(axis[span][0]), "to": int(axis[span][-1]),
             "lost": int((~good).sum()),
             "t": [int(one) for one in axis[span]],
             "price": [round(float(one), 2) for one in bones["price"][span]],
             "ema": [round(float(one), 2) for one in bones["ema"][span]],
             "pivots": [one for one in bones["pivots"]
                        if axis[span][0] <= one["t"] <= axis[span][-1]],
             "marks": report}
    block["truth"] = lay(truth)
    block["real"] = lay(walked["розмітка"])
    titles = {"base": "сама собі · одобрені ваги",
              "self": "сама собі · перенавчена"}
    for kind, got in sorted(runs.items()):
        block[kind] = lay(got["said"])
        lines.append({"key": kind, "title": titles[kind], "kind": kind})
    block["lines"] = lines
    block["cuts"] = {kind: [int(stamps[one]) for one in got["cuts"]]
                     for kind, got in runs.items()}
    block["legs"] = {kind: len(got["legs"]) for kind, got in runs.items()}
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} — {block['events']} подій, "
          f"{block['legs']} власних ніг на лінії старту {shown}")
    return block


if __name__ == "__main__":
    main()
