"""Адаптер драбини: «півот у наступні 100 подій» (дослідження 20, розділ 12).

Одобрена версія — `research/20-leg-loss/models/hazard100_win/`: мережа з
памʼяттю на 119 489 ваг (`layers 2 · hidden 64 · head 128 · вікно
градієнта 75 · стеля памʼяті 500`), один вихід `p₁₀₀`. Епоха 8 з 11,
широке AUC `0.7203` на шести монетах.

Реалізація драбини спільна з чотиригоризонтною моделлю —
[`hazard_common.py`](hazard_common.py).
"""

from __future__ import annotations

from pathlib import Path

from hazard_common import (EXTRA, MARGIN, METRIC, METRIC_ABOUT,  # noqa: F401
                           METRIC_DIR, build, data_of, evaluate, human,
                           optimizer, pairs_of, rungs, train_epoch)
import hazard_common

PROJECT_ROOT = Path(__file__).resolve().parents[3]

NAME = "hazard100"
TITLE = "Півот у наступні 100 подій"
SOURCE = "research/20-leg-loss/20-leg-loss.md → розділ 12"
ABOUT = ("Мережа з памʼяттю йде рядом монети подія за подією на "
         "`клас210х14х4ц` і на кожній події каже калібровану ймовірність "
         "того, що нога зігзага скінчиться в наступні 100 подій. Памʼять "
         "рве сама модель — за перевищенням над базовою частотою.")

CONF = {"horizons": (100,),
        "approved": str(PROJECT_ROOT / "research" / "20-leg-loss"
                        / "models" / "hazard100_win")}


def prepare(force: bool = False) -> dict:
    return hazard_common.prepare(CONF, force=force)


def start_from(ctx: dict, model, tune) -> dict:
    return hazard_common.start_from(ctx, model, tune)
