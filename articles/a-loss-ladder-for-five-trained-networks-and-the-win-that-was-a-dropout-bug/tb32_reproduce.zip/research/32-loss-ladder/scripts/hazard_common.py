"""Спільна частина драбини для обох мереж дослідження 20 (`hazard`).

Дослідження: research/32-loss-ladder/
Джерело: research/20-leg-loss/20-leg-loss.md → розділ 12

Мережа з памʼяттю йде рядом монети подія за подією й на кожній каже,
чи скінчиться нога в наступні `N` подій. Одна модель має один горизонт
(`p₁₀₀`), друга — чотири (`p₁₀`, `p₄₀`, `p₁₆₀`, `p₆₄₀`). Усе інше в них
однакове, тому тут одна реалізація, а різниця — у двох тонких модулях
[`ad_hazard.py`](ad_hazard.py) і [`ad_hazard4.py`](ad_hazard4.py).

## Нерухома міра

`широке AUC` — середнє AUC по **шести монетах** після межі розбиття, по
всіх горизонтах моделі. Саме нею одобрена версія вибирала епоху
(розділ 11: вибір по одному BTC — помилка), і драбина її не міняє:
рангова міра не залежить ні від ваги класу, ні від форми втрати.

## Що дорожчає на щаблях

    вага мітки    мітка `p₁₀` стоїть на 1.8 % подій; множник на вагу
                  додатного класу робить пропуск дорожчим
    фокус         `(1 − p_t) ** γ` гасить легкі події, яких 98 %
    близькість    події за `N` кроків до півота дорожчі за решту: саме
                  там від моделі й просять відповідь
    вікно         довжина відрізка, після якого йде крок оптимізатора
    поріг         кратність базовій частоті, на якій рветься памʼять
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LOSS20 = PROJECT_ROOT / "research" / "20-leg-loss" / "scripts"
LEG19 = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
sys.path.insert(0, str(LOSS20))
sys.path.insert(0, str(LEG19))

METRIC = "широке AUC"
METRIC_DIR = "max"
METRIC_ABOUT = ("середнє AUC по шести монетах після межі розбиття, по всіх "
                "горизонтах моделі; рангова міра, тому не залежить від "
                "ваги класу. Більше краще")
MARGIN = 0.001
EXTRA = [{"key": "pooled", "title": "AUC спільним пулом", "dir": "max"},
         {"key": "similar", "title": "схожість десятини", "dir": "max"},
         {"key": "resets_own", "title": "своїх обнулень", "dir": "max"}]

LR = 3e-4
SHAPE = {"layers": 2, "hidden": 64, "head": 128, "window": 75, "cap": 500}
LIFT = 10.0


def rungs() -> list:
    """Щаблі: кожен — одна епоха під своїм штрафом.

    Крок навчання спадає вниз по драбині. Одобрена версія взята на
    восьмій епосі з одинадцяти, тобто вона ще вчилась, — але кроком
    `3e-4` повна епоха з її точки вже переступає, тому далі йде `1e-4`.
    """
    base = {"wmul": 1.0, "gamma": 0.0, "near": (0, 1.0), "window": 75,
            "lift": LIFT}

    def rung(name: str, lr: float = LR, **change) -> dict:
        return {"name": name, "step": {**base, **change}, "lr": lr,
                "show": {"lr": lr,
                         **{key: (list(value) if isinstance(value, tuple)
                                  else value)
                            for key, value in change.items()}}}

    return [
        rung("той самий штраф"),
        rung("вага мітки ×1.5", wmul=1.5),
        rung("фокус γ1", gamma=1.0),
        rung("вага мітки ×2", wmul=2.0),
        rung("близькість ×2 (100 подій)", near=(100, 2.0)),
        rung("той самий штраф · крок ×0.3", lr=1e-4),
        rung("вага ×2 · фокус γ1", lr=1e-4, wmul=2.0, gamma=1.0),
        rung("вікно градієнта 150", lr=1e-4, window=150),
        rung("близькість ×4 (100 подій)", lr=1e-4, near=(100, 4.0)),
        rung("вага ×3", lr=1e-4, wmul=3.0),
        rung("фокус γ2", lr=1e-4, gamma=2.0),
        rung("близькість ×4 · вага ×2", lr=1e-4, near=(100, 4.0),
             wmul=2.0),
        rung("вікно градієнта 40", lr=3e-5, window=40),
        rung("поріг обнулення ×2", lr=3e-5, lift=20.0),
        rung("поріг обнулення ×0.5", lr=3e-5, lift=5.0),
        rung("усе разом", lr=3e-5, wmul=2.0, gamma=1.0, near=(200, 3.0),
             window=150),
    ]


# ---------- втрата щабля ----------


def step_loss(curve, truth, weight, left: float, one: dict):
    """Та сама зважена ентропія, але з фокусом і вагою за близькістю.

    Форма не міняється — міняється ціна помилки. `left` причинний лише
    заднім числом і стоїть **у вазі**, а не у вході: він вирішує, скільки
    коштує помилка на цій події, і в мережу не заходить.
    """
    import torch

    safe = curve.clamp(1e-6, 1.0 - 1e-6)
    each = -(weight * truth * torch.log(safe)
             + (1.0 - truth) * torch.log(1.0 - safe))
    if one["gamma"]:
        right = torch.where(truth > 0.5, safe, 1.0 - safe)
        each = each * ((1.0 - right).clamp(min=0.0)
                       ** one["gamma"]).detach()
    edge, times = one["near"]
    if edge and 0 <= left < edge:
        each = each * times
    return each.mean()


def walk(model, stream: dict, knobs: dict, weights, one: dict,
         optimizer=None) -> dict:
    """Прохід потоком: та сама рекурсія, що в дослідженні 20.

    Копія `hazard_train.walk_stream` з однією зміною: втрата на кроці
    береться з щабля драбини. Усе інше — ворота, поріг, стеля, вікно
    градієнта — лишається як в одобреній версії.
    """
    import torch
    import hazard_net as hazard
    import walk_train

    device = next(model.parameters()).device
    steps = torch.tensor(stream["x"], device=device)
    labels = torch.tensor(stream["labels"].astype(np.float32), device=device)
    known = stream["known"]
    left = stream.get("left")
    total = len(known)
    state = model.zero(device)
    memory: list = []
    weight = torch.tensor(weights, device=device, dtype=torch.float32)
    curves = np.zeros((total, len(hazard.HORIZONS)), dtype=np.float32)
    passed = np.zeros(total, dtype=np.int64)
    losses, chunk, resets = [], [], []
    alpha = 2.0 / (knobs["smooth"] + 1.0)
    run = None
    for index in range(total):
        held = len(memory)
        step = steps[index]
        if knobs["counter"]:
            step = torch.cat([step, walk_train.counter_of(held, knobs["cap"],
                                                          device)])
        logits, state, now = model.step(step, state, memory)
        curve = hazard.curve_of(logits)
        short = hazard.calibrate(curve[0], knobs["weight"])
        gate = hazard.gate_of(short, knobs["base"])
        state = (state[0] * gate, state[1] * gate)
        if known[index]:
            loss = step_loss(curve, labels[index], weight,
                             float(left[index]) if left is not None else -1.0,
                             one)
            chunk.append(loss)
            losses.append(float(loss.item()))
        memory.append(now)
        curves[index] = curve.detach().cpu().numpy()
        passed[index] = held
        value = float(short.detach())
        run = value if run is None else alpha * value + (1 - alpha) * run
        if optimizer is not None and len(chunk) >= knobs["window"]:
            optimizer.zero_grad()
            torch.stack(chunk).mean().backward()
            optimizer.step()
            chunk = []
            state = tuple(part.detach() for part in state)
            memory = [item.detach() for item in memory]
        forced = len(memory) >= knobs["cap"]
        if run >= knobs["threshold"] or forced:
            resets.append({"at": index,
                           "kind": "стеля" if forced
                                   and run < knobs["threshold"] else "поріг"})
            state = model.zero(device)
            memory = []
            run = None
            if optimizer is not None and chunk:
                optimizer.zero_grad()
                torch.stack(chunk).mean().backward()
                optimizer.step()
                chunk = []
    if optimizer is not None and chunk:
        optimizer.zero_grad()
        torch.stack(chunk).mean().backward()
        optimizer.step()
    own = [item for item in resets if item["kind"] == "поріг"]
    return {"loss": float(np.mean(losses)) if losses else 0.0,
            "curve": curves, "passed": passed, "resets": resets,
            "resets_own": len(own),
            "resets_forced": len(resets) - len(own)}


# ---------- дані й мережа ----------


def prepare(conf: dict, force: bool = False) -> dict:
    import torch
    import hazard_net as hazard
    import hazard_train as flow
    import leg_end_data as legs
    from leg_end_train import no_swap

    no_swap(force=force)
    hazard.set_horizons(conf["horizons"])
    cut = legs.cut_stamp(flow.CUT)
    pairs = [flow.PAIR] + list(flow.EXTRA)
    train = [one for one in (flow.stream_of(name, cut, "train")
                             for name in pairs) if one]
    val = [one for one in (flow.stream_of(name, cut, "val")
                           for name in pairs) if one]
    left = np.concatenate([one["left"][one["known"]] for one in train])
    labels = np.concatenate([one["labels"][one["known"]] for one in train])
    spans = hazard.spans_of(left)
    weights = hazard.weights_of(labels)
    base = hazard.base_rate(labels)
    knobs = {"cap": SHAPE["cap"], "window": SHAPE["window"], "smooth": 10,
             "threshold": hazard.threshold_of(labels, LIFT), "counter": True,
             "weight": weights[0], "base": base}
    print(f"потоки train: " + " · ".join(
        f"{one['pair']} {len(one['y'])}" for one in train))
    print(f"потоки val: " + " · ".join(
        f"{one['pair']} {len(one['y'])}" for one in val))
    print(f"горизонти {hazard.HORIZONS} · базова частота {base:.4f} · "
          f"ваги класів " + " · ".join(f"{one:.0f}" for one in weights))
    return {"conf": conf, "train": train, "val": val, "spans": spans,
            "weights": weights, "knobs": knobs, "labels_base": base,
            "device": "cpu", "cut": flow.CUT, "pairs": pairs}


def build(ctx: dict, seed: int):
    import torch
    import hazard_net as hazard

    torch.manual_seed(seed)
    width = int(ctx["train"][0]["x"].shape[1]) + 1
    model = hazard.HazardNet(features=width, heads=2,
                             outputs=len(hazard.HORIZONS),
                             hidden=SHAPE["hidden"], head=SHAPE["head"],
                             dropout=0.1, layers=SHAPE["layers"]).to("cpu")
    ctx["width"] = width
    ctx["params"] = hazard.parameters_of(model)
    return model, optimizer(ctx, model)


def optimizer(ctx: dict, model):
    import torch

    return torch.optim.Adam(model.parameters(), lr=LR)


def start_from(ctx: dict, model, tune) -> dict:
    import torch

    path = Path(ctx["conf"]["approved"]) / "model.pt"
    if not path.exists():
        raise SystemExit(f"немає одобрених ваг: {path}")
    model.load_state_dict(torch.load(path, map_location="cpu"))
    print(f"старт із {path.parent.name}: стан оптимізатора набереться заново")
    return {"config": {**SHAPE, "lr": LR, "lift": LIFT,
                       "horizons": list(ctx["conf"]["horizons"]),
                       "from": str(Path(ctx["conf"]["approved"])
                                   .relative_to(PROJECT_ROOT))}}


def train_epoch(ctx: dict, model, tune, rung: dict, seed: int,
                attempt: int = 1) -> float:
    """Епоха під штрафом щабля; повторна спроба — вдвічі меншим кроком."""
    import hazard_net as hazard

    one = rung["step"]
    for group in tune.param_groups:
        group["lr"] = rung.get("lr", LR) / (2 ** (attempt - 1))
    knobs = {**ctx["knobs"], "window": one["window"]}
    if one["lift"] != LIFT:
        labels = np.concatenate([row["labels"][row["known"]]
                                 for row in ctx["train"]])
        knobs["threshold"] = hazard.threshold_of(labels, one["lift"])
    weights = [value * one["wmul"] for value in ctx["weights"]]
    model.train()
    began = time.time()
    got = [walk(model, stream, knobs, weights, one, tune)["loss"]
           for stream in ctx["train"]]
    print(f"    епоха пройшла за {(time.time() - began) / 60:.1f} хв")
    return float(np.mean(got))


# ---------- замір ----------


def evaluate(ctx: dict, model) -> dict:
    """Широке AUC: шість монет після межі, усі горизонти моделі."""
    import torch
    import hazard_net as hazard
    import hazard_train as flow

    base = {"wmul": 1.0, "gamma": 0.0, "near": (0, 1.0), "window": 75,
            "lift": LIFT}
    model.eval()
    by_pair, means = {}, []
    pooled_said, pooled_truth = [], []
    similar, own, forced = [], 0, 0
    with torch.no_grad():
        for stream in ctx["val"]:
            walked = walk(model, stream, ctx["knobs"], ctx["weights"], base)
            known = stream["known"]
            each = [hazard.auc_of(walked["curve"][known, index],
                                  stream["labels"][known, index])
                    for index in range(len(hazard.HORIZONS))]
            good = [float(value) for value in each if value == value]
            mean = float(np.mean(good)) if good else float("nan")
            means.append(mean)
            got = flow.scores_of(stream, walked, ctx["spans"])
            if got["similar"] is not None:
                similar.append(float(got["similar"]))
            own += walked["resets_own"]
            forced += walked["resets_forced"]
            pooled_said.append(walked["curve"][known, 0])
            pooled_truth.append(stream["labels"][known, 0])
            by_pair[stream["pair"]] = {
                "mark": mean,
                "auc": {str(one): (float(value) if value == value else None)
                        for one, value in zip(hazard.HORIZONS, each)},
                "similar": got["similar"],
                "events": int(known.sum()),
                "pivots": int(len(stream["pivots"])),
                "resets_own": walked["resets_own"],
                "resets_forced": walked["resets_forced"]}
    pooled = hazard.auc_of(np.concatenate(pooled_said),
                           np.concatenate(pooled_truth))
    return {"mark": float(np.nanmean(means)),
            "metrics": {"pooled": float(pooled),
                        "similar": float(np.mean(similar)) if similar
                        else None,
                        "resets_own": own, "resets_forced": forced,
                        "events": int(sum(one["events"]
                                          for one in by_pair.values()))},
            "by_pair": by_pair}


def human(got: dict) -> str:
    one = got["metrics"]
    return (f"пул {one['pooled']:.4f} · своїх обнулень {one['resets_own']} · "
            f"стелею {one['resets_forced']}")


def pairs_of(ctx: dict) -> list:
    return [one["pair"] for one in ctx["val"]]


def data_of(ctx: dict) -> dict:
    import hazard_net as hazard

    return {"class": "клас210х14х4ц", "cut": ctx["cut"],
            "horizons": list(hazard.HORIZONS),
            "features": ctx.get("width"),
            "params": ctx.get("params"),
            "shape": {**SHAPE, "lr": LR, "lift": LIFT},
            "events": {"train": int(sum(len(one["y"])
                                        for one in ctx["train"])),
                       "val": int(sum(len(one["y"]) for one in ctx["val"]))},
            "approved": str(Path(ctx["conf"]["approved"])
                            .relative_to(PROJECT_ROOT))}
