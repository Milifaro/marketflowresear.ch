"""Одне обнулення на ногу: зона часткою ноги і ціна за сам натиск.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Етап 9 показав, чому мережа тисне скрізь. Порахуймо, що їй коштує
кожна стратегія у втраті етапу 8:

    мовчати після розвороту   до 0.5 × 81 = **40 за подію**, і так
                              до 150 подій поспіль
    хибно обнулитись          один спуск ≈ 0.13 висоти × 120 = **15**,
                              разово

Тиснути часто дешевше, ніж чекати, — і мережа робить саме це: 34.7
обнулень на 1000 подій там, де справжніх розворотів 2.5. Лінія через це
не встигає вирости й живе в діапазоні 0.15 замість 0…1.

## Що міняється

| було (етап 8) | стало |
| ------------- | ----- |
| зона 50 подій на всі ноги | зона — **частка ноги** (`SHARE`), у межах `LOW`…`HIGH` подій |
| за натиск поза зоною платиться тільки драбиною відстані | додається **бюджет ноги**: одне обнулення безплатно, все понад нього — `price × (перебір)²` |
| стеля драбини 81 | `ROOF` нижча: мовчання більше не дорожче за все інше разом |
| епоха обирається за формою і влучністю | до вибору входить **частота**: ціль — одне обнулення на ногу |

Ціна натиску росте по епохах драбиною `PRESS`: спершу мережа тримає
влучність, далі її тиснуть на частоту. Одним числом з самого початку
це не робиться — мережа просто замовкає зовсім.

Зона рахується **на кожну подію зі своєї ноги**: довжина ноги в цій
точці — `far + past + 1`, а `far` і `past` уже є в тензорах. Розмітка
на вхід не заходить, це тільки ціна у втраті.

Вхід : ваги `models/legzone/model.pt` (етап 8)
Вихід: results/rate_train.json, models/legrate/model.pt

Запуск:
    python3 research/32-loss-ladder/scripts/rate_train.py --epochs 40
    python3 research/32-loss-ladder/scripts/rate_train.py --epochs 20 --resume
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = SCRIPTS.parents[2]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

NAME = "legrate"
FROM = "legzone"
SEED = 0
EPOCHS = 40
PATIENCE = 12
LR = 1e-4
SHARE = 0.095              # зона до розвороту: частка ноги (zone_length.py)
LOW = 15                   # але не коротша за стільки подій
HIGH = 150                 # і не довша за стільки
HEAD = 15                  # голова зони лишається в подіях
FAR = 150
NEAR = 200
DEAD = 0.20
FADE = 0.35
AIM = 2.5                  # ціль: стільки обнулень на 1000 подій — одне на ногу
FREE = (0.10, 0.07, 0.05, 0.03, 0.02)
FLAT = 2.0                 # рівна ціна за натиск поза зоною, стала
PRESS = (5.0, 20.0, 60.0, 150.0, 400.0, 900.0, 2000.0)   # ціна перебору
LATE = (0.5, 0.35, 0.2, 0.1, 0.05, 0.02)   # ціна мовчання: вниз по епохах
BUDGET = 1.0               # скільки обнулень на ногу дозволено безплатно
KNOBS = {"down": 6.0, "up": 2.0, "grow": 5.0, "fall": 120.0, "cliff": 60.0,
         "tail": 4.0, "edge": 0.1, "early": 0.5, "late": 0.5, "times": 3.0,
         "pace": 5.0, "roof": 27.0, "far": FAR, "dead": DEAD, "fade": FADE,
         "share": SHARE, "low": LOW, "high": HIGH, "head": HEAD}
SCRIPT = "research/32-loss-ladder/scripts/rate_train.py"
OUT = "rate_train.json"


def sibling(name: str):
    """Сусідній скрипт дослідження — за шляхом файлу, а не за іменем."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


# ------------------------------------------------------------------ втрата

def tail_of(far, past, knobs: dict):
    """Зона до розвороту **цієї** ноги: частка її довжини, з межами.

    Довжина ноги в кожній події — `far + past + 1`: скільки лишилось до
    її кінця плюс скільки минуло від початку. Розмітки на вході мережі
    від цього не додається, число живе тільки в ціні.
    """
    import torch

    length = far + past + 1.0
    size = knobs["share"] * length
    return torch.clamp(size, min=float(knobs["low"]), max=float(knobs["high"]))


def outside_of(reset, far, past, knobs: dict):
    """Скільки мережа натиснула **поза** зоною розвороту, подія за подією."""
    zone = tail_of(far, past, knobs)
    inside = ((far <= zone) | (past <= knobs["head"])).to(reset.dtype)
    pull = (reset - knobs["dead"]) / (1.0 - knobs["dead"]) \
        if knobs["dead"] > 0 else reset
    return pull.clamp(0.0, 1.0) * (1.0 - inside)


def press_step(reset, far, past, knobs: dict, price: float = FLAT):
    """Рівна ціна за натиск поза зоною — і вона **не працює сама**.

    Перший прогін це показав числами: ціна росла з 2 до 55, частота
    стояла на 24…34 обнуленнях на 1000, а розмах лінії впав з 0.156 до
    нуля. Причина в тому, що лінійна ціна керує **сумою** натиску, а
    не його кількістю: найдешевша відповідь — стиснути всі зубці
    нарівно, а не прибрати зайві. Тому вона лишається малою сталою, а
    кількістю керує бюджет.
    """
    return price * outside_of(reset, far, past, knobs)


def budget_step(reset, far, past, born, own, knobs: dict, price: float,
                budget: float = BUDGET):
    """Бюджет ноги: одне обнулення безплатно, все понад — квадратично.

    Кількість натисків — не сума, і рівною ціною вона не береться.
    Тому натиски складаються **в межах своєї ноги**: нога ділиться за
    подіями народження (`born`), усередині неї береться сума `pull`
    поза зоною, і платиться `price × (сума − budget)²`. До бюджету
    мережа не платить нічого, за ним ціна росте швидше за вигоду.

    Ноги, розрізані краєм вікна, теж дістають цілий бюджет: таких
    відрізків два на вікно з 1200 подій, і на числа це не впливає.
    """
    import torch

    spend = outside_of(reset, far, past, knobs) * own
    leg = born.cumsum(dim=1).long()
    rows, width = leg.shape[0], int(leg.max().item()) + 1
    place = (torch.arange(rows, device=leg.device).unsqueeze(1) * width
             + leg).reshape(-1)
    total = torch.zeros(rows * width, device=spend.device,
                        dtype=spend.dtype).index_add_(0, place,
                                                      spend.reshape(-1))
    return price * ((total - budget).clamp(min=0.0) ** 2).sum()


def pivot_step(reset, far, past, born, knobs: dict, tools):
    """Драбина промаху етапу 8, але зона в кожної ноги своя.

    `tools` — модуль `zone_train`: драбина, мовчання і мертва зона
    беруться звідти, щоб формула лишалась одна на два етапи.
    """
    size = tail_of(far, past, knobs)
    pull = tools.pulled(reset, knobs.get("dead", 0.0))
    early = (far - size).clamp(min=0.0)
    hurt = knobs["early"] * tools.ladder_of(early, knobs) \
        * (far > size).to(pull.dtype) * pull
    late = (past - knobs["head"]).clamp(min=0.0)
    alive = ((past > knobs["head"])
             & (past <= knobs["head"] + knobs["far"])).to(pull.dtype)
    hurt = hurt + knobs["late"] * tools.ladder_of(late, knobs) * alive \
        * tools.still_of(pull, born) * (1.0 - pull)
    return hurt


def price_at(number: int, total: int, ladder=PRESS) -> float:
    """Значення драбини на цій епосі: та сама форма, що й у коридора.

    Другий прогін уперся в рівновагу: бюджет тисне частоту вниз, а
    доданок «мовчання після розвороту» — вгору, і вони стають на
    двадцяти обнуленнях на 1000. Тому вниз ведеться і ціна мовчання
    (`LATE`): поки вона коштує до 13.5 за подію, тиснути частіше
    завжди дешевше, ніж чекати.
    """
    if total <= 1:
        return float(ladder[-1])
    place = (number - 1) / max(total - 1, 1) * (len(ladder) - 1)
    low = int(np.floor(place))
    high = min(low + 1, len(ladder) - 1)
    part = place - low
    return float(ladder[low] * (1 - part) + ladder[high] * part)


def zone_pair(rows: list, picked: list) -> tuple:
    """Зона для **заміру**: середня по ногах val, щоб число було одне."""
    sizes = [max(min(int(round(rows[one]["events"] * SHARE)), HIGH), LOW)
             for one in picked]
    return int(round(float(np.median(sizes)))) if sizes else LOW, HEAD


def score_of(one: dict, aim: float = AIM) -> float:
    """Вибір епохи: форма, влучність у зону і **частота** разом.

    Частота входить прямо: одне обнулення на ногу — це `aim` на 1000
    подій, і кожне зайве робить епоху гіршою. Без цього доданка вибір
    завжди падав на епоху, яка тисне частіше й тому частіше вгадує.
    """
    zone = sibling("zone_train")
    often = float(one.get("often") or 0.0)
    return round(zone.score_of(one)
                 + min(often / max(aim, 1e-9), 40.0) / 20.0, 4)


def measure(model, built: dict, rows: list, picked: list, boxes: list,
            true: np.ndarray, seen: np.ndarray, device: str, zone: tuple):
    """Видача на вікнах val плюс влучність обнулення в зону."""
    return sibling("zone_train").measure(model, built, rows, picked, boxes,
                                         true, seen, device, zone)


# ---------------------------------------------------------------- навчання

def epoch_of(model, tune, built: dict, boxes: list, true: np.ndarray,
             ahead: np.ndarray, back: np.ndarray, device: str, seed: int,
             free: float, price: float, knobs: dict, tools) -> float:
    """Одна епоха: форма етапу 7, драбина етапу 8 і ціна за натиск."""
    import torch
    import share_train as share

    model.train()
    chunks = share.packed(boxes)
    order = list(range(len(chunks)))
    np.random.default_rng(seed).shuffle(order)
    total, seen = 0.0, 0

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, far, past, born = tools.tensors_of(
            built, chunk, true, ahead, back, device)
        if scale is None:
            scale = own.sum()
        said, reset = share.saw_of(model(x, mask, lengths), knobs["step"],
                                   knobs["fade"], knobs["dead"])
        chain = own.clone()
        chain[:, :1] = 0.0
        chain[:, 1:] = chain[:, 1:] * own[:, :-1]
        step = pivot_step(reset, far, past, born, knobs, tools) \
            + press_step(reset, far, past, knobs) \
            + share.share_step(said, y, chain, knobs, free)
        piece = ((step * own).sum()
                 + budget_step(reset, far, past, born, own, knobs,
                               price)) / scale
        piece.backward()
        return float(piece.detach()), int(own.sum().item()), scale

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            share.free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2]

    for number in order:
        tune.zero_grad()
        got, count, _ = learn(chunks[number])
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        share.free_of(device)
        total += got * count
        seen += count
    return total / max(seen, 1)


def save(curve: list, best, counter: dict, args, device: str, began: float,
         win: int, warm: int, zone: tuple, knobs: dict) -> None:
    """Звіт пишеться після кожної епохи: прогін нічний, і його рвуть."""
    import share_train as share

    report = {"script": SCRIPT, "ready": True, "model": NAME, "from": FROM,
              "lr": args.lr, "win": win, "warm": warm, "near": share.NEAR,
              "wide": share.WIDE, "edge": share.EDGE, "aim": AIM,
              "patience": args.patience,
              "free": list(FREE), "press": list(PRESS),
              "late": list(LATE), "flat": FLAT, "budget": BUDGET,
              "knobs": knobs,
              "device": device, "share": SHARE, "low": LOW, "high": HIGH,
              "zone": {"tail": zone[0], "head": zone[1], "far": FAR},
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "counter": counter, "curve": curve, "best": best,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / OUT).write_text(json.dumps(report, ensure_ascii=False),
                               encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--minutes", type=float, default=400.0)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--patience", type=int, default=PATIENCE,
                        help="0 — не спиняти: драбина має пройти всю")
    parser.add_argument("--resume", action="store_true",
                        help="доучити те, що вже лежить у models/legrate")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    train = sibling("zone_train")
    ctx = ad.prepare(force=args.force)
    device, rows, built = ctx["device"], ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    hot = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    was = json.loads((RESULTS / "zone_train.json").read_text(
        encoding="utf-8")) if (RESULTS / "zone_train.json").exists() else {}
    win = int(was.get("win", share.WIN))
    warm = int(was.get("warm", share.WARM))
    seen_zone = zone_pair(rows, val)
    knobs = {**KNOBS, "step": share.STEP, "zone": list(seen_zone)}

    first, last = share.edges_of(rows, hot + val, total)
    true = share.truth_of(first, last)
    ahead, back = train.steps_of(rows, hot + val, total)
    train_boxes = share.windows(share.spans_of(rows, hot), win, warm)
    val_boxes = share.windows(share.spans_of(rows, val), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in val_boxes:
        seen[one["first"]:one["last"] + 1] = True
    print(f"вікон: train {len(train_boxes)}, val {len(val_boxes)} по {win} "
          f"подій · зона {SHARE:.1%} ноги ({LOW}…{HIGH} подій), "
          f"на замір {seen_zone[0]}/{seen_zone[1]} · ціль {AIM}/1000 · "
          f"пристрій {device}")

    counter = share.marks(
        share.counter_line(built["x"], rows, val, total), true, seen,
        [(rows[one]["first"], rows[one]["last"]) for one in val])
    print(f"лічильник розмітки: міра {counter['mark']} · обвал "
          f"{counter['cliff']}")

    model = share.build_of(ctx, ad, share.SEED)
    keep = MODELS / NAME
    keep.mkdir(parents=True, exist_ok=True)
    tune = torch.optim.AdamW(model.parameters(), lr=args.lr)
    curve, best, stale = [], None, 0
    path = RESULTS / OUT
    started = MODELS / FROM / "model.pt"
    if args.resume and path.exists() and (keep / "model.pt").exists():
        older = json.loads(path.read_text(encoding="utf-8"))
        series.lift(model, keep / "model.pt")
        if (keep / "tune.pt").exists():
            tune.load_state_dict(torch.load(keep / "tune.pt",
                                            map_location="cpu"))
        curve, best = list(older.get("curve", [])), older.get("best")
        print(f"продовжую з епохи {len(curve) + 1}")
    elif started.exists():
        series.lift(model, started)
        print(f"починаю з ваг {started.relative_to(PROJECT_ROOT)}")
    else:
        raise SystemExit(f"немає ваг етапу 8: {started}")

    began = time.time()
    last_epoch = len(curve) + args.epochs
    for number in range(len(curve) + 1, last_epoch + 1):
        free = share.free_at(number, last_epoch, FREE)
        price = price_at(number, last_epoch)
        knobs["late"] = price_at(number, last_epoch, LATE)
        loss = epoch_of(model, tune, built, train_boxes, true, ahead, back,
                        device, SEED + number, free, price, knobs, train)
        share.free_of(device)
        now = measure(model, built, rows, val, val_boxes, true, seen, device,
                      seen_zone)
        share.free_of(device)
        spent = (time.time() - began) / 60.0
        step = {"epoch": number, "loss": round(loss, 4), "free": free,
                "price": round(price, 2),
                "late": round(knobs["late"], 4),
                **{key: value for key, value in now.items()
                   if key not in ("said", "fired")}}
        step["score"] = score_of(step)
        curve.append({**step, "minutes": round(spent, 1)})
        print(f"  епоха {number:>2} · ціна {price:6.1f} · мовчання "
              f"{knobs['late']:.3f} · втрата "
              f"{loss:.4f} · міра {now['mark']} · розмах "
              f"{round(now['head'] - now['tail'], 4)} · обнулень "
              f"{now['often']}/1000 · у зоні {now['inzone']} · без сигналу "
              f"{now['missed']} · оцінка {step['score']} · {spent:.1f} хв")
        if best is None or step["score"] < best["score"]:
            best = {key: value for key, value in step.items()}
            stale = 0
            torch.save(model.state_dict(), keep / "model.pt")
            torch.save(tune.state_dict(), keep / "tune.pt")
        else:
            stale += 1
        save(curve, best, counter, args, device, began, win, warm,
             seen_zone, knobs)
        if (args.patience and stale >= args.patience) \
                or spent > args.minutes:
            break
    save(curve, best, counter, args, device, began, win, warm, seen_zone,
         knobs)


if __name__ == "__main__":
    main()
