"""Зведення драбини в таблиці для файлу дослідження.

Дослідження: research/32-loss-ladder/

Читає `results/ladder_<модель>.json` і друкує markdown: зведення по всіх
моделях, хід кожної драбини щабель за щаблем і видачу на val по кожній
монеті — одобрена версія проти того, що взяла драбина.

Нічого не рахує заново: усі числа беруться з файлів прогонів.

Запуск:
    python3 research/32-loss-ladder/scripts/report.py
    python3 research/32-loss-ladder/scripts/report.py --model legleft
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

RESEARCH_DIR = Path(__file__).resolve().parents[1]
RESULTS = RESEARCH_DIR / "results"
MODELS = ("legleft", "legtip", "hazard100", "hazard4", "zone")
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")


def number(value, digits: int = 4) -> str:
    if value is None or isinstance(value, bool):
        return "—"
    if isinstance(value, (int, float)):
        if value != value or value in (float("inf"), float("-inf")):
            return "—"
        return f"{value:.{digits}f}"
    return str(value)


def finite(value) -> bool:
    """Чи це число, з яким можна рахувати: не None, не NaN, не ±∞."""
    return isinstance(value, (int, float)) and not isinstance(value, bool) \
        and value == value and value not in (float("inf"), float("-inf"))


def load(name: str) -> dict | None:
    path = RESULTS / f"ladder_{name}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def summary(runs: dict) -> str:
    rows = ["| Модель | Міра | Одобрена | Драбина | Зміна | Шум замірювання |"
            " Щаблів узято | Спроб |",
            "| ------ | ---- | -------: | ------: | ----: | --------------: |"
            " -----------: | ----: |"]
    for name, got in runs.items():
        gain = got["gain"]
        sign = "+" if gain > 0 else ""
        mark = "**краще**" if got["better"] else "не краще"
        noise = spread_of(got)
        # рахуємо по самих щаблях: прогін міг іти у два заходи, і
        # лічильники у файлі належать останньому з них
        tried = sum(1 for row in got["rungs"] if row["rung"])
        taken = sum(1 for row in got["rungs"] if row["rung"] and row["kept"])
        rows.append(
            f"| `{name}` | {got['metric']} "
            f"({'менше' if got['metric_dir'] == 'min' else 'більше'}) "
            f"| {number(got['base']['mark'])} | {number(got['best']['mark'])} "
            f"| {sign}{number(gain)} — {mark} "
            f"| ±{number(noise['median'])} ({noise['pairs']} пар) "
            f"| {taken} | {tried} |")
    return "\n".join(rows)


def spread_of(got: dict) -> dict:
    """Розкид міри між двома спробами того самого щабля.

    Дві спроби одного щабля — це та сама модель, ті самі дані й той
    самий штраф; різниться тільки порядок батчів і крок. Тому різниця
    між ними — це **шум замірювання**, і виграш драбини читається тільки
    поруч із ним: виграш, менший за розкид, виграшем не є.
    """
    pairs, seen = [], {}
    for row in got["rungs"]:
        # щабель, що зламав канал, має міру −inf: різниця з ним не число
        if not row["rung"] or not finite(row["mark"]):
            continue
        if row["rung"] in seen:
            pairs.append(abs(row["mark"] - seen[row["rung"]]))
        seen[row["rung"]] = row["mark"]
    if not pairs:
        return {"pairs": 0, "median": None, "top": None}
    pairs.sort()
    middle = pairs[len(pairs) // 2] if len(pairs) % 2 else \
        (pairs[len(pairs) // 2 - 1] + pairs[len(pairs) // 2]) / 2
    return {"pairs": len(pairs), "median": middle, "top": pairs[-1]}


def knobs_of(row: dict) -> str:
    """Ручки щабля; `lr` показується **тим, яким епоха реально йшла**.

    Повторна спроба щабля йде вдвічі меншим кроком, і в щаблі записаний
    його номінальний крок — той, з якого спроби починаються.
    """
    out = []
    for key, value in (row.get("config") or {}).items():
        if key == "lr" and row.get("attempt", 1) > 1:
            value = value / (2 ** (row["attempt"] - 1))
        if isinstance(value, list):
            value = "–".join(str(one) for one in value)
        if isinstance(value, float):
            value = f"{value:g}"
        out.append(f"{key} {value}")
    return " · ".join(out) or "—"


def rungs_table(got: dict) -> str:
    rows = [f"| Щабель | Що дорожчає | Спроба | Втрата | {got['metric']} |"
            " Рішення | Ручки |",
            "| -----: | ----------- | -----: | -----: | ----: | ------- |"
            " ----- |"]
    for row in got["rungs"]:
        decision = "**лишаю**" if row["kept"] else "вертаю"
        if row["rung"] == 0:
            decision = "точка відліку"
        mark = number(row["mark"])
        if (row.get("metrics") or {}).get("broken"):
            mark = "канал зламано"
        elif row["mark"] is None:
            mark = "не зміряно"
        rows.append(
            f"| {row['rung'] or '—'} | {row['name']} "
            f"| {row['attempt'] or '—'} | {number(row['loss'])} "
            f"| {mark} | {decision} | {knobs_of(row)} |")
    return "\n".join(rows)


def pairs_table(got: dict) -> str:
    # у таблицю монет ідуть міра і два числа поруч: більше колонок на
    # сторінку не лізе, а решта чисел стоїть у щаблях
    keys = [{"key": "mark", "title": got["metric"], "percent": False}]
    keys += [dict(one) for one in got.get("extra", [])
             if any(one["key"] in row
                    for row in got["best"]["by_pair"].values())][:2]
    head = ["| Монета |"]
    line = ["| ------ |"]
    for one in keys:
        head.append(f" {one['title']}: одобрена | драбина | зміна |")
        line.append(" ---: | ---: | ---: |")
    head.append(" Подій val |")
    line.append(" --------: |")
    rows = ["".join(head), "".join(line)]
    order = [one for one in PAIRS if one in got["best"]["by_pair"]]
    order += [one for one in got["best"]["by_pair"] if one not in PAIRS]
    for pair in order:
        before = got["base"]["by_pair"].get(pair, {})
        after = got["best"]["by_pair"].get(pair, {})
        cells = [f"| {pair} |"]
        for one in keys:
            was, now = before.get(one["key"]), after.get(one["key"])
            gain = (now - was) if isinstance(was, (int, float)) \
                and isinstance(now, (int, float)) else None
            digits = 1 if one.get("percent") else 4
            scale = 100 if one.get("percent") else 1
            cells.append(
                f" {number(None if was is None else was * scale, digits)} |"
                f" {number(None if now is None else now * scale, digits)} |"
                f" {'—' if gain is None else ('+' if gain > 0 else '') + number(gain * scale, digits)} |")
        events = after.get("events") or before.get("events")
        cells.append(f" {events if events else '—'} |")
        rows.append("".join(cells))
    return "\n".join(rows)


def beyond_noise(got: dict, noise: float) -> list:
    """Щаблі, що побили одобрену версію **більше ніж на шум**.

    Виграш, менший за розкид двох спроб того самого щабля, — це вибір
    із шуму, а не покращення. Тут лишаються тільки ті щаблі, різниця
    яких із точкою відліку більша за цей розкид.
    """
    base = got["base"]["mark"]
    out = []
    for row in got["rungs"]:
        if not row["rung"] or not finite(row["mark"]) or not finite(base):
            continue
        gain = row["mark"] - base
        if (gain < -noise) if got["metric_dir"] == "min" else (gain > noise):  # noqa: E501
            out.append(row)
    return out


def noise_line(got: dict) -> str:
    """Рядок про шум: виграш читається тільки поруч із ним."""
    noise = spread_of(got)
    if not noise["pairs"]:
        return ("Пар спроб на одному щаблі немає — шум замірювання цим "
                "прогоном не зміряний.")
    gain = abs(got["gain"])
    strong = beyond_noise(got, noise["median"])
    tried = sum(1 for row in got["rungs"] if row["rung"])
    verdict = ("більший за шум" if gain > noise["median"]
               else "**менший за шум**")
    names = []
    for one in strong:                   # щабель рахується раз, не за спробу
        if one["name"] not in names:
            names.append(one["name"])
    tail = (f" Спроб, що побили одобрену версію більше ніж на шум: "
            f"{len(strong)} з {tried}"
            + (f" — {', '.join(names)}." if names else ", тобто **жодної**."))
    return (f"Шум замірювання: дві спроби того самого щабля розходяться на "
            f"{number(noise['median'])} (медіана {noise['pairs']} пар, "
            f"найбільша {number(noise['top'])}). Виграш драбини "
            f"{number(gain)} — {verdict}." + tail)


def coins_line(got: dict) -> str:
    """Скільки монет покращилось — середнє по монетах ховає монету.

    Виграш може стояти на одній-двох монетах, а решта при цьому
    просідає. Середнє про це не каже нічого, тому воно читається разом
    із цим рядком.
    """
    rows, skipped = [], []
    for pair, after in got["best"]["by_pair"].items():
        before = got["base"]["by_pair"].get(pair, {})
        was, now = before.get("mark"), after.get("mark")
        if not finite(was) or not finite(now):
            # у монети, де хоч раз зламався канал, міри немає зовсім
            skipped.append(pair)
            continue
        gain = now - was
        rows.append((pair, -gain if got["metric_dir"] == "min" else gain))
    if not rows:
        return ""
    rows.sort(key=lambda one: one[1])
    good = [one for one in rows if one[1] > 0]
    tail = (f" Ще на {len(skipped)} монетах міри немає — там канал "
            f"зламаний на одному з боків порівняння: "
            f"{', '.join(skipped)}." if skipped else "")
    return (f"По монетах: покращилось {len(good)} з {len(rows)}.{tail} "
            f"Найбільше — {rows[-1][0]} ({'+' if rows[-1][1] > 0 else ''}"
            f"{number(rows[-1][1])}), найгірше — {rows[0][0]} "
            f"({'+' if rows[0][1] > 0 else ''}{number(rows[0][1])}). "
            f"Знак тут завжди «краще», хай куди дивиться сама міра.")


def show(name: str, got: dict) -> str:
    out = [f"### `{name}` — {got['title']}", "",
           f"Джерело: {got['source']}. Одобрені ваги: "
           f"`{got['data'].get('approved', '—')}`.", "",
           f"**Нерухома міра — {got['metric']}.** {got['metric_about']}", "",
           f"Одобрена версія дала **{number(got['base']['mark'])}**, "
           + (f"драбина — **{number(got['best']['mark'])}** "
              f"(щабель {got['best']['rung']} · {got['best']['name']})."
              if got["better"] else
              "жоден щабель її не побив."), "",
           noise_line(got), "",
           coins_line(got), "",
           "#### Щаблі", "", rungs_table(got), "",
           "#### Видача на val по монетах", "", pairs_table(got), ""]
    return "\n".join(out)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--model", default=None)
    args = parser.parse_args()
    names = [args.model] if args.model else list(MODELS)
    runs = {}
    for name in names:
        got = load(name)
        if got is None:
            print(f"<!-- {name}: прогону ще немає -->")
            continue
        runs[name] = got
    if not runs:
        return
    if not args.model:
        print("## Результат\n")
        print(summary(runs))
        print()
    for name, got in runs.items():
        print(show(name, got))


if __name__ == "__main__":
    main()
