"""Драбина втрат: донавчання одобрених мереж із посиленням штрафу.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання, Інші функції втрат

Кожна одобрена мережа проєкту вже має свою найкращу версію: ваги, ручки
й число на val. Тут з цієї версії **продовжують** — епоха за епохою, і
між епохами міняється функція втрат: штраф на щаблі росте.

    щабель 1  ->  епоха  ->  замір на val  ->  краще? лишаємо : вертаємо
    щабель 2  ->  епоха  ->  замір на val  ->  ...

## Чому це не «навчання з адаптивною втратою»

Втрата міняється **між** епохами, а не всередині кроку, і міняється за
явним розкладом — не від метрики. Це важливо: втрата з зворотним
звʼязком від метрики оптимізує саму себе, а розклад — ні.

## Чим міряється

Втрата міняється, тому **крива втрати нічого не каже**: число під
щаблем 5 не порівнюється з числом під щаблем 1. Тому в кожного адаптера
є **нерухома міра** (`METRIC`), яка стоїть на всьому прогоні й ніколи не
залежить від того, чим зараз вчать. Саме вона вирішує, лишається епоха
чи відкочується.

## Що робиться, коли гірше

Гірша епоха не лишається. Ваги вертаються до найкращих, **оптимізатор
збирається заново** (моменти AdamW набрані під іншим штрафом і тягнуть
не туди), порядок батчів міняється, **крок навчання ділиться навпіл** —
і той самий щабель учиться ще раз. Після `--attempts` невдач щабель
лишається невзятим, і драбина йде далі: наступний щабель стартує з тих
самих найкращих ваг.

Крок навчання спадає й уздовж самої драбини: одобрена версія стоїть у
своєму оптимумі на val, і повна епоха тим самим кроком, яким її вчили,
з нього просто виходить. Тому перші щаблі йдуть кроком одобреної версії,
далі — вдвічі й учетверо меншим.

## Вихід

    results/ladder_<модель>.json    хід драбини, щабель за щаблем
    models/<модель>/model.pt        найкраща версія, знайдена драбиною

Кожен замір на val лягає **по монетах**: таблиця на вкладці показує
кожну з шести окремо, бо середнє по монетах ховає, де саме зсув.

Запуск:
    python3 research/32-loss-ladder/scripts/ladder.py --model legleft
    python3 research/32-loss-ladder/scripts/ladder.py --model legtip \\
        --minutes 90 --attempts 2
    python3 research/32-loss-ladder/scripts/ladder.py --list
"""

from __future__ import annotations

import argparse
import importlib
import json
import signal
import sys
import time
from pathlib import Path

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

# Адаптер на кожну одобрену мережу: модуль у цій же теці.
ADAPTERS = {
    "legleft": "ad_legleft",
    "legtip": "ad_legtip",
    "hazard100": "ad_hazard",
    "hazard4": "ad_hazard4",
    "zone": "ad_zone",
}

STOP = {"asked": False}


def listen() -> None:
    """`kill -TERM` домальовує поточний щабель і виходить із файлами."""

    def ask(*_):
        STOP["asked"] = True
        print("\nзупинка на прохання: дорахую щабель і запишу файли")

    for one in (signal.SIGTERM, signal.SIGINT):
        signal.signal(one, ask)


def adapter_of(name: str):
    if name not in ADAPTERS:
        raise SystemExit(f"невідома модель: {name}; є {', '.join(ADAPTERS)}")
    return importlib.import_module(ADAPTERS[name])


def improved(got: dict, best: dict, direction: str,
             margin: float = 0.0) -> bool:
    """Чи краща нова версія за найкращу — за нерухомою мірою.

    `margin` — мертва зона: зміна, менша за неї, зміною не вважається.
    Без неї драбина ловила б шум замірювання й «покращувала» модель
    туди-сюди на четвертому знаку.
    """
    one, two = got["mark"], best["mark"]
    if one != one:                       # NaN: замір не вдався
        return False
    return one < two - margin if direction == "min" else one > two + margin


def state_of(model):
    import torch

    return {key: value.detach().to("cpu").clone()
            for key, value in model.state_dict().items()}


def restore(model, state) -> None:
    model.load_state_dict(state)


def line_of(row: dict, direction: str) -> str:
    mark = row["mark"]
    return (f"щабель {row['rung']:>2} · {row['name']:<22} "
            f"спроба {row['attempt']} · втрата {row['loss']:.4f} · "
            f"міра {mark:.4f} · {'ЛИШАЮ' if row['kept'] else 'вертаю'}")


def resume_from(mod, model, out: Path, keep: Path) -> dict | None:
    """Підняти драбину, що вже йшла: ваги, точку відліку й пройдені щаблі.

    Драбина довга, а машина одна, тому прогін має стелю часу й може
    впертись у неї на середині. Продовження бере **ваги найкращої
    версії** з `models/<модель>/model.pt` і хід із її ж файлу, і йде
    далі з того щабля, на якому спинилось. Точка відліку — та сама
    одобрена версія: її рядок лежить у файлі першим.
    """
    import torch

    if not out.exists() or not (keep / "model.pt").exists():
        return None
    got = json.loads(out.read_text(encoding="utf-8"))
    if got.get("model") != mod.NAME or not got.get("rungs"):
        return None
    model.load_state_dict(torch.load(keep / "model.pt", map_location="cpu"))
    # у файлі міра, якої немає, лежить як `null`; у памʼяті це найгірше
    # можливе число, інакше з нею не порівняти
    worst = float("inf") if mod.METRIC_DIR == "min" else float("-inf")
    for row in got["rungs"] + [got["best"], got["base"]]:
        if row.get("mark") is None:
            row["mark"] = worst
    done = max(row["rung"] for row in got["rungs"])
    print(f"продовження: пройдено щаблів {done}, найкраще "
          f"{got['best']['mark']:.4f} (щабель {got['best']['rung']} · "
          f"{got['best']['name']})")
    return {"report": got, "done": done}


def ladder(mod, ctx, minutes: float, attempts: int, seed: int,
           margin: float, out: Path, keep: Path,
           resume: bool = False) -> dict:
    """Драбина: щабель за щаблем, з відкатом і перенавчанням."""
    import torch

    began = time.time()
    model, tune = mod.build(ctx, seed)
    start = mod.start_from(ctx, model, tune)
    keep.mkdir(parents=True, exist_ok=True)
    before = resume_from(mod, model, out, keep) if resume else None
    if before is None:
        base = mod.evaluate(ctx, model)
        best = {**base, "rung": 0, "name": "одобрена", "attempt": 0}
        torch.save(model.state_dict(), keep / "model.pt")
        rows = [{"rung": 0, "name": "одобрена", "attempt": 0, "loss": 0.0,
                 "mark": base["mark"], "kept": True, "minutes": 0.0,
                 "metrics": base["metrics"], "by_pair": base["by_pair"],
                 "config": start.get("config", {})}]
        skip = 0
        print(f"одобрена версія: міра {base['mark']:.4f}  "
              f"{mod.human(base)}")
    else:
        got = before["report"]
        base = got["base"]
        best = {**got["best"], "attempt": 0}
        rows = list(got["rungs"])
        skip = before["done"]
    state = state_of(model)
    # продовження рахує щаблі далі, а не з нуля: інакше зведення казало б
    # «1 з 9» там, де насправді пройдено 20 спроб двома прогонами
    taken = sum(1 for row in rows if row["rung"] and row["kept"])
    tried = sum(1 for row in rows if row["rung"])
    for number, rung in enumerate(mod.rungs(), start=1):
        if number <= skip:               # пройдено в попередньому прогоні
            continue
        if STOP["asked"] or (time.time() - began) / 60 >= minutes:
            print("час вийшов" if not STOP["asked"] else "зупинка")
            break
        for attempt in range(1, attempts + 1):
            tried += 1
            loss = mod.train_epoch(ctx, model, tune, rung,
                                   seed + 13 * number + attempt, attempt)
            got = mod.evaluate(ctx, model)
            kept = improved(got, best, mod.METRIC_DIR, margin)
            row = {"rung": number, "name": rung["name"], "attempt": attempt,
                   "loss": loss, "mark": got["mark"], "kept": kept,
                   "minutes": round((time.time() - began) / 60, 2),
                   "metrics": got["metrics"], "by_pair": got["by_pair"],
                   "config": rung.get("show", {})}
            rows.append(row)
            print(line_of(row, mod.METRIC_DIR) + "  " + mod.human(got))
            if kept:
                best = {**got, "rung": number, "name": rung["name"],
                        "attempt": attempt}
                state = state_of(model)
                torch.save(model.state_dict(), keep / "model.pt")
                torch.save(tune.state_dict(), keep / "tune.pt")
                taken += 1
                break
            # гірше: ваги назад, оптимізатор заново — моменти набрані
            # під іншим штрафом і тягнуть не туди
            restore(model, state)
            tune = mod.optimizer(ctx, model)
            if (time.time() - began) / 60 >= minutes or STOP["asked"]:
                break
        write(out, report(mod, ctx, rows, base, best, began, taken, tried,
                          seed, margin, keep))
    report_now = report(mod, ctx, rows, base, best, began, taken, tried,
                        seed, margin, keep)
    write(out, report_now)
    return report_now


def report(mod, ctx, rows: list, base: dict, best: dict, began: float,
           taken: int, tried: int, seed: int, margin: float,
           keep: Path) -> dict:
    gain = best["mark"] - base["mark"]
    return {
        "script": "research/32-loss-ladder/scripts/ladder.py",
        "ready": True,
        "model": mod.NAME, "title": mod.TITLE, "about": mod.ABOUT,
        "source": mod.SOURCE,
        "metric": mod.METRIC, "metric_dir": mod.METRIC_DIR,
        "metric_about": mod.METRIC_ABOUT,
        "extra": getattr(mod, "EXTRA", []),
        "pairs": mod.pairs_of(ctx),
        "data": mod.data_of(ctx),
        "seed": seed, "margin": margin,
        "weights": str(keep.relative_to(PROJECT_ROOT)),
        "base": {"mark": base["mark"], "metrics": base["metrics"],
                 "by_pair": base["by_pair"]},
        "best": {"mark": best["mark"], "rung": best["rung"],
                 "name": best["name"], "metrics": best["metrics"],
                 "by_pair": best["by_pair"]},
        "gain": gain,
        "better": (gain < 0) if mod.METRIC_DIR == "min" else (gain > 0),
        "rungs": rows,
        "taken": taken, "tried": tried,
        "minutes": round((time.time() - began) / 60, 2),
    }


def clean(value):
    """±∞ і NaN → `null`: інакше файл перестає бути JSON.

    Міра щабля, який не пройшов умову допуску адаптера, дорівнює −∞.
    `json.dumps` пише його як `-Infinity`, а це вже не JSON: браузер на
    такому файлі падає, і вкладка не відкривається взагалі. У файл іде
    `null`, а те, що саме сталось, стоїть поруч у метриках щабля.
    """
    if isinstance(value, float):
        return value if value == value and value not in (
            float("inf"), float("-inf")) else None
    if isinstance(value, dict):
        return {key: clean(one) for key, one in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(one) for one in value]
    return value


def write(out: Path, report: dict) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(clean(report), ensure_ascii=False, indent=2),
                   encoding="utf-8")
    return out


def show(report: dict) -> None:
    print()
    print(f"{report['title']} — {report['metric']} "
          f"({'менше краще' if report['metric_dir'] == 'min' else 'більше краще'})")
    print(f"  одобрена : {report['base']['mark']:.4f}")
    print(f"  драбина  : {report['best']['mark']:.4f} "
          f"(щабель {report['best']['rung']} · {report['best']['name']})")
    print(f"  зміна    : {report['gain']:+.4f} — "
          f"{'краще' if report['better'] else 'не краще'}")
    print(f"  взято щаблів {report['taken']} з {report['tried']} спроб, "
          f"{report['minutes']:.1f} хв")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--model", default=None,
                        help="яка одобрена мережа: " + ", ".join(ADAPTERS))
    parser.add_argument("--list", action="store_true",
                        help="перелік адаптерів і вихід")
    parser.add_argument("--minutes", type=float, default=120.0,
                        help="стеля часу на драбину")
    parser.add_argument("--attempts", type=int, default=2,
                        help="скільки разів перенавчати щабель, що не взявся")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--margin", type=float, default=None,
                        help="мертва зона міри; за замовчуванням з адаптера")
    parser.add_argument("--rungs", type=int, default=None,
                        help="обрізати драбину до N щаблів")
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--force", action="store_true",
                        help="не перевіряти вільну памʼять")
    parser.add_argument("--resume", action="store_true",
                        help="продовжити драбину, яка вперлась у стелю часу")
    args = parser.parse_args()
    if args.list or not args.model:
        for name, module in ADAPTERS.items():
            print(f"{name:<12} {module}")
        return
    listen()
    mod = adapter_of(args.model)
    if args.rungs:
        full = mod.rungs
        mod.rungs = lambda: full()[:args.rungs]
    ctx = mod.prepare(force=args.force)
    out = args.out or RESULTS / f"ladder_{mod.NAME}.json"
    keep = MODELS / mod.NAME
    margin = args.margin if args.margin is not None else mod.MARGIN
    got = ladder(mod, ctx, args.minutes, args.attempts, args.seed,
                 margin, out, keep, resume=args.resume)
    show(got)
    print(f"записано: {out}")


if __name__ == "__main__":
    main()
