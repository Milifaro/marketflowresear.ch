"""Перенавчання `legleft` під власною рамкою: мережа сама ставить півоти.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Замір `self_pivot.py` показав, що одобрені ваги під власною рамкою
розсипаються: мережа ріже ногу на 289 подій замість ~940 і ставить 32
межі там, де півотів 10. Це й очікувано — вона вчилась у рамці, де нуль
лічильника ставила розмітка. Тут вона вчиться **в тій рамці, в якій
працюватиме**.

## Правило рамки

    нога почалась  ->  перші START подій мережа відповідає
    N = round(mean(сказано на цих подіях))   ->  довжина ноги
    минуло N подій ->  сигнал «кінець ноги»: памʼять і лічильник з нуля

Розмітка в рамці не бере участі: `leg:up` гаситься, `leg:step`,
`leg:guess` і `leg:open` рахуються від **власного** початку ноги.

## Що лишається від розмітки

Тільки **ціль**: скільки подій до справжнього півота зігзага 2.3 % на
ема10. Інакше вчити нема на чому — правда про ногу є тільки в розмітці.
Замикається це просто: перші `START` відповідей тягнуться втратою до
справжнього залишку, а з них же береться межа. Вивчивши відповідь,
мережа тим самим ставить межу на місце півота.

## Цикл епохи

1. **Рішення** (без градієнта): поточні ваги проходять ряд нога за
   ногою і ставлять межі. Межі кожної епохи нові — рамка йде за вагами.
2. **Навчання**: та сама втрата `band`, що в одобреної версії, на цих
   ногах. Вікно мовчання — `OPEN` подій **своєї** ноги.
3. **Замір**: той самий прохід на val і коридор проти справжньої правди
   на тих подіях, де мережа **відповідає**, плюс покриття — яку частку
   ряду вона взагалі коментує. Надбавки за балакучість у мірі немає:
   вона міряє слухняність вікну, якого у власної рамки немає.

Рішення й замір ідуть із **вимкненим dropout**: на `mps` після
зворотного проходу `model.eval()` його не вимикає (див. `val_series.py`
→ «Чому замір іде на процесорі»), і рамка залежала б від того, яка
епоха зараз іде.

Памʼять ноги — `DEEP` попередніх **своїх** ніг, але не довше за `MEM`
подій: без стелі довга нога тягне за собою квадрат уваги.

Вхід : ваги `research/29-class7dd-legs/models/legleft_blocks4_gauss_clock_band/`
Вихід: results/self_train.json        — крива, міри, межі
       models/legleft_self/model.pt   — ваги найкращої епохи

Запуск:
    python3 research/32-loss-ladder/scripts/self_train.py --minutes 90
    python3 research/32-loss-ladder/scripts/self_train.py --epochs 3 --force
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
NAME = "legleft_self"
SEED = 0
START = 20                 # скільки подій початку йде в середнє
DEEP = 4                   # скільки попередніх своїх ніг у памʼяті
MEM = 2000                 # стеля памʼяті в подіях: квадрат уваги
CLOCK = 3000.0             # чим діляться лічильники
OPEN = 150                 # вікно відповіді всередині своєї ноги
SHORT = 20                 # коротше за це нога не буває
LONG = 2000                # і довше теж
HEAD = 4                   # стеля ніг у батчі на проході рішення
BUDGET = 30_000_000        # стеля уваги в батчі: `довжина² × ніг`
BATCH = 8                  # ніг у батчі на навчанні
LR = 3e-4                  # рамка інша — крок менший за одобрений 1e-3
EPOCHS = 12
PATIENCE = 3
SCRIPT = "research/32-loss-ladder/scripts/self_train.py"


# ------------------------------------------------------------------ рамка

def spans_of(rows: list, picked: list) -> list:
    """Суцільні відрізки подій: через діру в ряді рамка не йде."""
    out = []
    for one in picked:
        row = rows[one]
        if out and out[-1]["pair"] == row["pair"] \
                and out[-1]["end"] + 1 == row["first"]:
            out[-1]["end"] = int(row["last"])
        else:
            out.append({"pair": row["pair"], "begin": int(row["first"]),
                        "end": int(row["last"])})
    return out


def truth_of(rows: list, picked: list, total: int) -> tuple:
    """Залишок до **справжнього** півота і номер кроку справжньої ноги."""
    left = np.full(total, np.nan, dtype=np.float32)
    step = np.full(total, np.nan, dtype=np.float32)
    for one in picked:
        row = rows[one]
        left[row["first"]:row["last"] + 1] = np.arange(row["events"] - 1,
                                                       -1, -1)
        step[row["first"]:row["last"] + 1] = np.arange(row["events"])
    return left, step


def guess_table(x, index: np.ndarray, step: np.ndarray) -> tuple:
    """Відповідь лічильника на кожному кроці — з готового каналу даних."""
    seen = {}
    for place, walked in zip(index, step):
        seen.setdefault(int(walked), float(x[place, -2]))
    keys = np.array(sorted(seen), dtype=np.int64)
    return keys, np.array([seen[int(one)] for one in keys], dtype=np.float32)


def clock_of(walk: np.ndarray, table: tuple) -> np.ndarray:
    """Три канали лічильника на готовий масив кроків."""
    keys, values = table
    place = np.clip(np.searchsorted(keys, walk, side="right") - 1,
                    0, len(keys) - 1)
    return np.stack([np.log1p(walk) / np.log1p(CLOCK),
                     values[place],
                     (walk < OPEN).astype(np.float32)], axis=-1)


def walk_of(hist: int, last: int, starts: dict) -> np.ndarray:
    """Номер кроку на кожній події шматка за вже поставленими межами."""
    walk = np.zeros(last - hist + 1, dtype=np.int64)
    for first, count in starts.items():
        if first + count - 1 < hist or first > last:
            continue
        begin, stop = max(first, hist), min(first + count - 1, last)
        walk[begin - hist:stop - hist + 1] = np.arange(begin - first,
                                                       stop - first + 1)
    return walk


def framed(built: dict, low: int, high: int, walk: np.ndarray,
           table: tuple) -> np.ndarray:
    """Канали шматка ряду, де чотири канали розмітки замінені власними."""
    piece = np.array(built["x"][low:high], dtype=np.float32)
    piece[:, -4] = 0.0                       # напрямок мережі не дано
    piece[:, -3:] = clock_of(walk, table)
    return piece


def memory_from(previous: list, first: int, deep: int = DEEP,
                mem: int = MEM) -> int:
    """Початок памʼяті: `deep` попередніх своїх ніг, але не довше `mem`."""
    if not previous:
        return first
    back = previous[max(0, len(previous) - deep)]["first"]
    return int(max(back, first - mem))


# ------------------------------------------------------------------ прохід

def quiet(model):
    """Dropout геть: на `mps` `eval()` його не вимикає після навчання."""
    class Off:
        def __enter__(self):
            self.was = model.drop.p
            model.drop.p = 0.0
            model.eval()
            return model

        def __exit__(self, *_):
            model.drop.p = self.was
    return Off()


def said_on(model, built: dict, table: tuple, rows: list,
            device: str) -> list:
    """Видача на батчі власних ніг; у кожної свої канали рамки."""
    import torch

    length = max(one["last"] - one["hist"] + 1 for one in rows)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(rows), length, width), dtype=np.float32)
    mask = np.zeros((len(rows), length), dtype=bool)
    for number, row in enumerate(rows):
        steps = row["last"] - row["hist"] + 1
        x[number, :steps, :-1] = framed(built, row["hist"], row["last"] + 1,
                                        row["walk"], table)
        x[number, steps - row["events"]:steps, -1] = 1.0
        mask[number, :steps] = True
    lengths = torch.tensor([one["last"] - one["hist"] + 1 for one in rows])
    with torch.no_grad():
        out = model(torch.from_numpy(x).to(device),
                    torch.from_numpy(mask).to(device), lengths)
    said = []
    for number, row in enumerate(rows):
        steps = row["last"] - row["hist"] + 1
        said.append(np.expm1(out[number, steps - row["events"]:steps]
                             .float().cpu().numpy()))
    return said


def free_of(device: str) -> None:
    """Віддати кеш прискорювача: без цього довгі ноги його вичерпують."""
    import torch

    if device == "mps" and hasattr(torch, "mps"):
        torch.mps.empty_cache()
    elif device == "cuda":
        torch.cuda.empty_cache()


def packed(rows: list, size: int, budget: int = BUDGET) -> list:
    """Батчі під стелю уваги: вона росте як `довжина² × ніг у батчі`.

    Рахувати батч кількістю ніг тут не можна: власна нога буває і на 20
    подій, і на 2000, а з памʼяттю — учетверо довша. Тому в батч
    береться стільки ніг, скільки вкладається в стелю, і не більше
    `size`.
    """
    out, chunk, longest = [], [], 0
    for row in rows:
        steps = row["last"] - row["hist"] + 1
        far = max(longest, steps)
        if chunk and (len(chunk) >= size or far * far * (len(chunk) + 1)
                      > budget):
            out.append(chunk)
            chunk, longest = [], 0
            far = steps
        chunk.append(row)
        longest = far
    if chunk:
        out.append(chunk)
    return out


def in_chunks(model, built, table, rows: list, device: str,
              size: int) -> list:
    """Той самий прохід, батч за батчем; що не влізло — ділиться навпіл."""
    out = []
    for chunk in packed(rows, size):
        try:
            out.extend(said_on(model, built, table, chunk, device))
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            free_of(device)
            print(f"батч на {len(chunk)} ніг не вліз: ділю навпіл")
            out.extend(in_chunks(model, built, table, chunk, device,
                                 max(1, len(chunk) // 2)))
        free_of(device)
    return out


def decide(model, built: dict, spans: list, table: tuple, device: str,
           start: int = START, size: int = HEAD) -> dict:
    """Межі ніг, поставлені самою мережею.

    Відрізки йдуть у ногу: кожен веде свою ногу незалежно, і батч
    збирається з їхніх голів. Усередині відрізка ноги строго
    послідовні — наступна починається там, де попередня скінчилась.
    """
    starts, state = {}, [{"at": one["begin"], "end": one["end"],
                          "pair": one["pair"], "legs": []} for one in spans]
    while True:
        live = [one for one in state if one["at"] <= one["end"]]
        if not live:
            break
        rows = []
        for one in live:
            room = one["end"] - one["at"] + 1
            count = min(start, room)
            hist = memory_from(one["legs"], one["at"])
            last = one["at"] + count - 1
            rows.append({"hist": hist, "first": one["at"], "last": last,
                         "events": count, "state": one, "room": room,
                         "walk": walk_of(hist, last,
                                         {**starts, one["at"]: count})})
        for row, said in zip(rows, in_chunks(model, built, table, rows,
                                             device, size)):
            one, room = row["state"], row["room"]
            mean = float(np.mean(said))
            count = int(min(max(round(mean) if np.isfinite(mean) else room,
                                SHORT), LONG, room))
            one["legs"].append({"first": one["at"],
                                "last": one["at"] + count - 1,
                                "events": count, "head": round(mean, 1),
                                "pair": one["pair"]})
            starts[one["at"]] = count
            one["at"] += count
    legs = []
    for one in state:
        for place, leg in enumerate(one["legs"]):
            hist = memory_from(one["legs"][:place], leg["first"])
            legs.append({**leg, "hist": hist,
                         "steps": leg["last"] - hist + 1})
    return {"legs": legs, "starts": starts}


def tensors(built: dict, legs: list, chunk: list, left: np.ndarray,
            starts: dict, table: tuple, device: str):
    """Батч власних ніг: канали рамки, ціль — справжній залишок."""
    import torch

    length = max(legs[one]["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    own = np.zeros((len(chunk), length), dtype=bool)
    walk = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        leg = legs[one]
        steps, count = leg["steps"], leg["events"]
        x[number, :steps, :-1] = framed(
            built, leg["hist"], leg["last"] + 1,
            walk_of(leg["hist"], leg["last"], starts), table)
        x[number, steps - count:steps, -1] = 1.0
        target = left[leg["first"]:leg["last"] + 1]
        good = np.isfinite(target)
        y[number, steps - count:steps] = np.where(good, target, 0.0)
        own[number, steps - count:steps] = good
        mask[number, :steps] = True
        walk[number, steps - count:steps] = np.arange(count)
    lengths = torch.tensor([legs[one]["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device),
            torch.from_numpy(np.log1p(y)).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(own).to(device),
            torch.from_numpy(walk).to(device))


def own_step(starts: dict, total: int) -> np.ndarray:
    """Номер кроку **власної** ноги на кожній події ряду."""
    walk = np.full(total, np.nan, dtype=np.float32)
    for first, count in starts.items():
        walk[first:first + count] = np.arange(count)
    return walk


def hit_of(cuts: np.ndarray, pivots: np.ndarray) -> dict:
    """Чи стоять власні межі мережі там само, де справжні півоти.

    Дві відстані, бо вони різні: від півота до найближчої межі каже, чи
    всі розвороти знайдено, а від межі до найближчого півота — чи не
    наставлено зайвих.
    """
    if not len(cuts) or not len(pivots):
        return {}
    gap = np.abs(pivots[:, None] - cuts[None, :])
    to_cut = gap.min(axis=1)
    return {"pivot_to_cut": round(float(np.median(to_cut)), 1),
            "cut_to_pivot": round(float(np.median(gap.min(axis=0))), 1),
            "near_100": round(float((to_cut <= 100).mean()), 4)}


def corridor(said: np.ndarray, truth: np.ndarray, talk: np.ndarray,
             base, seen: np.ndarray) -> dict:
    """Коридор на тих подіях, де мережа **відповідає**.

    Вікно береться власне: у версії з розміткою це перші `WINDOW` подій
    після півота зігзага, у власній рамці — перші `OPEN` подій своєї
    ноги. Надбавки за балакучість тут немає: вона міряє слухняність
    вікну, якого у власної рамки немає, і в порівнянні двох рамок
    ховає саму відповідь. Замість неї — **покриття**: яку частку ряду
    мережа взагалі коментує.
    """
    good = np.isfinite(said) & np.isfinite(truth) & talk & seen
    if not good.any():
        return {"mark": float("inf"), "near": 0.0, "wide": 0.0,
                "cover": 0.0, "err": None, "window": 0}
    share = said[good] / np.maximum(truth[good], 1.0)
    near = float(((share >= base.BAND[0]) & (share <= base.BAND[1])).mean())
    wide = float(((share >= base.WIDE[0]) & (share <= base.WIDE[1])).mean())
    return {"mark": round(1.0 - (near + wide) / 2.0, 4),
            "near": round(near, 4), "wide": round(wide, 4),
            "cover": round(float(good.sum()) / float(seen.sum()), 4),
            "err": round(float(np.median(np.abs(said[good] - truth[good]))),
                         1),
            "window": int(good.sum())}


def measure(model, built: dict, spans: list, table: tuple, left: np.ndarray,
            step: np.ndarray, device: str, base, start: int = START) -> dict:
    """Коридор під власною рамкою, проти справжньої правди."""
    with quiet(model):
        got = decide(model, built, spans, table, device, start)
        said = np.full(len(left), np.nan)
        for leg, piece in zip(got["legs"],
                              in_chunks(model, built, table, [
                                  {**one, "walk": walk_of(one["hist"],
                                                          one["last"],
                                                          got["starts"])}
                                  for one in got["legs"]], device, HEAD)):
            said[leg["first"]:leg["last"] + 1] = piece
    walk = own_step(got["starts"], len(left))
    lengths = [leg["events"] for leg in got["legs"]]
    # покриття і півоти рахуються **всередині заміряних відрізків**:
    # поза ними ряд належить іншій частині розбиття
    seen = np.zeros(len(left), dtype=bool)
    for one in spans:
        seen[one["begin"]:one["end"] + 1] = True
    return {**corridor(said, left, walk < OPEN, base, seen),
            "legs": len(lengths),
            "median_leg": round(float(np.median(lengths)), 1),
            **hit_of(np.array(sorted(got["starts"])),
                     np.flatnonzero((step == 0) & seen)),
            "said": said, "starts": got["starts"]}


def epoch_of(model, tune, built: dict, legs: list, starts: dict,
             left: np.ndarray, table: tuple, device: str, ad,
             seed: int, shape: str = "band") -> float:
    """Одна епоха на власних ногах під заданою формою втрати."""
    import torch

    model.train()
    order = sorted(range(len(legs)), key=lambda one: legs[one]["steps"])
    chunks = [[one["at"] for one in chunk] for chunk in
              packed([{"at": one, "hist": 0, "last": legs[one]["steps"] - 1}
                      for one in order], BATCH)]
    np.random.default_rng(seed).shuffle(chunks)
    total, seen = 0.0, 0

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, walk = tensors(built, legs, chunk, left,
                                                 starts, table, device)
        if scale is None:
            scale = own.sum()
        out = model(x, mask, lengths)
        each = loss_step(shape, out, y, walk, ad)
        piece = (each * own).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum()), scale

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            free_of(device)
            print(f"батч на {len(chunk)} ніг не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2]

    for chunk in chunks:
        tune.zero_grad()
        got, count, _ = learn(chunk)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        total += got * count
        seen += count
    return total / max(seen, 1)


# ------------------------------------------------------------------ втрати

# Рамка інша, тому й втрата не зобовʼязана бути тією, якою вчили
# одобрену версію. Вісім форм, і кожна питає своє:
#
#   band     та сама, що в одобреної: коридор у частках цілі й мовчання
#            після вікна. Точка відліку
#   down     той самий коридор, але заниження вчетверо дорожче. Головна
#            хвороба рамки — нога 285 подій замість 939, тобто заниження
#   tight    вужчий коридор 0.95–1.05 і дорожчі обидва краї
#   head     той самий коридор, але **перші START подій важать ×4**: саме
#            вони ставлять межу, решта вікна на неї не впливає
#   loose    коридор без плати за балакучість: вікно мовчання рамка
#            обирає сама, і штраф за розмову після нього питає не те
#   ratio    без коридору взагалі: модуль логарифма частки `сказано /
#            правда`. Рівно те, чим міряють, без мертвої зони
#   mae      L1 на `log1p` — медіана залишку, без вікна і без часток
#   events   Хубер на самому числі подій у сотнях: шкала відповіді
LOSS_SHAPES = ("band", "down", "tight", "head", "loose", "ratio", "mae",
               "events")


def band_knobs(ad, **change) -> dict:
    return {**ad.BAND, **change}


def loss_step(name: str, out, true, walk, ad):
    """Втрата на крок під іменем форми; `walk` — крок **власної** ноги."""
    import torch

    if name in ("band", "down", "tight", "head", "loose"):
        knobs = {"band": band_knobs(ad),
                 "down": band_knobs(ad, down=400.0, up=20.0),
                 "tight": band_knobs(ad, band=(0.95, 1.05), down=240.0,
                                     up=60.0),
                 "head": band_knobs(ad, wake=((0, 4.0), (START, 1.0))),
                 "loose": band_knobs(ad, quiet=0.0)}[name]
        return ad.band_step(out, true, walk, knobs)
    said = torch.expm1(out)
    real = torch.expm1(true).clamp(min=1.0)
    if name == "ratio":
        return (torch.log((said.clamp(min=1.0)) / real)).abs()
    if name == "mae":
        return (out - true).abs()
    if name == "events":
        return torch.nn.functional.huber_loss(
            said / 100.0, real / 100.0, reduction="none")
    raise SystemExit(f"невідома форма втрати: {name}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--loss", nargs="+", default=list(LOSS_SHAPES))
    parser.add_argument("--epochs", type=int, default=2,
                        help="епох на кожну форму втрати")
    parser.add_argument("--extra", type=int, default=4,
                        help="ще стільки епох переможцю")
    parser.add_argument("--minutes", type=float, default=200.0)
    parser.add_argument("--start", type=int, default=START)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import val_series as series

    ctx = ad.prepare(force=args.force)
    device = ctx["device"]
    rows, built = ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    left, step = truth_of(rows, train + val, total)
    index = np.concatenate([np.arange(rows[one]["first"],
                                      rows[one]["last"] + 1)
                            for one in train])
    walked = np.concatenate([np.arange(rows[one]["events"])
                             for one in train])
    table = guess_table(built["x"], index, walked)
    train_spans, val_spans = spans_of(rows, train), spans_of(rows, val)
    print(f"відрізків: train {len(train_spans)}, val {len(val_spans)} · "
          f"пристрій {device} · старт {args.start} · форм втрати "
          f"{len(args.loss)}")

    model, _ = ad.build(ctx, SEED)
    approved = ad.APPROVED / "model.pt"
    series.lift(model, approved)
    began = time.time()
    first = measure(model, built, val_spans, table, left, step, device,
                    ad.base, args.start)
    print(f"одобрені ваги під власною рамкою: міра {first['mark']} · "
          f"коридор {first['near']:.3f}/{first['wide']:.3f} · покриття "
          f"{first['cover']:.3f} · {first['legs']} ніг, медіана "
          f"{first['median_leg']} подій · півот → межа "
          f"{first.get('pivot_to_cut')}")
    clean = {key: value for key, value in first.items()
             if key not in ("said", "starts")}

    def climb(shape: str, keep: Path, epochs: int, tune=None,
              curve=None, best=None) -> tuple:
        """Кілька епох однією формою втрати; ваги кращої лягають у `keep`."""
        keep.mkdir(parents=True, exist_ok=True)
        tune = tune or torch.optim.AdamW(model.parameters(), lr=args.lr)
        curve, stale = list(curve or []), 0
        for number in range(len(curve) + 1, len(curve) + epochs + 1):
            with quiet(model):
                got = decide(model, built, train_spans, table, device,
                             args.start)
            free_of(device)
            loss = epoch_of(model, tune, built, got["legs"], got["starts"],
                            left, table, device, ad, SEED + number, shape)
            free_of(device)
            now = measure(model, built, val_spans, table, left, step, device,
                          ad.base, args.start)
            spent = (time.time() - began) / 60.0
            curve.append({"epoch": number, "loss": round(loss, 4),
                          "train_legs": len(got["legs"]),
                          **{key: value for key, value in now.items()
                             if key not in ("said", "starts")},
                          "minutes": round(spent, 1)})
            print(f"  {shape:>6} епоха {number:>2} · втрата {loss:.4f} · "
                  f"міра {now['mark']} · коридор {now['near']:.3f}/"
                  f"{now['wide']:.3f} · покриття {now['cover']:.3f} · "
                  f"{now['legs']} ніг, медіана {now['median_leg']} · "
                  f"півот → межа {now.get('pivot_to_cut')} · {spent:.1f} хв")
            if best is None or now["mark"] < best["mark"]:
                best = {"epoch": number,
                        **{key: value for key, value in now.items()
                           if key not in ("said", "starts")}}
                stale = 0
                torch.save(model.state_dict(), keep / "model.pt")
                torch.save(tune.state_dict(), keep / "tune.pt")
            else:
                stale += 1
            if stale >= PATIENCE or spent > args.minutes:
                break
        return curve, best, tune

    runs = {}
    for shape in args.loss:
        if (time.time() - began) / 60.0 > args.minutes:
            print(f"стеля часу: {shape} і далі не пройдено")
            break
        series.lift(model, approved)        # кожна форма стартує з однакового
        curve, best, _ = climb(shape, MODELS / f"{NAME}_{shape}",
                               args.epochs)
        runs[shape] = {"curve": curve, "best": best,
                       "weights": f"{NAME}_{shape}"}
        save(clean, runs, None, args, ad, device, began)

    ranked = sorted(runs, key=lambda one: runs[one]["best"]["mark"])
    won = ranked[0] if ranked else None
    if won and args.extra and (time.time() - began) / 60.0 < args.minutes:
        print(f"переможець гріду: {won} · міра "
              f"{runs[won]['best']['mark']} — доганяю ще {args.extra} епох")
        series.lift(model, MODELS / f"{NAME}_{won}" / "model.pt")
        curve, best, _ = climb(won, MODELS / f"{NAME}_{won}", args.extra,
                               curve=runs[won]["curve"],
                               best=runs[won]["best"])
        runs[won] = {"curve": curve, "best": best,
                     "weights": f"{NAME}_{won}"}
    if won:
        keep = MODELS / NAME
        keep.mkdir(parents=True, exist_ok=True)
        for name in ("model.pt", "tune.pt"):
            path = MODELS / f"{NAME}_{won}" / name
            if path.exists():
                (keep / name).write_bytes(path.read_bytes())
        print(f"ваги переможця скопійовано в {keep}")
    save(clean, runs, won, args, ad, device, began)


def save(first: dict, runs: dict, won: str | None, args, ad, device: str,
         began: float) -> None:
    """Звіт пишеться після кожної форми: прогін довгий, і його рвуть."""
    report = {"script": SCRIPT, "ready": True, "model": NAME,
              "start": args.start, "lr": args.lr, "deep": DEEP,
              "memory": MEM, "window": OPEN, "device": device,
              "approved": str((ad.APPROVED / "model.pt")
                              .relative_to(PROJECT_ROOT)),
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "shapes": list(runs), "won": won, "before": first,
              "runs": runs,
              "curve": runs[won]["curve"] if won else
              (list(runs.values())[0]["curve"] if runs else []),
              "best": runs[won]["best"] if won else None,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    path = RESULTS / "self_train.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
