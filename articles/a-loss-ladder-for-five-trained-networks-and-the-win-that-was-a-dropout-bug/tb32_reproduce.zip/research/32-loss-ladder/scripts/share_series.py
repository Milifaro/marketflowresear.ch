"""Частка ноги на ряді val BTC: що мережа намалювала під ціною.

Дослідження: research/32-loss-ladder/
Правила: rules/05-visualization.md → компоновка

Під ціною три лінії на спільній нерухомій шкалі 0…1:

    насправді   частка справжньої ноги зігзага 2.3 % на ема10 — пилка
    лічильник   крок / (крок + медіана залишку train) — межа знизу
    мережа      `legshare`: клас без жодного каналу розмітки

Ряд для мережі ріжеться **тими самими вікнами**, що й на навчанні:
`WIN` подій, перші `WARM` з них — розігрів памʼяті, і вони не
показуються. Розмітка в канали не заходить: мережа має сама побачити,
що нога скінчилась.

Замір іде на процесорі з тієї самої причини, що й `val_series.py`:
на `mps` після зворотного проходу `eval()` не вимикає dropout.

Вхід : models/legshare/model.pt
Вихід: results/share_series_BTC_USDT.json — ряд для вкладки і міри

Запуск:
    python3 research/32-loss-ladder/scripts/share_series.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
PAIR = "BTC_USDT"
SEED = 17
DEVICE = "cpu"
HALF = 105
OUT = f"share_series_{PAIR}.json"
SCRIPT = "research/32-loss-ladder/scripts/share_series.py"


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    picked = [one for one in val if rows[one]["pair"] == PAIR]
    first, last = share.edges_of(rows, train + val, total)
    truth = share.truth_of(first, last)

    trained = RESULTS / "share_train.json"
    got = json.loads(trained.read_text(encoding="utf-8")) \
        if trained.exists() else {}
    win, warm = got.get("win", share.WIN), got.get("warm", share.WARM)
    boxes = share.windows(share.spans_of(rows, picked), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in boxes:
        seen[one["first"]:one["last"] + 1] = True
    index = np.flatnonzero(seen)
    print(f"вікон {len(boxes)} по {win} подій (розігрів {warm})")

    bounds = [(rows[one]["first"], rows[one]["last"]) for one in picked]
    counter = share.counter_line(built["x"], rows, picked, total)
    report = {"counter": {**share.marks(counter, truth, seen, bounds),
                          "legs": len(picked)}}
    lines = {"counter": counter}
    path = MODELS / "legshare" / "model.pt"
    if path.exists():
        # мережа з двома виходами: «обнулись» і «підрости»
        model = share.build_of(ctx, ad, SEED)
        series.lift(model, path)
        now = share.measure(model, built, rows, picked, boxes, truth, seen,
                            DEVICE)
        lines["said"] = now["said"]
        lines["fired"] = now["fired"]      # де мережа тисне «обнулись»
        report["said"] = {key: value for key, value in now.items()
                          if key not in ("said", "fired")}
        report["said"]["weights"] = str(path.relative_to(PROJECT_ROOT))
        one = report["said"]
        print(f"  мережа: міра {one['mark']} · коридор "
              f"{one['near']:.3f}/{one['wide']:.3f} · голова {one['head']} · "
              f"хвіст {one['tail']} · обвал {one['cliff']} · ріст "
              f"{one['rise']}")
    else:
        print(f"немає ваг {path} — лишається сама правда й лічильник")
    write(lines, truth, report, index, built, args, win, warm)


def write(lines: dict, truth, report: dict, index, built, args,
          win: int, warm: int) -> dict:
    """Кістяк ряду з `val_series` і лінії частки під ціною."""
    import val_series as series

    bones = series.skeleton()
    axis = np.asarray(bones["t"], dtype=np.int64)
    stamps = np.asarray(built["t"][index], dtype=np.int64)
    where = series.nearest(axis, stamps, HALF)
    good = where >= 0
    keep = np.sort(where[good])
    span = slice(int(keep[0]), int(keep[-1]) + 1)

    def lay(values) -> list:
        column = np.full(len(axis), np.nan)
        column[where[good]] = np.asarray(values, dtype=float)[index][good]
        return rounded(column[span], 4)

    block = {"script": SCRIPT, "ready": True, "pair": PAIR,
             "model": "legshare", "device": DEVICE, "event_seconds": 210,
             "win": win, "warm": warm, "kinds": sorted(lines),
             "class": bones["class"], "threshold": bones["threshold"],
             "period": bones["period"], "events": int(len(axis[span])),
             "from": int(axis[span][0]), "to": int(axis[span][-1]),
             "lost": int((~good).sum()),
             "t": [int(one) for one in axis[span]],
             "price": [round(float(one), 2) for one in bones["price"][span]],
             "ema": [round(float(one), 2) for one in bones["ema"][span]],
             "pivots": [one for one in bones["pivots"]
                        if axis[span][0] <= one["t"] <= axis[span][-1]],
             "marks": report}
    block["truth"] = lay(truth)
    shown = [{"key": "truth", "title": "насправді", "kind": "truth"},
             {"key": "counter", "title": "лічильник", "kind": "counter"}]
    block["counter"] = lay(lines["counter"])
    if "said" in lines:
        block["said"] = lay(lines["said"])
        shown.append({"key": "said", "title": "мережа", "kind": "said"})
        block["fired"] = lay(lines["fired"])
        shown.append({"key": "fired", "title": "сигнал «обнулись»",
                      "kind": "fired"})
    block["lines"] = shown
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} — {block['events']} подій")
    return block


if __name__ == "__main__":
    main()
