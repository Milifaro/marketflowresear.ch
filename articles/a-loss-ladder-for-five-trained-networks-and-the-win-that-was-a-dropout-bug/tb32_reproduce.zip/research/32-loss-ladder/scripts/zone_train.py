"""Кінець ноги драбиною штрафу: чим далі промах, тим дорожче втричі.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Мережа та сама, що в `share_train.py`, і починає вона **з її ваг**:
два числа на подію — «обнулись» і «підрости», — з яких накопиченням
будується частка пройденої ноги. Міняється тільки те, чим штрафують
сигнал обнулення.

## Драбина втричі

Промах міряється **в подіях** від справжнього розвороту, а не в
частках ноги. Довкола півота стоїть безштрафова зона, заміряна
`pivot_zone.py`: там подія й сама не відрізняється від сусідніх, і
карати обнулення нема за що.

    зона     `TAIL` подій до розвороту, `HEAD` після — штрафу немає
    крок     кожні `pace` подій поза зоною штраф множиться на `times`
    пізно    нога скінчилась, сигналу немає — поки мовчить, ціна росте
    рано     обнулення до зони — ціна росте так само

`3⁰` на перших пʼяти подіях поза зоною — це «стандартний» штраф, далі
`3¹`, `3²`, `3³`. Стеля потрібна обом бокам: без неї подія з середини
ноги коштувала б `3⁶⁰`.

Штраф за «пізно» помножений на **мовчання**: `still(t)` — добуток
`(1 − r)` від самого розвороту. Щойно мережа натиснула, доданок гасне
сам, і градієнт тягне натиснути **раніше**, а не сильніше.

## Рішучий спуск

Перший прогін цієї драбини показав, чому самої драбини мало: лінія
сіла в рівну мушу (розмах 0.04, спуски на 20 % подій) і не росла
взагалі. Причина в конструкції: `s ← (1 − fade·r)·(s + g)` — кволий
сигнал `r ≈ 0.1` точить лінію на 2.5 % щокроку, і рости їй нема коли.
Тому в множник іде не сам сигнал, а сигнал за **мертвою зоною**
`DEAD`: слабший за неї лінію не чіпає взагалі, сильний роняє так само,
як раніше, і трохи швидше (`FADE` 0.35 замість 0.25).

Тоді ж вирівняні обидва боки драбини (`early` = `late`) і збита її
вага: у першому прогоні «пізно» коштувало вчетверо дорожче за «рано»,
а сама драбина — на два порядки дорожче за форму, і мережі було
вигідно бити на сполох по вісім разів за ногу. Множники між собою
лишились ті самі, ×3 на кожні пʼять подій; змінився тільки масштаб,
щоб форма й час розвороту важили одне проти одного, а не тонули.

## Що лишилось як було

Штраф за спуск усередині ноги (`fall`, ×120) і за видачу, яка не
впала на новій нозі (`cliff`, ×60), лишаються нерухомі: форма пилки
вже стоїть, її тільки треба втримати. Коридор безштрафової зони тут
вужчий за етап 7 (`FREE`, 10 % → 2 %): мережа приходить уже в формі.

## Чим міряється

Нерухома міра `share_train.marks` — коридор довкола правди плюс числа
форми. До вибору епохи додається **влучність у зону**: частка
розворотів, біля яких обнулення лягло в межі заміряної зони.

Вхід : models/legshare/model.pt   — мережа етапу 7
       results/pivot_zone.json    — межі безштрафової зони
Вихід: results/zone_train.json    — крива, міри, форма, влучність
       models/legzone/model.pt    — ваги найкращої епохи

Запуск:
    python3 research/32-loss-ladder/scripts/zone_train.py --epochs 40
    python3 research/32-loss-ladder/scripts/zone_train.py --epochs 10 --resume
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
NAME = "legzone"
FROM = "legshare"          # чиї ваги беруться за початок
SEED = 0
EPOCHS = 40
PATIENCE = 12
LR = 1e-4                  # менший за `legshare`: мережа вже в формі
TAIL = 50                  # безштрафова зона до розвороту, подій
HEAD = 15                  # і після нього
FAR = 150                  # доки після розвороту росте штраф за мовчання
NEAR = 200                 # у яких межах шукається обнулення на замір
DEAD = 0.20                # поріг рішучості: слабший сигнал лінію не чіпає
FADE = 0.35                # рішучий сигнал роняє лінію за десяток подій
FREE = (0.10, 0.07, 0.05, 0.03, 0.02)   # коридор: мережа вже в формі
KNOBS = {"down": 6.0, "up": 2.0, "grow": 5.0, "fall": 120.0, "cliff": 60.0,
         "tail": 4.0, "edge": 0.1, "early": 0.5, "late": 0.5, "times": 3.0,
         "pace": 5.0, "roof": 81.0, "far": FAR, "zone": (TAIL, HEAD),
         "dead": DEAD, "fade": FADE}
SCRIPT = "research/32-loss-ladder/scripts/zone_train.py"
OUT = "zone_train.json"


def zone_of(path: Path = RESULTS / "pivot_zone.json") -> tuple:
    """Межі безштрафової зони — з заміру, а не з голови."""
    if not path.exists():
        return TAIL, HEAD
    got = json.loads(path.read_text(encoding="utf-8")).get("free", {})
    return int(got.get("tail", TAIL)), int(got.get("head", HEAD))


# ------------------------------------------------------------------ втрата

def ladder_of(gap, knobs: dict):
    """Множник промаху: `times` на кожні `pace` подій, зі стелею `roof`."""
    import torch

    steps = torch.floor(gap.clamp(min=0.0) / knobs["pace"])
    return torch.pow(torch.full_like(steps, knobs["times"]), steps) \
        .clamp(max=knobs["roof"])


def still_of(reset, start):
    """Мовчання: добуток `(1 − r)` від розвороту до цієї події.

    Одиниця, поки мережа не натиснула жодного разу після півота, і
    швидко в нуль, щойно натиснула. Саме він робить штраф за «пізно»
    штрафом за **мовчання**, а не за слабкий сигнал.
    """
    import torch

    out, now = [], torch.ones_like(reset[:, 0])
    for place in range(reset.shape[1]):
        now = torch.where(start[:, place] > 0, torch.ones_like(now), now)
        out.append(now)
        now = now * (1.0 - reset[:, place])
    return torch.stack(out, dim=1)


def pulled(reset, dead: float):
    """Дієвий сигнал: слабший за мертву зону не рахується взагалі.

    Штраф говорить тим самим числом, що й лінія. Інакше лишається
    лазівка: тримати `r` трохи нижче мертвої зони — лінію це не роняє,
    а штраф за мовчання гасить.
    """
    if dead <= 0.0:
        return reset
    return ((reset - dead) / (1.0 - dead)).clamp(0.0, 1.0)


def pivot_step(reset, ahead, back, start, knobs: dict, zone: tuple):
    """Штраф на сам сигнал обнулення: рано — дорожче, пізно — найдорожче."""
    import torch

    tail, head = zone
    pull = pulled(reset, knobs.get("dead", 0.0))
    early = (ahead - tail).clamp(min=0.0)
    hurt = knobs["early"] * ladder_of(early, knobs) \
        * (ahead > tail).to(pull.dtype) * pull
    late = (back - head).clamp(min=0.0)
    alive = ((back > head) & (back <= head + knobs["far"])).to(pull.dtype)
    hurt = hurt + knobs["late"] * ladder_of(late, knobs) * alive \
        * still_of(pull, start) * (1.0 - pull)
    return hurt


# -------------------------------------------------------------------- дані

def steps_of(rows: list, picked: list, total: int) -> tuple:
    """Скільки подій до кінця своєї ноги і скільки минуло від початку."""
    ahead = np.full(total, -1.0, dtype=np.float32)
    back = np.full(total, -1.0, dtype=np.float32)
    for one in picked:
        row = rows[one]
        walk = np.arange(row["first"], row["last"] + 1)
        ahead[walk] = row["last"] - walk
        back[walk] = walk - row["first"]
    return ahead, back


def tensors_of(built: dict, chunk: list, truth: np.ndarray,
               ahead: np.ndarray, back: np.ndarray, device: str):
    """Батч вікон: клас без розмітки, ціль і відстані до країв ноги."""
    import torch
    import share_train as share

    length = max(one["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    own = np.zeros((len(chunk), length), dtype=np.float32)
    far = np.zeros((len(chunk), length), dtype=np.float32)
    past = np.zeros((len(chunk), length), dtype=np.float32)
    born = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        steps = one["steps"]
        piece = slice(one["hist"], one["last"] + 1)
        x[number, :steps, :-1] = share.frame_of(built, one)
        x[number, :steps, -1] = 1.0      # «своя нога» скрізь: межі немає
        told = truth[piece]
        good = np.isfinite(told)
        y[number, :steps] = np.where(good, told, 0.0)
        mask[number, :steps] = True
        own[number, steps - one["events"]:steps] = \
            good[steps - one["events"]:].astype(np.float32)
        far[number, :steps] = np.where(ahead[piece] >= 0, ahead[piece], 0.0)
        past[number, :steps] = np.where(back[piece] >= 0, back[piece], 0.0)
        born[number, :steps] = (back[piece] == 0).astype(np.float32)
    lengths = torch.tensor([one["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device), torch.from_numpy(y).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(own).to(device),
            torch.from_numpy(far).to(device),
            torch.from_numpy(past).to(device),
            torch.from_numpy(born).to(device))


# -------------------------------------------------------------------- міра

def timing_of(fired: np.ndarray, rows: list, picked: list, seen: np.ndarray,
              zone: tuple, level: float = 0.5, near: int = NEAR) -> dict:
    """Де лягло обнулення відносно справжнього розвороту, в подіях."""
    tail, head = zone
    hit = np.flatnonzero(seen & np.isfinite(fired) & (fired > level))
    pivots = [rows[one]["last"] for one in picked
              if seen[rows[one]["last"]]]
    if not pivots:
        return {"inzone": 0.0, "delay": None, "missed": 1.0, "pivots": 0}
    if not len(hit):
        return {"inzone": 0.0, "delay": None, "missed": 1.0,
                "pivots": len(pivots)}
    gaps = []
    for one in pivots:
        away = hit - one
        place = int(np.argmin(np.abs(away)))
        gaps.append(int(away[place]) if abs(away[place]) <= near else None)
    found = [one for one in gaps if one is not None]
    inside = [one for one in found if -tail <= one <= head]
    return {"inzone": round(len(inside) / len(gaps), 4),
            "delay": round(float(np.median(found)), 1) if found else None,
            "spread": round(float(np.median(np.abs(found))), 1)
            if found else None,
            "missed": round(1.0 - len(found) / len(gaps), 4),
            "pivots": len(gaps)}


def score_of(one: dict) -> float:
    """Вибір епохи: точність, форма і влучність у зону разом.

    До оцінки етапу 7 (`mark` плюс розмах і обвал) додається те, заради
    чого ця драбина й будувалась, — частка розворотів, біля яких
    обнулення лягло в заміряну зону. Усі доданки «менше краще».
    """
    import share_train as share

    got = one.get("inzone")
    return round(share.score_of(one) + (1.0 - float(got or 0.0)), 4)


def measure(model, built: dict, rows: list, picked: list, boxes: list,
            true: np.ndarray, seen: np.ndarray, device: str,
            zone: tuple) -> dict:
    """Видача на всіх вікнах val плюс влучність обнулення в зону."""
    import share_train as share

    got = share.measure(model, built, rows, picked, boxes, true, seen,
                        device, DEAD)
    return {**got, **timing_of(got["fired"], rows, picked, seen, zone)}


# ---------------------------------------------------------------- навчання

def epoch_of(model, tune, built: dict, boxes: list, true: np.ndarray,
             ahead: np.ndarray, back: np.ndarray, device: str, seed: int,
             free: float, knobs: dict, zone: tuple) -> float:
    """Одна епоха: форма зі етапу 7 плюс драбина промаху на обнуленні."""
    import torch
    import share_train as share

    model.train()
    chunks = share.packed(boxes)
    order = list(range(len(chunks)))
    np.random.default_rng(seed).shuffle(order)
    total, seen = 0.0, 0

    def feed(chunk: list, scale=None):
        x, y, mask, lengths, own, far, past, born = tensors_of(
            built, chunk, true, ahead, back, device)
        if scale is None:
            scale = own.sum()
        said, reset = share.saw_of(model(x, mask, lengths), knobs["step"],
                                   knobs["fade"], knobs["dead"])
        chain = own.clone()
        chain[:, :1] = 0.0
        chain[:, 1:] = chain[:, 1:] * own[:, :-1]
        step = pivot_step(reset, far, past, born, knobs, zone) \
            + share.share_step(said, y, chain, knobs, free)
        piece = (step * own).sum() / scale
        piece.backward()
        return float(piece.detach()), int(own.sum().item()), scale

    def learn(chunk: list, scale=None):
        try:
            return feed(chunk, scale)
        except RuntimeError as error:
            if len(chunk) == 1 or "out of memory" not in str(error).lower():
                raise
            share.free_of(device)
            print(f"батч на {len(chunk)} вікон не вліз: ділю навпіл")
            half = len(chunk) // 2
            one = learn(chunk[:half], scale)
            two = learn(chunk[half:], scale or one[2])
            return one[0] + two[0], one[1] + two[1], one[2]

    for number in order:
        tune.zero_grad()
        got, count, _ = learn(chunks[number])
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        tune.step()
        share.free_of(device)
        total += got * count
        seen += count
    return total / max(seen, 1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--minutes", type=float, default=400.0)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--win", type=int, default=None)
    parser.add_argument("--warm", type=int, default=None)
    parser.add_argument("--resume", action="store_true",
                        help="доучити те, що вже лежить у models/legzone")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch
    import ad_legleft as ad
    import share_train as share
    import val_series as series

    ctx = ad.prepare(force=args.force)
    device, rows, built = ctx["device"], ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    was = json.loads((RESULTS / "share_train.json").read_text(
        encoding="utf-8")) if (RESULTS / "share_train.json").exists() else {}
    win = args.win or int(was.get("win", share.WIN))
    warm = args.warm or int(was.get("warm", share.WARM))
    zone = zone_of()
    knobs = {**KNOBS, "step": share.STEP, "zone": list(zone)}

    first, last = share.edges_of(rows, train + val, total)
    true = share.truth_of(first, last)
    ahead, back = steps_of(rows, train + val, total)
    train_boxes = share.windows(share.spans_of(rows, train), win, warm)
    val_boxes = share.windows(share.spans_of(rows, val), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in val_boxes:
        seen[one["first"]:one["last"] + 1] = True
    print(f"вікон: train {len(train_boxes)}, val {len(val_boxes)} по {win} "
          f"подій (розігрів {warm}) · зона {zone[0]}/{zone[1]} подій · "
          f"пристрій {device}")

    counter = share.marks(
        share.counter_line(built["x"], rows, val, total), true, seen,
        [(rows[one]["first"], rows[one]["last"]) for one in val])
    print(f"лічильник розмітки: міра {counter['mark']} · голова "
          f"{counter['head']} · хвіст {counter['tail']} · обвал "
          f"{counter['cliff']}")

    model = share.build_of(ctx, ad, share.SEED)
    keep = MODELS / NAME
    keep.mkdir(parents=True, exist_ok=True)
    tune = torch.optim.AdamW(model.parameters(), lr=args.lr)
    curve, best, stale = [], None, 0
    path = RESULTS / OUT
    started = MODELS / FROM / "model.pt"
    if args.resume and path.exists() and (keep / "model.pt").exists():
        older = json.loads(path.read_text(encoding="utf-8"))
        series.lift(model, keep / "model.pt")
        if (keep / "tune.pt").exists():
            tune.load_state_dict(torch.load(keep / "tune.pt",
                                            map_location="cpu"))
        curve, best = list(older.get("curve", [])), older.get("best")
        print(f"продовжую з епохи {len(curve) + 1}")
    elif started.exists():
        series.lift(model, started)
        print(f"починаю з ваг {started.relative_to(PROJECT_ROOT)}")
    else:
        raise SystemExit(f"немає ваг етапу 7: {started}")

    began = time.time()
    for number in range(len(curve) + 1, len(curve) + args.epochs + 1):
        free = share.free_at(number, len(curve) + args.epochs, FREE)
        loss = epoch_of(model, tune, built, train_boxes, true, ahead, back,
                        device, SEED + number, free, knobs, zone)
        share.free_of(device)
        now = measure(model, built, rows, val, val_boxes, true, seen, device,
                      zone)
        share.free_of(device)
        spent = (time.time() - began) / 60.0
        step = {"epoch": number, "loss": round(loss, 4), "free": free,
                **{key: value for key, value in now.items()
                   if key not in ("said", "fired")}}
        step["score"] = score_of(step)
        curve.append({**step, "minutes": round(spent, 1)})
        print(f"  епоха {number:>2} · зона {free:.2f} · втрата {loss:.4f} · "
              f"міра {now['mark']} · голова {now['head']} · хвіст "
              f"{now['tail']} · обвал {now['cliff']} · обнулень "
              f"{now['often']}/1000 · у зоні {now['inzone']} · затримка "
              f"{now['delay']} · без сигналу {now['missed']} · оцінка "
              f"{step['score']} · {spent:.1f} хв")
        if best is None or step["score"] < best["score"]:
            best = {key: value for key, value in step.items()}
            stale = 0
            torch.save(model.state_dict(), keep / "model.pt")
            torch.save(tune.state_dict(), keep / "tune.pt")
        else:
            stale += 1
        save(curve, best, counter, args, ad, device, began, win, warm, zone,
             knobs)
        if stale >= PATIENCE or spent > args.minutes:
            break
    save(curve, best, counter, args, ad, device, began, win, warm, zone,
         knobs)


def save(curve: list, best, counter: dict, args, ad, device: str,
         began: float, win: int, warm: int, zone: tuple,
         knobs: dict) -> None:
    """Звіт пишеться після кожної епохи: прогін нічний, і його рвуть."""
    import share_train as share

    report = {"script": SCRIPT, "ready": True, "model": NAME, "from": FROM,
              "lr": args.lr, "win": win, "warm": warm, "near": share.NEAR,
              "wide": share.WIDE, "edge": share.EDGE,
              "free": list(FREE), "knobs": knobs, "device": device,
              "zone": {"tail": zone[0], "head": zone[1], "far": FAR},
              "weights": str((MODELS / NAME).relative_to(PROJECT_ROOT)),
              "counter": counter, "curve": curve, "best": best,
              "minutes": round((time.time() - began) / 60.0, 1)}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / OUT).write_text(json.dumps(report, ensure_ascii=False),
                               encoding="utf-8")


if __name__ == "__main__":
    main()
