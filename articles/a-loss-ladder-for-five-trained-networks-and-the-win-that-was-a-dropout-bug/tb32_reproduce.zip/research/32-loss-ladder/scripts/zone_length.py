"""Чи залежить зона розвороту від довжини ноги.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

`pivot_zone.py` виміряв зону одним числом на всі ноги: 50 подій до
розвороту, 15 після. У частках ноги ті самі 50 подій — від 3.7 % до
17.1 % (10-й і 90-й процентилі), а на найкоротшій нозі датасету це
чверть її довжини. Виходить перекіс: **коротка нога дістає більше
поблажки, ніж довга**, і саме там, де подій на всю ногу мало.

Питання одне: зона стоїть у подіях чи їде з довжиною ноги?

    їде     → зона це частка, і кожній нозі потрібна своя межа
    стоїть  → зона це стала величина класу, і правити треба не межу,
              а стелю: коротка нога не має отримувати більше подій
              безштрафовими, ніж довга

Міра та сама, що в `pivot_zone.py`: кошик подій на відстані `d` від
півота проти тіла ноги, логістична регресія на каналах класу, `AUC` на
ногах val, підлога на перемішаних мітках, межа — половина висоти піка.
Різниця одна: ноги спершу діляться на три кошики за довжиною, і крива
рахується в кожному кошику окремо.

Межі кошиків — **терцилі** ніг train, довших за `MIN_LEG`.

Вхід : датасет `legleft_blocks4_gauss_clock` (дослідження 29)
Вихід: results/zone_length.json — крива, межа і частка ноги на кошик

Запуск:
    python3 research/32-loss-ladder/scripts/zone_length.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
RESULTS = RESEARCH_DIR / "results"
sys.path.insert(0, str(SCRIPTS))


def sibling(name: str):
    """Сусідній скрипт дослідження — **за шляхом файлу**, а не за іменем.

    У проєкті є другий `pivot_zone.py` (дослідження 22), і звичайний
    `import` під повним прогоном тестів підхоплює той, чия тека раніше
    лягла в `sys.path`. Шлях файлу такої двозначності не має.
    """
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


zone = sibling("pivot_zone")

CUTS = (380, 780)          # терцилі довжин ніг train, довших за MIN_LEG
BUCKETS = (("short", 0, CUTS[0]), ("mid", CUTS[0], CUTS[1]),
           ("long", CUTS[1], 10 ** 9))
SCRIPT = "research/32-loss-ladder/scripts/zone_length.py"
OUT = "zone_length.json"


def legs_in(rows: list, picked: list, low: int, high: int) -> list:
    """Ноги кошика: довжина в `[low, high)` і не коротші за `MIN_LEG`."""
    return [one for one in picked
            if zone.MIN_LEG <= rows[one]["events"] < high
            and rows[one]["events"] >= low]


def curve_of(x, rows: list, train: list, val: list, side: str,
             seed: int = zone.SEED) -> list:
    """Крива кошика: те саме, що `pivot_zone.curve_of`, плюс лічильники.

    Ніг у кошику втричі менше, тому позитивів на кошик стає мало —
    і це число має бути видно в результаті поруч з `AUC`, інакше
    крива на двадцяти подіях виглядає як крива на тисячі.
    """
    out = []
    for number, (low, high) in enumerate(zone.STEPS):
        hot, body, _ = zone.spots_of(rows, train, low, high, side)
        cold = zone.thinned(body, zone.SAMPLE, seed + number)
        hot = zone.thinned(hot, zone.SAMPLE, seed + 100 + number)
        vhot, vbody, _ = zone.spots_of(rows, val, low, high, side)
        vcold = zone.thinned(vbody, zone.SAMPLE, seed + 200 + number)
        vhot = zone.thinned(vhot, zone.SAMPLE, seed + 300 + number)
        if len(hot) < 50 or len(vhot) < 20:
            continue
        began = time.time()
        got = zone.split_fit(x, (hot, cold), (vhot, vcold), seed + number)
        out.append({"from": low, "to": high, "at": (low + high) / 2.0,
                    **got, "train_hot": int(len(hot)),
                    "val_hot": int(len(vhot)),
                    "seconds": round(time.time() - began, 1)})
        print(f"    {side} {low:>3}…{high:<3} · AUC {got['auc']:.4f} · "
              f"підлога {got['floor']:.4f} · позитивів val {len(vhot)}")
    return out


GROUPS = ((0, 9), (10, 29), (30, 49), (50, 99), (100, 199), (200, 499))


def bands_of(curve: list, groups: tuple = GROUPS) -> list:
    """Надлишок `AUC − підлога`, складений по групах відстаней.

    Окремий кошик на двох десятках ніг val шумить на ±0.08, і правило
    «перший кошик нижче половини» обривається на цьому шумі. Група з
    двох-чотирьох кошиків цього не має: вона показує, де надлишок
    справді тримається, а де вже впав.
    """
    out = []
    for low, high in groups:
        piece = [one["auc"] - one["floor"] for one in curve
                 if one["from"] >= low and one["to"] <= high
                 and np.isfinite(one["auc"])]
        if not piece:
            continue
        out.append({"from": low, "to": high, "buckets": len(piece),
                    "over": round(float(np.mean(piece)), 4)})
    return out


def reach_of(block: dict) -> dict:
    """Докуди тримається надлишок: спільний поріг на всі кошики ніг.

    Поріг один на весь замір — половина найбільшої групи з усіх кошиків
    і обох боків. Зона кошика — верхня межа останньої групи, що стоїть
    над порогом. Спільний поріг тому, що питання порівняльне: не «яка
    зона взагалі», а «чи їде вона з довжиною ноги».
    """
    tops = [two["over"] for one in block["buckets"]
            for side in one["sides"].values()
            for two in side.get("bands", [])]
    if not tops:
        return {}
    level = max(tops) / 2.0
    out = {"level": round(level, 4), "sides": {}}
    for side in ("tail", "head"):
        got = []
        for one in block["buckets"]:
            bands = one["sides"].get(side, {}).get("bands", [])
            kept = 0
            for two in bands:
                if two["over"] >= level:
                    kept = two["to"] + 1
            if bands:
                got.append({"key": one["key"], "legs": one["legs"]["median"],
                            "events": kept,
                            "share": round(kept / one["legs"]["median"], 4)})
        if len(got) < 2:
            continue
        events = [one["events"] for one in got]
        shares = [one["share"] for one in got]
        rising = all(events[i] <= events[i + 1] for i in range(len(events) - 1))
        out["sides"][side] = {
            "rows": got, "rising": bool(rising),
            "events_spread": round(max(events) / max(min(events), 1), 2),
            "shares_spread": round(max(shares) / max(min(shares), 1e-9), 2)}
    return out


SHARES = ((0.0, 0.01), (0.01, 0.02), (0.02, 0.05), (0.05, 0.10),
          (0.10, 0.20), (0.20, 0.40))


def share_spots(rows: list, picked: list, low: float, high: float,
                side: str) -> tuple:
    """Те саме, що `pivot_zone.spots_of`, але кошик міряється в частках.

    Вісь подій і вісь часток — дві різні гіпотези про те, чим є зона.
    Правильна та, на якій криві коротких, середніх і довгих ніг
    **зливаються**: якщо зона стала в подіях, її видно на одній осі,
    якщо це частка ноги — на іншій.
    """
    bucket, body = [], []
    for one in picked:
        row = rows[one]
        events = row["events"]
        if events < zone.MIN_LEG:
            continue
        walk = np.arange(row["first"], row["last"] + 1)
        far = (row["last"] - walk) if side == "tail" else (walk - row["first"])
        part = far / max(events - 1, 1)
        near = (walk - row["first"]) / max(events - 1, 1)
        outside = (near > zone.BODY[1]) if side == "tail" \
            else (near < zone.BODY[0])
        take = (part >= low) & (part < high) & outside
        middle = (near >= zone.BODY[0]) & (near <= zone.BODY[1])
        bucket.append(walk[take])
        body.append(walk[middle])
    return (np.concatenate(bucket) if bucket else np.zeros(0, dtype=np.int64),
            np.concatenate(body) if body else np.zeros(0, dtype=np.int64))


def share_curve(x, rows: list, train: list, val: list, side: str,
                seed: int = zone.SEED) -> list:
    """Крива по частках ноги."""
    out = []
    for number, (low, high) in enumerate(SHARES):
        hot, body = share_spots(rows, train, low, high, side)
        cold = zone.thinned(body, zone.SAMPLE, seed + number)
        hot = zone.thinned(hot, zone.SAMPLE, seed + 100 + number)
        vhot, vbody = share_spots(rows, val, low, high, side)
        vcold = zone.thinned(vbody, zone.SAMPLE, seed + 200 + number)
        vhot = zone.thinned(vhot, zone.SAMPLE, seed + 300 + number)
        if len(hot) < 50 or len(vhot) < 20:
            continue
        got = zone.split_fit(x, (hot, cold), (vhot, vcold), seed + number)
        out.append({"from": low, "to": high, **got,
                    "over": round(got["auc"] - got["floor"], 4),
                    "val_hot": int(len(vhot))})
        print(f"    {side} {low:.0%}…{high:.0%} ноги · AUC {got['auc']:.4f} · "
              f"підлога {got['floor']:.4f} · позитивів val {len(vhot)}")
    return out


def agree_of(block: dict) -> dict:
    """Яка вісь зводить кошики докупи: подій чи часток ноги.

    На кожній групі відстані беремо надлишок у трьох кошиках ніг і
    дивимось розкид між ними. Вісь, на якій криві ближчі одна до одної,
    і є тією, в якій зона справді стала.
    """
    out = {}
    for axis, key in (("events", "bands"), ("share", "share_curve")):
        got = {}
        for side in ("tail", "head"):
            rows = []
            names = None
            for one in block["buckets"]:
                piece = one["sides"].get(side, {}).get(key, [])
                if not piece:
                    continue
                if key == "bands":
                    names = [f"{two['from']}…{two['to']}" for two in piece]
                    rows.append([two["over"] for two in piece])
                else:
                    names = [f"{two['from']:.0%}…{two['to']:.0%}"
                             for two in piece]
                    rows.append([two["over"] for two in piece])
            if len(rows) < 2:
                continue
            width = min(len(one) for one in rows)
            grid = np.asarray([one[:width] for one in rows], dtype=float)
            spread = np.nanstd(grid, axis=0)
            got[side] = {"steps": names[:width],
                         "rows": [[round(two, 4) for two in one]
                                  for one in grid.tolist()],
                         "spread": [round(float(two), 4) for two in spread],
                         "mean_spread": round(float(np.nanmean(spread)), 4)}
        out[axis] = got
    for side in ("tail", "head"):
        one = out.get("events", {}).get(side)
        two = out.get("share", {}).get(side)
        if one and two:
            one["axis"] = two["axis"] = ("частка ноги"
                                         if two["mean_spread"]
                                         < one["mean_spread"] else "подій")
    return out


THIRD = 3.0                # згасання: надлишок упав утричі проти піка кошика
LOWEST = 0.05              # і при цьому нижчий за це — інакше шум ловить хвіст


def death_of(block: dict, key: str = "bands") -> dict:
    """Де надлишок згасає в кожному кошику ніг — і що це у частках ноги.

    Питання не «який кошик сильніший» (довга нога видніша сама по собі),
    а **докуди тягнеться** її зона. Тому поріг береться від піка
    **свого** кошика: згаслою вважається перша група, де надлишок упав
    утричі проти найбільшої групи цього ж кошика.

    Якщо зона стала в подіях — рядок «подій» однаковий у трьох кошиках.
    Якщо це частка ноги — однаковим виходить рядок «частка».
    """
    out = []
    for one in block["buckets"]:
        piece = one["sides"].get("tail", {}).get(key, [])
        if not piece:
            continue
        peak = max(two["over"] for two in piece)
        level = max(peak / THIRD, LOWEST)
        # зупиняє **дві** групи поспіль нижче порога: одна яма посеред
        # кривої і один шумовий горб у хвості не мають ані обривати
        # зону, ані тягти її через усю ногу
        kept = 0
        for place, two in enumerate(piece):
            if two["over"] >= level:
                kept = two["to"] + 1 if key == "bands" else two["to"]
                continue
            after = piece[place + 1]["over"] if place + 1 < len(piece) else None
            if after is None or after < level:
                break
        size = one["legs"]["median"]
        events = kept if key == "bands" else int(round(kept * size))
        out.append({"key": one["key"], "median_leg": size, "peak": peak,
                    "level": round(level, 4), "events": events,
                    "share": round(events / size, 4)})
    if len(out) < 2:
        return {"rows": out}
    events = [one["events"] for one in out]
    shares = [one["share"] for one in out]
    return {"rows": out, "third": THIRD, "lowest": LOWEST,
            "events_spread": round(max(events) / max(min(events), 1), 2),
            "shares_spread": round(max(shares) / max(min(shares), 1e-9), 2),
            "verdict": "частка ноги" if (max(shares) / max(min(shares), 1e-9))
            < (max(events) / max(min(events), 1)) else "подій"}


def lengths_of(rows: list, picked: list) -> dict:
    """Довжини ніг кошика: скільки їх і які вони."""
    events = np.asarray([rows[one]["events"] for one in picked], dtype=float)
    if not len(events):
        return {"legs": 0}
    return {"legs": int(len(events)),
            "median": int(np.median(events)),
            "low": int(np.percentile(events, 10)),
            "high": int(np.percentile(events, 90))}


def slope_of(block: dict) -> dict:
    """Головна відповідь: межа їде з довжиною ноги чи стоїть?

    Поруч із межею в подіях іде та сама межа в частках медіанної ноги
    кошика. Стала зона дає рівний рядок подій і спадний рядок часток;
    зона-частка — навпаки.
    """
    out = {}
    for side in ("tail", "head"):
        events, shares, mid = [], [], []
        for one in block["buckets"]:
            edge = one["sides"].get(side, {}).get("edge", {})
            size = one["legs"]["median"] if one["legs"].get("legs") else 0
            if not edge.get("events") or not size:
                continue
            events.append(edge["events"])
            shares.append(edge["events"] / size)
            mid.append(size)
        if len(events) < 2:
            continue
        # «частка» означала б events ≈ k·довжина: міряємо обидва розкиди
        spread = (max(events) / min(events)) if min(events) else None
        drift = (max(shares) / min(shares)) if min(shares) else None
        out[side] = {"events": events, "shares": [round(s, 4) for s in shares],
                     "median_legs": mid,
                     "events_spread": round(spread, 2) if spread else None,
                     "shares_spread": round(drift, 2) if drift else None,
                     "verdict": "частка" if spread and drift
                     and spread > drift else "подій"}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    import ad_legleft as ad

    ctx = ad.prepare(force=args.force)
    rows, built = ctx["rows"], ctx["built"]
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]

    began = time.time()
    block = {"script": SCRIPT, "ready": True, "cuts": list(CUTS),
             "body": list(zone.BODY), "min_leg": zone.MIN_LEG,
             "sample": zone.SAMPLE, "margin": zone.MARGIN,
             "steps": [list(one) for one in zone.STEPS], "buckets": []}
    for key, low, high in BUCKETS:
        hot_train = legs_in(rows, train, low, high)
        hot_val = legs_in(rows, val, low, high)
        title = (f"{low}…{high} подій" if high < 10 ** 8
                 else f"від {low} подій")
        print(f"кошик {key} ({title}): ніг train {len(hot_train)}, "
              f"val {len(hot_val)}")
        one = {"key": key, "title": title, "from": low,
               "to": None if high > 10 ** 8 else high,
               "legs": lengths_of(rows, hot_train + hot_val),
               "train_legs": len(hot_train), "val_legs": len(hot_val),
               "sides": {}}
        if len(hot_train) < 20 or len(hot_val) < 5:
            print("  ніг замало, кошик пропущено")
            block["buckets"].append(one)
            continue
        for side in ("tail", "head"):
            curve = curve_of(built["x"], rows, hot_train, hot_val, side)
            edge = zone.edge_of(curve)
            one["sides"][side] = {"curve": curve, "edge": edge,
                                  "bands": bands_of(curve),
                                  "share_curve": share_curve(
                                      built["x"], rows, hot_train,
                                      hot_val, side)}
            print(f"    зона {side}: {edge['events']} подій")
        one["free"] = zone.free_of([{"key": side, "curve":
                                     one["sides"][side]["curve"]}
                                    for side in one["sides"]])
        block["buckets"].append(one)

    block["slope"] = slope_of(block)
    block["reach"] = reach_of(block)
    block["agree"] = agree_of(block)
    block["death"] = {"events": death_of(block, "bands"),
                      "share": death_of(block, "share_curve")}
    block["minutes"] = round((time.time() - began) / 60.0, 1)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    for side, got in block.get("reach", {}).get("sides", {}).items():
        rows = " · ".join(f"{one['key']} {one['events']} подій "
                          f"({one['share']:.1%} ноги)" for one in got["rows"])
        print(f"{side} (поріг {block['reach']['level']}): {rows}")
    got = block.get("death", {}).get("events", {})
    for one in got.get("rows", []):
        print(f"  {one['key']:6} нога {one['median_leg']:5} подій → зона "
              f"{one['events']:4} подій = {one['share']:.1%} ноги")
    print(f"  зона стала в: {got.get('verdict')} "
          f"(розмах подій {got.get('events_spread')}, "
          f"часток {got.get('shares_spread')})")
    for axis, got in block.get("agree", {}).items():
        for side, one in got.items():
            print(f"{axis:6} {side}: розкид між кошиками "
                  f"{one['mean_spread']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
