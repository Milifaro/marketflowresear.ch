"""Адаптер драбини: чотири горизонти (дослідження 20, розділ 12).

Одобрена версія — `research/20-leg-loss/models/hazard4_win/`: та сама
мережа (119 876 ваг, `layers 2 · hidden 64 · head 128 · вікно 75 · стеля
500`), але виходів чотири — `p₁₀`, `p₄₀`, `p₁₆₀`, `p₆₄₀`. Епоха 5 з 8,
широке AUC `0.7423` середнім по чотирьох горизонтах і шести монетах —
найкраще число дослідження 20.

Реалізація драбини спільна з одногоризонтною моделлю —
[`hazard_common.py`](hazard_common.py).
"""

from __future__ import annotations

from pathlib import Path

from hazard_common import (EXTRA, MARGIN, METRIC, METRIC_ABOUT,  # noqa: F401
                           METRIC_DIR, build, data_of, evaluate, human,
                           optimizer, pairs_of, rungs, train_epoch)
import hazard_common

PROJECT_ROOT = Path(__file__).resolve().parents[3]

NAME = "hazard4"
TITLE = "Чотири горизонти кінця ноги"
SOURCE = "research/20-leg-loss/20-leg-loss.md → розділ 12"
ABOUT = ("Та сама мережа з памʼяттю, але замість одного числа вона видає "
         "криву розподілу на чотирьох горизонтах: чи скінчиться нога в "
         "наступні 10, 40, 160 і 640 подій. Крива не спадає за побудовою, "
         "і з неї виводиться очікуване «лишилось».")

CONF = {"horizons": (10, 40, 160, 640),
        "approved": str(PROJECT_ROOT / "research" / "20-leg-loss"
                        / "models" / "hazard4_win")}


def prepare(force: bool = False) -> dict:
    return hazard_common.prepare(CONF, force=force)


def start_from(ctx: dict, model, tune) -> dict:
    return hazard_common.start_from(ctx, model, tune)
