"""Ряд val BTC: ціна зверху, видача кожної моделі драбини плашкою під нею.

Дослідження: research/32-loss-ladder/
Правила: rules/05-visualization.md → компоновка

Таблиці драбини дають по одному числу на монету. Тут ті самі моделі
показані **рядом**: ціна BTC із зігзагом 2.3 % на ема10 зверху, і під
нею — плашка на кожну модель, на **спільній осі X**. У кожній плашці
дві лінії: одобрена версія і та, яку знайшла драбина. Там, де драбина
не взяла жодного щабля, лінії збігаються — це видно очима, і саме так
воно й має виглядати.

## Спільна вісь

Мережі живуть на різних розмітках, але всі — на сітці подій 210 с, тому
подія знаходиться за своїм `t_start`. Кістяк ряду (час, ціна, ема10,
півоти) береться з `клас210х10-1х7д/д` BTC, як у дослідженнях 30 і 31, а
видача кожної моделі кладеться на цю вісь за часом. Чого в моделі немає
— розрив у лінії, а не нуль: межа train|val у дослідження 20 інша
(`14.08 15:27` проти `14.08 00:02`), і перші години val у її плашках
чесно порожні.

## Що в плашках

    legleft     скільки подій лишилось до кінця ноги: видача і правда
    legtip      сигнал «ми в останніх 5 % ноги», 0…1
    hazard100   калібрована `p₁₀₀` — «нога скінчиться в наступні 100 подій»
    hazard4     чотири горизонти тієї самої моделі: 10, 40, 160, 640
    zone        канали «зона півота» і «зона корекції», 0…1

Ваги беруться дві: одобрена версія свого дослідження і найкраща версія
драбини з `models/<модель>/model.pt`. Нічого не вчиться — це тільки
прохід по val.

## Чому замір іде на процесорі

Прохід LSTM на прискорювачі `mps` дає **різну видачу залежно від того,
чи був у цьому процесі зворотний прохід**: та сама вага, ті самі дані —
і дві різні відповіді. На процесорі такого немає, і саме процесорні
числа збігаються з `mps` у процесі без навчання. Тому ряд рахується на
`--device cpu`, а поруч із мірою прогону драбини у файл кладеться
**переміряна** — щоб різницю було видно, а не сховано.

Вхід : ваги моделей, дані своїх досліджень
Вихід: results/series_<модель>_BTC_USDT.json  — видача однієї моделі
       results/val_series_BTC_USDT.json       — зшитий ряд для вкладки

Запуск:
    python3 research/32-loss-ladder/scripts/val_series.py            усе
    python3 research/32-loss-ladder/scripts/val_series.py --model zone
    python3 research/32-loss-ladder/scripts/val_series.py --join
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS_DIR = RESEARCH_DIR / "models"
PAIR = "BTC_USDT"
MODELS = ("legleft", "legtip", "hazard100", "hazard4", "zone")
SEED = 17
JOINED = "val_series_BTC_USDT.json"
DEVICE = "cpu"                # див. «Чому замір іде на процесорі»
HALF = 105                    # пів події сітки 210 с: далі це вже сусід
SCRIPT = "research/32-loss-ladder/scripts/val_series.py"


# ---------------------------------------------------------------- дрібниці

def weights_of(name: str, approved: Path) -> list:
    """Дві версії ваг: одобрена і та, яку лишила драбина."""
    return [("base", approved), ("best", MODELS_DIR / name / "model.pt")]


def lift(model, path: Path) -> None:
    import torch

    if not path.exists():
        raise SystemExit(f"немає ваг: {path}")
    model.load_state_dict(torch.load(path, map_location="cpu"))


def rounded(values, digits: int = 4) -> list:
    """Числа в JSON: пропуск — `null`, інакше файл бреше нулем."""
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def write(name: str, block: dict, out: Path) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"series_{name}_{PAIR}.json"
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path}")
    return path


# ------------------------------------------------------------------ моделі

def series_legleft(name: str = "legleft") -> dict:
    """Скільки подій до кінця ноги: видача обох версій і сама правда."""
    sys.path.insert(0, str(SCRIPTS))
    import ad_legleft as ad

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    picked = [one for one in ctx["val"] if rows[one]["pair"] == PAIR]
    index = np.concatenate([np.arange(rows[one]["last"] - rows[one]["events"]
                                      + 1, rows[one]["last"] + 1)
                            for one in picked])
    model, _ = ad.build(ctx, SEED)
    values, truth, marks = {}, None, {}
    for kind, path in weights_of(name, ad.APPROVED / "model.pt"):
        lift(model, path)
        block = ad.base.guess(model, built, rows, picked, ctx["device"])
        if len(block["said"]) != len(index):
            raise SystemExit("видача і вісь подій розʼїхались")
        values[f"legleft_{kind}"] = rounded(block["said"], 1)
        marks[kind] = ad.marks_of(block, rows, picked)["mark"]
        truth = rounded(block["truth"], 1)
    return {"model": name, "pair": PAIR, "legs": len(picked),
            "device": DEVICE, "marks": marks,
            "t": [int(one) for one in built["t"][index]],
            "values": {**values, "legleft_truth": truth}}


def series_legtip(name: str = "legtip") -> dict:
    """Сигнал кінця ноги: ймовірність обох версій і мітка останніх 5 %."""
    sys.path.insert(0, str(SCRIPTS))
    import ad_legtip as ad

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    picked = [one for one in ctx["val"] if rows[one]["pair"] == PAIR]
    index = np.concatenate([np.arange(rows[one]["last"] - rows[one]["events"]
                                      + 1, rows[one]["last"] + 1)
                            for one in picked])
    model, _ = ad.build(ctx, SEED)
    values, truth, marks = {}, None, {}
    for kind, path in weights_of(name, ad.APPROVED / "model.pt"):
        lift(model, path)
        block = ad.base.guess(model, built, rows, picked, ctx["device"])
        if len(block["said"]) != len(index):
            raise SystemExit("видача і вісь подій розʼїхались")
        values[f"legtip_{kind}"] = rounded(block["said"])
        marks[kind] = ad.base.score(block)["ap"]
        truth = [int(one > 0.5) for one in block["truth"]]
    return {"model": name, "pair": PAIR, "legs": len(picked),
            "device": DEVICE, "marks": marks,
            "t": [int(one) for one in built["t"][index]],
            "values": {**values, "legtip_zone": truth}}


def series_hazard(name: str) -> dict:
    """Горизонти «нога скінчиться в наступні N подій» на потоці BTC."""
    sys.path.insert(0, str(SCRIPTS))
    import hazard_common
    ad = __import__("ad_hazard" if name == "hazard100" else "ad_hazard4")
    import hazard_net as hazard
    import torch

    ctx = ad.prepare(force=True)
    stream = next(one for one in ctx["val"] if one["pair"].startswith("BTC"))
    known = stream["known"]
    model, _ = ad.build(ctx, SEED)
    step = {"wmul": 1.0, "gamma": 0.0, "near": (0, 1.0), "window": 75,
            "lift": hazard_common.LIFT}
    values, marks = {}, {}
    for kind, path in weights_of(name, Path(ad.CONF["approved"])
                                 / "model.pt"):
        lift(model, path)
        # `evaluate` дослідження 20 міряє саме так: без градієнта і з
        # вимкненим dropout. Прохід у режимі навчання дає інші числа —
        # це вже не та модель, яку одобрили
        model.eval()
        with torch.no_grad():
            walked = hazard_common.walk(model, stream, ctx["knobs"],
                                        ctx["weights"], step)
        each = []
        for place, horizon in enumerate(hazard.HORIZONS):
            curve = np.where(known, walked["curve"][:, place], np.nan)
            values[f"{name}_p{horizon}_{kind}"] = rounded(curve)
            got = hazard.auc_of(walked["curve"][known, place],
                                stream["labels"][known, place])
            if got == got:
                each.append(float(got))
        marks[kind] = float(np.mean(each)) if each else None
    labels = np.where(known, stream["labels"][:, 0], np.nan)
    return {"model": name, "pair": stream["pair"],
            "horizons": [int(one) for one in hazard.HORIZONS],
            "events": int(known.sum()), "device": "cpu", "marks": marks,
            "t": [int(one) for one in stream["t"]],
            "values": {**values, f"{name}_zone": rounded(labels, 0)}}


def series_zone(name: str = "zone") -> dict:
    """Зона півота і зона корекції: два канали з трьох на кожній події."""
    sys.path.insert(0, str(SCRIPTS))
    import ad_zone as ad
    from zones import MARKS

    device = DEVICE
    coin = ad.base.coin_data(PAIR, ad.CLASS, ad.REDUCE, "all", None, None)
    for part in ("train", "val"):
        coin[f"blocks_{part}"] = ad.base.blocks_of(
            coin["where"], coin["legs"], coin["t"], coin["cut"], ad.STEP,
            part, "events")
    ctx = {"coins": [coin], "device": device,
           "labels": coin["labels"][np.concatenate(coin["blocks_train"])],
           "channels": int(coin["levels"].shape[1])}
    model, _ = ad.build(ctx, SEED)
    one = ad.rungs()[0]["step"]
    values, index, truth, marks = {}, None, None, {}
    for kind, path in weights_of(name, MODELS_DIR / name / "base.pt"):
        lift(model, path)
        got = ad.epoch(ctx, model, None, one, False)
        index = got["index"].astype(int)
        truth = got["truth"].astype(int)
        marks[kind] = ad.mark_of(ad.base.metrics_of(got["truth"],
                                                    got["proba"]))
        for channel in ("pivot", "correction"):
            values[f"zone_{channel}_{kind}"] = rounded(
                got["proba"][:, MARKS.index(channel)])
    return {"model": name, "pair": PAIR,
            "blocks": len(coin["blocks_val"]),
            "events": int(len(index)), "device": device, "marks": marks,
            "t": [int(one) for one in coin["t"][index]],
            "values": {**values,
                       "zone_mark": [int(one) for one in truth]}}


MAKERS = {"legleft": series_legleft, "legtip": series_legtip,
          "hazard100": series_hazard, "hazard4": series_hazard,
          "zone": series_zone}


# ------------------------------------------------------------------ кістяк

def skeleton(root: Path | None = None) -> dict:
    """Час, ціна, ема10 і півоти зігзага 2.3 % — усе на подіях BTC."""
    sys.path.insert(0, str(PROJECT_ROOT / "research" / "30-inleg-events"
                           / "scripts"))
    sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
    import inleg_profile as inleg
    from class210ema4 import ema
    from zigzag import zigzag

    data = inleg.load(PAIR, inleg.CLASS, root)
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["open"], dtype=float)
    smooth = ema(price, inleg.PERIOD)
    pivots = [{"t": int(stamps[one.index]), "ema": float(smooth[one.index]),
               "kind": one.kind} for one in zigzag(smooth, inleg.THRESHOLD)]
    return {"t": stamps, "price": price, "ema": smooth, "pivots": pivots,
            "cut": int(data["cut"]), "class": inleg.CLASS,
            "threshold": inleg.THRESHOLD, "period": inleg.PERIOD}


# ---------------------------------------------------------------- опис плашок

def panels_of(runs: dict) -> list:
    """Опис плашок: що в кожній лінії і звідки вона взялась."""
    out = []
    for name in MODELS:
        if name not in runs:
            continue
        lines = []
        if name == "legleft":
            lines = [{"key": "legleft_best", "title": "драбина",
                      "kind": "best"},
                     {"key": "legleft_base", "title": "одобрена",
                      "kind": "base"},
                     {"key": "legleft_truth", "title": "насправді",
                      "kind": "truth"}]
        elif name == "legtip":
            lines = [{"key": "legtip_best", "title": "драбина",
                      "kind": "best"},
                     {"key": "legtip_base", "title": "одобрена",
                      "kind": "base"}]
        elif name in ("hazard100", "hazard4"):
            for horizon in runs[name].get("horizons", []):
                lines.append({"key": f"{name}_p{horizon}_best",
                              "title": f"драбина p{horizon}", "kind": "best"})
                lines.append({"key": f"{name}_p{horizon}_base",
                              "title": f"одобрена p{horizon}", "kind": "base"})
        elif name == "zone":
            for channel, title in (("pivot", "півот"),
                                   ("correction", "корекція")):
                lines.append({"key": f"zone_{channel}_best",
                              "title": f"драбина · {title}", "kind": "best"})
                lines.append({"key": f"zone_{channel}_base",
                              "title": f"одобрена · {title}", "kind": "base"})
        out.append({"model": name, "lines": lines})
    return out


def mark_of(report: dict, side: str) -> float | None:
    """Міра моделі **на самому BTC**: спільне число ховає монету."""
    block = report[side]["by_pair"]
    for key, value in block.items():
        if key.startswith("BTC"):
            got = value.get("mark")
            return got if isinstance(got, (int, float)) else None
    return None


def nearest(axis: np.ndarray, stamps, gap: int = HALF) -> np.ndarray:
    """Куди лягає подія моделі на осі ряду; `-1` — нікуди.

    Сітки подій у дослідженнях різні: `клас210х14х4ц` дослідження 20
    стоїть на своєму якорі, і його мітки часу не збігаються з мітками
    `клас210х10-1х7д/д` до секунди. Тому подія шукає **найближчу**
    подію осі, і лягає на неї, тільки якщо та ближча за пів події.
    """
    stamps = np.asarray(stamps, dtype=np.int64)
    if not len(axis) or not len(stamps):
        return np.full(len(stamps), -1, dtype=np.int64)
    right = np.searchsorted(axis, stamps)
    left = np.clip(right - 1, 0, len(axis) - 1)
    right = np.clip(right, 0, len(axis) - 1)
    pick = np.where(np.abs(axis[left] - stamps)
                    <= np.abs(axis[right] - stamps), left, right)
    return np.where(np.abs(axis[pick] - stamps) <= gap, pick, -1)


def window_of(row: np.ndarray, stamps: np.ndarray) -> dict:
    """Відрізок, на якому модель узагалі відповідає.

    Вікна в моделей різні: ноги дослідження 29 лежать у val цілком,
    навіть якщо почались до межі; дослідження 20 має свою межу і свій
    кінець датасету. Це не збій, і плашка має сказати це числом.
    """
    good = np.flatnonzero(np.isfinite(np.asarray(row, dtype=float)))
    if not len(good):
        return {"from": None, "to": None}
    return {"from": int(stamps[good[0]]), "to": int(stamps[good[-1]])}


def join(out: Path = RESULTS) -> dict:
    """Зшити видачі моделей на спільну вісь подій BTC."""
    runs = {}
    for name in MODELS:
        path = out / f"series_{name}_{PAIR}.json"
        if path.exists():
            runs[name] = json.loads(path.read_text(encoding="utf-8"))
    if not runs:
        return {"script": SCRIPT, "ready": False, "pair": PAIR,
                "models": [], "reason": "жодної видачі не пораховано"}
    bones = skeleton()
    axis = np.asarray(bones["t"], dtype=np.int64)
    total = len(axis)
    values, touched, panels = {}, np.zeros(total, dtype=bool), []
    lost = {}
    for name, got in runs.items():
        where = nearest(axis, got["t"])
        good = where >= 0
        lost[name] = int((~good).sum())
        touched[where[good]] = True
        for key, row in got["values"].items():
            column = np.full(total, np.nan)
            column[where[good]] = np.asarray(row, dtype=float)[good]
            values[key] = column
    keep = np.flatnonzero(touched)
    span = slice(int(keep[0]), int(keep[-1]) + 1)
    stamps = bones["t"][span]
    ladders = {}
    for name in runs:
        path = out / f"ladder_{name}.json"
        if path.exists():
            ladders[name] = json.loads(path.read_text(encoding="utf-8"))
    for panel in panels_of(runs):
        name = panel["model"]
        report = ladders.get(name, {})
        panels.append({
            **panel,
            "title": report.get("title", name),
            "about": report.get("about"),
            "source": report.get("source"),
            "metric": report.get("metric"),
            "metric_dir": report.get("metric_dir"),
            "better": bool(report.get("better")),
            "rung": (report.get("best") or {}).get("rung"),
            "rung_name": (report.get("best") or {}).get("name"),
            "mark": {"base": mark_of(report, "base") if report else None,
                     "best": mark_of(report, "best") if report else None},
            # переміряне на процесорі: прогін драбини йшов на прискорювачі,
            # і його число не завжди повторюється (див. заголовок файлу)
            "mark_now": runs[name].get("marks", {}),
            "device": runs[name].get("device"),
            "events": int(np.isfinite(
                values[panel["lines"][0]["key"]][span]).sum()),
            **window_of(values[panel["lines"][0]["key"]][span], stamps),
            "lost": lost.get(name, 0),
            "zone": (f"{name}_zone" if f"{name}_zone" in values
                     else ("zone_mark" if name == "zone" else None)),
            "range": None if name == "legleft" else {"low": 0.0, "high": 1.0},
            "digits": 0 if name == "legleft" else 3})
    block = {"script": SCRIPT, "ready": True, "pair": PAIR,
             "class": bones["class"], "threshold": bones["threshold"],
             "period": bones["period"], "cut": bones["cut"],
             "event_seconds": 210, "device": DEVICE,
             "models": [one["model"] for one in panels],
             "events": int(len(stamps)),
             "from": int(stamps[0]), "to": int(stamps[-1]),
             "t": [int(one) for one in stamps],
             "price": [round(float(one), 2) for one in bones["price"][span]],
             "ema": [round(float(one), 2) for one in bones["ema"][span]],
             "pivots": [one for one in bones["pivots"]
                        if stamps[0] <= one["t"] <= stamps[-1]],
             "panels": panels}
    for key, column in values.items():
        piece = column[span]
        block[key] = rounded(piece, 1 if key.startswith("legleft") else 4)
    path = out / JOINED
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path} — {block['events']} подій, "
          f"{len(panels)} плашок, {len(block['pivots'])} півотів")
    for name, count in lost.items():
        if count:
            print(f"  {name}: {count} подій не лягли на вісь класу")
    return block


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--model", default=None, choices=MODELS)
    parser.add_argument("--join", action="store_true",
                        help="тільки зшити те, що вже пораховано")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    if args.model:
        write(args.model, MAKERS[args.model](args.model), args.out)
        return
    if not args.join:
        # кожна модель — своїм процесом: разом вони не влазять у памʼять
        for name in MODELS:
            print(f"--- {name}")
            done = subprocess.run(
                [sys.executable, "-u", str(Path(__file__).resolve()),
                 "--model", name, "--out", str(args.out)])
            if done.returncode:
                print(f"  {name}: прогін не вдався, код {done.returncode}")
    join(args.out)


if __name__ == "__main__":
    main()
