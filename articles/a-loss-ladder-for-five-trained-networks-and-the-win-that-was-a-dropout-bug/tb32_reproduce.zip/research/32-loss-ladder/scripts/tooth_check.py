"""Чиї зубці кращі: кандидати на роль сигналу кінця ноги, одна лінійка.

Дослідження: research/32-loss-ladder/
Правила: rules/03-models.md → Правила навчання

Етап 10 показав, що одна голова обидві задачі не тягне: скільки не
тисни на частоту обнулень, вона стоїть на 16–26 на 1000, а розмах лінії
осідає в нуль. Тому задачі діляться: одна мережа каже **де зубець**,
друга веде **частку пройденої ноги**, і обнуляється чужим сигналом.

Перше питання цього поділу — чий сигнал брати за зубці. Тут кандидати
міряються **однією лінійкою**, на тій самій стрічці val і в тій самій
рамці: рухомі вікна, розмітка забілена, «своя нога» скрізь одиниця.
Нарізки по ногах немає ні в кого — етап 5 показав, що вона сама
підказує мережі, де кінець.

## Чим міряються

Головне число — **вільне від порога**: `AUC` видачі як ознаки «подія в
зоні розвороту», де зона це 9.5 % ноги до півота і 15 подій після.
Ранг не залежить від того, як хто калібрований.

Далі — те, що видно на ділі: для кожної цілі «скільки обнулень на 1000
подій» береться поріг, який саме стільки й дає, і на ньому рахується

    підйом    у скільки разів частіше сигнал лягає в зону, ніж якби
              його розкидали навмання
    у зоні    частка розворотів, біля яких сигнал таки був
    без сигналу   частка розворотів, повз які пройшли мовчки

Так видно головне: **якщо дозволити рівно одне обнулення на ногу, чиї
зубці стоять там, де треба.**

Вхід : ваги кандидатів у models/, датасет `legleft_blocks4_gauss_clock`
Вихід: results/tooth_check.json

Запуск:
    python3 research/32-loss-ladder/scripts/tooth_check.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = SCRIPTS.parents[2]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
sys.path.insert(0, str(SCRIPTS))

SEED = 0
SHARE = 0.095              # зона до розвороту: частка ноги (zone_length.py)
LOW, HIGH = 15, 150
HEAD = 15
RATES = (1.0, 2.5, 5.0, 10.0, 20.0)   # цілі: обнулень на 1000 подій
NEAR = 200                 # у яких межах шукається сигнал біля розвороту
SCRIPT = "research/32-loss-ladder/scripts/tooth_check.py"
OUT = "tooth_check.json"

# Кандидати: ім'я ваг у models/, який вихід брати і звідки мережа.
KINDS = (
    {"key": "legzone", "weights": "legzone", "head": "reset", "outputs": 2,
     "title": "сигнал «обнулись» мережі частки (етап 8)"},
    {"key": "legrate", "weights": "legrate", "head": "reset", "outputs": 2,
     "title": "те саме після драбини частоти (етап 10)"},
    {"key": "legtip", "weights": "legtip", "head": "plain", "outputs": 1,
     "title": "«сигнал кінця ноги» дослідження 29, донавчений драбиною"},
)


def sibling(name: str):
    """Сусідній скрипт дослідження — за шляхом файлу, а не за іменем."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"ladder32_{name}", SCRIPTS / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


def model_of(ctx: dict, kind: dict, ad):
    """Мережа кандидата з його ваг: голова своя, тулуб спільний."""
    import torch
    from leg_end_net import LegEnd

    path = MODELS / kind["weights"] / "model.pt"
    if not path.exists():
        return None
    torch.manual_seed(SEED)
    model = LegEnd(features=ctx["built"]["x"].shape[1] + 1, hidden=ad.HIDDEN,
                   heads=ad.HEADS, attention=True,
                   outputs=kind["outputs"]).to(ctx["device"])
    model.load_state_dict(torch.load(path, map_location="cpu"))
    model.eval()
    return model


def score_on(model, built: dict, boxes: list, kind: dict, device: str,
             total: int) -> np.ndarray:
    """Видача кандидата на всій стрічці val: одне число на подію."""
    import torch
    import share_train as share

    out = np.full(total, np.nan, dtype=np.float32)
    for chunk in share.packed(boxes):
        length = max(one["steps"] for one in chunk)
        width = built["x"].shape[1] + 1
        x = np.zeros((len(chunk), length, width), dtype=np.float32)
        mask = np.zeros((len(chunk), length), dtype=bool)
        for number, one in enumerate(chunk):
            steps = one["steps"]
            x[number, :steps, :-1] = share.frame_of(built, one)
            x[number, :steps, -1] = 1.0
            mask[number, :steps] = True
        lengths = torch.tensor([one["steps"] for one in chunk])
        with torch.no_grad():
            raw = model(torch.from_numpy(x).to(device),
                        torch.from_numpy(mask).to(device), lengths)
            # мережа з одним виходом віддає (вікна, події) без третьої
            # осі, з двома — (вікна, події, 2); беремо перший вихід
            said = torch.sigmoid(raw[..., 0] if raw.dim() == 3 else raw)
        piece = said.float().cpu().numpy()
        for number, one in enumerate(chunk):
            keep = slice(one["steps"] - one["events"], one["steps"])
            out[one["first"]:one["last"] + 1] = piece[number, keep]
        share.free_of(device)
    return out


def zones_of(rows: list, picked: list) -> list:
    """Зона кожного розвороту: хвіст часткою ноги, голова в подіях."""
    out = []
    for one in picked:
        row = rows[one]
        tail = min(max(int(round(row["events"] * SHARE)), LOW), HIGH)
        out.append({"at": row["last"], "from": row["last"] - tail,
                    "to": row["last"] + HEAD})
    return out


def inzone_mask(rows: list, picked: list, total: int) -> np.ndarray:
    """Мітка «подія в зоні розвороту» — ціль для вільного від порога AUC."""
    out = np.zeros(total, dtype=bool)
    for one in zones_of(rows, picked):
        out[max(one["from"], 0):one["to"] + 1] = True
    return out


def level_for(score: np.ndarray, seen: np.ndarray, rate: float) -> float:
    """Поріг, який дає рівно `rate` обнулень на 1000 подій."""
    live = score[seen & np.isfinite(score)]
    if not len(live):
        return 1.0
    share = min(max(rate / 1000.0, 1.0 / len(live)), 1.0)
    return float(np.quantile(live, 1.0 - share))


def at_level(score: np.ndarray, seen: np.ndarray, rows: list, picked: list,
             level: float) -> dict:
    """Числа на заданому порозі: підйом, влучність, мовчання."""
    hit = np.flatnonzero(seen & np.isfinite(score) & (score > level))
    zones = zones_of(rows, picked)
    where = np.flatnonzero(seen)
    cover = np.zeros(len(where), dtype=bool)
    inside = np.zeros(len(hit), dtype=bool)
    found = np.zeros(len(zones), dtype=bool)
    for place, one in enumerate(zones):
        cover |= (where >= one["from"]) & (where <= one["to"])
        inside |= (hit >= one["from"]) & (hit <= one["to"])
        found[place] = bool(np.any((hit >= one["from"])
                                   & (hit <= one["to"])))
    part = float(cover.mean()) if len(where) else 0.0
    gaps = []
    for one in zones:
        away = hit - one["at"]
        if not len(away):
            continue
        place = int(np.argmin(np.abs(away)))
        gaps.append(int(away[place]) if abs(away[place]) <= NEAR else None)
    near = [one for one in gaps if one is not None]
    return {"level": round(level, 4), "resets": int(len(hit)),
            "per_1000": round(len(hit) / max(int(seen.sum()), 1) * 1000, 2),
            "on_pivot": round(float(inside.mean()), 4) if len(hit) else 0.0,
            "cover": round(part, 4),
            "lift": round(float(inside.mean()) / part, 2)
            if part > 0 and len(hit) else None,
            "inzone": round(float(found.mean()), 4) if len(zones) else None,
            "missed": round(1.0 - len(near) / max(len(gaps), 1), 4),
            "delay": round(float(np.median(near)), 1) if near else None}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    import ad_legleft as ad
    import share_train as share

    zone = sibling("pivot_zone")
    ctx = ad.prepare(force=args.force)
    rows, built = ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    was = RESULTS / "zone_train.json"
    older = json.loads(was.read_text(encoding="utf-8")) if was.exists() else {}
    win = int(older.get("win", share.WIN))
    warm = int(older.get("warm", share.WARM))
    boxes = share.windows(share.spans_of(rows, val), win, warm)
    seen = np.zeros(total, dtype=bool)
    for one in boxes:
        seen[one["first"]:one["last"] + 1] = True
    truth = inzone_mask(rows, val, total)
    print(f"вікон val {len(boxes)} по {win} подій · подій {int(seen.sum())} · "
          f"розворотів {len(val)} · зона {SHARE:.1%} ноги + {HEAD} подій")

    began = time.time()
    block = {"script": SCRIPT, "ready": True, "share": SHARE, "low": LOW,
             "high": HIGH, "head": HEAD, "rates": list(RATES),
             "win": win, "warm": warm, "events": int(seen.sum()),
             "pivots": len(val), "kinds": []}
    for kind in KINDS:
        model = model_of(ctx, kind, ad)
        if model is None:
            print(f"{kind['key']}: ваг немає, пропускаю")
            continue
        score = score_on(model, built, boxes, kind, ctx["device"], total)
        good = seen & np.isfinite(score)
        auc = zone.auc_of(truth[good].astype(float), score[good])
        one = {**{key: kind[key] for key in ("key", "title", "weights")},
               "auc": round(auc, 4), "steps": []}
        print(f"{kind['key']}: AUC зони {auc:.4f}")
        for rate in RATES:
            got = at_level(score, seen, rows, val,
                           level_for(score, seen, rate))
            got["aim"] = rate
            one["steps"].append(got)
            print(f"  ціль {rate:>5.1f}/1000 · поріг {got['level']:.4f} · "
                  f"вийшло {got['per_1000']:>5.2f} · підйом {got['lift']} · "
                  f"у зоні {got['inzone']} · без сигналу {got['missed']}")
        block["kinds"].append(one)

    block["minutes"] = round((time.time() - began) / 60.0, 1)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / OUT
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
