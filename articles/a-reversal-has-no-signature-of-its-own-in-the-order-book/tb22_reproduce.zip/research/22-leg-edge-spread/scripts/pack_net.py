"""Чи можна відрізнити пачку розвороту від будь-якої іншої десятки.

Дослідження: research/22-leg-edge-spread/
Правила: rules/01-data-and-db.md → Скейлери, Порядок дій і захист від витоку
         rules/03-models.md → Навчання моделей
         rules/05-visualization.md → UMAP

Розділ 3 порівнював силу пачок числом. Тут питання ставиться як задача
класифікації: **мережа проти всього датасету**.

## Пачки

| Клас | Що це | Мітка |
| ---- | ----- | ----- |
| розворот | сім подій до півота разом з ним і три після | `1` |
| решта | десятки поза зоною розвороту, без перекриття | `0` |

Пачки, що зачіпають зону, але не збігаються з нею, у навчання не йдуть:
вони ні розворот, ні «чиста» решта.

Пачка бере участь, тільки якщо всі десять подій ідуть підряд (210 секунд)
і в них немає жодного `NaN`.

## Вектор пачки

Подія — це `9 × 7` чисел, пачка — `10 × 9 × 7 = 630`. Фічі класу не
обмежені й мають важкі хвости, тому кожна фіча переводиться в **квантиль
свого ряду**: `x -> 2u − 1`, межі `[-1, 1]`.

Скейлер рахується **на подіях train своєї монети** і застосовується до
val (`scalers.quantile_fit` / `quantile_apply`) — інакше val підглядав би
у власний розподіл.

## Моделі

| Модель | Що це |
| ------ | ----- |
| `logistic` | логістична регресія, `class_weight="balanced"` |
| `mlp` | одношаровий персептрон 64, `relu`, `adam`, ті самі ваги через дублювання пачок розвороту |

Розбиття за датою: train — до `2026-08-14`, val — далі. Пачка цілком
лежить по один бік межі.

Міри: `AUC` (ROC) і `AP` (площа під precision-recall). Базова частка
розворотів — біля двох сотих відсотка, тому `AP` тут важливіший за `AUC`.

## Карта

UMAP на тих самих векторах: усі пачки розвороту й випадкова решта до
`SAMPLE`. Метрика `cosine`, три виміри, seed `SEED` (rules/05).

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/pack_net.json   — числа моделей
       results/pack_umap.json  — точки карти

Запуск:
    python3 research/22-leg-edge-spread/scripts/pack_net.py
    python3 research/22-leg-edge-spread/scripts/pack_net.py --no-umap
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import pivot_zone  # noqa: E402
import scalers  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = pivot_zone.CLASS
MODULE = pivot_zone.MODULE
LEAD, TAIL = pivot_zone.LEAD, pivot_zone.TAIL
SIZE = LEAD + TAIL
SEED = 0
SAMPLE = 6000              # точок на карті
HIDDEN = 64                # ширина прихованого шару
MAX_ITER = 60
OVERSAMPLE = 20            # у скільки разів дублюється пачка розвороту
METRIC = "cosine"
DIMS = 3
N_NEIGHBORS = 30
MIN_DIST = 0.1
LABELS = ({"id": 1, "name": "пачка розвороту"},
          {"id": 0, "name": "решта датасету"})


def cell(value):
    value = float(value)
    return None if not np.isfinite(value) else round(value, 4)


def coin_packs(coin: dict, features: list, lead: int = LEAD,
               tail: int = TAIL) -> dict:
    """Пачки однієї монети: вектори, мітки й частина датасету.

    Квантильний скейлер кожної фічі рахується на подіях train цієї
    монети й застосовується до всього її ряду.
    """
    size = lead + tail
    t, x = coin["t"], coin["x"]
    edge, right = stamp(CUT), stamp(END)
    scaled = np.empty_like(x, dtype=float)
    train_events = t < edge
    params = []
    for index in range(x.shape[2]):
        column = x[:, :, index]
        fit = scalers.quantile_fit(column[train_events].ravel())
        scaled[:, :, index] = scalers.quantile_apply(
            column.ravel(), fit).reshape(column.shape)
        params.append(fit["n"])

    zone = pivot_zone.zone_index(len(t), coin["pivots"], lead, tail)
    positive = pivot_zone.clean_starts(
        x, t, pivot_zone.zone_windows(len(t), coin["pivots"], lead, tail),
        size)
    step = np.arange(0, len(t) - size + 1, size)
    outside = np.array([one for one in step if not zone[one:one + size].any()],
                       dtype=np.int64)
    negative = pivot_zone.clean_starts(x, t, outside, size)

    rows, labels, parts, stamps = [], [], [], []
    for starts, label in ((positive, 1), (negative, 0)):
        for one in starts:
            block = scaled[one:one + size]
            if not np.isfinite(block).all():
                continue
            if t[one + size - 1] < edge:
                part = "train"
            elif t[one] >= edge and t[one + size - 1] < right:
                part = "val"
            else:
                continue
            rows.append(block.ravel())
            labels.append(label)
            parts.append(part)
            stamps.append(int(t[one]))
    return {"pair": coin["pair"],
            "x": np.array(rows, dtype=np.float32) if rows
            else np.empty((0, size * x.shape[1] * x.shape[2]),
                          dtype=np.float32),
            "y": np.array(labels, dtype=np.int8),
            "part": np.array(parts), "t": np.array(stamps, dtype=np.int64),
            "features": list(features), "train_events": int(params[0])}


def collect_packs(state: dict, lead: int = LEAD, tail: int = TAIL,
                  log=print) -> dict:
    """Пачки всіх монет одним набором."""
    coins = []
    for coin, pair in zip(state["coins"], PAIRS):
        coin["pair"] = pair
        body = coin_packs(coin, state["features"], lead, tail)
        coins.append(body)
        log(f"      {pair}: пачок {len(body['y'])}, "
            f"розворотів {int(body['y'].sum())}")
    return {
        "x": np.vstack([one["x"] for one in coins]),
        "y": np.concatenate([one["y"] for one in coins]),
        "part": np.concatenate([one["part"] for one in coins]),
        "coin": np.concatenate([np.full(len(one["y"]), index, dtype=np.int16)
                                for index, one in enumerate(coins)]),
        "t": np.concatenate([one["t"] for one in coins]),
        "by_coin": [{"pair": one["pair"], "packs": int(len(one["y"])),
                     "reversal": int(one["y"].sum())} for one in coins],
    }


def scores(model, x: np.ndarray) -> np.ndarray:
    """Оцінка моделі: рішення регресії або ймовірність мережі."""
    if hasattr(model, "decision_function"):
        return model.decision_function(x)
    return model.predict_proba(x)[:, 1]


def measure(y: np.ndarray, score: np.ndarray) -> dict:
    """AUC і AP на одній вибірці."""
    from sklearn.metrics import average_precision_score, roc_auc_score

    if len(set(y)) < 2:
        return {}
    return {"auc": cell(roc_auc_score(y, score)),
            "ap": cell(average_precision_score(y, score)),
            "base": cell(y.mean()), "packs": int(len(y)),
            "reversal": int(y.sum())}


def fit_logistic(train: tuple, seed: int = SEED):
    from sklearn.linear_model import LogisticRegression

    model = LogisticRegression(max_iter=2000, class_weight="balanced",
                               random_state=seed)
    model.fit(*train)
    return model


def fit_mlp(train: tuple, hidden: int = HIDDEN, seed: int = SEED,
            oversample: int = OVERSAMPLE, max_iter: int = MAX_ITER):
    """Персептрон. Ваг класів у sklearn немає, тому розвороти дублюються."""
    from sklearn.neural_network import MLPClassifier

    x, y = train
    extra = np.repeat(np.flatnonzero(y == 1), max(oversample - 1, 0))
    index = np.concatenate([np.arange(len(y)), extra])
    rng = np.random.default_rng(seed)
    rng.shuffle(index)
    model = MLPClassifier(hidden_layer_sizes=(hidden,), activation="relu",
                          solver="adam", max_iter=max_iter,
                          random_state=seed, early_stopping=False)
    model.fit(x[index], y[index])
    return model


def run_models(packs: dict, seed: int = SEED, log=print) -> list:
    """Логістична регресія і мережа на тих самих пачках."""
    train = packs["part"] == "train"
    val = packs["part"] == "val"
    out = []
    for name, fit in (("logistic", fit_logistic), ("mlp", fit_mlp)):
        started = time.time()
        model = fit((packs["x"][train], packs["y"][train]), seed=seed)
        body = {"model": name, "seconds": round(time.time() - started, 1)}
        for part, mask in (("train", train), ("val", val)):
            body[part] = measure(packs["y"][mask],
                                 scores(model, packs["x"][mask]))
        out.append(body)
        log(f"      {name}: train AUC {body['train'].get('auc')}, "
            f"val AUC {body['val'].get('auc')}, val AP {body['val'].get('ap')}"
            f" за {body['seconds']} с")
    return out


def sample_index(y: np.ndarray, size: int, seed: int = SEED) -> np.ndarray:
    """Розшарована вибірка: усі розвороти й випадкова решта."""
    rng = np.random.default_rng(seed)
    hit = np.flatnonzero(y == 1)
    rest = np.flatnonzero(y == 0)
    keep = min(max(size - len(hit), 0), len(rest))
    return np.sort(np.concatenate([hit, rng.choice(rest, keep,
                                                   replace=False)]))


def run_umap(packs: dict, sample: np.ndarray, seed: int = SEED) -> dict:
    import umap

    flat = packs["x"][sample].astype(np.float64)
    mean, std = flat.mean(axis=0), flat.std(axis=0)
    std[std == 0] = 1.0
    started = time.time()
    coords = umap.UMAP(n_components=DIMS, n_neighbors=N_NEIGHBORS,
                       min_dist=MIN_DIST, metric=METRIC, random_state=seed,
                       verbose=False).fit_transform((flat - mean) / std)
    body = {"dims": DIMS, "metric": METRIC, "events": int(len(sample)),
            "packs": int(len(packs["y"])), "sample": int(len(sample)),
            "vector_size": int(flat.shape[1]),
            "params": {"n_components": DIMS, "n_neighbors": N_NEIGHBORS,
                       "min_dist": MIN_DIST, "metric": METRIC,
                       "random_state": seed},
            "seconds": round(time.time() - started, 1),
            "labels": list(LABELS), "stratified": True,
            "by_label": {str(one["id"]):
                         int((packs["y"][sample] == one["id"]).sum())
                         for one in LABELS}}
    coords = np.asarray(coords, dtype=float)
    for axis, name in enumerate(("x", "y", "z")[:DIMS]):
        body[name] = [round(float(value), 3) for value in coords[:, axis]]
    body["g"] = [int(value) for value in packs["y"][sample]]
    body["c"] = [int(value) for value in packs["coin"][sample]]
    body["t"] = [int(value) for value in packs["t"][sample]]
    body["part"] = [str(value) for value in packs["part"][sample]]
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lead", type=int, default=LEAD)
    parser.add_argument("--tail", type=int, default=TAIL)
    parser.add_argument("--sample", type=int, default=SAMPLE)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--no-umap", action="store_true")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    state = pivot.collect(args.data, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None, module=MODULE,
                          folder_name=CLASS)
    print("[пачки]")
    packs = collect_packs(state, args.lead, args.tail)
    print(f"      разом {len(packs['y'])}, розворотів "
          f"{int(packs['y'].sum())}, train "
          f"{int((packs['part'] == 'train').sum())}, val "
          f"{int((packs['part'] == 'val').sum())}")
    print("[моделі]")
    models = run_models(packs, args.seed)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "pack_net.json").write_text(json.dumps({
        "script": "research/22-leg-edge-spread/scripts/pack_net.py",
        "command": "python3 research/22-leg-edge-spread/scripts/pack_net.py",
        "class": CLASS, "class_title": "клас210х10-1х7д/д",
        "features": state["features"], "lead": args.lead, "tail": args.tail,
        "size": args.lead + args.tail, "scaler": "quantile",
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "by_coin": packs["by_coin"],
        "vector_size": int(packs["x"].shape[1]),
        "hidden": HIDDEN, "max_iter": MAX_ITER, "oversample": OVERSAMPLE,
        "seed": args.seed, "event_seconds": EVENT_LENGTH,
        "labels": list(LABELS), "models": models, "ready": True},
        ensure_ascii=False), encoding="utf-8")

    if not args.no_umap:
        print("[карта]")
        sample = sample_index(packs["y"], args.sample, args.seed)
        body = run_umap(packs, sample, args.seed)
        body.update({
            "script": "research/22-leg-edge-spread/scripts/pack_net.py",
            "command": "python3 research/22-leg-edge-spread/scripts/"
                       "pack_net.py",
            "class": CLASS, "class_title": "клас210х10-1х7д/д",
            "lead": args.lead, "tail": args.tail, "pairs": list(PAIRS),
            "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
            "event_seconds": EVENT_LENGTH, "ready": True})
        (args.out / "pack_umap.json").write_text(
            json.dumps(body, ensure_ascii=False), encoding="utf-8")
        print(f"      точок {body['events']}, розворотів "
              f"{body['by_label']['1']}, за {body['seconds']} с")
    print(f"записано {args.out}/pack_net.json")


if __name__ == "__main__":
    main()
