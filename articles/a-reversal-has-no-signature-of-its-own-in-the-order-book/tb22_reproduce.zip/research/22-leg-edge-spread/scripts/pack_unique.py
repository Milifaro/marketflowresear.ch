"""Чи є в пачці розвороту ознака, якої немає в жодній іншій десятці.

Дослідження: research/22-leg-edge-spread/
Правила: rules/01-data-and-db.md → Скейлери
         rules/03-models.md → Навчання моделей

Розділ 3 порівнював пачки одним числом — сумою модулів — і показав, що
сильніші десятки в датасеті є. Тут питання інше: **чи існує ознака, яку
має пачка розвороту і не має жодна інша десятка**.

## Що з чим порівнюється

Тільки `train` — усе до `CUT`, по всіх шести монетах.

| Набір | Що це | Скільки |
| ----- | ----- | ------- |
| `розворот` | сім подій до півота разом із ним і три після | по одній на півот |
| `решта` | десятки з кроком **в одну подію**, що не торкаються жодної зони | увесь ряд |

Пачка бере участь, тільки якщо десять подій ідуть підряд по `210` секунд
і в них немає `NaN`.

## Ознаки пачки

Подія зводиться до семи чисел на фічу (модуль по девʼяти блоках,
поділений на медіану звичайної десятки цієї монети — та сама база, що в
`pivot_zone.py`), плюс знакове середнє і крайні блоки. З десяти подій
рахуються `KINDS` ознак на кожну фічу і шість спільних:

| Ознака | Що міряє |
| ------ | -------- |
| `mag` | медіана сили по десяти подіях |
| `max` | найсильніша подія пачки |
| `turn` | перекіс: сім перших проти трьох останніх |
| `arg` | позиція найсильнішої події |
| `peak` | у скільки разів пік вищий за медіану |
| `trend` | нахил сили вздовж пачки |
| `flip` | зміна знака: середній знак перших семи проти трьох останніх |
| `edge` | останній блок події проти першого |
| `spread` | розкид між сімома фічами, порядків |
| `direct` | сума сили прямих фіч |
| `inverse` | сума сили зворотних відношень |
| `ratio` | пряме проти зворотного |
| `updown` | наскільки `d_up` і `d_down` різні |
| `swap` | зміна ролей `d_up` / `d_down` між початком і хвостом |

## Чим міряється унікальність

| Число | Що означає |
| ----- | ---------- |
| `auc` | загальний поділ |
| `alone` | скільки пачок розвороту лежать **за краєм усієї решти** |
| `direction` | де розворот у середньому: вище чи нижче решти |
| `prec_at_n` | точність у топ-`N`, де `N` — кількість розворотів |
| `recall_fp1` | скільки розворотів вище порога, що відсікає 99.9 % решти |
| `best` | найкраща точність при повноті не нижче `MIN_RECALL` |

`alone > 0` — це і є «лише в цих»: значення, якого немає в жодної іншої
десятки. Далі те саме перевіряється парами умов, моделлю на всіх
ознаках (перевірка з відкладеною монетою) і відстанню до найближчої
чужої пачки.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/pack_unique.json

Запуск:
    python3 research/22-leg-edge-spread/scripts/pack_unique.py
    python3 research/22-leg-edge-spread/scripts/pack_unique.py --no-model
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import pivot_zone  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = pivot_zone.CLASS
MODULE = pivot_zone.MODULE
LEAD, TAIL = pivot_zone.LEAD, pivot_zone.TAIL
SIZE = LEAD + TAIL
DIRECT = pivot_zone.DIRECT
SEED = 0
EPS = 1e-12
MIN_RECALL = 0.10          # повнота, нижче якої точність не рахується
PAIR_TOP = 40              # скільки одиночних умов іде в пари
GRID = (0.5, 0.7, 0.8, 0.9, 0.95, 0.99)   # квантилі розворотів на пороги
CURVE = (0.5, 0.25, 0.1, 0.05, 0.02, 0.01)  # повнота в кривій точності
CURVE_TOP = 5              # скільки ознак іде в криву
NEAR_SAMPLE = 60000        # решти в перевірці найближчого сусіда
KINDS = ("mag", "max", "turn", "arg", "peak", "trend", "flip", "edge")
SHARED = ("spread", "direct", "inverse", "ratio", "updown", "swap")
DIGITS = 4


def cell(value):
    value = float(value)
    if not np.isfinite(value):
        return None
    return round(value, DIGITS) if abs(value) < 1e6 else round(value, 1)


def windows_of(values: np.ndarray, starts: np.ndarray,
               size: int = SIZE) -> np.ndarray:
    """(P, F, size): пачки, взяті з ряду (N, F) за початками `starts`."""
    view = np.lib.stride_tricks.sliding_window_view(values, size, axis=0)
    return np.ascontiguousarray(view[starts], dtype=np.float64)


def slope(w: np.ndarray) -> np.ndarray:
    """Нахил прямої по десяти позиціях пачки."""
    step = np.arange(w.shape[-1], dtype=float)
    step -= step.mean()
    return (w * step).sum(axis=-1) / (step * step).sum()


def names_of(features: list) -> list:
    """Порядок ознак: KINDS на кожну фічу, далі спільні."""
    out = [f"{kind}_{name}" for kind in KINDS for name in features]
    return out + list(SHARED)


def pack_marks(mag: np.ndarray, sign: np.ndarray, first: np.ndarray,
               last: np.ndarray, features: list) -> np.ndarray:
    """(P, K) ознаки пачок з рядів події: сила, знак і крайні блоки."""
    head, tail = mag[:, :, :LEAD], mag[:, :, LEAD:]
    median = np.median(mag, axis=2)
    columns = [median,
               mag.max(axis=2),
               np.log10((head.mean(axis=2) + EPS) / (tail.mean(axis=2) + EPS)),
               mag.argmax(axis=2).astype(float),
               mag.max(axis=2) / (median + EPS),
               slope(mag) / (median + EPS),
               np.abs(np.sign(sign[:, :, :LEAD]).mean(axis=2)
                      - np.sign(sign[:, :, LEAD:]).mean(axis=2)),
               np.log10((last.mean(axis=2) + EPS) / (first.mean(axis=2) + EPS))]
    body = np.concatenate(columns, axis=1)

    direct = [index for index, name in enumerate(features) if name in DIRECT]
    other = [index for index in range(len(features)) if index not in direct]
    straight = median[:, direct].sum(axis=1)
    inverse = median[:, other].sum(axis=1)
    up, down = features.index("d_up"), features.index("d_down")
    role = np.log10((mag[:, up] + EPS) / (mag[:, down] + EPS))
    shared = np.stack([
        np.log10((median.max(axis=1) + EPS) / (median.min(axis=1) + EPS)),
        straight, inverse,
        np.log10((straight + EPS) / (inverse + EPS)),
        np.abs(role.mean(axis=1)),
        role[:, :LEAD].mean(axis=1) - role[:, LEAD:].mean(axis=1)], axis=1)
    return np.concatenate([body, shared], axis=1)


def coin_marks(coin: dict, features: list, lead: int = LEAD,
               tail: int = TAIL) -> dict:
    """Ознаки всіх пачок однієї монети на train."""
    size = lead + tail
    t, x = coin["t"], coin["x"]
    edge = stamp(CUT)
    zone = pivot_zone.zone_index(len(t), coin["pivots"], lead, tail)

    step = np.arange(0, len(t) - size + 1, size)
    plain = np.array([one for one in step if not zone[one:one + size].any()],
                     dtype=np.int64)
    plain = pivot_zone.clean_starts(x, t, plain, size)
    usual = np.concatenate([np.arange(one, one + size) for one in plain]) \
        if len(plain) else np.empty(0, dtype=np.int64)
    relative, base = pivot_zone.event_scale(x, usual)
    signed = x.mean(axis=1) / base
    first, last = np.abs(x[:, 0]) / base, np.abs(x[:, -1]) / base

    ready = pivot_zone.linked(t, size)
    finite = np.isfinite(x).all(axis=(1, 2))
    whole = np.lib.stride_tricks.sliding_window_view(
        finite, size, axis=0).all(axis=1)
    inside = np.lib.stride_tricks.sliding_window_view(
        t < edge, size, axis=0).all(axis=1)
    touched = np.lib.stride_tricks.sliding_window_view(
        zone, size, axis=0).any(axis=1)
    good = ready[size - 1:] & whole & inside

    hit = pivot_zone.zone_windows(len(t), coin["pivots"], lead, tail)
    hit = hit[good[hit]] if len(hit) else hit
    rest = np.flatnonzero(good & ~touched)

    starts = np.concatenate([hit, rest]).astype(np.int64)
    marks = pack_marks(windows_of(relative, starts, size),
                       windows_of(signed, starts, size),
                       windows_of(first, starts, size),
                       windows_of(last, starts, size), list(features))
    label = np.concatenate([np.ones(len(hit), dtype=np.int8),
                            np.zeros(len(rest), dtype=np.int8)])
    return {"pair": coin["pair"], "marks": marks.astype(np.float32),
            "y": label, "t": t[starts].astype(np.int64),
            "start": starts, "pivots": int(len(coin["pivots"]))}


def collect_marks(state: dict, lead: int = LEAD, tail: int = TAIL,
                  log=print) -> dict:
    """Ознаки пачок усіх монет одним набором."""
    coins = []
    for coin, pair in zip(state["coins"], PAIRS):
        coin["pair"] = pair
        body = coin_marks(coin, state["features"], lead, tail)
        coins.append(body)
        log(f"      {pair}: пачок {len(body['y'])}, розворотів "
            f"{int(body['y'].sum())}")
    return {"x": np.vstack([one["marks"] for one in coins]),
            "y": np.concatenate([one["y"] for one in coins]),
            "coin": np.concatenate([np.full(len(one["y"]), index, np.int16)
                                    for index, one in enumerate(coins)]),
            "t": np.concatenate([one["t"] for one in coins]),
            "names": names_of(list(state["features"])),
            "by_coin": [{"pair": one["pair"], "packs": int(len(one["y"])),
                         "reversal": int(one["y"].sum())} for one in coins]}


def alone_count(hit: np.ndarray, rest: np.ndarray) -> tuple:
    """Скільки розворотів лежать за краєм усієї решти й з якого боку.

    Бік тут — це бік **викиду**, а не бік середнього: він каже, у якому
    хвості стоять поодинокі пачки. Напрямок самої ознаки — `direction`.
    """
    top = int((hit > np.nanmax(rest)).sum())
    low = int((hit < np.nanmin(rest)).sum())
    return (top, "вище") if top >= low else (low, "нижче")


def best_cut(hit: np.ndarray, rest: np.ndarray, sign: int,
             grid=GRID, least: float = MIN_RECALL) -> dict:
    """Найкраща точність при повноті не нижче `least` серед порогів `grid`."""
    best = {}
    for level in grid:
        edge = np.quantile(sign * hit, 1.0 - level)
        taken = int((sign * hit >= edge).sum())
        false = int((sign * rest >= edge).sum())
        recall = taken / max(len(hit), 1)
        if recall < least:
            continue
        precision = taken / max(taken + false, 1)
        if not best or precision > best["precision"]:
            best = {"recall": cell(recall), "precision": cell(precision),
                    "taken": taken, "false": false, "quantile": level}
    return best


def score_one(hit: np.ndarray, rest: np.ndarray, name: str,
              seed: int = SEED) -> dict:
    """Усі міри унікальності для одного числа.

    Розвороти стоять у наборі першими, а `arg` і `flip` беруть мало
    різних значень, тому рівні значення перемішуються: інакше топ-`N`
    діставався б розворотам просто за порядком у масиві.
    """
    from sklearn.metrics import roc_auc_score

    finite = np.isfinite(hit)
    hit, rest = hit[finite], rest[np.isfinite(rest)]
    if not len(hit) or not len(rest):
        return {"mark": name}
    y = np.concatenate([np.ones(len(hit)), np.zeros(len(rest))])
    value = np.concatenate([hit, rest])
    auc = float(roc_auc_score(y, value))
    sign = 1 if auc >= 0.5 else -1
    count, side = alone_count(hit, rest)
    mix = np.random.default_rng(seed).permutation(len(value))
    y, value = y[mix], value[mix]
    order = np.argsort(-sign * value, kind="stable")[:len(hit)]
    edge = np.quantile(sign * rest, 0.999)
    taken = int((sign * hit >= edge).sum())
    return {"mark": name, "auc": cell(max(auc, 1 - auc)),
            "direction": "вище" if sign > 0 else "нижче", "side": side,
            "alone": count, "alone_share": cell(count / len(hit)),
            "prec_at_n": cell(float(y[order].mean())),
            "recall_fp1": cell(taken / len(hit)),
            "median_hit": cell(np.median(hit)),
            "median_rest": cell(np.median(rest)),
            "best": best_cut(hit, rest, sign)}


def score_marks(packs: dict, log=print) -> list:
    """Таблиця ознак, відсортована за точністю в топ-N."""
    hit = packs["y"] == 1
    out = [score_one(packs["x"][hit, index], packs["x"][~hit, index], name)
           for index, name in enumerate(packs["names"])]
    out = [one for one in out if "auc" in one]
    out.sort(key=lambda one: (-one["prec_at_n"], -one["auc"]))
    for one in out[:8]:
        log(f"      {one['mark']:<20} AUC {one['auc']:.3f}  "
            f"топ-N {one['prec_at_n']:.3f}  сама {one['alone']}")
    return out


def curve_of(packs: dict, table: list, top: int = CURVE_TOP,
             grid=CURVE) -> list:
    """Точність при дедалі жорсткішому порозі: чи чистішає хвіст.

    Якщо розворот справді інший, то чим далі поріг, тим менше чужих
    пачок за ним. Якщо ж хвіст решти такий самий, точність стоїть на
    місці — і різниця між наборами лише в зсуві, а не в межі.
    """
    index = {name: number for number, name in enumerate(packs["names"])}
    hit = packs["y"] == 1
    out = []
    for one in table[:top]:
        column = packs["x"][:, index[one["mark"]]]
        sign = 1 if one["direction"] == "вище" else -1
        row = {"mark": one["mark"], "direction": one["direction"],
               "steps": []}
        for level in grid:
            edge = float(np.quantile(sign * column[hit], 1.0 - level))
            taken = int((sign * column[hit] >= edge).sum())
            false = int((sign * column[~hit] >= edge).sum())
            row["steps"].append({
                "recall": cell(level), "taken": taken, "false": false,
                "precision": cell(taken / max(taken + false, 1)),
                "lift": cell((taken / max(taken + false, 1))
                             / max(float(hit.mean()), EPS))})
        out.append(row)
    return out


def loner(packs: dict, table: list) -> list:
    """Пачки, що вийшли за край решти хоч однією ознакою."""
    index = {name: number for number, name in enumerate(packs["names"])}
    hit = np.flatnonzero(packs["y"] == 1)
    found = {}
    for one in table:
        if not one["alone"]:
            continue
        column = packs["x"][:, index[one["mark"]]]
        rest = column[packs["y"] == 0]
        rest = rest[np.isfinite(rest)]
        side = 1 if one["side"] == "вище" else -1
        limit = np.nanmax(side * rest)
        for place in hit[side * column[hit] > limit]:
            key = int(packs["t"][place])
            body = found.setdefault(key, {"t": key, "marks": [],
                                          "coin": int(packs["coin"][place])})
            body["marks"].append(one["mark"])
    out = sorted(found.values(), key=lambda one: -len(one["marks"]))
    for one in out:
        one["pair"] = PAIRS[one["coin"]]
        one["utc"] = time.strftime("%Y-%m-%d %H:%M:%S",
                                   time.gmtime(one["t"]))
    return out


def conditions(packs: dict, table: list, top: int = PAIR_TOP,
               grid=GRID) -> list:
    """Булеві умови «ознака за порогом» з найкращих одиночних ознак."""
    index = {name: number for number, name in enumerate(packs["names"])}
    hit = packs["y"] == 1
    out = []
    for one in table[:top]:
        column = packs["x"][:, index[one["mark"]]]
        sign = 1 if one["direction"] == "вище" else -1
        for level in grid:
            edge = float(np.quantile(sign * column[hit], 1.0 - level))
            mask = sign * column >= edge
            if not mask[hit].any():
                continue
            out.append({"mark": one["mark"], "sign": sign, "edge": edge,
                        "level": level, "mask": mask})
    return out


def pairs_of(packs: dict, rules: list, least: float = MIN_RECALL) -> list:
    """Найточніші пари умов: обидві виконані разом."""
    hit = packs["y"] == 1
    total = int(hit.sum())
    out = []
    for left in range(len(rules)):
        for right in range(left + 1, len(rules)):
            if rules[left]["mark"] == rules[right]["mark"]:
                continue
            mask = rules[left]["mask"] & rules[right]["mask"]
            taken = int(mask[hit].sum())
            recall = taken / max(total, 1)
            if recall < least:
                continue
            false = int(mask[~hit].sum())
            out.append({"left": f"{rules[left]['mark']}"
                                f"{'≥' if rules[left]['sign'] > 0 else '≤'}"
                                f"{cell(rules[left]['sign'] * rules[left]['edge'])}",
                        "right": f"{rules[right]['mark']}"
                                 f"{'≥' if rules[right]['sign'] > 0 else '≤'}"
                                 f"{cell(rules[right]['sign'] * rules[right]['edge'])}",
                        "recall": cell(recall), "taken": taken,
                        "false": false,
                        "precision": cell(taken / max(taken + false, 1))})
    out.sort(key=lambda one: (-one["precision"], -one["recall"]))
    return out[:12]


def run_model(packs: dict, seed: int = SEED, log=print) -> dict:
    """Дерева на всіх ознаках: перевірка з відкладеною монетою."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import average_precision_score, roc_auc_score

    x, y, coin = packs["x"], packs["y"], packs["coin"]
    score = np.full(len(y), np.nan)
    started = time.time()
    for number in np.unique(coin):
        out = coin == number
        model = HistGradientBoostingClassifier(
            max_iter=200, learning_rate=0.1, max_leaf_nodes=31,
            class_weight="balanced", random_state=seed)
        model.fit(np.nan_to_num(x[~out], nan=0.0, posinf=0.0, neginf=0.0),
                  y[~out])
        score[out] = model.predict_proba(
            np.nan_to_num(x[out], nan=0.0, posinf=0.0, neginf=0.0))[:, 1]
    body = score_one(score[y == 1], score[y == 0], "модель")
    body.update({"auc": cell(roc_auc_score(y, score)),
                 "ap": cell(average_precision_score(y, score)),
                 "base": cell(y.mean()), "packs": int(len(y)),
                 "reversal": int(y.sum()),
                 "seconds": round(time.time() - started, 1)})
    log(f"      відкладена монета: AUC {body['auc']}, AP {body['ap']}, "
        f"топ-N {body['prec_at_n']}, сама {body['alone']}")
    return body


def nearest(packs: dict, sample: int = NEAR_SAMPLE, seed: int = SEED,
            log=print) -> dict:
    """Чи є пачка розвороту в порожньому місці: сусід свій проти чужого."""
    from sklearn.neighbors import NearestNeighbors

    x = np.nan_to_num(packs["x"], nan=0.0, posinf=0.0, neginf=0.0)
    x = (x - x.mean(axis=0)) / np.where(x.std(axis=0) > 0, x.std(axis=0), 1.0)
    hit = packs["y"] == 1
    rng = np.random.default_rng(seed)
    rest = np.flatnonzero(~hit)
    rest = rng.choice(rest, min(sample, len(rest)), replace=False)
    own = NearestNeighbors(n_neighbors=2).fit(x[hit])
    other = NearestNeighbors(n_neighbors=1).fit(x[rest])
    mine = own.kneighbors(x[hit])[0][:, 1]
    alien = other.kneighbors(x[hit])[0][:, 0]
    body = {"sample": int(len(rest)), "reversal": int(hit.sum()),
            "own_median": cell(np.median(mine)),
            "alien_median": cell(np.median(alien)),
            "alone": int((alien > mine).sum()),
            "alone_share": cell(float((alien > mine).mean()))}
    log(f"      свій сусід {body['own_median']}, чужий {body['alien_median']},"
        f" без чужого поруч {body['alone']}")
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lead", type=int, default=LEAD)
    parser.add_argument("--tail", type=int, default=TAIL)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--no-model", action="store_true")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    state = pivot.collect(args.data, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None, module=MODULE,
                          folder_name=CLASS)
    print("[пачки train]")
    packs = collect_marks(state, args.lead, args.tail)
    print(f"      разом {len(packs['y'])}, розворотів "
          f"{int(packs['y'].sum())}, ознак {len(packs['names'])}")
    print("[ознаки]")
    table = score_marks(packs)
    print("[крива порога]")
    curve = curve_of(packs, table)
    for one in curve[:2]:
        line = "  ".join(f"{step['recall']}->{step['precision']}"
                         for step in one["steps"])
        print(f"      {one['mark']}: {line}")
    alone = loner(packs, table)
    print(f"[за краєм решти] пачок {len(alone)}")
    for one in alone[:3]:
        print(f"      {one['pair']} {one['utc']}: {len(one['marks'])} ознак")
    print("[пари умов]")
    duo = pairs_of(packs, conditions(packs, table))
    for one in duo[:5]:
        print(f"      {one['left']} і {one['right']}: точність "
              f"{one['precision']}, повнота {one['recall']}, "
              f"чужих {one['false']}")
    model = {}
    near = {}
    if not args.no_model:
        print("[модель]")
        model = run_model(packs, args.seed)
        print("[сусід]")
        near = nearest(packs, seed=args.seed)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "pack_unique.json").write_text(json.dumps({
        "script": "research/22-leg-edge-spread/scripts/pack_unique.py",
        "command": "python3 research/22-leg-edge-spread/scripts/pack_unique.py",
        "class": CLASS, "class_title": "клас210х10-1х7д/д",
        "features": state["features"], "lead": args.lead, "tail": args.tail,
        "size": args.lead + args.tail, "part": "train",
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "by_coin": packs["by_coin"],
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "event_seconds": EVENT_LENGTH, "seed": args.seed,
        "packs": int(len(packs["y"])), "reversal": int(packs["y"].sum()),
        "marks": packs["names"], "kinds": list(KINDS), "shared": list(SHARED),
        "grid": list(GRID), "curve_grid": list(CURVE),
        "min_recall": MIN_RECALL,
        "table": table, "curve": curve, "alone": alone, "pairs_table": duo, "model": model, "nearest": near,
        "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/pack_unique.json")


if __name__ == "__main__":
    main()
