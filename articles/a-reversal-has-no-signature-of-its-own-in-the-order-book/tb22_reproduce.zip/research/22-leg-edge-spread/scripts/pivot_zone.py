"""Зона півота: скільки в ній подій, як вона виглядає і чи вона сильна.

Дослідження: research/22-leg-edge-spread/
Правила: rules/02-markup.md → зігзаг
         rules/05-visualization.md → Обовʼязкова компоновка

Розділ 3 бере **пачку розвороту** — сім подій до півота разом з ним і
три після, десять подій підряд — і питає три речі:

1. Скільки таких подій у датасеті і яка це частка класу.
2. Як вони виглядають на ряду монети: ціна з зігзагом і зона поверх,
   train і val на одному полотні.
3. Чи є в датасеті десятки подій **сильніші** за зону розвороту.

## Показник пачки

Фічі класу — відношення похідних, тому беруться **модулі**, і десять
подій складаються **позиція в позицію**:

    A(пачка)[блок, фіча] = Σ |x[подія, блок, фіча]|   по десяти подіях

Це матриця 9 × 7 на кожну пачку. Її сума по всіх клітинках — `total`,
сума по блоках однієї фічі — показник цієї фічі.

Фічі не обмежені: коли знаменник майже нульовий, значення велике, і
**середнє по пачках злітає на одному викиді** (у `step` воно доходить до
`1e19`). Тому поруч із середнім скрізь стоїть **медіана**, і саме вона
береться за точку відліку в порівняннях.

Пачка бере участь, тільки якщо всі десять подій ідуть підряд (`210`
секунд між сусідніми) і в них немає жодного `NaN`: інакше сума
рахувалася б по різній кількості чисел.

## Теплові карти

Щоб три набори пачок можна було покласти на **одну шкалу**, значення
беруться не сирі, а **відносні**: модуль події по фічі ділиться на
медіану цієї ж фічі по всьому ряду монети.

    v[подія, фіча] = mean(|x[подія, блок, фіча]|) / база[фіча]

База — медіана `mean|x|` по подіях **звичайних десяток**: тих, що не
торкаються зони розвороту і йдуть без `NaN`. Тому карта `rest` стоїть на
`1.0` за побудовою, а `1.0` скрізь означає «як у звичайній десятці цієї
монети»; `3.0` — утричі сильніше. Так сім фіч різного масштабу стають
порівнюваними між собою, а монети — між собою.

Карта — це **10 позицій пачки × 7 фіч**: у клітинці медіана `v` по всіх
пачках набору. Карт три, шкала в них спільна:

| Карта | Пачки |
| ----- | ----- |
| `reversal` | пачки розвороту |
| `rest` | десятки поза зоною розвороту, без перекриття |
| `top` | найсильніші з них — верхній `TOP_SHARE` за сумою `v` по всіх фічах |
| `top_direct` | найсильніші за сумою `v` по **прямих** фічах: `d_up`, `d_down`, `d_price_avg` |

Дві карти найсильніших потрібні тому, що сума по всіх семи фічах тягнеться
зворотними відношеннями, а вони в зоні розвороту якраз **менші**. Пряма
трійка — це те, чим розворот себе показує, тому «сильніші за розворот»
шукається і в ній.

## З чим порівнюється

| Набір пачок | Що це |
| ----------- | ----- |
| `pivot` | пачки розвороту: сім подій до півота (з ним) і три після |
| `step` | увесь ряд, нарізаний підряд по десять подій без перекриття |
| `scan` | ряд пачками по десять подій із кроком в одну подію |

`scan` відповідає на головне питання розділу: скільки у датасеті пачок,
у яких сума модулів більша, ніж у **медіанної** пачки розвороту, і на
якому місці зона розвороту стоїть серед усіх пачок датасету.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
       ема й півоти — leg_deciles.py
Вихід: results/pivot_zone.json      — числа розділу
       results/zone_<PAIR>.json     — ряд монети для графіка

Запуск:
    python3 research/22-leg-edge-spread/scripts/pivot_zone.py
    python3 research/22-leg-edge-spread/scripts/pivot_zone.py --lead 7 --tail 3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))

import class210x10m1x7dd  # noqa: E402
import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
MODULE = class210x10m1x7dd
LEAD = 7                   # подій до півота, разом із самим півотом
TAIL = 3                   # подій після півота
WIDTHS = (2, 3, 5, 10, 20)  # зони ±k для таблиці «скільки подій»
POINTS = 12000             # точок на монету в графіку
TOP_SHARE = 0.01           # яку частку найсильніших пачок брати в `top`
# Прямі фічі: у зоні розвороту вони більші, а не менші.
DIRECT = ("d_up", "d_down", "d_price_avg")
DIGITS = 6


def cell(value):
    value = float(value)
    if not np.isfinite(value):
        return None
    return round(value, DIGITS) if abs(value) < 1e6 else round(value, 1)


def linked(t: np.ndarray, size: int) -> np.ndarray:
    """(N,) bool: подія закінчує `size` подій підряд по 210 секунд."""
    return pivot.batch_ready(t, size)


def window_starts(t: np.ndarray, size: int) -> np.ndarray:
    """Індекси перших подій усіх суцільних пачок довжини `size`."""
    ready = linked(t, size)
    return np.flatnonzero(ready) - (size - 1)


def parts_of(t: np.ndarray) -> np.ndarray:
    """train / val / поза межами — за датою події."""
    edge, right = stamp(CUT), stamp(END)
    return np.where(t < edge, "train",
                    np.where(t < right, "val", "поза"))


def zone_index(count: int, pivots, lead: int, tail: int) -> np.ndarray:
    """(N,) bool: подія лежить у пачці розвороту хоч одного півота."""
    mask = np.zeros(count, dtype=bool)
    for point in pivots:
        low = max(0, point.index - lead + 1)
        high = min(count, point.index + tail + 1)
        mask[low:high] = True
    return mask


def zone_windows(count: int, pivots, lead: int, tail: int) -> np.ndarray:
    """Перші події пачок розвороту: по одному на півот."""
    starts = np.array([point.index - lead + 1 for point in pivots],
                      dtype=np.int64)
    return starts[(starts >= 0) & (starts + lead + tail <= count)]


def sums_of(x: np.ndarray) -> tuple:
    """Модулі події: сума по всіх клітинках і сума по кожній фічі."""
    values = np.abs(x)
    return values.sum(axis=(1, 2)), values.sum(axis=1)


def rolling(values: np.ndarray, size: int) -> np.ndarray:
    """Сума пачки довжини `size`, індекс — перша подія пачки.

    Сума йде через накопичену суму, а вона від одного `NaN` псує весь
    хвіст ряду. Тому `NaN` тут замінюється нулем: пачки, у яких він є,
    однаково відкидаються окремою маскою.
    """
    if len(values) < size:
        return np.empty((0,) + values.shape[1:])
    cumulative = np.cumsum(np.nan_to_num(values, nan=0.0), axis=0)
    out = cumulative[size - 1:].copy()
    out[1:] -= cumulative[:-size]
    return out


def matrix_of(x: np.ndarray, starts: np.ndarray, size: int) -> dict:
    """Матриця 9 × 7: модулі, складені позиція в позицію.

    Середнє й медіана: у відношень похідних важкі хвости, і середнє по
    пачках тримає один викид, а медіана — ні.
    """
    if not len(starts):
        empty = np.full(x.shape[1:], np.nan).tolist()
        return {"mean": empty, "median": empty}
    stack = np.stack([np.abs(x[one:one + size]).sum(axis=0)
                      for one in starts])
    return {"mean": stack.mean(axis=0).tolist(),
            "median": np.median(stack, axis=0).tolist()}


def clean_starts(x: np.ndarray, t: np.ndarray, starts: np.ndarray,
                 size: int) -> np.ndarray:
    """Пачки, у яких події йдуть підряд і немає жодного NaN."""
    if not len(starts):
        return starts
    ready = linked(t, size)
    good = []
    for one in starts:
        if one < 0 or one + size > len(x):
            continue
        if not ready[one + size - 1]:
            continue
        if not np.isfinite(x[one:one + size]).all():
            continue
        good.append(one)
    return np.array(good, dtype=np.int64)


def event_scale(x: np.ndarray, index: np.ndarray | None = None) -> tuple:
    """Модуль події по фічі й база, якою він нормується.

    `mean(|x|)` по девʼяти блоках — одне число на подію й фічу. База —
    медіана цього числа по подіях `index` (звичайні десятки); без
    `index` — по всьому ряду.
    """
    values = np.abs(x).mean(axis=1)
    picked = values if index is None or not len(index) else values[index]
    with np.errstate(invalid="ignore"):
        base = np.nanmedian(picked, axis=0)
    base = np.where(np.isfinite(base) & (base > 0), base, 1.0)
    return values / base, base


def heat_of(relative: np.ndarray, starts: np.ndarray, size: int) -> list:
    """Карта 10 × 7: медіана відносного модуля по пачках набору."""
    if not len(starts):
        return [[None] * relative.shape[1] for _ in range(size)]
    stack = np.stack([relative[one:one + size] for one in starts])
    with np.errstate(invalid="ignore"):
        found = np.nanmedian(stack, axis=0)
    return [[cell(value) for value in row] for row in found]


def window_score(relative: np.ndarray, starts: np.ndarray, size: int,
                 columns=None) -> np.ndarray:
    """Сума відносних модулів пачки; `columns` звужує до частини фіч."""
    picked = relative if columns is None else relative[:, columns]
    return np.array([np.nansum(picked[one:one + size]) for one in starts])


def top_starts(relative: np.ndarray, starts: np.ndarray, size: int,
               share: float = TOP_SHARE, columns=None) -> np.ndarray:
    """Найсильніші пачки набору за сумою відносних модулів."""
    if not len(starts):
        return starts
    score = window_score(relative, starts, size, columns)
    order = np.argsort(score)[::-1]
    count = max(1, int(round(len(starts) * share)))
    return starts[order[:count]]


def spread_mask(count: int, starts: np.ndarray, size: int) -> np.ndarray:
    """(N,) bool: подія входить хоч в одну пачку з `starts`."""
    mask = np.zeros(count, dtype=bool)
    for one in starts:
        mask[one:one + size] = True
    return mask


def coin_series(coin: dict, mask: np.ndarray, points: int = POINTS,
                top: np.ndarray | None = None,
                over: np.ndarray | None = None) -> dict:
    """Ряд монети для графіка: ема, зігзаг, три мітки й межа train | val.

    Мітки: `zone` — пачка розвороту, `top` — найсильніші пачки поза
    зоною, `over` — пачки, сильніші за медіанну пачку розвороту.
    """
    count = len(coin["t"])
    step = max(1, count // points)
    top = np.zeros(count, dtype=bool) if top is None else top
    over = np.zeros(count, dtype=bool) if over is None else over
    # усі три мітки лишаються повністю: вісь X — номер збереженої точки,
    # тому мітка, яку проріджують, виглядала б вужчою за ту, яку ні
    marks = np.flatnonzero(mask | top | over)
    pivots = np.array([one.index for one in coin["pivots"]], dtype=np.int64)
    keep = np.union1d(np.union1d(np.arange(0, count, step), pivots), marks)
    return {
        "pair": coin["pair"], "events": int(len(keep)),
        "full_events": int(count), "step": int(step),
        "t": [int(one) for one in coin["t"][keep]],
        "price": [cell(one) for one in coin["ema"][keep]],
        "zone": [int(one) for one in mask[keep]],
        "top": [int(one) for one in top[keep]],
        "over": [int(one) for one in over[keep]],
        "top_events": int(top.sum()), "over_events": int(over.sum()),
        "cut": int(stamp(CUT)),
        "pivots": [{"t": int(coin["t"][one.index]),
                    "ema": cell(coin["ema"][one.index]), "kind": one.kind}
                   for one in coin["pivots"]],
        "zone_events": int(mask.sum()),
    }


def one_coin(coin: dict, lead: int, tail: int, widths=WIDTHS,
             features=None) -> dict:
    """Числа однієї монети: скільки подій у зонах і сила пачок."""
    size = lead + tail
    features = list(features if features is not None else MODULE.FEATURES)
    t, x = coin["t"], coin["x"]
    part = parts_of(t)
    total, by_feature = sums_of(x)

    counts = {}
    for width in widths:
        mask = zone_index(len(t), coin["pivots"], width + 1, width)
        counts[width] = {name: int((mask & (part == name)).sum())
                         for name in ("train", "val")}
        counts[width]["events"] = int(mask.sum())

    zone = zone_index(len(t), coin["pivots"], lead, tail)
    step_starts = np.arange(0, len(t) - size + 1, size)
    outside = np.array([one for one in step_starts
                        if not zone[one:one + size].any()], dtype=np.int64)
    starts = {"pivot": clean_starts(x, t, zone_windows(len(t), coin["pivots"],
                                                      lead, tail), size),
              "step": clean_starts(x, t, step_starts, size),
              "rest": clean_starts(x, t, outside, size)}
    usual = np.concatenate([np.arange(one, one + size)
                            for one in starts["rest"]]) \
        if len(starts["rest"]) else np.empty(0, dtype=np.int64)
    relative, base = event_scale(x, usual)
    direct = [index for index, name in enumerate(features) if name in DIRECT]
    if not direct:                     # клас без прямих фіч — беремо всі
        direct = list(range(x.shape[2]))
    top = top_starts(relative, starts["rest"], size)
    top_direct = top_starts(relative, starts["rest"], size, columns=direct)
    scan = window_starts(t, size)
    scan = scan[scan >= 0]
    scan_total = rolling(total, size)
    scan_feature = rolling(by_feature, size)
    keep = linked(t, size)[size - 1:]
    finite = rolling(np.isfinite(x).all(axis=(1, 2)).astype(int), size) == size
    good = keep & finite.ravel()

    body = {"pair": coin["pair"], "counts": counts,
            "events": {"all": int(len(t)),
                       **{name: int((part == name).sum())
                          for name in ("train", "val")}},
            "pivots": len(coin["pivots"]),
            "windows": {name: int(len(one)) for name, one in starts.items()},
            "matrix": {name: matrix_of(x, one, size)
                       for name, one in starts.items()},
            "score": {},
            "heat": {"reversal": heat_of(relative, starts["pivot"], size),
                     "rest": heat_of(relative, starts["rest"], size),
                     "top": heat_of(relative, top, size),
                     "top_direct": heat_of(relative, top_direct, size)},
            "heat_windows": {"reversal": int(len(starts["pivot"])),
                             "rest": int(len(starts["rest"])),
                             "top": int(len(top)),
                             "top_direct": int(len(top_direct))},
            "direct": [features[index] for index in direct],
            "top_starts": top_direct.tolist(),
            "base_events": int(len(usual)),
            "base": [float(value) for value in base]}
    for name, one in starts.items():
        if name == "rest":
            continue
        if not len(one):
            body["score"][name] = None
            continue
        totals = np.array([total[item:item + size].sum() for item in one])
        columns = np.array([by_feature[item:item + size].sum(axis=0)
                            for item in one])
        body["score"][name] = {
            "mean_total": float(totals.mean()),
            "median_total": float(np.median(totals)),
            "mean_by_feature": [float(value) for value in columns.mean(axis=0)],
            "median_by_feature": [float(value) for value in
                                  np.median(columns, axis=0)]}
    reference = body["score"]["pivot"]
    scored = scan_total[good]
    columns = scan_feature[good]
    body["scan"] = {"windows": int(good.sum())}
    if reference is not None and len(scored):
        for name, edge in (("mean", reference["mean_total"]),
                           ("median", reference["median_total"])):
            body["scan"][f"over_{name}"] = int((scored > edge).sum())
            body["scan"][f"share_{name}"] = float((scored > edge).mean())
        # чи є непереривні десятки, сильніші за пачку розвороту, у
        # відносних одиницях — тих самих, що на теплових картах
        zone_scan = rolling(zone.astype(int), size)[good] > 0
        for name, chosen in (("relative", None), ("direct", direct)):
            picked = relative if chosen is None else relative[:, chosen]
            scanned = rolling(np.nansum(picked, axis=1), size)[good]
            pivot_score = window_score(relative, starts["pivot"], size,
                                       chosen)
            if not len(pivot_score):
                continue
            edge_score = float(np.median(pivot_score))
            free = scanned[~zone_scan]
            if name == "direct":     # мітки для графіка: сильні пачки
                places = np.flatnonzero(good)
                strong = places[(~zone_scan) & (scanned > edge_score)]
                body["strong"] = strong.tolist()
            body["scan"][name] = {
                "windows": int(len(free)),
                "pivot_median": edge_score,
                "over": int((free > edge_score).sum()),
                "share": float((free > edge_score).mean()) if len(free)
                else None,
                "best": float(free.max()) if len(free) else None,
                "pivot_best": float(pivot_score.max())}
        body["scan"]["by_feature"] = [
            {"over": int((columns[:, index]
                          > reference["median_by_feature"][index]).sum()),
             "share": float((columns[:, index]
                             > reference["median_by_feature"][index]).mean())}
            for index in range(by_feature.shape[1])]
        # де стоять сильніші пачки: відстань від їх середини до півота
        places = np.flatnonzero(good) + size // 2
        strong = places[scored > reference["median_total"]]
        pivots = np.array([one.index for one in coin["pivots"]])
        if len(strong) and len(pivots):
            near = np.abs(strong[:, None] - pivots[None, :]).min(axis=1)
            body["scan"]["near_pivot"] = {
                "median": float(np.median(near)),
                "inside": int((near <= max(lead, tail)).sum()),
                "share_inside": float((near <= max(lead, tail)).mean())}
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lead", type=int, default=LEAD)
    parser.add_argument("--tail", type=int, default=TAIL)
    parser.add_argument("--points", type=int, default=POINTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    size = args.lead + args.tail
    state = pivot.collect(args.data, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None, module=MODULE,
                          folder_name=CLASS)
    args.out.mkdir(parents=True, exist_ok=True)
    coins = []
    for coin, pair in zip(state["coins"], PAIRS):
        coin["pair"] = pair
        coin["ema"] = leg_deciles.build_pair(pair, args.data,
                                             leg_deciles.PERIOD,
                                             leg_deciles.THRESHOLD)["ema"]
        body = one_coin(coin, args.lead, args.tail,
                        features=state["features"])
        count = len(coin["t"])
        mask = zone_index(count, coin["pivots"], args.lead, args.tail)
        top = spread_mask(count, np.array(body.pop("top_starts"), dtype=int),
                          size)
        over = spread_mask(count, np.array(body.pop("strong", []), dtype=int),
                           size)
        series = coin_series(coin, mask, args.points, top, over)
        (args.out / f"zone_{pair}.json").write_text(
            json.dumps({**series, "lead": args.lead, "tail": args.tail,
                        "top_share": TOP_SHARE, "direct": list(DIRECT),
                        "threshold": leg_deciles.THRESHOLD,
                        "period": leg_deciles.PERIOD,
                        "event_seconds": EVENT_LENGTH, "ready": True},
                       ensure_ascii=False), encoding="utf-8")
        body["series"] = {"points": series["events"], "step": series["step"]}
        coins.append(body)
        found = body["scan"].get("relative", {})
        straight = body["scan"].get("direct", {})
        print(f"[{pair}] подій {body['events']['all']}, півотів "
              f"{body['pivots']}, пачок розвороту "
              f"{body['windows']['pivot']}, поза зоною "
              f"{body['windows']['rest']}; сильніших: усіма фічами "
              f"{found.get('over')} ({100 * (found.get('share') or 0):.1f} %), "
              f"прямими {straight.get('over')} "
              f"({100 * (straight.get('share') or 0):.2f} %)")

    totals = {"events": sum(one["events"]["all"] for one in coins),
              "train": sum(one["events"]["train"] for one in coins),
              "val": sum(one["events"]["val"] for one in coins),
              "pivots": sum(one["pivots"] for one in coins),
              "windows": {name: sum(one["windows"][name] for one in coins)
                          for name in ("pivot", "step", "rest")},
              "scan": {"windows": sum(one["scan"]["windows"]
                                      for one in coins),
                       "over_mean": sum(one["scan"].get("over_mean", 0)
                                        for one in coins),
                       "over_median": sum(one["scan"].get("over_median", 0)
                                          for one in coins),
                       "relative": {
                           "windows": sum(one["scan"].get("relative", {})
                                          .get("windows", 0) for one in coins),
                           "over": sum(one["scan"].get("relative", {})
                                       .get("over", 0) for one in coins)},
                       "direct": {
                           "windows": sum(one["scan"].get("direct", {})
                                          .get("windows", 0) for one in coins),
                           "over": sum(one["scan"].get("direct", {})
                                       .get("over", 0) for one in coins)}}}
    for name in ("relative", "direct"):
        body = totals["scan"][name]
        body["share"] = (body["over"] / body["windows"] if body["windows"]
                         else None)
    free = totals["scan"]["relative"]
    for name in ("mean", "median"):
        totals["scan"][f"share_{name}"] = (
            totals["scan"][f"over_{name}"] / totals["scan"]["windows"]
            if totals["scan"]["windows"] else None)
    zones = []
    for width in WIDTHS:
        body = {"width": width, "per_pivot": 2 * width + 1}
        for name in ("events", "train", "val"):
            body[name] = sum(one["counts"][width][name] for one in coins)
        body["share"] = body["events"] / totals["events"]
        zones.append(body)

    (args.out / "pivot_zone.json").write_text(json.dumps({
        "script": "research/22-leg-edge-spread/scripts/pivot_zone.py",
        "command": "python3 research/22-leg-edge-spread/scripts/"
                   "pivot_zone.py",
        "class": CLASS, "class_title": "клас210х10-1х7д/д",
        "features": state["features"], "blocks": state["coins"][0]["x"].shape[1],
        "lead": args.lead, "tail": args.tail, "size": size,
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "widths": list(WIDTHS), "zones": zones,
        "top_share": TOP_SHARE,
        "heats": [{"id": "reversal", "name": "пачки розвороту"},
                  {"id": "rest", "name": "десятки поза зоною"},
                  {"id": "top", "name": "найсильніші: усі фічі"},
                  {"id": "top_direct", "name": "найсильніші: прямі фічі"}],
        "direct": list(DIRECT),
        "totals": totals, "coins": coins, "points": args.points,
        "event_seconds": EVENT_LENGTH, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    straight = totals["scan"]["direct"]
    print(f"пачок розвороту {totals['windows']['pivot']}; сильніших за нього "
          f"десяток поза зоною: усіма фічами {free['over']} з "
          f"{free['windows']} ({100 * (free['share'] or 0):.2f} %), "
          f"прямими {straight['over']} "
          f"({100 * (straight['share'] or 0):.2f} %)")


if __name__ == "__main__":
    main()
