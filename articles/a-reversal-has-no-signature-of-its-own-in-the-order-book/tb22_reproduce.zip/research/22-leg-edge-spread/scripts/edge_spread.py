"""Розкид фіч на краях ноги: скільки подій брати з початку й з кінця.

Дослідження: research/22-leg-edge-spread/
Правила: rules/02-markup.md → зігзаг
         rules/05-visualization.md → Кольори

На ході по нозі сім фіч `клас210х10-1х7д/д` розходяться саме біля
півотів, а в середині ноги злипаються. Тут це міряється числом і
шукається довжина краю, на якій розкид ще великий.

## Розкид

    ранг(подія, колонка) — ранг значення колонки серед подій своєї ноги,
                           приведений до [0, 1]
    r(фіча, край)        — середній ранг фічі по подіях краю
    розкид(край)         = max(r) − min(r)   по семи фічах однієї згортки

Ранг усередині ноги прибирає монету, режим і масштаб фічі. `0` — усі сім
фіч стоять в одному місці ноги, `1` — розведені по краях.

Міра рахується **на кожній нозі окремо**, далі медіана по ногах монети і
медіана по шести монетах: інакше довгі ноги однієї монети перетягують
результат.

## Чим задається край

| Міра | Розмір краю |
| ---- | ----------- |
| `percent` | частка подій **своєї** ноги |
| `previous` | та сама частка, але від довжини **попередньої** ноги |
| `events` | стільки самих подій, незалежно від довжини ноги |

Початок і кінець рахуються нарізно. Край не може накрити ногу цілком:
подій у ньому щонайбільше половина ноги, інакше нога пропускається.

## Довжина пачки

Пачка `W` — це вікно, яким фіча зводиться в число (`W = 1` — сама подія).
Скрипт проходить `BATCHES` і показує розкид на кожній, тому `W`
підбирається тим самим заміром, що й край.

## Робочий край

Найбільший розкид дає край з однієї події, але це не край, а одна
подія: середній ранг по ній — саме її ранг, і розкид роздутий. Тому край
коротший за `MIN_EDGE` подій у вибір не йде (у таблиці він лишається), а
робочим береться **найдовший край, у якого розкид ще не впав нижче `KEEP`
від найкращого** на цій мірі: розкид майже той самий, а подій більше.

Та сама умова діє, коли порівнюються довжини пачки: інакше `W` з
одноподійним краєм виграє в усіх.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/edge_spread.json

Запуск:
    python3 research/22-leg-edge-spread/scripts/edge_spread.py
    python3 research/22-leg-edge-spread/scripts/edge_spread.py --batch 20
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))

import class210x10m1x7dd  # noqa: E402
import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
MODULE = class210x10m1x7dd
BATCHES = (1, 5, 10, 20, 40)
DEFAULT_BATCH = 20
MIN_EVENTS = 20            # коротша нога не має ні краю, ні середини
MIN_EDGE = 3               # край з однієї-двох подій — це шум, не край
KEEP = 0.95                # розкид робочого краю проти найкращого
PARTS = ("train", "val")

# Розміри краю на кожну міру. `percent` і `previous` — частка подій,
# `events` — самі події.
MEASURES = (
    {"id": "percent", "name": "у відсотках ноги",
     "unit": "% подій ноги", "kind": "share",
     "sizes": (0.01, 0.02, 0.03, 0.05, 0.07, 0.10, 0.15, 0.20, 0.30, 0.40)},
    {"id": "previous", "name": "у відсотках до попередньої ноги",
     "unit": "% подій попередньої ноги", "kind": "previous",
     "sizes": (0.01, 0.02, 0.03, 0.05, 0.07, 0.10, 0.15, 0.20, 0.30, 0.40)},
    {"id": "events", "name": "у кількості подій",
     "unit": "подій", "kind": "events",
     "sizes": (1, 2, 3, 5, 8, 12, 20, 30, 50, 80)},
)


def cell(value):
    value = float(value)
    return None if not np.isfinite(value) else round(value, 4)


def legs_of(coin: dict, least: int = MIN_EVENTS) -> list:
    """Ноги монети: придатні події, частина датасету, довжина попередньої.

    Довжина попередньої ноги береться від **сусідньої** ноги, навіть якщо
    та сама в замір не пішла: інакше міра `previous` міряла б не те.
    """
    edge, right = stamp(CUT), stamp(END)
    raw = []
    for previous, point in zip(coin["pivots"], coin["pivots"][1:]):
        first, last = previous.index + 1, point.index
        if last <= first:
            continue
        events = np.arange(first, last + 1)
        events = events[coin["ready"][events]]
        if coin["t"][last] < edge:
            part = "train"
        elif coin["t"][first] >= edge and coin["t"][last] < right:
            part = "val"
        else:
            part = None
        raw.append({"events": events, "part": part})
    out = []
    for index, leg in enumerate(raw):
        if leg["part"] is None or len(leg["events"]) < least:
            continue
        out.append({"events": leg["events"], "part": leg["part"],
                    "previous": len(raw[index - 1]["events"]) if index else 0})
    return out


def edge_size(kind: str, size, leg: dict) -> int:
    """Скільки подій брати з краю на цій мірі. 0 — нога не підходить."""
    length = len(leg["events"])
    if kind == "share":
        count = int(round(size * length))
    elif kind == "previous":
        count = int(round(size * leg["previous"]))
    else:
        count = int(size)
    count = max(count, 1)
    return count if 2 * count <= length else 0


def leg_ranks(values: np.ndarray) -> np.ndarray:
    """Ранг кожної колонки всередині ноги, приведений до [0, 1]."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        ranks = rankdata(values, axis=0, nan_policy="omit")
    ranks = np.where(np.isfinite(values), ranks, np.nan)
    middle = (len(values) + 1) / 2
    ranks = np.where(np.isnan(ranks), middle, ranks)
    return (ranks - 0.5) / len(values)


def spread_of(ranks: np.ndarray, count: int, folds: dict) -> dict:
    """Розкид між фічами в обох краях ноги, на кожну згортку.

    `ranks` — (n, 8·F) ранги подій ноги, `folds` — індекси колонок однієї
    згортки. Повертає {згортка: (початок, кінець)}.
    """
    start = ranks[:count].mean(axis=0)
    end = ranks[-count:].mean(axis=0)
    out = {}
    for fold, columns in folds.items():
        out[fold] = (float(start[columns].max() - start[columns].min()),
                     float(end[columns].max() - end[columns].min()))
    return out


def fold_columns(names: list) -> tuple:
    """Колонки згорток і індекси семи фіч усередині кожної згортки."""
    keep = [index for index, one in enumerate(names) if one["kind"] == "agg"]
    folds = {}
    for place, index in enumerate(keep):
        folds.setdefault(names[index]["agg"], []).append(place)
    return keep, {fold: np.array(columns) for fold, columns in folds.items()}


def one_batch(state: dict, batch: int, least: int = MIN_EVENTS,
              measures=MEASURES, log=print) -> dict:
    """Одна довжина пачки: розкид на всіх мірах, розмірах і згортках."""
    names = pivot.column_names(state["features"])
    keep, folds = fold_columns(names)
    order = list(folds)
    gathered = {one["id"]: {part: {fold: [[] for _ in one["sizes"]]
                                   for fold in order} for part in PARTS}
                for one in measures}
    counts = {one["id"]: {part: [0] * len(one["sizes"]) for part in PARTS}
              for one in measures}
    events = {one["id"]: [[] for _ in one["sizes"]] for one in measures}
    legs = {part: 0 for part in PARTS}

    for coin in state["coins"]:
        coin["ready"] = pivot.batch_ready(coin["t"], batch)
        cols = pivot.columns_of(coin["x"], coin["ready"], batch)[:, keep]
        found = legs_of(coin, least)
        for part in PARTS:
            legs[part] += sum(1 for leg in found if leg["part"] == part)
        for leg in found:
            ranks = leg_ranks(cols[leg["events"]])
            for one in measures:
                for step, size in enumerate(one["sizes"]):
                    count = edge_size(one["kind"], size, leg)
                    if not count:
                        continue
                    counts[one["id"]][leg["part"]][step] += 1
                    if leg["part"] == "train":
                        events[one["id"]][step].append(count)
                    for fold, pair in spread_of(ranks, count, folds).items():
                        gathered[one["id"]][leg["part"]][fold][step].append(
                            pair)
        log(f"      {coin['pair']}: ніг {len(found)}, згорток {len(order)}")

    cards = []
    for one in measures:
        body = {"measure": one["id"], "sizes": list(one["sizes"]),
                "legs": {part: counts[one["id"]][part] for part in PARTS},
                "events": [cell(np.mean(rows)) if rows else None
                           for rows in events[one["id"]]],
                "spread": {}}
        for part in PARTS:
            body["spread"][part] = {
                fold: {"start": [], "end": []} for fold in order}
            for fold in order:
                for rows in gathered[one["id"]][part][fold]:
                    block = np.array(rows, dtype=float) if rows \
                        else np.empty((0, 2))
                    for side, column in (("start", 0), ("end", 1)):
                        body["spread"][part][fold][side].append(
                            cell(np.median(block[:, column])) if len(block)
                            else None)
        cards.append(body)
    return {"batch": batch, "folds": order, "legs": legs, "cards": cards}


def working_edge(card: dict, fold: str, part: str = "train",
                 keep: float = KEEP, least: int = MIN_EDGE) -> dict:
    """Найдовший край, у якого розкид ще не впав нижче `keep` від кращого.

    Край, коротший за `least` подій, у вибір не йде: середній ранг по
    одній-двох подіях — це їх власний ранг, і розкид у ньому роздутий.
    """
    out = {}
    for side in ("start", "end"):
        line = card["spread"][part][fold][side]
        good = [(step, value) for step, value in enumerate(line)
                if value is not None and card["legs"][part][step]
                and (card["events"][step] or 0) >= least]
        if not good:
            out[side] = None
            continue
        best = max(value for _, value in good)
        picked = max(step for step, value in good if value >= keep * best)
        out[side] = {"size": card["sizes"][picked], "spread": line[picked],
                     "best": best, "best_size": card["sizes"][
                         max(good, key=lambda one: one[1])[0]],
                     "legs": card["legs"][part][picked],
                     "events": card["events"][picked]}
    return out


def best_batch(cards: list, measure: str, fold: str, part: str = "train",
               keep: float = KEEP, least: int = MIN_EDGE) -> dict:
    """Довжина пачки з найбільшим розкидом на цій мірі й згортці."""
    scored = []
    for card in cards:
        body = next(one for one in card["cards"] if one["measure"] == measure)
        edge = working_edge(body, fold, part, keep, least)
        if not edge["start"] or not edge["end"]:
            continue
        scored.append({"batch": card["batch"],
                       "start": edge["start"]["spread"],
                       "end": edge["end"]["spread"],
                       "mean": (edge["start"]["spread"]
                                + edge["end"]["spread"]) / 2})
    if not scored:
        return {}
    return {"by_batch": scored,
            "best": max(scored, key=lambda one: one["mean"])["batch"]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, action="append", default=None)
    parser.add_argument("--least", type=int, default=MIN_EVENTS)
    parser.add_argument("--keep", type=float, default=KEEP)
    parser.add_argument("--min-edge", type=int, default=MIN_EDGE)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    state = pivot.collect(args.data, leg_deciles.PERIOD, leg_deciles.THRESHOLD,
                          (10,), log=lambda *a: None, module=MODULE,
                          folder_name=CLASS)
    sizes = tuple(args.batch) if args.batch else BATCHES
    cards = []
    for batch in sizes:
        print(f"[пачка {batch}]")
        cards.append(one_batch(state, batch, args.least))

    folds = cards[0]["folds"]
    default_fold = "abs" if "abs" in folds else folds[0]
    default_batch = DEFAULT_BATCH if DEFAULT_BATCH in sizes else sizes[0]
    picked = {}
    for one in MEASURES:
        card = next(body for body in cards
                    if body["batch"] == default_batch)
        body = next(item for item in card["cards"]
                    if item["measure"] == one["id"])
        picked[one["id"]] = {
            "fold": default_fold,
            "batch": default_batch,
            "edge": working_edge(body, default_fold, "train", args.keep,
                                 args.min_edge),
            "batches": best_batch(cards, one["id"], default_fold,
                                  keep=args.keep, least=args.min_edge)}

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "edge_spread.json").write_text(json.dumps({
        "script": "research/22-leg-edge-spread/scripts/edge_spread.py",
        "command": "python3 research/22-leg-edge-spread/scripts/"
                   "edge_spread.py",
        "class": CLASS, "class_title": "клас210х10-1х7д/д",
        "features": state["features"], "aggregates": pivot.AGGREGATES,
        "families": pivot.FAMILIES, "measures": [
            {key: (list(one[key]) if key == "sizes" else one[key])
             for key in ("id", "name", "unit", "kind", "sizes")}
            for one in MEASURES],
        "threshold": leg_deciles.THRESHOLD, "period": leg_deciles.PERIOD,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "parts": list(PARTS),
        "batches": list(sizes), "default_batch": default_batch,
        "default_fold": default_fold, "default_measure": MEASURES[0]["id"],
        "min_events": args.least, "keep": args.keep,
        "min_edge": args.min_edge,
        "event_seconds": EVENT_LENGTH,
        "cards": cards, "picked": picked, "ready": True},
        ensure_ascii=False), encoding="utf-8")

    for one in MEASURES:
        edge = picked[one["id"]]["edge"]
        batches = picked[one["id"]]["batches"]
        print(f"{one['name']:32s} початок {edge['start']['size']} "
              f"(розкид {edge['start']['spread']}), кінець "
              f"{edge['end']['size']} (розкид {edge['end']['spread']}), "
              f"краща пачка {batches.get('best')}")
    print(f"записано {args.out}/edge_spread.json")


if __name__ == "__main__":
    main()
