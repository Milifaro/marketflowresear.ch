"""Ланцюг класів, з яких росте клас210х10-1х7д/д, з прикладами.

Дослідження: research/22-leg-edge-spread/
Правила: rules/01-data-and-db.md → Класи (події)

Клас не стоїть сам по собі: він виростає з ланцюга, і кожна ланка має
свої формули. Скрипт бере **справжні класи проєкту** (описи й формули —
з `rules/scripts/class_card.py`, того самого джерела, що й вкладка
«Класи датасету») і додає до кожного **одну випадкову подію** з датасету
`BTC_USDT`.

Подія одна на весь ланцюг: береться випадковий індекс серед подій без
`NaN` у кінцевому класі, і кожна ланка показує **ту саму** подію на
своєму кроці. Вибір відтворюваний: `--seed`.

`клас210х8` у датасетах не зберігається, тому в нього є формули, але
прикладу немає.

Вхід : data/datasets/BTC_USDT/<клас>/train.npz
Вихід: results/class_chain.json

Запуск:
    python3 research/22-leg-edge-spread/scripts/class_chain.py
    python3 research/22-leg-edge-spread/scripts/class_chain.py --seed 7
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class_card  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
SEED = 0
DIGITS = 6

# Ланцюг: від початкового класу до нашого. Імена — id карток класів,
# тому «вигадати» клас тут неможливо: його або є в class_card, або ні.
CHAIN = ("class210x8", "class210x10x9", "class210x10x7", "class210x10x7dc",
         "class210x10m1x7dc", "class210x10m1x7dd")
LAST = CHAIN[-1]


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def cell(value: float):
    """Число для JSON: NaN не серіалізується, тому йде як null."""
    value = float(value)
    return None if not np.isfinite(value) else round(value, DIGITS)


def cards(chain=CHAIN) -> list:
    """Картки класів ланцюга в порядку побудови."""
    known = {card["id"]: card for card in class_card.CLASSES}
    missing = [name for name in chain if name not in known]
    if missing:
        raise SystemExit(f"немає таких класів: {', '.join(missing)}")
    return [known[name] for name in chain]


def load_chain(pair: str, chain=CHAIN, root: Path | None = None) -> dict:
    """Набори тих ланок, чий датасет зберігається."""
    sets = {}
    for card in cards(chain):
        if card["dataset"] is None:
            continue
        path = (root or DATASETS) / pair / card["dataset"] / "train.npz"
        if not path.exists():
            raise SystemExit(f"немає датасету {path}")
        sets[card["id"]] = card["loader"](path)
    return sets


def pick(sets: dict, seed: int = SEED, last: str = LAST) -> int:
    """Випадкова подія серед тих, де в кінцевому класі немає NaN."""
    values = sets[last].x
    clean = np.isfinite(values.reshape(len(values), -1)).all(axis=1)
    good = np.flatnonzero(clean)
    if not len(good):
        raise SystemExit("подій без NaN немає")
    return int(np.random.default_rng(seed).choice(good))


def table(x: np.ndarray, features: list, first_block: int = 1) -> dict:
    """Одна подія таблицею: рядок на блок, колонка на фічу."""
    return {"features": list(features),
            "blocks": [{"block": first_block + step,
                        "values": [cell(value) for value in row]}
                       for step, row in enumerate(x)]}


def one_class(card: dict, sets: dict, index: int) -> dict:
    """Ланка ланцюга: формули з картки плюс приклад події."""
    body = {key: card[key] for key in
            ("id", "name", "parent", "shape", "unit", "script", "about",
             "features")}
    body["dataset"] = card["dataset"]
    if card["id"] not in sets:
        body["example"] = None
        return body
    dataset = sets[card["id"]]
    # клас без першої плашки («-1» в імені) починається з другого блоку
    first = 2 if card["id"].startswith("class210x10m1") else 1
    body["example"] = table(dataset.x[index], dataset.features, first)
    body["events"] = int(len(dataset))
    return body


def build(pair: str = PAIR, seed: int = SEED, chain=CHAIN,
          root: Path | None = None) -> dict:
    sets = load_chain(pair, chain, root)
    index = pick(sets, seed)
    last = sets[LAST]
    return {
        "script": "research/22-leg-edge-spread/scripts/class_chain.py",
        "command": "python3 research/22-leg-edge-spread/scripts/"
                   "class_chain.py",
        "pair": pair,
        "seed": seed,
        "index": index,
        "event": {"t_start": int(last.t_start[index]),
                  "t_end": int(last.t_end[index]),
                  "from_utc": utc(last.t_start[index]),
                  "to_utc": utc(last.t_end[index]),
                  "price_open": cell(last.price_open[index]),
                  "price_close": cell(last.price_close[index])},
        "default_class": LAST,
        "classes": [one_class(card, sets, index) for card in cards(chain)],
        "ready": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.seed, CHAIN, args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "class_chain.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    for card in payload["classes"]:
        shape = "×".join(str(v) for v in card["shape"])
        example = "приклад є" if card["example"] else "прикладу немає"
        print(f"{card['name']:22s} {shape:8s} фіч {len(card['features']):2d}"
              f" · {example}")
    print(f"подія {payload['index']} "
          f"({payload['event']['from_utc']}) -> {args.out}/class_chain.json")


if __name__ == "__main__":
    main()
