"""Хітмап кореляцій ЕМА чотирьох фіч: періоди 10 … 400 кроком 10.

Дослідження: research/11-ema-zigzag-correlation/
Правила: rules/05-visualization.md, rules/02-markup.md

Для кожного періоду рахується ЕМА кожної фічі класу-джерела
(`клас210х210х4ц`: три безрозмірні фічі стакану й обʼємів плюс цінова)
і три набори кореляцій:

- з **зігзагом 2.3%** — напрямок руху (`+1` вгору, `-1` вниз) і нормована
  нога (`-1` у нижньому півоті, `+1` у верхньому, між ними пропорційно ціні);
- з **зігзагом 0.8%** — те саме на вкладеному зігзагу;
- **між самими фічами** — усі шість пар.

Зігзаг будується **на ЕМА ціни того самого періоду**, що й фічі колонки
(`--zigzag ema`, типово): спершу ЕМА ціни, потім по ній півоти, потім
нормалізація. Тобто в кожній колонці і фічі, і зігзаг згладжені однаково.
`--zigzag price` лишає зігзаг на самій ціні події — один і той самий для
всіх колонок.

Кореляції рахуються обома методами (`scripts/correlation.py`): Пірсоном
і Спірменом. На хітмапі — Пірсон, у JSON — обидва.

Вхід : data/datasets/<PAIR>/class210x210x4c/{train,val,test}.npz
Вихід: results/<префікс>.json — усі числа
       results/<префікс>.png  — хітмап

Періоди задаються діапазонами `від:до:крок`, їх можна кілька:
типово `10:400:10` і `450:1000:50` — 52 періоди від 0.6 до 58 годин.

Запуск:
    python3 research/11-ema-zigzag-correlation/scripts/ema_grid.py \
        --pair BTC_USDT --range 10:400:10 --range 450:1000:50
"""

from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, Normalize  # noqa: E402
import numpy as np  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from class_series import collect  # noqa: E402
from class210ema4 import ema  # noqa: E402
from correlation import pearson, spearman  # noqa: E402
from zigzag import INNER_THRESHOLD, OUTER_THRESHOLD  # noqa: E402
from zigzag_correlation import NORMALIZERS, targets  # noqa: E402

DPI = 200
BG, PANEL, TEXT, MUTED = "#0d0f14", "#1b1e26", "#e6e8ee", "#98a0b3"
UP, DOWN = "#46c882", "#eb5a5a"
# Знак — колір (rules/05): червоне мінус, зелене плюс, нуль — тло.
DIVERGING = LinearSegmentedColormap.from_list(
    "corr", ["#ff8f8f", DOWN, "#7a2a2a", BG, "#1c7a4d", UP, "#9dedc0"])

SOURCE = "class210x210x4c"
DEFAULT_RANGES = ["10:400:10", "450:1000:50"]


def periods_from(ranges: list[str]) -> list[int]:
    """`від:до:крок` → перелік періодів без повторів, за зростанням."""
    periods: set[int] = set()
    for item in ranges:
        try:
            start, stop, step = (int(part) for part in item.split(":"))
        except ValueError:
            raise SystemExit(f"діапазон має вигляд від:до:крок, а не {item!r}")
        if start < 1 or step < 1 or stop < start:
            raise SystemExit(f"хибний діапазон {item!r}")
        periods.update(range(start, stop + 1, step))
    return sorted(periods)


def feature_names(in_dir: Path) -> list[str]:
    """Імена фіч класу-джерела з його ж файлу."""
    with np.load(in_dir / "train.npz", allow_pickle=False) as data:
        return [f"ema_{name}" for name in data["features"]]


def rows_for(series: dict, period: int) -> list[np.ndarray]:
    """ЕМА кожної фічі класу-джерела на одному періоді."""
    return [ema(series["x"][:, index], period)
            for index in range(series["x"].shape[1])]


def legs_for(series: dict, period: int, zigzag_on: str) -> dict:
    """Цілі колонки: на ЕМА ціни цього ж періоду або на самій ціні.

    Значення — `(ціль, як обробити фічу)`: нормовані ряди вимагають, щоб
    фіча пройшла той самий скейлер по тих самих ногах
    (`scripts/zigzag_correlation.py` → targets).
    """
    prices = (series["price_open"] if zigzag_on == "price"
              else ema(series["price_open"], period))
    return targets(prices)


def grid(in_dir: Path, periods: list[int], zigzag_on: str = "ema") -> dict:
    """Числа хітмапа: кореляції на кожному періоді."""
    series = collect(in_dir)
    features = feature_names(in_dir)
    pairs = list(combinations(range(len(features)), 2))
    names = list(legs_for(series, periods[0], zigzag_on))

    shape = (len(features), len(periods))
    result = {
        "periods": periods,
        "features": features,
        "pairs": [[features[a], features[b]] for a, b in pairs],
        "events": int(len(series["timestamp"])),
        "event_seconds": 210,
        "thresholds": {"зігзаг 2.3": OUTER_THRESHOLD,
                       "зігзаг 0.8": INNER_THRESHOLD},
        "scalers": [{"id": key, "name": title}
                    for key, title in NORMALIZERS.items()],
        "source": str(in_dir),
        "zigzag_on": zigzag_on,
        "zigzag": {name: {"pearson": np.zeros(shape).tolist(),
                          "spearman": np.zeros(shape).tolist()}
                   for name in names},
        "features_pairs": {"pearson": np.zeros((len(pairs), len(periods))).tolist(),
                           "spearman": np.zeros((len(pairs), len(periods))).tolist()},
    }

    for column, period in enumerate(periods):
        rows = rows_for(series, period)
        legs = legs_for(series, period, zigzag_on)
        for name, (target, scale) in legs.items():
            # фіча йде тим самим скейлером і по тих самих ногах, що й ціль
            scaled = rows if scale is None else [scale(row) for row in rows]
            for index, row in enumerate(scaled):
                # ранги рахуються після відкидання подій поза зігзагом,
                # інакше вони потрапляють у Спірмена з чужими рангами
                result["zigzag"][name]["pearson"][index][column] = \
                    round(pearson(row, target), 4)
                result["zigzag"][name]["spearman"][index][column] = \
                    round(spearman(row, target), 4)
        for index, (a, b) in enumerate(pairs):
            result["features_pairs"]["pearson"][index][column] = \
                round(pearson(rows[a], rows[b]), 4)
            result["features_pairs"]["spearman"][index][column] = \
                round(spearman(rows[a], rows[b]), 4)
        print(f"      період {period}: готово")
    return result


def panel(ax, bar, values, labels, periods, title, fig):
    """Одна смуга хітмапа: рядки — ряди, колонки — періоди."""
    values = np.asarray(values, dtype=float)
    limit = float(np.nanmax(np.abs(values))) or 1.0     # шкала з самих даних
    image = ax.imshow(values, aspect="auto", origin="upper",
                      interpolation="nearest", cmap=DIVERGING,
                      norm=Normalize(-limit, limit),
                      extent=[periods[0] - 5, periods[-1] + 5,
                              len(labels), 0])
    ax.set_yticks(np.arange(len(labels)) + 0.5)
    ax.set_yticklabels(labels, color=MUTED, fontsize=7)
    ax.set_ylabel(title, color=MUTED, fontsize=8)
    ax.tick_params(colors=MUTED, labelsize=7)
    for spine in ax.spines.values():
        spine.set_edgecolor("#2c313d")
    colorbar = fig.colorbar(image, cax=bar)
    colorbar.ax.tick_params(colors=MUTED, labelsize=7)
    colorbar.outline.set_edgecolor("#2c313d")
    return limit


def draw(data: dict, out: Path, pair: str) -> dict:
    periods = data["periods"]
    bands = len(data["zigzag"]) + 1
    fig, axes = plt.subplots(bands, 2, figsize=(13, 3 + 2.2 * bands),
                             gridspec_kw={"width_ratios": [40, 1],
                                          "height_ratios": [4] * (bands - 1) + [6],
                                          "hspace": 0.28, "wspace": 0.02})
    fig.patch.set_facecolor(BG)
    for ax in axes.flat:
        ax.set_facecolor(PANEL)

    hours = [f"{p * 210 / 3600:.1f}" for p in (periods[0], periods[-1])]
    axes[0][0].set_title(
        f"{pair} · кореляція ЕМА фіч ({data['source_class']}) з рухами зігзага "
        f"і між собою · {data['events']} подій по {data['event_seconds']} с\n"
        f"Колонка — період ЕМА: {len(periods)} значень від {periods[0]} "
        f"до {periods[-1]} подій ({hours[0]} … {hours[1]} год), крок "
        f"{periods[1] - periods[0]} до 400 і "
        f"{periods[-1] - periods[-2]} далі. "
        f"Показано Пірсона; Спірмен — у ema_grid.json.\n"
        f"Зігзаг побудований на "
        f"{'ЕМА ціни того самого періоду' if data['zigzag_on'] == 'ema' else 'ціні події'}. "
        f"Напрямок руху: +1 вгору, -1 вниз. Нормований зігзаг: -1 у нижньому "
        f"півоті, +1 у верхньому, між ними пропорційно ціні в нозі. "
        f"Події поза зігзагом не рахуються.",
        color=TEXT, fontsize=9, loc="left")

    limits = {}
    for index, name in enumerate(data["zigzag"]):
        limits[name] = panel(
            axes[index][0], axes[index][1],
            data["zigzag"][name]["pearson"], data["features"], periods,
            name.replace(" ", "\n", 1), fig)
    limits["між фічами"] = panel(
        axes[-1][0], axes[-1][1], data["features_pairs"]["pearson"],
        [f"{a} × {b}".replace("ema_", "") for a, b in data["pairs"]],
        periods, "між фічами", fig)

    axes[-1][0].set_xlabel("період ЕМА, подій", color=MUTED, fontsize=8)
    for row in axes[:-1]:
        row[0].set_xticklabels([])

    fig.text(
        0.5, 0.02,
        "зелене — плюс, червоне — мінус, тло — нуль; шкала кожної смуги "
        "симетрична і порахована з її власних даних (межі — у підписі шкали "
        "справа)\n"
        "рядки верхніх смуг — та сама фіча на різних періодах; нижня "
        "смуга — усі шість пар фіч між собою",
        color=MUTED, fontsize=8, ha="center", va="top")

    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=DPI, facecolor=fig.get_facecolor(),
                bbox_inches="tight")
    plt.close(fig)
    return limits


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--range", dest="ranges", action="append",
                        help="від:до:крок, можна кілька; типово "
                             + " і ".join(DEFAULT_RANGES))
    parser.add_argument("--class", dest="class_name", default=SOURCE,
                        help="тека класу-джерела в data/datasets/<PAIR>/")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--zigzag", dest="zigzag_on", default="ema",
                        choices=("ema", "price"),
                        help="ряд для зігзага: ЕМА ціни того самого періоду "
                             "чи сама ціна події")
    parser.add_argument("--prefix", default="ema_grid",
                        help="імена файлів виводу")
    parser.add_argument("--out", type=Path, default=RESEARCH_DIR / "results")
    args = parser.parse_args()

    in_dir = (args.in_dir or PROJECT_ROOT / "data" / "datasets" / args.pair
              / args.class_name)
    periods = periods_from(args.ranges or DEFAULT_RANGES)
    if not periods:
        raise SystemExit("порожній перелік періодів")

    print(f"[1/2] {len(periods)} періодів: {periods[0]} … {periods[-1]}")
    data = grid(in_dir, periods, args.zigzag_on)
    data["pair"] = args.pair
    data["source_class"] = in_dir.name
    data["limits"] = draw(data, args.out / f"{args.prefix}.png", args.pair)
    (args.out / f"{args.prefix}.json").write_text(
        json.dumps(data, ensure_ascii=False), encoding="utf-8")
    print(f"[2/2] записано в {args.out}/{args.prefix}.png і {args.prefix}.json")


if __name__ == "__main__":
    main()
