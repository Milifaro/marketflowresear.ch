"""клас210ема4 — чотири ЕМА на подію: ціна і три фічі клас210х210х3.

Правила: rules/01-data-and-db.md → Класи (події) → клас210ема4

Подія та сама, що в `клас210х210х3` — 210 секунд. Значення чотири, усі
експоненційні середні по ряду подій, відсортованому за часом:

    ema_price       = ЕМА(price_open)
    ema_balance     = ЕМА(balance)
    ema_d_balance   = ЕМА(d_balance)
    ema_vol_balance = ЕМА(vol_balance)

- Формула: `alpha = 2 / (період + 1)`, старт із першого значення ряду.
- Період — параметр побудови, зберігається разом з даними.
- ЕМА дивиться тільки назад, тому майбутнього в події немає. Але ряд
  наскрізний: середнє події з val/test спирається на попередні події,
  серед яких є train. Це властивість самої ЕМА, не витік уперед.
- Перша фіча в quote (USDT), решта три безрозмірні, межі [-1, 1].
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210x210x3 import Class210x210x3, FEATURES as PARENT_FEATURES

FEATURES = ["ema_price"] + [f"ema_{name}" for name in PARENT_FEATURES]
DEFAULT_PERIOD = 200      # подій; 200 × 210 с ≈ 11 год 40 хв


@dataclass
class Class210ema4:
    """Набір подій клас210ема4."""

    x: np.ndarray            # (N, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    period: int = DEFAULT_PERIOD
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    period: int
    nan_by_feature: dict


def ema(values: np.ndarray, period: int) -> np.ndarray:
    """ЕМА ряду: alpha = 2 / (period + 1), старт із першого значення."""
    if period < 1:
        raise ValueError("період має бути >= 1")
    values = np.asarray(values, dtype=float)
    alpha = 2.0 / (period + 1.0)
    out = np.empty_like(values)
    previous = np.nan
    for index, value in enumerate(values):
        if not np.isfinite(value):
            out[index] = np.nan
            continue
        previous = (value if not np.isfinite(previous)
                    else previous + alpha * (value - previous))
        out[index] = previous
    return out


def build(parent: Class210x210x3, period: int = DEFAULT_PERIOD
          ) -> tuple[Class210ema4, BuildReport]:
    """Будує клас210ема4 з клас210х210х3, відсортованого за часом."""
    if parent.x.ndim != 2 or parent.x.shape[1] != len(PARENT_FEATURES):
        raise ValueError(f"очікується масив (N, {len(PARENT_FEATURES)})")
    if len(parent) and np.any(np.diff(parent.timestamp) <= 0):
        raise ValueError("події мають іти за часом, без повторів")

    rows = [ema(parent.price_open, period)]
    rows += [ema(parent.x[:, index], period)
             for index in range(len(PARENT_FEATURES))]
    x = np.stack(rows, axis=1) if len(parent) else np.zeros((0, len(FEATURES)))

    dataset = Class210ema4(
        x=x,
        timestamp=parent.timestamp,
        price_open=parent.price_open,
        price_close=parent.price_close,
        period=period,
    )
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        period=period,
        nan_by_feature={name: int(np.isnan(x[:, i]).sum())
                        for i, name in enumerate(FEATURES)},
    )
    return dataset, report


def save(dataset: Class210ema4, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        period=np.array(dataset.period),
        features=np.array(dataset.features),
    )


def load(path) -> Class210ema4:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210ema4(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            period=int(data["period"]),
            features=list(data["features"]),
        )
