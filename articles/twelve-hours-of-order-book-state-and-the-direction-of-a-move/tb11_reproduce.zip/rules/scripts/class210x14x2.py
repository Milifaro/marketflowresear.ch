"""клас210х14х2 — нормовані різниці опору й підтримки, межі [-1, 1].

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х2

Будується повністю з клас210х14х4, до батьківських класів не звертається.
Поблочно, для кожного з 15 блоків по 14 секунд:

    balance   = (resist_j   - support_j)   / (|resist_j|   + |support_j|)
    d_balance = (d_resist_j - d_support_j) / (|d_resist_j| + |d_support_j|)

- 2 фічі × 15 значень. Форма події: (15, 2).
- Обидві величини безрозмірні: одиниці обʼємів скорочуються.
- Нульовий знаменник (обидві величини блоку = 0) дає NaN — значення
  лишається як є, кількість фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210x14x4 import FEATURES as PARENT_FEATURES, N_BLOCKS, Class210x14x4

FEATURES = ["balance", "d_balance"]

_P = {name: i for i, name in enumerate(PARENT_FEATURES)}


@dataclass
class Class210x14x2:
    """Набір подій клас210х14х2."""

    x: np.ndarray            # (N, 15, 2)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_balance: int      # блоків із нульовим знаменником у balance
    nan_d_balance: int    # те саме в d_balance


def _norm_diff(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """(a - b) / (|a| + |b|), межі [-1, 1]. Нульовий знаменник -> NaN."""
    denominator = np.abs(a) + np.abs(b)
    with np.errstate(invalid="ignore", divide="ignore"):
        return (a - b) / denominator


def build(parent: Class210x14x4) -> tuple[Class210x14x2, BuildReport]:
    """Будує клас210х14х2 з клас210х14х4."""
    if parent.x.ndim != 3 or parent.x.shape[1:] != (N_BLOCKS,
                                                    len(PARENT_FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, {len(PARENT_FEATURES)})")

    src = parent.x.astype(float)
    balance = _norm_diff(src[:, :, _P["resist"]], src[:, :, _P["support"]])
    d_balance = _norm_diff(src[:, :, _P["d_resist"]], src[:, :, _P["d_support"]])

    dataset = Class210x14x2(
        x=np.stack([balance, d_balance], axis=2),
        timestamp=parent.timestamp,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_balance=int(np.isnan(balance).sum()),
        nan_d_balance=int(np.isnan(d_balance).sum()),
    )
    return dataset, report


def save(dataset: Class210x14x2, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x14x2:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x14x2(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
