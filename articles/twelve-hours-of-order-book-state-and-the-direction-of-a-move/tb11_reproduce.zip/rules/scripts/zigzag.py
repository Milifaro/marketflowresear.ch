"""Зігзаг: півоти за відсотковим порогом і вкладені зігзаги.

Правила: rules/02-markup.md

- Зігзаг з кроком між вершинами від N% («зігзаг 2.3» — поріг 2,3%).
- «рух вгору» — зелений, «рух вниз» — червоний.
- Півоти: зверху (`high`) — зелений, знизу (`low`) — червоний.
- Усередині кожного руху будується вкладений зігзаг з меншим порогом
  («зігзаг 0.8»), щоб бачити внутрішні корекції.
- Після зігзага будь-якого порогу півоти переносяться на справжню точку
  кінця ноги: `snap(...)`, rules/02-markup.md → Точка кінця ноги.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from scalers import SCALERS

OUTER_THRESHOLD = 0.023  # зігзаг 2.3
INNER_THRESHOLD = 0.008  # зігзаг 0.8
DEFAULT_SCALER = "minmax"  # нормований зігзаг за замовчуванням
SNAP_SPAN = 25  # у якому вікні шукається справжня точка кінця ноги


@dataclass
class Pivot:
    """Півот зігзагу."""

    index: int
    kind: str  # 'high' — зверху, 'low' — знизу

    def as_dict(self, prices: np.ndarray, timestamps: np.ndarray) -> dict:
        return {"i": int(self.index), "t": int(timestamps[self.index]),
                "p": float(prices[self.index]), "k": self.kind}


@dataclass
class Move:
    """Рух між двома сусідніми півотами."""

    start: int
    end: int
    direction: str  # 'up' | 'down'


def zigzag(prices: np.ndarray, threshold: float) -> list[Pivot]:
    """Півоти зігзагу: розворот підтверджується зміною на threshold від екстремуму.

    threshold — частками (0.023 = 2,3%).
    """
    if threshold <= 0:
        raise ValueError("threshold має бути > 0")
    prices = np.asarray(prices, dtype=float)
    if len(prices) < 2:
        return []

    pivots: list[Pivot] = []
    direction = None            # напрямок поточного руху
    hi = lo = 0                 # індекси екстремумів від останнього півота

    for i in range(1, len(prices)):
        price = prices[i]
        if price > prices[hi]:
            hi = i
        if price < prices[lo]:
            lo = i

        if direction is None:
            if price >= prices[lo] * (1 + threshold):
                pivots.append(Pivot(lo, "low"))
                direction, hi = "up", i
            elif price <= prices[hi] * (1 - threshold):
                pivots.append(Pivot(hi, "high"))
                direction, lo = "down", i
        elif direction == "up":
            if price <= prices[hi] * (1 - threshold):
                pivots.append(Pivot(hi, "high"))
                direction, lo = "down", i
        else:
            if price >= prices[lo] * (1 + threshold):
                pivots.append(Pivot(lo, "low"))
                direction, hi = "up", i

    # незавершений рух: останній екстремум лишається як край
    if direction == "up" and hi > pivots[-1].index:
        pivots.append(Pivot(hi, "high"))
    elif direction == "down" and lo > pivots[-1].index:
        pivots.append(Pivot(lo, "low"))
    return pivots


def snap(pivots: list[Pivot], prices: np.ndarray,
         span: int = SNAP_SPAN) -> list[Pivot]:
    """Точна точка кінця ноги: півот переноситься на екстремум ціни поруч.

    Зігзаг будується по згладженій ціні, а ЕМА відстає — півот стоїть
    пізніше за подію, у якій розворот стався (медіана −4 події,
    дослідження 34). Тому після зігзага **будь-якого** порогу кожен
    півот переноситься на подію, чия ціна в цьому вікні крайня:
    `high` — на максимум, `low` — на мінімум.

    `prices` — ціна, по якій шукається екстремум: `price_close` події
    (правило rules/02-markup.md → Точка кінця ноги). Вікно пошуку
    обрізається сусідніми півотами, тому порядок і чергування
    зберігаються.
    """
    if span < 0:
        raise ValueError("span має бути >= 0")
    prices = np.asarray(prices, dtype=float)
    if not len(prices):
        return list(pivots)
    moved: list[Pivot] = []
    for number, pivot in enumerate(pivots):
        low = max(pivot.index - span, 0)
        if moved:
            low = max(low, moved[-1].index + 1)
        high = min(pivot.index + span, len(prices) - 1)
        if number + 1 < len(pivots):
            high = min(high, pivots[number + 1].index - 1)
        if high < low:                       # місця немає — лишаємо як є
            moved.append(Pivot(pivot.index, pivot.kind))
            continue
        piece = prices[low:high + 1]
        step = int(np.argmax(piece) if pivot.kind == "high"
                   else np.argmin(piece))
        moved.append(Pivot(low + step, pivot.kind))
    return moved


def moves(pivots: list[Pivot]) -> list[Move]:
    """Рухи між сусідніми півотами."""
    return [Move(a.index, b.index, "up" if a.kind == "low" else "down")
            for a, b in zip(pivots, pivots[1:])]


def normalized(prices: np.ndarray, pivots: list[Pivot],
               scaler: str = DEFAULT_SCALER) -> np.ndarray:
    """Нормований зігзаг: місце ціни в нозі, порахувати можна трьома способами.

    Нога — це одиниця нормування: кожен рух між сусідніми півотами
    проходить скейлер **окремо**, на своїх власних значеннях
    (`rules/01-data-and-db.md` → Скейлери).

    | Скейлер | Формула на нозі | Що показує |
    | ------- | --------------- | ---------- |
    | `minmax` | `2 * (price - low) / (high - low) - 1` | частку пройденого шляху: рівно -1 у нижньому півоті, +1 у верхньому |
    | `robust` | `(price - медіана) / (q75 - q25)` | те саме в одиницях IQR ноги: центр і масштаб з квантилів, довгий хвіст ноги їх не тягне |
    | `quantile` | `2u - 1`, `u` — місце ціни в CDF ноги | ранг події всередині ноги: рівний розподіл, швидкість руху не впливає |

    `low` і `high` — ціни півотів руху; для `minmax` вони ж є межами
    ноги, тому напрямок руху читається з самих значень: вони ростуть на
    русі вгору й спадають на русі вниз.

    Точки поза зігзагом (до першого півота й після останнього) — NaN.
    Рух з нульовою висотою (обидва півоти за однією ціною) — теж NaN:
    нормувати нема чого.

    Півот належить **обом** сусіднім ногам, а значення в ряду одне: його
    пише наступна нога. Для `minmax` це те саме число з обох боків
    (`+1` у вершині, `-1` у дні), для `robust` і `quantile` — ні, бо
    ноги різні. Одна точка на кожен півот, 685 з 40 242 подій.
    """
    if scaler not in SCALERS:
        raise ValueError(f"скейлер має бути з {tuple(SCALERS)}")
    prices = np.asarray(prices, dtype=float)
    out = np.full(len(prices), np.nan)
    scale = SCALERS[scaler]
    for move in moves(pivots):
        low = min(prices[move.start], prices[move.end])
        high = max(prices[move.start], prices[move.end])
        if high == low:
            continue
        chunk = prices[move.start:move.end + 1]
        out[move.start:move.end + 1] = scale(chunk)[0]
    return out


def nested_zigzag(prices: np.ndarray, pivots: list[Pivot],
                  threshold: float) -> list[Pivot]:
    """Вкладений зігзаг усередині кожного руху; краї рухів не дублюються."""
    prices = np.asarray(prices, dtype=float)
    inner: list[Pivot] = []
    for move in moves(pivots):
        chunk = prices[move.start:move.end + 1]
        for pivot in zigzag(chunk, threshold):
            index = move.start + pivot.index
            if move.start < index < move.end:
                inner.append(Pivot(index, pivot.kind))
    return inner
