"""Заповнення пропусків часу — секунди без торгової активності.

Правила: rules/01-data-and-db.md → Пропуски часу

У вихідному CSV секунда зʼявляється тільки тоді, коли в ній була угода.
Секунда без угод у файлі просто відсутня, і подія `клас210х8`, якій
потрібні 210 секунд підряд, розсипається на такому пропуску.

Короткий пропуск — це не збій збору, а відсутність активності. Він
відновлюється рядком:

    vol_buy, vol_sell            0 — угод не було
    price_avg                    ціна попередньої секунди — вона не змінилась
    рівні опору й підтримки      значення попередньої секунди — стакан на місці

Довгий пропуск не заповнюється: це вже зупинка збору даних, і що там
було насправді — невідомо. Межа — `MAX_GAP` секунд.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from data_source import SOURCE_COLUMNS

# Довші пропуски — зупинка збору, не тиша в стакані.
MAX_GAP = 60

TS_IDX = SOURCE_COLUMNS.index("timestamp")
VOL_IDX = [SOURCE_COLUMNS.index("vol_buy"), SOURCE_COLUMNS.index("vol_sell")]


@dataclass
class FillReport:
    """Звіт заповнення одного відрізка."""

    max_gap: int
    gaps_total: int
    gaps_filled: int
    seconds_filled: int
    gaps_left: int
    seconds_left: int

    def __add__(self, other: "FillReport") -> "FillReport":
        return FillReport(
            max_gap=max(self.max_gap, other.max_gap),
            gaps_total=self.gaps_total + other.gaps_total,
            gaps_filled=self.gaps_filled + other.gaps_filled,
            seconds_filled=self.seconds_filled + other.seconds_filled,
            gaps_left=self.gaps_left + other.gaps_left,
            seconds_left=self.seconds_left + other.seconds_left,
        )


def empty_report(max_gap: int = MAX_GAP) -> FillReport:
    return FillReport(max_gap=max_gap, gaps_total=0, gaps_filled=0,
                      seconds_filled=0, gaps_left=0, seconds_left=0)


def fill(rows: np.ndarray, max_gap: int = MAX_GAP
         ) -> tuple[np.ndarray, FillReport]:
    """Вставляє секунди без угод у пропуски завдовжки до `max_gap`.

    Вхід — масив у порядку SOURCE_COLUMNS, відсортований за timestamp,
    без дублікатів. Вихід — той самий масив із доданими рядками.
    `max_gap=0` вимикає заповнення.
    """
    if rows.ndim != 2 or rows.shape[1] != len(SOURCE_COLUMNS):
        raise ValueError(f"очікується масив (N, {len(SOURCE_COLUMNS)})")
    if max_gap < 0:
        raise ValueError("max_gap має бути >= 0")
    if len(rows) < 2:
        return rows, empty_report(max_gap)

    ts = rows[:, TS_IDX].astype(np.int64)
    if np.any(np.diff(ts) <= 0):
        raise ValueError("рядки мають іти строго за зростанням timestamp")

    holes = np.diff(ts) - 1
    short = (holes > 0) & (holes <= max_gap)
    long_ = holes > max_gap
    report = FillReport(
        max_gap=max_gap,
        gaps_total=int((holes > 0).sum()),
        gaps_filled=int(short.sum()),
        seconds_filled=int(holes[short].sum()),
        gaps_left=int(long_.sum()),
        seconds_left=int(holes[long_].sum()),
    )
    if report.seconds_filled == 0:
        return rows, report

    # Кожен рядок повторюється стільки разів, скільки секунд він покриває.
    repeats = np.ones(len(rows), dtype=np.int64)
    repeats[:-1] += np.where(short, holes, 0)
    out = np.repeat(rows, repeats, axis=0)

    # Перший рядок кожного повтору — справжня секунда, решта — заповнені.
    starts = np.concatenate(([0], np.cumsum(repeats)[:-1]))
    offset = np.arange(len(out), dtype=np.int64) - np.repeat(starts, repeats)
    out[:, TS_IDX] += offset

    added = offset > 0
    for idx in VOL_IDX:
        out[added, idx] = 0.0
    return out, report
