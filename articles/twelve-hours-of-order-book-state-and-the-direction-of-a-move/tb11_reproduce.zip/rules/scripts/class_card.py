"""Картки класів подій: опис, формули, розміри, статистика по датасету.

Правила: rules/01-data-and-db.md → Класи (події)

Один опис на клас: звідки будується, яка форма події, які фічі й за якими
формулами, у яких одиницях, скільки подій у кожній вибірці й у яких межах
реально лежать значення. Числа беруться **з готових датасетів**, а не
з голови: межі, квантилі, розкид і гістограми рахуються на `train`.

Опис класу тут і в rules/01-data-and-db.md — те саме; цей скрипт додає
до нього виміряні числа й дані для вкладки дашборду «Класи датасету».

Вхід : data/datasets/<PAIR>/<клас>/{train,val,test}.npz + report.json
Вихід: data/datasets/<PAIR>/cards.json

Запуск:
    python3 rules/scripts/class_card.py --pair BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210ema4
import class210ema4c
import class210x10m1x2d
import class210x10m1x3p1dc
import class210x10m1x7dc
import class210x10m1x7dd
import class210x10x7
import class210x10x7dc
import class210x10x9
import class210x14x2
import class210x14x3
import class210x14x4
import class210x14x4c
import class210x14x5
import class210x210x3
import class210x210x4c
import class210x4bema10x10x130
import scalers
from class210x8 import EVENT_LENGTH, FEATURES as BASE_FEATURES
from class210x14x4 import BLOCK, N_BLOCKS
from data_source import PROJECT_ROOT, SOURCE_COLUMNS

PARTS = ("train", "val", "test")
BINS = 64          # стовпчиків у гістограмі фічі
CLIP = 0.005       # хвости, які гістограма не показує (з кожного боку)

# Порядок — від батька до похідних, як у rules/01-data-and-db.md.
CLASSES = [
    {
        "id": "class210x8",
        "name": "клас210х8",
        "parent": "початковий датасет",
        "shape": [EVENT_LENGTH, len(BASE_FEATURES)],
        "unit": "як у вихідному CSV",
        "script": "rules/scripts/class210x8.py",
        "dataset": None,       # не зберігається: з нього одразу будуються похідні
        "loader": None,
        "about": ("Подія — 210 секунд безперервної посекундної історії, без "
                  "пропусків у timestamp. Базовий клас: у датасетах не "
                  "зберігається, з нього будуються похідні."),
        "features": [{"name": name, "formula": f"{name} як є, посекундно",
                      "unit": "base (BTC)" if name.startswith("vol") else "—"}
                     for name in BASE_FEATURES],
    },
    {
        "id": "class210x14x4",
        "name": "клас210х14х4",
        "parent": "клас210х8",
        "shape": [N_BLOCKS, len(class210x14x4.FEATURES)],
        "unit": "обʼєми події",
        "script": "rules/scripts/class210x14x4.py",
        "dataset": "class210x14x4",
        "loader": class210x14x4.load,
        "about": ("Одиниця вимірювання привʼязана до обʼємів самої події: "
                  "суми по блоках з 14 секунд діляться на середній обʼєм за "
                  "210 с. Подія з нульовим середнім обʼємом відкидається."),
        "features": [
            {"name": "resist", "formula": "Σ14(const_resist) / mean(vol_buy)",
             "unit": "обʼєми"},
            {"name": "d_resist",
             "formula": "Σ14(resist_plus − resist_minus) / mean(vol_buy)",
             "unit": "обʼєми"},
            {"name": "support", "formula": "Σ14(const_support) / mean(vol_sell)",
             "unit": "обʼєми"},
            {"name": "d_support",
             "formula": "Σ14(support_plus − support_minus) / mean(vol_sell)",
             "unit": "обʼєми"},
        ],
    },
    {
        "id": "class210x14x2",
        "name": "клас210х14х2",
        "parent": "клас210х14х4",
        "shape": [N_BLOCKS, len(class210x14x2.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x14x2.py",
        "dataset": "class210x14x2",
        "loader": class210x14x2.load,
        "about": ("Нормовані різниці опору й підтримки поблочно. Одиниці "
                  "обʼємів скорочуються. +1 — працює тільки опір, −1 — тільки "
                  "підтримка, 0 — рівність. Нульовий знаменник дає NaN, подія "
                  "лишається."),
        "features": [
            {"name": "balance",
             "formula": "(resist − support) / (|resist| + |support|)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance",
             "formula": "(d_resist − d_support) / (|d_resist| + |d_support|)",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x14x5",
        "name": "клас210х14х5",
        "parent": "клас210х8",
        "shape": [N_BLOCKS, len(class210x14x5.FEATURES)],
        "unit": "обʼєми події + безрозмірна",
        "script": "rules/scripts/class210x14x5.py",
        "dataset": "class210x14x5",
        "loader": class210x14x5.load,
        "about": ("Клас210х14х4 плюс баланс обʼємів у кожному блоці. "
                  "Будується з клас210х8: посекундні обʼєми потрібні цілими, "
                  "а в клас210х14х4 вони пішли в знаменник. Перші чотири фічі "
                  "збігаються з клас210х14х4 подія в подію."),
        "features": [
            {"name": "resist", "formula": "Σ14(const_resist) / mean(vol_buy)",
             "unit": "обʼєми"},
            {"name": "d_resist",
             "formula": "Σ14(resist_plus − resist_minus) / mean(vol_buy)",
             "unit": "обʼєми"},
            {"name": "support", "formula": "Σ14(const_support) / mean(vol_sell)",
             "unit": "обʼєми"},
            {"name": "d_support",
             "formula": "Σ14(support_plus − support_minus) / mean(vol_sell)",
             "unit": "обʼєми"},
            {"name": "vol_balance",
             "formula": ("(Σ14(vol_buy) − Σ14(vol_sell))"
                         " / (Σ14(vol_buy) + Σ14(vol_sell))"),
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x14x3",
        "name": "клас210х14х3",
        "parent": "клас210х14х5",
        "shape": [N_BLOCKS, len(class210x14x3.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x14x3.py",
        "dataset": "class210x14x3",
        "loader": class210x14x3.load,
        "about": ("Клас210х14х2 плюс баланс обʼємів у кожному блоці — увесь "
                  "стан блоку трьома безрозмірними числами: хто сильніший у "
                  "стакані, куди він рухається і хто сильніший в обʼємах. "
                  "Будується з клас210х14х5: перші дві фічі рахує той самий "
                  "код, що будує клас210х14х2, третя береться колонкою як є."),
        "features": [
            {"name": "balance",
             "formula": "(resist − support) / (|resist| + |support|)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance",
             "formula": "(d_resist − d_support) / (|d_resist| + |d_support|)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "vol_balance",
             "formula": ("(Σ14(vol_buy) − Σ14(vol_sell))"
                         " / (Σ14(vol_buy) + Σ14(vol_sell))"),
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x14x4c",
        "name": "клас210х14х4ц",
        "parent": "клас210х14х3",
        "shape": [N_BLOCKS, len(class210x14x4c.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x14x4c.py",
        "dataset": "class210x14x4c",
        "loader": class210x14x4c.load,
        "about": ("Клас210х14х3 плюс цінова фіча — ціна, оброблена тим самим "
                  "правилом, що й решта: нормована різниця руху вгору й руху "
                  "вниз у межах блоку з 14 секунд. Модуль близький до 1 — рух "
                  "без відкатів, близький до 0 — топтання на місці. Блок, де "
                  "ціна не змінилась жодної секунди, дає NaN; подія лишається."),
        "features": [
            {"name": "balance",
             "formula": "(resist − support) / (|resist| + |support|)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance",
             "formula": "(d_resist − d_support) / (|d_resist| + |d_support|)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "vol_balance",
             "formula": ("(Σ14(vol_buy) − Σ14(vol_sell))"
                         " / (Σ14(vol_buy) + Σ14(vol_sell))"),
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "price_balance",
             "formula": ("(Σ up − Σ down) / (Σ up + Σ down) = (кінець блоку"
                         " − початок блоку) / Σ|посекундних змін|"),
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x210x3",
        "name": "клас210х210х3",
        "parent": "клас210х14х3",
        "shape": [len(class210x210x3.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x210x3.py",
        "dataset": "class210x210x3",
        "loader": class210x210x3.load,
        "about": ("Клас210х14х3, усереднений по всій події: кожна фіча — "
                  "середнє по всіх 15 блоках, тобто по всіх 210 секундах. "
                  "Крок дорівнює довжині події, звідси 210х210 в імені. Три "
                  "числа на подію — весь її стан одним вектором: куди "
                  "схилений стакан, куди він рухається і куди схилені обʼєми."),
        "features": [
            {"name": "balance", "formula": "mean15(balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance", "formula": "mean15(d_balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "vol_balance", "formula": "mean15(vol_balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x210x4c",
        "name": "клас210х210х4ц",
        "parent": "клас210х14х4ц",
        "shape": [len(class210x210x4c.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x210x4c.py",
        "dataset": "class210x210x4c",
        "loader": class210x210x4c.load,
        "about": ("Клас210х14х4ц, усереднений по всій події — те саме, що "
                  "клас210х210х3, тільки фіч чотири. NaN у блоці робить NaN "
                  "усю фічу події."),
        "features": [
            {"name": "balance", "formula": "mean15(balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance", "formula": "mean15(d_balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "vol_balance", "formula": "mean15(vol_balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "price_balance", "formula": "mean15(price_balance_j)",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210ema4",
        "name": "клас210ема4",
        "parent": "клас210х210х3",
        "shape": [len(class210ema4.FEATURES)],
        "unit": "ціна в quote (USDT) + три безрозмірні",
        "script": "rules/scripts/class210ema4.py",
        "dataset": "class210ema4",
        "loader": class210ema4.load,
        "about": ("Чотири експоненційні середні на подію: ЕМА ціни й ЕМА "
                  "трьох фіч клас210х210х3. Формула alpha = 2 / (період + 1), "
                  "старт із першого значення ряду. Період — параметр побудови "
                  "й зберігається разом з даними, типово 200 подій ≈ 11 год "
                  "40 хв. ЕМА дивиться тільки назад, ряд наскрізний за часом."),
        "features": [
            {"name": "ema_price", "formula": "ЕМА(price_open)",
             "unit": "quote (USDT)"},
            {"name": "ema_balance", "formula": "ЕМА(balance)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "ema_d_balance", "formula": "ЕМА(d_balance)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "ema_vol_balance", "formula": "ЕМА(vol_balance)",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210ema4c",
        "name": "клас210ема4ц",
        "parent": "клас210х210х4ц",
        "shape": [len(class210ema4c.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210ema4c.py",
        "dataset": "class210ema4c",
        "loader": class210ema4c.load,
        "about": ("Те саме, що клас210ема4, з однією різницею: замість ЕМА "
                  "самої ціни — ЕМА цінової фічі, тому всі чотири ряди "
                  "безрозмірні й в одному масштабі. Формат .npz той самий, "
                  "тому скрипти аналізу читають обидва класи однаково."),
        "features": [
            {"name": "ema_balance", "formula": "ЕМА(balance)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "ema_d_balance", "formula": "ЕМА(d_balance)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "ema_vol_balance", "formula": "ЕМА(vol_balance)",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "ema_price_balance", "formula": "ЕМА(price_balance)",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x4bema10x10x130",
        "name": "клас210х4бема10х10х130",
        "parent": "клас210х210х4ц",
        "shape": [len(class210x4bema10x10x130.PERIODS),
                  len(class210x4bema10x10x130.FEATURES)],
        "unit": "безрозмірні, [−1, 1]",
        "script": "rules/scripts/class210x4bema10x10x130.py",
        "dataset": "class210x4bema10x10x130",
        "loader": class210x4bema10x10x130.load,
        "about": ("Клас для навчання. Чотири безрозмірні фічі клас210х210х4ц, "
                  "кожна взята тринадцятьма ЕМА: періоди 10, 20 … 130 подій "
                  "(0.6 … 7.6 год). Рядок події — період, колонка — фіча. "
                  "Цілі в клас не входять: вони лежать поруч файлами "
                  "<вибірка>_targets.npz (rules/scripts/zigzag_targets.py)."),
        "features": [
            {"name": "balance", "formula": "ема_p(balance), p = 10 … 130",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "d_balance", "formula": "ема_p(d_balance), p = 10 … 130",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "vol_balance",
             "formula": "ема_p(vol_balance), p = 10 … 130",
             "unit": "безрозмірна, [−1, 1]"},
            {"name": "price_balance",
             "formula": "ема_p(price_balance), p = 10 … 130",
             "unit": "безрозмірна, [−1, 1]"},
        ],
    },
    {
        "id": "class210x10x9",
        "name": "клас210х10х9",
        "parent": "клас210х8",
        "shape": [class210x10x9.N_BLOCKS, len(class210x10x9.FEATURES)],
        "unit": "як у вихідному CSV",
        "script": "rules/scripts/class210x10x9.py",
        "dataset": "class210x10x9",
        "loader": class210x10x9.load,
        "about": ("Ті самі 210 секунд, що в клас210х8, але разом з 8 фічами "
                  "береться й price_avg — 9 фіч. Секунди зводяться в 10 "
                  "блоків по 21 секунді, значення блоку — середнє за блок. "
                  "Проміжний клас: з нього рахується клас210х10х7. Разом з "
                  "подією зберігаються час початку й час кінця — у навчанні "
                  "вони участі не беруть."),
        "features": [{"name": name, "formula": f"Σ21({name}) / 21",
                      "unit": ("base (BTC)" if name.startswith("vol")
                               else "quote (USDT)" if name == "price_avg"
                               else "—")}
                     for name in class210x10x9.FEATURES],
    },
    {
        "id": "class210x10x7",
        "name": "клас210х10х7",
        "parent": "клас210х10х9",
        "shape": [class210x10x9.N_BLOCKS, len(class210x10x7.FEATURES)],
        "unit": "обʼєми блоку + обʼєм + ціна",
        "script": "rules/scripts/class210x10x7.py",
        "dataset": "class210x10x7",
        "loader": class210x10x7.load,
        "about": ("Рівні стакана діляться на обʼєм свого ж блоку, і з девʼяти "
                  "фіч лишається сім. Перші чотири — безрозмірні, одиниці "
                  "обʼємів у них скорочуються; обʼєми й ціна лишаються як є. "
                  "Блок з нульовим обʼємом дає NaN, подія лишається."),
        "features": [
            {"name": "resist", "formula": "const_resist / vol_buy",
             "unit": "обʼєми блоку"},
            {"name": "bal_resist",
             "formula": "(resist_plus − resist_minus) / vol_buy",
             "unit": "обʼєми блоку"},
            {"name": "support", "formula": "const_support / vol_sell",
             "unit": "обʼєми блоку"},
            {"name": "bal_support",
             "formula": "(support_plus − support_minus) / vol_sell",
             "unit": "обʼєми блоку"},
            {"name": "vol_buy", "formula": "середнє блоку як є",
             "unit": "base (BTC)"},
            {"name": "vol_sell", "formula": "середнє блоку як є",
             "unit": "base (BTC)"},
            {"name": "price_avg", "formula": "середнє блоку як є",
             "unit": "quote (USDT)"},
        ],
    },
    {
        "id": "class210x10x7dc",
        "name": "клас210х10х7дц",
        "parent": "клас210х10х7",
        "shape": [class210x10x9.N_BLOCKS, len(class210x10x7dc.FEATURES)],
        "unit": "приріст за 21 секунду",
        "script": "rules/scripts/class210x10x7dc.py",
        "dataset": "class210x10x7dc",
        "loader": class210x10x7dc.load,
        "about": ("Перші похідні фіч клас210х10х7 по блоках: d[j] = x[j] − "
                  "x[j−1], індекс у похідної — наступного блоку. Перший блок "
                  "бере попереднє значення з останнього блоку попередньої "
                  "події, якщо вона стоїть впритул; на початку датасету і "
                  "після розриву даних перша похідна дорівнює середньому "
                  "трьох наступних похідних цієї ж події."),
        "features": [
            {"name": f"d_{name}", "formula": f"{name}[j] − {name}[j−1]",
             "unit": "приріст фічі за 21 секунду"}
            for name in class210x10x7.FEATURES],
    },
    {
        "id": "class210x10m1x7dc",
        "name": "клас210х10-1х7дц",
        "parent": "клас210х10х7дц",
        "shape": [class210x10m1x7dc.N_BLOCKS,
                  len(class210x10m1x7dc.FEATURES)],
        "unit": "приріст за 21 секунду",
        "script": "rules/scripts/class210x10m1x7dc.py",
        "dataset": "class210x10m1x7dc",
        "loader": class210x10m1x7dc.load,
        "about": ("Клас210х10х7дц без першої плашки. Лишаються тільки девʼять "
                  "чистих похідних — тих, що цілком порахувались усередині "
                  "події й не залежать ні від попередньої події, ні від "
                  "правила розриву."),
        "features": [
            {"name": f"d_{name}", "formula": f"{name}[j] − {name}[j−1]",
             "unit": "приріст фічі за 21 секунду"}
            for name in class210x10x7.FEATURES],
    },
    {
        "id": "class210x10m1x3p1dc",
        "name": "клас210х10-1х3+1дц",
        "parent": "клас210х10-1х7дц",
        "shape": [class210x10m1x3p1dc.N_BLOCKS,
                  len(class210x10m1x3p1dc.FEATURES)],
        "unit": "безрозмірні [−1, 1] + приріст ціни",
        "script": "rules/scripts/class210x10m1x3p1dc.py",
        "dataset": "class210x10m1x3p1dc",
        "loader": class210x10m1x3p1dc.load,
        "about": ("Шість фіч клас210х10-1х7дц ідуть парами «опір проти "
                  "підтримки», і кожна пара згортається в нормовану різницю "
                  "модулів. Сьома фіча, ціна, пари не має і переноситься як "
                  "є — звідси 3+1 в імені. Модулі в чисельнику міняють "
                  "питання: фіча каже, чия сторона сильніше зрушила, а не "
                  "куди. Блок, де обидві похідні пари нульові, дає NaN."),
        "features": [
            {"name": name,
             "formula": f"(|{a}| − |{b}|) / (|{a}| + |{b}|)",
             "unit": "безрозмірна, [−1, 1]"}
            for name, a, b in class210x10m1x3p1dc.PAIRS
        ] + [
            {"name": name, "formula": "переноситься з батька як є",
             "unit": "приріст ціни за 21 секунду"}
            for name in class210x10m1x3p1dc.CARRIED
        ],
    },
    {
        "id": "class210x10m1x2d",
        "name": "клас210х10-1х2д",
        "parent": "клас210х10-1х7дц",
        "shape": [class210x10m1x2d.N_BLOCKS,
                  len(class210x10m1x2d.FEATURES)],
        "unit": "безрозмірні відношення похідних",
        "script": "rules/scripts/class210x10m1x2d.py",
        "dataset": "class210x10m1x2d",
        "loader": class210x10m1x2d.load,
        "about": ("Кожна сторона книги згортається в одну фічу: похідна "
                  "обʼєму ділиться на похідну свого рівня. Ціни в класі "
                  "немає. Блок з нульовим знаменником дає NaN. Відношення "
                  "не обмежене: коли рівень майже не зрушив, значення "
                  "велике, тому міри на цьому класі рангові."),
        "features": [
            {"name": name, "formula": f"{top} / {bottom}",
             "unit": "безрозмірна"}
            for name, top, bottom in class210x10m1x2d.RATIOS],
    },
    {
        "id": "class210x10m1x7dd",
        "name": "клас210х10-1х7д/д",
        "parent": "клас210х10-1х7дц",
        "shape": [class210x10m1x7dd.N_BLOCKS,
                  len(class210x10m1x7dd.FEATURES)],
        "unit": "безрозмірні відношення похідних + приріст ціни",
        "script": "rules/scripts/class210x10m1x7dd.py",
        "dataset": "class210x10m1x7dd",
        "loader": class210x10m1x7dd.load,
        "about": ("Розширення клас210х10-1х2д: до двох фіч «обʼєм на свій "
                  "рівень» додані чотири зворотні — «рівень на свій обʼєм», "
                  "і перенесена ціна. д/д — похідна на похідну: чисельник і "
                  "знаменник в однакових одиницях, тому перші шість фіч "
                  "безрозмірні. Кожна велика там, де малий її власний "
                  "знаменник. Блок з нульовим знаменником дає NaN."),
        "features": [
            {"name": name, "formula": f"{top} / {bottom}",
             "unit": "безрозмірна"}
            for name, top, bottom in class210x10m1x7dd.RATIOS
        ] + [
            {"name": name, "formula": "переноситься з батька як є",
             "unit": "приріст ціни за 21 секунду"}
            for name in class210x10m1x7dd.CARRIED
        ],
    },
]


# Скейлери поруч із сирим розподілом (rules/scripts/scalers.py).
SCALERS = {"robust": scalers.robust, "quantile": scalers.quantile}

# Колонки розподілу на вкладці. Вкладка малює їх по цьому переліку, тому
# новий скейлер додається тут і в SCALERS — розмітку правити не треба.
DISTRIBUTIONS = [
    {"id": "hist", "name": "розподіл",
     "formula": "сирі значення фічі, без перетворень"},
    {"id": "robust", "name": "робаст",
     "formula": "(x − медіана) / (q75 − q25)"},
    {"id": "quantile", "name": "квантиль",
     "formula": "місце x в емпіричній CDF вибірки, 2u − 1; [−1, 1]"},
]


def histogram(clean: np.ndarray, bins: int = BINS, clip: float = CLIP) -> dict:
    """Гістограма з рівними бінами між квантилями clip і 1 - clip."""
    low, high = (float(np.quantile(clean, clip)),
                 float(np.quantile(clean, 1 - clip)))
    if high <= low:
        high = low + 1e-12
    counts, _ = np.histogram(clean, bins=bins, range=(low, high))
    return {"from": low, "to": high, "counts": [int(v) for v in counts],
            "shown": float(((clean >= low) & (clean <= high)).mean())}


def feature_stats(values: np.ndarray, bins: int = BINS,
                  clip: float = CLIP) -> dict:
    """Межі, квантилі, розкид і гістограми однієї фічі по всіх блоках.

    Гістограм три: сирі значення і ті самі значення після робаст- та
    квантильного скейлера. Скейлери рахуються на цій самій вибірці
    (`train` класу) — вкладка показує, що кожен із них робить з розподілом.
    """
    values = np.asarray(values, dtype=float).ravel()
    nan = int(np.isnan(values).sum())
    clean = values[~np.isnan(values)]
    if not len(clean):
        return {"count": int(len(values)), "nan": nan}
    stats = {
        "count": int(len(values)),
        "nan": nan,
        "min": float(clean.min()),
        "q01": float(np.quantile(clean, 0.01)),
        "median": float(np.median(clean)),
        "q99": float(np.quantile(clean, 0.99)),
        "max": float(clean.max()),
        "std": float(clean.std()),
        "at_bounds": int((np.abs(clean) == 1.0).sum()),
        "hist": histogram(clean, bins, clip),
    }
    for name, scale in SCALERS.items():
        scaled, params = scale(clean)
        stats[name] = dict(params, hist=histogram(scaled, bins, clip),
                           min=float(scaled.min()), max=float(scaled.max()),
                           median=float(np.median(scaled)),
                           std=float(scaled.std()))
    return stats


def dataset_card(item: dict, root: Path, pair: str) -> dict:
    """Числа класу з його датасету: розміри вибірок, звіт, статистика фіч."""
    card = {key: value for key, value in item.items() if key != "loader"}
    if not item["dataset"]:
        return card
    folder = root / "data" / "datasets" / pair / item["dataset"]
    card["dataset"] = f"data/datasets/{pair}/{item['dataset']}/"
    card["ready"] = folder.exists()
    if not card["ready"]:
        return card

    report = folder / "report.json"
    card["report"] = (json.loads(report.read_text(encoding="utf-8"))
                      if report.exists() else None)
    card["samples"] = {}
    for name in PARTS:
        path = folder / f"{name}.npz"
        if path.exists():
            card["samples"][name] = int(len(item["loader"](path)))

    train = item["loader"](folder / "train.npz")
    values = np.asarray(train.x, dtype=float)
    if values.ndim == 2:          # подія вже вектор: один блок на всі 210 с
        values = values[:, None, :]
    card["events"] = int(len(train))
    card["blocks_per_event"] = int(values.shape[1])
    card["period"] = {"from": int(train.timestamp.min()),
                      "to": int(train.timestamp.max())}
    if hasattr(train, "period"):
        card["ema_period"] = int(train.period)
    if hasattr(train, "periods"):
        card["ema_periods"] = [int(v) for v in train.periods]
    for index, feature in enumerate(card["features"]):
        feature["stats"] = feature_stats(values[:, :, index])
    return card


def build(pair: str = "BTC_USDT", root: Path = PROJECT_ROOT) -> dict:
    """Картки всіх класів."""
    payload = {
        "pair": pair,
        "script": "rules/scripts/class_card.py",
        "command": f"python3 rules/scripts/class_card.py --pair {pair}",
        "rules": "rules/01-data-and-db.md",
        "event_length": EVENT_LENGTH,
        "block": BLOCK,
        "blocks": N_BLOCKS,
        "source_columns": SOURCE_COLUMNS,
        "naming": ("клас<довжина>х<крок>х<кількість фіч>; суфікс х8 означає, "
                   "що клас побудований на початковому датасеті"),
        "note": ("Формули — з rules/01-data-and-db.md. Межі, квантилі, розкид "
                 "і гістограми виміряні на вибірці train відповідного класу."),
        "distributions": DISTRIBUTIONS,
        "classes": [dataset_card(item, root, pair) for item in CLASSES],
    }
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    payload = build(args.pair)
    out = args.out or (PROJECT_ROOT / "data" / "datasets" / args.pair
                       / "cards.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    for card in payload["classes"]:
        shape = "×".join(str(v) for v in card["shape"])
        events = card.get("events")
        print(f"{card['name']:14s} {shape:8s} фіч {len(card['features'])}"
              + (f", train {events}" if events else ", датасет не зберігається"))
    print(f"записано {out.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
