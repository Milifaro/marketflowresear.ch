"""клас210х14х5 — клас210х14х4 плюс баланс обʼємів по блоках.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х5

Будується з `клас210х8`: перші чотири фічі — точно ті самі, що в
`клас210х14х4`, пʼята рахується з посекундних обʼємів, яких у `клас210х14х4`
вже немає (вони там пішли в знаменник).

Поблочно, для кожного з 15 блоків по 14 секунд:

    resist      = Σ14(const_resist)                 / mean(vol_buy)
    d_resist    = Σ14(resist_plus  - resist_minus)  / mean(vol_buy)
    support     = Σ14(const_support)                / mean(vol_sell)
    d_support   = Σ14(support_plus - support_minus) / mean(vol_sell)
    vol_balance = (Σ14(vol_buy) - Σ14(vol_sell)) / (Σ14(vol_buy) + Σ14(vol_sell))

- 5 фіч × 15 значень. Форма події: (15, 5).
- `vol_balance` безрозмірна, межі [-1, 1]: `+1` — тільки покупки, `-1` —
  тільки продажі, `0` — порівну. Сума і середнє в блоці дають те саме
  число (обидва діляться на 14), тому формула збігається з
  `(mean(vol_buy) - mean(vol_sell)) / (mean(vol_buy) + mean(vol_sell))`
  по блоку.
- Подія з нульовим `mean(vol_buy)` або `mean(vol_sell)` за 210 с
  відкидається, як і в `клас210х14х4`.
- Блок, де обидва обʼєми нульові, дає `NaN` — подія лишається, кількість
  таких блоків фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x14x4
from class210x8 import EVENT_LENGTH, FEATURES as PARENT_FEATURES, Class210x8
from class210x14x4 import BLOCK, N_BLOCKS

FEATURES = list(class210x14x4.FEATURES) + ["vol_balance"]

_P = {name: i for i, name in enumerate(PARENT_FEATURES)}


@dataclass
class Class210x14x5:
    """Набір подій клас210х14х5."""

    x: np.ndarray            # (N, 15, 5)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    dropped_zero_volume: int
    events_out: int
    nan_vol_balance: int     # блоків, де обидва обʼєми нульові


def _block_sums(values: np.ndarray) -> np.ndarray:
    """(N, 210) -> (N, 15): суми по блоках з 14 секунд."""
    return values.reshape(len(values), N_BLOCKS, BLOCK).sum(axis=2)


def volume_balance(parent: Class210x8) -> np.ndarray:
    """(N, 210, 8) -> (N, 15): баланс обʼємів у кожному блоці, межі [-1, 1]."""
    buy = _block_sums(parent.x[:, :, _P["vol_buy"]].astype(float))
    sell = _block_sums(parent.x[:, :, _P["vol_sell"]].astype(float))
    with np.errstate(invalid="ignore", divide="ignore"):
        return (buy - sell) / (buy + sell)


def build(parent: Class210x8) -> tuple[Class210x14x5, BuildReport]:
    """Будує клас210х14х5 з клас210х8."""
    if parent.x.ndim != 3 or parent.x.shape[1:] != (EVENT_LENGTH,
                                                    len(PARENT_FEATURES)):
        raise ValueError(
            f"очікується масив (N, {EVENT_LENGTH}, {len(PARENT_FEATURES)})")

    four, four_report = class210x14x4.build(parent)
    # той самий відбір, що всередині клас210х14х4: ділення на обʼєми можливе
    mean_buy = parent.x[:, :, _P["vol_buy"]].mean(axis=1)
    mean_sell = parent.x[:, :, _P["vol_sell"]].mean(axis=1)
    keep = (mean_buy != 0) & (mean_sell != 0)
    if not np.array_equal(parent.timestamp[keep], four.timestamp):
        raise ValueError("відбір подій розійшовся з клас210х14х4")
    balance = volume_balance(parent)[keep]

    dataset = Class210x14x5(
        x=np.concatenate([four.x.astype(float), balance[:, :, None]], axis=2),
        timestamp=four.timestamp,
        price_open=four.price_open,
        price_close=four.price_close,
    )
    report = BuildReport(
        events_in=four_report.events_in,
        dropped_zero_volume=four_report.dropped_zero_volume,
        events_out=len(dataset),
        nan_vol_balance=int(np.isnan(balance).sum()),
    )
    return dataset, report


def save(dataset: Class210x14x5, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x14x5:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x14x5(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
