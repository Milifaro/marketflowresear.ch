"""клас210х10-1х7дц — клас210х10х7дц без першої плашки.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10-1х7дц

Перший блок `клас210х10х7дц` — єдиний, чия похідна не рахується цілком
усередині події: вона або перейшла через межу з попередньої події, або
на розриві взята середнім наступних трьох. Цей клас його прибирає й
лишає **тільки чисті похідні**.

Форма події: `(9, 7)`. Фічі й порядок ті самі, що в батька.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x10x7dc
from class210x10x7dc import Class210x10x7dc

FEATURES = list(class210x10x7dc.FEATURES)
N_BLOCKS = class210x10x7dc.N_BLOCKS - 1          # 9


@dataclass
class Class210x10m1x7dc:
    """Набір подій клас210х10-1х7дц."""

    x: np.ndarray            # (N, 9, 7)
    t_start: np.ndarray      # (N,)
    t_end: np.ndarray        # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        return self.t_start


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_values: int


def build(parent: Class210x10x7dc) -> tuple[Class210x10m1x7dc, BuildReport]:
    """Прибирає перший блок кожної події."""
    if parent.x.ndim != 3 or parent.x.shape[1] != class210x10x7dc.N_BLOCKS:
        raise ValueError(
            f"очікується масив (N, {class210x10x7dc.N_BLOCKS}, F)")
    value = parent.x[:, 1:, :]
    dataset = Class210x10m1x7dc(
        x=value,
        t_start=parent.t_start,
        t_end=parent.t_end,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    report = BuildReport(events_in=len(parent), events_out=len(dataset),
                         nan_values=int(np.isnan(value).sum()))
    return dataset, report


def take(dataset: Class210x10m1x7dc, index: np.ndarray) -> Class210x10m1x7dc:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10m1x7dc(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10m1x7dc, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10m1x7dc:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10m1x7dc(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
