"""клас210х210х4ц — клас210х14х4ц, усереднений по всій події.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х210х4ц

Те саме, що `клас210х210х3`, тільки фіч чотири: до трьох безрозмірних
додана цінова. Кожна фіча — середнє по всіх 15 блоках по 14 секунд:

    balance       = mean15(balance_j)
    d_balance     = mean15(d_balance_j)
    vol_balance   = mean15(vol_balance_j)
    price_balance = mean15(price_balance_j)

- **4 фічі × 1 значення.** Форма події: `(4,)`.
- Усі чотири безрозмірні, межі `[-1, 1]`.
- `NaN` у блоці робить `NaN` усю фічу події: середнє не перескакує
  пропуск. Кількість фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210x14x4 import N_BLOCKS
from class210x14x4c import Class210x14x4c, FEATURES as PARENT_FEATURES

FEATURES = list(PARENT_FEATURES)
EVENT_LENGTH = 210      # крок = довжина події: один блок на всю подію


@dataclass
class Class210x210x4c:
    """Набір подій клас210х210х4ц."""

    x: np.ndarray            # (N, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_by_feature: dict


def build(parent: Class210x14x4c) -> tuple[Class210x210x4c, BuildReport]:
    """Будує клас210х210х4ц з клас210х14х4ц."""
    if parent.x.ndim != 3 or parent.x.shape[1:] != (N_BLOCKS, len(FEATURES)):
        raise ValueError(f"очікується масив (N, {N_BLOCKS}, {len(FEATURES)})")

    x = np.asarray(parent.x, dtype=float).mean(axis=1)
    dataset = Class210x210x4c(
        x=x, timestamp=parent.timestamp, price_open=parent.price_open,
        price_close=parent.price_close)
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_by_feature={name: int(np.isnan(x[:, i]).sum())
                        for i, name in enumerate(FEATURES)},
    )
    return dataset, report


def save(dataset: Class210x210x4c, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x210x4c:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x210x4c(
            x=data["x"], timestamp=data["timestamp"],
            price_open=data["price_open"], price_close=data["price_close"],
            features=list(data["features"]))
