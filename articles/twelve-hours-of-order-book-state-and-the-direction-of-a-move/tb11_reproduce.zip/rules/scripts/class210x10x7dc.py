"""клас210х10х7дц — перші похідні фіч клас210х10х7 по блоках.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10х7дц

`д` — похідна, `ц` — у фічах є ціна (`price_avg` батька, тут `d_price_avg`).

Похідна — різниця між наступним і попереднім значенням, індекс у неї
**наступного**:

    d[j] = x[j] − x[j−1],     j = 2 … 10

Перший блок попереднього значення у своїй події не має — воно береться
з **попередньої події**, якщо вона стоїть впритул (`t_start` різняться
рівно на 210 секунд):

    d[1] = x[1] − x_попередньої[10]

Перша подія датасету і перша подія після розриву даних попередньої не
мають. Для них перша похідна дорівнює середньому арифметичному трьох
наступних похідних тієї самої фічі в цій же події:

    d[1] = (d[2] + d[3] + d[4]) / 3

Такі події позначені прапорцем `seam`.

Форма події: `(10, 7)`. Імена фіч — імена батька з префіксом `d_`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x10x7
from class210x10x9 import EVENT_LENGTH, N_BLOCKS
from class210x10x7 import Class210x10x7

FEATURES = [f"d_{name}" for name in class210x10x7.FEATURES]

# Скільки наступних похідних усереднюється замість першої на розриві.
SEAM_BLOCKS = 3


@dataclass
class Class210x10x7dc:
    """Набір подій клас210х10х7дц."""

    x: np.ndarray            # (N, 10, 7)
    t_start: np.ndarray      # (N,)
    t_end: np.ndarray        # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    seam: np.ndarray         # (N,) bool — першу похідну взято з наступних
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        return self.t_start


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    seams: int               # подій без попередньої (початок або розрив)
    linked: int              # подій, чия перша похідна перейшла через межу
    nan_values: int


def linked_mask(t_start: np.ndarray, event_seconds: int = EVENT_LENGTH
                ) -> np.ndarray:
    """(N,) bool: чи стоїть подія впритул до попередньої.

    Події мають іти за часом. Перша подія завжди `False`.
    """
    t_start = np.asarray(t_start, dtype=np.int64)
    if len(t_start) and np.any(np.diff(t_start) <= 0):
        raise ValueError("події мають іти за часом, без повторів")
    linked = np.zeros(len(t_start), dtype=bool)
    if len(t_start) > 1:
        linked[1:] = np.diff(t_start) == event_seconds
    return linked


def derivative(x: np.ndarray, linked: np.ndarray) -> np.ndarray:
    """(N, 10, 7) значень -> (N, 10, 7) похідних за правилом класу."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 3 or x.shape[1] != N_BLOCKS:
        raise ValueError(f"очікується масив (N, {N_BLOCKS}, F)")
    linked = np.asarray(linked, dtype=bool)
    if len(linked) != len(x):
        raise ValueError("прапорець звʼязності має бути на кожну подію")

    out = np.empty_like(x)
    out[:, 1:] = np.diff(x, axis=1)
    # перша похідна: різниця з останнім блоком попередньої події
    out[:, 0] = np.nan
    if len(x) > 1:
        out[1:, 0] = np.where(linked[1:, None], x[1:, 0] - x[:-1, -1], np.nan)
    # розрив: середнє трьох наступних похідних цієї ж події
    seam = ~linked
    if seam.any():
        out[seam, 0] = out[seam, 1:1 + SEAM_BLOCKS].mean(axis=1)
    return out


def build(parent: Class210x10x7) -> tuple[Class210x10x7dc, BuildReport]:
    """Будує клас210х10х7дц з клас210х10х7, відсортованого за часом."""
    linked = linked_mask(parent.t_start)
    value = derivative(parent.x, linked)
    dataset = Class210x10x7dc(
        x=value,
        t_start=parent.t_start,
        t_end=parent.t_end,
        price_open=parent.price_open,
        price_close=parent.price_close,
        seam=~linked,
    )
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        seams=int((~linked).sum()),
        linked=int(linked.sum()),
        nan_values=int(np.isnan(value).sum()),
    )
    return dataset, report


def take(dataset: Class210x10x7dc, index: np.ndarray) -> Class210x10x7dc:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10x7dc(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        seam=dataset.seam[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10x7dc, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        seam=dataset.seam,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10x7dc:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10x7dc(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            seam=data["seam"],
            features=list(data["features"]),
        )
