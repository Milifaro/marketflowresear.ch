"""Ноги датасету: розмітка ряду подій за стандартом rules/02-markup.md.

Хід — стандартний для всього проєкту:

    ряд подій частини -> ема10(price_open) -> півоти зігзага свого порогу
    -> точка кінця ноги (екстремум price_close, ±25 подій) -> ноги

Ряд обрізається по ногах: усе до першого півота і все після останнього
відкидається, бо це не нога, а обрубок. Кожна частина датасету
(`train`, `val`) ріжеться **окремо** — нога не переходить з однієї
в іншу.

Запуск:
    python3 rules/scripts/leg_markup.py
    python3 rules/scripts/leg_markup.py --pairs BTC_USDT --threshold 0.008
    python3 rules/scripts/leg_markup.py --root <тека> --out <файл>

Вихід: data/legs/legs.json — ноги кожної монети й частини та їх статистика.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from build_class210x10x7dc import PAIRS, PARTS
from class210ema4 import ema
from zigzag import OUTER_THRESHOLD, SNAP_SPAN, snap, zigzag

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATASETS = PROJECT_ROOT / "data" / "datasets"
OUT = PROJECT_ROOT / "data" / "legs" / "legs.json"

PERIOD = 10                # ема ціни, на якій стоять півоти
ROW_CLASS = "class210x10x7"    # з якого класу береться ряд подій
HOLE = 3600                # діра в ряді, з якої нога вважається рваною
SHORT = 60                 # нога коротша за стільки подій вважається куцою
STEP = 210                 # крок сітки подій, секунд


def load_part(pair: str, part: str, class_name: str = ROW_CLASS,
              root: Path | None = None) -> dict:
    """Ряд подій однієї частини: час і ціни. Фічі тут не потрібні."""
    path = (root or DATASETS) / pair / class_name / f"{part}.npz"
    with np.load(path) as store:
        key = "t_start" if "t_start" in store else "timestamp"
        stamps = store[key].astype(np.int64)
        opens = store["price_open"].astype(float)
        closes = store["price_close"].astype(float)
    order = np.argsort(stamps, kind="stable")
    return {"pair": pair, "part": part, "t": stamps[order],
            "open": opens[order], "close": closes[order]}


def pivots_of(row: dict, threshold: float = OUTER_THRESHOLD,
              span: int = SNAP_SPAN) -> list:
    """Півоти за стандартом: зігзаг по ема10 і точна точка кінця ноги."""
    smooth = ema(row["open"], PERIOD)
    return snap(zigzag(smooth, threshold), row["close"], span)


def legs_of(row: dict, threshold: float = OUTER_THRESHOLD,
            span: int = SNAP_SPAN) -> list:
    """Ноги частини: відрізки між сусідніми півотами, обидва кінці точні."""
    pivots = pivots_of(row, threshold, span)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        step = np.diff(row["t"][first:last + 1])
        legs.append({"leg": len(legs) + 1,
                     "kind": "up" if pivot.kind == "high" else "down",
                     "first": int(first), "last": int(last),
                     "events": int(last - first + 1),
                     "from": int(row["t"][first]), "to": int(row["t"][last]),
                     "hours": float((row["t"][last] - row["t"][first]) / 3600),
                     "hole_hours": float((step[step > STEP] - STEP).sum() / 3600),
                     "move": float(np.log(row["close"][last]
                                          / row["open"][first]))})
    return legs


def cut(row: dict, legs: list) -> dict:
    """Скільки ряду лишається після обрізання по ногах."""
    count = len(row["t"])
    if not legs:
        return {"events": count, "kept": 0, "head": count, "tail": 0,
                "share": 0.0}
    head = legs[0]["first"]
    tail = count - 1 - legs[-1]["last"]
    kept = legs[-1]["last"] - legs[0]["first"] + 1
    return {"events": count, "kept": int(kept), "head": int(head),
            "tail": int(tail), "share": kept / count if count else 0.0}


def spread(values: np.ndarray) -> dict:
    """Пʼять чисел розподілу: мінімум, квартилі, максимум і середнє."""
    if not len(values):
        return {"min": None, "q25": None, "median": None, "q75": None,
                "max": None, "mean": None}
    return {"min": float(np.min(values)), "q25": float(np.percentile(values, 25)),
            "median": float(np.median(values)),
            "q75": float(np.percentile(values, 75)),
            "max": float(np.max(values)), "mean": float(np.mean(values))}


def stats(row: dict, legs: list) -> dict:
    """Статистика ніг однієї частини однієї монети."""
    events = np.array([leg["events"] for leg in legs], dtype=float)
    hours = np.array([leg["hours"] for leg in legs], dtype=float)
    move = np.array([abs(leg["move"]) for leg in legs], dtype=float)
    up = [leg for leg in legs if leg["kind"] == "up"]
    down = [leg for leg in legs if leg["kind"] == "down"]
    torn = [leg for leg in legs if leg["hole_hours"] * 3600 > HOLE]
    short = [leg for leg in legs if leg["events"] < SHORT]
    return {"pair": row["pair"], "part": row["part"],
            "from": int(row["t"][0]), "to": int(row["t"][-1]),
            "cut": cut(row, legs),
            "legs": len(legs), "up": len(up), "down": len(down),
            "torn": len(torn), "short": len(short),
            "events": spread(events), "hours": spread(hours),
            "move": spread(move),
            "move_up": spread(np.array([leg["move"] for leg in up])),
            "move_down": spread(np.array([leg["move"] for leg in down]))}


def build(pairs=PAIRS, parts=PARTS, class_name: str = ROW_CLASS,
          threshold: float = OUTER_THRESHOLD, span: int = SNAP_SPAN,
          root: Path | None = None) -> dict:
    """Ноги й статистика всіх монет обох частин."""
    rows, table = [], {}
    for pair in pairs:
        for part in parts:
            row = load_part(pair, part, class_name, root)
            legs = legs_of(row, threshold, span)
            table.setdefault(pair, {})[part] = legs
            rows.append(stats(row, legs))
    totals = {}
    for part in parts:
        chosen = [one for one in rows if one["part"] == part]
        every = [leg for pair in table.values() for leg in pair.get(part, [])]
        totals[part] = {
            "pairs": len(chosen), "legs": sum(one["legs"] for one in chosen),
            "up": sum(one["up"] for one in chosen),
            "down": sum(one["down"] for one in chosen),
            "torn": sum(one["torn"] for one in chosen),
            "short": sum(one["short"] for one in chosen),
            "events": sum(one["cut"]["events"] for one in chosen),
            "kept": sum(one["cut"]["kept"] for one in chosen),
            "head": sum(one["cut"]["head"] for one in chosen),
            "tail": sum(one["cut"]["tail"] for one in chosen),
            "length": spread(np.array([leg["events"] for leg in every],
                                      dtype=float)),
            "move": spread(np.array([abs(leg["move"]) for leg in every],
                                    dtype=float))}
    return {"pairs": list(pairs), "parts": list(parts), "class": class_name,
            "threshold": threshold, "span": span, "period": PERIOD,
            "short": SHORT, "hole": HOLE,
            "rows": rows, "totals": totals,
            "legs": {pair: {part: legs for part, legs in parts_.items()}
                     for pair, parts_ in table.items()}}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    parser.add_argument("--parts", nargs="*", default=list(PARTS))
    parser.add_argument("--class", dest="class_name", default=ROW_CLASS)
    parser.add_argument("--threshold", type=float, default=OUTER_THRESHOLD)
    parser.add_argument("--span", type=int, default=SNAP_SPAN)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--root", type=Path, default=None,
                        help="тека датасетів; типово data/datasets")
    args = parser.parse_args()

    result = build(args.pairs, args.parts, args.class_name, args.threshold,
                   args.span, args.root)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    print(f"зігзаг {100 * args.threshold:.1f} %, ема{PERIOD}, "
          f"точка кінця ноги ±{args.span} подій, ряд {args.class_name}\n")
    head = (f"{'монета':11s} {'частина':8s} {'подій':>7s} {'у ногах':>8s} "
            f"{'обрізано':>9s} {'ніг':>5s} {'вгору':>6s} {'вниз':>5s} "
            f"{'подій/ногу':>11s} {'рух':>7s} {'рвані':>6s} {'куці':>5s}")
    print(head)
    for one in result["rows"]:
        cut_one = one["cut"]
        print(f"{one['pair']:11s} {one['part']:8s} {cut_one['events']:7d} "
              f"{100 * cut_one['share']:7.1f} % "
              f"{cut_one['head'] + cut_one['tail']:9d} {one['legs']:5d} "
              f"{one['up']:6d} {one['down']:5d} "
              f"{one['events']['median']:11.0f} "
              f"{100 * one['move']['median']:6.2f} % {one['torn']:6d} "
              f"{one['short']:5d}")
    print()
    for part, one in result["totals"].items():
        print(f"{part}: {one['legs']} ніг ({one['up']} вгору / "
              f"{one['down']} вниз), подій {one['events']}, у ногах "
              f"{one['kept']} ({100 * one['kept'] / one['events']:.1f} %), "
              f"медіана {one['length']['median']:.0f} подій і "
              f"{100 * one['move']['median']:.2f} % руху")
    print(f"\n{args.out}")


if __name__ == "__main__":
    main()
