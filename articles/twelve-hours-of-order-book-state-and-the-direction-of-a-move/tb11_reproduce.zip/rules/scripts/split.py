"""Розбиття датасету на train / val / test.

Правила: rules/01-data-and-db.md → Підготовка основного датасету
         rules/03-models.md → Розбиття даних

- test = 25%, train+val = 75%, окремими файлами.
- train+val ділиться рендомно на 10 нерівних частин, train:val = 4:1
  (8 частин train, 2 частини val).
- Кількість цільових подій у train і val — пропорційна та рівномірно
  розподілена (розбиття робиться в межах кожного класу міток).
- Розбиття робиться ПЕРШИМ, до будь-яких дій над датасетом.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations

import numpy as np

N_PARTS = 10
VAL_PARTS = 2          # train:val = 4:1  ->  8:2
TEST_FRACTION = 0.25
MIN_PART_FRACTION = 0.5  # мін. розмір частини = 0.5 середньої (частини нерівні)


@dataclass
class Split:
    """Індекси подій по вибірках."""

    train: np.ndarray
    val: np.ndarray
    test: np.ndarray
    parts: list[np.ndarray]  # 10 частин train+val

    def sizes(self) -> dict[str, int]:
        return {"train": len(self.train), "val": len(self.val),
                "test": len(self.test)}


def _label_groups(n: int, labels: np.ndarray | None) -> list[np.ndarray]:
    """Групи індексів по мітках. Без міток — одна група."""
    if labels is None:
        return [np.arange(n)]
    labels = np.asarray(labels)
    if len(labels) != n:
        raise ValueError("довжина labels не збігається з кількістю подій")
    return [np.flatnonzero(labels == v) for v in np.unique(labels)]


def random_part_weights(k: int, rng: np.random.Generator) -> np.ndarray:
    """k нерівних ваг, що дають у сумі 1. Мінімальна вага — MIN_PART_FRACTION/k."""
    if k < 1:
        raise ValueError("k має бути >= 1")
    floor = MIN_PART_FRACTION / k
    return floor + rng.dirichlet(np.ones(k)) * (1.0 - floor * k)


def sizes_from_weights(n: int, weights: np.ndarray,
                       rng: np.random.Generator) -> list[int]:
    """Розміри частин за вагами; сума точно дорівнює n, порожніх частин немає."""
    k = len(weights)
    if n < k:
        raise ValueError(f"подій ({n}) менше, ніж частин ({k})")
    sizes = np.maximum(1, np.floor(weights * n).astype(int))
    while sizes.sum() > n:  # відняти зайве у найбільших частин
        sizes[np.argmax(sizes)] -= 1
    for i in rng.permutation(k)[: n - int(sizes.sum())]:
        sizes[i] += 1
    return [int(s) for s in sizes]


def random_part_sizes(n: int, k: int, rng: np.random.Generator) -> list[int]:
    """k нерівних рендомних розмірів, що дають у сумі n."""
    return sizes_from_weights(n, random_part_weights(k, rng), rng)


def choose_val_parts(parts: list[np.ndarray],
                     rng: np.random.Generator) -> set[int]:
    """Обирає VAL_PARTS частин, сумарний розмір яких найближчий до 1/(1+4).

    Частини нерівні, тому val береться не «будь-які дві», а та комбінація,
    що дає відношення train:val якнайближче до 4:1.
    """
    sizes = np.array([len(p) for p in parts], dtype=float)
    target = sizes.sum() * VAL_PARTS / N_PARTS
    combos = list(combinations(range(len(parts)), VAL_PARTS))
    error = np.array([abs(sizes[list(c)].sum() - target) for c in combos])
    best = np.flatnonzero(error == error.min())
    return set(combos[int(rng.choice(best))])


def split_dataset(n_events: int, labels: np.ndarray | None = None,
                  seed: int = 0) -> Split:
    """Повертає розбиття train / val / test за правилами проєкту."""
    rng = np.random.default_rng(seed)
    test_idx, parts = [], [[] for _ in range(N_PARTS)]
    # Ваги спільні для всіх міток — так частки цільових подій у частинах рівні.
    weights = random_part_weights(N_PARTS, rng)

    for group in _label_groups(n_events, labels):
        group = rng.permutation(group)
        n_test = int(round(len(group) * TEST_FRACTION))
        test_idx.append(group[:n_test])

        pool = group[n_test:]
        offset = 0
        for part, size in zip(parts, sizes_from_weights(len(pool), weights, rng)):
            part.append(pool[offset:offset + size])
            offset += size

    parts = [np.concatenate(p) for p in parts]
    val_ids = choose_val_parts(parts, rng)
    val_parts = [parts[i] for i in val_ids]
    train_parts = [p for i, p in enumerate(parts) if i not in val_ids]

    return Split(
        train=np.sort(np.concatenate(train_parts)),
        val=np.sort(np.concatenate(val_parts)),
        test=np.sort(np.concatenate(test_idx)),
        parts=parts,
    )


def production_split(n_events: int, labels: np.ndarray | None = None,
                     seed: int = 0) -> Split:
    """Розбиття для продакшен-моделі: правила train/val, але зі 100% датасету.

    Валідаційна частина виключається — усі дані йдуть у train
    (rules/03-models.md → Типи мереж → Продакшен).
    """
    rng = np.random.default_rng(seed)
    parts = [[] for _ in range(N_PARTS)]
    weights = random_part_weights(N_PARTS, rng)
    for group in _label_groups(n_events, labels):
        group = rng.permutation(group)
        offset = 0
        for part, size in zip(parts, sizes_from_weights(len(group), weights, rng)):
            part.append(group[offset:offset + size])
            offset += size

    parts = [np.concatenate(p) for p in parts]
    return Split(
        train=np.sort(np.concatenate(parts)),
        val=np.empty(0, dtype=int),
        test=np.empty(0, dtype=int),
        parts=parts,
    )
