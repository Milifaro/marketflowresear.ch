"""клас210х10х9 — подія з 210 секунд у 10 блоках по 21 секунді.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10х9

Подія — ті самі 210 секунд безперервної історії, що й у `клас210х8`, але
разом з 8 фічами береться ще й `price_avg`: **9 фіч**. Секунди зводяться
в 10 блоків по 21 секунді, значення блоку — **середнє за блок**:

    x[j, f] = Σ21(f) / 21

Форма події: `(10, 9)`.

Додатково з подією зберігаються (не для навчання): час початку `t_start`
і час кінця `t_end` події, а також `price_open` / `price_close`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210x8 import EVENT_LENGTH, PRICE_IDX, TS_IDX, contiguous_segments
from data_source import SOURCE_COLUMNS

BLOCK = 21
N_BLOCKS = EVENT_LENGTH // BLOCK          # 10

# 8 фіч клас210х8 плюс ціна — порядок фіксований і не міняється.
FEATURES = [
    "const_resist",
    "resist_plus",
    "resist_minus",
    "const_support",
    "support_plus",
    "support_minus",
    "vol_buy",
    "vol_sell",
    "price_avg",
]

FEATURE_IDX = [SOURCE_COLUMNS.index(name) for name in FEATURES]


@dataclass
class Class210x10x9:
    """Набір подій клас210х10х9."""

    x: np.ndarray            # (N, 10, 9)
    t_start: np.ndarray      # (N,) — перша секунда події
    t_end: np.ndarray        # (N,) — остання секунда події
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        """Синонім `t_start` — так подію адресує решта класів."""
        return self.t_start


def block_mean(seconds: np.ndarray) -> np.ndarray:
    """(N, 210, F) посекундних значень -> (N, 10, F) середніх по блоках."""
    seconds = np.asarray(seconds, dtype=float)
    if seconds.ndim != 3 or seconds.shape[1] != EVENT_LENGTH:
        raise ValueError(f"очікується масив (N, {EVENT_LENGTH}, F)")
    return seconds.reshape(len(seconds), N_BLOCKS, BLOCK,
                           seconds.shape[2]).mean(axis=2)


def build(rows: np.ndarray, step: int = EVENT_LENGTH) -> Class210x10x9:
    """Будує події з масиву у порядку SOURCE_COLUMNS.

    step=210 (за замовчуванням) — події не перекриваються.
    """
    rows = np.asarray(rows, dtype=float)
    if rows.ndim != 2 or rows.shape[1] != len(SOURCE_COLUMNS):
        raise ValueError(f"очікується масив (N, {len(SOURCE_COLUMNS)})")
    if step < 1:
        raise ValueError("step має бути >= 1")

    windows, starts = [], []
    ts = rows[:, TS_IDX]
    for lo, hi in contiguous_segments(ts):
        for begin in range(lo, hi - EVENT_LENGTH + 1, step):
            windows.append(rows[begin:begin + EVENT_LENGTH, FEATURE_IDX])
            starts.append(begin)

    if not windows:
        return empty()

    idx = np.asarray(starts)
    return Class210x10x9(
        x=block_mean(np.stack(windows)),
        t_start=ts[idx].astype(np.int64),
        t_end=ts[idx + EVENT_LENGTH - 1].astype(np.int64),
        price_open=rows[idx, PRICE_IDX],
        price_close=rows[idx + EVENT_LENGTH - 1, PRICE_IDX],
    )


def empty() -> Class210x10x9:
    """Порожній набір потрібної форми."""
    return Class210x10x9(
        x=np.empty((0, N_BLOCKS, len(FEATURES)), dtype=np.float64),
        t_start=np.empty(0, dtype=np.int64),
        t_end=np.empty(0, dtype=np.int64),
        price_open=np.empty(0, dtype=np.float64),
        price_close=np.empty(0, dtype=np.float64),
    )


def concat(parts: list[Class210x10x9]) -> Class210x10x9:
    """Обʼєднує кілька наборів в один, порядок не міняється."""
    parts = [p for p in parts if len(p)]
    if not parts:
        return empty()
    return Class210x10x9(
        x=np.concatenate([p.x for p in parts]),
        t_start=np.concatenate([p.t_start for p in parts]),
        t_end=np.concatenate([p.t_end for p in parts]),
        price_open=np.concatenate([p.price_open for p in parts]),
        price_close=np.concatenate([p.price_close for p in parts]),
    )


def order_by_time(dataset: Class210x10x9) -> Class210x10x9:
    """Події за часом, без повторів `t_start`."""
    order = np.argsort(dataset.t_start, kind="stable")
    keep = order[np.concatenate(
        ([True], np.diff(dataset.t_start[order]) != 0))] if len(order) else order
    return take(dataset, keep)


def take(dataset: Class210x10x9, index: np.ndarray) -> Class210x10x9:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10x9(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10x9, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10x9:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10x9(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
