"""клас210х14х3 — клас210х14х2 плюс баланс обʼємів по блоках.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х3

Будується повністю з `клас210х14х5`: у ньому вже лежать і чотири фічі
`клас210х14х4`, і поблочний `vol_balance`. Поблочно, для кожного з 15 блоків
по 14 секунд:

    balance     = (resist_j   - support_j)   / (|resist_j|   + |support_j|)
    d_balance   = (d_resist_j - d_support_j) / (|d_resist_j| + |d_support_j|)
    vol_balance = (Σ14(vol_buy) - Σ14(vol_sell)) / (Σ14(vol_buy) + Σ14(vol_sell))

- 3 фічі × 15 значень. Форма події: (15, 3).
- Усі три безрозмірні, межі [-1, 1]: у перших двох одиниці обʼємів
  скорочуються, третя — частка від суми обʼємів.
- Жодна формула тут не переписується: перші дві рахує `class210x14x2.build`,
  третя вже порахована `class210x14x5.volume_balance` і береться як є.
- Нульовий знаменник дає NaN — значення лишається як є, кількість
  фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x14x2
import class210x14x4
import class210x14x5
from class210x14x4 import N_BLOCKS
from class210x14x5 import FEATURES as PARENT_FEATURES

FEATURES = list(class210x14x2.FEATURES) + ["vol_balance"]

_P = {name: i for i, name in enumerate(PARENT_FEATURES)}


@dataclass
class Class210x14x3:
    """Набір подій клас210х14х3."""

    x: np.ndarray            # (N, 15, 3)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_balance: int        # блоків із нульовим знаменником у balance
    nan_d_balance: int      # те саме в d_balance
    nan_vol_balance: int    # блоків, де обидва обʼєми нульові


def build(parent: Class210x14x5) -> tuple[Class210x14x3, BuildReport]:
    """Будує клас210х14х3 з клас210х14х5."""
    if parent.x.ndim != 3 or parent.x.shape[1:] != (N_BLOCKS,
                                                    len(PARENT_FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, {len(PARENT_FEATURES)})")

    # Перші чотири фічі клас210х14х5 — це клас210х14х4 подія в подію
    # (rules/01-data-and-db.md → клас210х14х5), тож balance і d_balance
    # рахує той самий код, що будує клас210х14х2.
    four = class210x14x4.Class210x14x4(
        x=parent.x[:, :, :len(class210x14x4.FEATURES)],
        timestamp=parent.timestamp,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    two, two_report = class210x14x2.build(four)
    volume = np.asarray(parent.x[:, :, _P["vol_balance"]], dtype=float)

    dataset = Class210x14x3(
        x=np.concatenate([two.x, volume[:, :, None]], axis=2),
        timestamp=parent.timestamp,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_balance=two_report.nan_balance,
        nan_d_balance=two_report.nan_d_balance,
        nan_vol_balance=int(np.isnan(volume).sum()),
    )
    return dataset, report


def save(dataset: Class210x14x3, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x14x3:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x14x3(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
