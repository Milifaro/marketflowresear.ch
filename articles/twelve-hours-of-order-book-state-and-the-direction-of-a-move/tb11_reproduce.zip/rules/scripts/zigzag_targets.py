"""Цілі навчання: нормований зігзаг на ЕМА ціни, пороги 2.3% і 0.8%.

Правила: rules/02-markup.md → Нормований зігзаг
         rules/01-data-and-db.md → клас210х4бема10х10х130

Порядок побудови цілі — той самий, що в дослідженні 11, етап 4:

    ема_p(price) -> півоти зігзага свого порогу (2.3% або 0.8%)
                 -> нормована нога: -1 у нижньому півоті, +1 у верхньому

Кожен поріг рахується **окремим** зігзагом по тому самому ряду ема_p,
а не вкладеним усередину рухів 2.3%: «зігзаг 0.8» — це зігзаг з порогом
0.8%, а не корекції всередині руху 2.3%.

Ціль будується на **кожному періоді** ЕМА того самого переліку, що й фічі
класу (10 … 130 кроком 10), окремо для кожного порогу. Виходить
`2 × 13` рядів-кандидатів; який з них брати за ціль, вирішує підбір
(`scripts/target_pick.py`).

Події поза зігзагом (до першого півота й після останнього) — `NaN`:
на таких подіях цілі немає.

## Незалежний зігзаг

Другий спосіб побудови цілі — **незалежний зігзаг**: півоти шукаються по
самій ціні події, без попереднього згладжування, тому зігзаг один і той
самий для всіх періодів ЕМА фіч — він від них не залежить:

    price -> півоти зігзага свого порогу -> нормована нога -> ема_s(нога)

Згладжується вже **нормована нога**, а не ціна. ЕМА причинна (дивиться
тільки назад), межі `[-1, 1]` зберігаються — це опукла комбінація
значень ноги. Ряд лишається `NaN` там, де його немає у самого зігзага.

## Нормалізація ноги

Нога нормується одним із трьох скейлерів (`rules/scripts/scalers.py`),
кожен — **по своїй нозі окремо**:

| Ключ | Формула на нозі | Ряд |
| ---- | --------------- | --- |
| `minmax` | `2 * (price - low) / (high - low) - 1` | «розподіл»: -1 у нижньому півоті, +1 у верхньому |
| `robust` | `(price - медіана) / (q75 - q25)` | те саме в одиницях IQR ноги |
| `quantile` | `2u - 1`, `u` — місце ціни в CDF ноги | ранг події всередині ноги |

Скейлер міняє тільки **спосіб відповіді**, питання лишається те саме:
де подія стоїть у своїй нозі.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210ema4 import ema
from scalers import SCALERS as leg_scalers
from zigzag import (DEFAULT_SCALER, INNER_THRESHOLD, OUTER_THRESHOLD,
                    normalized, zigzag)

THRESHOLDS = {"2.3": OUTER_THRESHOLD, "0.8": INNER_THRESHOLD}
PERIODS = list(range(10, 140, 10))
SMOOTH = 10   # ЕМА, якою згладжується нормована нога незалежного зігзага
SCALERS = tuple(leg_scalers)   # чим нормується нога: minmax, robust, quantile


@dataclass
class Targets:
    """Ряди цілей: (N, періоди, пороги)."""

    y: np.ndarray            # (N, 13, 2)
    timestamp: np.ndarray    # (N,)
    periods: list[int] = field(default_factory=lambda: list(PERIODS))
    names: list[str] = field(default_factory=lambda: list(THRESHOLDS))

    def __len__(self) -> int:
        return len(self.y)

    def column(self, period: int, name: str) -> np.ndarray:
        """Один ряд цілі: період ЕМА × поріг зігзага."""
        return self.y[:, self.periods.index(period), self.names.index(name)]


def build(prices: np.ndarray, timestamp: np.ndarray,
          periods: list[int] | None = None,
          scaler: str = DEFAULT_SCALER) -> Targets:
    """Нормований зігзаг на ЕМА ціни для кожного періоду й порогу.

    `prices` — ціни подій, відсортовані за часом (`price_open`).
    `scaler` — чим нормується нога (`minmax`, `robust`, `quantile`).
    """
    periods = list(periods or PERIODS)
    prices = np.asarray(prices, dtype=float)
    if len(prices) != len(timestamp):
        raise ValueError("ціни й timestamp різної довжини")
    if len(prices) and np.any(np.diff(np.asarray(timestamp)) <= 0):
        raise ValueError("події мають іти за часом, без повторів")

    y = np.full((len(prices), len(periods), len(THRESHOLDS)), np.nan)
    for row, period in enumerate(periods):
        smoothed = ema(prices, period)
        for column, threshold in enumerate(THRESHOLDS.values()):
            y[:, row, column] = normalized(smoothed,
                                           zigzag(smoothed, threshold), scaler)
    return Targets(y=y, timestamp=np.asarray(timestamp), periods=periods)


def save(targets: Targets, path) -> None:
    """Зберігає цілі у .npz."""
    np.savez_compressed(
        path, y=targets.y.astype(np.float32), timestamp=targets.timestamp,
        periods=np.array(targets.periods), names=np.array(targets.names))


def load(path) -> Targets:
    """Читає цілі з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Targets(y=data["y"], timestamp=data["timestamp"],
                       periods=[int(value) for value in data["periods"]],
                       names=list(data["names"]))


def independent(prices: np.ndarray, timestamp: np.ndarray,
                smooth: int | list[int] | None = None,
                scaler: str = DEFAULT_SCALER) -> Targets:
    """Незалежний зігзаг: півоти по самій ціні, ЕМА вже на нормованій нозі.

    На відміну від `build`, ціна не згладжується: зігзаг один на весь ряд
    і від періодів ЕМА фіч не залежить. Згладжується його **нормована
    нога** — ЕМА періоду `smooth` (за замовчуванням 10).

    `periods` у результаті — періоди цього згладжування, не ЕМА ціни.
    `scaler` — чим нормується нога (`minmax`, `robust`, `quantile`).
    """
    periods = [smooth or SMOOTH] if isinstance(smooth, (int, type(None))) \
        else list(smooth)
    prices = np.asarray(prices, dtype=float)
    if len(prices) != len(timestamp):
        raise ValueError("ціни й timestamp різної довжини")
    if len(prices) and np.any(np.diff(np.asarray(timestamp)) <= 0):
        raise ValueError("події мають іти за часом, без повторів")

    y = np.full((len(prices), len(periods), len(THRESHOLDS)), np.nan)
    for column, threshold in enumerate(THRESHOLDS.values()):
        leg = normalized(prices, zigzag(prices, threshold), scaler)
        for row, period in enumerate(periods):
            y[:, row, column] = leg if period <= 1 else ema(leg, period)
    return Targets(y=y, timestamp=np.asarray(timestamp), periods=periods)
