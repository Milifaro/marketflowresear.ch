"""Ряд подій клас210х210х3: увесь датасет однією послідовністю.

Правила: rules/01-data-and-db.md → Базові скрипти

train + val + test складаються разом і сортуються за `timestamp`.
Одна подія — одна точка: час UTC, ціна і три фічі клас210х210х3.
`collect()` бере цим же порядком події для кореляцій ЕМА
(дослідження 11).

Вхід : data/datasets/<PAIR>/class210x210x3/{train,val,test}.npz
Вихід: data/datasets/<PAIR>/class210x210x3/series.json

Запуск:
    python3 rules/scripts/class_series.py --pair BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x210x3
from class210x210x3 import EVENT_LENGTH, FEATURES
from data_source import PROJECT_ROOT

PARTS = ("train", "val", "test")
PRICE_DIGITS = 2       # quote (USDT)
VALUE_DIGITS = 6       # фічі безрозмірні, межі [-1, 1]


def collect(in_dir: Path) -> dict:
    """Складає всі вибірки в один ряд, відсортований за часом."""
    x, timestamp, price_open, price_close, part = [], [], [], [], []
    sizes = {}
    for index, name in enumerate(PARTS):
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        dataset = class210x210x3.load(path)
        sizes[name] = len(dataset)
        x.append(np.asarray(dataset.x, dtype=float))
        timestamp.append(np.asarray(dataset.timestamp, dtype=np.int64))
        price_open.append(np.asarray(dataset.price_open, dtype=float))
        price_close.append(np.asarray(dataset.price_close, dtype=float))
        part.append(np.full(len(dataset), index, dtype=np.int8))

    timestamp = np.concatenate(timestamp)
    order = np.argsort(timestamp, kind="stable")
    return {
        "x": np.concatenate(x)[order],
        "timestamp": timestamp[order],
        "price_open": np.concatenate(price_open)[order],
        "price_close": np.concatenate(price_close)[order],
        "part": np.concatenate(part)[order],
        "sizes": sizes,
    }


def series(in_dir: Path, pair: str) -> dict:
    """JSON вкладки: ряд подій, межі осей і опис для шапки."""
    row = collect(in_dir)
    x, timestamp = row["x"], row["timestamp"]
    if not len(timestamp):
        raise SystemExit(f"порожній датасет у {in_dir}")

    price = np.concatenate([row["price_open"], row["price_close"]])
    # розрив — коли між початками сусідніх подій більше, ніж одна подія
    gaps = int((np.diff(timestamp) > EVENT_LENGTH).sum())
    return {
        "pair": pair,
        "class": "клас210х210х3",
        "class_id": "class210x210x3",
        "script": "rules/scripts/class_series.py",
        "event_seconds": EVENT_LENGTH,
        "features": list(FEATURES),
        "part_names": list(PARTS),
        "parts": row["sizes"],
        "events": int(len(timestamp)),
        "gaps": gaps,
        "period": {"from": int(timestamp[0]),
                   "to": int(timestamp[-1]) + EVENT_LENGTH},
        "range": {
            "price": [round(float(price.min()), PRICE_DIGITS),
                      round(float(price.max()), PRICE_DIGITS)],
            "features": [[round(float(np.nanmin(x[:, i])), VALUE_DIGITS),
                          round(float(np.nanmax(x[:, i])), VALUE_DIGITS)]
                         for i in range(len(FEATURES))],
        },
        "t": timestamp.tolist(),
        "part": row["part"].tolist(),
        "price_open": np.round(row["price_open"], PRICE_DIGITS).tolist(),
        "price_close": np.round(row["price_close"], PRICE_DIGITS).tolist(),
        "f": [np.round(x[:, i], VALUE_DIGITS).tolist()
              for i in range(len(FEATURES))],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    in_dir = (args.in_dir or PROJECT_ROOT / "data" / "datasets" / args.pair
              / "class210x210x3")
    out = args.out or in_dir / "series.json"

    payload = series(in_dir, args.pair)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    print(f"{payload['events']} подій, розривів {payload['gaps']}, "
          f"ціна {payload['range']['price'][0]}…{payload['range']['price'][1]}")
    print(f"записано в {out}")


if __name__ == "__main__":
    main()
