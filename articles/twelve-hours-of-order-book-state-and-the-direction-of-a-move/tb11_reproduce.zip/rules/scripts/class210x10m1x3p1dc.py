"""клас210х10-1х3+1дц — три нормовані різниці похідних плюс ціна.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10-1х3+1дц

Батько — `клас210х10-1х7дц`: девʼять блоків чистих похідних, сім фіч.
Шість із них ідуть парами «опір проти підтримки», і кожна пара
згортається в одну нормовану різницю **модулів**:

    b = (|a| − |b|) / (|a| + |b|)

| Фіча | a | b |
| ---- | - | - |
| `b_resist_support` | `d_resist` | `d_support` |
| `b_bal_resist_support` | `d_bal_resist` | `d_bal_support` |
| `b_vol_buy_sell` | `d_vol_buy` | `d_vol_sell` |

Сьома фіча — `d_price_avg` — пари не має і переноситься **як є**. Звідси
`3+1` в імені: три різниці плюс одна перенесена.

Модулі в чисельнику міняють питання: фіча каже, **чия сторона сильніше
зрушила**, а не куди вона зрушила. `+1` — рухався тільки опір, `−1` —
тільки підтримка, `0` — порівну. Знак самих похідних тут зникає; куди
тягне кожна сторона, лишається в батьківському класі.

- **4 фічі × 9 блоків.** Форма події: `(9, 4)`.
- Перші три безрозмірні, межі `[-1, 1]`; `d_price_avg` — приріст ціни
  за 21 секунду, як у батька.
- Блок, де обидві похідні пари рівно нульові, дає нульовий знаменник і
  `NaN`; подія лишається, кількість фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x10m1x7dc
from class210x10m1x7dc import Class210x10m1x7dc

N_BLOCKS = class210x10m1x7dc.N_BLOCKS          # 9

# Пари батьківських фіч і імʼя різниці, яку вони дають.
PAIRS = (
    ("b_resist_support", "d_resist", "d_support"),
    ("b_bal_resist_support", "d_bal_resist", "d_bal_support"),
    ("b_vol_buy_sell", "d_vol_buy", "d_vol_sell"),
)
# Фіча без пари: переноситься з батька як є.
CARRIED = ("d_price_avg",)

FEATURES = [name for name, _, _ in PAIRS] + list(CARRIED)

PARENT = {name: index for index, name
          in enumerate(class210x10m1x7dc.FEATURES)}


@dataclass
class Class210x10m1x3p1dc:
    """Набір подій клас210х10-1х3+1дц."""

    x: np.ndarray            # (N, 9, 4)
    t_start: np.ndarray      # (N,)
    t_end: np.ndarray        # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        return self.t_start


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_values: int          # значень NaN у всьому наборі
    zero_pairs: int          # блоків, де обидві похідні пари рівно нульові


def balance(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """(|a| − |b|) / (|a| + |b|). Обидва нулі -> NaN."""
    left = np.abs(np.asarray(left, dtype=float))
    right = np.abs(np.asarray(right, dtype=float))
    bottom = left + right
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(bottom > 0, (left - right) / bottom, np.nan)


def features_of(x: np.ndarray) -> np.ndarray:
    """(N, 9, 7) -> (N, 9, 4) за формулами класу."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 3 or x.shape[1:] != (N_BLOCKS,
                                      len(class210x10m1x7dc.FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, "
            f"{len(class210x10m1x7dc.FEATURES)})")
    columns = [balance(x[:, :, PARENT[a]], x[:, :, PARENT[b]])
               for _, a, b in PAIRS]
    columns += [x[:, :, PARENT[name]] for name in CARRIED]
    return np.stack(columns, axis=2)


def build(parent: Class210x10m1x7dc
          ) -> tuple[Class210x10m1x3p1dc, BuildReport]:
    """Будує клас210х10-1х3+1дц з клас210х10-1х7дц."""
    value = features_of(parent.x)
    dataset = Class210x10m1x3p1dc(
        x=value,
        t_start=parent.t_start,
        t_end=parent.t_end,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    zero = 0
    for _, a, b in PAIRS:
        both = (np.abs(parent.x[:, :, PARENT[a]])
                + np.abs(parent.x[:, :, PARENT[b]]))
        zero += int((both == 0).sum())
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_values=int(np.isnan(value).sum()),
        zero_pairs=zero,
    )
    return dataset, report


def take(dataset: Class210x10m1x3p1dc, index: np.ndarray
         ) -> Class210x10m1x3p1dc:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10m1x3p1dc(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10m1x3p1dc, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10m1x3p1dc:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10m1x3p1dc(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
