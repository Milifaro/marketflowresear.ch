"""клас210х10-1х2д — дві похідні відношення обʼєму до свого рівня.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10-1х2д

Батько — `клас210х10-1х7дц`: девʼять блоків чистих похідних, сім фіч.
Кожна сторона книги згортається в одну фічу — похідна обʼєму ділиться
на похідну свого рівня:

| Фіча | чисельник | знаменник |
| ---- | --------- | --------- |
| `d_up` | `d_vol_buy` | `d_resist` |
| `d_down` | `d_vol_sell` | `d_support` |

- **2 фічі × 9 блоків.** Форма події: `(9, 2)`.
- Ціни в класі немає, тому суфікса `ц` в імені теж немає.
- Блок з нульовим знаменником дає `NaN`; подія лишається, кількість
  фіксується у звіті побудови.
- Відношення двох похідних не обмежене: коли рівень майже не зрушив,
  значення велике. Міри, що читають цей клас, — рангові.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x10m1x7dc
from class210x10m1x7dc import Class210x10m1x7dc

N_BLOCKS = class210x10m1x7dc.N_BLOCKS          # 9

# Імʼя фічі, чисельник і знаменник — обидва з батьківського класу.
RATIOS = (
    ("d_up", "d_vol_buy", "d_resist"),
    ("d_down", "d_vol_sell", "d_support"),
)

FEATURES = [name for name, _, _ in RATIOS]

PARENT = {name: index for index, name
          in enumerate(class210x10m1x7dc.FEATURES)}


@dataclass
class Class210x10m1x2d:
    """Набір подій клас210х10-1х2д."""

    x: np.ndarray            # (N, 9, 2)
    t_start: np.ndarray      # (N,)
    t_end: np.ndarray        # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        return self.t_start


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_values: int          # значень NaN у всьому наборі
    zero_bottom: int         # блоків з нульовим знаменником


def ratio(top: np.ndarray, bottom: np.ndarray) -> np.ndarray:
    """top / bottom. Нульовий знаменник -> NaN."""
    top = np.asarray(top, dtype=float)
    bottom = np.asarray(bottom, dtype=float)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(bottom != 0, top / bottom, np.nan)


def features_of(x: np.ndarray) -> np.ndarray:
    """(N, 9, 7) -> (N, 9, 2) за формулами класу."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 3 or x.shape[1:] != (N_BLOCKS,
                                      len(class210x10m1x7dc.FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, "
            f"{len(class210x10m1x7dc.FEATURES)})")
    columns = [ratio(x[:, :, PARENT[top]], x[:, :, PARENT[bottom]])
               for _, top, bottom in RATIOS]
    return np.stack(columns, axis=2)


def build(parent: Class210x10m1x7dc) -> tuple[Class210x10m1x2d, BuildReport]:
    """Будує клас210х10-1х2д з клас210х10-1х7дц."""
    value = features_of(parent.x)
    dataset = Class210x10m1x2d(
        x=value,
        t_start=parent.t_start,
        t_end=parent.t_end,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    zero = sum(int((parent.x[:, :, PARENT[bottom]] == 0).sum())
               for _, _, bottom in RATIOS)
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_values=int(np.isnan(value).sum()),
        zero_bottom=zero,
    )
    return dataset, report


def take(dataset: Class210x10m1x2d, index: np.ndarray) -> Class210x10m1x2d:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10m1x2d(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10m1x2d, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10m1x2d:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10m1x2d(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
