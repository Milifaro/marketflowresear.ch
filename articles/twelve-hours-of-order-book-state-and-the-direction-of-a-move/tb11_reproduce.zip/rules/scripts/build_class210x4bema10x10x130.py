"""Побудова датасету клас210х4бема10х10х130 і цілей до нього.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х4бема10х10х130

Фічі й цілі — наскрізні по часу, тому вибірки спершу складаються в один
ряд за `timestamp`, а потім розкладаються по тому самому розбиттю.
Разом з кожною вибіркою пишуться цілі (`rules/scripts/zigzag_targets.py`)
двома способами:

- `<part>_targets.npz` — зігзаги 2.3% і 0.8% на ЕМА ціни тих самих
  періодів, що й фічі;
- `<part>_targets_ind.npz` — **незалежний зігзаг**: півоти по самій ціні,
  ЕМА `zigzag_targets.SMOOTH` вже на нормованій нозі;
- `<part>_targets_ind_<скейлер>.npz` — той самий незалежний зігзаг, нога
  нормована `robust` і `quantile` замість `minmax`
  (`rules/02-markup.md` → Нормалізація ноги).

Запуск:
    python3 rules/scripts/build_class210x4bema10x10x130.py --pair BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x4bema10x10x130 as klass
import class210x210x4c
import zigzag_targets
from class210x210x4c import Class210x210x4c
from data_source import PROJECT_ROOT
from zigzag import DEFAULT_SCALER

PARTS = ("train", "val", "test")


def merge(in_dir: Path) -> tuple[Class210x210x4c, dict]:
    """Усі вибірки одним рядом, відсортованим за часом."""
    x, timestamp, price_open, price_close, order = [], [], [], [], {}
    for name in PARTS:
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        part = class210x210x4c.load(path)
        order[name] = np.asarray(part.timestamp, dtype=np.int64)
        x.append(np.asarray(part.x, dtype=float))
        timestamp.append(order[name])
        price_open.append(np.asarray(part.price_open, dtype=float))
        price_close.append(np.asarray(part.price_close, dtype=float))
    timestamp = np.concatenate(timestamp)
    index = np.argsort(timestamp, kind="stable")
    row = Class210x210x4c(x=np.concatenate(x)[index], timestamp=timestamp[index],
                          price_open=np.concatenate(price_open)[index],
                          price_close=np.concatenate(price_close)[index])
    return row, order


def build_pair(in_dir: Path, out_dir: Path, periods: list[int]) -> dict:
    row, order = merge(in_dir)
    dataset, report = klass.build(row, periods)
    targets = zigzag_targets.build(row.price_open, row.timestamp, periods)
    # незалежний зігзаг у трьох нормалізаціях ноги; minmax лишається без
    # суфікса — це ряд «розподіл», з яким працює навчання
    independent = {name: zigzag_targets.independent(row.price_open,
                                                    row.timestamp, scaler=name)
                   for name in zigzag_targets.SCALERS}
    out_dir.mkdir(parents=True, exist_ok=True)

    position = {int(ts): i for i, ts in enumerate(dataset.timestamp)}
    result = {"source": str(in_dir), **asdict(report), "parts": {},
              "targets": {"thresholds": list(zigzag_targets.THRESHOLDS),
                          "periods": periods},
              "targets_independent": {
                  "thresholds": list(zigzag_targets.THRESHOLDS),
                  "smooth": independent[DEFAULT_SCALER].periods,
                  "scalers": list(zigzag_targets.SCALERS)}}
    for name in PARTS:
        index = np.array([position[int(ts)] for ts in order[name]], dtype=int)
        part = klass.Class210x4bEma(
            x=dataset.x[index], timestamp=dataset.timestamp[index],
            price_open=dataset.price_open[index],
            price_close=dataset.price_close[index], periods=periods)
        klass.save(part, out_dir / f"{name}.npz")
        zigzag_targets.save(
            zigzag_targets.Targets(y=targets.y[index],
                                   timestamp=targets.timestamp[index],
                                   periods=periods),
            out_dir / f"{name}_targets.npz")
        for scaler, item in independent.items():
            suffix = "" if scaler == DEFAULT_SCALER else f"_{scaler}"
            zigzag_targets.save(
                zigzag_targets.Targets(y=item.y[index],
                                       timestamp=item.timestamp[index],
                                       periods=item.periods),
                out_dir / f"{name}_targets_ind{suffix}.npz")
        outside = int(np.isnan(targets.y[index]).all(axis=(1, 2)).sum())
        outside_ind = int(np.isnan(independent[DEFAULT_SCALER].y[index])
                          .all(axis=(1, 2)).sum())
        result["parts"][name] = {"events": len(part), "outside_zigzag": outside,
                                 "outside_zigzag_independent": outside_ind}
        print(f"{name}: {len(part)} подій, форма {part.x.shape[1:]}, "
              f"поза зігзагом {outside}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    datasets = PROJECT_ROOT / "data" / "datasets" / args.pair
    in_dir = args.in_dir or datasets / "class210x210x4c"
    out_dir = args.out or datasets / "class210x4bema10x10x130"

    report = build_pair(in_dir, out_dir, klass.PERIODS)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"записано в {out_dir}")


if __name__ == "__main__":
    main()
