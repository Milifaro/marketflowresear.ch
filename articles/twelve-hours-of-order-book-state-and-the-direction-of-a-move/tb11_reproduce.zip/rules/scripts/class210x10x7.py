"""клас210х10х7 — рівні стакана в одиницях обʼємів блоку.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10х7

Батько — `клас210х10х9`: 10 блоків по 21 секунді, у блоці середні 9 фіч.
У кожному блоці шість рівнів стакана діляться на обʼєм **свого ж блоку**,
і з дев'яти фіч лишається сім:

    resist       = const_resist / vol_buy
    bal_resist   = (resist_plus − resist_minus) / vol_buy
    support      = const_support / vol_sell
    bal_support  = (support_plus − support_minus) / vol_sell
    vol_buy, vol_sell, price_avg — середні блоку як є

Форма події: `(10, 7)`. Перші чотири фічі — безрозмірні (одиниці обʼємів
скорочуються), `vol_buy` / `vol_sell` — база (BTC), `price_avg` — котирування.

Блок з нульовим обʼємом дає нульовий знаменник і `NaN`; подія лишається,
кількість `NaN` фіксується у звіті побудови.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x10x9
from class210x10x9 import N_BLOCKS, Class210x10x9

FEATURES = [
    "resist",
    "bal_resist",
    "support",
    "bal_support",
    "vol_buy",
    "vol_sell",
    "price_avg",
]

PARENT = {name: index for index, name in enumerate(class210x10x9.FEATURES)}


@dataclass
class Class210x10x7:
    """Набір подій клас210х10х7."""

    x: np.ndarray            # (N, 10, 7)
    t_start: np.ndarray      # (N,)
    t_end: np.ndarray        # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)

    @property
    def timestamp(self) -> np.ndarray:
        return self.t_start


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_values: int          # значень NaN у всьому наборі
    zero_vol_buy: int        # блоків з нульовим обʼємом купівлі
    zero_vol_sell: int       # блоків з нульовим обʼємом продажу


def ratio(top: np.ndarray, bottom: np.ndarray) -> np.ndarray:
    """Ділення блоку на обʼєм блоку. Нульовий обʼєм -> NaN."""
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(bottom != 0, top / bottom, np.nan)


def features_of(x: np.ndarray) -> np.ndarray:
    """(N, 10, 9) -> (N, 10, 7) за формулами класу."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 3 or x.shape[1:] != (N_BLOCKS, len(class210x10x9.FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, {len(class210x10x9.FEATURES)})")
    buy = x[:, :, PARENT["vol_buy"]]
    sell = x[:, :, PARENT["vol_sell"]]
    return np.stack([
        ratio(x[:, :, PARENT["const_resist"]], buy),
        ratio(x[:, :, PARENT["resist_plus"]] - x[:, :, PARENT["resist_minus"]],
              buy),
        ratio(x[:, :, PARENT["const_support"]], sell),
        ratio(x[:, :, PARENT["support_plus"]] - x[:, :, PARENT["support_minus"]],
              sell),
        buy,
        sell,
        x[:, :, PARENT["price_avg"]],
    ], axis=2)


def build(parent: Class210x10x9) -> tuple[Class210x10x7, BuildReport]:
    """Будує клас210х10х7 з клас210х10х9."""
    value = features_of(parent.x)
    dataset = Class210x10x7(
        x=value,
        t_start=parent.t_start,
        t_end=parent.t_end,
        price_open=parent.price_open,
        price_close=parent.price_close,
    )
    buy = parent.x[:, :, PARENT["vol_buy"]]
    sell = parent.x[:, :, PARENT["vol_sell"]]
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_values=int(np.isnan(value).sum()),
        zero_vol_buy=int((buy == 0).sum()),
        zero_vol_sell=int((sell == 0).sum()),
    )
    return dataset, report


def take(dataset: Class210x10x7, index: np.ndarray) -> Class210x10x7:
    """Підмножина подій у заданому порядку."""
    index = np.asarray(index)
    return Class210x10x7(
        x=dataset.x[index],
        t_start=dataset.t_start[index],
        t_end=dataset.t_end[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index],
        features=list(dataset.features),
    )


def save(dataset: Class210x10x7, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        t_start=dataset.t_start,
        t_end=dataset.t_end,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x10x7:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x10x7(
            x=data["x"],
            t_start=data["t_start"],
            t_end=data["t_end"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
