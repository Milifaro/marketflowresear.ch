"""Побудова датасету клас210х14х4ц: клас210х14х3 плюс цінова фіча.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х4ц

Цінова фіча рахується з посекундних цін, тому береться з робочої копії
`data/`; решта три фічі — з готового `клас210х14х3`. Події зіставляються
за `timestamp`, розбиття train/val/test і порядок подій не міняються.

Джерело на Desktop не читається — тільки `data/`.

Пропуски часу заповнюються так само, як у розбитті: якщо датасет зібраний
з `--fill-gaps 60`, тут потрібен той самий прапорець.

Запуск:
    python3 rules/scripts/build_class210x14x4c.py --pair BTC_USDT
    python3 rules/scripts/build_class210x14x4c.py --pair BTC_USDT --fill-gaps 60
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x14x3
import class210x14x4c
import fill_gaps
from class210x8 import EVENT_LENGTH
from data_source import PROJECT_ROOT, load_day, to_array

PARTS = ("train", "val", "test")
WORK_ROOT = PROJECT_ROOT / "data"


def work_files(pair: str, root: Path | None = None) -> list[Path]:
    """Файли робочої копії data/<рік>/<місяць>/<PAIR>/."""
    root = Path(root) if root is not None else WORK_ROOT
    return sorted(root.glob(f"*/*/{pair}/1S_*_{pair}.csv"))


def price_feature(files: list[Path], step: int = EVENT_LENGTH, log=print,
                  max_gap: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """Цінова фіча всіх подій робочої копії: (N, 15) і timestamp (N,)."""
    values, stamps = [], []
    for index, path in enumerate(files, 1):
        frame, _ = load_day(path)
        rows, _ = fill_gaps.fill(to_array(frame), max_gap)
        block, ts = class210x14x4c.from_rows(rows, step)
        if len(ts):
            values.append(block)
            stamps.append(ts)
        if index % 40 == 0 or index == len(files):
            log(f"      {index}/{len(files)} файлів, подій: "
                f"{sum(len(s) for s in stamps)}")
    if not stamps:
        return np.empty((0, 15)), np.empty(0, dtype=np.int64)
    return np.concatenate(values), np.concatenate(stamps)


def build_pair(pair: str, in_dir: Path, out_dir: Path, step: int,
               root: Path | None = None, max_gap: int = 0) -> dict:
    files = work_files(pair, root)
    if not files:
        raise SystemExit(f"немає робочої копії data/ для {pair}")
    print(f"[1/3] файлів у робочій копії: {len(files)}")

    prices, stamps = price_feature(files, step, max_gap=max_gap)
    print(f"[2/3] цінова фіча: {len(stamps)} подій, "
          f"NaN-блоків: {int(np.isnan(prices).sum())}")

    out_dir.mkdir(parents=True, exist_ok=True)
    report = {"source": str(in_dir), "work_events": int(len(stamps)),
              "parts": {}}
    for name in PARTS:
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        parent = class210x14x3.load(path)
        dataset, part = class210x14x4c.build(parent, prices, stamps)
        if len(dataset) != len(parent):
            raise SystemExit(f"{name}: цінової фічі немає для "
                             f"{len(parent) - len(dataset)} подій")
        class210x14x4c.save(dataset, out_dir / f"{name}.npz")
        report["parts"][name] = asdict(part)
        print(f"      {name}: {len(dataset)} подій, NaN-блоків "
              f"price_balance: {part.nan_price_balance}")
    print(f"[3/3] записано в {out_dir}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--step", type=int, default=EVENT_LENGTH)
    parser.add_argument("--fill-gaps", type=int, default=0,
                        help="той самий прапорець, що й у build_dataset.py")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=None,
                        help="корінь робочої копії; типово data/")
    args = parser.parse_args()

    datasets = PROJECT_ROOT / "data" / "datasets" / args.pair
    in_dir = args.in_dir or datasets / "class210x14x3"
    out_dir = args.out or datasets / "class210x14x4c"

    report = build_pair(args.pair, in_dir, out_dir, args.step, args.data,
                        max_gap=args.fill_gaps)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
