"""клас210х14х4 — похідний клас у одиницях обʼємів.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х4

Будується повністю з клас210х8. Блоки по 14 секунд з кроком 14 -> 15 значень
на фічу, 4 фічі. Форма події: (15, 4).

    resist    = Σ14(const_resist)                 / mean(vol_buy)
    d_resist  = Σ14(resist_plus  - resist_minus)  / mean(vol_buy)
    support   = Σ14(const_support)                / mean(vol_sell)
    d_support = Σ14(support_plus - support_minus) / mean(vol_sell)
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210x8 import EVENT_LENGTH, FEATURES as PARENT_FEATURES, Class210x8

BLOCK = 14
N_BLOCKS = EVENT_LENGTH // BLOCK  # 15

FEATURES = ["resist", "d_resist", "support", "d_support"]

_P = {name: i for i, name in enumerate(PARENT_FEATURES)}


@dataclass
class Class210x14x4:
    """Набір подій клас210х14х4."""

    x: np.ndarray            # (N, 15, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    dropped_zero_volume: int
    events_out: int


def _block_sums(values: np.ndarray) -> np.ndarray:
    """(N, 210) -> (N, 15): суми по блоках з 14 секунд."""
    return values.reshape(len(values), N_BLOCKS, BLOCK).sum(axis=2)


def build(parent: Class210x8) -> tuple[Class210x14x4, BuildReport]:
    """Будує клас210х14х4 з клас210х8."""
    if parent.x.ndim != 3 or parent.x.shape[1:] != (EVENT_LENGTH,
                                                    len(PARENT_FEATURES)):
        raise ValueError(
            f"очікується масив (N, {EVENT_LENGTH}, {len(PARENT_FEATURES)})")

    events_in = len(parent)
    mean_buy = parent.x[:, :, _P["vol_buy"]].mean(axis=1)
    mean_sell = parent.x[:, :, _P["vol_sell"]].mean(axis=1)

    # Ділення неможливе — подія відкидається (rules/01-data-and-db.md).
    keep = (mean_buy != 0) & (mean_sell != 0)
    src = parent.x[keep]
    mean_buy = mean_buy[keep][:, None]
    mean_sell = mean_sell[keep][:, None]

    resist = _block_sums(src[:, :, _P["const_resist"]]) / mean_buy
    d_resist = _block_sums(
        src[:, :, _P["resist_plus"]] - src[:, :, _P["resist_minus"]]) / mean_buy
    support = _block_sums(src[:, :, _P["const_support"]]) / mean_sell
    d_support = _block_sums(
        src[:, :, _P["support_plus"]] - src[:, :, _P["support_minus"]]) / mean_sell

    dataset = Class210x14x4(
        x=np.stack([resist, d_resist, support, d_support], axis=2),
        timestamp=parent.timestamp[keep],
        price_open=parent.price_open[keep],
        price_close=parent.price_close[keep],
    )
    report = BuildReport(
        events_in=events_in,
        dropped_zero_volume=int(events_in - keep.sum()),
        events_out=len(dataset),
    )
    return dataset, report


def save(dataset: Class210x14x4, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x14x4:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x14x4(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
