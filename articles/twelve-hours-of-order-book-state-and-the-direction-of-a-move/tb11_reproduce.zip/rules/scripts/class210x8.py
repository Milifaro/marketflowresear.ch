"""клас210х8 — базовий клас подій.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х8

Подія = 210 секунд безперервної посекундної історії, 8 фіч.
Форма події: (210, 8). Додатково зберігаються timestamp, price_open, price_close
(не для навчання).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from data_source import SOURCE_COLUMNS

EVENT_LENGTH = 210

FEATURES = [
    "const_resist",
    "resist_plus",
    "resist_minus",
    "const_support",
    "support_plus",
    "support_minus",
    "vol_buy",
    "vol_sell",
]

FEATURE_IDX = [SOURCE_COLUMNS.index(name) for name in FEATURES]
TS_IDX = SOURCE_COLUMNS.index("timestamp")
PRICE_IDX = SOURCE_COLUMNS.index("price_avg")


@dataclass
class Class210x8:
    """Набір подій клас210х8."""

    x: np.ndarray            # (N, 210, 8)
    timestamp: np.ndarray    # (N,) — перша секунда події
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


def contiguous_segments(timestamps: np.ndarray, min_length: int = EVENT_LENGTH
                        ) -> list[tuple[int, int]]:
    """Відрізки з кроком рівно 1 секунда. Повертає [start, stop) індексів."""
    if len(timestamps) == 0:
        return []
    breaks = np.flatnonzero(np.diff(timestamps) != 1) + 1
    bounds = np.concatenate(([0], breaks, [len(timestamps)]))
    return [(int(a), int(b)) for a, b in zip(bounds[:-1], bounds[1:])
            if b - a >= min_length]


def build(rows: np.ndarray, step: int = EVENT_LENGTH) -> Class210x8:
    """Будує події з масиву у порядку SOURCE_COLUMNS.

    step=210 (за замовчуванням) — події не перекриваються.
    """
    if rows.ndim != 2 or rows.shape[1] != len(SOURCE_COLUMNS):
        raise ValueError(f"очікується масив (N, {len(SOURCE_COLUMNS)})")
    if step < 1:
        raise ValueError("step має бути >= 1")

    events, starts = [], []
    ts = rows[:, TS_IDX]
    for lo, hi in contiguous_segments(ts):
        for begin in range(lo, hi - EVENT_LENGTH + 1, step):
            events.append(rows[begin:begin + EVENT_LENGTH, FEATURE_IDX])
            starts.append(begin)

    if not events:
        return Class210x8(
            x=np.empty((0, EVENT_LENGTH, len(FEATURES)), dtype=np.float64),
            timestamp=np.empty(0, dtype=np.int64),
            price_open=np.empty(0, dtype=np.float64),
            price_close=np.empty(0, dtype=np.float64),
        )

    idx = np.asarray(starts)
    return Class210x8(
        x=np.stack(events),
        timestamp=ts[idx].astype(np.int64),
        price_open=rows[idx, PRICE_IDX],
        price_close=rows[idx + EVENT_LENGTH - 1, PRICE_IDX],
    )


def concat(parts: list[Class210x8]) -> Class210x8:
    """Обʼєднує кілька наборів подій в один."""
    parts = [p for p in parts if len(p)]
    if not parts:
        return build(np.empty((0, len(SOURCE_COLUMNS))))
    return Class210x8(
        x=np.concatenate([p.x for p in parts]),
        timestamp=np.concatenate([p.timestamp for p in parts]),
        price_open=np.concatenate([p.price_open for p in parts]),
        price_close=np.concatenate([p.price_close for p in parts]),
    )
