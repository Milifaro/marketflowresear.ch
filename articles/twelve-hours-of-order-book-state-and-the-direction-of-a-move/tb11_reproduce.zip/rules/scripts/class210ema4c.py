"""клас210ема4ц — чотири ЕМА безрозмірних фіч клас210х210х4ц.

Правила: rules/01-data-and-db.md → Класи (події) → клас210ема4ц

Те саме, що `клас210ема4`, з однією різницею: замість ЕМА самої ціни
береться **ЕМА цінової фічі**, тому всі чотири ряди безрозмірні й
в одному масштабі `[-1, 1]`:

    ema_balance       = ЕМА(balance)
    ema_d_balance     = ЕМА(d_balance)
    ema_vol_balance   = ЕМА(vol_balance)
    ema_price_balance = ЕМА(price_balance)

- Формула та сама: `alpha = 2 / (період + 1)`, старт із першого значення
  ряду; період — параметр побудови, зберігається разом з даними.
- ЕМА дивиться тільки назад; ряд наскрізний за часом.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210ema4 import DEFAULT_PERIOD, ema
from class210x210x4c import Class210x210x4c, FEATURES as PARENT_FEATURES

FEATURES = [f"ema_{name}" for name in PARENT_FEATURES]


@dataclass
class Class210ema4c:
    """Набір подій клас210ема4ц."""

    x: np.ndarray            # (N, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    period: int = DEFAULT_PERIOD
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    period: int
    nan_by_feature: dict


def build(parent: Class210x210x4c, period: int = DEFAULT_PERIOD
          ) -> tuple[Class210ema4c, BuildReport]:
    """Будує клас210ема4ц з клас210х210х4ц, відсортованого за часом."""
    if parent.x.ndim != 2 or parent.x.shape[1] != len(PARENT_FEATURES):
        raise ValueError(f"очікується масив (N, {len(PARENT_FEATURES)})")
    if len(parent) and np.any(np.diff(parent.timestamp) <= 0):
        raise ValueError("події мають іти за часом, без повторів")

    x = (np.stack([ema(parent.x[:, index], period)
                   for index in range(len(PARENT_FEATURES))], axis=1)
         if len(parent) else np.zeros((0, len(FEATURES))))

    dataset = Class210ema4c(
        x=x, timestamp=parent.timestamp, price_open=parent.price_open,
        price_close=parent.price_close, period=period)
    report = BuildReport(
        events_in=len(parent), events_out=len(dataset), period=period,
        nan_by_feature={name: int(np.isnan(x[:, i]).sum())
                        for i, name in enumerate(FEATURES)})
    return dataset, report


def save(dataset: Class210ema4c, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        period=np.array(dataset.period),
        features=np.array(dataset.features))


def load(path) -> Class210ema4c:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210ema4c(
            x=data["x"], timestamp=data["timestamp"],
            price_open=data["price_open"], price_close=data["price_close"],
            period=int(data["period"]), features=list(data["features"]))
