"""клас210х4бема10х10х130 — чотири безрозмірні фічі × тринадцять ЕМА.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х4бема10х10х130

Клас для навчання. Подія та сама — 210 секунд; значення — це чотири
безрозмірні фічі `клас210х210х4ц`, кожна взята **тринадцятьма ЕМА**:
періоди 10, 20, … 130 подій (0.6 … 7.6 год).

    ema_p(balance), ema_p(d_balance), ema_p(vol_balance), ema_p(price_balance)
    для p = 10, 20, … 130

- **4 фічі × 13 періодів.** Форма події: `(13, 4)` — рядок це період,
  колонка це фіча.
- Усі значення безрозмірні, межі `[-1, 1]`: ЕМА чисел з `[-1, 1]`
  лишається в цих межах.
- Формула ЕМА: `alpha = 2 / (період + 1)`, старт із першого значення ряду —
  та сама, що в решті класів.
- ЕМА наскрізна за часом: події спершу складаються в один ряд за
  `timestamp`, і лише потім розкладаються по наявному розбиттю. ЕМА
  дивиться тільки назад, майбутнього в події немає.
- Цілі для навчання в клас не входять — вони будуються окремо
  (`rules/scripts/zigzag_targets.py`, `rules/02-markup.md`).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from class210ema4 import ema
from class210x210x4c import Class210x210x4c, FEATURES as PARENT_FEATURES

FEATURES = list(PARENT_FEATURES)
PERIODS = list(range(10, 140, 10))      # 13 періодів: 10 … 130


@dataclass
class Class210x4bEma:
    """Набір подій клас210х4бема10х10х130."""

    x: np.ndarray            # (N, 13, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    periods: list[int] = field(default_factory=lambda: list(PERIODS))
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    periods: list
    nan_by_feature: dict


def build(parent: Class210x210x4c, periods: list[int] | None = None
          ) -> tuple[Class210x4bEma, BuildReport]:
    """Будує клас з клас210х210х4ц, відсортованого за часом."""
    periods = list(periods or PERIODS)
    if parent.x.ndim != 2 or parent.x.shape[1] != len(FEATURES):
        raise ValueError(f"очікується масив (N, {len(FEATURES)})")
    if any(period < 1 for period in periods):
        raise ValueError("періоди мають бути >= 1")
    if len(parent) and np.any(np.diff(parent.timestamp) <= 0):
        raise ValueError("події мають іти за часом, без повторів")

    x = np.stack(
        [np.stack([ema(parent.x[:, feature], period)
                   for feature in range(len(FEATURES))], axis=1)
         for period in periods], axis=1) if len(parent) else np.zeros(
        (0, len(periods), len(FEATURES)))

    dataset = Class210x4bEma(
        x=x, timestamp=parent.timestamp, price_open=parent.price_open,
        price_close=parent.price_close, periods=periods)
    report = BuildReport(
        events_in=len(parent), events_out=len(dataset), periods=periods,
        nan_by_feature={name: int(np.isnan(x[:, :, i]).sum())
                        for i, name in enumerate(FEATURES)})
    return dataset, report


def save(dataset: Class210x4bEma, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        periods=np.array(dataset.periods),
        features=np.array(dataset.features))


def load(path) -> Class210x4bEma:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x4bEma(
            x=data["x"], timestamp=data["timestamp"],
            price_open=data["price_open"], price_close=data["price_close"],
            periods=[int(value) for value in data["periods"]],
            features=list(data["features"]))
