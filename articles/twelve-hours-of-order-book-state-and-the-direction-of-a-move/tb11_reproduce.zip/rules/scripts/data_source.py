"""Читання вихідних даних і робоча копія.

Правила: rules/01-data-and-db.md
- /Users/at/Desktop/DATA — тільки читання.
- Обробка ведеться над робочою копією в data/.
- З вихідного CSV беруться тільки SOURCE_COLUMNS.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

SOURCE_ROOT = Path("/Users/at/Desktop/DATA")
PROJECT_ROOT = Path(__file__).resolve().parents[2]
WORK_ROOT = PROJECT_ROOT / "data"

# Тільки ці колонки (rules/01-data-and-db.md → Колонки початкового датасету)
SOURCE_COLUMNS = [
    "timestamp",
    "price_avg",
    "const_resist",
    "resist_plus",
    "resist_minus",
    "const_support",
    "support_plus",
    "support_minus",
    "vol_buy",
    "vol_sell",
]

# Дата відсічки основного датасету (включно)
DEFAULT_END_DATE = "2026-08-16"


@dataclass
class LoadReport:
    """Звіт про завантаження одного файлу."""

    path: str
    rows_read: int
    nan_rows_dropped: int
    duplicates_removed: int
    rows_kept: int


def source_files(pair: str, end_date: str = DEFAULT_END_DATE,
                 root: Path | None = None) -> list[Path]:
    """Файли пари з початку доступного періоду до end_date включно."""
    root = Path(root) if root is not None else SOURCE_ROOT
    files = sorted(root.glob(f"*/*/{pair}/1S_*_{pair}.csv"))
    return [f for f in files if _file_date(f) <= end_date]


def _file_date(path: Path) -> str:
    """1S_2026-05-01_BTC_USDT.csv -> '2026-05-01'."""
    return path.name.split("_")[1]


def copy_to_work(files: list[Path], root: Path | None = None,
                 work_root: Path | None = None) -> list[Path]:
    """Копіює файли в data/, зберігаючи структуру. Джерело не змінюється."""
    root = Path(root) if root is not None else SOURCE_ROOT
    work_root = Path(work_root) if work_root is not None else WORK_ROOT
    copied = []
    for src in files:
        dst = work_root / src.relative_to(root)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists() or dst.stat().st_size != src.stat().st_size:
            shutil.copy2(src, dst)
        copied.append(dst)
    return copied


def load_day(path: Path) -> tuple[pd.DataFrame, LoadReport]:
    """Читає добовий CSV: тільки потрібні колонки, без дублікатів timestamp."""
    frame = pd.read_csv(path, usecols=SOURCE_COLUMNS)[SOURCE_COLUMNS]
    rows_read = len(frame)

    frame = frame.dropna(subset=SOURCE_COLUMNS)
    rows_valid = len(frame)

    frame = frame.sort_values("timestamp", kind="stable")
    frame = frame.drop_duplicates(subset="timestamp", keep="first")
    frame = frame.reset_index(drop=True)

    report = LoadReport(
        path=str(path),
        rows_read=rows_read,
        nan_rows_dropped=rows_read - rows_valid,
        duplicates_removed=rows_valid - len(frame),
        rows_kept=len(frame),
    )
    return frame, report


def to_array(frame: pd.DataFrame) -> np.ndarray:
    """DataFrame -> float64 масив у порядку SOURCE_COLUMNS."""
    return frame[SOURCE_COLUMNS].to_numpy(dtype=np.float64)
