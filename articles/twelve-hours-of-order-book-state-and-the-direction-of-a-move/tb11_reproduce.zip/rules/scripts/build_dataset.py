"""Побудова датасету клас210х14х4: сирі CSV -> train / val / test.

Правила: rules/01-data-and-db.md

Порядок:
  1. Копія потрібних файлів у data/ (джерело — тільки читання).
  2. Читання 10 колонок, очистка дублікатів по timestamp.
  3. Заповнення коротких пропусків часу (--fill-gaps), клас210х8 -> клас210х14х4.
  4. Розбиття 75/25, train+val на 10 частин, train:val = 4:1.
  5. Запис train.npz / val.npz / test.npz + report.json.

Запуск:
    python3 rules/scripts/build_dataset.py --pair BTC_USDT
    python3 rules/scripts/build_dataset.py --pair BTC_USDT --fill-gaps 60
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x8
import class210x14x4
import fill_gaps
from class210x14x4 import Class210x14x4
from data_source import (DEFAULT_END_DATE, PROJECT_ROOT, copy_to_work, load_day,
                         source_files, to_array)
from split import split_dataset


def build_pair(pair: str, end_date: str, step: int, seed: int, out_dir: Path,
               source_root: Path | None = None,
               work_root: Path | None = None, max_gap: int = 0) -> dict:
    files = source_files(pair, end_date, root=source_root)
    if not files:
        raise SystemExit(f"немає файлів для {pair} до {end_date}")
    print(f"[1/5] файлів: {len(files)} ({files[0].name} .. {files[-1].name})")

    work_files = copy_to_work(files, root=source_root, work_root=work_root)
    print(f"[2/5] копія в data/: {len(work_files)} файлів")

    parts, rows_read, duplicates, nan_rows = [], 0, 0, 0
    filled = fill_gaps.empty_report(max_gap)
    for i, path in enumerate(work_files, 1):
        frame, report = load_day(path)
        rows_read += report.rows_read
        duplicates += report.duplicates_removed
        nan_rows += report.nan_rows_dropped
        rows, day_fill = fill_gaps.fill(to_array(frame), max_gap)
        filled += day_fill
        parts.append(class210x8.build(rows, step=step))
        if i % 20 == 0 or i == len(work_files):
            print(f"      {i}/{len(work_files)} файлів, "
                  f"подій: {sum(len(p) for p in parts)}")

    base = class210x8.concat(parts)
    print(f"[3/5] клас210х8: {len(base)} подій, "
          f"дублікатів прибрано: {duplicates}, рядків з NaN: {nan_rows}")
    if max_gap:
        print(f"      пропуски <= {max_gap} c: заповнено {filled.gaps_filled} "
              f"({filled.seconds_filled} секунд), лишилось {filled.gaps_left} "
              f"({filled.seconds_left} секунд)")

    dataset, build_report = class210x14x4.build(base)
    print(f"[4/5] клас210х14х4: {len(dataset)} подій, "
          f"відкинуто (нульовий обʼєм): {build_report.dropped_zero_volume}")

    split = split_dataset(len(dataset), labels=None, seed=seed)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, idx in (("train", split.train), ("val", split.val),
                      ("test", split.test)):
        class210x14x4.save(_take(dataset, idx), out_dir / f"{name}.npz")
    print(f"[5/5] записано в {out_dir}: {split.sizes()}")

    return {
        "pair": pair,
        "end_date": end_date,
        "files": len(files),
        "first_file": files[0].name,
        "last_file": files[-1].name,
        "rows_read": rows_read,
        "duplicates_removed": duplicates,
        "nan_rows_dropped": nan_rows,
        "event_step": step,
        "fill_gaps": asdict(filled),
        "seed": seed,
        "class210x8_events": len(base),
        "class210x14x4": asdict(build_report),
        "split_sizes": split.sizes(),
        "part_sizes": [len(p) for p in split.parts],
    }


def _take(dataset: Class210x14x4, idx: np.ndarray) -> Class210x14x4:
    return Class210x14x4(
        x=dataset.x[idx],
        timestamp=dataset.timestamp[idx],
        price_open=dataset.price_open[idx],
        price_close=dataset.price_close[idx],
        features=dataset.features,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--step", type=int, default=class210x8.EVENT_LENGTH,
                        help="крок між подіями в секундах (210 = без перекриття)")
    parser.add_argument("--fill-gaps", type=int, default=0,
                        help="заповнювати пропуски часу до N секунд (0 — не "
                             f"заповнювати, рекомендовано {fill_gaps.MAX_GAP})")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    out_dir = args.out or (PROJECT_ROOT / "data" / "datasets" / args.pair
                           / "class210x14x4")
    report = build_pair(args.pair, args.end_date, args.step, args.seed, out_dir,
                        max_gap=args.fill_gaps)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
