"""Скейлери: одна фіча або одна ціль -> ті самі значення в іншій шкалі.

Правила: rules/01-data-and-db.md → Скейлери

Три способи привести ряд до порівнюваного вигляду. Усі три — на самих
значеннях ряду, без сторонніх констант, тому їх можна застосувати
однаково і до фічі, і до цілі:

| Скейлер | Формула | Межі |
| ------- | ------- | ---- |
| `minmax` | `2 * (x - min) / (max - min) - 1` | `[-1, 1]` |
| `robust` | `(x - медіана) / (q75 - q25)` | без меж, центр 0 |
| `quantile` | `2 * u - 1`, `u` — місце x в емпіричній CDF | `[-1, 1]` |

- `NaN` не входять у розрахунок параметрів і лишаються `NaN` на виході.
- Вироджений ряд (усі значення однакові, нульовий IQR) дає нулі: ділити
  нема на що, а різниці всередині ряду немає.
- Кожен скейлер повертає значення й свої параметри — щоб той самий
  результат можна було перерахувати або застосувати до іншого ряду.

Використання: rules/scripts/class_card.py (колонки розподілу вкладки
«Класи датасету»), scripts/zigzag_correlation.py (кореляції ЕМА).
"""

from __future__ import annotations

import numpy as np


def _clean(values: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Ряд, маска чисел і порожній вихід під NaN."""
    values = np.asarray(values, dtype=float)
    good = np.isfinite(values)
    return values, good, np.full(len(values), np.nan)


def minmax(values: np.ndarray) -> tuple[np.ndarray, dict]:
    """Мінмакс у [-1, 1]: мінімум ряду -> -1, максимум -> +1.

        x -> 2 * (x - min) / (max - min) - 1
    """
    values, good, out = _clean(values)
    if not good.any():
        return out, {"min": None, "max": None}
    low, high = float(values[good].min()), float(values[good].max())
    out[good] = (0.0 if high == low
                 else 2 * (values[good] - low) / (high - low) - 1)
    return out, {"min": low, "max": high}


def robust(values: np.ndarray) -> tuple[np.ndarray, dict]:
    """Робаст: центр — медіана, масштаб — IQR.

        x -> (x - медіана) / (q75 - q25)

    Центр і масштаб рахуються з квантилів, тому викиди на них не
    впливають (на відміну від z-score, куди входить кожен хвіст).
    """
    values, good, out = _clean(values)
    if not good.any():
        return out, {"center": None, "iqr": None}
    center = float(np.median(values[good]))
    q25, q75 = (float(np.quantile(values[good], 0.25)),
                float(np.quantile(values[good], 0.75)))
    iqr = q75 - q25
    out[good] = 0.0 if iqr <= 0 else (values[good] - center) / iqr
    return out, {"center": center, "q25": q25, "q75": q75,
                 "iqr": float(iqr) if iqr > 0 else 0.0}


def quantile(values: np.ndarray) -> tuple[np.ndarray, dict]:
    """Квантильний: значення -> його місце в емпіричній CDF ряду.

        u = (частка значень < x + частка значень <= x) / 2
        x -> 2 * u - 1

    Перетворення рангове: воно не масштабує вісь, а замінює значення
    часткою у своєму ряду. Тому воно монотонне — порядок значень
    зберігається, а форма розподілу стає рівною.
    """
    values, good, out = _clean(values)
    if not good.any():
        return out, {"n": 0}
    clean = values[good]
    order = np.sort(clean)
    left = np.searchsorted(order, clean, side="left")
    right = np.searchsorted(order, clean, side="right")
    out[good] = 2 * (left + right) / (2.0 * len(clean)) - 1
    return out, {"n": int(len(clean))}


QUANTILE_KNOTS = 1001   # опорних точок CDF, якими зберігається квантиль


def quantile_fit(values: np.ndarray, knots: int = QUANTILE_KNOTS) -> dict:
    """Параметри квантильного скейлера: опорні точки CDF ряду.

    Потрібно, коли скейлер рахується на одній вибірці (`train`), а
    застосовується до інших (`val`, `test`) — щоб перетворення було
    **тим самим**, а не перерахованим по чужому ряду
    (rules/01-data-and-db.md → Порядок дій і захист від витоку).

    Замість усього ряду зберігаються `knots` рівновіддалених квантилів:
    файл лишається малим, а між ними йде лінійна інтерполяція.

    Частки беруться тією самою умовністю, що й у `quantile`: значення
    рангу `i` серед `n` дістає `u = (i + 0.5) / n`. Тому на своєму ж ряду
    `quantile_apply(x, quantile_fit(x))` повторює `quantile(x)`.
    """
    values = np.asarray(values, dtype=float)
    clean = values[np.isfinite(values)]
    if not len(clean):
        return {"n": 0, "levels": [], "knots": []}
    n = len(clean)
    grid = np.linspace(0.0, 1.0, int(knots))     # місце серед порядкових
    levels = (grid * (n - 1) + 0.5) / n          # частка тієї самої умовності
    return {"n": int(n), "levels": levels.tolist(),
            "knots": np.quantile(clean, grid).tolist()}


def quantile_apply(values: np.ndarray, params: dict) -> np.ndarray:
    """Застосовує збережений квантильний скейлер: `x -> 2 * u - 1`.

    `u` — місце `x` серед опорних квантилів. Значення поза межами ряду,
    на якому скейлер рахувався, лягають на його краї — найменшу й
    найбільшу частку (`0.5 / n` і `1 - 0.5 / n`).
    Вироджений ряд (усі опорні точки однакові) дає нулі.
    """
    values, good, out = _clean(values)
    knots = np.asarray(params.get("knots", []), dtype=float)
    levels = np.asarray(params.get("levels", []), dtype=float)
    if not good.any() or not len(knots):
        return out
    if knots[-1] == knots[0]:
        out[good] = 0.0
        return out
    out[good] = 2 * np.interp(values[good], knots, levels) - 1
    return out


# Перелік для вкладок і скриптів: ключ -> функція.
SCALERS = {"minmax": minmax, "robust": robust, "quantile": quantile}

# Підписи українською — ті самі, що на дашборді.
TITLES = {"minmax": "мінмакс", "robust": "робаст", "quantile": "квантиль"}
