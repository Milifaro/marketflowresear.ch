"""Розбиття по часу: суцільні відрізки підряд і проміжок між ними.

Правила: rules/03-models.md → Розбиття даних → Розбиття по часу

`split.py` перемішує події й тому годиться тільки для задач, де сусідні
події незалежні. Для рядів це не так: подія і її сусід за 210 с лежать
в одній нозі зігзага й мають майже ту саму ціль. Перемішування розкидає
таких сусідів по train, val і test — і test перестає бути незалежним.

Тут вибірки йдуть **суцільними відрізками в хронологічному порядку**:

    [ train ] ▒ [ val ] ▒ [ test ]        ▒ — проміжок, події викидаються

Проміжок (embargo) береться **максимумом із двох глибин памʼяті**:

- глибина фічі — скільки подій назад дивиться найдовша ЕМА (`min_gap`);
- глибина цілі — ціла нога зігзага: край вибірки ріжеться по півоту, щоб
  дві сусідні вибірки не поділили одну ногу.

Різати по півоту — не те саме, що відступити фіксовану кількість подій:
нога буває і пів дня, і чотири доби, а витік дає саме спільна нога.

Функції:
    chronological()  — одне розбиття train / val / test
    walk_forward()   — кілька послідовних вікон «вчись на минулому,
                       міряй на наступному»
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

TEST_FRACTION = 0.25     # доля test в одному розбитті
VAL_FRACTION = 0.15      # доля val від того, що лишилось під train
FOLDS = 5                # вікон у walk-forward
FIRST_TRAIN = 0.5        # доля датасету під train першого вікна


@dataclass
class Fold:
    """Одне вікно: індекси подій по вибірках і що викинуто у проміжки."""

    index: int
    train: np.ndarray
    val: np.ndarray
    test: np.ndarray
    dropped: dict = field(default_factory=dict)

    def sizes(self) -> dict[str, int]:
        return {"train": len(self.train), "val": len(self.val),
                "test": len(self.test)}


def cut_before(pivots: np.ndarray, start: int, min_gap: int) -> int:
    """Останній півот перед `start`, віддалений від нього щонайменше на `min_gap`.

    Повертає межу: вибірка ліворуч закінчується **до** цього індексу.
    Немає такого півота — повертає 0 (ліворуч нічого не лишається).
    """
    pivots = np.asarray(pivots, dtype=int)
    if min_gap < 0:
        raise ValueError("min_gap має бути >= 0")
    good = pivots[(pivots < start) & (start - pivots >= min_gap)]
    return int(good[-1]) if len(good) else 0


def legs_between(pivots: np.ndarray, start: int, stop: int) -> int:
    """Скільки ніг зігзага цілком лягло у відрізок [start, stop).

    Це і є розмір вибірки в незалежних одиницях: усередині ноги сусідні
    події майже однакові й новою інформацією не є.
    """
    inside = np.asarray(pivots, dtype=int)
    inside = inside[(inside >= start) & (inside < stop)]
    return max(len(inside) - 1, 0)


def _window(n: int, pivots: np.ndarray, test_from: int, test_to: int,
            val_fraction: float, min_gap: int, index: int) -> Fold | None:
    """Одне вікно: test заданий, val і train відрізаються ліворуч по півотах."""
    val_to = cut_before(pivots, test_from, min_gap)
    if val_to <= 0:
        return None
    val_from = cut_before(pivots, max(int(round(val_to * (1 - val_fraction))), 1),
                          min_gap)
    if val_from <= 0:
        return None
    train_to = cut_before(pivots, val_from, min_gap)
    if train_to <= 0:
        return None

    fold = Fold(
        index=index,
        train=np.arange(0, train_to),
        val=np.arange(val_from, val_to),
        test=np.arange(test_from, min(test_to, n)),
        dropped={"train_val": int(val_from - train_to),
                 "val_test": int(test_from - val_to)},
    )
    return fold if len(fold.train) and len(fold.val) and len(fold.test) else None


def chronological(n_events: int, pivots: np.ndarray,
                  test_fraction: float = TEST_FRACTION,
                  val_fraction: float = VAL_FRACTION,
                  min_gap: int = 0) -> Fold:
    """Одне розбиття: train / val / test суцільними відрізками підряд."""
    if n_events < 1:
        raise ValueError("подій має бути >= 1")
    if not 0 < test_fraction < 1:
        raise ValueError("test_fraction має бути в (0, 1)")
    test_from = int(round(n_events * (1 - test_fraction)))
    fold = _window(n_events, pivots, test_from, n_events, val_fraction,
                   min_gap, 0)
    if fold is None:
        raise ValueError("півотів не вистачає на проміжки між вибірками")
    return fold


def walk_forward(n_events: int, pivots: np.ndarray, folds: int = FOLDS,
                 first_train: float = FIRST_TRAIN,
                 val_fraction: float = VAL_FRACTION,
                 min_gap: int = 0) -> list[Fold]:
    """Послідовні вікна: train росте, test щоразу йде далі в часі.

    Хвіст датасету (`1 - first_train`) ділиться на `folds` рівних відрізків
    по кількості подій — це test кожного вікна. Усе, що лівіше, йде під
    train і val того самого вікна, з проміжками по півотах.
    """
    if folds < 1:
        raise ValueError("вікон має бути >= 1")
    if not 0 < first_train < 1:
        raise ValueError("first_train має бути в (0, 1)")

    start = int(round(n_events * first_train))
    edges = np.linspace(start, n_events, folds + 1).round().astype(int)
    built = []
    for index, (test_from, test_to) in enumerate(zip(edges[:-1], edges[1:])):
        fold = _window(n_events, pivots, int(test_from), int(test_to),
                       val_fraction, min_gap, index)
        if fold is not None:
            built.append(fold)
    if not built:
        raise ValueError("жодного вікна: півотів не вистачає на проміжки")
    return built
