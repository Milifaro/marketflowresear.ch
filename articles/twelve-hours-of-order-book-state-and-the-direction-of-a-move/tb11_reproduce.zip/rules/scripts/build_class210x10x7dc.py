"""Побудова датасету клас210х10х7дц і класів, що з нього ростуть.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х10х9,
         клас210х10х7, клас210х10х7дц, клас210х10-1х7дц,
         клас210х10-1х3+1дц, клас210х10-1х2д, клас210х10-1х7д/д
Дослідження: research/21-class210x10x7dc/

Пайплайн однією командою, для кожної монети окремо:

    data/<рік>/<місяць>/<PAIR>/*.csv
        -> клас210х10х9         (10 блоків по 21 с, середні 9 фіч)
        -> клас210х10х7         (рівні / обʼєм блоку)
        -> клас210х10х7дц       (перші похідні по блоках)
        -> клас210х10-1х7дц     (те саме без першої плашки)
        -> клас210х10-1х3+1дц   (три нормовані різниці пар плюс ціна)
        -> клас210х10-1х2д      (похідна обʼєму на похідну свого рівня)
        -> клас210х10-1х7д/д    (шість відношень похідних плюс ціна)

Похідна першого блоку переходить через межу подій, тому вона рахується
на **суцільному ряду монети**, до розбиття: спершу всі події за часом,
потім похідні, і аж потім train / val.

## Розбиття за датою

    подія скінчилась до CUT            -> train
    подія почалась з CUT і до END      -> val

`CUT = 2026-08-14 00:00 UTC`, `END = 2026-09-07 00:00 UTC`. Межа спільна
для всіх шести монет: train — усе, що було до 14.08, val — свіжий
відрізок 14.08 … 07.09, якого немає в train у жодної монети.

Джерело на Desktop не читається — тільки робоча копія `data/`.

Запуск:
    python3 rules/scripts/build_class210x10x7dc.py
    python3 rules/scripts/build_class210x10x7dc.py --pair BTC_USDT
    python3 rules/scripts/build_class210x10x7dc.py --fill-gaps 0
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x10m1x2d
import class210x10m1x3p1dc
import class210x10m1x7dd
import class210x10m1x7dc
import class210x10x7
import class210x10x7dc
import class210x10x9
import fill_gaps
from class210x10x9 import EVENT_LENGTH
from data_source import PROJECT_ROOT, load_day, to_array

WORK_ROOT = PROJECT_ROOT / "data"
DATASETS = WORK_ROOT / "datasets"

PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
PARTS = ("train", "val")

CUT = "2026-08-14"          # межа train | val, UTC
END = "2026-09-07"          # правий край валідації, UTC
FILL_GAPS = 60              # пропуски до хвилини заповнюються (rules/01)

# Ім'я теки датасету на кожен клас пайплайну.
FOLDERS = {"class210x10x9": class210x10x9,
           "class210x10x7": class210x10x7,
           "class210x10x7dc": class210x10x7dc,
           "class210x10m1x7dc": class210x10m1x7dc,
           "class210x10m1x3p1dc": class210x10m1x3p1dc,
           "class210x10m1x2d": class210x10m1x2d,
           "class210x10m1x7dd": class210x10m1x7dd}


def stamp(day: str) -> int:
    """'2026-08-14' -> timestamp UTC початку доби."""
    moment = dt.datetime.strptime(day, "%Y-%m-%d")
    return int(moment.replace(tzinfo=dt.timezone.utc).timestamp())


def utc(seconds: int) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def work_files(pair: str, root: Path | None = None) -> list[Path]:
    """Файли робочої копії data/<рік>/<місяць>/<PAIR>/."""
    root = Path(root) if root is not None else WORK_ROOT
    return sorted(root.glob(f"*/*/{pair}/1S_*_{pair}.csv"))


def series(files: list[Path], step: int = EVENT_LENGTH,
           max_gap: int = FILL_GAPS, log=print) -> tuple:
    """Усі події монети одним рядом за часом (клас210х10х9)."""
    parts, filled = [], fill_gaps.empty_report(max_gap)
    for index, path in enumerate(files, 1):
        frame, _ = load_day(path)
        rows, report = fill_gaps.fill(to_array(frame), max_gap)
        filled = filled + report
        parts.append(class210x10x9.build(rows, step))
        if index % 40 == 0 or index == len(files):
            log(f"      {index}/{len(files)} файлів, "
                f"подій: {sum(len(p) for p in parts)}")
    return class210x10x9.order_by_time(class210x10x9.concat(parts)), filled


def split_by_date(t_start: np.ndarray, t_end: np.ndarray, cut: str = CUT,
                  end: str = END) -> dict:
    """Індекси подій train / val за датою. Подія цілком по один бік межі."""
    edge, right = stamp(cut), stamp(end)
    train = np.flatnonzero(t_end < edge)
    val = np.flatnonzero((t_start >= edge) & (t_end < right))
    return {"train": train, "val": val}


def build_pair(pair: str, out_root: Path, step: int = EVENT_LENGTH,
               max_gap: int = FILL_GAPS, cut: str = CUT, end: str = END,
               root: Path | None = None, log=print) -> dict:
    """Одна монета: сім класів, розбитих за датою."""
    files = work_files(pair, root)
    if not files:
        raise SystemExit(f"немає робочої копії data/ для {pair}")
    log(f"[{pair}] файлів у робочій копії: {len(files)}")

    nine, filled = series(files, step, max_gap, log)
    if not len(nine):
        raise SystemExit(f"{pair}: жодної події")
    seven, seven_report = class210x10x7.build(nine)
    derived, derived_report = class210x10x7dc.build(seven)
    trimmed, trimmed_report = class210x10m1x7dc.build(derived)
    paired, paired_report = class210x10m1x3p1dc.build(trimmed)
    sided, sided_report = class210x10m1x2d.build(trimmed)
    doubled, doubled_report = class210x10m1x7dd.build(trimmed)
    log(f"[{pair}] подій {len(nine)}, розривів {derived_report.seams}, "
        f"NaN у клас210х10х7 {seven_report.nan_values}")

    parts = split_by_date(nine.t_start, nine.t_end, cut, end)
    datasets = {"class210x10x9": (class210x10x9, nine),
                "class210x10x7": (class210x10x7, seven),
                "class210x10x7dc": (class210x10x7dc, derived),
                "class210x10m1x7dc": (class210x10m1x7dc, trimmed),
                "class210x10m1x3p1dc": (class210x10m1x3p1dc, paired),
                "class210x10m1x2d": (class210x10m1x2d, sided),
                "class210x10m1x7dd": (class210x10m1x7dd, doubled)}
    counts = {}
    for folder, (module, dataset) in datasets.items():
        out_dir = out_root / pair / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        for name in PARTS:
            module.save(module.take(dataset, parts[name]),
                        out_dir / f"{name}.npz")
        counts[folder] = {name: int(len(parts[name])) for name in PARTS}

    report = {
        "pair": pair,
        "files": len(files),
        "event_seconds": EVENT_LENGTH,
        "event_step": step,
        "fill_gaps": asdict(filled),
        "events": len(nine),
        "period": {"from_utc": utc(nine.t_start[0]),
                   "to_utc": utc(nine.t_end[-1])},
        "split": {"cut_utc": f"{cut} 00:00:00", "end_utc": f"{end} 00:00:00",
                  **{name: int(len(parts[name])) for name in PARTS},
                  "dropped": int(len(nine) - sum(len(parts[name])
                                                 for name in PARTS))},
        "counts": counts,
        "class210x10x7": asdict(seven_report),
        "class210x10x7dc": asdict(derived_report),
        "class210x10m1x7dc": asdict(trimmed_report),
        "class210x10m1x3p1dc": asdict(paired_report),
        "class210x10m1x2d": asdict(sided_report),
        "class210x10m1x7dd": asdict(doubled_report),
    }
    log(f"[{pair}] train {report['split']['train']}, "
        f"val {report['split']['val']}, поза межами "
        f"{report['split']['dropped']}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None,
                        help="монета; можна кілька разів, типово всі шість")
    parser.add_argument("--step", type=int, default=EVENT_LENGTH)
    parser.add_argument("--fill-gaps", type=int, default=FILL_GAPS)
    parser.add_argument("--cut", default=CUT)
    parser.add_argument("--end", default=END)
    parser.add_argument("--data", type=Path, default=None,
                        help="корінь робочої копії; типово data/")
    parser.add_argument("--out", type=Path, default=DATASETS)
    args = parser.parse_args()

    pairs = args.pair or list(PAIRS)
    reports = {}
    for pair in pairs:
        reports[pair] = build_pair(pair, args.out, args.step, args.fill_gaps,
                                   args.cut, args.end, args.data)
    summary = {
        "script": "rules/scripts/build_class210x10x7dc.py",
        "command": "python3 rules/scripts/build_class210x10x7dc.py",
        "pairs": pairs,
        "cut_utc": f"{args.cut} 00:00:00",
        "end_utc": f"{args.end} 00:00:00",
        "fill_gaps": args.fill_gaps,
        "event_step": args.step,
        "totals": {
            part: sum(reports[pair]["split"][part] for pair in pairs)
            for part in PARTS},
        "by_pair": reports,
    }
    for pair in pairs:
        for folder in FOLDERS:
            (args.out / pair / folder / "report.json").write_text(
                json.dumps(reports[pair], indent=2, ensure_ascii=False),
                encoding="utf-8")
    (args.out / "class210x10x7dc.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"train {summary['totals']['train']}, val {summary['totals']['val']}")


if __name__ == "__main__":
    main()
