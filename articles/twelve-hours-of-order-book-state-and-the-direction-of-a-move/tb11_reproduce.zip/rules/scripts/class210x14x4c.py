"""клас210х14х4ц — клас210х14х3 плюс цінова фіча по блоках.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х4ц

Четверта фіча будується тим самим правилом, що й решта: нормована різниця
двох сторін у межах блоку з 14 секунд, безрозмірна, межі [-1, 1].
Сторони для ціни — рух вгору й рух вниз:

    up_j    = Σ додатних посекундних змін ціни в блоці
    down_j  = Σ модулів відʼємних змін
    price_balance = (up_j - down_j) / (up_j + down_j)

Через телескопування чисельник дорівнює `кінець блоку - початок блоку`,
тому фіча читається як «наскільки прямим був рух»: `+1` — ціна в блоці
тільки росла, `-1` — тільки падала, `0` — повернулась туди, звідки вийшла.

- Зміни рахуються всередині блоку: 13 різниць на блок, межі блоків не
  зшиваються — так усі 15 блоків однакові.
- Блок, де ціна не змінилась жодної секунди, дає нульовий знаменник і
  `NaN`; подія лишається, кількість фіксується у звіті побудови.
- **4 фічі × 15 значень.** Форма події: `(15, 4)`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

import class210x14x3
from class210x14x4 import BLOCK, N_BLOCKS
from class210x8 import (EVENT_LENGTH, PRICE_IDX, TS_IDX,  # noqa: E501
                        contiguous_segments)
from class210x14x3 import Class210x14x3
from data_source import SOURCE_COLUMNS

FEATURES = list(class210x14x3.FEATURES) + ["price_balance"]


@dataclass
class Class210x14x4c:
    """Набір подій клас210х14х4ц."""

    x: np.ndarray            # (N, 15, 4)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class BuildReport:
    """Звіт побудови."""

    events_in: int
    events_out: int
    nan_price_balance: int   # блоків, де ціна не рухалась жодної секунди
    matched: int             # подій, яким знайшлась цінова фіча


def price_balance(prices: np.ndarray) -> np.ndarray:
    """(N, 210) посекундних цін -> (N, 15) нормованих різниць по блоках."""
    prices = np.asarray(prices, dtype=float)
    if prices.ndim != 2 or prices.shape[1] != EVENT_LENGTH:
        raise ValueError(f"очікується масив (N, {EVENT_LENGTH})")
    blocks = prices.reshape(len(prices), N_BLOCKS, BLOCK)
    steps = np.diff(blocks, axis=2)
    walked = np.abs(steps).sum(axis=2)
    moved = blocks[:, :, -1] - blocks[:, :, 0]
    with np.errstate(invalid="ignore", divide="ignore"):
        value = np.where(walked > 0, moved / walked, np.nan)
    return value


def from_rows(rows: np.ndarray, step: int = EVENT_LENGTH
              ) -> tuple[np.ndarray, np.ndarray]:
    """Цінова фіча подій масиву SOURCE_COLUMNS: (N, 15) і timestamp (N,).

    Нарізка на події — та сама, що в клас210х8: безперервні 210 секунд,
    крок `step`.
    """
    rows = np.asarray(rows, dtype=float)
    if rows.ndim != 2 or rows.shape[1] != len(SOURCE_COLUMNS):
        raise ValueError(f"очікується масив (N, {len(SOURCE_COLUMNS)})")
    ts = rows[:, TS_IDX]
    windows, starts = [], []
    for lo, hi in contiguous_segments(ts):
        for begin in range(lo, hi - EVENT_LENGTH + 1, step):
            windows.append(rows[begin:begin + EVENT_LENGTH, PRICE_IDX])
            starts.append(begin)
    if not windows:
        return (np.empty((0, N_BLOCKS)), np.empty(0, dtype=np.int64))
    return price_balance(np.stack(windows)), ts[np.asarray(starts)].astype(
        np.int64)


def build(parent: Class210x14x3, prices: np.ndarray, timestamp: np.ndarray
          ) -> tuple[Class210x14x4c, BuildReport]:
    """Додає цінову фічу до клас210х14х3, зіставляючи події за timestamp.

    Подія без цінової фічі відкидається — фіча має бути в кожній події.
    """
    if parent.x.ndim != 3 or parent.x.shape[1:] != (N_BLOCKS,
                                                    len(class210x14x3.FEATURES)):
        raise ValueError(
            f"очікується масив (N, {N_BLOCKS}, {len(class210x14x3.FEATURES)})")
    prices = np.asarray(prices, dtype=float)
    if prices.ndim != 2 or prices.shape[1] != N_BLOCKS:
        raise ValueError(f"цінова фіча має форму (N, {N_BLOCKS})")

    position = {int(ts): i for i, ts in enumerate(timestamp)}
    keep = np.array([int(ts) in position for ts in parent.timestamp], dtype=bool)
    index = np.array([position[int(ts)] for ts in parent.timestamp[keep]],
                     dtype=int)
    price = prices[index] if len(index) else np.empty((0, N_BLOCKS))

    dataset = Class210x14x4c(
        x=np.concatenate([parent.x[keep], price[:, :, None]], axis=2),
        timestamp=parent.timestamp[keep],
        price_open=parent.price_open[keep],
        price_close=parent.price_close[keep],
    )
    report = BuildReport(
        events_in=len(parent),
        events_out=len(dataset),
        nan_price_balance=int(np.isnan(price).sum()),
        matched=int(keep.sum()),
    )
    return dataset, report


def save(dataset: Class210x14x4c, path) -> None:
    """Зберігає набір у .npz."""
    np.savez_compressed(
        path,
        x=dataset.x.astype(np.float32),
        timestamp=dataset.timestamp,
        price_open=dataset.price_open,
        price_close=dataset.price_close,
        features=np.array(dataset.features),
    )


def load(path) -> Class210x14x4c:
    """Читає набір з .npz."""
    with np.load(path, allow_pickle=False) as data:
        return Class210x14x4c(
            x=data["x"],
            timestamp=data["timestamp"],
            price_open=data["price_open"],
            price_close=data["price_close"],
            features=list(data["features"]),
        )
