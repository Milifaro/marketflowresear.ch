"""Побудова датасету клас210ема4ц з готового клас210х210х4ц.

Правила: rules/01-data-and-db.md → Класи (події) → клас210ема4ц

ЕМА — наскрізний ряд, тому вибірки спершу складаються в один ряд за
`timestamp`, а потім розкладаються по тому самому розбиттю.

Запуск:
    python3 rules/scripts/build_class210ema4c.py --pair BTC_USDT --period 200
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210ema4c
import class210x210x4c
from class210ema4 import DEFAULT_PERIOD
from class210x210x4c import Class210x210x4c
from data_source import PROJECT_ROOT

PARTS = ("train", "val", "test")


def merge(in_dir: Path) -> tuple[Class210x210x4c, dict]:
    """Усі вибірки одним рядом, відсортованим за часом."""
    x, timestamp, price_open, price_close, order = [], [], [], [], {}
    for name in PARTS:
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        part = class210x210x4c.load(path)
        order[name] = np.asarray(part.timestamp, dtype=np.int64)
        x.append(np.asarray(part.x, dtype=float))
        timestamp.append(order[name])
        price_open.append(np.asarray(part.price_open, dtype=float))
        price_close.append(np.asarray(part.price_close, dtype=float))
    timestamp = np.concatenate(timestamp)
    index = np.argsort(timestamp, kind="stable")
    row = Class210x210x4c(x=np.concatenate(x)[index], timestamp=timestamp[index],
                          price_open=np.concatenate(price_open)[index],
                          price_close=np.concatenate(price_close)[index])
    return row, order


def take_by_timestamp(dataset: class210ema4c.Class210ema4c,
                      wanted: np.ndarray) -> class210ema4c.Class210ema4c:
    """Події у порядку `wanted`."""
    position = {int(ts): i for i, ts in enumerate(dataset.timestamp)}
    missing = [int(ts) for ts in wanted if int(ts) not in position]
    if missing:
        raise SystemExit(f"немає {len(missing)} подій розбиття у ряду "
                         f"(перша: {missing[0]})")
    index = np.array([position[int(ts)] for ts in wanted], dtype=int)
    return class210ema4c.Class210ema4c(
        x=dataset.x[index], timestamp=dataset.timestamp[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index], period=dataset.period)


def build_pair(in_dir: Path, out_dir: Path, period: int) -> dict:
    row, order = merge(in_dir)
    dataset, report = class210ema4c.build(row, period)
    out_dir.mkdir(parents=True, exist_ok=True)
    result = {"source": str(in_dir), "period": period,
              "events": len(dataset), **asdict(report), "parts": {}}
    for name in PARTS:
        part = take_by_timestamp(dataset, order[name])
        class210ema4c.save(part, out_dir / f"{name}.npz")
        result["parts"][name] = {"events": len(part)}
        print(f"{name}: {len(part)} подій")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--period", type=int, default=DEFAULT_PERIOD)
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    datasets = PROJECT_ROOT / "data" / "datasets" / args.pair
    in_dir = args.in_dir or datasets / "class210x210x4c"
    out_dir = args.out or datasets / "class210ema4c"

    report = build_pair(in_dir, out_dir, args.period)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"ЕМА {args.period} подій ≈ {args.period * 210 / 3600:.2f} год, "
          f"записано в {out_dir}")


if __name__ == "__main__":
    main()
