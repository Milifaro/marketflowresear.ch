"""Побудова датасету клас210х14х2 з готового клас210х14х4.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х2

Батьківські файли train/val/test уже розбиті — розбиття не змінюється,
кожен файл перераховується окремо, події не переставляються.

Запуск:
    python3 rules/scripts/build_class210x14x2.py --pair BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x14x2
import class210x14x4
from data_source import PROJECT_ROOT

PARTS = ("train", "val", "test")


def build_pair(in_dir: Path, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    report = {"source": str(in_dir), "parts": {}}
    for name in PARTS:
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        dataset, part_report = class210x14x2.build(class210x14x4.load(path))
        class210x14x2.save(dataset, out_dir / f"{name}.npz")
        report["parts"][name] = asdict(part_report)
        print(f"{name}: {len(dataset)} подій, "
              f"NaN-блоків balance/d_balance: "
              f"{part_report.nan_balance}/{part_report.nan_d_balance}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    datasets = PROJECT_ROOT / "data" / "datasets" / args.pair
    in_dir = args.in_dir or datasets / "class210x14x4"
    out_dir = args.out or datasets / "class210x14x2"

    report = build_pair(in_dir, out_dir)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"записано в {out_dir}")


if __name__ == "__main__":
    main()
