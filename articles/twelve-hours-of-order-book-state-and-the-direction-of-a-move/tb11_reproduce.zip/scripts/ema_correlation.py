"""Кореляція ЕМА ціни з ЕМА фіч клас210х210х3.

Правила: rules/01-data-and-db.md → Базові скрипти

Ряд `class_series.collect()`: train + val + test разом, відсортовані за
timestamp, одна подія — 210 с. ЕМА рахується тією самою формулою, що й на
дашборді: alpha = 2 / (період + 1), старт із першого значення ряду.

На кожну фічу рахується два зрізи, у кожному — Пірсон і Спірмен
(`scripts/correlation.py`):

- `levels` — кореляція самих ЕМА. Обидва ряди трендові й сильно
  автокорельовані, тому це число говорить більше про спільний тренд, ніж
  про звʼязок;
- `changes` — кореляція приростів ЕМА (різниць сусідніх значень). Тренд
  прибрано, лишається спільний рух.

Вхід : data/datasets/<PAIR>/class210x210x3/{train,val,test}.npz
Вихід: data/datasets/<PAIR>/class210x210x3/ema_correlation_<період>.json

Запуск:
    python3 scripts/ema_correlation.py --pair BTC_USDT --period 200
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

sys.path.insert(0, str(Path(__file__).resolve().parent))

from class_series import collect  # noqa: E402
from class210ema4 import ema  # noqa: E402  (одна ЕМА на весь проєкт)
from class210x210x3 import FEATURES  # noqa: E402
from correlation import both  # noqa: E402


def correlate(in_dir: Path, period: int, pair: str = "BTC_USDT") -> dict:
    """ЕМА ціни проти ЕМА кожної фічі: на рівнях і на приростах."""
    row = collect(in_dir)
    price = ema(row["price_open"], period)
    result = {
        "pair": pair,
        "class": "клас210х210х3",
        "period": period,
        "events": int(len(row["timestamp"])),
        "event_seconds": 210,
        "span_hours": round(period * 210 / 3600, 2),
        "source": str(in_dir),
        "features": {},
    }
    for index, name in enumerate(FEATURES):
        line = ema(row["x"][:, index], period)
        result["features"][name] = {
            "levels": both(price, line),
            "changes": both(np.diff(price), np.diff(line)),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--period", type=int, default=200)
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    in_dir = (args.in_dir or PROJECT_ROOT / "data" / "datasets" / args.pair
              / "class210x210x3")
    out = args.out or in_dir / f"ema_correlation_{args.period}.json"

    result = correlate(in_dir, args.period, args.pair)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                   encoding="utf-8")

    print(f"{result['pair']} · ЕМА {result['period']} "
          f"({result['span_hours']} год) · {result['events']} подій")
    print(f"{'фіча':<12} {'рівні: Пірсон':>14} {'Спірмен':>9} "
          f"{'прирости: Пірсон':>18} {'Спірмен':>9}")
    for name, values in result["features"].items():
        print(f"{name:<12} {values['levels']['pearson']:>14.4f} "
              f"{values['levels']['spearman']:>9.4f} "
              f"{values['changes']['pearson']:>18.4f} "
              f"{values['changes']['spearman']:>9.4f}")
    print(f"записано в {out}")


if __name__ == "__main__":
    main()
