"""Кореляції: Пірсона й Спірмена, без сторонніх бібліотек.

- **Пірсона** — лінійний звʼязок самих значень.
- **Спірмена** — та сама формула на рангах: ловить будь-який монотонний
  звʼязок і не боїться викидів. Ранги середні на однакових значеннях,
  тому підходить і для рядів із великою кількістю повторів (напрямок
  руху ±1).

Пари, де хоч одне значення не визначене, у розрахунок не входять.
"""

from __future__ import annotations

import numpy as np


def ranks(values: np.ndarray) -> np.ndarray:
    """Ранги зі середнім на однакових значеннях (1, 2.5, 2.5, 4)."""
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    result = np.empty(len(values), dtype=float)
    start = 0
    for index in range(1, len(values) + 1):
        if index == len(values) or sorted_values[index] != sorted_values[start]:
            result[order[start:index]] = (start + index + 1) / 2
            start = index
    return result


def _pairs(first: np.ndarray, second: np.ndarray
           ) -> tuple[np.ndarray, np.ndarray]:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    good = np.isfinite(first) & np.isfinite(second)
    return first[good], second[good]


def pearson(first: np.ndarray, second: np.ndarray) -> float:
    """Кореляція Пірсона по парах, де обидва значення визначені."""
    a, b = _pairs(first, second)
    if len(a) < 2 or a.std() == 0 or b.std() == 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def spearman(first: np.ndarray, second: np.ndarray) -> float:
    """Кореляція Спірмена: Пірсон на середніх рангах."""
    a, b = _pairs(first, second)
    if len(a) < 2:
        return float("nan")
    return pearson(ranks(a), ranks(b))


def both(first: np.ndarray, second: np.ndarray, digits: int = 4) -> dict:
    """Обидві кореляції одним словником."""
    return {"pearson": round(pearson(first, second), digits),
            "spearman": round(spearman(first, second), digits)}
