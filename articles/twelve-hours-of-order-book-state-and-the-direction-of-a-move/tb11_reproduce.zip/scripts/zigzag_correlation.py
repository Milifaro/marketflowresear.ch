"""Кореляція фіч ЕМА-класу з рухами зігзага 2.3% і 0.8%.

Правила: rules/01-data-and-db.md → Класи (події) → клас210ема4
         rules/02-markup.md — зігзаг

Ряд подій ЕМА-класу (`клас210ема4` або `клас210ема4ц`; train + val +
test разом, за часом) → зігзаг по
`price_open`:

- **зігзаг 2.3** — півоти за порогом 2.3%, рух між сусідніми півотами;
- **зігзаг 0.8** — те саме окремим прогоном з порогом 0.8%: самостійний
  зігзаг по тому самому ряду, не вкладений у рухи 2.3.

Кожній події ставиться дві величини на кожен зігзаг:

- **напрямок** руху, у якому вона стоїть: `+1` вгору, `-1` вниз;
- **нормований зігзаг** — де ціна події стоїть у своїй нозі. Нормування
  йде **по кожній нозі окремо** одним із трьох скейлерів
  (`rules/scripts/scalers.py`): `мінмакс` (`-1` у нижньому півоті, `+1`
  у верхньому), `робаст` (медіана й IQR ноги), `квантиль` (місце ціни
  в емпіричній CDF ноги).

**Фіча обробляється тим самим скейлером і по тих самих ногах, що й ціль.**
Інакше порівнюються різні речі: ціль — місце в нозі, фіча — сирий рівень.
Ряди напрямку скейлера не мають: там ціль категорійна (`+1` / `-1`),
і фіча йде як є.

Події поза зігзагом (до першого півота й після останнього) у розрахунок
не входять.

Далі кожна з фіч ЕМА корелюється з ціллю — Пірсоном і Спірменом
(`scripts/correlation.py`). Пірсон на ряду ±1 — це точково-бісеріальна
кореляція, Спірмен — та сама формула на рангах.

Зігзаг будується **на ЕМА ціни того самого періоду**, що й фічі
(`--zigzag ema`, типово): спершу ЕМА ціни, потім по ній півоти, потім
нормалізація. `--zigzag price` лишає зігзаг на самій ціні події.

Вхід : data/datasets/<PAIR>/<клас>/{train,val,test}.npz
Вихід: data/datasets/<PAIR>/<клас>/zigzag_correlation.json

Запуск:
    python3 scripts/zigzag_correlation.py --pair BTC_USDT
    python3 scripts/zigzag_correlation.py --pair BTC_USDT --class class210ema4c
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210ema4  # noqa: E402
import scalers  # noqa: E402
from class210ema4 import ema  # noqa: E402
from correlation import both  # noqa: E402
from zigzag import (INNER_THRESHOLD, OUTER_THRESHOLD, moves,  # noqa: E402
                    zigzag)

PARTS = ("train", "val", "test")
THRESHOLDS = {"зігзаг 2.3": OUTER_THRESHOLD, "зігзаг 0.8": INNER_THRESHOLD}
# Скейлери нормованих рядів: ключ -> підпис на вкладці.
NORMALIZERS = dict(scalers.TITLES)


def merge(in_dir: Path) -> class210ema4.Class210ema4:
    """Усі вибірки одним рядом, відсортованим за часом."""
    x, timestamp, price_open, price_close = [], [], [], []
    period, features = None, None
    for name in PARTS:
        path = in_dir / f"{name}.npz"
        if not path.exists():
            raise SystemExit(f"немає файлу {path}")
        part = class210ema4.load(path)
        period, features = part.period, list(part.features)
        x.append(np.asarray(part.x, dtype=float))
        timestamp.append(np.asarray(part.timestamp, dtype=np.int64))
        price_open.append(np.asarray(part.price_open, dtype=float))
        price_close.append(np.asarray(part.price_close, dtype=float))
    timestamp = np.concatenate(timestamp)
    index = np.argsort(timestamp, kind="stable")
    # імена фіч беруться з самих даних: клас може бути й клас210ема4ц
    return class210ema4.Class210ema4(
        x=np.concatenate(x)[index], timestamp=timestamp[index],
        price_open=np.concatenate(price_open)[index],
        price_close=np.concatenate(price_close)[index], period=period,
        features=features)


def directions(prices: np.ndarray,
               threshold: float = OUTER_THRESHOLD) -> np.ndarray:
    """Напрямок руху для кожної події: +1 вгору, -1 вниз, NaN поза зігзагом.

    Кожен поріг — свій самостійний зігзаг по тому самому ряду цін.
    """
    prices = np.asarray(prices, dtype=float)
    out = np.full(len(prices), np.nan)
    for move in moves(zigzag(prices, threshold)):
        out[move.start:move.end] = 1.0 if move.direction == "up" else -1.0
    return out


def by_legs(values: np.ndarray, pivots: list, scaler) -> np.ndarray:
    """Скейлер по кожній нозі окремо; поза зігзагом — NaN.

    Нога — відрізок між сусідніми півотами, разом з обома кінцями.
    Параметри скейлера рахуються всередині ноги, тому ряд відповідає на
    питання «де значення стоїть у своїй нозі», а не «який його рівень».
    """
    values = np.asarray(values, dtype=float)
    out = np.full(len(values), np.nan)
    for move in moves(pivots):
        chunk = slice(move.start, move.end + 1)
        out[chunk] = scaler(values[chunk])[0]
    return out


def positions(prices: np.ndarray, threshold: float = OUTER_THRESHOLD,
              scaler: str = "minmax") -> np.ndarray:
    """Нормований зігзаг: ціна ноги, оброблена скейлером цієї ноги.

    `minmax` дає класичне `-1` у нижньому півоті, `+1` у верхньому.
    """
    prices = np.asarray(prices, dtype=float)
    return by_legs(prices, zigzag(prices, threshold),
                   scalers.SCALERS[scaler])


def targets(prices: np.ndarray) -> dict:
    """Ряди, з якими рахуються кореляції.

    На кожен поріг — напрямок руху і три нормовані ряди, по одному на
    скейлер. Зігзаг 0.8 самостійний: свої півоти по всьому ряду за
    порогом 0.8%, незалежно від півотів 2.3 (`rules/02-markup.md`).

    Значення словника — `(ціль, як обробити фічу для цієї цілі)`. Для
    нормованих рядів фіча проходить той самий скейлер по тих самих ногах;
    для напрямку — лишається як є (`None`).
    """
    prices = np.asarray(prices, dtype=float)
    out = {}
    for label, threshold in THRESHOLDS.items():
        pivots = zigzag(prices, threshold)
        out[label] = (directions(prices, threshold), None)
        for key, title in NORMALIZERS.items():
            scaler = scalers.SCALERS[key]
            out[f"{label} нормований · {title}"] = (
                by_legs(prices, pivots, scaler),
                lambda values, pivots=pivots, scaler=scaler:
                    by_legs(values, pivots, scaler))
    return out


def scaler_of(name: str) -> str | None:
    """Підпис скейлера з імені ряду: «... нормований · робаст» -> «робаст»."""
    return name.split(" · ")[1] if " · " in name else None


def zigzag_series(row, zigzag_on: str = "ema") -> np.ndarray:
    """Ряд, на якому будується зігзаг: ЕМА ціни того самого періоду або ціна."""
    if zigzag_on == "price":
        return np.asarray(row.price_open, dtype=float)
    if zigzag_on != "ema":
        raise SystemExit("--zigzag приймає ema або price")
    return ema(row.price_open, row.period)


def correlate(in_dir: Path, pair: str = "BTC_USDT",
              zigzag_on: str = "ema") -> dict:
    """Фічі ЕМА проти рухів зігзага: напрямок і нормована нога."""
    row = merge(in_dir)
    legs = targets(zigzag_series(row, zigzag_on))
    result = {
        "pair": pair,
        "class": in_dir.name,
        "period": int(row.period),
        "events": len(row),
        "event_seconds": 210,
        "zigzag_on": zigzag_on,
        "thresholds": dict(THRESHOLDS),
        "scalers": [{"id": key, "name": title} for key, title
                    in NORMALIZERS.items()],
        "source": str(in_dir),
        "zigzags": {},
    }
    for name, (target, scale) in legs.items():
        good = np.isfinite(target)
        result["zigzags"][name] = {
            "events": int(good.sum()),
            "up": int((target[good] > 0).sum()),
            "down": int((target[good] < 0).sum()),
            # рівно нуль: центр ноги в робасті, середина в квантилі
            "middle": int((target[good] == 0).sum()),
            "normalized": scale is not None,
            "scaler": scaler_of(name),
            "threshold": name.split(" нормований")[0],
            "features": {
                feature: both(row.x[:, index] if scale is None
                              else scale(row.x[:, index]), target)
                for index, feature in enumerate(row.features)},
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--class", dest="class_name", default="class210ema4",
                        help="тека класу в data/datasets/<PAIR>/")
    parser.add_argument("--zigzag", dest="zigzag_on", default="ema",
                        choices=("ema", "price"),
                        help="ряд для зігзага: ЕМА ціни того самого періоду "
                             "чи сама ціна події")
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    in_dir = (args.in_dir or PROJECT_ROOT / "data" / "datasets" / args.pair
              / args.class_name)
    out = args.out or in_dir / "zigzag_correlation.json"

    result = correlate(in_dir, args.pair, args.zigzag_on)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                   encoding="utf-8")

    print(f"{result['pair']} · {result['class']}, ЕМА {result['period']} · "
          f"{result['events']} подій · зігзаг на "
          f"{'ЕМА ціни' if result['zigzag_on'] == 'ema' else 'ціні події'}")
    for name, part in result["zigzags"].items():
        print(f"\n{name}: {part['events']} подій у рухах "
              f"({'вище середини' if part['normalized'] else 'вгору'} "
              f"{part['up']}, "
              f"{'нижче' if part['normalized'] else 'вниз'} {part['down']})")
        print(f"{'фіча':<18} {'Пірсон':>8} {'Спірмен':>9}")
        for feature, values in part["features"].items():
            print(f"{feature:<18} {values['pearson']:>8.4f} "
                  f"{values['spearman']:>9.4f}")
    print(f"\nзаписано в {out}")


if __name__ == "__main__":
    main()
