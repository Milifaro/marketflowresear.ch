"""Підбір цілі: яка мітка найкраще звʼязана з фічами клас210х4бема10х10х130.

Правила: rules/01-data-and-db.md → клас210х4бема10х10х130
         rules/02-markup.md → Нормований зігзаг

Кандидати в цілі — нормований зігзаг на ЕМА ціни, окремо для порогів
**2.3%** і **0.8%**, на кожному з періодів 10 … 130 кроком 10 (по 13 на
поріг). Фічі — ті самі 4 × 13 значень класу.

Рахується кореляція **кожної фічі з кожним кандидатом** (Пірсон і
Спірмен), і на кожен поріг обирається мітка, у якої звʼязок найбільший.

Підбір іде **тільки на train** — вибір цілі це агрегат по датасету, а
такі рахуються на train і застосовуються до val/test
(`rules/01-data-and-db.md` → Порядок дій і захист від витоку).

Вхід : data/datasets/<PAIR>/class210x4bema10x10x130/{train,val,test}*.npz
Вихід: data/datasets/<PAIR>/class210x4bema10x10x130/target_pick.json

Запуск:
    python3 scripts/target_pick.py --pair BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x4bema10x10x130 as klass  # noqa: E402
import zigzag_targets  # noqa: E402
from correlation import pearson, ranks  # noqa: E402


def measure(in_dir: Path, part: str = "train") -> dict:
    """Кореляції всіх фіч з усіма кандидатами в цілі."""
    dataset = klass.load(in_dir / f"{part}.npz")
    targets = zigzag_targets.load(in_dir / f"{part}_targets.npz")
    if not np.array_equal(dataset.timestamp, targets.timestamp):
        raise SystemExit("фічі й цілі зібрані на різних подіях")

    rows = [(f"{name} ема{period}", dataset.x[:, i, j])
            for i, period in enumerate(dataset.periods)
            for j, name in enumerate(dataset.features)]
    row_ranks = {label: ranks(values) for label, values in rows}

    result = {
        "part": part,
        "events": len(dataset),
        "features": [label for label, _ in rows],
        "feature_periods": dataset.periods,
        "target_periods": targets.periods,
        "thresholds": targets.names,
        "source": str(in_dir),
        "targets": {},
    }
    for name in targets.names:
        for period in targets.periods:
            label = f"зігзаг {name} нормований, ема{period}"
            values = targets.column(period, name)
            good = np.isfinite(values)
            scores = {}
            target_ranks = ranks(np.where(good, values, np.nan))
            for feature, series in rows:
                scores[feature] = {
                    "pearson": round(pearson(series, values), 4),
                    "spearman": round(pearson(row_ranks[feature],
                                              target_ranks), 4),
                }
            # фіча-константа дає невизначену кореляцію — такі пари просто
            # не рахуються, а не псують підсумок
            strength = {key: abs(item["pearson"]) for key, item in scores.items()
                        if np.isfinite(item["pearson"])}
            best = max(strength, key=strength.get) if strength else None
            result["targets"][label] = {
                "threshold": name,
                "period": period,
                "events": int(good.sum()),
                "outside": int((~good).sum()),
                "undefined": len(scores) - len(strength),
                "best_feature": best,
                "best": scores[best] if best else None,
                "max_abs": round(strength[best], 4) if best else 0.0,
                "mean_abs": (round(float(np.mean(list(strength.values()))), 4)
                             if strength else 0.0),
                "features": scores,
            }
    return result


def choose(result: dict) -> dict:
    """Найкраща мітка на кожен поріг: де звʼязок з фічами найбільший."""
    picked = {}
    for name in result["thresholds"]:
        rows = {label: item for label, item in result["targets"].items()
                if item["threshold"] == name}
        by_max = max(rows, key=lambda label: rows[label]["max_abs"])
        by_mean = max(rows, key=lambda label: rows[label]["mean_abs"])
        picked[name] = {
            "target": by_max,
            "period": rows[by_max]["period"],
            "max_abs": rows[by_max]["max_abs"],
            "mean_abs": rows[by_max]["mean_abs"],
            "best_feature": rows[by_max]["best_feature"],
            "best": rows[by_max]["best"],
            "events": rows[by_max]["events"],
            "by_mean_abs": {"target": by_mean,
                            "period": rows[by_mean]["period"],
                            "mean_abs": rows[by_mean]["mean_abs"]},
        }
    return picked


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--part", default="train", choices=("train", "val",
                                                            "test"))
    parser.add_argument("--in", dest="in_dir", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    in_dir = (args.in_dir or PROJECT_ROOT / "data" / "datasets" / args.pair
              / "class210x4bema10x10x130")
    out = args.out or in_dir / "target_pick.json"

    result = measure(in_dir, args.part)
    result["picked"] = choose(result)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")

    print(f"{args.pair} · {result['part']} · {result['events']} подій · "
          f"{len(result['features'])} фіч × {len(result['targets'])} кандидатів")
    for name in result["thresholds"]:
        rows = [(item["period"], item["max_abs"], item["mean_abs"])
                for item in result["targets"].values()
                if item["threshold"] == name]
        print(f"\nзігзаг {name} нормований — |r| по періодах ЕМА цілі:")
        print("  період " + " ".join(f"{period:>6}" for period, _, _ in rows))
        print("  макс   " + " ".join(f"{value:>6.3f}" for _, value, _ in rows))
        print("  серед. " + " ".join(f"{value:>6.3f}" for _, _, value in rows))
        pick = result["picked"][name]
        print(f"  обрано: {pick['target']} · макс |r| {pick['max_abs']} "
              f"({pick['best_feature']}, Пірсон {pick['best']['pearson']}, "
              f"Спірмен {pick['best']['spearman']}) · подій {pick['events']}")
    print(f"\nзаписано в {out}")


if __name__ == "__main__":
    main()
