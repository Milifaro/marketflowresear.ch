"""Мережа з памʼяттю на розворот: чи вистачає їй самого класу.

Дослідження: research/25-leg-lstm/
Правила: rules/01-data-and-db.md → Скейлери
         rules/03-models.md → Навчання моделей

Дослідження 23 показало дві речі. Перша: дерева на 62 агрегатах пачки
дають ×3.8 до бази, а пʼять чисел про положення ціни — ×121. Друга:
одного вікна на 400 подій мало, бо півот це екстремум **усієї ноги**, і
чотири вікна піднімають точність із 25 % до 63 %.

Обидва висновки зроблені на **агрегатах**: перш ніж дійти до моделі,
десять подій згорталися в медіани, нахили й позиції піка, а вікна
задавалися руками. Мережа з памʼяттю нічого згортати не просить: їй
подається **послідовність подій як є**, і довгий контекст вона має
будувати сама.

Питання етапу просте: **чи вистачає їй самого класу**.

## Довжина вікна

Вікно береться на **кожній** події: жодного відбору за суцільністю чи
`NaN` немає — інакше з заміру зникали б саме ті місця, де даних бракує, а
в роботі мережу питатимуть і там. Довше вікно все одно коштує прикладів
на початку ряду:

| `LENGTH` | Вікон | Розворотів | train | val |
| -------- | ----- | ---------- | ----- | --- |
| 30 | 156 862 | 346 | 139 308 | 17 554 |
| 60 | 101 952 | 223 | 90 953 | 10 999 |
| 90 | 69 861 | 158 | 62 372 | 7 489 |
| 120 | 48 584 | 115 | 43 446 | 5 138 |

Узято `LENGTH = 60` — три з половиною години: далі розворотів лишається
менше двох сотень на все навчання.

Це саме по собі важливо: у дослідженні 23 контекст працював на вікнах до
**1600 подій**, а мережа бачить 60. Усе, що довше за її вікно, вона з
класу дістати не може — і саме це перевіряє порівняння нижче.

## Приклад

Вікно з `LENGTH` подій підряд, що закінчується на події `e`. Кожна подія
— `9 × 7 = 63` числа класу `клас210х10-1х7д/д`. Мітка та сама, що в
драбині дослідження 23:

    y[e] = 1, якщо півот стоїть на події e − LAG

## Три набори каналів

| Набір | Канали | Що перевіряє |
| ----- | ------ | ------------ |
| `клас` | 63 | чи дістане мережа все потрібне з самого класу |
| `ціна` | 20 | скільки дає сама лише ціна: пʼять чисел контексту на чотирьох вікнах |
| `клас+ціна` | 83 | чи додає клас щось поверх ціни |

`клас` тут не «сліпий до ціни»: серед семи фіч є `d_price_avg` — приріст
ціни за подію. Проінтегрувавши його по вікну, мережа в принципі може
відновити хід ціни сама. Набір `клас` перевіряє саме це.

## Скейлер

Кожен канал переводиться в **квантиль свого ряду** (`x → 2u − 1`,
[`rules/scripts/scalers.py`](../../rules/scripts/scalers.py)). Скейлер
рахується на подіях `train` **своєї монети** й застосовується до всього
ряду — інакше val підглядав би у власний розподіл.

## Мережа

`LSTM` на `HIDDEN` станів, один шар, далі шар нормування, `dropout` і
лінійна голова в один логіт. Розворотів мало, тому в `BCEWithLogits`
стоїть `pos_weight`, а негативи проріджуються до `NEG_RATE` на кожен
позитив.

Розбиття за датою: train до `CUT`, val від `CUT` до `END`. Вікно цілком
лежить по один бік межі.

## Поріг і вибір епохи

Мережа запамʼятовує навчання: train `AUC` дорівнює 0.99 при val 0.77.
Тому поріг **не можна** брати з її оцінок на власному train — він стане
вищим за все, що вона видасть на val, і сигналів не буде взагалі.

Порядок такий самий, як у дослідженні 24:

1. шість прогонів з **відкладеною монетою** дають чесні оцінки train —
   кожне вікно оцінене мережею, що його монети не бачила;
2. окремий прогін на всіх монетах дає оцінки val;
3. епоха обирається за **чесним** `AP`, а не за val: інакше val бере
   участь у виборі й видача на ньому вже не є видачею поза часом;
4. поріг стоїть на чесних оцінках **тієї самої** епохи, на повноті
   `RECALL`, і йде на val як є.

Оцінки й мітки беруться з однієї епохи — тієї, яку обрано.

## Плашка монети

Кожна монета віддає свій **ряд val**: ема ціни, зігзаг і **сирий сигнал
мережі на кожній події ряду**. Мітки — влучила, у рівні півота, хибний,
проґавила — рахуються з нього **порогом**, і поріг у плашці рухають
рукою; за замовчуванням він стоїть на чесних оцінках train на повноті
`SERIES_RECALL`. Сигнал іде на кожному наборі каналів, тому набори можна
порівняти оком.

Перші `LENGTH` подій ряду val закриті вікнами **краю** — тими, що лежать
через межу навчання. У числа вони не йдуть (`kind = -1`), але сигнал на
них є: інакше плашка починалась би з дірки.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/lstm_pivot.json     — числа навчання
       results/lstm_<PAIR>.json    — ряд val однієї монети

Запуск:
    python3 research/25-leg-lstm/scripts/lstm_pivot.py
    python3 research/25-leg-lstm/scripts/lstm_pivot.py --sets клас --epochs 4
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
SIGNAL_SCRIPTS = PROJECT_ROOT / "research" / "23-reversal-signal" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(SIGNAL_SCRIPTS))

import scalers  # noqa: E402
import signal_data as legs  # noqa: E402
import leg_context  # noqa: E402
import pivot_delay  # noqa: E402
from signal_data import CUT, END, PAIRS, stamp  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LENGTH = 60                # подій у вікні — три з половиною години
LAG = 3                    # мітка: півот стояв LAG подій тому
LOOKS = pivot_delay.LOOKS  # вікна контексту для каналів ціни
HIDDEN = 96
LAYERS = 1
DROPOUT = 0.1
BATCH = 256
EPOCHS = 10
RATE = 1e-3
NEG_RATE = 200             # негативів на один позитив
POS_WEIGHT = 20.0
RECALL = (0.2, 0.3)
SERIES_RECALL = 0.3        # на якій повноті стоїть поріг у плашках монет
SEED = legs.SEED
SETS = ("клас", "ціна", "клас+ціна")
MARKS = ("hit", "near", "false", "miss", "blind")


def device_of():
    import torch

    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


PARTS = {"клас": ("клас",), "ціна": ("ціна",),
         "клас+ціна": ("клас", "ціна")}


def width_of(channels: dict, name: str) -> int:
    """Скільки каналів у наборі."""
    return sum(channels[one].shape[1] for one in PARTS[name])


def coin_channels(coin: dict) -> dict:
    """Канали однієї монети: клас подією й контекст ціни на чотирьох вікнах.

    Скейлер квантиля рахується на подіях train цієї монети. Складені
    набори (`клас+ціна`) копією не зберігаються — вони збираються з
    частин у момент подачі пачки, інакше ряд на 70 тисяч подій × шість
    монет не влазить у памʼять.
    """
    x = coin["x"].reshape(len(coin["t"]), -1).astype(np.float64)
    price = []
    for look in LOOKS:
        found = (dict(coin["context"]) if look == legs.LOOK
                 else dict(legs.context_of(coin["ema"], coin["pivots"], look)))
        found["move"] = np.maximum(found["run"], found["draw"])
        price.append(np.column_stack([found[name]
                                      for name in leg_context.CONTEXT]))
    price = np.hstack(price)
    train = coin["t"] < stamp(CUT)
    out = {}
    for name, values in (("клас", x), ("ціна", price)):
        scaled = np.empty_like(values, dtype=np.float32)
        for index in range(values.shape[1]):
            column = values[:, index]
            fit = scalers.quantile_fit(column[train])
            scaled[:, index] = scalers.quantile_apply(column, fit)
        out[name] = np.nan_to_num(scaled, nan=0.0, posinf=0.0, neginf=0.0)
    return out       # «клас+ціна» збирається пачкою, не лежить копією


def windows_of(coin: dict, length: int = LENGTH, lag: int = LAG) -> dict:
    """Кінці вікон, мітки й частина ряду.

    Вікно закінчується на події `e`, тягнеться на `length` подій назад і
    цілком лежить по один бік межі train | val. Інших умов немає: вікно
    береться на кожній події, а `NaN` у каналах уже зняті нулями в
    `coin_channels`.
    """
    t = coin["t"]
    edge, right = stamp(CUT), stamp(END)
    ends = np.arange(length - 1, len(t))     # вікно на кожній події
    ends = ends[ends - lag >= 0]

    place = np.zeros(len(t), dtype=bool)
    for point in coin["pivots"]:
        if 0 <= point.index < len(place):
            place[point.index] = True
    first = t[ends - length + 1]
    last = t[ends]
    part = np.where(last < edge, "train",
                    np.where((first >= edge) & (last < right), "val", "поза"))
    return {"ends": ends, "y": place[ends - lag].astype(np.int8),
            "part": part}


def sample(y: np.ndarray, part: np.ndarray, rate: int = NEG_RATE,
           seed: int = SEED) -> np.ndarray:
    """Усі розвороти train і проріджені негативи; val і край — цілком.

    Край — це вікна, що лежать через межу train | val. У числа вони не
    йдуть: мережа вчилась на їхньому початку. Але саме вони закривають
    перші `LENGTH` подій ряду val, тому мережу питають і там — інакше
    плашка монети починалась би з дірки без сигналу.
    """
    rng = np.random.default_rng(seed)
    train = part == "train"
    hit = np.flatnonzero(train & (y == 1))
    rest = np.flatnonzero(train & (y == 0))
    keep = min(len(hit) * rate, len(rest))
    picked = rng.choice(rest, keep, replace=False) if keep else rest[:0]
    return np.sort(np.concatenate([hit, picked,
                                   np.flatnonzero(part == "val"),
                                   np.flatnonzero(part == "поза")]))


def collect(coins: list, length: int = LENGTH, lag: int = LAG,
            rate: int = NEG_RATE, seed: int = SEED, log=print) -> dict:
    """Канали, кінці вікон і мітки всіх монет."""
    body = []
    for number, coin in enumerate(coins):
        channels = coin_channels(coin)
        found = windows_of(coin, length, lag)
        picked = sample(found["y"], found["part"], rate, seed)
        ends = found["ends"][picked]
        spot = np.clip(ends - lag, 0, len(coin["ema"]) - 1)
        near = legs.pivot_gap(coin["ema"], coin["pivots"],
                              spot) <= legs.NEAR
        body.append({"pair": coin["pair"], "channels": channels,
                     "ends": ends, "y": found["y"][picked], "near": near,
                     "part": found["part"][picked], "coin": number})
        coin.pop("x", None)          # фічі більше не потрібні: є канали
        log(f"      {coin['pair']}: вікон {len(picked)}, розворотів "
            f"{int(found['y'][picked].sum())}, "
            f"train {int((found['part'][picked] == 'train').sum())}, "
            f"val {int((found['part'][picked] == 'val').sum())}, "
            f"край {int((found['part'][picked] == 'поза').sum())}")
    return {"coins": body, "length": length, "lag": lag}


def rows_of(state: dict, part: str, coins=None) -> np.ndarray:
    """(монета, місце) кожного вікна частини — у порядку подачі в мережу.

    `coins` — перелік номерів монет; `None` означає всі.
    """
    rows = []
    for one in state["coins"]:
        if coins is not None and one["coin"] not in coins:
            continue
        place = np.flatnonzero(one["part"] == part)
        rows.extend((one["coin"], index) for index in place)
    return np.array(rows, dtype=np.int64).reshape(-1, 2)


def labels_of(state: dict, part: str, coins=None) -> np.ndarray:
    """Мітки частини в тому самому порядку, що й `rows_of`."""
    return flags_of(state, part, "y", coins)


def flags_of(state: dict, part: str, key: str, coins=None) -> np.ndarray:
    """Колонка `key` частини в тому самому порядку, що й `rows_of`."""
    rows = rows_of(state, part, coins)
    return np.array([state["coins"][number][key][index]
                     for number, index in rows])


def batches(state: dict, name: str, part: str, batch: int = BATCH,
            shuffle: bool = False, seed: int = SEED, coins=None):
    """Пачки вікон одного набору каналів: (batch, length, канали)."""
    rows = rows_of(state, part, coins)
    if shuffle:
        np.random.default_rng(seed).shuffle(rows)
    length = state["length"]
    for start in range(0, len(rows), batch):
        block = rows[start:start + batch]
        x = np.empty((len(block), length,
                      width_of(state["coins"][0]["channels"], name)),
                     dtype=np.float32)
        y = np.empty(len(block), dtype=np.float32)
        for place, (number, index) in enumerate(block):
            coin = state["coins"][number]
            end = coin["ends"][index]
            low = end - length + 1
            at = 0
            for part in PARTS[name]:
                values = coin["channels"][part]
                x[place, :, at:at + values.shape[1]] = values[low:end + 1]
                at += values.shape[1]
            y[place] = coin["y"][index]
        yield x, y


def build(channels: int, hidden: int = HIDDEN, layers: int = LAYERS,
          dropout: float = DROPOUT, seed: int = SEED):
    import torch
    from torch import nn

    torch.manual_seed(seed)

    class Pivot(nn.Module):
        """LSTM по вікну подій -> один логіт на останній стан."""

        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(channels, hidden, num_layers=layers,
                                batch_first=True)
            self.norm = nn.LayerNorm(hidden)
            self.drop = nn.Dropout(dropout)
            self.head = nn.Linear(hidden, 1)

        def forward(self, x):
            out, _ = self.lstm(x)
            return self.head(self.drop(self.norm(out[:, -1]))).squeeze(-1)

    return Pivot()


def scores_of(model, state: dict, name: str, part: str, device,
              batch: int = BATCH, coins=None) -> tuple:
    import torch

    model.eval()
    out, want = [], []
    with torch.no_grad():
        for x, y in batches(state, name, part, batch, coins=coins):
            found = model(torch.from_numpy(x).to(device))
            out.append(torch.sigmoid(found).float().cpu().numpy())
            want.append(y)
    if not out:
        return np.empty(0), np.empty(0)
    return np.concatenate(out), np.concatenate(want)


def blind_pivots(coin: dict, asked: set, lag: int) -> list:
    """Півоти val, відповідь про які ще попереду.

    Питання ставиться на кожній події, але про півот `p` його ставлять
    на події `p + LAG` — і для останніх подій ряду цієї події ще немає.
    Без цієї мітки такий півот мовчки зникав би з плашки.
    """
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return []
    low, high = int(inside[0]), int(inside[-1])
    return [int(min(point.index + lag, high)) for point in coin["pivots"]
            if low <= point.index <= high and point.index not in asked]


def fired_by_coin(state: dict, coins: list, train: tuple, val: tuple,
                  spare: np.ndarray | None = None,
                  want: float = SERIES_RECALL) -> tuple:
    """Сирий сигнал мережі на val — по кожній монеті окремо.

    `train` — чесні оцінки train (відкладена монета), з них поріг.
    `spare` — оцінки вікон краю: вони закривають перші `LENGTH` подій
    ряду val, де вікно ще заходить за межу навчання.

    Повертає поріг і, на кожну монету, сигнал **на кожній події** її ряду
    val разом з тим, чим ця подія є:

    | `kind` | Подія |
    | ------ | ----- |
    | `-1` | вікно є, у рахунок не йде: воно лежить через межу навчання |
    | `0` | питання поставлене, півота на події `e − LAG` немає |
    | `1` | півот там є |
    | `2` | півота там немає, але ціна тієї події в його рівні |

    Мітки — влучив, у рівні, хибний, проґавив — з цих двох рядів
    рахуються порогом, і поріг у плашці рухають рукою. Окремо йдуть лише
    півоти, відповідь про які ще попереду (`blind`): від порога вони не
    залежать.
    """
    score, y = train
    other, label = val
    edge = float(np.quantile(score[y == 1], 1.0 - want))
    close = flags_of(state, "val", "near") & (label == 0)
    lag = state["lag"]
    found = {one["pair"]: {} for one in state["coins"]}   # подія -> сигнал
    asked = {one["pair"]: set() for one in state["coins"]}
    for place, (number, index) in enumerate(rows_of(state, "val")):
        one = state["coins"][number]
        end = int(one["ends"][index])
        found[one["pair"]][end] = (
            float(other[place]),
            legs.PIVOT if label[place] else
            legs.LEVEL if close[place] else legs.PLAIN)
        if label[place]:
            asked[one["pair"]].add(end - lag)
    if spare is not None:
        for place, (number, index) in enumerate(rows_of(state, "поза")):
            one = state["coins"][number]
            end = int(one["ends"][index])
            found[one["pair"]].setdefault(end, (float(spare[place]),
                                                legs.NO_COUNT))
    out, raw = {}, {}
    for one, coin in zip(state["coins"], coins):
        pair = one["pair"]
        out[pair] = {"blind": blind_pivots(coin, asked[pair], lag)}
        inside = np.flatnonzero(coin["part"] == "val")
        low = int(inside[0]) if len(inside) else 0
        high = int(inside[-1]) if len(inside) else -1
        ends = sorted(end for end in found[pair] if low <= end <= high)
        raw[pair] = {"ends": ends,
                     "value": [round(found[pair][end][0], 4) for end in ends],
                     "kind": [found[pair][end][1] for end in ends]}
    return ({"edge": legs.cell(edge), "want": legs.cell(want),
             "near": legs.cell(legs.NEAR), "by_coin": out}, raw)


def coin_series(coin: dict, rows: list) -> dict:
    """Ряд val однієї монети: ема, зігзаг і сигнал кожного набору каналів."""
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return {"pair": coin["pair"], "events": 0, "ready": False}
    low, high = int(inside[0]), int(inside[-1])
    index = np.arange(low, high + 1)
    place = {value: number for number, value in enumerate(index)}
    body = {"pair": coin["pair"], "ready": True, "events": int(len(index)),
            "from_utc": legs.leg_deciles.utc(coin["t"][low]),
            "to_utc": legs.leg_deciles.utc(coin["t"][high]),
            "t": coin["t"][index].astype(int).tolist(),
            "price": [round(float(one), 6) for one in coin["ema"][index]],
            "period": legs.PERIOD, "threshold": legs.THRESHOLD,
            "event_seconds": legs.EVENT_LENGTH,
            "pivots": [{"t": int(coin["t"][point.index]),
                        "ema": round(float(coin["ema"][point.index]), 6),
                        "kind": point.kind}
                       for point in coin["pivots"]
                       if low <= point.index <= high],
            "sets": {}}
    for row in rows:
        raw = (row.get("raw") or {}).get(coin["pair"])
        if not raw:
            continue
        found = row.get("marks", {}).get("by_coin", {}).get(coin["pair"], {})
        body["sets"][row["set"]] = legs.step_lines(
            raw, found.get("blind", ()), place, len(index),
            row["marks"].get("edge"), row["marks"].get("near"))
    return body


def train_once(state: dict, name: str, epochs: int, look: dict,
               fit=None, rate: float = RATE, weight: float = POS_WEIGHT,
               seed: int = SEED, log=print, tag: str = "") -> dict:
    """Навчання на train монет `fit` і оцінки після кожної епохи.

    `fit` — номери монет, на яких вчимось (`None` — усі). `look` — що
    оцінювати: `{імʼя: (частина, монети)}`. Повертає оцінки щоепохи, а не
    останню: епоху обирають потім, і числа мають бути з тієї самої.
    """
    import torch
    from torch import nn

    device = device_of()
    channels = width_of(state["coins"][0]["channels"], name)
    model = build(channels, seed=seed).to(device)
    loss = nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor([weight], device=device))
    tune = torch.optim.Adam(model.parameters(), lr=rate)
    history, started = [], time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        total, seen = 0.0, 0
        for x, y in batches(state, name, "train", shuffle=True,
                            seed=seed + epoch, coins=fit):
            found = model(torch.from_numpy(x).to(device))
            step = loss(found, torch.from_numpy(y).to(device))
            tune.zero_grad()
            step.backward()
            tune.step()
            total += float(step.detach()) * len(y)
            seen += len(y)
        row = {"epoch": epoch, "loss": legs.cell(total / max(seen, 1))}
        for key, (part, coins) in look.items():
            row[key] = scores_of(model, state, name, part, device, coins=coins)
        history.append(row)
    log(f"      {tag or name}: {epochs} епох за "
        f"{round(time.time() - started, 1)} с")
    return {"history": history, "device": str(device),
            "parameters": int(sum(one.numel() for one in model.parameters())),
            "channels": channels, "seconds": round(time.time() - started, 1)}


def honest_scores(state: dict, name: str, epochs: int, seed: int = SEED,
                  log=print) -> list:
    """Оцінка кожного вікна train моделлю, що його монети не бачила.

    Без цього поріг довелося б брати з оцінок моделі на її ж навчанні —
    а мережа їх запамʼятовує (train AUC 0.99), і поріг виходить вищим за
    все, що вона колись видасть на val.
    """
    numbers = [one["coin"] for one in state["coins"]]
    rows = rows_of(state, "train")
    out = [np.full(len(rows), np.nan) for _ in range(epochs)]
    for number in numbers:
        keep = [one for one in numbers if one != number]
        got = train_once(state, name, epochs,
                         look={"hold": ("train", [number])}, fit=keep,
                         seed=seed, log=log,
                         tag=f"{name} без {state['coins'][number]['pair']}")
        place = np.flatnonzero(rows[:, 0] == number)
        for epoch, row in enumerate(got["history"]):
            out[epoch][place] = row["hold"][0]
    return out


def carry(train: tuple, val: tuple, days: float, recall=RECALL,
          near: np.ndarray | None = None) -> list:
    """Поріг із чесних оцінок train, застосований до val як є.

    `near` — вікна, що показують на подію в ціновому околі півота:
    строга точність їх не зараховує, точність з допуском зараховує.
    """
    score, y = train
    other, want = val
    if near is None:
        near = np.zeros(len(want), dtype=bool)
    close = near & (want == 0)
    out = []
    for level in recall:
        edge = float(np.quantile(score[y == 1], 1.0 - level))
        shot = other >= edge
        taken = int((shot & (want == 1)).sum())
        spare = int((shot & close).sum())
        false = int((shot & (want == 0) & ~close).sum())
        seen = int(((score >= edge) & (y == 1)).sum())
        wrong = int(((score >= edge) & (y == 0)).sum())
        out.append({
            "want": legs.cell(level), "edge": legs.cell(edge),
            "train": legs.cell(seen / max(seen + wrong, 1)),
            "val": legs.cell(taken / max(taken + spare + false, 1)),
            "near_val": legs.cell((taken + spare)
                                  / max(taken + spare + false, 1)),
            "recall": legs.cell(taken / max(int((want == 1).sum()), 1)),
            "taken": taken, "spare": spare, "false": false,
            "per_day": legs.cell((taken + spare + false)
                                 / max(days, legs.EPS))})
    return out


def run_set(state: dict, coins: list, name: str, epochs: int = EPOCHS,
            rate: float = RATE, weight: float = POS_WEIGHT,
            seed: int = SEED, log=print) -> dict:
    """Навчання одного набору каналів: чесні оцінки, епоха, видача на val.

    Порядок такий:

    1. шість прогонів з відкладеною монетою -> чесні оцінки train щоепохи;
    2. прогін на всіх монетах -> оцінки val щоепохи;
    3. епоха обирається за **чесним** `AP`, а не за val;
    4. поріг стоїть на чесних оцінках тієї самої епохи й іде на val як є.
    """
    honest_y = labels_of(state, "train").astype(int)
    honest = honest_scores(state, name, epochs, seed, log)
    full = train_once(state, name, epochs, seed=seed, rate=rate,
                      weight=weight, log=log, tag=f"{name} на всіх",
                      look={"train": ("train", None), "val": ("val", None),
                            "край": ("поза", None)})
    days = sum(int((one["part"] == "val").sum()) for one in state["coins"]) \
        * legs.EVENT_LENGTH / 86400
    near = flags_of(state, "val", "near")
    history = []
    for epoch, row in enumerate(full["history"]):
        fair = (honest[epoch], honest_y)
        body = {"epoch": row["epoch"], "loss": row["loss"],
                "honest": leg_context.measure(honest_y, honest[epoch]),
                "train": leg_context.measure(row["train"][1].astype(int),
                                             row["train"][0]),
                "val": leg_context.measure(row["val"][1].astype(int),
                                           row["val"][0]),
                "steps": carry(fair, row["val"], days, RECALL, near)}
        history.append(body)
        log(f"      {name} епоха {row['epoch']:>2}: втрата {body['loss']}, "
            f"чесний AUC {body['honest'].get('auc')}, val AUC "
            f"{body['val'].get('auc')}, val точність {body['steps'][-1]['val']}")
    best = max(history, key=lambda one: one["honest"].get("ap") or 0)
    place = best["epoch"] - 1
    spare = full["history"][place].get("край")
    marks, raw = fired_by_coin(state, coins, (honest[place], honest_y),
                               full["history"][place]["val"],
                               spare[0] if spare is not None else None)
    return {"set": name, "channels": full["channels"],
            "marks": marks, "raw": raw,
            "parameters": full["parameters"], "device": full["device"],
            "seconds": round(full["seconds"] * (len(state["coins"]) + 1), 1),
            "history": history, "best": best, "days": legs.cell(days)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sets", nargs="+", default=list(SETS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--length", type=int, default=LENGTH)
    parser.add_argument("--lag", type=int, default=LAG)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[вікна]")
    state = collect(coins, args.length, args.lag, seed=args.seed)
    print("[навчання]")
    rows = [run_set(state, coins, name, args.epochs, seed=args.seed)
            for name in args.sets]

    args.out.mkdir(parents=True, exist_ok=True)
    print("[плашки монет]")
    for coin in coins:
        body = coin_series(coin, rows)
        body.update({"script": "research/25-leg-lstm/scripts/lstm_pivot.py",
                     "cut_utc": f"{CUT} 00:00:00",
                     "end_utc": f"{END} 00:00:00",
                     "series_recall": SERIES_RECALL, "lag": args.lag,
                     "near": legs.NEAR, "marks": list(MARKS),
                     "length": args.length, "set_list": list(args.sets)})
        (args.out / f"lstm_{coin['pair']}.json").write_text(
            json.dumps(body, ensure_ascii=False), encoding="utf-8")
        first = body.get("sets", {}).get(args.sets[0], {})
        print(f"      {coin['pair']}: подій {body['events']}, півотів "
              f"{len(body.get('pivots', []))}, набір {args.sets[0]} — "
              f"{first.get('counts', {})}")

    for row in rows:                 # сирий сигнал живе у плашках монет
        row.pop("raw", None)
    (args.out / "lstm_pivot.json").write_text(json.dumps({
        "script": "research/25-leg-lstm/scripts/lstm_pivot.py",
        "command": "python3 research/25-leg-lstm/scripts/lstm_pivot.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "sets": list(args.sets),
        "length": args.length, "lag": args.lag, "looks": list(LOOKS),
        "context_names": list(leg_context.CONTEXT), "hidden": HIDDEN,
        "layers": LAYERS, "dropout": DROPOUT, "batch": BATCH,
        "epochs": args.epochs, "rate": RATE, "neg_rate": NEG_RATE,
        "pos_weight": POS_WEIGHT, "recall_grid": list(RECALL),
        "series_recall": SERIES_RECALL, "near": legs.NEAR,
        "marks": list(MARKS),
        "scaler": "quantile", "seed": args.seed, "honest": "відкладена монета",
        "epoch_by": "чесний AP",
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/lstm_pivot.json")


if __name__ == "__main__":
    main()
