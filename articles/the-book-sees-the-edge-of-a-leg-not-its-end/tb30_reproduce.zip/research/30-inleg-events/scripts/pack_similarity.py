"""Пачки між собою: своя нога проти сусідньої.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/05-visualization.md

Гіпотеза: **пачки однієї ноги схожі між собою більше, ніж пачка цієї
ноги й пачка сусідньої**. Якщо так — межу ноги видно не по окремій
події, а по тому, що схожість пачок на ній рветься.

Ряд ноги ріжеться на пачки по `N` подій підряд, без перекриття. Пачка —
це сирі числа класу, як вони лежать: `N × 9 блоків × 7 фіч`. Пара пачок
міряється відстанню.

    через півот  дві пачки різних ніг, між ними `s` пачок і півот
    край ноги    дві пачки однієї ноги на тій самій відстані, і пара
                 так само впирається в півот — але не переходить його
    середина     будь-яка інша пара однієї ноги на тій самій відстані

Головне в замірі — **два контролі**, а не один.

1. **Однакова відстань у парі.** Пачки, що стоять поруч у ряді, схожі
   вже тому, що поруч, тому пари рівняються тільки на однаковій `s`.
2. **Однакове місце в нозі.** Пара через півот завжди стоїть на краях
   ноги, а краї в цьому класі мають свій рівень (етап 1). Тому головне
   порівняння — **через півот проти краю ноги**: та сама відстань, те
   саме місце, різниця лише в тому, чи лежить між пачками півот.

| крок | як |
| ---- | -- |
| **пачка** | `N` подій підряд, `N` з переліку; пачка не переходить через півот |
| **числа** | сирі — числа класу як є; ранги — кожне число переведене в ранг серед подій монети й зсунуте на −0.5 (хвости відношень похідних доходять до 1e12) |
| **відстань** | `cosine`, `euclidean`, `manhattan` — три метрики, як і для карт (rules/05-visualization.md) |
| **пари** | через півот, край ноги і середина — окремо на кожній відстані `s` |
| **міра** | AUC «пара через півот далі, ніж пара порівняння»; 0.5 — півот нічого не додає |
| **контроль** | мітку пар перемішують і щоразу беруть найбільший \\|z\\| перебору |

Оптимальна пачка — та, на якій AUC найбільша при сусідніх пачках
(`s` = 1): це найкоротша пара, де питання ще має сенс.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/pack_similarity_<PAIR>_<клас>.json
       results/pack_similarity_<PAIR>_<клас>.meta.json

Запуск:
    python3 research/30-inleg-events/scripts/pack_similarity.py
    python3 research/30-inleg-events/scripts/pack_similarity.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

PACKS = (3, 5, 8, 10, 15, 20, 30, 40)
DEFAULT_PACK = 10
SEPARATIONS = (1, 2, 3, 5, 8)      # скільки пачок між пачками пари
METRICS = ("cosine", "euclidean", "manhattan")
VARIANTS = ("raw", "rank")
SHUFFLES = 300
SEED = 17


def cut(legs: list, size: int) -> dict:
    """Ряд кожної ноги — на пачки по `size` подій, без перекриття."""
    start, leg_number, kind = [], [], []
    for number, leg in enumerate(legs):
        place = leg["first"]
        while place + size - 1 <= leg["last"]:
            start.append(place)
            leg_number.append(number)
            kind.append(leg["kind"])
            place += size
    return {"start": np.array(start, dtype=int),
            "leg": np.array(leg_number, dtype=int),
            "kind": np.array(kind)}


def vectors(values: np.ndarray, start: np.ndarray, size: int) -> np.ndarray:
    """Пачка одним рядком: `size` подій × 9 блоків × 7 фіч."""
    width = values.shape[1] * values.shape[2]
    if start.size == 0:
        return np.zeros((0, width * size))
    index = start[:, None] + np.arange(size)[None, :]
    return values[index].reshape(len(start), size * width)


def ranked_events(values: np.ndarray, inside: np.ndarray) -> np.ndarray:
    """Кожне число події — в ранг серед подій ніг монети, зсунутий на −0.5."""
    out = np.zeros(values.shape, dtype=float)
    for block in range(values.shape[1]):
        for feature in range(values.shape[2]):
            column = inleg.ranks(values[:, block, feature], inside) - 0.5
            out[:, block, feature] = np.nan_to_num(column, nan=0.0)
    return out


def distance(left: np.ndarray, right: np.ndarray, metric: str) -> np.ndarray:
    """Відстань між парами пачок, рядок до рядка."""
    left = np.nan_to_num(left, nan=0.0, posinf=0.0, neginf=0.0)
    right = np.nan_to_num(right, nan=0.0, posinf=0.0, neginf=0.0)
    if metric == "euclidean":
        return np.sqrt(((left - right) ** 2).sum(axis=1))
    if metric == "manhattan":
        return np.abs(left - right).sum(axis=1)
    if metric == "cosine":
        top = (left * right).sum(axis=1)
        bottom = (np.sqrt((left ** 2).sum(axis=1))
                  * np.sqrt((right ** 2).sum(axis=1)))
        return 1 - np.divide(top, bottom, out=np.zeros(len(left)),
                             where=bottom > 0)
    raise ValueError(f"невідома метрика: {metric}")


KINDS = ("across", "edge", "middle")


def pairs_of(packs: dict, step: int) -> dict:
    """Пари пачок на відстані `step`, розкладені на три види.

    `across` — пара переходить півот; `edge` — пара своєї ноги, яка так
    само впирається в півот (починається першою пачкою ноги або
    закінчується останньою), але його не переходить; `middle` — решта
    пар своєї ноги.
    """
    left, right, kind = [], [], []
    leg = packs["leg"]
    first = {number: int(np.flatnonzero(leg == number)[0])
             for number in np.unique(leg)}
    last = {number: int(np.flatnonzero(leg == number)[-1])
            for number in np.unique(leg)}
    for number in range(len(leg) - step):
        other = number + step
        if leg[other] == leg[number] + 1:
            left.append(number)
            right.append(other)
            kind.append("across")
        elif leg[other] == leg[number]:
            own = int(leg[number])
            edge = number == first[own] or other == last[own]
            left.append(number)
            right.append(other)
            kind.append("edge" if edge else "middle")
    return {"left": np.array(left, dtype=int),
            "right": np.array(right, dtype=int),
            "kind": np.array(kind)}


def measure(values: dict, packs: dict, step: int,
            keep: np.ndarray | None = None) -> dict:
    """Одна відстань у парі: AUC на кожній метриці й варіанті чисел.

    Головне число — `edge`: пара через півот проти пари того самого
    краю ноги. `middle` лишається поруч як другий контроль.
    """
    pair = pairs_of(packs, step)
    if keep is not None:               # пари тільки своєї частини ряду
        take = keep[pair["left"]] & keep[pair["right"]]
        pair = {key: value[take] for key, value in pair.items()}
    counts = {kind: int((pair["kind"] == kind).sum()) for kind in KINDS}
    block = {"separation": step, **counts}
    if min(counts["across"], counts["edge"]) < 10:
        return {**block, "ready": False}
    stack, marks = [], []
    for variant in VARIANTS:
        table = values[variant]
        for metric in METRICS:
            far = distance(table[pair["left"]], table[pair["right"]], metric)
            item = {"across_median":
                    round(float(np.median(far[pair["kind"] == "across"])), 6)}
            for against in ("edge", "middle"):
                picked = np.isin(pair["kind"], ("across", against))
                label = (pair["kind"] == "across").astype(int)
                got = control.auc_block(np.where(picked, far, np.nan), label)
                item[against] = {
                    "auc": got["auc"], "z": got["z"],
                    "across": got["pivots"], "against": got["corrections"],
                    "median": round(float(np.median(
                        far[pair["kind"] == against])), 6)}
            block.setdefault(variant, {})[metric] = item
            # у контроль іде тільки те, що порівнюється: інакше
            # перемішана мітка розкидає пари по рядках, яких у замірі
            # немає, і найбільший |z| виходить ні з чого
            stack.append(far[np.isin(pair["kind"], ("across", "edge"))])
            marks.append({"variant": variant, "metric": metric})
    taken = pair["kind"][np.isin(pair["kind"], ("across", "edge"))]
    null = control.shuffle_null(
        np.array(stack), (taken == "across").astype(int),
        shuffles=SHUFFLES, seed=SEED)
    seen = [(abs(block[one["variant"]][one["metric"]]["edge"]["z"] or 0), one)
            for one in marks]
    null["best"] = max(seen, key=lambda one: one[0])[1]
    return {**block, "ready": True, "null": null}


def pack_block(data: dict, legs: list, size: int, inside: np.ndarray,
               part: str = "all", edge: float = 0.0) -> dict:
    """Одна довжина пачки: пачки, пари й міри на кожній відстані."""
    packs = cut(legs, size)
    if packs["start"].size < 20:
        return {"pack": size, "ready": False, "packs": int(packs["start"].size)}
    values = {"raw": vectors(data["x"], packs["start"], size),
              "rank": vectors(data["rank"], packs["start"], size)}
    when = data["t"][packs["start"]].astype(float)
    keep = None if part == "all" else (
        when < edge if part == "train" else when >= edge)
    rows = [measure(values, packs, step, keep) for step in SEPARATIONS]
    ready = [one for one in rows if one.get("ready")]
    best = None
    for one in ready:
        for variant in VARIANTS:
            for metric in METRICS:
                item = one[variant][metric]["edge"]
                if item["auc"] is None:
                    continue
                mark = {"separation": one["separation"], "variant": variant,
                        "metric": metric, **item}
                if best is None or abs(mark["z"]) > abs(best["z"]):
                    best = mark
    near = ready[0] if ready else None
    return {"pack": size, "ready": bool(ready),
            "packs": int(packs["start"].size if keep is None
                         else keep.sum()),
            "events": int(packs["start"].size * size),
            "columns": int(size * data["x"].shape[1] * data["x"].shape[2]),
            "by_separation": rows, "best": best,
            "near": ({"separation": near["separation"],
                      **{variant: near[variant] for variant in VARIANTS}}
                     if near else None)}


def build(pair: str = PAIR, class_name: str = CLASS, packs=PACKS,
          root: Path | None = None, part: str = "all") -> dict:
    data = inleg.load(pair, class_name, root)
    edge = float(data.get("cut", 0))
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True
    data["rank"] = ranked_events(data["x"], inside)

    by_pack = {str(size): pack_block(data, legs, size, inside, part, edge)
               for size in packs}
    # оптимальна пачка — найбільша AUC на сусідніх пачках (s = 1)
    best = None
    for size in packs:
        block = by_pack[str(size)]
        if not block.get("ready") or not block.get("near"):
            continue
        for variant in VARIANTS:
            for metric in METRICS:
                item = block["near"][variant][metric]["edge"]
                if item["auc"] is None:
                    continue
                mark = {"pack": size, "variant": variant, "metric": metric,
                        **item}
                if best is None or abs(mark["z"]) > abs(best["z"]):
                    best = mark
    return {
        "script": "research/30-inleg-events/scripts/pack_similarity.py",
        "pair": pair, "class": class_name, "part": part, "cut": int(edge),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "packs": list(packs), "default_pack": DEFAULT_PACK,
        "separations": list(SEPARATIONS), "metrics": list(METRICS),
        "variants": list(VARIANTS), "shuffles": SHUFFLES, "seed": SEED,
        "features": list(data["features"]),
        "blocks": int(data["x"].shape[1]),
        "legs": len(legs), "events": int(inside.sum()),
        "by_pack": by_pack, "optimal": best,
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, "
          f"{report['events']} подій у ногах; пара пачок своєї ноги проти "
          f"пари через півот, на однаковій відстані")
    for variant in VARIANTS:
        print(f"\nчисла: {variant}")
        head = f"{'пачка':>6} {'пачок':>7} " + "".join(
            f"{'s=' + str(step):>21}" for step in SEPARATIONS)
        print(head)
        for metric in METRICS:
            print(f"  метрика {metric}")
            for size in report["packs"]:
                block = report["by_pack"][str(size)]
                if not block.get("ready"):
                    print(f"{size:>6}   замало пачок")
                    continue
                line = f"{size:>6} {block['packs']:>7} "
                for one in block["by_separation"]:
                    if not one.get("ready") \
                            or one[variant][metric]["edge"]["auc"] is None:
                        line += f"{'—':>21}"
                        continue
                    item = one[variant][metric]["edge"]
                    line += (f"{item['auc']:>10.3f} (z {item['z']:>+5.1f})"
                             .rjust(21))
                print(line)
    best = report["optimal"]
    if best:
        print(f"\nоптимальна пачка (сусідні пачки, s = 1): "
              f"{best['pack']} подій, числа {best['variant']}, метрика "
              f"{best['metric']}: AUC {best['auc']:.3f}, z {best['z']:+.1f}, "
              f"{best['across']} пар через півот проти {best['against']} "
              f"пар того самого краю ноги")
        ready = [one for one in report["by_pack"][str(best["pack"])]
                 ["by_separation"] if one.get("ready")]
        if not ready:
            return
        block = ready[0]
        null = block["null"]
        print(f"контроль на цій пачці: {null['combos']} комбінацій, "
              f"найбільший |z| {null['max_z']:.1f}; на перемішаній мітці "
              f"медіана {null['null_median']:.1f}, 95 % "
              f"{null['null_p95']:.1f} -> p = {null['p_value']:.3f}")
        item = block[best["variant"]][best["metric"]]
        print(f"медіана відстані: через півот {item['across_median']:.4f}, "
              f"край ноги {item['edge']['median']:.4f}, "
              f"середина {item['middle']['median']:.4f}")
        print("\nдругий контроль — через півот проти середини ноги "
              "(той самий рядок, інша база):")
        for size in report["packs"]:
            near = report["by_pack"][str(size)].get("near")
            if not near or best["variant"] not in near:
                continue
            one = near[best["variant"]][best["metric"]]["middle"]
            edge = near[best["variant"]][best["metric"]]["edge"]
            print(f"  пачка {size:>3}: край {edge['auc']:.3f} "
                  f"(z {edge['z']:+.1f}) · середина {one['auc']:.3f} "
                  f"(z {one['z']:+.1f})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, PACKS, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"pack_similarity_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_pack"}
    meta["by_pack"] = {
        key: {one: item for one, item in block.items()
              if one not in ("by_separation", "near")}
        for key, block in report["by_pack"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
