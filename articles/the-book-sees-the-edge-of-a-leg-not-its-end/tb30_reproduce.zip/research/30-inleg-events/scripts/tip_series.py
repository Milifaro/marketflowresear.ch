"""Ряд val із видачею детектора «це хвіст ноги».

Дослідження: research/30-inleg-events/
Правила: rules/05-visualization.md → компоновка, rules/02-markup.md

Етап 10 показав числами: рівні фіч у вікні кажуть «це край ноги».
Тут та сама модель показана рядом — так, як цього вимагають правила
відображення: ціна з зігзагом зверху, видача моделі в підвалі на
**спільній осі X**, легенда під графіком.

Хід:

1. Ряд ділиться межею датасету: **модель учиться тільки на train**.
2. Вікно — `K` подій підряд, що закінчуються поточною подією, і не
   виходить за свою ногу. Вхід моделі — сім чисел: рівень кожної фічі
   класу у вікні (середнє по подіях і блоках).
3. **Ранги беруться з train.** Рівень val-події — це її місце серед
   train-подій, інакше вона знала б про майбутнє.
4. Мітка навчання: вікно, що закінчується півотом, — хвіст ноги (1);
   будь-яке інше вікно тієї самої ноги — 0. Голова ноги в негативи не
   входить (етап 10).
5. На val модель проходить **кожною подією** й дає число від 0 до 1.

Вихід — ряд для вкладки: час, ціна, ема10, півоти зігзага 2.3 %, видача
моделі і зона хвоста (останні `K` подій кожної ноги).

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/tip_series_<PAIR>_<клас>.json

Запуск:
    python3 research/30-inleg-events/scripts/tip_series.py
    python3 research/30-inleg-events/scripts/tip_series.py --size 10
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import leg_head_tail as headtail  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR
SIZE = 20                  # довжина вікна, подій
SEED = headtail.SEED
MODEL = headtail.MODEL


def train_ranks(values: np.ndarray, learn: np.ndarray) -> np.ndarray:
    """Ранг кожного числа події серед **train**-подій, 0…1, центрований.

    Val-подія міряється тією самою лінійкою, що й train: її ранг — це
    місце серед train-чисел. Майбутнього в лінійці немає.
    """
    out = np.zeros(values.shape, dtype=float)
    for block in range(values.shape[1]):
        for feature in range(values.shape[2]):
            column = values[:, block, feature]
            base = np.sort(column[learn & np.isfinite(column)])
            if base.size < 2:
                continue
            place = np.searchsorted(base, column, side="left") / base.size
            out[:, block, feature] = np.where(np.isfinite(column),
                                              place - 0.5, 0.0)
    return out


def windows_of(legs: list, size: int, learn: np.ndarray) -> dict:
    """Вікно на кожній події: де кінчається, чия нога, чи це хвіст."""
    end, leg_number, tail, part = [], [], [], []
    for number, leg in enumerate(legs):
        first = leg["first"] + size - 1
        if first > leg["last"]:
            continue
        for place in range(first, leg["last"] + 1):
            end.append(place)
            leg_number.append(number)
            tail.append(1 if place == leg["last"] else 0)
            part.append("train" if learn[place] else "val")
    return {"end": np.array(end, dtype=int),
            "leg": np.array(leg_number, dtype=int),
            "tail": np.array(tail, dtype=int),
            "part": np.array(part)}


def levels_of(rank: np.ndarray, end: np.ndarray, size: int) -> np.ndarray:
    """Рівень кожної фічі у вікні: середнє по його подіях і блоках."""
    index = end[:, None] - np.arange(size)[None, :]
    return rank[index].mean(axis=(1, 2))


def build(pair: str = PAIR, class_name: str = CLASS, size: int = SIZE,
          root: Path | None = None) -> dict:
    from sklearn.ensemble import HistGradientBoostingClassifier

    data = inleg.load(pair, class_name, root)
    cut = int(data["cut"])
    learn = data["t"] < cut
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]

    rank = train_ranks(data["x"], learn)
    rows = windows_of(legs, size, learn)
    level = levels_of(rank, rows["end"], size)
    # у навчання йде тільки вікно, яке цілком у train
    whole = learn[rows["end"]] & learn[rows["end"] - size + 1]
    train = whole & (rows["part"] == "train")
    model = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
    weight = np.where(rows["tail"][train] == 1,
                      1 / max(int((rows["tail"][train] == 1).sum()), 1),
                      1 / max(int((rows["tail"][train] == 0).sum()), 1))
    model.fit(level[train], rows["tail"][train], sample_weight=weight)

    said = np.full(len(data["t"]), np.nan)
    show = (rows["part"] == "val") & (rows["end"] >= 0)
    said[rows["end"][show]] = model.predict_proba(level[show])[:, 1]

    keep = data["t"] >= cut
    smooth = ema(data["open"], inleg.PERIOD)
    pivots = [{"t": int(data["t"][one.index]),
               "ema": float(smooth[one.index]), "kind": one.kind}
              for one in zigzag(smooth, inleg.THRESHOLD)
              if data["t"][one.index] >= cut]
    zone = np.zeros(len(data["t"]), dtype=int)
    for leg in legs:
        zone[max(leg["last"] - size + 1, leg["first"]):leg["last"] + 1] = 1

    truth = rows["tail"][show]
    score = model.predict_proba(level[show])[:, 1]
    value = inleg.auc(score[truth == 1], score[truth == 0])
    yes = int((truth == 1).sum())
    order = np.argsort(-score)
    limit = float(np.sort(score)[::-1][max(yes - 1, 0)]) if yes else 1.0
    return {
        "script": "research/30-inleg-events/scripts/tip_series.py",
        "pair": pair, "class": class_name, "part": "val", "size": size,
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "cut": cut, "seed": SEED, "model": MODEL,
        "model_kind": "HistGradientBoostingClassifier",
        "features": list(data["features"]),
        "event_seconds": 210,
        "legs": len(legs),
        "train_windows": int(train.sum()),
        "train_tails": int(rows["tail"][train].sum()),
        "events": int(keep.sum()),
        "windows": int(show.sum()),
        "tails": yes,
        "auc": round(float(value), 5) if yes else None,
        "precision": round(float(truth[order[:max(yes, 1)]].mean()), 5)
        if yes else None,
        "base": round(float(truth.mean()), 5) if truth.size else None,
        "limit": round(limit, 5),
        "t": [int(one) for one in data["t"][keep]],
        "price": [float(one) for one in data["open"][keep]],
        "ema": [float(one) for one in smooth[keep]],
        "p": [None if not np.isfinite(one) else round(float(one), 5)
              for one in said[keep]],
        "zone": [int(one) for one in zone[keep]],
        "pivots": pivots,
        "ready": bool(yes),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}: ряд val "
          f"{report['events']} подій, {report['windows']} вікон по "
          f"{report['size']} подій, {report['tails']} хвостів; модель "
          f"учена на {report['train_windows']} train-вікнах "
          f"({report['train_tails']} хвостів)")
    if report["auc"] is not None:
        print(f"на val: AUC {report['auc']:.3f}, точність верхівки "
              f"{report['precision'] * 100:.1f} % проти "
              f"{report['base'] * 100:.2f} % базових, поріг верхівки "
              f"{report['limit']:.3f}")
    print(f"півотів у вікні val: {len(report['pivots'])}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--size", type=int, default=SIZE)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.size, args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"tip_series_{args.pair}_{args.class_name}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items()
            if key not in ("t", "price", "ema", "p", "zone", "pivots")}
    meta["pivots"] = len(report["pivots"])
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
