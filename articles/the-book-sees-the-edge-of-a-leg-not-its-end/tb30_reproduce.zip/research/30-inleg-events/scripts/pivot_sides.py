"""Боки півота: чи можна по фічах сказати, з якого боку подія.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Етап 4 порівнював **згортки** фіч рангами й пулом. Тут питання ставиться
прямо, на самих фічах і на самій події:

    подія стоїть за `K` подій до півота чи за `K` подій після нього?

- Вхід — сирі числа класу, як вони є: 9 блоків × 7 фіч = **63 числа на
  подію**. Жодних згорток, рангів і кривих.
- Мітка — бік півота: 1 — подія нової ноги, 0 — подія старої.
- Відповідь — AUC кожного з 63 чисел і модель на всіх 63 одразу.

Напрямок. Стара й нова ноги дивляться в різні боки, тому фіча, яка знає
напрямок, розділила б боки сама собою — і це була б відповідь про
напрямок, а не про місце. Тому все міряється тричі: на всіх півотах
разом, на півотах `high` (нога вгору → нога вниз) і на півотах `low`
окремо. Ознака місця дає **однаковий знак** на обох боках, ознака
напрямку — протилежний.

Модель — `HistGradientBoostingClassifier` на 63 числах події. Розбиття
чесне й за часом: перші 70 % півотів учать, останні 30 % відповідають.
Подія тестового півота в навчання не потрапляє.

Контроль перемішуванням — той самий, що в `pivot_vs_correction.py`:
при 63 × 4 комбінаціях великий |z| зʼявляється сам собою.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/pivot_sides_<PAIR>_<клас>.json
       results/pivot_sides_<PAIR>_<клас>.meta.json

Запуск:
    python3 research/30-inleg-events/scripts/pivot_sides.py
    python3 research/30-inleg-events/scripts/pivot_sides.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

SIDES = (5, 10, 20, 40)          # скільки подій беремо з кожного боку
DEFAULT_SIDE = 20
TRAIN_SHARE = 0.7                # перші 70 % півотів — навчання
CUTS = ("all", "high", "low")    # усі півоти, тільки high, тільки low
SEED = 17
MODEL = {"max_iter": 300, "learning_rate": 0.05, "max_leaf_nodes": 7,
         "min_samples_leaf": 20, "l2_regularization": 1.0}


def pivots_of(legs: list) -> list:
    """Півоти між двома сусідніми ногами, що йдуть без пропуску."""
    rows = []
    for old, new in zip(legs, legs[1:]):
        if new["first"] != old["last"] + 1:
            continue
        rows.append({"index": old["last"],
                     "kind": "high" if old["kind"] == "up" else "low",
                     "old_first": old["first"], "new_last": new["last"],
                     "t": old["to"]})
    return rows


def events_of(data: dict, pivots: list, side: int) -> dict:
    """Події обабіч кожного півота: сирі числа класу і мітка боку."""
    index, label, owner, kind = [], [], [], []
    for number, pivot in enumerate(pivots):
        low = max(pivot["old_first"], pivot["index"] - side + 1)
        high = min(pivot["new_last"], pivot["index"] + side)
        before = np.arange(low, pivot["index"] + 1)
        after = np.arange(pivot["index"] + 1, high + 1)
        if before.size < side or after.size < side:
            continue
        index.extend(before.tolist() + after.tolist())
        label.extend([0] * before.size + [1] * after.size)
        owner.extend([number] * (before.size + after.size))
        kind.extend([pivot["kind"]] * (before.size + after.size))
    index = np.array(index, dtype=int)
    width = data["x"].shape[1] * data["x"].shape[2]
    x = data["x"][index].reshape(len(index), width) if index.size \
        else np.zeros((0, width))
    return {"x": x, "y": np.array(label), "pivot": np.array(owner),
            "kind": np.array(kind), "index": index}


def column_names(features: list, blocks: int) -> list:
    """Імʼя кожного з 63 чисел події: фіча і номер блока."""
    return [f"{name}·блок{block + 1}"
            for block in range(blocks) for name in features]


def by_column(rows: dict, names: list) -> list:
    """AUC кожного числа події: подія нової ноги проти події старої."""
    out = []
    for number, name in enumerate(names):
        values = rows["x"][:, number]
        block = {"column": name}
        for cut in CUTS:
            picked = np.ones(len(values), bool) if cut == "all" \
                else rows["kind"] == cut
            block[cut] = control.auc_block(np.where(picked, values, np.nan),
                                           rows["y"])
        out.append(block)
    return out


def model_run(rows: dict, pivots: list, cut: str,
              line: float | None = None) -> dict:
    """Модель на 63 числах події. Розбиття за часом, по півотах."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    picked = np.ones(len(rows["y"]), bool) if cut == "all" \
        else rows["kind"] == cut
    if picked.sum() < 40:
        return {"ready": False, "events": int(picked.sum())}
    when = np.array([pivot["t"] for pivot in pivots], dtype=float)
    order = np.argsort(when, kind="stable")
    early = order[:max(int(len(order) * TRAIN_SHARE), 1)] if line is None \
        else np.flatnonzero(when < float(line))
    train = picked & np.isin(rows["pivot"], early)
    test = picked & ~np.isin(rows["pivot"], early)
    if train.sum() < 40 or test.sum() < 20 \
            or len(np.unique(rows["y"][test])) < 2:
        return {"ready": False, "events": int(picked.sum())}
    model = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
    model.fit(np.nan_to_num(rows["x"][train], nan=0.0,
                            posinf=0.0, neginf=0.0), rows["y"][train])
    said = model.predict_proba(np.nan_to_num(rows["x"][test], nan=0.0,
                                             posinf=0.0,
                                             neginf=0.0))[:, 1]
    truth = rows["y"][test]
    value = inleg.auc(said[truth == 1], said[truth == 0])
    err = float(np.sqrt(((truth == 1).sum() + (truth == 0).sum() + 1)
                        / (12 * max((truth == 1).sum()
                                    * (truth == 0).sum(), 1))))
    return {"ready": True,
            "auc": round(float(value), 5),
            "z": round(float((value - 0.5) / err), 3) if err else None,
            "hit": round(float(((said >= 0.5).astype(int) == truth).mean()),
                         5),
            "base": round(float(max(truth.mean(), 1 - truth.mean())), 5),
            "train_events": int(train.sum()), "test_events": int(test.sum()),
            "train_pivots": int(len(early)),
            "test_pivots": int(len(order) - len(early))}


def measure(data: dict, pivots: list, side: int, part: str = "all",
            cut: float = 0.0) -> dict:
    """Один розмір боку: AUC кожного числа, контроль і модель."""
    rows = events_of(data, pivots, side)
    if rows["y"].size == 0 or len(np.unique(rows["y"])) < 2:
        return {"ready": False, "side": side, "events": 0}
    when = data["t"][rows["index"]].astype(float)
    keep = np.ones(len(when), bool) if part == "all" else (
        when < cut if part == "train" else when >= cut)
    if int(keep.sum()) < 20 or len(np.unique(rows["y"][keep])) < 2:
        return {"ready": False, "side": side, "events": int(keep.sum())}
    seen = {key: value[keep] for key, value in rows.items()}
    names = column_names(data["features"], data["x"].shape[1])
    columns = by_column(seen, names)
    stack = np.stack([seen["x"][:, number] for number in range(len(names))])
    null = control.shuffle_null(stack, seen["y"])
    best = max((one for one in columns if one["all"]["z"] is not None),
               key=lambda one: abs(one["all"]["z"]), default=None)
    null["best"] = {"column": best["column"] if best else None}
    return {"ready": True, "side": side,
            "events": int(seen["y"].size),
            "pivots": int(len(np.unique(seen["pivot"]))),
            "by_column": columns, "null": null,
            "model": {one: model_run(rows, pivots, one,
                                     cut if part == "val" else None)
                      for one in CUTS}}


def build(pair: str = PAIR, class_name: str = CLASS, sides=SIDES,
          root: Path | None = None, part: str = "all") -> dict:
    data = inleg.load(pair, class_name, root)
    cut = float(data.get("cut", 0))
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    pivots = pivots_of(legs)
    return {
        "script": "research/30-inleg-events/scripts/pivot_sides.py",
        "pair": pair, "class": class_name, "part": part, "cut": int(cut),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "sides": list(sides), "default_side": DEFAULT_SIDE,
        "cuts": list(CUTS), "train_share": TRAIN_SHARE,
        "model_kind": "HistGradientBoostingClassifier",
        "model": MODEL, "seed": SEED,
        "features": list(data["features"]),
        "blocks": int(data["x"].shape[1]),
        "columns": column_names(data["features"], data["x"].shape[1]),
        "legs": len(legs), "pivots": len(pivots),
        "by_side": {str(side): measure(data, pivots, side, part, cut)
                    for side in sides},
        "ready": bool(pivots),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, "
          f"{report['pivots']} півотів; вхід — сирі числа події "
          f"{report['blocks']} блоків × {len(report['features'])} фіч = "
          f"{len(report['columns'])} чисел")
    for side in report["sides"]:
        block = report["by_side"][str(side)]
        if not block.get("ready"):
            print(f"\n{side} подій з боку: замало подій")
            continue
        print(f"\n{side} подій з кожного боку: {block['events']} подій, "
              f"{block['pivots']} півотів")
        null = block["null"]
        print(f"  контроль: {null['combos']} комбінацій, найбільший |z| "
              f"{null['max_z']:.1f}; на перемішаній мітці медіана "
              f"{null['null_median']:.1f}, 95 % {null['null_p95']:.1f} "
              f"-> p = {null['p_value']:.3f}")
        rows = sorted((one for one in block["by_column"]
                       if one["all"]["z"] is not None),
                      key=lambda one: -abs(one["all"]["z"]))
        print("  найсильніші числа події (AUC: усі / high / low):")
        for one in rows[:6]:
            side = " · ".join(
                f"{one[cut]['auc']:.3f}" if one[cut]["auc"] is not None
                else "—" for cut in CUTS)
            print(f"    {one['column']:<24} {side}   "
                  f"(z {one['all']['z']:+.1f})")
        print("  модель на всіх числах події (тест — останні 30 % півотів):")
        for cut in CUTS:
            one = block["model"][cut]
            if not one.get("ready"):
                print(f"    {cut:<5} замало подій")
                continue
            print(f"    {cut:<5} AUC {one['auc']:.3f} (z {one['z']:+.1f}), "
                  f"влучність {one['hit'] * 100:.1f} % проти "
                  f"{one['base'] * 100:.1f} % базових, "
                  f"{one['test_events']} подій тесту з "
                  f"{one['test_pivots']} півотів")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, SIDES, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"pivot_sides_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_side"}
    meta["by_side"] = {
        key: {one: item for one, item in block.items() if one != "by_column"}
        for key, block in report["by_side"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
