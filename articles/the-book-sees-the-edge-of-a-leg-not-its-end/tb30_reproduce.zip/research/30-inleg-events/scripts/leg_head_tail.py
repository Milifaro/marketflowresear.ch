"""Голова ноги і її хвіст: чи повʼязані вони і чи видно по них кінець.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Два питання про одну ногу:

1. **Чи корелюють початок і кінець ноги.** У кожної ноги береться
   `голова` — перші `K` подій після півота — і `хвіст` — останні `K`
   подій перед наступним півотом. Чи повʼязаний рівень фічі в голові з
   її рівнем у хвості тієї самої ноги? Контроль — та сама кореляція з
   хвостом **чужої** ноги: якщо вона така сама, нога власного почерку
   не має.

2. **Чи можна по голові впізнати кінець.** Голова ноги вже відома —
   вона в минулому. Береться вікно з `K` подій і питання: це хвіст ноги
   чи її середина? Порівняння йде **з головою**: різниця рівнів
   `кандидат − голова` по кожній фічі й відстань між ними. Поруч —
   база без голови: ті самі рівні кандидата самі по собі. Якщо голова
   нічого не додає, порівнювати з нею немає сенсу.

Пачка описується сімома числами — рівень кожної фічі класу: середнє по
її подіях і блоках, переведене в **ранг серед подій ноги монети**
(відношення похідних мають хвости до 1e12). Відстані рахуються на
повному векторі пачки — `K × 9 блоків × 7 фіч`, сирому й ранговому.

| вхід моделі | що це |
| ----------- | ----- |
| `head` | різниця рівнів `кандидат − голова` по 7 фічах і 6 відстаней до голови |
| `plain` | тільки рівні кандидата — база без голови |
| `both` | обидва набори разом |

Розбиття за часом: перші 70 % ніг учать, останні відповідають. Контроль
перемішуванням — як в інших етапах.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_head_tail_<PAIR>_<клас>[_part].json
       results/leg_head_tail_<PAIR>_<клас>[_part].meta.json

Запуск:
    python3 research/30-inleg-events/scripts/leg_head_tail.py --part train
    python3 research/30-inleg-events/scripts/leg_head_tail.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pack_similarity as similarity  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

SIZES = (5, 10, 20, 40)          # довжина голови, хвоста й вікна-кандидата
DEFAULT_SIZE = 20
KITS = ("head", "plain", "both")  # що подається моделі
METRICS = similarity.METRICS
VARIANTS = similarity.VARIANTS
TRAIN_SHARE = 0.7
SHUFFLES = 300
SEED = 17
MODEL = {"max_iter": 200, "learning_rate": 0.05, "max_leaf_nodes": 7,
         "min_samples_leaf": 20, "l2_regularization": 1.0}


def levels(rank: np.ndarray, start: int, size: int) -> np.ndarray:
    """Рівень кожної фічі в пачці: середнє по її подіях і блоках."""
    return rank[start:start + size].mean(axis=(0, 1))


def windows(legs: list, size: int) -> list:
    """Голова, хвіст і середини кожної ноги — вікнами по `size` подій."""
    rows = []
    for number, leg in enumerate(legs):
        length = leg["last"] - leg["first"] + 1
        if length < 4 * size:          # голова, хвіст і хоч одна середина
            continue
        head = leg["first"]
        tail = leg["last"] - size + 1
        middles = list(range(head + size, tail - size + 1, size))
        if not middles:
            continue
        rows.append({"leg": number, "kind": leg["kind"], "t": leg["to"],
                     "events": length, "head": head, "tail": tail,
                     "middles": middles})
    return rows


def distances(values: dict, left: int, right: int, size: int) -> dict:
    """Шість відстаней між двома пачками: два набори чисел × три метрики."""
    out = {}
    for variant, table in values.items():
        one = table[left:left + size].reshape(1, -1)
        two = table[right:right + size].reshape(1, -1)
        for metric in METRICS:
            out[f"{variant}|{metric}"] = float(
                similarity.distance(one, two, metric)[0])
    return out


def pair_rows(data: dict, rows: list, size: int) -> dict:
    """Кандидати: хвіст ноги проти її середин, з головою як опорою."""
    values = {"raw": data["x"], "rank": data["rank"]}
    features = data["features"]
    names = ([f"різниця·{name}" for name in features]
             + [f"відстань·{key}" for key in
                (f"{variant}|{metric}" for variant in VARIANTS
                 for metric in METRICS)]
             + [f"рівень·{name}" for name in features])
    head_end = len(features) + len(VARIANTS) * len(METRICS)
    columns, label, owner, when = [], [], [], []
    for row in rows:
        head = levels(data["rank"], row["head"], size)
        for place, mark in ([(row["tail"], 1)]
                            + [(one, 0) for one in row["middles"]]):
            level = levels(data["rank"], place, size)
            far = distances(values, place, row["head"], size)
            columns.append(np.concatenate([
                level - head,
                np.array([far[f"{variant}|{metric}"]
                          for variant in VARIANTS for metric in METRICS]),
                level]))
            label.append(mark)
            owner.append(row["leg"])
            when.append(row["t"])
    return {"x": np.array(columns, dtype=float), "names": names,
            "y": np.array(label), "leg": np.array(owner),
            "t": np.array(when, dtype=float),
            "kits": {"head": list(range(head_end)),
                     "plain": list(range(head_end, len(names))),
                     "both": list(range(len(names)))}}


def head_tail_link(data: dict, rows: list, size: int) -> dict:
    """Кореляція рівня фічі в голові з її рівнем у хвості тієї самої ноги."""
    from scipy.stats import spearmanr

    if len(rows) < 8:
        return {"ready": False, "legs": len(rows)}
    head = np.array([levels(data["rank"], row["head"], size) for row in rows])
    tail = np.array([levels(data["rank"], row["tail"], size) for row in rows])
    middle = np.array([levels(data["rank"], row["middles"][
        len(row["middles"]) // 2], size) for row in rows])
    other = np.roll(tail, 1, axis=0)        # хвіст сусідньої ноги — контроль
    block = {}
    for number, name in enumerate(data["features"]):
        block[name] = {
            "own": round(float(spearmanr(head[:, number],
                                         tail[:, number]).statistic), 5),
            "middle": round(float(spearmanr(head[:, number],
                                            middle[:, number]).statistic), 5),
            "other": round(float(spearmanr(head[:, number],
                                           other[:, number]).statistic), 5),
            "head_level": round(float(np.median(head[:, number])), 5),
            "tail_level": round(float(np.median(tail[:, number])), 5)}
    # чи ближчий хвіст до своєї голови, ніж до чужої
    own = np.abs(tail - head).mean(axis=1)
    away = np.abs(other - head).mean(axis=1)
    return {"ready": True, "legs": len(rows),
            "by_feature": block,
            "own_distance": round(float(np.median(own)), 5),
            "other_distance": round(float(np.median(away)), 5),
            "auc": control.auc_block(np.concatenate([own, away]),
                                     np.concatenate([np.zeros(len(own)),
                                                     np.ones(len(away))]))}


def tail_vs_head(data: dict, rows: list, size: int) -> dict:
    """Хвіст ноги проти її голови — на самих рівнях фіч.

    Профіль ноги U-подібний (етап 1), тому детектор кінця може насправді
    ловити будь-який край. Тут питання пряме: чи відрізняє він хвіст від
    голови. Різниці й відстані до голови тут не беруть участі — для
    голови вони нульові за побудовою.
    """
    from sklearn.ensemble import HistGradientBoostingClassifier

    head = np.array([levels(data["rank"], row["head"], size) for row in rows])
    tail = np.array([levels(data["rank"], row["tail"], size) for row in rows])
    when = np.array([row["t"] for row in rows], dtype=float)
    x = np.concatenate([tail, head])
    label = np.concatenate([np.ones(len(tail)), np.zeros(len(head))])
    moment = np.concatenate([when, when])
    table = [{"column": f"рівень·{name}",
              **control.auc_block(x[:, number], label)}
             for number, name in enumerate(data["features"])]
    null = control.shuffle_null(x.T.copy(), label, shuffles=SHUFFLES,
                                seed=SEED)
    best = max((one for one in table if one["z"] is not None),
               key=lambda one: abs(one["z"]), default=None)
    null["best"] = {"column": best["column"] if best else None}

    model = {"ready": False}
    line = float(np.quantile(when, TRAIN_SHARE))
    train, test = moment <= line, moment > line
    if min(int(train.sum()), int(test.sum())) >= 10 \
            and len(np.unique(label[test])) == 2:
        fit = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
        fit.fit(np.nan_to_num(x[train]), label[train])
        said = fit.predict_proba(np.nan_to_num(x[test]))[:, 1]
        truth = label[test]
        value = inleg.auc(said[truth == 1], said[truth == 0])
        yes, no = int((truth == 1).sum()), int((truth == 0).sum())
        err = float(np.sqrt((yes + no + 1) / (12 * max(yes * no, 1))))
        model = {"ready": True, "auc": round(float(value), 5),
                 "z": round(float((value - 0.5) / err), 3) if err else None,
                 "hit": round(float(((said >= 0.5) == truth).mean()), 5),
                 "test_tails": yes, "test_heads": no}
    return {"ready": True, "legs": len(rows), "by_column": table,
            "null": null, "model": model}


def model_run(rows: dict, kit: str) -> dict:
    """Модель «це хвіст ноги чи середина» на заданому наборі входів."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    index = rows["kits"][kit]
    x, label, when = rows["x"][:, index], rows["y"], rows["t"]
    if label.size < 40 or len(np.unique(label)) < 2:
        return {"ready": False, "rows": int(label.size)}
    line = float(np.quantile(np.unique(when), TRAIN_SHARE))
    train, test = when <= line, when > line
    if min(int(train.sum()), int(test.sum())) < 20 \
            or len(np.unique(label[test])) < 2 \
            or len(np.unique(label[train])) < 2:
        return {"ready": False, "rows": int(label.size)}
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    weight = np.where(label[train] == 1,
                      1 / max(int((label[train] == 1).sum()), 1),
                      1 / max(int((label[train] == 0).sum()), 1))
    model = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
    model.fit(clean[train], label[train], sample_weight=weight)
    said = model.predict_proba(clean[test])[:, 1]
    truth = label[test]
    value = inleg.auc(said[truth == 1], said[truth == 0])
    yes, no = int((truth == 1).sum()), int((truth == 0).sum())
    err = float(np.sqrt((yes + no + 1) / (12 * max(yes * no, 1))))
    order = np.argsort(-said)
    hits = np.flatnonzero(truth[order] == 1)
    tenth = max(int(len(order) * 0.1), 1)
    return {"ready": True, "auc": round(float(value), 5),
            "z": round(float((value - 0.5) / err), 3) if err else None,
            "precision": round(float(truth[order[:yes]].mean()), 5),
            "base": round(float(truth.mean()), 5),
            "first_hit": int(hits[0] + 1) if hits.size else None,
            "recall_tenth": round(float((truth[order[:tenth]] == 1).sum()
                                        / max(yes, 1)), 5),
            "train_rows": int(train.sum()), "test_rows": int(test.sum()),
            "test_tails": yes, "test_middles": no}


def size_block(data: dict, legs: list, size: int) -> dict:
    """Одна довжина вікна: звʼязок голови з хвостом і детектор кінця."""
    rows = windows(legs, size)
    if len(rows) < 8:
        return {"size": size, "ready": False, "legs": len(rows)}
    pairs = pair_rows(data, rows, size)
    table = []
    for number, name in enumerate(pairs["names"]):
        got = control.auc_block(pairs["x"][:, number], pairs["y"])
        table.append({"column": name, **got})
    null = control.shuffle_null(pairs["x"].T.copy(), pairs["y"],
                                shuffles=SHUFFLES, seed=SEED)
    best = max((one for one in table if one["z"] is not None),
               key=lambda one: abs(one["z"]), default=None)
    null["best"] = {"column": best["column"] if best else None}
    return {"size": size, "ready": True, "legs": len(rows),
            "tails": int(pairs["y"].sum()),
            "middles": int((pairs["y"] == 0).sum()),
            "link": head_tail_link(data, rows, size),
            "edges": tail_vs_head(data, rows, size),
            "by_column": table, "null": null,
            "model": {kit: model_run(pairs, kit) for kit in KITS}}


def build(pair: str = PAIR, class_name: str = CLASS, sizes=SIZES,
          root: Path | None = None, part: str = "train") -> dict:
    data = inleg.load(pair, class_name, root, part)
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True
    data["rank"] = similarity.ranked_events(data["x"], inside)
    return {
        "script": "research/30-inleg-events/scripts/leg_head_tail.py",
        "pair": pair, "class": class_name, "part": part,
        "cut": int(data.get("cut", 0)),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "sizes": list(sizes), "default_size": DEFAULT_SIZE,
        "kits": list(KITS), "metrics": list(METRICS),
        "variants": list(VARIANTS), "train_share": TRAIN_SHARE,
        "shuffles": SHUFFLES, "seed": SEED,
        "model_kind": "HistGradientBoostingClassifier", "model": MODEL,
        "features": list(data["features"]),
        "legs": len(legs), "events": int(inside.sum()),
        "by_size": {str(size): size_block(data, legs, size)
                    for size in sizes},
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, {report['events']} "
          f"подій у ногах")
    for size in report["sizes"]:
        block = report["by_size"][str(size)]
        if not block.get("ready"):
            print(f"\nвікно {size} подій: замало ніг")
            continue
        print(f"\nвікно {size} подій: {block['legs']} ніг, "
              f"{block['tails']} хвостів проти {block['middles']} середин")
        link = block["link"]
        if link.get("ready"):
            print("  кореляція голови з хвостом тієї самої ноги "
                  "(своя · середина · чужий хвіст):")
            for name, one in link["by_feature"].items():
                print(f"    {name:<20} {one['own']:+.3f} · "
                      f"{one['middle']:+.3f} · {one['other']:+.3f}")
            print(f"    хвіст до своєї голови {link['own_distance']:.4f}, "
                  f"до чужої {link['other_distance']:.4f}, "
                  f"AUC {link['auc']['auc']:.3f} "
                  f"(z {link['auc']['z']:+.1f})")
        null = block["null"]
        print(f"  контроль: {null['combos']} колонок, найбільший |z| "
              f"{null['max_z']:.1f}; шум медіана {null['null_median']:.1f}, "
              f"95 % {null['null_p95']:.1f} -> p = {null['p_value']:.3f}")
        top = sorted((one for one in block["by_column"]
                      if one["z"] is not None),
                     key=lambda one: -abs(one["z"]))[:5]
        for one in top:
            print(f"    {one['column']:<28} AUC {one['auc']:.3f} "
                  f"z {one['z']:+.1f}")
        edges = block.get("edges", {})
        if edges.get("ready"):
            top = sorted((one for one in edges["by_column"]
                          if one["z"] is not None),
                         key=lambda one: -abs(one["z"]))[:3]
            line = " · ".join(f"{one['column'].split('·')[1]} "
                              f"{one['auc']:.3f}" for one in top)
            model = edges["model"]
            print(f"  хвіст проти голови ({edges['legs']} ніг): {line}; "
                  f"найбільший |z| {edges['null']['max_z']:.1f}, шум 95 % "
                  f"{edges['null']['null_p95']:.1f}, p = "
                  f"{edges['null']['p_value']:.3f}"
                  + (f"; модель AUC {model['auc']:.3f} "
                     f"(z {model['z']:+.1f})" if model.get("ready") else ""))
        print("  модель «це хвіст ноги» (тест — останні ноги за часом):")
        for kit in KITS:
            one = block["model"][kit]
            if not one.get("ready"):
                print(f"    {kit:<6} замало рядків")
                continue
            print(f"    {kit:<6} AUC {one['auc']:.3f} (z {one['z']:+.1f}), "
                  f"точність верхівки {one['precision'] * 100:.1f} % проти "
                  f"{one['base'] * 100:.1f} % базових, перший хвіст "
                  f"{one['first_hit']}, у верхній десятині "
                  f"{one['recall_tenth'] * 100:.0f} %")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="train", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, SIZES, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"leg_head_tail_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_size"}
    meta["by_size"] = {
        key: {one: item for one, item in block.items() if one != "by_column"}
        for key, block in report["by_size"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
