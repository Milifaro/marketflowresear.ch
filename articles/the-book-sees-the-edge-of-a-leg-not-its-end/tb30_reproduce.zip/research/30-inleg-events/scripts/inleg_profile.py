"""Події в межах ноги: чим подія на краю ноги відрізняється від решти.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Дослідження 29 (етап 1) міряло фічі `клас210х10-1х7д/д` уздовж ноги
однією згорткою — середнім по девʼяти блоках події. Тут те саме питання
ставиться **подія за подією і по кожному параметру події**:

1. **Де в нозі сидить параметр** — профіль по десятинах, краї проти
   середини, розріз за напрямком ноги.
2. **Чи видно це всередині однієї ноги** — Спірмен параметра з позицією
   події, порахований **у межах кожної ноги окремо**, і частка ніг, де
   знак той самий. Профіль пулом може бути наслідком того, що довгі ноги
   стоять в іншому місці ряду; всередині ноги такої лазівки немає.
3. **Подія за рухом ноги проти зустрічної** — подія, чий власний рух
   ціни йде в напрямку ноги, проти події, чий рух іде проти неї: чим
   вони відрізняються за кожним параметром і як ця різниця міняється
   по десятинах.
4. **Де починається інша нога** — вікно подій навколо півота: профіль
   параметра на кожному зсуві й AUC «подія нової ноги проти події
   старої» для вікон від 1 до 34 подій з кожного боку.

Параметри події. Подія класу — це `(9, 7)`: девʼять блоків по 21 с,
сім фіч. Кожна фіча згортається в шість чисел:

| параметр | що це |
| -------- | ----- |
| `mean`   | середнє по девʼяти блоках |
| `first`  | перший блок події |
| `last`   | останній блок події |
| `peak`   | блок з найбільшим модулем, зі своїм знаком |
| `spread` | розкид по блоках (стандартне відхилення) |
| `slope`  | нахил МНК по номеру блока — хід величини всередині події |

7 фіч × 6 параметрів = **42 величини на подію**, і кожна міряється
окремо.

Нормалізація. Відношення похідних не мають скінченного розкиду: ділення
на майже нуль дає хвости до 1e12, і середнє по десятині на сирих числах
не значить нічого (rules/01-data-and-db.md → `клас210х10-1х7д/д`). Тому
кожна величина переводиться **в ранги серед подій ніг цієї монети**:

    ранг      ранг самої величини, 0…1, рівень ряду 0.5
    амплітуда ранг |величини|, рівень ряду 0.5
    сплеск    подія в топ-5 % |величини| монети, рівень ряду 0.05

Напрямок ноги не вноситься в ранг (на відміну від дослідження 29): серед
параметрів є невідʼємні (`spread`), і множення на напрямок робило б їхній
ранг просто міткою напрямку. Напрямок іде окремим розрізом — ноги вгору
й ноги вниз рахуються нарізно.

Хід:

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 % -> ноги
    -> 42 величини на подію -> ранги по монеті -> чотири заміри

Ноги з дірою в ряді понад годину не рахуються — як у дослідженнях 28 і 29.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/inleg_profile_<PAIR>_<клас>.json      — усе
       results/inleg_profile_<PAIR>_<клас>.meta.json — те саме без ніг

Запуск:
    python3 research/30-inleg-events/scripts/inleg_profile.py
    python3 research/30-inleg-events/scripts/inleg_profile.py \
        --pair BTC_USDT --class class210x10m1x7dd
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
# розмітка ноги — той самий хід, що в дослідженнях 28 і 29
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from edge_profile import (DATASETS, DECILES, EDGES, HOLE,  # noqa: E402
                          MIDDLE, PERIOD, THRESHOLD, legs_of)
from edge_profile import load as load_series  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
PAIR = "BTC_USDT"

REDUCERS = ("mean", "first", "last", "peak", "spread", "slope")
CURVES = ("rank", "amplitude", "hot")
HOT = 0.95                       # межа сплеску: топ-5 % подій монети за |v|
BASE = {"rank": 0.5, "amplitude": 0.5, "hot": 1 - HOT}
OFFSETS = 40                     # скільки подій з кожного боку півота
WINDOWS = (1, 2, 3, 5, 8, 13, 21, 34)   # вікна порівняння через півот
MIN_LEG = 20                     # коротша нога в заміри всередині ноги не йде
PARTS = ("all", "train", "val")   # яку частину ряду міряти


def boundary(pair: str, class_name: str, root: Path | None = None) -> int:
    """Межа train/val датасету — перший час у `val.npz`."""
    folder = (root or DATASETS) / pair / class_name
    with np.load(folder / "val.npz", allow_pickle=False) as store:
        key = "t_start" if "t_start" in store else "timestamp"
        return int(store[key].min())


def load(pair: str, class_name: str, root: Path | None = None,
         part: str = "all") -> dict:
    """Ряд монети цілком або тільки одна його частина.

    `part` — `all` (train + val разом, як в усіх заміpах за замовчуванням),
    `train` (до межі датасету) або `val` (від межі). Межа береться з
    самого датасету, а не з дати в коді.
    """
    if part not in PARTS:
        raise ValueError(f"невідома частина ряду: {part}")
    data = load_series(pair, class_name, root)
    data["cut"] = boundary(pair, class_name, root)
    if part == "all":
        return data
    keep = data["t"] < data["cut"] if part == "train" \
        else data["t"] >= data["cut"]
    return {**data, "t": data["t"][keep], "open": data["open"][keep],
            "close": data["close"][keep], "x": data["x"][keep],
            "part": part}


# ---------------------------------------------------------------- величини

def reduce_blocks(block: np.ndarray, how: str) -> np.ndarray:
    """(N, 9) -> (N,): один параметр події з девʼяти блоків фічі."""
    block = np.asarray(block, dtype=float)
    if how == "mean":
        return np.nanmean(block, axis=1)
    if how == "first":
        return block[:, 0]
    if how == "last":
        return block[:, -1]
    if how == "peak":
        size = np.abs(np.nan_to_num(block, nan=-np.inf))
        return block[np.arange(len(block)), np.argmax(size, axis=1)]
    if how == "spread":
        return np.nanstd(block, axis=1)
    if how == "slope":
        # МНК по номеру блока, тільки по блоках із числом: вісь і величина
        # центруються на своєму рядку, порожні блоки в суми не входять
        steps = np.arange(block.shape[1], dtype=float)
        good = np.isfinite(block)
        count = good.sum(axis=1, keepdims=True)
        axis = np.where(good, steps, 0.0)
        value = np.where(good, block, 0.0)
        with np.errstate(invalid="ignore", divide="ignore"):
            axis = axis - np.where(count > 0, axis.sum(axis=1, keepdims=True)
                                   / np.maximum(count, 1), 0.0)
            value = value - np.where(count > 0,
                                     value.sum(axis=1, keepdims=True)
                                     / np.maximum(count, 1), 0.0)
        axis, value = np.where(good, axis, 0.0), np.where(good, value, 0.0)
        top = (value * axis).sum(axis=1)
        bottom = (axis ** 2).sum(axis=1)
        return np.divide(top, bottom, out=np.full(len(block), np.nan),
                         where=bottom != 0)
    raise ValueError(f"невідомий параметр події: {how}")


def columns_of(data: dict) -> dict:
    """42 величини події: кожна фіча класу × кожен параметр."""
    out = {}
    for index, name in enumerate(data["features"]):
        block = data["x"][:, :, index]
        for how in REDUCERS:
            out[f"{name}·{how}"] = reduce_blocks(block, how)
    return out


def ranks(column: np.ndarray, inside: np.ndarray) -> np.ndarray:
    """Ранг величини серед подій ніг цієї монети, 0…1. Не число — NaN."""
    out = np.full(column.shape, np.nan)
    good = inside & np.isfinite(column)
    count = int(good.sum())
    if count < 2:
        return out
    order = np.argsort(column[good], kind="stable")
    place = np.empty(count, dtype=float)
    place[order] = np.arange(count, dtype=float)
    out[good] = (place + 0.5) / count
    return out


def curves_of(column: np.ndarray, inside: np.ndarray) -> dict:
    """Три криві події: ранг величини, ранг модуля і сплеск."""
    size = np.abs(column)
    good = inside & np.isfinite(size)
    line = np.quantile(size[good], HOT) if good.any() else np.inf
    return {"rank": ranks(column, inside),
            "amplitude": ranks(size, inside),
            "hot": np.where(good, (size >= line).astype(float), np.nan)}


# ------------------------------------------------------------------- міри

def mean_of(piece: np.ndarray) -> float:
    good = np.isfinite(piece)
    return float(piece[good].mean()) if good.any() else float("nan")


def stat(values: np.ndarray) -> dict:
    """Середнє, похибка середнього і t по ногах."""
    values = np.asarray(values, dtype=float)
    good = values[np.isfinite(values)]
    if good.size < 2:
        return {"mean": None, "err": None, "t": None, "share": None,
                "legs": int(good.size)}
    err = float(good.std(ddof=1) / np.sqrt(good.size))
    return {"mean": float(good.mean()), "err": err,
            "t": float(good.mean() / err) if err else None,
            "share": float((good > 0).mean()), "legs": int(good.size)}


def tied(values: np.ndarray) -> np.ndarray:
    """Ранги з усередненням на однакових значеннях.

    Сплеск — колонка з нулів і одиниць: без усереднення однакові значення
    впорядкувалися б за номером події, і будь-яка міра читала б номер
    події замість величини.
    """
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="stable")
    place = np.empty(values.size, dtype=float)
    place[order] = np.arange(values.size, dtype=float)
    unique, back, counts = np.unique(values, return_inverse=True,
                                     return_counts=True)
    totals = np.zeros(unique.size)
    np.add.at(totals, back, place)
    return (totals / counts)[back]


def auc(positive: np.ndarray, negative: np.ndarray) -> float:
    """AUC через ранги: частка пар, де позитив вищий за негатив."""
    positive = positive[np.isfinite(positive)]
    negative = negative[np.isfinite(negative)]
    if positive.size == 0 or negative.size == 0:
        return float("nan")
    place = tied(np.concatenate([positive, negative]))
    top = place[:positive.size].sum() - positive.size * (positive.size - 1) / 2
    return float(top / (positive.size * negative.size))


def spearman(values: np.ndarray, place: np.ndarray) -> float:
    """Спірмен величини з позицією в нозі, всередині однієї ноги."""
    good = np.isfinite(values)
    if good.sum() < 4:
        return float("nan")
    rank, right = tied(values[good]), place[good]
    if np.std(rank) == 0 or np.std(right) == 0:
        return float("nan")
    return float(np.corrcoef(rank, right)[0, 1])


# ------------------------------------------------------------ хід по ногах

def leg_table(legs: list, curve: np.ndarray) -> dict:
    """Нога за ногою: десятини, Спірмен усередині ноги, краї проти середини."""
    deciles, inside, edge_auc, tail_auc, head_auc = [], [], [], [], []
    for leg in legs:
        first, last = leg["first"], leg["last"]
        piece = curve[first:last + 1]
        length = piece.size
        parts = np.minimum(
            np.floor(np.arange(length) / length * DECILES) + 1,
            DECILES).astype(int)
        deciles.append([mean_of(piece[parts == part])
                        for part in range(1, DECILES + 1)])
        if length < MIN_LEG:
            inside.append(np.nan)
            edge_auc.append(np.nan)
            head_auc.append(np.nan)
            tail_auc.append(np.nan)
            continue
        place = np.arange(length, dtype=float) / max(length - 1, 1)
        inside.append(spearman(piece, place))
        middle = np.isin(parts, MIDDLE)
        edge = np.isin(parts, EDGES)
        edge_auc.append(auc(piece[edge], piece[middle]))
        head_auc.append(auc(piece[parts == 1], piece[middle]))
        tail_auc.append(auc(piece[parts == DECILES], piece[middle]))
    return {"deciles": np.array(deciles, dtype=float),
            "inside": np.array(inside, dtype=float),
            "edge_auc": np.array(edge_auc, dtype=float),
            "head_auc": np.array(head_auc, dtype=float),
            "tail_auc": np.array(tail_auc, dtype=float)}


def decile_block(table: dict, picked: np.ndarray) -> dict:
    """Профіль по десятинах: середнє по ногах, краї проти середини."""
    rows = table["deciles"][picked]
    if rows.size == 0:
        return {"legs": 0}
    mean = np.nanmean(rows, axis=0)
    spread = np.nanstd(rows, axis=0)
    count = np.maximum(np.isfinite(rows).sum(axis=0), 1)
    err = spread / np.sqrt(count)
    edges = [part - 1 for part in EDGES]
    middle = [part - 1 for part in MIDDLE]
    gap = float(np.nanmean(mean[edges]) - np.nanmean(mean[middle]))
    return {"legs": int(picked.sum()),
            "curve": [round(float(v), 5) for v in mean],
            "err": [round(float(v), 5) for v in err],
            "head": round(float(mean[0]), 5),
            "tail": round(float(mean[-1]), 5),
            "edges": round(float(np.nanmean(mean[edges])), 5),
            "middle": round(float(np.nanmean(mean[middle])), 5),
            "gap": round(gap, 5),
            "t": round(float(gap / (float(np.nanmean(err)) or 1.0)), 3),
            "inside": stat(table["inside"][picked]),
            "edge_auc": stat(table["edge_auc"][picked] - 0.5),
            "head_auc": stat(table["head_auc"][picked] - 0.5),
            "tail_auc": stat(table["tail_auc"][picked] - 0.5)}


def by_move(legs: list, curve: np.ndarray, moves: np.ndarray) -> dict:
    """Подія за рухом ноги проти зустрічної: різниця пáрно всередині ноги."""
    pairs, co_level, counter_level, by_decile, share = [], [], [], [], []
    for leg in legs:
        first, last = leg["first"], leg["last"]
        piece = curve[first:last + 1]
        step = moves[first:last + 1] * (1 if leg["kind"] == "up" else -1)
        length = piece.size
        parts = np.minimum(
            np.floor(np.arange(length) / length * DECILES) + 1,
            DECILES).astype(int)
        co, counter = step > 0, step < 0
        if co.sum() < 3 or counter.sum() < 3:
            continue
        co_level.append(mean_of(piece[co]))
        counter_level.append(mean_of(piece[counter]))
        pairs.append(mean_of(piece[co]) - mean_of(piece[counter]))
        by_decile.append([
            mean_of(piece[co & (parts == part)])
            - mean_of(piece[counter & (parts == part)])
            for part in range(1, DECILES + 1)])
        share.append([float(np.mean(co[parts == part]))
                      if (parts == part).any() else np.nan
                      for part in range(1, DECILES + 1)])
    if not pairs:
        return {"legs": 0}
    table = np.array(by_decile, dtype=float)
    return {"legs": len(pairs),
            "co": round(mean_of(np.array(co_level)), 5),
            "counter": round(mean_of(np.array(counter_level)), 5),
            "diff": stat(np.array(pairs)),
            "by_decile": [round(float(v), 5)
                          for v in np.nanmean(table, axis=0)],
            "share": [round(float(v), 5) for v in
                      np.nanmean(np.array(share, dtype=float), axis=0)]}


def across_pivot(legs: list, curve: np.ndarray) -> dict:
    """Вікно подій навколо півота: профіль зсувів і AUC стара/нова нога."""
    before = [[] for _ in range(OFFSETS)]
    after = [[] for _ in range(OFFSETS)]
    for old, new in zip(legs, legs[1:]):
        if new["first"] != old["last"] + 1:
            continue          # між ногами пропуск: пари немає
        for step in range(OFFSETS):
            if old["last"] - step >= old["first"]:
                before[step].append(curve[old["last"] - step])
            if new["first"] + step <= new["last"]:
                after[step].append(curve[new["first"] + step])
    if not any(before) or not any(after):
        return {"pivots": 0}
    left = [np.array(one, dtype=float) for one in before]
    right = [np.array(one, dtype=float) for one in after]
    windows = []
    for size in WINDOWS:
        old = np.concatenate(left[:size]) if any(
            one.size for one in left[:size]) else np.array([])
        new = np.concatenate(right[:size]) if any(
            one.size for one in right[:size]) else np.array([])
        value = auc(new, old)
        count = min(old.size, new.size)
        # похибка AUC при однаковому розподілі боків: sqrt((n+m+1)/12nm)
        err = float(np.sqrt((old.size + new.size + 1)
                            / (12 * max(old.size * new.size, 1))))
        windows.append({"window": size,
                        "auc": round(value, 5) if np.isfinite(value) else None,
                        "z": round(float((value - 0.5) / err), 3)
                        if np.isfinite(value) and err else None,
                        "events": int(count)})
    return {"pivots": int(max(one.size for one in left)),
            "before": [round(mean_of(one), 5) for one in left[::-1]],
            "after": [round(mean_of(one), 5) for one in right],
            "before_err": [round(float(one[np.isfinite(one)].std()
                                       / max(np.sqrt(np.isfinite(one).sum()),
                                             1)), 5)
                           for one in left[::-1]],
            "after_err": [round(float(one[np.isfinite(one)].std()
                                      / max(np.sqrt(np.isfinite(one).sum()),
                                            1)), 5)
                          for one in right],
            "windows": windows,
            # краще вікно — найнадійніше, а не найбільше за AUC: вікно
            # в одну подію має 60-70 подій з боку, і будь-яке його число
            # гуляє на ±0.07
            "best": max((one for one in windows if one["z"] is not None),
                        key=lambda one: abs(one["z"]),
                        default=None)}


# ------------------------------------------------------------------ збірка

def build(pair: str = PAIR, class_name: str = CLASS,
          root: Path | None = None, part: str = "all") -> dict:
    data = load(pair, class_name, root, part)
    _, legs = legs_of(data)
    kept = [leg for leg in legs if leg["hole_hours"] * 3600 <= HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in kept:
        inside[leg["first"]:leg["last"] + 1] = True
    moves = np.log(data["close"] / data["open"])
    kinds = np.array([leg["kind"] for leg in kept])
    lengths = np.array([leg["events"] for leg in kept], dtype=float)
    cuts = {"all": np.ones(len(kept), dtype=bool),
            "up": kinds == "up", "down": kinds == "down"}

    columns = columns_of(data)
    report_columns = {}
    for name, column in columns.items():
        curves = curves_of(column, inside)
        block = {}
        for curve_name, curve in curves.items():
            table = leg_table(kept, curve)
            block[curve_name] = {
                **{cut: decile_block(table, picked)
                   for cut, picked in cuts.items()},
                "move": by_move(kept, curve, moves),
                "pivot": across_pivot(kept, curve)}
        report_columns[name] = block

    return {
        "script": "research/30-inleg-events/scripts/inleg_profile.py",
        "pair": pair, "class": class_name, "part": part,
        "cut": int(data.get("cut", 0)),
        "threshold": THRESHOLD, "period": PERIOD, "deciles": DECILES,
        "edges": list(EDGES), "middle": list(MIDDLE),
        "hole_hours": HOLE / 3600, "min_leg": MIN_LEG,
        "offsets": OFFSETS, "windows": list(WINDOWS),
        "curves": list(CURVES), "base": BASE,
        "normalise": "ранги серед подій ніг монети",
        "features": list(data["features"]), "reducers": list(REDUCERS),
        "columns": list(columns),
        "events": int(inside.sum()), "events_all": int(len(data["t"])),
        "legs": len(kept), "dropped_legs": len(legs) - len(kept),
        "leg_events": {"median": float(np.median(lengths)) if len(kept) else 0,
                       "min": float(lengths.min()) if len(kept) else 0,
                       "max": float(lengths.max()) if len(kept) else 0},
        "from": int(data["t"].min()), "to": int(data["t"].max()),
        "by_column": report_columns,
        "ready": bool(kept),
    }


def strict(item):
    """JSON не тримає NaN: клітинка без числа стає null."""
    if isinstance(item, float):
        return item if np.isfinite(item) else None
    if isinstance(item, (np.floating, np.integer)):
        return strict(item.item())
    if isinstance(item, dict):
        return {key: strict(value) for key, value in item.items()}
    if isinstance(item, list):
        return [strict(value) for value in item]
    return item


def show(report: dict) -> None:
    """Короткий звіт у термінал: найсильніші величини кожного заміру."""
    print(f"{report['pair']}, клас {report['class']}, частина ряду "
          f"{report['part']}: "
          f"{report['legs']} ніг (відкинуто з дірами "
          f"{report['dropped_legs']}), {report['events']} подій у ногах, "
          f"медіана ноги {report['leg_events']['median']:.0f} подій")
    print(f"зігзаг {report['threshold'] * 100:.1f} % на ема{report['period']}, "
          f"{len(report['columns'])} величин події "
          f"({len(report['features'])} фіч × {len(report['reducers'])} "
          f"параметрів), нормалізація — {report['normalise']}")

    def top(key, count=8):
        rows = []
        for name, block in report["by_column"].items():
            for curve in CURVES:
                rows.append((name, curve, key(block[curve])))
        rows = [row for row in rows if row[2] is not None
                and np.isfinite(row[2])]
        rows.sort(key=lambda row: -abs(row[2]))
        return rows[:count]

    print("\n1. краї проти середини (t по ногах)")
    for name, curve, value in top(lambda one: one["all"]["t"]):
        block = report["by_column"][name][curve]["all"]
        print(f"  {name:<28} {curve:<9} краї {block['edges']:+.3f} "
              f"середина {block['middle']:+.3f} t {value:+.1f}")

    print("\n2. всередині однієї ноги (Спірмен з позицією, t по ногах)")
    for name, curve, value in top(
            lambda one: (one["all"]["inside"] or {}).get("t")):
        block = report["by_column"][name][curve]["all"]["inside"]
        print(f"  {name:<28} {curve:<9} ρ {block['mean']:+.3f} "
              f"t {value:+.1f} ніг зі знаком {block['share']:.2f}")

    print("\n3. подія за рухом ноги проти зустрічної (t по ногах)")
    for name, curve, value in top(
            lambda one: (one["move"].get("diff") or {}).get("t")):
        block = report["by_column"][name][curve]["move"]
        print(f"  {name:<28} {curve:<9} за рухом {block['co']:+.3f} "
              f"проти {block['counter']:+.3f} "
              f"різниця {block['diff']['mean']:+.4f} t {value:+.1f}")

    print("\n4. подія нової ноги проти події старої (краще вікно за z)")
    for name, curve, value in top(
            lambda one: (one["pivot"].get("best") or {}).get("z")):
        block = report["by_column"][name][curve]["pivot"]["best"]
        print(f"  {name:<28} {curve:<9} вікно {block['window']:>2} подій "
              f"AUC {block['auc']:.3f} (z {value:+.1f}, "
              f"{block['events']} подій з боку)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"inleg_profile_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_column"}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False),
        encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
