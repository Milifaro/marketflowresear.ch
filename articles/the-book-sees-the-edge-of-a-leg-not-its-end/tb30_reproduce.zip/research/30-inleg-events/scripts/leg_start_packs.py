"""Пачка від півота: коли вже можна сказати, що почалась нова нога.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Питання причинне й пряме: після півота пройшла одна подія, дві, три …
скільки їх треба, щоб відрізнити **початок нової ноги** від будь-якого
іншого місця тієї самої ноги?

    пачка = `N` подій підряд, узятих **з першої події після півота**
    мітка 1 — пачка справді стоїть на початку ноги
    мітка 0 — пачка тієї самої довжини з середини ноги

Вхід — сирі числа класу, як вони лежать у події: `N × 9 блоків × 7 фіч`.
Жодних згорток, рангів і кривих: кожне число події — окрема колонка,
і колонка знає, на якій події пачки вона стоїть
(`d_up·блок3·подія2` — фіча `d_up`, третій блок, друга подія пачки).

Негативна пачка береться не ближче за `CLEAR` подій до початку своєї
ноги й не переходить через її кінець: інакше «середина ноги» містила б
той самий півот, який шукаємо. Кроком `STRIDE` — щоб сусідні пачки не
повторювали одна одну подія в подію.

Заміри на кожній довжині пачки:

| # | Що | Як |
| - | -- | -- |
| 1 | **кожне число окремо** | AUC «початок ноги проти середини» на самому значенні фічі в цьому блоці цієї події пачки |
| 2 | **контроль** | мітку перемішують 300 разів і щоразу беруть найбільший \\|z\\| усього перебору: при тисячах колонок великий \\|z\\| зʼявляється сам собою |
| 3 | **модель** | `HistGradientBoostingClassifier` на всіх числах пачки одразу; розбиття за часом — перші 70 % ряду вчать, останні відповідають |
| 4 | **початки ніг між собою** | та сама пачка, але питання інше: початок ноги вгору проти початку ноги вниз |

Модель зважує боки: негативних пачок у десятки разів більше, тому вага
кожного боку однакова, а влучність читається як **точність на верхніх
`P` пачках**, де `P` — скільки початків ніг у тесті.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_start_packs_<PAIR>_<клас>.json
       results/leg_start_packs_<PAIR>_<клас>.meta.json

Запуск:
    python3 research/30-inleg-events/scripts/leg_start_packs.py
    python3 research/30-inleg-events/scripts/leg_start_packs.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pivot_sides as sides  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

PACKS = (1, 2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 26, 33, 40)
DEFAULT_PACK = 10
CLEAR = 60          # негативна пачка не ближче за стільки подій до півота
STRIDE = 10         # крок негативних пачок по ряду
TOP = 12            # скільки найсильніших чисел лишається у звіті
SHUFFLES = 300
TRAIN_SHARE = 0.7   # перші 70 % ряду за часом — навчання
SEED = 17
MODEL = {"max_iter": 200, "learning_rate": 0.05, "max_leaf_nodes": 7,
         "min_samples_leaf": 20, "l2_regularization": 1.0}


def packs_of(legs: list, size: int) -> dict:
    """Пачки по `size` подій: початки ніг і середини тих самих ніг."""
    start, label, kind, first = [], [], [], []
    for number, leg in enumerate(legs):
        head = leg["first"]
        if number and legs[number - 1]["last"] + 1 == leg["first"] \
                and head + size - 1 <= leg["last"]:
            start.append(head)
            label.append(1)
            kind.append(leg["kind"])
            first.append(leg["first"])
        low = leg["first"] + CLEAR
        high = leg["last"] - size + 1
        for place in range(low, high + 1, STRIDE):
            start.append(place)
            label.append(0)
            kind.append(leg["kind"])
            first.append(leg["first"])
    return {"start": np.array(start, dtype=int),
            "y": np.array(label, dtype=int),
            "kind": np.array(kind),
            "leg_first": np.array(first, dtype=int)}


def numbers_of(data: dict, start: np.ndarray, size: int) -> np.ndarray:
    """Сирі числа пачки: `size` подій × 9 блоків × 7 фіч, одним рядком."""
    width = data["x"].shape[1] * data["x"].shape[2]
    if start.size == 0:
        return np.zeros((0, width * size))
    index = start[:, None] + np.arange(size)[None, :]
    return data["x"][index].reshape(len(start), size * width)


def column_names(features: list, blocks: int, size: int) -> list:
    """Імʼя кожної колонки пачки: фіча, блок і номер події в пачці."""
    return [f"{name}·блок{block + 1}·подія{step + 1}"
            for step in range(size)
            for block in range(blocks) for name in features]


def top_columns(x: np.ndarray, label: np.ndarray, names: list,
                top: int = TOP) -> list:
    """Найсильніші числа пачки за |z| до AUC."""
    rank = np.zeros(x.shape[::-1], dtype=float)
    good = np.zeros(x.shape[::-1], dtype=bool)
    for number in range(x.shape[1]):
        rank[number], good[number] = control.ranked(x[:, number])
    auc = control.auc_of(rank, good, label)
    z = control.z_of(auc, rank, good, label)
    order = np.argsort(-np.abs(np.nan_to_num(z)))[:top]
    return [{"column": names[number],
             "auc": round(float(auc[number]), 5),
             "z": round(float(z[number]), 3)}
            for number in order if np.isfinite(z[number])]


def model_run(x: np.ndarray, label: np.ndarray, when: np.ndarray,
              line: float | None = None) -> dict:
    """Модель на всіх числах пачки. Розбиття за часом, боки зважені."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    if label.size < 40 or len(np.unique(label)) < 2:
        return {"ready": False, "packs": int(label.size)}
    line = float(np.quantile(when, TRAIN_SHARE)) if line is None \
        else float(line)
    train, test = when < line, when >= line
    if min(int(train.sum()), int(test.sum())) < 10 \
            or len(np.unique(label[test])) < 2 \
            or len(np.unique(label[train])) < 2:
        return {"ready": False, "packs": int(label.size)}
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    weight = np.where(label[train] == 1,
                      1 / max(int((label[train] == 1).sum()), 1),
                      1 / max(int((label[train] == 0).sum()), 1))
    model = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
    model.fit(clean[train], label[train], sample_weight=weight)
    said = model.predict_proba(clean[test])[:, 1]
    truth = label[test]
    value = inleg.auc(said[truth == 1], said[truth == 0])
    yes, no = int((truth == 1).sum()), int((truth == 0).sum())
    err = float(np.sqrt((yes + no + 1) / (12 * max(yes * no, 1))))
    order = np.argsort(-said)                # видача від найгучнішої
    top = order[:yes]                        # верхні P пачок, P — початків
    hits = np.flatnonzero(truth[order] == 1)
    tenth = max(int(len(order) * 0.1), 1)
    return {"ready": True,
            "auc": round(float(value), 5),
            "z": round(float((value - 0.5) / err), 3) if err else None,
            "precision": round(float(truth[top].mean()), 5),
            "base": round(float(truth.mean()), 5),
            "lift": round(float(truth[top].mean() / max(truth.mean(),
                                                        1e-9)), 3),
            # де в видачі стоїть перший справжній початок ноги і скільки
            # їх зібралось у верхній десятині — точність на верхівці
            # нічого не каже, коли вона нульова
            "first_hit": int(hits[0] + 1) if hits.size else None,
            "recall_tenth": round(float((truth[order[:tenth]] == 1).sum()
                                        / max(yes, 1)), 5),
            "packs_tenth": int(tenth),
            "train_packs": int(train.sum()), "test_packs": int(test.sum()),
            "train_starts": int((label[train] == 1).sum()),
            "test_starts": int((label[test] == 1).sum())}


def measure(data: dict, legs: list, size: int, part: str = "all",
            cut: float = 0.0) -> dict:
    """Одна довжина пачки: числа, контроль, модель і початки між собою."""
    rows = packs_of(legs, size)
    if rows["y"].size == 0 or rows["y"].sum() < 5:
        return {"ready": False, "pack": size, "starts": int(rows["y"].sum())}
    x = numbers_of(data, rows["start"], size)
    names = column_names(data["features"], data["x"].shape[1], size)
    when = data["t"][rows["start"]].astype(float)
    keep = np.ones(len(when), bool) if part == "all" else (
        when < cut if part == "train" else when >= cut)
    if int(rows["y"][keep].sum()) < 5:
        return {"ready": False, "pack": size,
                "starts": int(rows["y"][keep].sum())}

    null = control.shuffle_null(x[keep].T, rows["y"][keep],
                                shuffles=SHUFFLES, seed=SEED)
    top = top_columns(x[keep], rows["y"][keep], names)
    null["best"] = {"column": top[0]["column"] if top else None}

    heads = (rows["y"] == 1) & keep        # початки ніг між собою
    pair_label = (rows["kind"][heads] == "up").astype(int)
    pair = {"ready": False, "starts": int(heads.sum())}
    if heads.sum() >= 10 and len(np.unique(pair_label)) == 2:
        pair = {"ready": True, "starts": int(heads.sum()),
                "up": int(pair_label.sum()),
                "down": int((pair_label == 0).sum()),
                "null": control.shuffle_null(x[heads].T, pair_label,
                                             shuffles=SHUFFLES, seed=SEED),
                "top": top_columns(x[heads], pair_label, names),
                "model": model_run(x[heads], pair_label, when[heads],
                                   cut if part == "val" else None)}

    line = cut if part == "val" else None
    return {"ready": True, "pack": size,
            "packs": int(keep.sum()),
            "starts": int(rows["y"][keep].sum()),
            "middles": int((rows["y"][keep] == 0).sum()),
            "columns": len(names),
            "null": null, "top": top,
            "model": {"all": model_run(x, rows["y"], when, line),
                      "up": model_run(x[rows["kind"] == "up"],
                                      rows["y"][rows["kind"] == "up"],
                                      when[rows["kind"] == "up"], line),
                      "down": model_run(x[rows["kind"] == "down"],
                                        rows["y"][rows["kind"] == "down"],
                                        when[rows["kind"] == "down"], line)},
            "pair": pair}


def build(pair: str = PAIR, class_name: str = CLASS, packs=PACKS,
          root: Path | None = None, part: str = "all") -> dict:
    data = inleg.load(pair, class_name, root)
    cut = float(data.get("cut", 0))
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    return {
        "script": "research/30-inleg-events/scripts/leg_start_packs.py",
        "pair": pair, "class": class_name, "part": part, "cut": int(cut),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "packs": list(packs), "default_pack": DEFAULT_PACK,
        "cuts": ["all", "up", "down"],
        "clear": CLEAR, "stride": STRIDE, "top": TOP,
        "train_share": TRAIN_SHARE, "seed": SEED,
        "model_kind": "HistGradientBoostingClassifier", "model": MODEL,
        "features": list(data["features"]),
        "blocks": int(data["x"].shape[1]),
        "legs": len(legs),
        "pivots": len(sides.pivots_of(legs)),
        "by_pack": {str(size): measure(data, legs, size, part, cut)
                    for size in packs},
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, "
          f"{report['pivots']} півотів; пачка від першої події після "
          f"півота проти пачки з середини ноги (не ближче "
          f"{report['clear']} подій до її початку, крок "
          f"{report['stride']})")
    print(f"вхід — сирі числа: {report['blocks']} блоків × "
          f"{len(report['features'])} фіч на подію, помножені на довжину "
          f"пачки; модель {report['model_kind']}, перші "
          f"{report['train_share'] * 100:.0f} % ряду вчать")
    head = (f"\n{'пачка':>6} {'колонок':>8} {'початків':>9} {'середин':>8} "
            f"{'AUC':>6} {'точність':>9} {'база':>6} {'десятина':>8} "
            f"{'перший':>7} {'|z|':>7} {'p':>6}")
    print(head)
    for size in report["packs"]:
        block = report["by_pack"][str(size)]
        if not block.get("ready"):
            print(f"{size:>6}   замало пачок")
            continue
        model = block["model"]["all"]
        null = block["null"]
        if not model.get("ready"):
            print(f"{size:>6} {block['columns']:>8} {block['starts']:>9} "
                  f"{block['middles']:>8}   модель не рахувалась")
            continue
        print(f"{size:>6} {block['columns']:>8} {block['starts']:>9} "
              f"{block['middles']:>8} {model['auc']:>6.3f} "
              f"{model['precision'] * 100:>8.1f}% {model['base'] * 100:>5.1f}%"
              f" {model['recall_tenth'] * 100:>7.0f}% "
              f"{str(model['first_hit']):>7} {null['max_z']:>7.1f} "
              f"{null['p_value']:>6.3f}")

    block = report["by_pack"][str(report["default_pack"])]
    if block.get("ready"):
        print(f"\nпачка {report['default_pack']} подій — найсильніші числа:")
        for one in block["top"][:8]:
            print(f"  {one['column']:<34} AUC {one['auc']:.3f} "
                  f"z {one['z']:+.1f}")
        for cut in ("up", "down"):
            model = block["model"][cut]
            if model.get("ready"):
                print(f"  ноги {cut:<5} AUC {model['auc']:.3f}, точність "
                      f"{model['precision'] * 100:.1f} % проти "
                      f"{model['base'] * 100:.1f} % базових")

    print("\nпочатки ніг між собою (вгору проти вниз):")
    for size in report["packs"]:
        block = report["by_pack"][str(size)]
        pair = block.get("pair", {}) if block.get("ready") else {}
        if not pair.get("ready"):
            continue
        model = pair["model"]
        line = (f"AUC моделі {model['auc']:.3f}" if model.get("ready")
                else "модель не рахувалась")
        print(f"  пачка {size:>3}: {pair['up']} вгору проти {pair['down']} "
              f"вниз, найбільший |z| чисел {pair['null']['max_z']:.1f} "
              f"(шум 95 % {pair['null']['null_p95']:.1f}, "
              f"p = {pair['null']['p_value']:.3f}), {line}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, PACKS, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"leg_start_packs_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_pack"}
    meta["by_pack"] = {
        key: {one: item for one, item in block.items() if one != "top"}
        for key, block in report["by_pack"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
