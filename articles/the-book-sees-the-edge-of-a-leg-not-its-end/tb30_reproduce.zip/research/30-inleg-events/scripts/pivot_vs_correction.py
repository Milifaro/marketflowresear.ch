"""Справжній півот проти корекції: чи бачить клас різницю наперед.

Дослідження: research/30-inleg-events/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Етап 4 порівнював хвіст ноги з головою наступної — тобто **при вже
відомому півоті**. Питання цього етапу інше й причинне: у нозі повно
місць, де ціна розвернулась проти ноги на 0.5–1.5 % і нога пішла далі.
Чи відрізняється в класі місце, де нога **справді скінчилась**, від
місця, де була лише корекція?

Кандидати — точки, де ціна розвернулась проти ноги:

| хто | як знайдено | мітка |
| --- | ----------- | ----- |
| **півот** | півот зігзага 2.3 % на ема10 — нога тут скінчилась | 1 |
| **корекція** | півот вкладеного зігзага меншого порогу всередині ноги, того самого боку, що завершив би ногу (`high` в нозі вгору, `low` в нозі вниз) — розворот був, але нога пішла далі | 0 |

Корекція береться не ближче за `GAP` подій до країв своєї ноги: інакше її
вікно захопило б справжній півот, і замір порівнював би півот із півотом.

Замір. Навколо кожного кандидата беруться два вікна по `W` подій:

    before  середній ранг величини на подіях `idx - W + 1 … idx`
    after   середній ранг на подіях `idx + 1 … idx + W`
    step    after - before

`before` — **причинний**: у момент кандидата ці події вже є. `after`
причинним не є й показує лише, чи різниця взагалі існує. На кожній з
42 величин події й кожній кривій рахується AUC «півот проти корекції» і
`z` до нього.

Глибина корекції — рух від кандидата до наступного півота вкладеного
зігзага, у відсотках: саме те, наскільки далеко пішов рух проти ноги.
Замір повторюється по смугах глибини — чи схожа глибока корекція на
справжній півот сильніше за дрібну.

Величини події, ранги й ноги — ті самі, що в `inleg_profile.py`.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/pivot_vs_correction_<PAIR>_<клас>.json
       results/pivot_vs_correction_<PAIR>_<клас>.meta.json

Запуск:
    python3 research/30-inleg-events/scripts/pivot_vs_correction.py
    python3 research/30-inleg-events/scripts/pivot_vs_correction.py \
        --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

SMALLS = (0.005, 0.008, 0.010, 0.015)   # пороги вкладеного зігзага
DEFAULT_SMALL = 0.010                   # той, що показує вкладка
WINDOWS = (5, 13, 21, 34)               # подій з кожного боку кандидата
DEFAULT_WINDOW = 21                     # вікно, на якому йдуть смуги глибини
GAP = 40                                # відступ корекції від країв ноги
DEPTH_BINS = ((0.005, 0.010), (0.010, 0.015), (0.015, None))
MEASURES = ("before", "after", "step")
SHUFFLES = 500                          # перемішувань мітки в контролі
SEED = 17


def candidates(data: dict, legs: list, small: float) -> list:
    """Точки розвороту проти ноги: справжні півоти й корекції."""
    smooth = ema(data["open"], inleg.PERIOD)
    rows = []
    for number, leg in enumerate(legs):
        if number + 1 < len(legs) \
                and legs[number + 1]["first"] == leg["last"] + 1:
            after = legs[number + 1]
            rows.append({"index": leg["last"], "pivot": 1, "leg": leg["leg"],
                         "kind": leg["kind"], "depth": abs(after["move"]),
                         "low": leg["first"], "high": after["last"]})
    inner = zigzag(smooth, small)
    for point, nxt in zip(inner, inner[1:]):
        for leg in legs:
            if not leg["first"] + GAP <= point.index <= leg["last"] - GAP:
                continue
            ends = "high" if leg["kind"] == "up" else "low"
            if point.kind != ends:
                break
            depth = abs(float(np.log(smooth[nxt.index] / smooth[point.index])))
            rows.append({"index": int(point.index), "pivot": 0,
                         "leg": leg["leg"], "kind": leg["kind"],
                         "depth": depth,
                         "low": leg["first"], "high": leg["last"]})
            break
    return rows


def windows_of(curve: np.ndarray, rows: list, size: int) -> dict:
    """Три числа на кандидата: до точки, після неї і різниця."""
    out = {name: [] for name in MEASURES}
    out["ok"] = []
    for row in rows:
        index = row["index"]
        full = (index - size + 1 >= row["low"]
                and index + size <= row["high"])
        if not full:
            out["ok"].append(False)
            for name in MEASURES:
                out[name].append(np.nan)
            continue
        before = inleg.mean_of(curve[index - size + 1:index + 1])
        after = inleg.mean_of(curve[index + 1:index + size + 1])
        out["ok"].append(True)
        out["before"].append(before)
        out["after"].append(after)
        out["step"].append(after - before)
    return {name: np.array(out[name], dtype=float) for name in MEASURES} \
        | {"ok": np.array(out["ok"], dtype=bool)}


def auc_block(values: np.ndarray, label: np.ndarray) -> dict:
    """AUC «півот проти корекції» і `z` під нею."""
    good = np.isfinite(values)
    yes = values[good & (label == 1)]
    no = values[good & (label == 0)]
    if yes.size < 3 or no.size < 3:
        return {"auc": None, "z": None, "pivots": int(yes.size),
                "corrections": int(no.size)}
    value = inleg.auc(yes, no)
    err = float(np.sqrt((yes.size + no.size + 1)
                        / (12 * max(yes.size * no.size, 1))))
    return {"auc": round(value, 5),
            "z": round(float((value - 0.5) / err), 3) if err else None,
            "pivots": int(yes.size), "corrections": int(no.size)}


def ranked(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Ранги величини серед своїх чисел і маска, де число є.

    Ранги від перестановки мітки не залежать, тому рахуються раз: AUC
    перемішаного набору — це та сама сума рангів, узята по інших рядках.
    """
    good = np.isfinite(values)
    place = np.zeros(values.size, dtype=float)
    if good.any():
        place[good] = inleg.tied(values[good])
    return place, good


def auc_of(rank: np.ndarray, good: np.ndarray,
           label: np.ndarray) -> np.ndarray:
    """AUC кожного рядка стосу для однієї мітки. Мало чисел — NaN."""
    yes = good * (label == 1)
    count_yes = yes.sum(axis=1)
    count_no = good.sum(axis=1) - count_yes
    top = (rank * yes).sum(axis=1) - count_yes * (count_yes - 1) / 2
    bottom = count_yes * count_no
    out = np.divide(top, bottom, out=np.full(len(rank), np.nan),
                    where=bottom > 0)
    return np.where((count_yes >= 3) & (count_no >= 3), out, np.nan)


def z_of(auc: np.ndarray, rank: np.ndarray, good: np.ndarray,
         label: np.ndarray) -> np.ndarray:
    """`z` до AUC: похибка при однакових боках — sqrt((n+m+1)/12nm)."""
    yes = good * (label == 1)
    count_yes = yes.sum(axis=1)
    count_no = good.sum(axis=1) - count_yes
    err = np.sqrt((count_yes + count_no + 1)
                  / np.maximum(12 * count_yes * count_no, 1))
    return np.divide(auc - 0.5, err, out=np.full(len(auc), np.nan),
                     where=err > 0)


def shuffle_null(stack: np.ndarray, label: np.ndarray,
                 shuffles: int = SHUFFLES, seed: int = SEED) -> dict:
    """Найбільший |z| перебору проти такого самого перебору на шумі.

    Перебір іде по 42 величинах × 3 кривих × 4 вікнах × 3 мірах, і при
    такій кількості комбінацій великий |z| зʼявляється сам собою. Мітку
    «півот / корекція» перемішують `shuffles` разів і щоразу беруть
    найбільший |z| усього перебору: так видно, з чим порівнювати
    справжній.
    """
    rank = np.zeros(stack.shape, dtype=float)
    good = np.zeros(stack.shape, dtype=bool)
    for number, row in enumerate(stack):
        rank[number], good[number] = ranked(row)
    seen = np.nanmax(np.abs(z_of(auc_of(rank, good, label), rank, good,
                                 label)))
    rng = np.random.default_rng(seed)
    tops = []
    for _ in range(shuffles):
        fake = rng.permutation(label)
        tops.append(float(np.nanmax(np.abs(
            z_of(auc_of(rank, good, fake), rank, good, fake)))))
    tops = np.array(tops)
    return {"combos": int(len(stack)), "shuffles": shuffles, "seed": seed,
            "max_z": round(float(seen), 3),
            "null_median": round(float(np.median(tops)), 3),
            "null_p95": round(float(np.quantile(tops, 0.95)), 3),
            "p_value": round(float((tops >= seen).mean()), 4)}


def depth_bins(rows: list) -> list:
    """Смуги глибини корекції: скільки їх і де межі."""
    depth = np.array([row["depth"] for row in rows if not row["pivot"]])
    out = []
    for low, high in DEPTH_BINS:
        picked = (depth >= low) & ((depth < high) if high else True)
        out.append({"from": low, "to": high, "count": int(picked.sum())})
    return out


def measure(data: dict, legs: list, curves: dict, small: float,
            part: str = "all", cut: float = 0.0) -> dict:
    """Один поріг вкладеного зігзага: кандидати, AUC і смуги глибини."""
    rows = candidates(data, legs, small)
    if part != "all":                      # кандидати тільки своєї частини
        when = data["t"][[row["index"] for row in rows]] if rows \
            else np.zeros(0)
        keep = when < cut if part == "train" else when >= cut
        rows = [row for row, take in zip(rows, keep) if take]
    label = np.array([row["pivot"] for row in rows])
    depth = np.array([row["depth"] for row in rows], dtype=float)
    if not rows or label.sum() < 3 or (label == 0).sum() < 3:
        return {"pivots": int(label.sum()) if rows else 0,
                "corrections": int((label == 0).sum()) if rows else 0,
                "ready": False}

    table, counts, stack, marks = {}, {}, [], []
    for name, curve in curves.items():
        column, curve_name = name.rsplit("|", 1)
        block = table.setdefault(column, {}).setdefault(curve_name, {})
        for size in WINDOWS:
            got = windows_of(curve, rows, size)
            block[str(size)] = {one: auc_block(got[one], label)
                                for one in MEASURES}
            for one in MEASURES:
                stack.append(got[one])
                marks.append({"column": column, "curve": curve_name,
                              "window": size, "measure": one})
            counts[str(size)] = {
                "pivots": int((got["ok"] & (label == 1)).sum()),
                "corrections": int((got["ok"] & (label == 0)).sum())}
    null = shuffle_null(np.array(stack), label)
    null["best"] = marks[int(np.nanargmax(np.abs([
        (block[str(mark["window"])][mark["measure"]]["z"] or 0)
        for mark, block in zip(marks, (table[mark["column"]][mark["curve"]]
                                       for mark in marks))])))]

    bins = depth_bins(rows)
    by_depth = []
    for number, (low, high) in enumerate(DEPTH_BINS):
        picked = np.array([
            bool(row["pivot"]) or (row["depth"] >= low
                                   and (row["depth"] < high if high else True))
            for row in rows])
        if (picked & (label == 0)).sum() < 3:
            by_depth.append({**bins[number], "ready": False})
            continue
        block = {}
        for name, curve in curves.items():
            column, curve_name = name.rsplit("|", 1)
            got = windows_of(curve, [row for row, take in zip(rows, picked)
                                     if take], DEFAULT_WINDOW)
            side = label[picked]
            block.setdefault(column, {})[curve_name] = {
                one: auc_block(got[one], side) for one in MEASURES}
        by_depth.append({**bins[number], "ready": True, "by_column": block})

    return {"ready": True,
            "pivots": int(label.sum()),
            "corrections": int((label == 0).sum()),
            "per_leg": round(float((label == 0).sum() / max(len(legs), 1)), 3),
            "depth": {"median": round(float(np.median(depth[label == 0])), 5),
                      "p25": round(float(np.quantile(depth[label == 0],
                                                     0.25)), 5),
                      "p75": round(float(np.quantile(depth[label == 0],
                                                     0.75)), 5),
                      "pivot_median": round(float(np.median(
                          depth[label == 1])), 5),
                      "bins": bins},
            "counts": counts, "null": null,
            "by_column": table, "by_depth": by_depth,
            "rows": [{"index": row["index"], "pivot": row["pivot"],
                      "leg": row["leg"], "kind": row["kind"],
                      "depth": round(row["depth"], 5)} for row in rows]}



def build(pair: str = PAIR, class_name: str = CLASS,
          smalls=SMALLS, root: Path | None = None,
          part: str = "all") -> dict:
    data = inleg.load(pair, class_name, root)
    cut = float(data.get("cut", 0))
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs
            if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True

    columns = inleg.columns_of(data)
    curves = {}
    for name, column in columns.items():
        for curve_name, curve in inleg.curves_of(column, inside).items():
            curves[f"{name}|{curve_name}"] = curve

    return {
        "script": "research/30-inleg-events/scripts/pivot_vs_correction.py",
        "pair": pair, "class": class_name, "part": part, "cut": int(cut),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "smalls": list(smalls), "default_small": DEFAULT_SMALL,
        "windows": list(WINDOWS), "default_window": DEFAULT_WINDOW,
        "gap": GAP, "measures": list(MEASURES),
        "hole_hours": inleg.HOLE / 3600,
        "curves": list(inleg.CURVES), "base": inleg.BASE,
        "normalise": "ранги серед подій ніг монети",
        "features": list(data["features"]), "reducers": list(inleg.REDUCERS),
        "columns": list(columns),
        "legs": len(legs), "events": int(inside.sum()),
        "by_small": {str(small): measure(data, legs, curves, small, part,
                                         cut)
                     for small in smalls},
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    """Короткий звіт у термінал."""
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, "
          f"{report['events']} подій у ногах; кандидати — півоти зігзага "
          f"{report['threshold'] * 100:.1f} % проти корекцій вкладеного "
          f"зігзага, відступ від країв ноги {report['gap']} подій")
    for small in report["smalls"]:
        block = report["by_small"][str(small)]
        if not block.get("ready"):
            print(f"\nвкладений {small * 100:.1f} %: замало кандидатів")
            continue
        depth = block["depth"]
        print(f"\nвкладений зігзаг {small * 100:.1f} %: "
              f"{block['pivots']} півотів проти {block['corrections']} "
              f"корекцій ({block['per_leg']} на ногу); глибина корекції "
              f"медіана {depth['median'] * 100:.2f} % "
              f"(25–75 %: {depth['p25'] * 100:.2f}–{depth['p75'] * 100:.2f}), "
              f"рух після справжнього півота "
              f"{depth['pivot_median'] * 100:.2f} %")
        counts = block["counts"][str(report["default_window"])]
        print(f"  вікно {report['default_window']} подій: "
              f"{counts['pivots']} півотів і {counts['corrections']} "
              f"корекцій з повним вікном")
        null = block["null"]
        print(f"  контроль: перебір {null['combos']} комбінацій, "
              f"найбільший |z| {null['max_z']:.1f}; на перемішаній мітці "
              f"({null['shuffles']} прогонів) медіана {null['null_median']:.1f}"
              f", 95 % {null['null_p95']:.1f} -> p = {null['p_value']:.3f}")
        for measure_name in MEASURES:
            rows = []
            for column, curves in block["by_column"].items():
                for curve, windows in curves.items():
                    for size, item in windows.items():
                        one = item[measure_name]
                        if one["z"] is not None:
                            rows.append((column, curve, size, one))
            rows.sort(key=lambda row: -abs(row[3]["z"]))
            title = {"before": "до кандидата (причинно)",
                     "after": "після кандидата",
                     "step": "різниця після мінус до"}[measure_name]
            print(f"  {title}:")
            for column, curve, size, one in rows[:5]:
                print(f"    {column:<26} {curve:<9} вікно {size:>2} "
                      f"AUC {one['auc']:.3f} z {one['z']:+.1f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, SMALLS, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"pivot_vs_correction_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_small"}
    meta["by_small"] = {
        key: {one: item for one, item in block.items()
              if one not in ("by_column", "by_depth", "rows")}
        for key, block in report["by_small"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False),
        encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
