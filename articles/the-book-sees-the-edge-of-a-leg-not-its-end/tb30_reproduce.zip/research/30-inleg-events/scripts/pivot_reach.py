"""Доки тягнеться півот: від нього в обидва боки до рівня ноги.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Етап 1 показав: краї ноги в цьому класі інші, ніж її середина. Тут
питання кількісне: **на скільки подій від півота тягнеться ця різниця**
і де фіча повертається до свого звичайного рівня в нозі.

Хід:

1. Кожна подія дає одне число на фічу — середнє по девʼяти блоках,
   переведене в ранг серед подій ніг монети.
2. Для кожної ноги рахується її **власний рівень** — середнє тих самих
   рангів по серединних десятинах (4–7). Це та межа, до якої фіча має
   «нормалізуватись».
3. Від кожного півота йдемо в обидва боки: `назад` — у ногу, що
   скінчилась (зсув 1 — сама подія півота), `вперед` — у ногу, що
   почалась (зсув 1 — перша подія нової ноги).
4. На кожному зсуві береться відхилення `рівень події − рівень її ноги`,
   усереднене по всіх півотах, і `t` = відхилення на похибку середнього.
5. **Довжина збурення** — перший зсув, від якого `RUN` зсувів підряд
   мають `|t| < LIMIT`. Далі фіча від рівня своєї ноги не відрізняється.

Розріз: усі півоти разом, окремо `high` (нога вгору скінчилась) і `low`.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/pivot_reach_<PAIR>_<клас>[_part].json
       results/pivot_reach_<PAIR>_<клас>[_part].meta.json

Запуск:
    python3 research/30-inleg-events/scripts/pivot_reach.py --part train
    python3 research/30-inleg-events/scripts/pivot_reach.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

REACH = 200          # скільки зсувів дивимось у кожен бік
LIMIT = 2.0          # |t|, нижче якого відхилення вважається зниклим
RUN = 10             # скільки зсувів підряд мають бути нижче межі
SIDES = ("back", "ahead")
CUTS = ("all", "high", "low")
MIDDLE = inleg.MIDDLE          # десятини, що дають рівень ноги


def event_levels(data: dict, inside: np.ndarray) -> np.ndarray:
    """Рівень кожної фічі на події: середнє по блоках у рангах монети."""
    out = np.zeros((len(data["t"]), data["x"].shape[2]), dtype=float)
    for number in range(data["x"].shape[2]):
        column = np.nanmean(data["x"][:, :, number], axis=1)
        out[:, number] = np.nan_to_num(inleg.ranks(column, inside) - 0.5,
                                       nan=0.0)
    return out


def leg_levels(level: np.ndarray, legs: list) -> np.ndarray:
    """Власний рівень ноги — середнє по її серединних десятинах."""
    out = np.zeros((len(legs), level.shape[1]), dtype=float)
    for number, leg in enumerate(legs):
        length = leg["last"] - leg["first"] + 1
        parts = np.minimum(
            np.floor(np.arange(length) / length * inleg.DECILES) + 1,
            inleg.DECILES).astype(int)
        picked = np.isin(parts, MIDDLE)
        out[number] = level[leg["first"]:leg["last"] + 1][picked].mean(axis=0)
    return out


def pivots_of(legs: list) -> list:
    """Півоти між сусідніми ногами, що йдуть без пропуску в ряді."""
    rows = []
    for number, (old, new) in enumerate(zip(legs, legs[1:])):
        if new["first"] != old["last"] + 1:
            continue
        rows.append({"index": old["last"], "old": number, "new": number + 1,
                     "kind": "high" if old["kind"] == "up" else "low"})
    return rows


def profile(level: np.ndarray, base: np.ndarray, legs: list, pivots: list,
            side: str, reach: int = REACH) -> dict:
    """Відхилення від рівня ноги на кожному зсуві від півота."""
    columns = [[[] for _ in range(reach)]
               for _ in range(level.shape[1])]
    for pivot in pivots:
        leg = legs[pivot["old"] if side == "back" else pivot["new"]]
        own = base[pivot["old"] if side == "back" else pivot["new"]]
        for step in range(reach):
            place = pivot["index"] - step if side == "back" \
                else pivot["index"] + 1 + step
            if place < leg["first"] or place > leg["last"]:
                break
            for number in range(level.shape[1]):
                columns[number][step].append(level[place, number] - own[number])
    out = []
    for number in range(level.shape[1]):
        mean, err, count = [], [], []
        for step in range(reach):
            piece = np.array(columns[number][step], dtype=float)
            if piece.size < 5:
                mean.append(None)
                err.append(None)
                count.append(int(piece.size))
                continue
            mean.append(round(float(piece.mean()), 5))
            err.append(round(float(piece.std(ddof=1) / np.sqrt(piece.size)),
                             5))
            count.append(int(piece.size))
        out.append({"mean": mean, "err": err, "count": count})
    return {"by_feature": out}


def settle(block: dict, limit: float = LIMIT, run: int = RUN) -> dict:
    """Перший зсув, від якого `run` зсувів підряд лежать нижче межі."""
    mean = block["mean"]
    err = block["err"]
    score = [None if one is None or two in (None, 0) else one / two
             for one, two in zip(mean, err)]
    good = [one is not None and abs(one) < limit for one in score]
    reach = None
    for start in range(len(good) - run + 1):
        if all(good[start:start + run]):
            reach = start + 1          # зсуви рахуються з одиниці
            break
    strong = [number + 1 for number, one in enumerate(score)
              if one is not None and abs(one) >= limit]
    return {"reach": reach,
            "t_first": round(float(score[0]), 3) if score and score[0]
            is not None else None,
            "last_strong": strong[-1] if strong else None,
            "steps_strong": len(strong),
            "t": [None if one is None else round(float(one), 3)
                  for one in score]}


def build(pair: str = PAIR, class_name: str = CLASS,
          root: Path | None = None, part: str = "train") -> dict:
    data = inleg.load(pair, class_name, root, part)
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True
    level = event_levels(data, inside)
    base = leg_levels(level, legs)
    pivots = pivots_of(legs)

    by_cut = {}
    for cut in CUTS:
        picked = [one for one in pivots
                  if cut == "all" or one["kind"] == cut]
        if len(picked) < 5:
            by_cut[cut] = {"ready": False, "pivots": len(picked)}
            continue
        block = {"ready": True, "pivots": len(picked)}
        for side in SIDES:
            got = profile(level, base, legs, picked, side)
            block[side] = {
                name: {**got["by_feature"][number],
                       **settle(got["by_feature"][number])}
                for number, name in enumerate(data["features"])}
        by_cut[cut] = block

    return {
        "script": "research/30-inleg-events/scripts/pivot_reach.py",
        "pair": pair, "class": class_name, "part": part,
        "cut": int(data.get("cut", 0)),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "reach": REACH, "limit": LIMIT, "run": RUN,
        "middle": list(MIDDLE), "sides": list(SIDES), "cuts": list(CUTS),
        "features": list(data["features"]),
        "legs": len(legs), "pivots": len(pivots),
        "events": int(inside.sum()),
        "by_cut": by_cut,
        "ready": bool(pivots),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, {report['pivots']} "
          f"півотів, {report['events']} подій у ногах")
    print(f"рівень ноги — середнє по десятинах "
          f"{'-'.join(str(one) for one in report['middle'])}; збурення "
          f"вважається зниклим, коли |t| < {report['limit']} на "
          f"{report['run']} зсувах підряд")
    titles = {"back": "назад, у ногу що скінчилась",
              "ahead": "вперед, у ногу що почалась"}
    for cut in report["cuts"]:
        block = report["by_cut"][cut]
        if not block.get("ready"):
            print(f"\nпівоти {cut}: замало")
            continue
        print(f"\nпівоти {cut} ({block['pivots']}):")
        for side in report["sides"]:
            print(f"  {titles[side]}:")
            for name in report["features"]:
                one = block[side][name]
                reach = one["reach"]
                print(f"    {name:<20} t на самому півоті "
                      f"{one['t_first']:+6.1f} · нормалізується через "
                      f"{'—' if reach is None else reach:>4} подій · "
                      f"останній сильний зсув "
                      f"{one['last_strong'] if one['last_strong'] else '—'}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="train", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"pivot_reach_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_cut"}
    meta["by_cut"] = {
        cut: {"ready": block.get("ready"), "pivots": block.get("pivots"),
              **{side: {name: {"reach": block[side][name]["reach"],
                               "t_first": block[side][name]["t_first"],
                               "last_strong":
                                   block[side][name]["last_strong"]}
                        for name in report["features"]}
                 for side in SIDES if block.get("ready")}}
        for cut, block in report["by_cut"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
