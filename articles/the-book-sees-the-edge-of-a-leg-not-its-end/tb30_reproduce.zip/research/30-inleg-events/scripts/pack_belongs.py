"""Чи належить пачка цій нозі: кожна пачка проти всіх пачок ноги.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/05-visualization.md

Етап 8 рівняв пари пачок на однаковій відстані. Тут питання поставлене
так, як його ставить сам ряд:

    є нога й усі її пачки. Береться ще одна пачка. Чи вона з цієї ноги?

Хід:

1. Ряд кожної ноги ріжеться на пачки по `N` подій підряд, без перекриття
   (крок = `N`). Пачка через півот не переходить.
2. Усередині ноги рахуються **всі пари пачок** — кожна з кожною.
3. Пачка порівнюється з ногою **без самої себе**: береться її відстань
   до кожної пачки ноги, з них — медіана, найближча, чверть і середня.
4. Ті самі числа рахуються для пачок **наступної ноги** і, окремо, для
   пачок **далекої ноги** (не сусідньої) — це контроль: якщо сусідня
   нога відрізняється не більше за випадкову, справа не в півоті.

| хто | що рахується |
| --- | ------------ |
| `своя` | пачка ноги проти решти пачок цієї самої ноги |
| `наступна` | пачка наступної ноги проти всіх пачок цієї |
| `далека` | пачка випадкової несусідньої ноги проти всіх пачок цієї |

Числа пачки — сирі числа класу (`N × 9 блоків × 7 фіч`) і ті самі числа
в рангах події. Відстань — `cosine`, `euclidean`, `manhattan`.

Модель. Те саме питання, але вчене: на вхід ідуть **усі відстані пачки
до ноги** (по чотири згортки на кожну з шести пар «числа × метрика» —
24 колонки), відповідь — своя пачка чи чужа. Розбиття за часом: перші
70 % ніг учать, останні відповідають. Ця модель і є тим, що просили —
вона отримує пачку, порівнює її з усією ногою й каже, чи пачка звідти.

Контроль часом. «Своя нога» — це ще й «поруч у часі»: пачка сусідньої
ноги завжди далі від ноги, ніж її власна, і сама по собі відстань може
бути просто дрейфом ряду. Тому поруч іде **замір з рівною часовою
відстанню**:

    опора    `W` пачок підряд
    кандидат наступна пачка одразу за опорою

і питання — чи далі кандидат від опори, коли між ними лежить **півот**,
ніж коли той самий кандидат іде всередині ноги. Часова відстань у обох
випадках однакова за побудовою, тому дрейф з відповіді зникає.

Контроль перемішуванням — як в інших етапах: мітку перемішують і щоразу
беруть найбільший \\|z\\| усього перебору.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/pack_belongs_<PAIR>_<клас>.json
       results/pack_belongs_<PAIR>_<клас>.meta.json

Запуск:
    python3 research/30-inleg-events/scripts/pack_belongs.py
    python3 research/30-inleg-events/scripts/pack_belongs.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pack_similarity as similarity  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

PACKS = (10, 20, 30)
DEFAULT_PACK = 20
METRICS = similarity.METRICS
VARIANTS = similarity.VARIANTS
AGGREGATES = ("median", "min", "q25", "mean")
SOURCES = ("own", "next", "far")
FAR_LEGS = 2            # скільки далеких ніг береться на кожну ногу
REFERENCE = 5           # скільки пачок в опорі заміру з рівним часом
MIN_PACKS = 4           # нога з меншою кількістю пачок у замір не йде
TRAIN_SHARE = 0.7
SHUFFLES = 300
SEED = 17
MODEL = {"max_iter": 200, "learning_rate": 0.05, "max_leaf_nodes": 7,
         "min_samples_leaf": 20, "l2_regularization": 1.0}


def pairwise(left: np.ndarray, right: np.ndarray, metric: str) -> np.ndarray:
    """Матриця відстаней: кожен рядок `left` до кожного рядка `right`."""
    left = np.nan_to_num(left, nan=0.0, posinf=0.0, neginf=0.0)
    right = np.nan_to_num(right, nan=0.0, posinf=0.0, neginf=0.0)
    if metric == "cosine":
        top = left @ right.T
        bottom = (np.sqrt((left ** 2).sum(axis=1))[:, None]
                  * np.sqrt((right ** 2).sum(axis=1))[None, :])
        return 1 - np.divide(top, bottom, out=np.zeros_like(top),
                             where=bottom > 0)
    if metric == "euclidean":
        far = ((left ** 2).sum(axis=1)[:, None]
               + (right ** 2).sum(axis=1)[None, :] - 2 * (left @ right.T))
        return np.sqrt(np.maximum(far, 0))
    if metric == "manhattan":
        return np.abs(left[:, None, :] - right[None, :, :]).sum(axis=2)
    raise ValueError(f"невідома метрика: {metric}")


def fold(far: np.ndarray) -> dict:
    """Згортки відстані пачки до ноги: медіана, найближча, чверть, середня."""
    return {"median": np.median(far, axis=1), "min": far.min(axis=1),
            "q25": np.quantile(far, 0.25, axis=1), "mean": far.mean(axis=1)}


def rows_of(values: dict, packs: dict, legs: list, seed: int = SEED) -> dict:
    """Відстані кожної пачки до ноги: своя, наступна і далека."""
    rng = np.random.default_rng(seed)
    places = [np.flatnonzero(packs["leg"] == number)
              for number in range(len(legs))]
    columns, label, owner, when, source = [], [], [], [], []
    for number, own in enumerate(places):
        if own.size < MIN_PACKS:
            continue
        others = [one for one in range(len(legs))
                  if abs(one - number) > 1 and places[one].size >= MIN_PACKS]
        pick = rng.choice(others, size=min(FAR_LEGS, len(others)),
                          replace=False) if others else []
        groups = {"own": own}
        if number + 1 < len(places) and places[number + 1].size:
            groups["next"] = places[number + 1]
        if len(pick):
            groups["far"] = np.concatenate([places[one] for one in pick])
        for kind, index in groups.items():
            table = {}
            for variant in VARIANTS:
                block = values[variant]
                for metric in METRICS:
                    far = pairwise(block[index], block[own], metric)
                    if kind == "own":       # себе з себе не рахуємо
                        far = far.copy()
                        far[np.arange(len(index)), np.arange(len(index))] \
                            = np.nan
                        far = np.sort(far, axis=1)[:, :-1]
                    for name, value in fold(far).items():
                        table[f"{variant}|{metric}|{name}"] = value
            keys = sorted(table)
            columns.append(np.stack([table[key] for key in keys], axis=1))
            label.extend([1 if kind == "own" else 0] * len(index))
            owner.extend([number] * len(index))
            when.extend([legs[number]["to"]] * len(index))
            source.extend([kind] * len(index))
    if not columns:
        return {"x": np.zeros((0, 0)), "names": []}
    return {"x": np.concatenate(columns, axis=0),
            "names": sorted(f"{variant}|{metric}|{name}"
                            for variant in VARIANTS for metric in METRICS
                            for name in AGGREGATES),
            "y": np.array(label), "leg": np.array(owner),
            "t": np.array(when, dtype=float),
            "source": np.array(source)}


def matched_rows(values: dict, packs: dict, legs: list) -> dict:
    """Замір з рівною часовою відстанню: опора й наступна за нею пачка.

    Кандидат завжди стоїть одразу за опорою — і коли між ними півот, і
    коли ні. Лишається тільки питання про півот.
    """
    places = [np.flatnonzero(packs["leg"] == number)
              for number in range(len(legs))]
    columns, label, when = [], [], []
    for number, own in enumerate(places):
        if own.size < REFERENCE + 1:
            continue
        cases = []
        for start in range(own.size - REFERENCE):
            base = own[start:start + REFERENCE]
            cases.append((base, own[start + REFERENCE], 0))
        if number + 1 < len(places) and places[number + 1].size:
            cases.append((own[-REFERENCE:], places[number + 1][0], 1))
        for base, candidate, mark in cases:
            table = {}
            for variant in VARIANTS:
                block = values[variant]
                for metric in METRICS:
                    far = pairwise(block[candidate][None, :], block[base],
                                   metric)
                    for name, value in fold(far).items():
                        table[f"{variant}|{metric}|{name}"] = float(value[0])
            keys = sorted(table)
            columns.append([table[key] for key in keys])
            label.append(mark)
            when.append(legs[number]["to"])
    if not columns:
        return {"x": np.zeros((0, 0)), "names": []}
    return {"x": np.array(columns, dtype=float),
            "names": sorted(f"{variant}|{metric}|{name}"
                            for variant in VARIANTS for metric in METRICS
                            for name in AGGREGATES),
            "y": np.array(label), "t": np.array(when, dtype=float)}


def part_mask(when: np.ndarray, part: str, cut: float) -> np.ndarray:
    """Які рядки міряються: увесь ряд, тільки train або тільки val."""
    if part == "train":
        return when < cut
    if part == "val":
        return when >= cut
    return np.ones(len(when), dtype=bool)


def matched_block(values: dict, packs: dict, legs: list, part: str = "all",
                  cut: float = 0.0) -> dict:
    """AUC, контроль і модель на замірі з рівною часовою відстанню."""
    rows = matched_rows(values, packs, legs)
    if rows["x"].size == 0 or rows["y"].sum() < 10:
        return {"ready": False}
    keep = part_mask(rows["t"], part, cut)
    if int(rows["y"][keep].sum()) < 5:
        return {"ready": False, "across": int(rows["y"][keep].sum())}
    table, stack, marks = {}, [], []
    for number, name in enumerate(rows["names"]):
        variant, metric, aggregate = name.split("|")
        column = np.where(keep, rows["x"][:, number], np.nan)
        got = control.auc_block(column, rows["y"])
        table.setdefault(variant, {}).setdefault(metric, {})[aggregate] = {
            **got,
            "across_median": round(float(np.nanmedian(
                column[rows["y"] == 1])), 6),
            "within_median": round(float(np.nanmedian(
                column[rows["y"] == 0])), 6)}
        stack.append(column[keep])
        marks.append({"variant": variant, "metric": metric,
                      "aggregate": aggregate})
    null = control.shuffle_null(np.array(stack), rows["y"][keep],
                                shuffles=SHUFFLES, seed=SEED)
    seen = [(abs(table[one["variant"]][one["metric"]][one["aggregate"]]["z"]
                 or 0), one) for one in marks]
    null["best"] = max(seen, key=lambda one: one[0])[1]
    return {"ready": True, "reference": REFERENCE,
            "across": int(rows["y"][keep].sum()),
            "within": int((rows["y"][keep] == 0).sum()),
            "by_variant": table, "null": null,
            # мітка моделі скрізь однакова: 1 — пачка своя, 0 — чужа,
            # тому тут вона перевертається (у замірі 1 — через півот)
            "model": model_run({"x": rows["x"], "y": 1 - rows["y"],
                                "t": rows["t"],
                                "source": np.where(rows["y"] == 1, "next",
                                                   "own")},
                               cut if part == "val" else None)}


def model_run(rows: dict, line: float | None = None) -> dict:
    """Модель «чи пачка з цієї ноги»: вхід — відстані до всієї ноги."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    picked = np.isin(rows["source"], ("own", "next"))
    x, label, when = rows["x"][picked], rows["y"][picked], rows["t"][picked]
    label = np.asarray(label)
    if label.size < 40 or len(np.unique(label)) < 2:
        return {"ready": False, "packs": int(label.size)}
    line = float(np.quantile(when, TRAIN_SHARE)) if line is None \
        else float(line)
    train, test = when < line, when >= line
    if min(int(train.sum()), int(test.sum())) < 20 \
            or len(np.unique(label[test])) < 2 \
            or len(np.unique(label[train])) < 2:
        return {"ready": False, "packs": int(label.size)}
    clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    model = HistGradientBoostingClassifier(random_state=SEED, **MODEL)
    model.fit(clean[train], label[train])
    said = model.predict_proba(clean[test])[:, 1]
    truth = label[test]
    value = inleg.auc(said[truth == 1], said[truth == 0])
    yes, no = int((truth == 1).sum()), int((truth == 0).sum())
    err = float(np.sqrt((yes + no + 1) / (12 * max(yes * no, 1))))
    # верхівка видачі: коли боки нерівні, влучність нічого не каже
    order = np.argsort(said)                 # найтихіші — найбільш «чужі»
    top = order[:no]
    hits = np.flatnonzero(truth[order] == 0)
    return {"ready": True, "auc": round(float(value), 5),
            "z": round(float((value - 0.5) / err), 3) if err else None,
            "hit": round(float(((said >= 0.5).astype(int) == truth).mean()),
                         5),
            "base": round(float(max(truth.mean(), 1 - truth.mean())), 5),
            "precision": round(float((truth[top] == 0).mean()), 5),
            "share": round(float((truth == 0).mean()), 5),
            "first_hit": int(hits[0] + 1) if hits.size else None,
            "train_packs": int(train.sum()), "test_packs": int(test.sum()),
            "test_own": yes, "test_next": no}


def pack_block(data: dict, legs: list, size: int, part: str = "all",
               cut: float = 0.0) -> dict:
    """Одна довжина пачки: всі пари, три джерела, контроль і модель."""
    packs = similarity.cut(legs, size)
    if packs["start"].size < 20:
        return {"pack": size, "ready": False,
                "packs": int(packs["start"].size)}
    values = {"raw": similarity.vectors(data["x"], packs["start"], size),
              "rank": similarity.vectors(data["rank"], packs["start"], size)}
    rows = rows_of(values, packs, legs)
    if rows["x"].size == 0:
        return {"pack": size, "ready": False, "packs": 0}

    keep = part_mask(rows["t"], part, cut)
    counts = {kind: int(((rows["source"] == kind) & keep).sum())
              for kind in SOURCES}
    if min(counts["own"], counts["next"]) < 10:
        return {"pack": size, "ready": False, "packs": counts["own"]}
    table, stack, marks = {}, [], []
    for number, name in enumerate(rows["names"]):
        variant, metric, aggregate = name.split("|")
        column = np.where(keep, rows["x"][:, number], np.nan)
        block = table.setdefault(variant, {}).setdefault(metric, {})
        item = {}
        for kind in SOURCES:
            piece = column[(rows["source"] == kind) & keep]
            item[f"{kind}_median"] = round(float(np.nanmedian(piece)), 6) \
                if piece.size else None
        for against in ("next", "far"):
            picked = np.isin(rows["source"], ("own", against))
            item[against] = control.auc_block(
                np.where(picked, column, np.nan), rows["y"])
        # чи відрізняється сусідня нога від далекої взагалі
        picked = np.isin(rows["source"], ("next", "far"))
        item["next_vs_far"] = control.auc_block(
            np.where(picked, column, np.nan),
            (rows["source"] == "next").astype(int))
        block[aggregate] = item
        if aggregate in AGGREGATES:
            both = np.isin(rows["source"], ("own", "next")) & keep
            stack.append(rows["x"][both, number])
            marks.append({"variant": variant, "metric": metric,
                          "aggregate": aggregate})
    both = np.isin(rows["source"], ("own", "next")) & keep
    null = control.shuffle_null(np.array(stack), rows["y"][both],
                                shuffles=SHUFFLES, seed=SEED)
    seen = [(abs(table[one["variant"]][one["metric"]][one["aggregate"]]
                 ["next"]["z"] or 0), one) for one in marks]
    null["best"] = max(seen, key=lambda one: one[0])[1]

    return {"pack": size, "ready": True,
            "packs": int(packs["start"].size),
            "legs": int(len(np.unique(rows["leg"]))),
            "columns": int(size * data["x"].shape[1] * data["x"].shape[2]),
            "counts": counts, "by_variant": table, "null": null,
            "model": model_run(rows, cut if part == "val" else None),
            "matched": matched_block(values, packs, legs, part, cut)}


def build(pair: str = PAIR, class_name: str = CLASS, packs=PACKS,
          root: Path | None = None, part: str = "all") -> dict:
    data = inleg.load(pair, class_name, root)
    cut = float(data.get("cut", 0))
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True
    data["rank"] = similarity.ranked_events(data["x"], inside)

    by_pack = {str(size): pack_block(data, legs, size, part, cut)
               for size in packs}
    best = None
    for size in packs:
        block = by_pack[str(size)]
        if not block.get("ready"):
            continue
        for variant in VARIANTS:
            for metric in METRICS:
                for aggregate in AGGREGATES:
                    item = block["by_variant"][variant][metric][aggregate]
                    if item["next"]["auc"] is None:
                        continue
                    mark = {"pack": size, "variant": variant,
                            "metric": metric, "aggregate": aggregate,
                            **item["next"]}
                    if best is None or abs(mark["z"]) > abs(best["z"]):
                        best = mark
    return {
        "script": "research/30-inleg-events/scripts/pack_belongs.py",
        "pair": pair, "class": class_name, "part": part, "cut": int(cut),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "packs": list(packs), "default_pack": DEFAULT_PACK,
        "metrics": list(METRICS), "variants": list(VARIANTS),
        "aggregates": list(AGGREGATES), "sources": list(SOURCES),
        "far_legs": FAR_LEGS, "min_packs": MIN_PACKS,
        "train_share": TRAIN_SHARE, "shuffles": SHUFFLES, "seed": SEED,
        "model_kind": "HistGradientBoostingClassifier", "model": MODEL,
        "features": list(data["features"]),
        "blocks": int(data["x"].shape[1]),
        "legs": len(legs), "events": int(inside.sum()),
        "by_pack": by_pack, "optimal": best,
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина ряду "
          f"{report['part']}: {report['legs']} ніг, "
          f"{report['events']} подій у ногах")
    print("пачка проти всіх пачок своєї ноги; порівняння — пачки наступної "
          "ноги, контроль — пачки далекої ноги")
    for size in report["packs"]:
        block = report["by_pack"][str(size)]
        if not block.get("ready"):
            print(f"\nпачка {size} подій: замало пачок")
            continue
        counts = block["counts"]
        print(f"\nпачка {size} подій: {block['packs']} пачок, "
              f"{block['legs']} ніг, {block['columns']} чисел у пачці; "
              f"своїх {counts['own']}, наступних {counts['next']}, "
              f"далеких {counts['far']}")
        null = block["null"]
        print(f"  контроль: {null['combos']} комбінацій, найбільший |z| "
              f"{null['max_z']:.1f}; на перемішаній мітці медіана "
              f"{null['null_median']:.1f}, 95 % {null['null_p95']:.1f} "
              f"-> p = {null['p_value']:.3f}")
        rows = []
        for variant in VARIANTS:
            for metric in METRICS:
                for aggregate in AGGREGATES:
                    item = block["by_variant"][variant][metric][aggregate]
                    if item["next"]["z"] is None:
                        continue
                    rows.append((abs(item["next"]["z"]), variant, metric,
                                 aggregate, item))
        rows.sort(reverse=True, key=lambda one: one[0])
        print("  найсильніші згортки (AUC своя проти наступної · проти "
              "далекої · наступна проти далекої):")
        for _, variant, metric, aggregate, item in rows[:5]:
            print(f"    {variant:<5} {metric:<10} {aggregate:<7} "
                  f"{item['next']['auc']:.3f} (z {item['next']['z']:+.1f}) · "
                  f"{item['far']['auc']:.3f} · "
                  f"{item['next_vs_far']['auc']:.3f}")
        model = block["model"]
        if model.get("ready"):
            print(f"  модель «чи пачка з цієї ноги»: AUC {model['auc']:.3f} "
                  f"(z {model['z']:+.1f}), влучність "
                  f"{model['hit'] * 100:.1f} % проти {model['base'] * 100:.1f}"
                  f" % базових, точність верхівки "
                  f"{model['precision'] * 100:.1f} %, тест "
                  f"{model['test_own']} своїх і {model['test_next']} чужих")
        else:
            print("  модель: замало пачок")
        matched = block.get("matched", {})
        if matched.get("ready"):
            null = matched["null"]
            rows = []
            for variant in VARIANTS:
                for metric in METRICS:
                    for aggregate in AGGREGATES:
                        item = matched["by_variant"][variant][metric][
                            aggregate]
                        if item["z"] is None:
                            continue
                        rows.append((abs(item["z"]), variant, metric,
                                     aggregate, item))
            rows.sort(reverse=True, key=lambda one: one[0])
            print(f"  рівний час (опора {matched['reference']} пачок, "
                  f"кандидат — наступна): {matched['across']} через півот "
                  f"проти {matched['within']} усередині ноги")
            for _, variant, metric, aggregate, item in rows[:3]:
                print(f"    {variant:<5} {metric:<10} {aggregate:<7} "
                      f"AUC {item['auc']:.3f} (z {item['z']:+.1f})")
            print(f"    контроль: найбільший |z| {null['max_z']:.1f}, "
                  f"шум медіана {null['null_median']:.1f}, 95 % "
                  f"{null['null_p95']:.1f} -> p = {null['p_value']:.3f}")
            model = matched["model"]
            if model.get("ready"):
                print(f"    модель: AUC {model['auc']:.3f} "
                      f"(z {model['z']:+.1f}), точність верхівки "
                      f"{model['precision'] * 100:.1f} % проти "
                      f"{model['share'] * 100:.1f} % базових, перший "
                      f"чужий {model['first_hit']}")
            else:
                print("    модель: замало пачок")

    best = report["optimal"]
    if best:
        print(f"\nнайкраще в переборі: пачка {best['pack']} подій, "
              f"{best['variant']}, {best['metric']}, {best['aggregate']}: "
              f"AUC {best['auc']:.3f}, z {best['z']:+.1f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="all", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, PACKS, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"pack_belongs_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "by_pack"}
    meta["by_pack"] = {
        key: {one: item for one, item in block.items() if one != "by_variant"}
        for key, block in report["by_pack"].items()}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
