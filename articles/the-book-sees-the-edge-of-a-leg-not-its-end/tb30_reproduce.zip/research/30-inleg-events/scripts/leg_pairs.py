"""Сусідні ноги одного напрямку: чи схожий у них середній клас.

Дослідження: research/30-inleg-events/
Правила: rules/01-data-and-db.md → Класи (події), rules/02-markup.md

Кожна нога описується **середнім класом** — сім чисел, по одному на
фічу: середнє її подій (кожна подія — середнє по девʼяти блоках,
у рангах серед подій ніг монети).

Питання: якщо взяти ноги **одного напрямку** попарно — попередню й
поточну — наскільки різний у них середній клас?

| пара | що це |
| ---- | ----- |
| `сусідні` | попередня нога того самого напрямку і поточна |
| `випадкові` | дві ноги того самого напрямку, взяті навмання (контроль) |

Контроль обовʼязковий: сусідні ноги стоять поруч у часі, тому бути
схожими вони можуть просто через це. Якщо випадкова пара відрізняється
так само, «сусідство» нічого не означає.

Що рахується на кожній фічі:

- медіана `|поточна − попередня|` у рангах — наскільки різні;
- та сама медіана у **частках розкиду** по всіх ногах: 1.0 означає, що
  сусідні ноги різняться так само, як будь-які дві;
- Спірмен між рівнем попередньої і поточної ноги по всіх парах;
- AUC «сусідня пара ближча за випадкову» на повному векторі з семи
  чисел, три метрики.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_pairs_<PAIR>_<клас>[_part].json
       results/leg_pairs_<PAIR>_<клас>[_part].meta.json

Запуск:
    python3 research/30-inleg-events/scripts/leg_pairs.py --part train
    python3 research/30-inleg-events/scripts/leg_pairs.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS_DIR.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import inleg_profile as inleg  # noqa: E402
import pack_similarity as similarity  # noqa: E402
import pivot_reach as reach  # noqa: E402
import pivot_vs_correction as control  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = inleg.CLASS
PAIR = inleg.PAIR

KINDS = ("up", "down")
METRICS = similarity.METRICS
SHUFFLES = 300
DRAWS = 200            # скільки випадкових пар береться на контроль
GAPS = (1, 2, 3, 4, 5, 6, 8, 10)   # через скільки ніг узята пара
SEED = 17


def leg_class(level: np.ndarray, legs: list) -> np.ndarray:
    """Середній клас ноги: сім чисел, по одному на фічу."""
    return np.array([level[leg["first"]:leg["last"] + 1].mean(axis=0)
                     for leg in legs], dtype=float)


def pairs_of(legs: list, kind: str) -> list:
    """Сусідні ноги одного напрямку: (попередня, поточна)."""
    order = [number for number, leg in enumerate(legs)
             if leg["kind"] == kind]
    return [(left, right) for left, right in zip(order, order[1:])]


def random_pairs(legs: list, kind: str, count: int = DRAWS,
                 seed: int = SEED) -> list:
    """Випадкові пари того самого напрямку — контроль на сусідство."""
    order = [number for number, leg in enumerate(legs)
             if leg["kind"] == kind]
    if len(order) < 4:
        return []
    rng = np.random.default_rng(seed)
    out = []
    while len(out) < count:
        left, right = rng.choice(order, size=2, replace=False)
        if abs(order.index(int(left)) - order.index(int(right))) == 1:
            continue                      # сусідів у контроль не беремо
        out.append((int(left), int(right)))
    return out


def spread_of(table: np.ndarray, kind_index: np.ndarray) -> np.ndarray:
    """Розкид середнього класу по всіх ногах цього напрямку."""
    return table[kind_index].std(axis=0, ddof=1)


def by_feature(table: np.ndarray, pairs: list, other: list,
               spread: np.ndarray, features: list) -> list:
    """Наскільки різняться фічі в парі — і як це проти контролю."""
    from scipy.stats import spearmanr

    near = np.array([table[right] - table[left] for left, right in pairs])
    away = np.array([table[right] - table[left] for left, right in other]) \
        if other else np.zeros((0, table.shape[1]))
    out = []
    for number, name in enumerate(features):
        left = np.array([table[one][number] for one, _ in pairs])
        right = np.array([table[two][number] for _, two in pairs])
        gap = float(np.median(np.abs(near[:, number])))
        wide = float(np.median(np.abs(away[:, number]))) if away.size else None
        out.append({
            "feature": name,
            "gap": round(gap, 5),
            "random_gap": round(wide, 5) if wide is not None else None,
            "share": round(gap / spread[number], 4) if spread[number] else None,
            "spearman": round(float(spearmanr(left, right).statistic), 5)
            if len(pairs) > 3 else None,
            "auc": control.auc_block(
                np.concatenate([np.abs(near[:, number]),
                                np.abs(away[:, number])]),
                np.concatenate([np.ones(len(near)), np.zeros(len(away))]))
            if away.size else None})
    return out


def by_metric(table: np.ndarray, pairs: list, other: list) -> dict:
    """Відстань між середніми класами пари проти випадкової пари."""
    out = {}
    for metric in METRICS:
        near = np.array([similarity.distance(table[left][None, :],
                                             table[right][None, :],
                                             metric)[0]
                         for left, right in pairs])
        away = np.array([similarity.distance(table[left][None, :],
                                             table[right][None, :],
                                             metric)[0]
                         for left, right in other]) if other \
            else np.zeros(0)
        if not away.size:
            out[metric] = {"ready": False}
            continue
        out[metric] = {
            "ready": True,
            "near": round(float(np.median(near)), 5),
            "random": round(float(np.median(away)), 5),
            **control.auc_block(np.concatenate([near, away]),
                                np.concatenate([np.ones(len(near)),
                                                np.zeros(len(away))]))}
    return out


def gap_pairs(legs: list, kind: str, gap: int) -> list:
    """Пари ніг одного напрямку через `gap` кроків у їхньому переліку."""
    order = [number for number, leg in enumerate(legs)
             if leg["kind"] == kind]
    return [(order[i], order[i + gap]) for i in range(len(order) - gap)]


def by_gap(table: np.ndarray, legs: list, kind: str) -> list:
    """Схожість пари залежно від того, через скільки ніг вона взята.

    Сусідні ноги стоять поруч і в часі, тому самі по собі можуть бути
    схожими через дрейф ряду. Якщо схожість спадає з кроком плавно —
    це дрейф; якщо крок 1 стоїть окремо від решти — справа в сусідстві.
    """
    out = []
    for gap in GAPS:
        pairs = gap_pairs(legs, kind, gap)
        if len(pairs) < 4:
            out.append({"gap": gap, "pairs": len(pairs), "ready": False})
            continue
        far = {metric: float(np.median([
            similarity.distance(table[left][None, :], table[right][None, :],
                                metric)[0]
            for left, right in pairs])) for metric in METRICS}
        level = float(np.median([
            np.abs(table[right] - table[left]).mean()
            for left, right in pairs]))
        out.append({"gap": gap, "pairs": len(pairs), "ready": True,
                    "level": round(level, 5),
                    **{metric: round(value, 5)
                       for metric, value in far.items()}})
    return out


def kind_block(table: np.ndarray, legs: list, kind: str,
               features: list) -> dict:
    """Один напрямок: пари, контроль і числа на кожній фічі."""
    pairs = pairs_of(legs, kind)
    other = random_pairs(legs, kind)
    picked = np.array([number for number, leg in enumerate(legs)
                       if leg["kind"] == kind])
    if len(pairs) < 4 or picked.size < 4:
        return {"ready": False, "pairs": len(pairs)}
    spread = spread_of(table, picked)
    rows = by_feature(table, pairs, other, spread, features)
    stack = np.array([np.concatenate([
        np.abs([table[right][number] - table[left][number]
                for left, right in pairs]),
        np.abs([table[right][number] - table[left][number]
                for left, right in other])])
        for number in range(table.shape[1])])
    label = np.concatenate([np.ones(len(pairs)), np.zeros(len(other))])
    null = control.shuffle_null(stack, label, shuffles=SHUFFLES, seed=SEED)
    null["best"] = {"feature": max(
        rows, key=lambda one: abs((one["auc"] or {}).get("z") or 0))[
            "feature"]}
    return {"ready": True, "legs": int(picked.size), "pairs": len(pairs),
            "random": len(other),
            "spread": [round(float(one), 5) for one in spread],
            "by_feature": rows, "by_metric": by_metric(table, pairs, other),
            "by_gap": by_gap(table, legs, kind), "null": null}


def build(pair: str = PAIR, class_name: str = CLASS,
          root: Path | None = None, part: str = "train") -> dict:
    data = inleg.load(pair, class_name, root, part)
    _, all_legs = inleg.legs_of(data)
    legs = [leg for leg in all_legs if leg["hole_hours"] * 3600 <= inleg.HOLE]
    inside = np.zeros(len(data["t"]), dtype=bool)
    for leg in legs:
        inside[leg["first"]:leg["last"] + 1] = True
    level = reach.event_levels(data, inside)
    table = leg_class(level, legs)
    return {
        "script": "research/30-inleg-events/scripts/leg_pairs.py",
        "pair": pair, "class": class_name, "part": part,
        "cut": int(data.get("cut", 0)),
        "threshold": inleg.THRESHOLD, "period": inleg.PERIOD,
        "hole_hours": inleg.HOLE / 3600,
        "kinds": list(KINDS), "metrics": list(METRICS),
        "draws": DRAWS, "shuffles": SHUFFLES, "seed": SEED,
        "features": list(data["features"]),
        "legs": len(legs), "events": int(inside.sum()),
        "by_kind": {kind: kind_block(table, legs, kind, data["features"])
                    for kind in KINDS},
        "ready": bool(legs),
    }


def show(report: dict) -> None:
    print(f"{report['pair']}, клас {report['class']}, частина "
          f"{report['part']}: {report['legs']} ніг, {report['events']} "
          f"подій у ногах")
    print("середній клас ноги — сім чисел у рангах; пара — попередня нога "
          "того самого напрямку і поточна")
    for kind in report["kinds"]:
        block = report["by_kind"][kind]
        if not block.get("ready"):
            print(f"\nноги {kind}: замало пар")
            continue
        print(f"\nноги {kind}: {block['legs']} ніг, {block['pairs']} "
              f"сусідніх пар проти {block['random']} випадкових")
        print(f"  {'фіча':<20} {'|різниця|':>10} {'випадкова':>10} "
              f"{'частка розкиду':>15} {'Спірмен':>9} {'AUC':>7} {'z':>6}")
        for one in block["by_feature"]:
            auc = one["auc"] or {}
            print(f"  {one['feature']:<20} {one['gap']:>10.4f} "
                  f"{one['random_gap']:>10.4f} {one['share']:>15.2f} "
                  f"{one['spearman']:>+9.3f} "
                  f"{auc.get('auc', float('nan')):>7.3f} "
                  f"{auc.get('z', float('nan')):>+6.1f}")
        print("  відстань між середніми класами пари (сусідня / випадкова, "
              "AUC):")
        for metric, one in block["by_metric"].items():
            if not one.get("ready"):
                continue
            print(f"    {metric:<10} {one['near']:.4f} / {one['random']:.4f} "
                  f"AUC {one['auc']:.3f} (z {one['z']:+.1f})")
        print("  схожість за кроком між ногами (медіана; крок 1 — сусідні):")
        print(f"    {'крок':>5} {'пар':>5} {'рівень':>9} "
              + " ".join(f"{metric:>11}" for metric in METRICS))
        for one in block["by_gap"]:
            if not one.get("ready"):
                continue
            print(f"    {one['gap']:>5} {one['pairs']:>5} "
                  f"{one['level']:>9.4f} "
                  + " ".join(f"{one[metric]:>11.4f}" for metric in METRICS))
        null = block["null"]
        print(f"  контроль: {null['combos']} фіч, найбільший |z| "
              f"{null['max_z']:.1f}; шум медіана {null['null_median']:.1f}, "
              f"95 % {null['null_p95']:.1f} -> p = {null['p_value']:.3f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--part", default="train", choices=inleg.PARTS)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.class_name, args.data, args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"leg_pairs_{args.pair}_{args.class_name}"
    if args.part != "all":
        name += f"_{args.part}"
    (args.out / f"{name}.json").write_text(
        json.dumps(inleg.strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(inleg.strict(report), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
