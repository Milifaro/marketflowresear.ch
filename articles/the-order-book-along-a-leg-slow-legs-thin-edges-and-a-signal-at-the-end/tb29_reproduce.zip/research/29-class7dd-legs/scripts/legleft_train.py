"""Мережа з памʼяттю: скільки подій до кінця ноги, на кожній події.

Дослідження: research/29-class7dd-legs/
Правила: rules/03-models.md → Правила навчання

Етап 3 брав голову ноги — `K` перших подій — і питав про всю ногу одним
числом; модель там дерева. Тут те саме питання ставиться **послідовно**:
події подаються одна за одною, і на кожній мережа каже, скільки їх
лишилось до півота. Памʼять несе всю ногу, тому з кожним кроком модель
знає більше, а не менше.

    вхід  (B, L, C)  ->  LSTM(C -> hidden)   памʼять ноги, паддинг не заходить
          (B, L, h)  ->  причинна увага      крок t бачить кроки 1 … t
          (B, L, 2h) ->  Linear -> 1         `log1p(подій до кінця)`

Мережа та сама, що в дослідженні 19 (`leg_end_net.LegEnd`), з одним
виходом: там він був логітом, тут — числом. Паддинг замаскований, ціль
стоїть тільки на подіях своєї ноги.

## Чотири функції втрат

Міряємо ми **медіанну похибку в подіях**, і не всяка втрата про це
просить. `log1p` стискає хвіст: промах на 10 подіях у кінці ноги коштує
стільки ж, скільки промах на 300 на її початку, — і мережа чесно віддає
початок ноги. Тому втрата — ключ `--loss`:

    huber   Хубер на log1p(left) — стиснута шкала, дрібні числа дорожчі
    mae     L1 на log1p — та сама шкала, але це просить медіану, а не
            середнє: рівно те, чим ми потім міряємо
    events  Хубер на самому числі подій, поділеному на MEASURE — шкала
            подій, тобто прямо та, у якій рахується похибка
    wmse    ваговий MSE з `rules/03-models.md`: `w = 1 + α·|y|^β` на
            log1p. Вага береться **з цілі**, не з прогнозу, тому вона не
            тягне видачу вгору, а тільки робить довгий залишок дорожчим
    tail    та сама `events`, але помилка тим дорожча, чим ближче подія
            до кінця ноги: ×2 на 70–80 % ноги, ×4 на 80–90 %, ×8 на
            останніх 10 %. Вага береться **з місця події в нозі**, не з
            цілі й не з прогнозу
    edges   те саме з обох країв: ×10 на перших 10 % ноги, ×4 на 10–20 %,
            ×2 на 20–30 %, далі середина по ×1 і хвіст як у `tail`.
            Профіль U-подібний — рівно там, де етап 1 знайшов край ноги
            в кожній фічі
    ramp    драбина по десятинах: ×1 на перших 10 % ноги і далі рівно
            +1 на кожну десятину, до ×10 на останній. Ваги ростуть
            плавно, без стрибка, і кінець ноги дорожчий за початок
            рівно вдесятеро
    steep   та сама драбина, але з сьомої десятини крок подвоєний:
            ×9, ×11, ×13, ×15 замість ×7, ×8, ×9, ×10. Початок і
            середина ноги важать як у `ramp`, хвіст — у півтора раза
            дорожче

`huber` лишається за замовчуванням: на ньому пораховані перші прогони.

## Проти чого міряємо

    медіана       train-медіана залишку — відповідь без жодного входу
    лічильник     медіана залишку серед train-подій із тим самим числом
                  пройдених подій: знати «нога триває вже `i` подій» можна
                  причинно, і це сильна база

Похибка — медіана `|сказано − насправді|` в подіях, окремо по десятинах
ноги: видно, з якого місця ноги мережа починає щось знати.

Видача **кожної епохи** на val лягає окремим файлом: на вкладці її можна
подивитись нога за ногою і побачити, що саме мережа казала на першій
епосі й на останній.

Вхід : ../data/legleft_<tag>.npz (legleft_data.py)
Вихід: results/legleft_<tag>.json         — крива навчання, похибки, бази
       results/legleft_<tag>_epochs.json  — видача кожної епохи на val
       ../models/legleft_<tag>/           — ваги найкращої епохи

Запуск:
    python3 research/29-class7dd-legs/scripts/legleft_data.py
    python3 research/29-class7dd-legs/scripts/legleft_train.py
    python3 research/29-class7dd-legs/scripts/legleft_train.py --epochs 30
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
NET_SCRIPTS = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(NET_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from legleft_data import (DATA, HISTORY, NORM, NORMS,  # noqa: E402
                          tag_of)
# rules/03-models.md → Навчання без свопа: прогін не починається,
# коли вільної памʼяті менше за MEMORY_NEED.
from leg_end_train import no_swap  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

SEED = 0                   # rules/03-models.md → Правила навчання
EPOCHS = 12                # стеля епох; рання зупинка по val
PATIENCE = 4               # епох без покращення val
BATCH = 8                  # ніг у батчі; батч збирається з близьких довжин
LR = 1e-3
HIDDEN = 64
HEADS = 2
DECILES = 10
LOSSES = ("huber", "mae", "events", "wmse", "tail", "edges", "ramp",
          "steep", "sides", "band")
# Втрати, яким для кроку потрібне ще й місце події в нозі: вони не
# вкладаються в `loss_of(out, true)` і рахуються окремо, у `run`.
PLACED = ("band",)
# Профілі ваги за місцем події в нозі. Пара — «від якої частки ноги» і
# «у скільки разів дорожча помилка»; до першої межі вага 1.
TAIL = ((0.7, 2.0), (0.8, 4.0), (0.9, 8.0))
EDGES = ((0.0, 10.0), (0.1, 4.0), (0.2, 2.0), (0.3, 1.0),
         (0.7, 2.0), (0.8, 4.0), (0.9, 8.0))
RAMP = tuple((one / DECILES, float(one + 1)) for one in range(DECILES))
# `steep`: перші шість десятин як у `ramp`, далі крок +2 замість +1
STEEP = RAMP[:6] + ((0.6, 9.0), (0.7, 11.0), (0.8, 13.0), (0.9, 15.0))
PROFILES = {"tail": TAIL, "edges": EDGES, "ramp": RAMP, "steep": STEEP}
# `sides`: вага не одна на десятину, а **дві** — окремо коли мережа
# сказала більше за ціль і коли менше. Трійка — «від якої частки ноги»,
# «завищення», «заниження».
#
# Перша десятина: заниження дороге, завищення майже безкоштовне — там
# правда 700-800 подій, а симетрична втрата тягне видачу в медіану ряду.
# Рівно нуль за завищення був би виродженим (оптимум — нескінченність),
# тому 0.1: у 300 разів дешевше за заниження, але з дном.
# Далі нахил спадає 30 → 15 → 8 → 4. На 5-6 десятині вся вага нижче
# одиниці, і заниження там **дешевше** за завищення: у середині ноги
# мережі дозволено казати менше. Хвіст 7-10 — як у `ramp`, симетричний.
SIDES = ((0.0, 0.1, 30.0), (0.1, 1.0, 15.0), (0.2, 1.0, 8.0),
         (0.3, 1.0, 4.0), (0.4, 0.5, 0.25), (0.6, 7.0, 7.0),
         (0.7, 8.0, 8.0), (0.8, 9.0, 9.0), (0.9, 10.0, 10.0))
# `band`: мережа відповідає перші WINDOW подій після півота, далі
# мовчить — ціль там рівно 0. Межа стоїть на **лічильнику подій**, а не
# на частці ноги: частка визначається повною довжиною, тобто майбутнім,
# і вимога «до половини кажи, далі мовчи» непричинна — мережа не може
# знати, в якій вона половині, і хеджує одним числом на всю ногу.
# Лічильник вона бачить каналом `leg:step`, тому такий перемикач
# вивчається точно. На своїй половині штраф береться не за
# різницю, а за **відношення** `сказано / правда`: усередині BAND штрафу
# немає взагалі, а за його межами він росте експоненційно — вниз до
# DOWN на нулі, вгору до UP на STOP, далі не росте. Униз дорожче:
# сказати «нозі лишилось мало», коли їй лишилось багато, гірше.
WINDOW = 150               # скільки подій після півота мережа відповідає
BAND = (0.9, 1.1)          # частки цілі, де штрафу немає
WIDE = (0.7, 1.3)          # ширший коридор: другий доданок оцінки
CEIL = 2.2                 # вище цієї частки штраф уже не росте
GROW = 5.0                 # крутість експоненти на краях
DOWN = 80.0                # штраф на самому краю заниження
UP = 20.0                  # і на краю завищення
QUIET = 6.0                # вага мовчання після вікна відповіді
# Перші події після півота важать більше: саме там мережа запізнюється
# зі стрибком. Пара — «від якого кроку» і «у скільки разів дорожче».
WAKE = ((0, 1.0),)         # рівно: підйом голови тягне вгору все вікно
MEASURE = 100.0            # у скільки подій міряється втрата `events`
ALPHA = 1.0                # ваговий MSE: w = 1 + ALPHA * |y| ** BETA
BETA = 1.0
# Грід ручок: rules/03-models.md → Правила навчання. Ширина памʼяті й крок
# навчання; увага вмикається окремим ключем.
GRID = {"hidden": (32, 64), "lr": (1e-3, 3e-4)}


# Зупинка на прохання: `kill -TERM <pid>` не вбиває прогін, а домальовує
# поточну епоху і виходить нормально — з результатами й видачами. Без
# цього обірваний прогін не лишає нічого, бо файли пишуться в кінці.
STOP = {"asked": False}


def listen() -> None:
    import signal

    def ask(*_):
        STOP["asked"] = True
        print("зупинка на прохання: допрацьовую епоху і зберігаю")

    for name in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(name, ask)
        except (ValueError, OSError):
            pass


def device_name() -> str:
    import torch

    if torch.backends.mps.is_available():
        return "mps"
    return "cuda" if torch.cuda.is_available() else "cpu"


def load(tag: str, root: Path = DATA) -> dict:
    """Межі ніг — у памʼять, канали — memmap: з диска їде тільки батч."""
    with np.load(root / f"legleft_{tag}.npz", allow_pickle=False) as store:
        built = {key: store[key] for key in store.files}
    built["x"] = np.load(root / f"legleft_{tag}.npy", mmap_mode="r")
    return built


def legs_of(built: dict) -> list:
    """Ноги як рядки: межі своєї ноги, початок памʼяті, чия і куди.

    `hist … first − 1` — попередні ноги: вони заходять у памʼять, але
    ціль на них замаскована. `first … last` — своя нога, на ній і
    стоїть питання «скільки подій до кінця».
    """
    return [{"hist": int(one), "first": int(two), "last": int(three),
             "events": int(four), "history": int(five), "part": str(six),
             "pair": str(seven), "kind": str(eight),
             "steps": int(three) - int(one) + 1}
            for one, two, three, four, five, six, seven, eight in
            zip(built["hist"], built["first"], built["last"],
                built["events"], built["history"], built["part"],
                built["pair"], built["kind"])]


def tail_weights(place, tail=TAIL):
    """Вага кроку за його місцем у нозі: 1 → 2 → 4 → 8 до самого півота.

    `place` — частка пройденої ноги, 0 на першій події і майже 1 на
    останній. Межі беруться з профілю, тому вага описана числами, а не
    зашита в код: `TAIL` важить тільки хвіст, `EDGES` — обидва краї.
    """
    import torch

    weight = torch.ones_like(place)
    for edge, times in tail:
        weight = torch.where(place >= edge,
                             torch.full_like(place, times), weight)
    return weight


def side_weights(out, true, place, sides=SIDES):
    """Вага кроку з двох боків: окремо за завищення і за заниження.

    Профіль — трійки «від якої частки ноги, завищення, заниження», тому
    драбина описана числами, а не зашита в код. На кожній події
    береться та пара, у чию десятину подія потрапила, і з неї — та
    вага, якій відповідає знак похибки.

    Вага дивиться на знак похибки, тому вона **свідомо** зсуває видачу:
    де заниження дорожче, там мережа піде вгору. Множник `detach`иться —
    це вага, а не доданок: градієнт має йти у видачу, а не в саму вагу.
    """
    import torch

    over = torch.full_like(place, sides[0][1])
    under = torch.full_like(place, sides[0][2])
    for edge, up, down in sides[1:]:
        far = place >= edge
        over = torch.where(far, torch.full_like(place, up), over)
        under = torch.where(far, torch.full_like(place, down), under)
    return torch.where(out < true, under, over).detach()


def band_loss(out, true, step, window: int = WINDOW, band=BAND,
              ceil: float = CEIL, grow: float = GROW, down: float = DOWN,
              up: float = UP):
    """Втрата на крок для `band`: коридор довкола цілі й мовчання далі.

    На першій половині ноги питання стоїть у частках: `r = сказано /
    правда`. Усередині коридору `band` штрафу немає зовсім — «влучив», —
    а за його межами він росте експоненційно: вниз від `band[0]` до нуля
    доходить до `down`, вгору від `band[1]` до `stop` — до `up`, і вище
    `stop` не росте. Униз дорожче, бо сказати «нозі лишилось мало», коли
    їй лишилось багато, — гірша помилка.

    Після `window` подій від півота ціль інша: рівно **0**. Мережа там
    мовчить, і штраф там — модуль видачі в сотнях подій: платиш рівно
    пропорційно тому, що сказав.

    Перші події вікна важать більше (`WAKE`): саме там мережа запізнюється
    зі стрибком — на кроці 0-10 вона каже помітно менше, ніж далі у вікні. Межа по лічильнику, а не по частці ноги: лічильник
    мережа бачить на вході, а частку — ні.
    """
    import torch

    said = torch.expm1(out)
    real = torch.expm1(true).clamp(min=1.0)
    share = (said / real).clamp(min=0.0)
    steep = float(np.expm1(grow))
    low = down * torch.expm1(grow * (band[0] - share).clamp(min=0.0)
                             / band[0]) / steep
    high = up * torch.expm1(
        grow * (share.clamp(max=ceil) - band[1]).clamp(min=0.0)
        / (ceil - band[1])) / steep
    # модуль, а не Хубер: Хубер за межею одиниці росте надто мляво, і
    # «сказав 155» коштує майже стільки ж, скільки «сказав 1000»
    quiet = QUIET * (said / MEASURE).abs()
    wake = torch.full_like(step, WAKE[0][1])
    for edge, times in WAKE[1:]:
        wake = torch.where(step >= edge, torch.full_like(step, times), wake)
    return torch.where(step < window, wake * (low + high), quiet)


def loss_of(name: str = "huber"):
    """Втрата на крок, без згортки: маска накладається зовні.

    Вхід і ціль приходять у `log1p(подій)`. `events` розтискає їх назад
    у події й ділить на `MEASURE`, щоб крок оптимізатора лишався того
    самого порядку, що й на стиснутій шкалі.
    """
    import torch

    huber = torch.nn.HuberLoss(reduction="none")
    if name == "huber":
        return lambda out, true: huber(out, true)
    if name == "mae":
        return lambda out, true: (out - true).abs()
    if name == "events":
        return lambda out, true: huber(torch.expm1(out) / MEASURE,
                                      torch.expm1(true) / MEASURE)
    if name == "wmse":
        return lambda out, true: (1 + ALPHA * true.abs() ** BETA) \
            * (out - true) ** 2
    if name == "sides":                   # вага з двох боків, теж окремо
        return lambda out, true: huber(torch.expm1(out) / MEASURE,
                                      torch.expm1(true) / MEASURE)
    if name in PROFILES:                  # вага йде окремо, з місця в нозі
        return lambda out, true: huber(torch.expm1(out) / MEASURE,
                                      torch.expm1(true) / MEASURE)
    raise ValueError(f"невідома втрата: {name}")


def batches(rows: list, size: int = BATCH, seed: int = SEED) -> list:
    """Батчі з ніг близької довжини: паддингу менше, памʼять ціліша."""
    order = sorted(range(len(rows)), key=lambda one: rows[one]["steps"])
    chunks = [order[start:start + size]
              for start in range(0, len(order), size)]
    np.random.default_rng(seed).shuffle(chunks)
    return chunks


def tensors(built: dict, rows: list, chunk: list, device: str):
    """Один батч: `(B, L, C+1)`, ціль `log1p(left)` і три маски.

    `mask` — де взагалі є подія (для уваги й для рекурсії), `count` — де
    стоїть питання, тобто події **своєї** ноги. Останній канал каже
    мережі, чи вона вже в своїй нозі, чи ще в памʼяті попередніх.
    `place` — частка пройденої ноги на кожному кроці: з неї береться вага
    втрати `tail`. `step` — те саме в подіях: скільки подій минуло від
    півота; по ньому `band` вирішує, де мережа має замовкнути. У мережу
    жодне з них не заходить — вона бачить лічильник окремим каналом.
    """
    import torch

    length = max(rows[one]["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    count = np.zeros((len(chunk), length), dtype=bool)
    place = np.zeros((len(chunk), length), dtype=np.float32)
    walk = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        row = rows[one]
        steps, own = row["steps"], row["events"]
        x[number, :steps, :-1] = np.asarray(
            built["x"][row["hist"]:row["last"] + 1], dtype=np.float32)
        x[number, steps - own:steps, -1] = 1.0
        y[number, steps - own:steps] = np.arange(own - 1, -1, -1)
        mask[number, :steps] = True
        count[number, steps - own:steps] = True
        place[number, steps - own:steps] = np.arange(own) / max(own, 1)
        walk[number, steps - own:steps] = np.arange(own)
    lengths = torch.tensor([rows[one]["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device),
            torch.from_numpy(np.log1p(y)).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(count).to(device),
            torch.from_numpy(place).to(device),
            torch.from_numpy(walk).to(device))


def weight_of(built: dict, rows: list, picked: list, device: str,
              loss: str):
    """Сумарна вага батча — без проходу вперед.

    Вага береться з масок і місця події, тому відома до того, як мережа
    щось сказала. Саме це дозволяє порахувати батч половинами й дістати
    ту саму суму, що й цілим.
    """
    _, _, _, _, own, place, _ = tensors(built, rows, picked, device)
    share = own if loss not in PROFILES \
        else own * tail_weights(place, PROFILES[loss])
    return share.sum()


def one_batch(model, built: dict, rows: list, chunk: list,
              device: str) -> dict:
    """Видача на одному батчі ніг: сказано, насправді, десятина, нога."""
    said, truth, place, legs = [], [], [], []
    x, y, mask, lengths, _, _, _ = tensors(built, rows, chunk, device)
    out = model(x, mask, lengths)
    for number, one in enumerate(chunk):
        row = rows[one]
        steps, count = row["steps"], row["events"]
        piece = slice(steps - count, steps)
        said.append(np.expm1(out[number, piece].float().cpu().numpy()))
        truth.append(np.expm1(y[number, piece].float().cpu().numpy()))
        place.append((np.arange(count) / count * DECILES).astype(int) + 1)
        legs.append(np.full(count, one))
    return {"said": said, "truth": truth, "place": place, "legs": legs}


def out_of_memory(error: Exception) -> bool:
    """Чи це брак памʼяті прискорювача, а не справжня поломка."""
    return "out of memory" in str(error).lower()


def free_of(device: str) -> None:
    """Віддати кеш прискорювача перед повторною спробою."""
    import torch

    if device == "mps" and hasattr(torch, "mps"):
        torch.mps.empty_cache()
    elif device == "cuda":
        torch.cuda.empty_cache()


def band_grid() -> dict:
    """Константи сітки `band`: ними підписується оцінка прогону.

    Оцінка рахується цією ж сіткою, тому при зміні будь-якого числа
    старі оцінки з новими не порівнюються. Підпис лежить у файлі
    прогону, і продовження з іншою сіткою починає відбір кращої епохи
    заново — ваги при цьому лишаються.
    """
    return {"window": WINDOW, "band": list(BAND), "wide": list(WIDE),
            "ceil": CEIL,
            "grow": GROW, "down": DOWN, "up": UP, "quiet": QUIET,
            "wake": [list(one) for one in WAKE]}


def band_mark(block: dict, rows: list, picked: list) -> float:
    """Оцінка `band` на val: **скільки видачі лягло в коридор**.

    Кращу епоху не можна обирати за медіаною `|сказано − насправді|`:
    після вікна ціль рівно 0, і чим краще мережа мовчить, тим гіршою
    вона за тією міркою виглядає.

    Сама втрата теж не годиться: вона винагороджує уникнення грубих
    промахів, а від моделі просять влучань. Тому оцінка — це частка
    подій вікна, що лягли в коридор (вузький і широкий разом), плюс
    надбавка за балакучість після вікна, де ціль рівно 0. Менше —
    краще, нуль — ідеал.
    """
    step = np.concatenate([np.arange(rows[one]["events"], dtype=np.float64)
                           for one in picked])
    said = np.asarray(block["said"], dtype=np.float64)
    truth = np.asarray(block["truth"], dtype=np.float64)
    talk = step < WINDOW
    if not talk.any():
        return float("inf")
    share = said[talk] / np.maximum(truth[talk], 1.0)
    near = float(((share >= BAND[0]) & (share <= BAND[1])).mean())
    wide = float(((share >= WIDE[0]) & (share <= WIDE[1])).mean())
    loud = float(np.median(np.abs(said[~talk]))) / MEASURE \
        if (~talk).any() else 0.0
    return 1.0 - (near + wide) / 2.0 + loud


def guess(model, built: dict, rows: list, picked: list, device: str,
          size: int = BATCH) -> dict:
    """Видача мережі на ногах: сказано, насправді і місце події в нозі.

    Увага росте як `довжина² × ніг у батчі`, тому на довгих ногах батч
    може не влізти в памʼять прискорювача. Такий батч ділиться навпіл і
    рахується ще раз — видача від цього не міняється: паддинг
    замаскований, і кожна нога рахується сама по собі.
    """
    import torch

    found = []
    model.eval()
    with torch.no_grad():
        for chunk in [picked[start:start + size]
                      for start in range(0, len(picked), size)]:
            try:
                found.append(one_batch(model, built, rows, chunk, device))
            except RuntimeError as error:
                if len(chunk) == 1 or not out_of_memory(error):
                    raise
                free_of(device)
                print(f"батч на {len(chunk)} ніг не вліз у памʼять: "
                      f"ділю навпіл")
                got = guess(model, built, rows, chunk, device,
                            max(1, len(chunk) // 2))
                found.append({"said": [got["said"]],
                              "truth": [got["truth"]],
                              "place": [got["decile"]],
                              "legs": [got["leg"]]})
    return {"said": np.concatenate([one for got in found
                                    for one in got["said"]]),
            "truth": np.concatenate([one for got in found
                                     for one in got["truth"]]),
            "decile": np.minimum(np.concatenate(
                [one for got in found for one in got["place"]]), DECILES),
            "leg": np.concatenate([one for got in found
                                   for one in got["legs"]])}


def errors(block: dict) -> dict:
    """Медіанна похибка в подіях: усього і по десятинах ноги."""
    gap = np.abs(block["said"] - block["truth"])
    by_decile = []
    for part in range(1, DECILES + 1):
        picked = block["decile"] == part
        by_decile.append(float(np.median(gap[picked])) if picked.any()
                         else None)
    return {"err": float(np.median(gap)),
            "err_mean": float(gap.mean()),
            "by_decile": by_decile,
            "events": int(gap.size)}


def shot_of(block: dict, rows: list, picked: list, epoch: int,
            got: dict) -> dict:
    """Видача однієї епохи на val: сказане число на кожній події ноги."""
    return {"epoch": epoch, "err": got["err"], "by_decile": got["by_decile"],
            "said": [int(round(float(one))) for one in block["said"]]}


def baselines(built: dict, rows: list, train: list, val: list) -> dict:
    """Дві бази без навчання: медіана залишку і медіана за лічильником."""
    def pull(picked):
        left, step, place = [], [], []
        for one in picked:
            row = rows[one]
            left.append(np.arange(row["events"] - 1, -1, -1,
                                  dtype=np.float32))
            step.append(np.arange(row["events"]))
            place.append(np.minimum(
                (np.arange(row["events"]) / row["events"] * DECILES)
                .astype(int) + 1, DECILES))
        return (np.concatenate(left), np.concatenate(step),
                np.concatenate(place))

    def spread(gap, decile):
        return [float(np.median(gap[decile == part]))
                if (decile == part).any() else None
                for part in range(1, DECILES + 1)]

    train_left, train_step, _ = pull(train)
    val_left, val_step, val_decile = pull(val)
    flat = float(np.median(train_left))
    # медіана залишку серед train-подій із тим самим лічильником
    top = int(train_step.max()) + 1
    table = np.full(top, flat)
    order = np.argsort(train_step, kind="stable")
    bounds = np.searchsorted(train_step[order], np.arange(top + 1))
    for step in range(top):
        piece = order[bounds[step]:bounds[step + 1]]
        if piece.size >= 5:
            table[step] = float(np.median(train_left[piece]))
    said = table[np.minimum(val_step, top - 1)]
    return {
        "median": {"said": flat,
                   "err": float(np.median(np.abs(flat - val_left))),
                   "by_decile": spread(np.abs(flat - val_left), val_decile)},
        "counter": {"err": float(np.median(np.abs(said - val_left))),
                    "by_decile": spread(np.abs(said - val_left), val_decile),
                    "steps": top},
    }


def resume_from(model, tune, keep: Path | None) -> bool:
    """Підняти ваги (і, якщо є, стан оптимізатора) з попереднього прогону.

    Ваги пишуться на кожній кращій епосі, тому продовження стартує саме
    з неї. Стан AdamW зберігається поруч із першого прогону, де цей ключ
    зʼявився: без нього моменти набираються заново, і продовження — це
    теплий рестарт, а не строге продовження. Що саме сталось, каже
    повернуте значення.
    """
    import torch

    if keep is None or not (keep / "model.pt").exists():
        raise SystemExit(f"немає ваг для продовження: {keep}/model.pt")
    model.load_state_dict(torch.load(keep / "model.pt", map_location="cpu"))
    if (keep / "tune.pt").exists():
        tune.load_state_dict(torch.load(keep / "tune.pt",
                                        map_location="cpu"))
        return True
    return False


def run(built: dict, rows: list, epochs: int = EPOCHS, hidden: int = HIDDEN,
        heads: int = HEADS, lr: float = LR, patience: int = PATIENCE,
        seed: int = SEED, attention: bool = True, device: str | None = None,
        keep: Path | None = None, loss: str = "huber",
        before: dict | None = None, warm: Path | None = None) -> dict:
    import torch
    from leg_end_net import LegEnd, parameters_of, spec_of

    device = device or device_name()
    torch.manual_seed(seed)
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    model = LegEnd(features=built["x"].shape[1] + 1, hidden=hidden,
                   heads=heads, attention=attention, outputs=1).to(device)
    tune = torch.optim.AdamW(model.parameters(), lr=lr)
    step_loss = None if loss in PLACED else loss_of(loss)
    curve, best, stale, shots = [], None, 0, []
    start, lifted = 1, None
    if before is not None:                # продовження вже початого прогону
        lifted = resume_from(model, tune, keep)
        curve = list(before.get("curve", []))
        shots = list(before.get("shots", []))
        best = dict(before["best"]) if before.get("best") else None
        if loss in PLACED and before.get("grid_band") != band_grid():
            # сітку змінили: старі оцінки з новими не порівнюються
            print("сітка втрати інша — відбір кращої епохи з нуля")
            best = None
        start = max((one["epoch"] for one in curve), default=0) + 1
        print(f"продовження з епохи {start}: ваги епохи "
              f"{best['epoch'] if best else '—'}, "
              f"стан оптимізатора "
              f"{'піднято' if lifted else 'набереться заново'}")
    elif warm is not None:      # ваги чужого прогону, крива своя з нуля
        got = resume_from(model, tune, warm)
        print(f"стартові ваги з {warm.name}: "
              f"стан оптимізатора {'піднято' if got else 'набереться заново'}")
    for epoch in range(start, start + epochs):
        model.train()
        total, seen = 0.0, 0
        def feed(picked: list, scale=None):
            """Крок по батчу: вперед, назад і сума втрати.

            `scale` — сумарна вага батча. Вона рахується з масок, без
            проходу вперед, тому батч можна порахувати двома половинами
            й дістати рівно ту саму суму, що й цілим: градієнти
            складаються, а дільник спільний.
            """
            x, y, mask, lengths, own, place, walk = tensors(
                built, rows, picked, device)
            # ціль стоїть тільки на своїй нозі: попередні йдуть у памʼять;
            # `tail` додає вагу за місцем події в нозі
            share = own if loss not in PROFILES \
                else own * tail_weights(place, PROFILES[loss])
            if scale is None:
                scale = share.sum()
            out = model(x, mask, lengths)
            if loss == "sides":     # вага з двох боків: знак похибки вирішує
                share = own * side_weights(out, y, place)
            each = band_loss(out, y, walk) if loss in PLACED \
                else step_loss(out, y)
            piece = (each * share).sum() / scale
            piece.backward()
            return float(piece.detach()), int(own.sum()), scale

        def learn(picked: list, scale=None):
            """Той самий крок, але батч, що не вліз у памʼять, ділиться."""
            try:
                return feed(picked, scale)
            except RuntimeError as error:
                if len(picked) == 1 or not out_of_memory(error):
                    raise
                free_of(device)
                print(f"батч на {len(picked)} ніг не вліз у памʼять: "
                      f"ділю навпіл")
                if scale is None:   # дільник рахується без проходу вперед
                    scale = weight_of(built, rows, picked, device, loss)
                half = len(picked) // 2
                one = learn(picked[:half], scale)
                two = learn(picked[half:], scale)
                return one[0] + two[0], one[1] + two[1], scale

        for chunk in batches([rows[one] for one in train], seed=seed + epoch):
            picked = [train[one] for one in chunk]
            tune.zero_grad()
            got, count, _ = learn(picked)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            tune.step()
            total += got * count
            seen += count
        block = guess(model, built, rows, val, device)
        got = errors(block)
        # для `band` краща епоха — з найменшою її ж втратою на val:
        # похибка в подіях там міряє не те, чого просять
        mark = band_mark(block, rows, val) if loss in PLACED else got["err"]
        got = {**got, "mark": mark}
        step = {"epoch": epoch, "loss": total / max(seen, 1),
                "val_err": got["err"], "val_err_mean": got["err_mean"],
                "mark": mark}
        curve.append(step)
        shots.append(shot_of(block, rows, val, epoch, got))
        print(f"епоха {epoch:>2}  втрата {step['loss']:.4f}  "
              f"val похибка {got['err']:.0f} подій"
              + (f"  оцінка {mark:.4f}" if loss in PLACED else ""))
        # у прогонів, початих до появи оцінки, її у файлі немає
        if best is None or mark < best.get("mark", float("inf")):
            best = {**got, "epoch": epoch}
            stale = 0
            if keep is not None:
                keep.mkdir(parents=True, exist_ok=True)
                torch.save(model.state_dict(), keep / "model.pt")
                torch.save(tune.state_dict(), keep / "tune.pt")
        # ваги кожної епохи лягають поруч: критерій відбору ще міняється,
        # і хороша епоха не має губитись через те, чим її міряли
        if keep is not None:
            keep.mkdir(parents=True, exist_ok=True)
            torch.save(model.state_dict(), keep / f"epoch{epoch}.pt")
        else:
            stale += 1
            if stale >= patience:
                break
        if STOP["asked"]:
            break
    on_train = errors(guess(model, built, rows, train, device))
    return {"curve": curve, "best": best, "train": on_train, "shots": shots,
            "val": val, "loss": loss, "seed": seed,
            "grid_band": band_grid() if loss in PLACED else None,
            "epochs": len(curve), "device": device,
            "params": parameters_of(model),
            "spec": spec_of(model, built["x"].shape[0],
                        built["x"].shape[1] + 1),
            "legs": {"train": len(train), "val": len(val)},
            "base": baselines(built, rows, train, val)}


def configs(grid: dict = GRID) -> list:
    """Усі поєднання ручок гріда, по одному рядку на прогін."""
    rows = [{}]
    for name, values in grid.items():
        rows = [{**row, name: value} for row in rows for value in values]
    return rows


def label_of(config: dict) -> str:
    return " · ".join(f"{name} {value}" for name, value in config.items())


def report_of(built: dict, meta: dict, result: dict, tag: str) -> dict:
    base = result["base"]
    best = result["best"]
    return {
        "script": "research/29-class7dd-legs/scripts/legleft_train.py",
        "ready": True, "tag": tag, "data": meta,
        "channels": int(built["x"].shape[1]) + 1,
        "history": meta.get("history", 0),
        "classes": meta.get("classes", []),
        "seed": result.get("seed", SEED), "device": result["device"],
        "params": result["params"],
        "spec": result["spec"], "curve": result["curve"],
        "epochs": result["epochs"], "legs": result["legs"],
        "config": result.get("config", {"hidden": HIDDEN, "lr": LR}),
        "loss": result.get("loss", "huber"),
        "tail": [list(one) for one in
                 PROFILES.get(result.get("loss"), ())],
        "shots": [{"epoch": one["epoch"], "err": one["err"],
                   "by_decile": one["by_decile"]}
                  for one in result.get("shots", [])],
        "grid": result.get("grid", []),
        "grid_band": result.get("grid_band"),
        "best": best, "train": result["train"], "base": base,
        "gain": {"median": float(1 - best["err"] / base["median"]["err"])
                 if base["median"]["err"] else 0.0,
                 "counter": float(1 - best["err"] / base["counter"]["err"])
                 if base["counter"]["err"] else 0.0},
    }


def epochs_of(built: dict, rows: list, result: dict, tag: str,
              meta: dict) -> dict:
    """Файл видач: ряд val кожної монети, факт і що казала кожна епоха.

    Ноги йдуть за часом усередині монети, тому видача лягає прямо на ряд:
    зверху ціна із півотами, знизу пилка «подій до кінця» і крива мережі.
    """
    val = sorted(result["val"], key=lambda one: (rows[one]["pair"],
                                                 rows[one]["first"]))
    legs, place = [], 0
    for one in val:
        row = rows[one]
        legs.append({"pair": row["pair"], "kind": row["kind"],
                     "events": row["events"], "history": row["history"],
                     "start": place, "order": result["val"].index(one)})
        place += row["events"]
    # видача епохи йде в порядку `result["val"]`; тут вона перекладається
    # в порядок ряду, той самий, що в `legs`
    def sorted_said(said: list) -> list:
        out = []
        place = {}
        step = 0
        for one in result["val"]:
            place[one] = step
            step += rows[one]["events"]
        for one in val:
            start = place[one]
            out.extend(said[start:start + rows[one]["events"]])
        return out

    stamps, price, truth, coin = [], [], [], []
    for one in val:
        row = rows[one]
        piece = slice(row["first"], row["last"] + 1)
        stamps.extend(int(value) for value in built["t"][piece])
        price.extend(round(float(value), 6) for value in built["price"][piece])
        truth.extend(range(row["events"] - 1, -1, -1))
        coin.extend([row["pair"]] * row["events"])
    return {
        "script": "research/29-class7dd-legs/scripts/legleft_train.py",
        "ready": bool(legs), "tag": tag, "history": meta.get("history", 0),
        "channels": int(meta.get("channels", 0)) + 1,
        "threshold": meta.get("threshold", 0.023),
        "period": meta.get("period", 10),
        "config": result.get("config", {}), "events": place,
        "loss": result.get("loss", "huber"),
        "best": result["best"]["epoch"], "legs": legs,
        "pairs": sorted({row["pair"] for row in legs}),
        "t": stamps, "price": price, "truth": truth, "pair": coin,
        # епохи попереднього прогону приходять сюди без `said`: їхня
        # видача вже лежить у старому файлі й береться звідти в `main`
        "epochs": [{**one, "said": sorted_said(one["said"])}
                   for one in result["shots"] if "said" in one],
    }


def show(report: dict) -> None:
    best, base = report["best"], report["base"]
    print(f"\nканали {report['channels']}, памʼять "
          f"{report.get('history', 0)} ніг, втрата {report.get('loss')}, "
          f"ваг {report['params']}, "
          f"пристрій {report['device']}, ручки "
          f"{label_of(report['config'])}, епоха {best['epoch']} з "
          f"{report['epochs']}")
    print(f"похибка на val: мережа {best['err']:.0f} подій · "
          f"медіана {base['median']['err']:.0f} · "
          f"лічильник {base['counter']['err']:.0f}")
    print(f"виграш: проти медіани {report['gain']['median']:+.3f}, "
          f"проти лічильника {report['gain']['counter']:+.3f}")
    print("\nмедіанна похибка по десятинах ноги, подій")
    for name, line in (("мережа", best["by_decile"]),
                       ("лічильник", base["counter"]["by_decile"]),
                       ("медіана", base["median"]["by_decile"])):
        print(f"  {name:<10} " + " ".join(
            f"{one:>6.0f}" if one is not None else "     —" for one in line))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--blocks", action="store_true")
    parser.add_argument("--history", type=int, default=HISTORY,
                        help="скільки попередніх ніг у памʼяті (як у даних)")
    parser.add_argument("--norm", default=NORM, choices=NORMS,
                        help="нормалізація датасету (як у даних)")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--loss", default="huber", choices=LOSSES,
                        help="функція втрат: huber, mae, events, wmse")
    parser.add_argument("--hidden", type=int, default=HIDDEN)
    parser.add_argument("--heads", type=int, default=HEADS)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--no-attention", action="store_true")
    parser.add_argument("--grid", action="store_true",
                        help="перебрати ручки гріда і лишити найкращу")
    parser.add_argument("--seed", type=int, default=SEED,
                        help="засів: інший дає незалежний прогін тієї самої "
                             "конфігурації")
    parser.add_argument("--clock", action="store_true",
                        help="датасет із причинними лічильниками")
    parser.add_argument("--warm", default=None,
                        help="взяти стартові ваги з готового прогону "
                             "(його тег), а крива епох піде своя з першої")
    parser.add_argument("--resume", action="store_true",
                        help="продовжити прогін цього тега з його останньої "
                             "кращої епохи, а не вчити з нуля")
    parser.add_argument("--force", action="store_true",
                        help="почати навчання попри брак вільної памʼяті")
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    no_swap(force=args.force)
    listen()

    tag = tag_of(args.blocks, args.history, args.norm, args.clock)
    built = load(tag, args.data)
    meta = json.loads((args.data / f"legleft_{tag}.meta.json")
                      .read_text(encoding="utf-8"))
    # прогони різних втрат лежать поруч, тому втрата входить в імʼя
    tag = tag if args.loss == "huber" else f"{tag}_{args.loss}"
    rows = legs_of(built)
    before, was = None, {}
    if args.resume:
        if args.grid:
            raise SystemExit("--resume і --grid разом не мають сенсу: "
                             "продовжується один прогін, не перебір")
        kept = args.out / f"legleft_{tag}.json"
        if not kept.exists():
            raise SystemExit(f"немає що продовжувати: {kept}")
        before = json.loads(kept.read_text(encoding="utf-8"))
        # видачі попередніх епох лежать окремим файлом: беруться як є,
        # бо ноги val і їхній порядок ті самі
        older = args.out / f"legleft_{tag}_epochs.json"
        if older.exists():
            was = {one["epoch"]: one for one in json.loads(
                older.read_text(encoding="utf-8")).get("epochs", [])}
    plan = configs() if args.grid else [{"hidden": args.hidden,
                                         "lr": args.lr}]
    result, grid = None, []
    for config in plan:
        print(f"\n=== {label_of(config)} ===")
        got = run(built, rows, args.epochs, config["hidden"], args.heads,
                  config["lr"], patience=args.patience, seed=args.seed,
                  loss=args.loss, attention=not args.no_attention,
                  keep=MODELS / f"legleft_{tag}"
                  if len(plan) == 1 else None, before=before,
                  warm=MODELS / f"legleft_{args.warm}" if args.warm else None)
        grid.append({"config": config, "err": got["best"]["err"],
                     "epoch": got["best"]["epoch"],
                     "epochs": got["epochs"]})
        if result is None or got["best"]["err"] < result["best"]["err"]:
            result = {**got, "config": config}
    # найкраща ручка переучується ще раз і саме її ваги лягають у models/
    if len(plan) > 1:
        print(f"\n=== найкраща: {label_of(result['config'])} ===")
        result = {**run(built, rows, args.epochs, result["config"]["hidden"],
                        args.heads, result["config"]["lr"],
                        patience=args.patience, loss=args.loss,
                        attention=not args.no_attention,
                        keep=MODELS / f"legleft_{tag}"),
                  "config": result["config"]}
    result["grid"] = (before or {}).get("grid", []) if args.resume else grid
    report = report_of(built, meta, result, tag)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / f"legleft_{tag}.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    shown = epochs_of(built, rows, result, tag, meta)
    if was:                     # видачі старих епох перерахунку не просять
        fresh = {one["epoch"] for one in shown["epochs"]}
        shown["epochs"] = sorted(
            [one for one in was.values() if one["epoch"] not in fresh]
            + shown["epochs"], key=lambda one: one["epoch"])
    (args.out / f"legleft_{tag}_epochs.json").write_text(
        json.dumps(shown, ensure_ascii=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'legleft_{tag}.json'}")


if __name__ == "__main__":
    main()
