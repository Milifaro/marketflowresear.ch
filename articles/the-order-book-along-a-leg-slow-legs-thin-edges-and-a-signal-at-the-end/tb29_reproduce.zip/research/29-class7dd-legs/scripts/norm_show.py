"""Одна подія класу до нормалізації і після неї.

Дослідження: research/29-class7dd-legs/
Правила: rules/01-data-and-db.md → Опис класів

Мережа не бачить сирої фічі. Тут видно, що саме вона бачить: та сама
подія друкується двічі — числами класу, як вони лежать у датасеті, і
тими самими числами після перетворення. Кожен блок події — окремий
канал, і одиниця в кожного своя, тому перетворення рахується по
каналу на всьому ряді монети з базою `train`.

Разом із подією друкується підсумок каналу: медіана, 99-й перцентиль і
максимум `|значення|` до і після. Це показує, у які межі стало те, чим
годують мережу.

Запуск:
    python3 research/29-class7dd-legs/scripts/norm_show.py
    python3 research/29-class7dd-legs/scripts/norm_show.py --norm asinh99
    python3 research/29-class7dd-legs/scripts/norm_show.py --event 40000
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = RESEARCH_DIR.parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "28-leg-edge-profile"
                       / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from edge_profile import load  # noqa: E402
from leg_start import VAL_FROM  # noqa: E402
from legleft_data import NORM, NORMS, normal  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
CLASS = "class210x10m1x7dd"
EVENT = 60_000                     # яку подію ряду показати


def numbers(pair: str, name: str, norm: str, root: Path | None = None):
    """Клас цілком до і після нормалізації, канал за каналом."""
    data = load(pair, name, root)
    raw = np.asarray(data["x"], dtype=float)
    train = data["t"] < VAL_FROM
    out = np.empty(raw.shape, dtype=np.float32)
    for number in range(raw.shape[2]):
        for block in range(raw.shape[1]):
            out[:, block, number] = normal(raw[:, block, number].copy(),
                                           train, norm)
    return data, raw, out


def summary(raw: np.ndarray, out: np.ndarray) -> dict:
    """Межі каналів до і після: медіана, 99-й перцентиль, максимум."""
    def stats(values):
        one = np.abs(values[np.isfinite(values)])
        return {"median": float(np.median(one)),
                "p99": float(np.percentile(one, 99)),
                "top": float(one.max())}
    return {"before": stats(raw), "after": stats(out)}


def show(found: dict) -> None:
    when = datetime.fromtimestamp(found["t"], timezone.utc)
    blocks = len(found["rows"][0]["before"])
    print(f"\n{found['pair']} · {found['class']} · подія "
          f"{found['event']} ({when:%Y-%m-%d %H:%M} UTC) · "
          f"нормалізація {found['norm']}\n")
    head = "".join(f"{'б' + str(one + 1):>10}" for one in range(blocks))
    for part in ("before", "after"):
        print(f"{'до нормалізації' if part == 'before' else 'після':<22}{head}")
        for row in found["rows"]:
            line = "".join(f"{one:>10.3g}" for one in row[part])
            print(f"  {row['feature']:<20}{line}")
        print()
    limits = found["limits"]
    print(f"{'канали класу':<22}{'медіана':>12}{'99-й':>12}{'максимум':>12}")
    for part, title in (("before", "до"), ("after", "після")):
        one = limits[part]
        print(f"  {title:<20}{one['median']:>12.3g}{one['p99']:>12.3g}"
              f"{one['top']:>12.3g}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--class", dest="name", default=CLASS)
    parser.add_argument("--norm", default=NORM, choices=NORMS)
    parser.add_argument("--event", type=int, default=EVENT)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    data, raw, out = numbers(args.pair, args.name, args.norm, args.data)
    place = min(args.event, len(data["t"]) - 1)
    found = {
        "script": "research/29-class7dd-legs/scripts/norm_show.py",
        "pair": args.pair, "class": args.name, "norm": args.norm,
        "event": place, "t": int(data["t"][place]),
        "rows": [{"feature": str(one),
                  "before": [float(v) for v in raw[place, :, number]],
                  "after": [float(v) for v in out[place, :, number]]}
                 for number, one in enumerate(data["features"])],
        "limits": summary(raw, out),
        "ready": True,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"norm_show_{args.pair}_{args.name}_{args.norm}.json"
    path.write_text(json.dumps(found, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    show(found)
    print(f"\nзаписано в {path}")


if __name__ == "__main__":
    main()
