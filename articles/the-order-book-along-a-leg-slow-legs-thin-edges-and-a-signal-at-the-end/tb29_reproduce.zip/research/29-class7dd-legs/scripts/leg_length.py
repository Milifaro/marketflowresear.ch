"""Довжина ноги з рівня фічі: скільки подій ще протримається нога.

Дослідження: research/29-class7dd-legs/
Правила: rules/01-data-and-db.md → Опис класів, rules/03-models.md

Етап 1 показав звʼязок: довга нога — повільна. Спірмен між кількістю
подій ноги і рівнем фічі в ній доходить до −0.61 (`d_price_avg`,
амплітуда) і +0.65 (`d_support_sell`, сплеск). Але той рівень міряний
**по всій нозі**, тобто разом із подіями, яких на початку ще немає:
як прогноз він не існує.

Тут те саме питання ставиться причинно. Нога вже триває `K` подій після
півота; видно **тільки ці `K` подій** (і, за набором, попередню ногу).
Скільки подій у нозі буде всього?

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 % -> ноги
    -> перші K подій ноги -> ранги фіч -> три криві -> модель -> events

Три набори входів:

    head       рівень семи фіч у перших `K` подіях ноги + її напрямок
    prev       попередня нога: її довжина і рівень фіч у ній
    head_prev  обидва

Два базові рівні:

    медіана    train-медіана довжини — модель без жодного входу
    перенос    довжина попередньої ноги, без навчання

Ранги. Фічі — відношення похідних, хвости до 1e12, тому кожна переводиться
в ранг усередині монети (етап 1). Тут таблиця рангів будується **тільки на
train-подіях монети** і застосовується до всього ряду: інакше рівень
val-події знав би про майбутнє.

Ділень два, як в етапі 8 дослідження 28. **За датою** — train до 14.08,
val після: чесний час, але ніг у val десятки. **Відкладена монета** —
модель учиться на пʼятьох монетах і відповідає на шостій, шість разів:
у замір іде кожна нога, але час перемішаний.

Ціль навчається в логарифмі (довжина йде від десятків до тисяч подій),
похибка рахується в подіях.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_length_<клас>.json      — усе, з переліком ніг
       results/leg_length_<клас>.meta.json — те саме без ніг

Запуск:
    python3 research/29-class7dd-legs/scripts/leg_length.py
    python3 research/29-class7dd-legs/scripts/leg_length.py --head 39
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS  # noqa: E402
from edge_profile import (HOLE, PERIOD, THRESHOLD, legs_of,  # noqa: E402
                          load, value)
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402
from class_edge_profile import CLASS, CURVES, HOT, mean_of  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

HEADS = (10, 20, 39, 60, 100)   # скільки подій початку ноги видно моделі
SETS = ("head", "prev", "head_prev")
BINS = 5                        # на скільки груп ділиться рівень фічі
SHOW = 39                       # на якому K будуються групи рівня


def curves_of(column: np.ndarray, dirs: np.ndarray,
              train: np.ndarray) -> dict:
    """Три криві по події, з таблицею рангів, знятою тільки з train.

    Відмінність від етапу 1: там ранг рахувався по всьому ряду монети,
    бо питання було описове. Тут рівень val-події не має права знати
    про майбутнє, тому база рангів — train-події ніг цієї монети.
    """
    inside = dirs != 0
    size = np.abs(column)
    signed = column * dirs
    base_rows = inside & train
    line = np.quantile(size[base_rows & np.isfinite(size)], HOT) \
        if (base_rows & np.isfinite(size)).any() else np.inf
    return {"rank": placed(signed, base_rows, inside) - 0.5,
            "amplitude": placed(size, base_rows, inside),
            "hot": np.where(inside & np.isfinite(size),
                            (size >= line).astype(float), np.nan)}


def placed(column: np.ndarray, base_rows: np.ndarray,
           inside: np.ndarray) -> np.ndarray:
    """Ранг величини серед train-подій ніг монети, 0…1."""
    out = np.full(column.shape, np.nan)
    base = np.sort(column[base_rows & np.isfinite(column)])
    good = inside & np.isfinite(column)
    if base.size < 2 or not good.any():
        return out
    out[good] = (np.searchsorted(base, column[good], side="left") + 0.5) \
        / base.size
    return out


def levels(curves: dict, features: list, first: int, last: int) -> dict:
    """Рівень кожної фічі на відрізку: середнє кожної з трьох кривих."""
    return {f"{name}_{curve}": mean_of(curves[name][curve][first:last + 1])
            for name in features for curve in CURVES}


def rows_of(pairs, class_name: str, root: Path | None, reduce: str) -> list:
    """Нога за ногою: її довжина, рівень фіч у голові й попередня нога."""
    rows = []
    for pair in pairs:
        data = load(pair, class_name, root)
        _, legs = legs_of(data)
        clean = [leg for leg in legs if leg["hole_hours"] * 3600 <= HOLE]
        dirs = np.zeros(len(data["t"]))
        for leg in clean:
            dirs[leg["first"]:leg["last"] + 1] = \
                1 if leg["kind"] == "up" else -1
        train = data["t"] < VAL_FROM
        curves = {name: curves_of(value(data, name, reduce), dirs, train)
                  for name in data["features"]}
        order = {leg["leg"]: number for number, leg in enumerate(clean)}
        for leg in clean:
            number = order[leg["leg"]]
            if number < 1 or clean[number - 1]["leg"] != leg["leg"] - 1:
                continue
            before = clean[number - 1]
            rows.append({
                "pair": pair, "leg": leg["leg"], "kind": leg["kind"],
                "from": leg["from"], "to": leg["to"],
                "first": leg["first"], "last": leg["last"],
                "events": leg["events"],
                "part": "val" if leg["from"] >= VAL_FROM else "train",
                "up": float(leg["kind"] == "up"),
                "prev_events": before["events"],
                "prev": levels(curves, data["features"],
                               before["first"], before["last"]),
                "head": {size: levels(curves, data["features"], leg["first"],
                                      leg["first"] + size - 1)
                         for size in HEADS},
                "whole": levels(curves, data["features"],
                                leg["first"], leg["last"]),
            })
    return rows


def columns(row: dict, size: int, kit: str) -> dict:
    """Вхід моделі: що саме їй видно на події `size` після півота."""
    out = {}
    if kit in ("head", "head_prev"):
        out.update({f"h_{name}": item for name, item
                    in row["head"][size].items()})
        out["h_up"] = row["up"]
    if kit in ("prev", "head_prev"):
        out.update({f"p_{name}": item for name, item in row["prev"].items()})
        out["p_events"] = float(row["prev_events"])
    return out


def model_of(x_train, y_train):
    from sklearn.ensemble import HistGradientBoostingRegressor

    model = HistGradientBoostingRegressor(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=7,
        min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
    model.fit(x_train, np.log(y_train))
    return model


def scored(pred: np.ndarray, truth: np.ndarray, carry: np.ndarray,
           base: float, line: float) -> dict:
    """Спірмен, похибка в подіях проти двох базових рівнів і AUC «довга»."""
    from scipy.stats import spearmanr
    from sklearn.metrics import roc_auc_score

    err = float(np.median(np.abs(pred - truth)))
    base_err = float(np.median(np.abs(base - truth)))
    carry_err = float(np.median(np.abs(carry - truth)))
    long = (truth > line).astype(int)
    return {
        "spearman": float(spearmanr(pred, truth).statistic),
        "carry_spearman": float(spearmanr(carry, truth).statistic),
        "err": err, "median_err": base_err, "carry_err": carry_err,
        "gain": float(1 - err / base_err) if base_err else 0.0,
        "carry_gain": float(1 - carry_err / base_err) if base_err else 0.0,
        "auc": float(roc_auc_score(long, pred))
        if 0 < long.sum() < long.size else 0.5,
        "truth_median": float(np.median(truth)),
    }


def matrix_of(rows: list, size: int, kit: str) -> tuple:
    names = sorted(columns(rows[0], size, kit))
    x = np.array([[columns(row, size, kit)[name] for name in names]
                  for row in rows], dtype=float)
    y = np.array([row["events"] for row in rows], dtype=float)
    carry = np.array([row["prev_events"] for row in rows], dtype=float)
    return x, y, carry, names


def learn(rows: list, size: int, kit: str) -> dict:
    """Один набір входів на одному `K`, ділення за датою."""
    if not rows:
        return {"legs": 0}
    x, y, carry, names = matrix_of(rows, size, kit)
    train = np.array([row["part"] == "train" for row in rows])
    if train.sum() < 30 or (~train).sum() < 15:
        return {"legs": int((~train).sum())}
    pred = np.exp(model_of(x[train], y[train]).predict(x[~train]))
    line = float(np.median(y[train]))
    return {"window": size, "kit": kit, "columns": len(names),
            "legs": {"train": int(train.sum()), "val": int((~train).sum())},
            "line": line,
            **scored(pred, y[~train], carry[~train], line, line)}


def apart(rows: list, size: int, kit: str) -> dict:
    """Той самий замір відкладеною монетою: у тесті кожна нога."""
    if not rows:
        return {"legs": 0}
    x, y, carry, _ = matrix_of(rows, size, kit)
    coins = np.array([row["pair"] for row in rows])
    pred = np.full(len(rows), np.nan)
    base = np.full(len(rows), np.nan)
    for coin in sorted(set(coins)):
        train, test = coins != coin, coins == coin
        if train.sum() < 30 or test.sum() < 5:
            continue
        pred[test] = np.exp(model_of(x[train], y[train]).predict(x[test]))
        base[test] = float(np.median(y[train]))
    seen = np.isfinite(pred)
    if seen.sum() < 30:
        return {"legs": int(seen.sum())}
    return {"legs": int(seen.sum()),
            **scored(pred[seen], y[seen], carry[seen],
                     float(np.median(base[seen])),
                     float(np.median(y[seen])))}


def against_length(rows: list, size: int) -> dict:
    """Спірмен довжини ноги проти рівня фічі — у голові й по всій нозі."""
    from scipy.stats import spearmanr

    events = np.array([row["events"] for row in rows], dtype=float)
    out = {}
    for key in rows[0]["whole"]:
        for where in ("head", "whole"):
            level = np.array([(row["head"][size] if where == "head"
                               else row["whole"])[key] for row in rows],
                             dtype=float)
            good = np.isfinite(level)
            out.setdefault(key, {})[where] = float(
                spearmanr(events[good], level[good]).statistic) \
                if good.sum() > 2 else 0.0
    return out


def by_level(rows: list, size: int, key: str) -> list:
    """Рівень фічі в голові → яка нога виходить: групи по квантилях."""
    events = np.array([row["events"] for row in rows], dtype=float)
    level = np.array([row["head"][size][key] for row in rows], dtype=float)
    good = np.isfinite(level)
    events, level = events[good], level[good]
    order = np.argsort(level, kind="stable")
    groups = []
    for chunk in np.array_split(order, BINS):
        if chunk.size == 0:
            continue
        groups.append({"legs": int(chunk.size),
                       "level": float(np.median(level[chunk])),
                       "from": float(level[chunk].min()),
                       "to": float(level[chunk].max()),
                       "median": float(np.median(events[chunk])),
                       "q1": float(np.percentile(events[chunk], 25)),
                       "q3": float(np.percentile(events[chunk], 75))})
    return groups


def strongest(table: dict) -> str:
    """Фіча з найсильнішим звʼязком у голові ноги."""
    return max(table, key=lambda key: abs(table[key]["head"]))


def build(pairs=PAIRS, class_name: str = CLASS, heads=HEADS,
          root: Path | None = None, reduce: str = "mean") -> dict:
    rows = rows_of(pairs, class_name, root, reduce)
    table, marks, bins = {}, {}, {}
    for size in heads:
        picked = [row for row in rows if row["events"] >= size]
        if not picked:
            continue
        table[str(size)] = {
            "legs": len(picked),
            "val_legs": sum(row["part"] == "val" for row in picked),
            "median": float(np.median([row["events"] for row in picked])),
            "by_kit": {kit: {**learn(picked, size, kit),
                             "apart": apart(picked, size, kit)}
                       for kit in SETS}}
        marks[str(size)] = against_length(picked, size)
        best = strongest(marks[str(size)])
        bins[str(size)] = {"feature": best,
                           "groups": by_level(picked, size, best)}
    val = [row for row in rows if row["part"] == "val"]
    return {
        "script": "research/29-class7dd-legs/scripts/leg_length.py",
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "reduce": reduce, "normalise": "ранги по монеті, база — train",
        "curves": list(CURVES), "heads": list(heads), "sets": list(SETS),
        "seed": SEED, "trees": TREES, "val_from": "2026-08-14",
        "bins": BINS, "show": SHOW if str(SHOW) in table else
        (list(table)[0] if table else None),
        "pairs": list(pairs),
        "features": rows[0]["whole"] and sorted(
            {key.rsplit("_", 1)[0] for key in rows[0]["whole"]}) or [],
        "legs": {"all": len(rows), "val": len(val),
                 "train": len(rows) - len(val)},
        "by_window": table, "against_length": marks, "by_level": bins,
        "rows": [{key: row[key] for key in
                  ("pair", "leg", "kind", "from", "events", "part",
                   "prev_events")} for row in rows],
        "ready": bool(table),
    }


def show(report: dict) -> None:
    print(f"клас {report['class']}, ноги {report['legs']['all']} "
          f"(train {report['legs']['train']}, val {report['legs']['val']}), "
          f"монети {len(report['pairs'])}\n")
    print(f"{'K':>4} {'ніг':>5} {'набір':<10} | за датою: "
          f"{'Спірмен':>8} {'виграш':>7} {'AUC':>6} "
          f"| відкладена монета: {'Спірмен':>8} {'виграш':>7} "
          f"{'перенос':>8} {'AUC':>6}")
    for size in report["heads"]:
        block = report["by_window"].get(str(size))
        if not block:
            continue
        for kit in report["sets"]:
            one = block["by_kit"][kit]
            far = one.get("apart", {})
            if "err" not in one or "err" not in far:
                continue
            print(f"{size:>4} {block['legs']:>5} {kit:<10} | "
                  f"{one['spearman']:>+18.3f} {one['gain']:>+7.3f} "
                  f"{one['auc']:>6.3f} | {far['spearman']:>+26.3f} "
                  f"{far['gain']:>+7.3f} {far['carry_gain']:>+8.3f} "
                  f"{far['auc']:>6.3f}")
        print()
    show_size = str(report["show"])
    marks = report["against_length"].get(show_size, {})
    print(f"довжина ноги проти рівня фічі, K = {show_size}: "
          f"голова / вся нога")
    for key in sorted(marks, key=lambda one: -abs(marks[one]["head"]))[:8]:
        print(f"  {key:<28} {marks[key]['head']:+.3f} / "
              f"{marks[key]['whole']:+.3f}")
    bins = report["by_level"].get(show_size, {})
    if bins:
        print(f"\nрівень «{bins['feature']}» у перших {show_size} подіях "
              f"→ довжина ноги")
        for group in bins["groups"]:
            print(f"  {group['level']:+.3f}  ніг {group['legs']:>4}  "
                  f"медіана {group['median']:>7.0f}  "
                  f"({group['q1']:.0f} … {group['q3']:.0f})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--head", type=int, action="append", default=None)
    parser.add_argument("--reduce", default="mean",
                        choices=("mean", "sum", "last"))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name,
                   tuple(args.head or HEADS), args.data, args.reduce)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"leg_length_{args.class_name}"
    (args.out / f"{name}.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "rows"}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
