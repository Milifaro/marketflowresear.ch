"""Нога рядом на val: коли її виявлено і де їй скінчитись.

Дослідження: research/29-class7dd-legs/
Правила: rules/03-models.md, rules/05-visualization.md

Дві моделі дослідження на одному ряді, обидві на `клас210х10-1х7д/д`:

    детектор   етап 2 — «розворот стався всередині останніх `X` подій»,
               поріг із train (верхівка `TOP` його оцінок). Перше
               спрацювання всередині ноги — це момент, коли **нову ногу
               виявлено**
    прогноз    етап 3 — скільки подій у нозі буде всього, з рівня фіч у
               перших `K` подіях і з попередньої ноги. Прогноз, зроблений
               на момент виявлення, дає **подію, на якій нозі скінчитись**

Разом вони читаються як одна фраза: нова нога виявлена на події `N` після
півота, скінчиться приблизно на події `M`. Обидві моделі вчаться на
`train` (до 14.08) і показуються на `val`.

Прогноз береться на найбільшому `K`, що вже настав на момент виявлення;
якщо детектор спрацював раніше за перший `K`, точка прогнозу зсувається
на подію `K` — раніше моделі просто нема чого сказати.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/leg_length_series.json        — перелік монет і зведення
       results/leg_length_series_<PAIR>.json — ряд однієї монети

Запуск:
    python3 research/29-class7dd-legs/scripts/leg_length_series.py
    python3 research/29-class7dd-legs/scripts/leg_length_series.py --window 30
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import HOLE, PERIOD, THRESHOLD, legs_of, load  # noqa: E402
from leg_start import SEED, TREES, VAL_FROM, strict  # noqa: E402
import class_new_leg as detector  # noqa: E402
from leg_length import (CLASS, HEADS, columns, matrix_of,  # noqa: E402
                        model_of, rows_of)

RESULTS = RESEARCH_DIR / "results"

WINDOW = 39                # вікно детектора: робоча середина етапу 2
# Верхівка оцінок train, з якої береться поріг. На 1 % детектор мовчазний
# (етап 2: точність 0.618, але спрацювань одиниці), і на ряді видно
# майже нічого; 5 % дає точність 0.406 і сигнал на більшості ніг.
TOP = 0.05
KIT = "head_prev"          # найсильніший набір входів етапу 3
DIGITS = 6                 # знаків у ціні ряду


def utc(stamp: int) -> str:
    return datetime.fromtimestamp(int(stamp), timezone.utc) \
        .strftime("%Y-%m-%d %H:%M")


def watcher(pairs, class_name: str, size: int, root: Path | None,
            top: float = TOP):
    """Детектор нової ноги і його поріг, узятий на train."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    rows = detector.collect(pairs, class_name, size, root, holes="sum")
    train = rows["part"] == "train"
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=SEED)
    model.fit(rows["x"][train], rows["y"][train])
    inside = model.predict_proba(rows["x"][train])[:, 1]
    return model, float(np.quantile(inside, 1 - top))


def foreseer(rows: list, size: int, kit: str = KIT):
    """Прогноз довжини на одному `K`: модель, навчена на train-ногах."""
    picked = [row for row in rows
              if row["events"] >= size and row["part"] == "train"]
    if len(picked) < 30:
        return None
    x, y, _, names = matrix_of(picked, size, kit)
    return model_of(x, y), names


def told(models: dict, row: dict, size: int, kit: str = KIT) -> float:
    """Що модель `K` каже про цю ногу: скільки подій у ній буде."""
    model, names = models[size]
    seen = columns(row, size, kit)
    x = np.array([[seen[name] for name in names]], dtype=float)
    return float(np.exp(model.predict(x)[0]))


def scores(data: dict, class_name: str, size: int, model,
           length: int) -> np.ndarray:
    """Оцінка детектора на кожній події ряду; де її немає — NaN."""
    matrix, _, index = detector.features(data, size)
    out = np.full(length, np.nan)
    good = np.isfinite(matrix).all(axis=1)
    if good.any():
        out[index[good]] = model.predict_proba(matrix[good])[:, 1]
    return out


def legs_on(rows: list, pair: str) -> list:
    return sorted([row for row in rows if row["pair"] == pair],
                  key=lambda one: one["first"])


def series(pair: str, rows: list, models: dict, watch, edge: float,
           class_name: str, size: int, root: Path | None,
           heads=HEADS) -> dict:
    """Ряд однієї монети: ціна, оцінка детектора, довжина ноги і прогноз."""
    data = load(pair, class_name, root)
    smooth = ema(data["open"], PERIOD)
    total = len(data["t"])
    score = scores(data, class_name, size, watch, total)
    place = np.flatnonzero(data["t"] >= VAL_FROM)
    if place.size == 0:
        return {"ready": False, "pair": pair}
    low, high = int(place[0]), int(place[-1])

    def spot(index: int | None):
        """Місце події у вікні val: індекс на осі X ряду або None."""
        if index is None or not low <= index <= high:
            return None
        return int(index - low)

    passed = np.full(total, np.nan)
    guess = np.full(total, np.nan)
    truth = np.full(total, np.nan)
    told_legs = []
    for row in legs_on(rows, pair):
        first, last = row["first"], row["last"]
        if last < low or first > high:
            continue
        steps = np.arange(last - first + 1) + 1
        passed[first:last + 1] = steps
        truth[first:last + 1] = row["events"]
        # детектор: перша подія ноги, де оцінка перетнула поріг. Мітка
        # каже «розворот усередині останніх X подій», тому виявленням
        # рахується лише спрацювання в перших X подіях ноги — пізніші
        # перетини порога це вже хибні спрацювання всередині ноги.
        line = score[first:last + 1]
        fired = np.flatnonzero(np.isfinite(line) & (line >= edge))
        found = int(fired[0]) + 1 if fired.size else None
        false = int((fired > size).sum())
        if found is not None and found > size:
            found = None
        # прогноз: найбільший K, що вже настав на момент виявлення
        ready = [one for one in heads
                 if one in models and one <= row["events"]]
        if not ready:
            told_legs.append({"kind": row["kind"], "events": row["events"],
                              "from": row["from"], "to": row["to"],
                              "first_i": spot(first), "last_i": spot(last),
                              "detect_i": spot(first + found - 1)
                              if found else None,
                              "detect_after": found, "false": false,
                              "said": None})
            continue
        step = max([one for one in ready if found and one <= found]
                   or [ready[0]])
        said = told(models, row, step)
        at = first + max(step, found or step) - 1
        guess[at:last + 1] = said
        end = first + int(round(said)) - 1
        told_legs.append({
            "kind": row["kind"], "events": row["events"],
            "from": row["from"], "to": row["to"],
            "detect_after": found, "false": false,
            "detect_t": int(data["t"][first + found - 1]) if found else None,
            "said": round(said, 1), "said_after": int(at - first + 1),
            "said_t": int(data["t"][at]),
            "first_i": spot(first), "last_i": spot(last),
            "detect_i": spot(first + found - 1) if found else None,
            "said_i": spot(at), "end_i": spot(end),
            "end_t": int(data["t"][min(end, total - 1)]),
            "end_over": int(max(0, end - (total - 1))),
            "head": step, "err": round(said - row["events"], 1)})
    keep = np.arange(low, high + 1)
    return {
        "ready": True, "pair": pair, "events": int(keep.size),
        "threshold": THRESHOLD, "period": PERIOD, "class": class_name,
        "window": size, "edge": edge, "kit": KIT, "heads": list(heads),
        "from_utc": utc(data["t"][low]), "to_utc": utc(data["t"][high]),
        "t": data["t"][keep].astype(int).tolist(),
        "price": [round(float(one), DIGITS) for one in smooth[keep]],
        "score": [round(float(one), 4) if np.isfinite(one) else None
                  for one in score[keep]],
        "passed": [float(one) if np.isfinite(one) else None
                   for one in passed[keep]],
        "guess": [float(one) if np.isfinite(one) else None
                  for one in guess[keep]],
        "truth": [float(one) if np.isfinite(one) else None
                  for one in truth[keep]],
        "pivots": [{"t": row["to"],
                    "ema": round(float(smooth[row["last"]]), DIGITS),
                    "kind": "high" if row["kind"] == "up" else "low"}
                   for row in legs_on(rows, pair)
                   if low <= row["last"] <= high],
        "legs": told_legs,
    }


def tally(legs: list) -> dict:
    """Зведення по монеті: скільки ніг виявлено і як точний прогноз."""
    seen = [one for one in legs if one.get("detect_after")]
    said = [one for one in legs if one.get("said")]
    return {
        "legs": len(legs), "detected": len(seen),
        "false": int(sum(one.get("false", 0) for one in legs)),
        "detect_median": float(np.median([one["detect_after"]
                                          for one in seen])) if seen else 0.0,
        "told": len(said),
        "err_median": float(np.median([abs(one["err"]) for one in said]))
        if said else 0.0,
        "err_share": float(np.median([abs(one["err"]) / one["events"]
                                      for one in said])) if said else 0.0,
    }


def build(pairs=PAIRS, class_name: str = CLASS, size: int = WINDOW,
          heads=HEADS, root: Path | None = None, out: Path = RESULTS,
          top: float = TOP) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    rows = rows_of(pairs, class_name, root, "mean")
    models = {one: found for one in heads
              if (found := foreseer(rows, one)) is not None}
    watch, edge = watcher(pairs, class_name, size, root, top)
    listed = []
    for pair in pairs:
        body = series(pair, rows, models, watch, edge, class_name, size,
                      root, heads)
        if not body["ready"]:
            continue
        (out / f"leg_length_series_{pair}.json").write_text(
            json.dumps(strict(body), ensure_ascii=False, allow_nan=False),
            encoding="utf-8")
        listed.append({"pair": pair, "events": body["events"],
                       "from_utc": body["from_utc"], "to_utc": body["to_utc"],
                       **tally(body["legs"])})
    return {
        "script": "research/29-class7dd-legs/scripts/leg_length_series.py",
        "ready": bool(listed), "class": class_name, "window": size,
        "seconds": size * 210, "edge": edge, "top": top, "kit": KIT,
        "heads": list(heads), "threshold": THRESHOLD, "period": PERIOD,
        "hole_hours": HOLE / 3600, "seed": SEED, "val_from": "2026-08-14",
        "pairs": [one["pair"] for one in listed], "coins": listed,
    }


def show(report: dict) -> None:
    print(f"детектор: вікно {report['window']} подій, поріг "
          f"{report['edge']:.4f} (верхівка {report['top'] * 100:g} % train)")
    print(f"прогноз: набір {report['kit']}, K з "
          f"{', '.join(str(one) for one in report['heads'])}\n")
    print(f"{'монета':<10} {'ніг':>5} {'виявлено':>9} {'подій до':>9} "
          f"{'хибних':>7} {'прогноз':>8} {'похибка':>8} {'частка':>7}")
    for one in report["coins"]:
        print(f"{one['pair']:<10} {one['legs']:>5} {one['detected']:>9} "
              f"{one['detect_median']:>9.0f} {one['false']:>7} "
              f"{one['told']:>8} {one['err_median']:>8.0f} "
              f"{one['err_share']:>7.2f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--head", type=int, action="append", default=None)
    parser.add_argument("--top", type=float, default=TOP)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.window,
                   tuple(args.head or HEADS), args.data, args.out, args.top)
    (args.out / "leg_length_series.json").write_text(
        json.dumps(strict(report), indent=2, ensure_ascii=False,
                   allow_nan=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'leg_length_series.json'}")


if __name__ == "__main__":
    main()
