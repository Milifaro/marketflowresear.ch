"""Профіль ноги на фічах класу: де в нозі сидить кожна фіча.

Дослідження: research/29-class7dd-legs/
Правила: rules/01-data-and-db.md → Опис класів, rules/02-markup.md

Етап 1 дослідження 28 міряв ціну: рух ноги зігзага 2.3 % збирається на її
краях. Тут той самий хід іде по **всіх фічах класу** —
`клас210х10-1х7д/д` (шість відношень похідних сусідніх рівнів плюс похідна
ціни). Питання те саме: чи є в фічі край ноги, чи вона однакова всюди, чи
міняє це напрямок і довжина ноги.

Відмінність від ціни: рух ціни додається і має скінченний розкид, а
відношення похідних — ні. Ділення на майже нуль дає хвости в 1e12, і
середнє по десятині там не значить нічого. Тому кожна фіча перед замірами
переводиться **в ранги всередині монети** (0…1) — три криві по десятинах:

    ранг      ранг напрямленої величини (v × напрямок ноги), центрований:
              0 — усе як у середньому по монеті, + — вище за ряд
    амплітуда ранг |v| — наскільки подія екстремальна за модулем
    сплеск    частка подій десятини, що входять у топ-5 % |v| монети
              (рівно 0.05, якщо сплески розкидані по нозі рівно)

Хід:

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 % -> ноги
    -> десятини -> згортка фічі по блоках події -> ранги по монеті
    -> середнє по десятині кожної ноги -> середнє по ногах

Ноги з дірою понад годину викидаються — як в етапі 1.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/class_edge_profile_<клас>.json       — усе, з переліком ніг
       results/class_edge_profile_<клас>.meta.json  — те саме без ніг

Запуск:
    python3 research/29-class7dd-legs/scripts/class_edge_profile.py
    python3 research/29-class7dd-legs/scripts/class_edge_profile.py \
        --class class210x10x7 --reduce mean
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
# розмітка ноги береться з етапу 1 дослідження 28 — той самий хід
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS  # noqa: E402
from edge_profile import (DECILES, EDGES, LENGTH_BINS, MIDDLE,  # noqa: E402
                          HOLE, PERIOD, THRESHOLD, legs_of, load, value)

RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
HOT = 0.95                 # межа сплеску: топ-5 % подій монети за |v|
CURVES = ("rank", "amplitude", "hot")
BASE = {"rank": 0.0, "amplitude": 0.5, "hot": 1 - HOT}


def ranks(column: np.ndarray, inside: np.ndarray) -> np.ndarray:
    """Ранг величини серед подій ніг цієї монети, 0…1. Не число — NaN."""
    out = np.full(column.shape, np.nan)
    good = inside & np.isfinite(column)
    count = int(good.sum())
    if count < 2:
        return out
    order = np.argsort(column[good], kind="stable")
    place = np.empty(count, dtype=float)
    place[order] = np.arange(count, dtype=float)
    out[good] = (place + 0.5) / count
    return out


def curves_of(column: np.ndarray, dirs: np.ndarray) -> dict:
    """Три криві по події: ранг напрямленої, ранг модуля і сплеск."""
    inside = dirs != 0
    size = np.abs(column)
    good = inside & np.isfinite(size)
    line = np.quantile(size[good], HOT) if good.any() else np.inf
    hot = np.where(good, (size >= line).astype(float), np.nan)
    return {"rank": ranks(column * dirs, inside) - 0.5,
            "amplitude": ranks(size, inside),
            "hot": hot}


def leg_rows(legs: list, curves: dict, pair: str) -> list:
    """Нога за ногою: середнє кожної кривої по десятинах ноги."""
    rows = []
    for leg in legs:
        first, last = leg["first"], leg["last"]
        length = last - first + 1
        parts = np.minimum(
            np.floor(np.arange(length) / length * DECILES) + 1,
            DECILES).astype(int)
        row = {"pair": pair, "leg": leg["leg"], "kind": leg["kind"],
               "events": leg["events"], "from": leg["from"], "to": leg["to"],
               "move": leg["move"] * (1 if leg["kind"] == "up" else -1),
               "hole_hours": leg["hole_hours"]}
        for name in CURVES:
            piece = curves[name][first:last + 1]
            row[name] = [mean_of(piece[parts == part])
                         for part in range(1, DECILES + 1)]
            row[f"leg_{name}"] = mean_of(piece)
        rows.append(row)
    return rows


def mean_of(piece: np.ndarray) -> float:
    good = np.isfinite(piece)
    return float(piece[good].mean()) if good.any() else float("nan")


def profile(rows: list) -> dict:
    """Криві по десятинах і краї проти середини на кожній з них."""
    if not rows:
        return {"legs": 0}
    edges = [part - 1 for part in EDGES]
    middle = [part - 1 for part in MIDDLE]
    block = {"legs": len(rows),
             "events": int(sum(row["events"] for row in rows))}
    for name in CURVES:
        table = np.array([row[name] for row in rows], dtype=float)
        mean = np.nanmean(table, axis=0)
        spread = np.nanstd(table, axis=0)
        count = np.maximum(np.isfinite(table).sum(axis=0), 1)
        block[name] = [round(float(v), 6) for v in mean]
        block[f"{name}_err"] = [round(float(v), 6)
                                for v in spread / np.sqrt(count)]
        block[f"{name}_edges"] = float(mean[edges].mean())
        block[f"{name}_middle"] = float(mean[middle].mean())
        block[f"{name}_gap"] = float(
            (mean[edges].mean() - mean[middle].mean())
            / (float(np.nanmean(spread)) or 1.0))
        block[f"{name}_t"] = float(
            (mean[edges].mean() - mean[middle].mean())
            / (float(np.nanmean(spread / np.sqrt(count))) or 1.0))
    return block


def by_length(rows: list, parts: int = LENGTH_BINS) -> list:
    """Той самий профіль у розрізі довжини ноги."""
    events = np.array([row["events"] for row in rows], dtype=float)
    bounds = [np.percentile(events, 100 * i / parts) for i in range(parts + 1)]
    groups = []
    for index in range(parts):
        low, high = bounds[index], bounds[index + 1]
        picked = [row for row in rows if low <= row["events"] <= high] \
            if index == parts - 1 else \
            [row for row in rows if low <= row["events"] < high]
        groups.append({"from": float(low), "to": float(high),
                       **profile(picked)})
    return groups


def against_length(rows: list) -> dict:
    """Кількість подій ноги проти рівня фічі в ній."""
    from scipy.stats import spearmanr
    if len(rows) < 3:
        return {"legs": len(rows)}
    events = np.array([row["events"] for row in rows], dtype=float)
    block = {"legs": len(rows)}
    for name in CURVES:
        level = np.array([row[f"leg_{name}"] for row in rows], dtype=float)
        good = np.isfinite(level)
        block[name] = float(spearmanr(events[good], level[good]).statistic) \
            if good.sum() > 2 else 0.0
    order = np.argsort(events)
    block["bins"] = [
        {"events": float(np.median(events[chunk])),
         "amplitude": mean_of(np.array([rows[i]["leg_amplitude"]
                                        for i in chunk])),
         "legs": int(chunk.size)}
        for chunk in np.array_split(order, 8)]
    return block


def build(pairs=PAIRS, class_name: str = CLASS, reduce: str = "mean",
          root: Path | None = None) -> dict:
    features, rows, legs_seen = [], {}, 0
    for pair in pairs:
        data = load(pair, class_name, root)
        _, legs = legs_of(data)
        legs_seen += len(legs)
        kept = [leg for leg in legs if leg["hole_hours"] * 3600 <= HOLE]
        dirs = np.zeros(len(data["t"]))
        for leg in kept:
            dirs[leg["first"]:leg["last"] + 1] = \
                1 if leg["kind"] == "up" else -1
        features = features or data["features"]
        for name in features:
            curves = curves_of(value(data, name, reduce), dirs)
            rows.setdefault(name, []).extend(leg_rows(kept, curves, pair))
    count = len(rows[features[0]]) if features else 0
    return {
        "script": "research/29-class7dd-legs/scripts/class_edge_profile.py",
        "threshold": THRESHOLD, "period": PERIOD, "deciles": DECILES,
        "class": class_name, "reduce": reduce, "normalise": "ранги по монеті",
        "hot": 1 - HOT, "curves": list(CURVES), "base": BASE,
        "edges": list(EDGES), "middle": list(MIDDLE), "hole_hours": HOLE / 3600,
        "pairs": list(pairs), "features": list(features),
        "legs": count, "dropped_legs": legs_seen - count,
        "by_feature": {
            name: {
                "all": profile(rows[name]),
                "by_kind": {kind: profile([row for row in rows[name]
                                           if row["kind"] == kind])
                            for kind in ("up", "down")},
                "by_pair": {pair: profile([row for row in rows[name]
                                           if row["pair"] == pair])
                            for pair in pairs},
                "by_length": by_length(rows[name]),
                "against_length": against_length(rows[name]),
            } for name in features},
        "rows": {name: rows[name] for name in features},
        "ready": bool(count),
    }


def show(report: dict) -> None:
    print(f"клас {report['class']}, ноги {report['legs']} "
          f"(відкинуто з дірами {report['dropped_legs']}), "
          f"монети {len(report['pairs'])}, згортка події — {report['reduce']}, "
          f"нормалізація — {report['normalise']}")
    titles = {"rank": "ранг напрямленої величини (0 — рівень ряду)",
              "amplitude": "ранг модуля (0.5 — рівень ряду)",
              "hot": "частка сплесків, топ-5 % |v| (0.05 — рівно по нозі)"}
    for curve in CURVES:
        print(f"\n{titles[curve]}")
        for name in report["features"]:
            block = report["by_feature"][name]["all"]
            line = " ".join(f"{v:+.3f}" for v in block[curve])
            print(f"  {name:<20} {line}   краї {block[f'{curve}_edges']:+.3f} "
                  f"середина {block[f'{curve}_middle']:+.3f} "
                  f"(t {block[f'{curve}_t']:+.1f})")
    print("\nноги вгору проти ніг вниз, ранг напрямленої: краї / середина")
    for name in report["features"]:
        block = report["by_feature"][name]["by_kind"]
        print(f"  {name:<20} вгору {block['up']['rank_edges']:+.3f} / "
              f"{block['up']['rank_middle']:+.3f}   "
              f"вниз {block['down']['rank_edges']:+.3f} / "
              f"{block['down']['rank_middle']:+.3f}")
    print("\nдовжина ноги проти рівня фічі (Спірмен: ранг · амплітуда · сплеск)")
    for name in report["features"]:
        block = report["by_feature"][name]["against_length"]
        print(f"  {name:<20} {block['rank']:+.3f} · {block['amplitude']:+.3f} "
              f"· {block['hot']:+.3f}")


def strict(item):
    """JSON не тримає NaN: десятина без жодного числа стає null."""
    if isinstance(item, float):
        return item if np.isfinite(item) else None
    if isinstance(item, dict):
        return {key: strict(value) for key, value in item.items()}
    if isinstance(item, list):
        return [strict(value) for value in item]
    return item


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--class", dest="class_name", default=CLASS)
    parser.add_argument("--reduce", default="mean",
                        choices=("mean", "sum", "last"))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.class_name, args.reduce,
                   args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    name = f"class_edge_profile_{args.class_name}"
    (args.out / f"{name}.json").write_text(
        json.dumps(strict(report), ensure_ascii=False, allow_nan=False),
        encoding="utf-8")
    meta = {key: item for key, item in report.items() if key != "rows"}
    (args.out / f"{name}.meta.json").write_text(
        json.dumps(strict(meta), indent=2, ensure_ascii=False,
                   allow_nan=False),
        encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'{name}.json'}")


if __name__ == "__main__":
    main()
