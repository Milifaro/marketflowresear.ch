"""Нога як послідовність подій: скільки подій лишилось до її кінця.

Дослідження: research/29-class7dd-legs/
Правила: rules/01-data-and-db.md → Опис класів, rules/02-markup.md

Етап 3 питав з голови ноги: «скільки подій у нозі буде всього». Тут
питання ставиться **на кожній події**: нога вже триває, події подаються
одна за одною — скільки їх лишилось до півота. Чим далі йде нога, тим
більше історії в моделі, і на останніх подіях вона бачить майже все.

## Що заходить у крок

Усі класи проєкту, які лежать на **сітці подій 210 с** (`t_start`) і є
в кожної монети — сім класів, 43 фічі разом. Кожна фіча згортається по
блоках події у три числа: середнє, розкид і остання плашка. Так у крок
заходить `43 × 3 = 129` каналів, і форма події всередині 210 секунд
частково лишається. Ключ `--blocks` подає натомість **усі блоки як є**
(410 каналів) — згортка тоді не робиться взагалі.

## Нормалізація: `--norm`

Фічі відношень (`клас210х10-1х7д/д` і подібні) — це ділення похідних:
у ряді трапляються значення до `1e21`. Сирими їх подавати не можна, і
монети з різними рівнями на одну шкалу не лягають. Є два способи, і
вони роблять різні речі:

    rank    ранг усередині монети, база — тільки події `train`. Порядок
            зберігається, **все інше зникає**: і масштаб, і відстань між
            значеннями. Це квантування: −686 200 і −7432 стають двома
            сусідніми числами. Пропуск заходить як 0.5
    asinh99 `asinh(v / s) / k`, `s` — **99-й перцентиль** `|v|` серед
            train-подій монети, `k` — розкид того, що вийшло. Одиниця
            береться по хвосту, тому 99 % подій лягають у лінійну
            частину `asinh` і їхні різниці проходять **як є**; стискається
            тільки останній відсоток. Ділення на `k` афінне — різниць
            воно не чіпає, а вхід ставить у межі одиниці. Замір:
            `norm_check.py`
    gauss   **розподіл**: канал перекладається у стандартний нормальний.
            Місце значення в черзі train-подій (та сама база, що в `rank`)
            подається в обернену нормальну функцію розподілу
            `z = Φ⁻¹(r)`, тому в кожного каналу після перетворення
            середнє 0, розкид 1 і форма дзвона — незалежно від того, чим
            фіча була: відношенням похідних із хвостом у `1e21` чи
            обʼємом. Порядок зберігається строго, хвіст перестає бути
            хвостом, а середина ряду розтягується там, де подій густо.
            Пропуск заходить як 0 — середина розподілу
    asinh   `asinh(v / s)`, `s` — медіана `|v|` серед train-подій монети.
            Функція непарна і **строго зростає**, тому нічого не склеює:
            перетворення оборотне, дані не псуються. Біля нуля вона
            лінійна — дрібні зміни фічі проходять як є, у своїх одиницях
            `s`. На хвості переходить у логарифм: `4e21` стає числом
            близько 50, а не нескінченністю. Знак лишається. Пропуск
            заходить як 0 — «руху не було»

`asinh` зберігає і рівень фічі, і її зміну; `rank` зберігає тільки
місце в черзі. За замовчуванням — `asinh99`: на справжніх каналах він
лишає 99.1 % різниць недоторканими проти 50.6 % у `asinh` і 0 % у
`rank`, склеює 0.03 % значень проти 12.97 % у рангів, і фіча з нього
відновлюється з похибкою `3e-16`.

## Ціль

`left` — скільки подій лишилось до кінця ноги: на останній події ноги
це 0, на першій — довжина ноги мінус один. Мережа вчиться на `log1p`,
похибка рахується в подіях.

## Памʼять через півоти

`--history N` веде в послідовність ще `N` **попередніх ніг** перед своєю:
памʼять LSTM заходить у свою ногу вже наповненою, а не з нуля. Події
попередніх ніг ідуть **тільки в памʼять** — ціль на них замаскована, у
похибку вони не потрапляють. Попередні ноги беруться суцільно, номер до
номера; якщо їх менше за `N`, береться скільки є.

Щоб ряд не роздувався, події зберігаються **один раз**: `x` — суцільний
ряд монети, а нога тримає лише свої межі (`hist`, `first`, `last`).
Історія сусідніх ніг — це той самий шматок ряду, а не його копія.

Поруч із каналами лежать `t` і `price` — час події і ема10 ціни. Вони в
навчання не заходять: це підпис під видачею, щоб її можна було покласти
на ряд і подивитись очима.

## Памʼять

Ряд каналів **не тримається в оперативній памʼяті** — ні тут, ні в
навчанні. Він пишеться в `legleft_<tag>.npy` через `open_memmap` монета
за монетою і читається з диска шматками: у навчання їде тільки батч.
Тип каналів іде за нормалізацією: ранги лежать у `[0, 1]`, там вистачає
`float16`, а `asinh` тримає дрібні зміни біля нуля і пишеться `float32`
— половинна точність з'їла б третій знак, тобто саме те, що зберігаємо. Побудова теж іде класом за класом: у памʼяті одночасно
лежить один клас однієї монети, а не весь датасет.

## Розбиття

Нога цілком по один бік межі: закінчилась до 14.08 — `train`, після —
`val`. Ноги з дірою в ряді понад годину не беруться — як в етапах 1–3.

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: ../data/legleft_<tag>.npy — канали подій, `float16`, читається з диска
       ../data/legleft_<tag>.npz — межі ніг, час і ціна ряду

Запуск:
    python3 research/29-class7dd-legs/scripts/legleft_data.py
    python3 research/29-class7dd-legs/scripts/legleft_data.py --history 4
    python3 research/29-class7dd-legs/scripts/legleft_data.py --blocks
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.special import ndtri

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
EDGE_SCRIPTS = PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(EDGE_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from build_class210x10x7dc import PAIRS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from edge_profile import (DATASETS, HOLE, PERIOD, THRESHOLD,  # noqa: E402
                          legs_of, load)
from leg_start import VAL_FROM  # noqa: E402

DATA = RESEARCH_DIR / "data"
GRID = "t_start"           # сітка подій: 210 с на подію
LENGTH = 3000              # стеля довжини послідовності; лишається її хвіст
HISTORY = 0                # скільки попередніх ніг заходить у памʼять
STATS = ("mean", "std", "last")
NORMS = ("asinh99", "asinh", "gauss", "rank")
NORM = "asinh99"
TAIL = 99                  # перцентиль |v|, який стає одиницею каналу
WIDTH = 90                 # перцентиль |y|, яким видача ставиться в одиницю
EDGE = 1e-6                # відступ від країв рангу, щоб `Φ⁻¹` не дав ∞
FILL = {"rank": 0.5,       # ранг для пропуску: рівно посередині
        "asinh": 0.0,      # asinh: нуль — «руху не було»
        "asinh99": 0.0,
        "gauss": 0.0}      # розподіл: нуль — середина дзвона
UP = 1.0                   # канал напрямку: нога вгору
DOWN = 0.0                 # і нога вниз
CLOCK = 3000               # чим діляться лічильники: стеля довжини ноги
WINDOW = 150               # вікно відповіді: стільки подій після півота
# Ранги лежать у [0, 1] — там досить половинної точності. `asinh` тримає
# дрібні зміни біля нуля, і float16 з'їв би саме їх, тому float32.
DTYPE = {"rank": np.float16, "asinh": np.float32,
         "asinh99": np.float32, "gauss": np.float32}


def classes_on(pairs, root: Path | None = None) -> list:
    """Класи на сітці `t_start`, які є в кожної монети."""
    folder = root or DATASETS
    common = None
    for pair in pairs:
        names = {one.name for one in (folder / pair).iterdir()
                 if one.is_dir()}
        common = names if common is None else (common & names)
    found = []
    for name in sorted(common or ()):
        try:
            with np.load(folder / pairs[0] / name / "train.npz") as store:
                if GRID in store and store["x"].ndim == 3:
                    found.append(name)
        except (FileNotFoundError, KeyError):
            continue
    return found


def channels(data: dict, name: str, blocks: bool) -> tuple:
    """Подія одного класу в канали: або всі блоки, або три числа на фічу."""
    values = data["x"]
    names, columns = [], []
    for number, feature in enumerate(data["features"]):
        column = values[..., number]
        if blocks:
            for block in range(column.shape[1]):
                names.append(f"{name}:{feature}:b{block + 1}")
                columns.append(column[:, block])
            continue
        for stat in STATS:
            names.append(f"{name}:{feature}:{stat}")
            columns.append({"mean": column.mean(axis=1),
                            "std": column.std(axis=1),
                            "last": column[:, -1]}[stat])
    return names, columns


def ranked(column: np.ndarray, train: np.ndarray) -> np.ndarray:
    """Ранг каналу серед train-подій монети, 0…1; пропуск — 0.5."""
    base = np.sort(column[train & np.isfinite(column)])
    out = np.full(column.shape, FILL["rank"], dtype=np.float32)
    if base.size < 2:
        return out
    good = np.isfinite(column)
    out[good] = ((np.searchsorted(base, column[good], side="left") + 0.5)
                 / base.size).astype(np.float32)
    return out


def spread(column: np.ndarray, train: np.ndarray) -> np.ndarray:
    """Розподіл: канал у стандартний нормальний, `z = Φ⁻¹(r)`.

    Місце значення в черзі train-подій — це його ймовірність `r`, а
    обернена нормальна функція розподілу переводить рівномірне `r` у
    дзвін. Тому канал після перетворення має середнє 0, розкид 1 і
    однакову форму в усіх фіч: відношення похідних із хвостом у `1e21`
    і обʼєм лягають на одну шкалу без ручної одиниці.

    Порядок строго зберігається — `Φ⁻¹` зростає, — а густа середина
    ряду розтягується: там, де подій багато, сусідні значення розходяться
    далі, ніж у рангу. Краї підтискаються на `EDGE`, інакше найбільше
    значення дало б `+∞`.
    """
    rank = ranked(column, train)
    out = np.asarray(ndtri(np.clip(rank, EDGE, 1.0 - EDGE)),
                     dtype=np.float32)
    out[~np.isfinite(column)] = FILL["gauss"]
    return out


def scale_of(column: np.ndarray, train: np.ndarray,
             tail: int | None = None) -> float:
    """Своя одиниця каналу з ненульових train-подій.

    Без `tail` — медіана `|v|`; з `tail` — той перцентиль `|v|`.
    Перцентиль, а не середнє: на відношеннях похідних середнє забирає
    собі один блок із майже нульовим знаменником. Нулі не рахуються —
    інакше канал, де половина подій рівно нульова, дістав би `s = 0`.
    """
    values = np.abs(column[train & np.isfinite(column)])
    values = values[values > 0]
    if not values.size:
        return 1.0
    one = float(np.median(values) if tail is None
                else np.percentile(values, tail))
    return one if np.isfinite(one) and one > 0 else 1.0


def curved(column: np.ndarray, train: np.ndarray) -> np.ndarray:
    """`asinh(v / s)` — знак, порядок і дрібні зміни лишаються цілими.

    `asinh` строго зростає, тому два різні числа лишаються різними:
    на відміну від рангу, перетворення нічого не склеює і оборотне.
    Біля нуля воно лінійне (`asinh(x) ≈ x`), тобто зміна фічі на дрібну
    величину проходить у своїх одиницях `s`; далеко — логарифмічне
    (`≈ sign · ln(2|v|/s)`), тому хвіст у `1e21` стає числом близько 50.
    """
    out = np.full(column.shape, FILL["asinh"], dtype=np.float32)
    good = np.isfinite(column)
    if not good.any():
        return out
    out[good] = np.arcsinh(column[good] / scale_of(column, train))
    return out


def wide(column: np.ndarray, train: np.ndarray,
         tail: int = TAIL) -> np.ndarray:
    """`asinh(v/s)/k` з одиницею по хвосту: різниці проходять майже всі.

    `s` — 99-й перцентиль `|v|`, тому 99 % подій лежать у лінійній
    частині `asinh`, де множник різниць вище 0.7, і зміна фічі йде крізь
    перетворення як є. Стискається тільки останній відсоток — той, де
    відношення похідних вилітає в мільйони.

    `k` — 90-й перцентиль `|y|` серед train-подій. Ділення на нього
    афінне: воно не чіпає ні порядку, ні відношення різниць, а вхід
    мережі ставить у робочі межі. Замір на справжніх каналах
    (`norm_check.py`) дає при цьому медіану входу 0.14, 99-й перцентиль
    5.2 і максимум 21 — мережа бачить і середину ряду, і хвіст, і жодне
    з цього не в тисячних і не в тисячах.
    """
    out = np.full(column.shape, FILL["asinh99"], dtype=np.float32)
    good = np.isfinite(column)
    if not good.any():
        return out
    out[good] = np.arcsinh(column[good] / scale_of(column, train, tail))
    return out / scale_of(out, train & good, WIDTH)


def normal(column: np.ndarray, train: np.ndarray,
           norm: str = NORM) -> np.ndarray:
    """Канал у шкалу мережі: `asinh` зберігає зміни, `gauss` — розподіл."""
    if norm == "rank":
        return ranked(column, train)
    if norm == "asinh":
        return curved(column, train)
    if norm == "asinh99":
        return wide(column, train)
    if norm == "gauss":
        return spread(column, train)
    raise ValueError(f"невідома нормалізація: {norm}")


def titles_of(pair: str, names: list, blocks: bool,
              root: Path | None, clock: bool = False) -> list:
    """Імена каналів: один клас за раз, нічого не тримаємо."""
    found = []
    for name in names:
        data = load(pair, name, root)
        found.extend(channels(data, name, blocks)[0])
        del data
    found = found + ["leg:up"]
    return found + ["leg:step", "leg:guess", "leg:open"] \
        if clock else found


def coin(pair: str, names: list, blocks: bool, root: Path | None,
         into: np.ndarray | None = None, at: int = 0,
         norm: str = NORM, clock: bool = False) -> dict:
    """Ряд однієї монети: ноги, час, ціна і канали, записані в `into`.

    Канали пишуться **класом за разом** прямо у виданий шматок памʼяті
    (зазвичай це memmap на диску), тому одночасно в памʼяті лежить один
    клас однієї монети, а не весь датасет.
    """
    row = load(pair, names[0], root)
    stamps = row["t"]
    train = stamps < VAL_FROM
    _, legs = legs_of(row)
    kept = [leg for leg in legs if leg["hole_hours"] * 3600 <= HOLE]
    price = ema(row["open"], PERIOD).astype(np.float32)
    del row
    place = 0
    for name in names:
        data = load(pair, name, root)
        if not np.array_equal(stamps, data["t"]):
            # класи однієї сітки, але ряд може бути коротший: беремо спільні
            order = np.searchsorted(data["t"], stamps)
            keep = (order < len(data["t"])) & (data["t"][
                np.minimum(order, len(data["t"]) - 1)] == stamps)
            if not keep.all():
                raise ValueError(f"{pair}: {name} не лягає на спільний ряд")
            data = {**data, "x": data["x"][order]}
        found, columns = channels(data, name, blocks)
        for number, column in enumerate(columns):
            if into is not None:
                into[at:at + len(stamps), place + number] = \
                    normal(np.asarray(column, dtype=float), train, norm)
        place += len(found)
        del data, columns
    # напрямок ноги окремим каналом: він причинний (нога вже почалась)
    # і дає памʼяті бачити, що півот був
    if into is not None:
        into[at:at + len(stamps), place] = FILL[norm]
        for leg in kept:
            into[at + leg["first"]:at + leg["last"] + 1, place] = \
                UP if leg["kind"] == "up" else DOWN
        if clock:               # лічильник, його відповідь і вікно
            step, guess, inside = clock_of(kept, len(stamps), train)
            into[at:at + len(stamps), place + 1] = step
            into[at:at + len(stamps), place + 2] = guess
            into[at:at + len(stamps), place + 3] = inside
    return {"pair": pair, "t": stamps, "price": price, "legs": kept,
            "events": len(stamps)}


def clock_of(legs: list, count: int, train: np.ndarray) -> tuple:
    """Три причинні канали: лічильник подій, його відповідь і вікно.

    `step` — скільки подій минуло від півота на цій події своєї ноги.
    Число причинне: нога вже почалась, майбутнього в ньому немає.

    `guess` — медіана залишку серед **train**-подій із тим самим номером
    кроку. Це та сама база «лічильник», з якою порівнюється мережа, тільки
    подана їй на вхід: маючи її готовою, мережа може не рахувати кроки
    сама, а виправляти цю відповідь класом.

    `open` — одиниця, поки крок менший за `WINDOW`, і нуль після. Межа
    вікна — це умова задачі, а не прогноз: ми самі задали її лічильником,
    тому мережа має право бачити її готовою. Інакше їй доводиться
    вибудовувати сходинку на логарифмічному каналі, де крок 149 і 150
    відрізняються на тисячні.

    Лічильник і його відповідь стискаються `log1p` і діляться на
    `log1p(CLOCK)`, тому лягають у межі одиниці й не тягнуть за собою
    хвіст довгих ніг.
    """
    step = np.zeros(count, dtype=np.float32)
    left = np.full(count, np.nan, dtype=np.float32)
    for leg in legs:
        first, last = leg["first"], leg["last"]
        step[first:last + 1] = np.arange(last - first + 1)
        left[first:last + 1] = np.arange(last - first, -1, -1)
    # база рахується тільки по train-подіях: val у неї не заглядає
    base = {}
    good = np.isfinite(left) & train
    for one in np.unique(step[good]):
        pick = good & (step == one)
        if pick.any():
            base[float(one)] = float(np.median(left[pick]))
    guess = np.zeros(count, dtype=np.float32)
    if base:
        keys = np.array(sorted(base))
        values = np.array([base[one] for one in keys])
        place = np.clip(np.searchsorted(keys, step), 0, len(keys) - 1)
        guess = values[place].astype(np.float32)
    scale = float(np.log1p(CLOCK))
    inside = np.zeros(count, dtype=np.float32)
    for leg in legs:
        first, last = leg["first"], leg["last"]
        inside[first:min(first + WINDOW, last + 1)] = 1.0
    return (np.log1p(step) / scale).astype(np.float32), \
        (np.log1p(np.maximum(guess, 0.0)) / scale).astype(np.float32), \
        inside


def history_of(legs: list, number: int, deep: int) -> tuple:
    """Початок історії: `deep` суцільних ніг перед цією, скільки є."""
    first = legs[number]["first"]
    place = number
    for _ in range(deep):
        if place == 0 or legs[place - 1]["leg"] != legs[place]["leg"] - 1:
            break
        place -= 1
        first = legs[place]["first"]
    return first, number - place


def size_of(pair: str, names: list, root: Path | None) -> int:
    """Скільки подій у монеті — без читання каналів."""
    data = load(pair, names[0], root)
    count = len(data["t"])
    del data
    return count


def build(pairs=PAIRS, blocks: bool = False, root: Path | None = None,
          length: int = LENGTH, history: int = HISTORY,
          into: Path | None = None, norm: str = NORM,
          clock: bool = False) -> dict:
    """Датасет ніг. `into` — куди писати канали; без нього все в памʼяті."""
    names = classes_on(pairs, root)
    titles = titles_of(pairs[0], names, blocks, root, clock)
    counts = [size_of(pair, names, root) for pair in pairs]
    table = memmap_of(into, sum(counts), len(titles), norm) \
        if into is not None \
        else np.zeros((sum(counts), len(titles)), dtype=DTYPE[norm])
    rows, stamps, prices, offset = [], [], [], 0
    for pair, count in zip(pairs, counts):
        found = coin(pair, names, blocks, root, table, offset, norm,
                     clock)
        stamps.append(found["t"].astype(np.int64))
        prices.append(found["price"])
        legs = found["legs"]
        for number, leg in enumerate(legs):
            first, last = leg["first"], leg["last"]
            start, deep = history_of(legs, number, history)
            if last - start + 1 > length:      # хвіст ближче до відповіді
                start = last - length + 1
            first = max(first, start)
            rows.append({
                "pair": pair, "leg": int(leg["leg"]), "kind": leg["kind"],
                "from": int(found["t"][first]), "to": int(found["t"][last]),
                "events": last - first + 1, "history": deep,
                "history_events": first - start,
                "hist": offset + start, "first": offset + first,
                "last": offset + last,
                "part": "train" if found["t"][last] < VAL_FROM else "val"})
        offset += found["events"]
        del found
    return {"x": table, "t": np.concatenate(stamps),
            "price": np.concatenate(prices), "rows": rows,
            "features": titles, "classes": names, "blocks": blocks,
            "length": length, "history": history, "pairs": list(pairs),
            "norm": norm, "clock": clock}


def meta_of(built: dict) -> dict:
    rows = built["rows"]
    train = [one for one in rows if one["part"] == "train"]
    return {
        "script": "research/29-class7dd-legs/scripts/legleft_data.py",
        "threshold": THRESHOLD, "period": PERIOD, "grid": GRID,
        "classes": built["classes"], "blocks": built["blocks"],
        "norm": built.get("norm", NORM),
        "clock": bool(built.get("clock")),
        "stats": [] if built["blocks"] else list(STATS),
        "channels": len(built["features"]), "length": built["length"],
        "history": built["history"],
        "history_median": float(np.median([one["history"] for one in rows]))
        if rows else 0.0,
        "hole_hours": HOLE / 3600, "val_from": "2026-08-14",
        "pairs": built["pairs"],
        "legs": {"all": len(rows), "train": len(train),
                 "val": len(rows) - len(train)},
        "events": {"all": int(sum(one["events"] for one in rows)),
                   "train": int(sum(one["events"] for one in train)),
                   "val": int(sum(one["events"] for one in rows
                                  if one["part"] == "val")),
                   "memory": int(sum(one["history_events"]
                                     for one in rows))},
        "median_leg": float(np.median([one["events"] for one in rows])),
        "ready": bool(rows),
    }


def memmap_of(path: Path, rows: int, columns: int,
              norm: str = NORM) -> np.ndarray:
    """Шматок на диску під канали: у памʼять він не читається."""
    path.parent.mkdir(parents=True, exist_ok=True)
    return np.lib.format.open_memmap(path, mode="w+", dtype=DTYPE[norm],
                                     shape=(rows, columns))


def tag_of(blocks: bool, history: int = HISTORY, norm: str = NORM,
           clock: bool = False) -> str:
    """Імʼя датасету: згортка, глибина памʼяті й нормалізація.

    `rank` суфікса не має — на ньому пораховані перші прогони, і їхні
    файли лишаються під старими іменами.
    """
    name = "blocks" if blocks else "stats"
    name = name if not history else f"{name}{history}"
    name = name if norm == "rank" else f"{name}_{norm}"
    return f"{name}_clock" if clock else name


def save(built: dict, out: Path = DATA) -> Path:
    """Канали вже лежать у `.npy`; тут пишеться все інше — воно дрібне."""
    out.mkdir(parents=True, exist_ok=True)
    tag = tag_of(built["blocks"], built["history"],
                 built.get("norm", NORM), bool(built.get("clock")))
    rows = built["rows"]
    path = out / f"legleft_{tag}.npz"
    if not isinstance(built["x"], np.memmap):
        np.save(out / f"legleft_{tag}.npy", built["x"])
    else:
        built["x"].flush()
    np.savez_compressed(
        path, t=built["t"], price=built["price"],
        hist=np.array([one["hist"] for one in rows]),
        first=np.array([one["first"] for one in rows]),
        last=np.array([one["last"] for one in rows]),
        events=np.array([one["events"] for one in rows]),
        history=np.array([one["history"] for one in rows]),
        part=np.array([one["part"] for one in rows]),
        pair=np.array([one["pair"] for one in rows]),
        kind=np.array([one["kind"] for one in rows]),
        begin=np.array([one["from"] for one in rows]),
        finish=np.array([one["to"] for one in rows]),
        features=np.array(built["features"]))
    (out / f"legleft_{tag}.meta.json").write_text(
        json.dumps(meta_of(built), indent=2, ensure_ascii=False),
        encoding="utf-8")
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--blocks", action="store_true",
                        help="усі блоки події як канали, без згортки")
    parser.add_argument("--length", type=int, default=LENGTH)
    parser.add_argument("--history", type=int, default=HISTORY,
                        help="скільки попередніх ніг заходить у памʼять")
    parser.add_argument("--norm", default=NORM, choices=NORMS,
                        help="нормалізація каналу: asinh зберігає зміни, "
                             "rank — тільки порядок")
    parser.add_argument("--clock", action="store_true",
                        help="додати причинні канали: лічильник подій від "
                             "півота і відповідь лічильника")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=DATA)
    args = parser.parse_args()

    tag = tag_of(args.blocks, args.history, args.norm, args.clock)
    built = build(args.pair or list(PAIRS), args.blocks, args.data,
                  args.length, args.history,
                  into=args.out / f"legleft_{tag}.npy", norm=args.norm,
                  clock=args.clock)
    meta = meta_of(built)
    path = save(built, args.out)
    print(f"класи: {', '.join(meta['classes'])}")
    print(f"канали: {meta['channels']} "
          f"({'усі блоки' if meta['blocks'] else 'середнє, розкид, остання'})"
          f", нормалізація {meta['norm']}")
    print(f"ноги: {meta['legs']['all']} (train {meta['legs']['train']}, "
          f"val {meta['legs']['val']}), медіана {meta['median_leg']:.0f} подій")
    print(f"події: {meta['events']['all']} "
          f"(train {meta['events']['train']}, val {meta['events']['val']})")
    print(f"памʼять: {meta['history']} попередніх ніг "
          f"(медіана взято {meta['history_median']:.0f}), "
          f"{meta['events']['memory']} подій тільки в памʼять")
    print(f"записано в {path} і {path.with_suffix('.npy')}")
    print(f"канали лежать на диску ({DTYPE[args.norm].__name__}), "
          f"у навчання їде батч")


if __name__ == "__main__":
    main()
