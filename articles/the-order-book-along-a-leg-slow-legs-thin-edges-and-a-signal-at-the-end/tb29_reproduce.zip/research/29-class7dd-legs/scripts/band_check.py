"""Чи потрапляє видача мережі в потрібний коридор довкола цілі.

Дослідження: research/29-class7dd-legs/
Правила: rules/03-models.md → Відображення результатів

Медіана `|сказано − насправді|` каже, наскільки мережа промахується в
подіях, і нічого не каже про те, **в скільки разів**. Для ноги, де
лишилось 700 подій, промах у 70 — це 10 %, а для ноги, де лишилось 70, —
це 100 %. Втрата `band` ставить питання саме в частках, і міряти її
треба так само.

Ряд ріжеться **по лічильнику подій від півота** — тим самим, по якому
проведена межа вікна у втраті. На кожній сходинці кроку рахується
відношення `сказано / правда` і три частки: скільки подій лягло в
коридор, скільки нижче за нього і скільки вище. Коридор за
замовчуванням — `0.9 … 1.1`, тобто ±10 %.

Окремо йде підсумок по **вікну відповіді** (крок менший за `WINDOW`) і
медіана видачі після нього: там ціль рівно 0, і дивитись треба не на
коридор, а на те, чи мережа замовкла.

Ключ `--seeds` міряє **середнє трьох незалежних засівів** — це найкращий
результат підбору. Різниця між засівами тут більша, ніж між більшістю
налаштувань, тому середина між ними влучає частіше за будь-який окремо.

Ключ `--mix` міряє не одну епоху, а **середнє кількох**: помилки епох
частково незалежні, і середина між ними влучає частіше за кожну окремо.
Ваги кожної епохи лежать поруч із кращою (`epoch<N>.pt`), тому такий
набір — це така сама модель, як будь-яка інша, тільки з трьох знімків.

Запуск:
    python3 research/29-class7dd-legs/scripts/band_check.py
    python3 research/29-class7dd-legs/scripts/band_check.py --tag <тег>
    python3 research/29-class7dd-legs/scripts/band_check.py --band 0.8 1.2
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
RESULTS = RESEARCH_DIR / "results"

TAGS = ("blocks4_gauss_clock_band",)
SEEDS = ("blocks4_gauss_clock_band_seed0", "blocks4_gauss_clock_band_seed1",
         "blocks4_gauss_clock_band_seed2")
# три незалежні прогони тієї самої конфігурації й три кращі епохи кожного
MIXES = {"blocks4_gauss_clock_band_seed0": (24, 27, 12),
         "blocks4_gauss_clock_band_seed1": (24, 12, 9),
         "blocks4_gauss_clock_band_seed2": (16, 10, 19)}
BAND = (0.9, 1.1)
WINDOW = 150               # вікно відповіді: стільки подій після півота
STEPS = (0, 10, 50, 100, 150, 200, 300, 500)


def shares_of(said: np.ndarray, truth: np.ndarray) -> np.ndarray:
    """Відношення `сказано / правда`; нуль правди в знаменник не йде."""
    return said / np.maximum(truth, 1.0)


def steps_of(legs: list, events: int) -> np.ndarray:
    """Скільки подій минуло від півота на кожній події ряду val."""
    step = np.zeros(events)
    for leg in legs:
        start, count = leg["start"], leg["events"]
        step[start:start + count] = np.arange(count)
    return step


def rows_of(said: np.ndarray, truth: np.ndarray, step: np.ndarray,
            band=BAND, edges=STEPS) -> list:
    """Сходинка за сходинкою: медіана відношення і три частки."""
    found = []
    for lo, hi in zip(edges, list(edges[1:]) + [None]):
        keep = (step >= lo) if hi is None else ((step >= lo) & (step < hi))
        if not keep.any():
            continue
        share = shares_of(said[keep], truth[keep])
        found.append({
            "from": int(lo), "to": None if hi is None else int(hi),
            "events": int(keep.sum()),
            "said": float(np.median(said[keep])),
            "truth": float(np.median(truth[keep])),
            "share": float(np.median(share)),
            "hit": float(((share >= band[0]) & (share <= band[1])).mean()),
            "low": float((share < band[0]).mean()),
            "high": float((share > band[1]).mean()),
        })
    return found


def said_of(found: dict, mix: list | None) -> tuple:
    """Видача: кращої епохи або середнє названих."""
    if not mix:
        shot = next(one for one in found["epochs"]
                    if one["epoch"] == found["best"])
        return np.asarray(shot["said"], dtype=float), [found["best"]]
    piles = [np.asarray(one["said"], dtype=float)
             for one in found["epochs"] if one["epoch"] in mix]
    if not piles:
        raise SystemExit(f"немає таких епох: {mix}")
    return np.mean(np.stack(piles), axis=0), sorted(mix)


def seeds_of(tags=SEEDS, root: Path = RESULTS, band=BAND) -> dict:
    """Середнє кількох засівів: у кожного беруться його кращі епохи."""
    piles, taken = [], {}
    for tag in tags:
        found = json.loads((root / f"legleft_{tag}_epochs.json")
                           .read_text(encoding="utf-8"))
        said, epochs = said_of(found, list(MIXES.get(tag, ())))
        piles.append(said)
        taken[tag] = epochs
    said = np.mean(np.stack(piles), axis=0)
    truth = np.asarray(found["truth"], dtype=float)
    step = steps_of(found["legs"], len(truth))
    head = step < WINDOW
    share = shares_of(said[head], truth[head])
    return {
        "tag": " + ".join(tags), "loss": found.get("loss"),
        "epoch": 0, "epochs": [], "seeds": taken,
        "err": 0.0, "band": list(band), "window": WINDOW,
        "rows": rows_of(said, truth, step, band),
        "head": {"events": int(head.sum()),
                 "hit": float(((share >= band[0])
                               & (share <= band[1])).mean()),
                 "low": float((share < band[0]).mean()),
                 "high": float((share > band[1]).mean()),
                 "share": float(np.median(share)),
                 "quiet": float(np.median(said[~head]))},
    }


def run_of(tag: str, root: Path = RESULTS, band=BAND,
           mix: list | None = None) -> dict:
    """Краща епоха прогону (або середнє кількох) у частках цілі."""
    found = json.loads((root / f"legleft_{tag}_epochs.json")
                       .read_text(encoding="utf-8"))
    said, taken = said_of(found, mix)
    shot = next(one for one in found["epochs"]
                if one["epoch"] == taken[0])
    truth = np.asarray(found["truth"], dtype=float)
    step = steps_of(found["legs"], len(truth))
    rows = rows_of(said, truth, step, band)
    head = step < WINDOW
    share = shares_of(said[head], truth[head])
    return {
        "tag": tag, "loss": found.get("loss"), "epoch": taken[0],
        "epochs": taken,
        "err": float(shot["err"]), "band": list(band), "window": WINDOW,
        "rows": rows,
        "head": {"events": int(head.sum()),
                 "hit": float(((share >= band[0])
                               & (share <= band[1])).mean()),
                 "low": float((share < band[0]).mean()),
                 "high": float((share > band[1]).mean()),
                 "share": float(np.median(share)),
                 "quiet": float(np.median(said[~head]))},
    }


def show(found: dict) -> None:
    head = found["head"]
    taken = found.get("epochs") or [found["epoch"]]
    if found.get("seeds"):
        name = "середнє засівів: " + ", ".join(
            f"{one.rsplit('seed', 1)[-1]} → {two}"
            for one, two in found["seeds"].items())
    elif len(taken) == 1:
        name = f"епоха {taken[0]}"
    else:
        name = "середнє епох " + ", ".join(map(str, taken))
    print(f"\n{found['loss']} · {name} · коридор "
          f"{found['band'][0]:.2f} … {found['band'][1]:.2f}\n")
    print(f"{'крок':>10}{'подій':>8}{'сказано':>10}{'правда':>9}"
          f"{'частка':>9}{'у коридорі':>12}{'нижче':>9}{'вище':>8}")
    for row in found["rows"]:
        name = f"{row['from']}-{row['to']}" if row["to"] else f"{row['from']}+"
        gate = " │" if row["to"] == found["window"] else "  "
        print(f"{name:>10}{row['events']:>8}{row['said']:>10.0f}"
              f"{row['truth']:>9.0f}{row['share']:>9.2f}"
              f"{row['hit'] * 100:>11.1f}%{row['low'] * 100:>8.1f}%"
              f"{row['high'] * 100:>7.1f}%{gate}")
    print(f"\nвікно відповіді (до {found['window']} подій): у коридорі "
          f"{head['hit'] * 100:.1f}%, нижче {head['low'] * 100:.1f}%, вище "
          f"{head['high'] * 100:.1f}%, медіана частки {head['share']:.2f}")
    print(f"після вікна мережа каже {head['quiet']:.0f} (ціль 0)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", action="append", default=None)
    parser.add_argument("--band", type=float, nargs=2, default=list(BAND))
    parser.add_argument("--seeds", action="store_true",
                        help="середнє трьох незалежних засівів")
    parser.add_argument("--mix", type=int, nargs="+", default=None,
                        help="усереднити видачі названих епох")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    rows = [seeds_of(SEEDS, args.out, tuple(args.band))] if args.seeds \
        else [run_of(one, args.out, tuple(args.band), args.mix)
              for one in (args.tag or list(TAGS))]
    result = {"script": "research/29-class7dd-legs/scripts/band_check.py",
              "band": list(args.band), "runs": rows, "ready": True}
    path = args.out / "band_check.json"
    path.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    for one in rows:
        show(one)
    print(f"\nзаписано в {path}")


if __name__ == "__main__":
    main()
