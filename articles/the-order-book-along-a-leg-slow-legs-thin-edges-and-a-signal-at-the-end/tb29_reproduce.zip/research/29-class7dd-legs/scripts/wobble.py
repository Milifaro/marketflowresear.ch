"""Наскільки рвана видача мережі вздовж ноги.

Дослідження: research/29-class7dd-legs/
Правила: rules/03-models.md → Відображення результатів

Загальна похибка каже, **де** мережа стоїть, і нічого не каже про те,
як вона туди йде. Усередині ноги залишок меншає рівно на одну подію за
подію, тому правильний крок видачі — `−1`, і будь-що інше — це рваність:
провал на сотню подій за один крок або хід угору, якого в цілі не буває.

Тут це міряється на готових видачах прогону (`legleft_<tag>_epochs.json`)
по кожній нозі val окремо, у подіях:

    крок         `Δ = сказано[t] − сказано[t−1]` усередині своєї ноги
    відхилення   медіана `|Δ + 1|` — на скільки крок не той
    провали      частка кроків нижче −20, −30, −40
    угору        частка кроків, де видача зросла, хоча залишок меншає

Рахується на середині ноги — від `HEAD` до `TILL` її частки, де нога
вже почалась і ще не кінчається, — і окремо по всій нозі.

Запуск:
    python3 research/29-class7dd-legs/scripts/wobble.py
    python3 research/29-class7dd-legs/scripts/wobble.py --tag blocks4_gauss_ramp
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
RESULTS = RESEARCH_DIR / "results"

TAGS = ("blocks4_gauss_ramp", "blocks4_gauss_sides")
HEAD = 0.10                # з якої частки ноги дивимось
TILL = 0.85                # і до якої
FALLS = (-20.0, -30.0, -40.0)


def steps_of(said: np.ndarray, legs: list, head: float, till: float):
    """Кроки видачі всередині кожної ноги, на заданому відрізку ноги."""
    found = []
    for leg in legs:
        start, count = leg["start"], leg["events"]
        piece = said[start:start + count]
        if count < 3:
            continue
        place = np.arange(count) / count
        step = np.diff(piece)
        keep = (place[1:] >= head) & (place[1:] <= till)
        found.append(step[keep])
    return np.concatenate(found) if found else np.zeros(0)


def measure(step: np.ndarray) -> dict:
    """Числа про рваність одного набору кроків."""
    if not step.size:
        return {}
    return {
        "steps": int(step.size),
        "off": float(np.median(np.abs(step + 1.0))),
        "up": float((step > 0).mean()),
        "falls": {str(int(edge)): float((step < edge).mean())
                  for edge in FALLS},
        "worst": float(step.min()),
    }


def run_of(tag: str, root: Path = RESULTS, head: float = HEAD,
           till: float = TILL) -> dict:
    """Рваність кращої епохи прогону — на відрізку і по всій нозі."""
    path = root / f"legleft_{tag}_epochs.json"
    found = json.loads(path.read_text(encoding="utf-8"))
    best = found.get("best")
    shot = next(one for one in found["epochs"] if one["epoch"] == best)
    said = np.asarray(shot["said"], dtype=float)
    legs = found["legs"]
    return {"tag": tag, "loss": found.get("loss"), "epoch": best,
            "err": float(shot["err"]),
            "piece": measure(steps_of(said, legs, head, till)),
            "all": measure(steps_of(said, legs, 0.0, 1.0))}


def show(rows: list, head: float, till: float) -> None:
    print(f"\nрваність видачі, відрізок {head:.0%} … {till:.0%} ноги\n")
    print(f"{'прогін':<22}{'епоха':>6}{'похибка':>9}{'|Δ+1|':>8}"
          f"{'угору':>8}{'<−20':>8}{'<−30':>8}{'<−40':>8}{'найгірший':>11}")
    for row in rows:
        one = row["piece"]
        print(f"{row['loss'] or row['tag']:<22}{row['epoch']:>6}"
              f"{row['err']:>9.0f}{one['off']:>8.2f}"
              f"{one['up'] * 100:>7.1f}%{one['falls']['-20'] * 100:>7.2f}%"
              f"{one['falls']['-30'] * 100:>7.2f}%"
              f"{one['falls']['-40'] * 100:>7.2f}%{one['worst']:>11.0f}")
    print("\n|Δ+1| — медіана відхилення кроку від правильного −1, подій")
    print("угору — частка кроків, де видача зросла (у цілі такого немає)")
    print("<−20 … <−40 — частка кроків, глибших за поріг")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", action="append", default=None)
    parser.add_argument("--head", type=float, default=HEAD)
    parser.add_argument("--till", type=float, default=TILL)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    rows = [run_of(one, args.out, args.head, args.till)
            for one in (args.tag or list(TAGS))]
    found = {"script": "research/29-class7dd-legs/scripts/wobble.py",
             "head": args.head, "till": args.till, "falls": list(FALLS),
             "rows": rows, "ready": True}
    path = args.out / "wobble.json"
    path.write_text(json.dumps(found, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    show(rows, args.head, args.till)
    print(f"\nзаписано в {path}")


if __name__ == "__main__":
    main()
