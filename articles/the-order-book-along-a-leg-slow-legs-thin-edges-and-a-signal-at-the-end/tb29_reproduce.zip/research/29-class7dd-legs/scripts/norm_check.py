"""Скільки інформації фічі лишається після нормалізації.

Дослідження: research/29-class7dd-legs/
Правила: rules/01-data-and-db.md → Опис класів

Мережа не бачить сирої фічі — вона бачить те, у що фічу перевели. Тут
перевід міряється проти самої фічі: що з нею сталось і скільки з неї
лишилось. Кандидати рахуються на **справжніх каналах** усіх класів, які
йдуть у навчання, а не на вигаданому ряді.

## Що міряється

Кожен кандидат — це функція `y = g(v)`, і питання до неї три:

    склеювання   скільки різних `v` перетворились на одне й те саме `y`.
                 Ранг склеює за побудовою: він лишає місце в черзі й
                 викидає все інше. Строго зростаюча функція не склеює
                 нічого, крім того, що з'їдає точність `float32`
    відновлення  найбільша відносна похибка, з якою з `y` дістається
                 назад `v`. Це прямий замір «наскільки дані цілі»:
                 якщо число відновлюється, воно не втрачене
    різниці      наскільки зміна фічі проходить крізь `g` як є. Локальний
                 множник — це `g'(v)`, і для `asinh(v/s)` він дорівнює
                 `1/√(1+(v/s)²)`: біля нуля одиниця, далеко — падає.
                 Частка подій, де множник вище 0.7, — це частка, у якій
                 зміни проходять майже недоторканими

Разом із цим міряється **розмах** видачі: якщо всі числа лягли в
`1e-4`, мережа їх не побачить — не тому, що інформацію втрачено, а тому
що вхід став плоским. Тому кожен кандидат після свого перетворення
ділиться на медіану `|y|` своєї `train`-частини: різниці від цього не
страждають (ділення — афінне), а вхід стає в межах одиниці. Медіана, а
не розкид: розкид задає той самий важкий хвіст, і на ньому вся середина
ряду злипається біля нуля.

## Кандидати

    rank         ранг усередині монети, база — train
    gauss        той самий ранг, поданий в обернену нормальну функцію
                 розподілу: канал стає стандартним нормальним. Порядок
                 цілий, форма в усіх каналів однакова, але сталого
                 множника різниць немає — крок по фічі переноситься за
                 густиною ряду, тому в графі «різниці як є» стоїть нуль,
                 як у рангу
    asinh_med    `asinh(v/s)`, `s` — медіана `|v|`
    asinh_p90    те саме, `s` — 90-й перцентиль `|v|`
    asinh_p99    те саме, `s` — 99-й перцентиль `|v|`
    log_med      `sign(v)·log1p(|v|/s)`, `s` — медіана `|v|`
    affine       `v / MAD` без стиснення — різниці цілі всі, але хвіст
                 лишається хвостом

Запуск:

    python3 research/29-class7dd-legs/scripts/norm_check.py
    python3 research/29-class7dd-legs/scripts/norm_check.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import ndtri

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = RESEARCH_DIR.parents[1]
DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"

PAIR = "BTC_USDT"
VAL_FROM = 1_786_665_600          # 2026-08-14, межа train/val
EDGE = 1e-6                       # відступ від країв рангу під `Φ⁻¹`
CLOSE = 0.7                       # множник різниць, який рахуємо «як є»
SAMPLE = 200_000                  # скільки значень каналу брати на замір
SEED = 17


def classes_of(pair: str, root: Path | None = None) -> list:
    """Класи монети на сітці подій 210 с."""
    folder = (root or DATASETS) / pair
    found = []
    for one in sorted(folder.iterdir()):
        if not one.is_dir():
            continue
        try:
            with np.load(one / "train.npz") as store:
                if "t_start" in store and store["x"].ndim == 3:
                    found.append(one.name)
        except (FileNotFoundError, KeyError):
            continue
    return found


def columns_of(pair: str, name: str, root: Path | None = None):
    """Канали класу: кожен блок кожної фічі окремо, як у навчанні."""
    folder = (root or DATASETS) / pair / name
    parts = []
    for part in ("train", "val"):
        with np.load(folder / f"{part}.npz", allow_pickle=True) as store:
            parts.append((np.asarray(store["x"], dtype=np.float64),
                          np.asarray(store["t_start"], dtype=np.int64),
                          [str(one) for one in store["features"]]))
    values = np.concatenate([one[0] for one in parts])
    stamps = np.concatenate([one[1] for one in parts])
    names = parts[0][2]
    for number, feature in enumerate(names):
        column = values[..., number]
        for block in range(column.shape[1]):
            yield f"{name}:{feature}:b{block + 1}", column[:, block], stamps


def scale_of(values: np.ndarray, how: str) -> float:
    """Одиниця каналу: медіана, перцентиль або MAD ненульових значень."""
    good = np.abs(values[np.isfinite(values)])
    good = good[good > 0]
    if not good.size:
        return 1.0
    one = {"med": lambda: np.median(good),
           "p90": lambda: np.percentile(good, 90),
           "p99": lambda: np.percentile(good, 99),
           "mad": lambda: np.median(good)}[how]()
    one = float(one)
    return one if np.isfinite(one) and one > 0 else 1.0


def ranked(column: np.ndarray, train: np.ndarray) -> np.ndarray:
    base = np.sort(column[train & np.isfinite(column)])
    out = np.full(column.shape, 0.5)
    if base.size < 2:
        return out
    good = np.isfinite(column)
    out[good] = (np.searchsorted(base, column[good], side="left") + 0.5) \
        / base.size
    return out


def kinds() -> dict:
    """Кандидати: пряме перетворення і зворотне до нього."""
    def curve(how):
        def ahead(column, train):
            one = scale_of(column[train], how)
            return np.arcsinh(column / one), one
        return ahead

    def logged(column, train):
        one = scale_of(column[train], "med")
        return np.sign(column) * np.log1p(np.abs(column) / one), one

    def affine(column, train):
        one = scale_of(column[train], "mad")
        return column / one, one

    return {
        "rank": None,                     # рахується окремо: воно не функція
        "gauss": None,                    # те саме: ранг під `Φ⁻¹`
        "asinh_med": curve("med"),
        "asinh_p90": curve("p90"),
        "asinh_p99": curve("p99"),
        "log_med": logged,
        "affine": affine,
    }


def back_of(name: str, out: np.ndarray, one: float) -> np.ndarray:
    """Зворотне перетворення: з видачі назад у фічу."""
    if name.startswith("asinh"):
        return np.sinh(out) * one
    if name == "log_med":
        return np.sign(out) * np.expm1(np.abs(out)) * one
    if name == "affine":
        return out * one
    raise ValueError(name)


def slope_of(name: str, column: np.ndarray, one: float) -> np.ndarray:
    """Локальний множник різниць `g'(v)`, приведений до `g'(0) = 1`."""
    if name.startswith("asinh"):
        return 1.0 / np.sqrt(1.0 + (column / one) ** 2)
    if name == "log_med":
        return 1.0 / (1.0 + np.abs(column) / one)
    if name == "affine":
        return np.ones_like(column)
    raise ValueError(name)


def glued(out: np.ndarray, column: np.ndarray) -> float:
    """Частка різних значень фічі, які злиплись в одне число видачі."""
    good = np.isfinite(column) & np.isfinite(out)
    if good.sum() < 2:
        return 0.0
    raw = np.unique(column[good]).size
    got = np.unique(np.asarray(out[good], dtype=np.float32)).size
    return float(1.0 - got / raw) if raw else 0.0


def measure(column: np.ndarray, stamps: np.ndarray, rng) -> dict:
    """Один канал: що кожен кандидат зробив із його числами."""
    train = stamps < VAL_FROM
    if column.size > SAMPLE:                 # замір іде на вибірці ряду
        keep = rng.choice(column.size, SAMPLE, replace=False)
        keep.sort()
        column, train = column[keep], train[keep]
    good = np.isfinite(column)
    if good.sum() < 100 or not train.any():
        return {}
    found = {}
    for name, ahead in kinds().items():
        if ahead is None:
            out = ranked(column, train)
            if name == "gauss":
                out = ndtri(np.clip(out, EDGE, 1.0 - EDGE))
            spread = scale_of(out[train & good], "med")
            found[name] = {
                "glued": glued(out, column),
                "back": float("inf"),        # з рангу фічу не дістати
                "close": 0.0,                # відстані не переносяться
                "spread": float(np.percentile(np.abs(out[good] / spread),
                                              99)),
                "top": float(np.abs(out[good] / spread).max()),
            }
            continue
        out, one = ahead(column, train)
        spread = scale_of(out[train & good], "med")
        again = back_of(name, out, one)
        gap = np.abs(again[good] - column[good]) \
            / np.maximum(np.abs(column[good]), 1e-12)
        slope = slope_of(name, column[good], one)
        found[name] = {
            "glued": glued(out / spread, column),
            "back": float(np.percentile(gap, 99)),
            "close": float((slope >= CLOSE).mean()),
            "spread": float(np.percentile(np.abs(out[good] / spread), 99)),
            "top": float(np.abs(out[good] / spread).max()),
        }
    return found


def walk(pair: str, root: Path | None = None) -> dict:
    """Усі канали всіх класів монети, кандидат за кандидатом."""
    rng = np.random.default_rng(SEED)
    piles, count = {}, 0
    for name in classes_of(pair, root):
        for title, column, stamps in columns_of(pair, name, root):
            got = measure(column, stamps, rng)
            if not got:
                continue
            count += 1
            for kind, numbers in got.items():
                piles.setdefault(kind, []).append(numbers)
    rows = []
    for kind, numbers in piles.items():
        # `back` у рангу нескінченний — у JSON він іде як `null`:
        # `Infinity` не читається строгим розбором
        back = float(np.median([one["back"] for one in numbers]))
        rows.append({
            "kind": kind,
            "glued": float(np.mean([one["glued"] for one in numbers])),
            "back": back if np.isfinite(back) else None,
            "close": float(np.mean([one["close"] for one in numbers])),
            "spread": float(np.median([one["spread"] for one in numbers])),
            "top": float(np.median([one["top"] for one in numbers])),
        })
    return {"pair": pair, "channels": count, "rows": rows}


def show(found: dict) -> None:
    print(f"\n{found['pair']}: {found['channels']} каналів\n")
    print(f"{'кандидат':<12}{'склеєно':>10}{'відновлення':>14}"
          f"{'різниці як є':>15}{'розмах':>10}{'найбільше':>14}")
    for row in found["rows"]:
        back = "—" if row["back"] is None else f"{row['back']:.2e}"
        print(f"{row['kind']:<12}{row['glued'] * 100:>9.2f}%{back:>14}"
              f"{row['close'] * 100:>14.1f}%{row['spread']:>10.2f}"
              f"{row['top']:>14.3g}")
    print("\nсклеєно — частка різних значень фічі, що стали одним числом")
    print("відновлення — 99-й перцентиль відносної похибки зворотного ходу")
    print("різниці як є — частка подій, де множник різниць вище 0.7")
    print("розмах — 99-й перцентиль |видачі| після ділення на медіану train")
    print("найбільше — те саме, але максимум: чим мережу доведеться годувати")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    found = walk(args.pair, args.data)
    found["script"] = "research/29-class7dd-legs/scripts/norm_check.py"
    found["ready"] = True
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"norm_check_{args.pair}.json"
    path.write_text(json.dumps(found, indent=2, ensure_ascii=False),
                    encoding="utf-8")
    show(found)
    print(f"\nзаписано в {path}")


if __name__ == "__main__":
    main()
