"""Сигнал кінця ноги: останні 5 % ноги проти всієї її решти.

Дослідження: research/29-class7dd-legs/
Правила: rules/03-models.md → Правила навчання

Етап 4 просив у мережі **число** — скільки подій лишилось до півота, — і
міряв, на скільки подій вона промахнулась. Тут питання інше й простіше:
не «скільки лишилось», а **«ми вже в кінці?»**. Ціль на події ноги:

    перші 95 % подій ноги  ->  0
    останні 5 %            ->  1   (сигнал)

Тобто на кожній нозі стоїть рівно один короткий сплеск — її хвіст, — і
від мережі просять, щоб її видача мала **пік саме там**. Ніг у датасеті
554, медіанна довжина 392 події, тому сигнал — це 19-20 подій на нозі, а
не одна: позначка береться часткою, не фіксованим числом, і на короткій
нозі вона коротка, на довгій — довга. Щоб на найкоротших ногах сигнал не
зник зовсім, береться `max(1, round(5 % довжини))` останніх подій.

Вхід той самий, що в найкращому прогоні етапу 4:

    4 попередні ноги в памʼяті LSTM (події йдуть у памʼять, ціль на них
    замаскована)
    усі блоки події як канали — згортки немає
    три причинні канали: скільки подій минуло від півота, відповідь
    лічильника і вікно відповіді
    нормалізація `gauss` — місце значення в черзі train подається в
    обернену нормальну функцію розподілу, і канал стає стандартним
    нормальним

Мережа теж та сама (`leg_end_net.LegEnd`, LSTM + причинна увага), але
вихід тут — **логіт**, а не число подій.

## Функції втрат

    bce     BCE на логіті з вагою позитиву `pos_weight`: сигнал у 20
            разів рідший за фон, і без ваги мережа просто мовчить
    focal   та сама BCE, помножена на `(1 − p_t) ** GAMMA`: легкі
            негативи, яких 95 %, перестають тягнути градієнт, і вага
            йде в ті події, де мережа ще помиляється
    close   focal із вагою за місцем події в нозі: помилка на останніх
            20 % ноги дорожча (×2 на 80–90 %, ×4 на 90–95 %), бо саме
            там проходить межа сигналу і саме там вирішується, буде пік
            на місці чи розмажеться
    quiet   `bce` плюс **тиша на початку ноги**: перші HUSH подій після
            півота сигнал майже неможливий (0.3 % подій val), і хибний
            сплеск там коштує вчетверо дорожче. Межа стоїть на
            лічильнику кроків, який мережа бачить каналом, тому вона
            причинна — це той самий прийом, що дає тишу прогону `band`
            етапу 4

## Вага позитиву

Ключ `--pos-weight`. Сигнал займає 5 % подій, і за замовчуванням його
вага 19 — рівно стільки, щоб сигнал і фон важили порівну. Ціна цього:
пропустити сигнал у 19 разів дорожче, ніж крикнути дарма, тому мережі
**вигідно кричати**. Видача з `pos-weight 19` стоїть вище 0.5 на 15 %
подій val при 5 % сигналу — утричі частіше, ніж треба, і на ряді це
видно як суцільний шум замість окремих сплесків.

`--pos-weight 1` — звичайна BCE: хибний сплеск коштує рівно стільки ж,
скільки пропуск. Мережа тоді мовчить більшу частину ноги й піднімає
голос лише там, де впевнена. AUC і `AP` — рангові міри, їм рівень
байдужий, а от картина на ряді міняється повністю.

## Проти чого міряємо

    рівень      частка сигналу серед подій val — точність «вгадування»
                без жодного входу
    лічильник   `P(сигнал | скільки подій минуло від півота)` з train.
                Знати номер кроку можна причинно, і це чесна база:
                довгі ноги рідкісні, тому сам крок уже щось каже

Міра — **AUC** і **середня влучність** (площа під кривою влучність-
повнота, `AP`): остання прямо каже, наскільки видача корисна, коли
сигналу лише 5 %. Поруч — профіль видачі по десятинах ноги: пік має
стояти в десятій.

Краща епоха береться за `AP` на val, тому число завищене відбором.
Чесна оцінка лічиться поруч: ноги val діляться навпіл, епоха обирається
на одній половині, міряється на другій, і навпаки.

Вхід : ../data/legleft_blocks4_gauss_clock.npz (legleft_data.py --clock)
Вихід: results/legtip_<tag>.json        — крива, метрики, десятини, бази
       results/legtip_<tag>_epochs.json — видача кожної епохи на val
       ../models/legtip_<tag>/           — ваги найкращої епохи

Запуск:
    python3 research/29-class7dd-legs/scripts/legleft_data.py \
        --blocks --history 4 --norm gauss --clock
    python3 research/29-class7dd-legs/scripts/legtip_train.py \
        --blocks --history 4 --norm gauss --clock \
        --hidden 32 --lr 1e-3 --epochs 12 --loss focal --force
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
NET_SCRIPTS = PROJECT_ROOT / "research" / "19-leg-end-lstm" / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(NET_SCRIPTS))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from legleft_data import DATA, HISTORY, NORM, NORMS, tag_of  # noqa: E402
from legleft_train import (batches, device_name, free_of,  # noqa: E402
                           legs_of, load, out_of_memory)
from leg_end_train import no_swap  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"

SEED = 0                   # rules/03-models.md → Правила навчання
EPOCHS = 12
PATIENCE = 4
BATCH = 8
LR = 1e-3
HIDDEN = 32
HEADS = 2
DECILES = 10
TIP = 0.05                 # яка частка ноги з кінця — сигнал
LOSSES = ("bce", "focal", "close", "quiet")
GAMMA = 2.0                # крутість focal: легкі негативи дешевшають
# `close`: вага за місцем події в нозі. Пара — «від якої частки ноги» і
# «у скільки разів дорожча помилка»; до першої межі вага 1. Межа сигналу
# стоїть на 95 %, і саме довкола неї вирішується, буде пік на місці.
CLOSE = ((0.8, 2.0), (0.9, 4.0))
# `quiet`: скільки подій після півота сигнал вважається неможливим і в
# скільки разів там дорожчий хибний сплеск. Межа — на лічильнику кроків,
# який мережа бачить каналом, тому вимога причинна.
HUSH = 50
HUSH_COST = 4.0
POS = 19.0                 # вага позитиву за замовчуванням: 5 % сигналу
TOP = 0.05                 # частка найгучніших подій val: влучність там
GRID = {"hidden": (32, 64), "lr": (1e-3, 3e-4)}

STOP = {"asked": False}


def listen() -> None:
    import signal

    def ask(*_):
        STOP["asked"] = True
        print("\nзупинка попрошена: домальовую епоху і виходжу")

    for name in ("SIGTERM", "SIGINT"):
        signal.signal(getattr(signal, name), ask)


def tip_of(count: int, share: float = TIP) -> int:
    """Скільки останніх подій ноги — сигнал. Мінімум одна."""
    return max(1, int(round(count * share)))


def tensors(built: dict, rows: list, chunk: list, device: str):
    """Батч ніг: `(B, L, C+1)`, ціль 0/1, маски, місце події і крок.

    `mask` — де взагалі є подія, `count` — де стоїть питання (події своєї
    ноги; попередні йдуть тільки в памʼять). Останній канал каже мережі,
    чи вона вже в своїй нозі. `place` — частка пройденої ноги, з неї
    береться вага втрати `close`; у мережу вона не заходить.
    """
    import torch

    length = max(rows[one]["steps"] for one in chunk)
    width = built["x"].shape[1] + 1
    x = np.zeros((len(chunk), length, width), dtype=np.float32)
    y = np.zeros((len(chunk), length), dtype=np.float32)
    mask = np.zeros((len(chunk), length), dtype=bool)
    count = np.zeros((len(chunk), length), dtype=bool)
    place = np.zeros((len(chunk), length), dtype=np.float32)
    walk = np.zeros((len(chunk), length), dtype=np.float32)
    for number, one in enumerate(chunk):
        row = rows[one]
        steps, own = row["steps"], row["events"]
        x[number, :steps, :-1] = np.asarray(
            built["x"][row["hist"]:row["last"] + 1], dtype=np.float32)
        x[number, steps - own:steps, -1] = 1.0
        y[number, steps - tip_of(own):steps] = 1.0
        mask[number, :steps] = True
        count[number, steps - own:steps] = True
        place[number, steps - own:steps] = np.arange(own) / max(own, 1)
        walk[number, steps - own:steps] = np.arange(own)
    lengths = torch.tensor([rows[one]["steps"] for one in chunk])
    return (torch.from_numpy(x).to(device), torch.from_numpy(y).to(device),
            torch.from_numpy(mask).to(device), lengths,
            torch.from_numpy(count).to(device),
            torch.from_numpy(place).to(device),
            torch.from_numpy(walk).to(device))


def place_weights(place, profile=CLOSE):
    """Вага кроку за його місцем у нозі: 1 → 2 → 4 біля межі сигналу."""
    import torch

    weight = torch.ones_like(place)
    for edge, times in profile:
        weight = torch.where(place >= edge,
                             torch.full_like(place, times), weight)
    return weight


def step_loss(out, true, place, name: str, pos: float, step=None):
    """Втрата на крок, без згортки: маска й дільник накладаються зовні.

    `step` — лічильник подій від півота; потрібен тільки `quiet`, яка з
    нього бере межу тиші. Число причинне: мережа бачить його каналом.
    """
    import torch

    raw = torch.nn.functional.binary_cross_entropy_with_logits(
        out, true, reduction="none")
    weight = torch.where(true > 0.5, torch.full_like(true, pos),
                         torch.ones_like(true))
    if name == "bce":
        return raw * weight
    if name == "quiet":
        # перші HUSH подій після півота нога щойно почалась: сигналу там
        # практично не буває, і хибний сплеск коштує дорожче
        hush = (step < HUSH) & (true <= 0.5)
        return raw * torch.where(hush, weight * HUSH_COST, weight)
    # focal: p_t — ймовірність, яку мережа дала правильній відповіді
    prob = torch.sigmoid(out)
    right = torch.where(true > 0.5, prob, 1.0 - prob)
    hard = (1.0 - right).clamp(min=0.0) ** GAMMA
    each = raw * weight * hard.detach()
    return each if name == "focal" else each * place_weights(place)


def one_batch(model, built: dict, rows: list, chunk: list, device: str):
    """Видача на батчі ніг: ймовірність, ціль, десятина, крок, нога."""
    import torch

    said, truth, decile, step, legs = [], [], [], [], []
    x, y, mask, lengths, _, _, _ = tensors(built, rows, chunk, device)
    out = torch.sigmoid(model(x, mask, lengths))
    for number, one in enumerate(chunk):
        row = rows[one]
        steps, count = row["steps"], row["events"]
        piece = slice(steps - count, steps)
        said.append(out[number, piece].float().cpu().numpy())
        truth.append(y[number, piece].float().cpu().numpy())
        decile.append(np.minimum(
            (np.arange(count) / count * DECILES).astype(int) + 1, DECILES))
        step.append(np.arange(count))
        legs.append(np.full(count, one))
    return {"said": said, "truth": truth, "decile": decile,
            "step": step, "legs": legs}


def guess(model, built: dict, rows: list, picked: list, device: str,
          size: int = BATCH) -> dict:
    """Видача мережі на ногах. Батч, що не вліз у памʼять, ділиться."""
    import torch

    found = []
    model.eval()
    with torch.no_grad():
        for chunk in [picked[start:start + size]
                      for start in range(0, len(picked), size)]:
            try:
                found.append(one_batch(model, built, rows, chunk, device))
            except RuntimeError as error:
                if len(chunk) == 1 or not out_of_memory(error):
                    raise
                free_of(device)
                print(f"батч на {len(chunk)} ніг не вліз у памʼять: "
                      f"ділю навпіл")
                got = guess(model, built, rows, chunk, device,
                            max(1, len(chunk) // 2))
                found.append({key: [got[key]] for key in
                              ("said", "truth", "decile", "step", "legs")})
    return {key: np.concatenate([one for got in found for one in got[key]])
            for key in ("said", "truth", "decile", "step", "legs")}


# ---------- метрики ----------


def auc_of(said: np.ndarray, truth: np.ndarray) -> float:
    """Площа під ROC через ранги: без sklearn, звʼязки діляться порівну."""
    hit = truth > 0.5
    ones, zeros = int(hit.sum()), int((~hit).sum())
    if not ones or not zeros:
        return 0.5
    order = np.argsort(said, kind="stable")
    ranks = np.empty(said.size, dtype=np.float64)
    ranks[order] = np.arange(1, said.size + 1)
    values = said[order]
    start = 0
    for stop in range(1, said.size + 1):     # звʼязки — середній ранг
        if stop == said.size or values[stop] != values[start]:
            if stop - start > 1:
                ranks[order[start:stop]] = (start + 1 + stop) / 2.0
            start = stop
    return float((ranks[hit].sum() - ones * (ones + 1) / 2.0)
                 / (ones * zeros))


def average_precision(said: np.ndarray, truth: np.ndarray) -> float:
    """Середня влучність: площа під кривою влучність-повнота."""
    hit = (truth > 0.5).astype(np.float64)
    if not hit.any():
        return 0.0
    order = np.argsort(-said, kind="stable")
    got = hit[order]
    found = np.cumsum(got)
    precision = found / np.arange(1, got.size + 1)
    return float((precision * got).sum() / got.sum())


def precision_at(said: np.ndarray, truth: np.ndarray,
                 share: float = TOP) -> dict:
    """Влучність серед найгучніших `share` подій і в скільки разів це
    більше за рівень сигналу."""
    take = max(1, int(round(said.size * share)))
    order = np.argsort(-said, kind="stable")[:take]
    hit = truth > 0.5
    base = float(hit.mean())
    precision = float(hit[order].mean())
    return {"share": share, "events": take, "limit": float(said[order][-1]),
            "precision": precision, "recall": float(hit[order].sum()
                                                    / max(hit.sum(), 1)),
            "lift": precision / base if base else 0.0}


def peak_share(block: dict) -> float:
    """Частка ніг, де найгучніша подія стоїть у сигнальній зоні."""
    legs = np.unique(block["legs"])
    good = 0
    for one in legs:
        pick = block["legs"] == one
        said, truth = block["said"][pick], block["truth"][pick]
        if truth[np.argmax(said)] > 0.5:
            good += 1
    return float(good / max(len(legs), 1))


def by_decile(block: dict, key: str = "said") -> list:
    """Середня видача по десятинах ноги: пік має стояти в десятій."""
    return [float(block[key][block["decile"] == part].mean())
            if (block["decile"] == part).any() else None
            for part in range(1, DECILES + 1)]


def score(block: dict) -> dict:
    said, truth = block["said"], block["truth"]
    return {"auc": auc_of(said, truth), "ap": average_precision(said, truth),
            "base": float((truth > 0.5).mean()),
            "peak": peak_share(block),
            "top": precision_at(said, truth),
            "by_decile": by_decile(block),
            "events": int(said.size)}


def counter_base(built: dict, rows: list, train: list, val: list) -> dict:
    """Дві бази без входу: рівень сигналу і лічильник кроків від півота.

    Лічильник знає тільки, скільки подій минуло від півота, і відповідає
    часткою сигналу серед train-подій із тим самим номером кроку.
    """
    def pull(picked):
        truth, step, decile = [], [], []
        for one in picked:
            count = rows[one]["events"]
            mark = np.zeros(count, dtype=np.float64)
            mark[count - tip_of(count):] = 1.0
            truth.append(mark)
            step.append(np.arange(count))
            decile.append(np.minimum(
                (np.arange(count) / count * DECILES).astype(int) + 1,
                DECILES))
        return (np.concatenate(truth), np.concatenate(step),
                np.concatenate(decile))

    train_truth, train_step, _ = pull(train)
    val_truth, val_step, val_decile = pull(val)
    flat = float(train_truth.mean())
    top = int(train_step.max()) + 1
    table = np.full(top, flat)
    order = np.argsort(train_step, kind="stable")
    bounds = np.searchsorted(train_step[order], np.arange(top + 1))
    for step in range(top):
        piece = order[bounds[step]:bounds[step + 1]]
        if piece.size >= 20:
            table[step] = float(train_truth[piece].mean())
    said = table[np.minimum(val_step, top - 1)]
    block = {"said": said, "truth": val_truth, "decile": val_decile,
             "legs": np.concatenate([np.full(rows[one]["events"], one)
                                     for one in val])}
    return {"flat": {"auc": 0.5, "ap": float(val_truth.mean()),
                     "base": float(val_truth.mean()),
                     "by_decile": [flat] * DECILES},
            "counter": {**score(block), "steps": top}}


def honest(shots: list, val_legs: np.ndarray) -> dict:
    """Чесна оцінка: епоха обирається на половині ніг, міряється на другій.

    Краща епоха всієї таблиці обрана за `AP` на тому самому val, тому її
    число завищене. Тут ноги val діляться навпіл за номером, епоха
    береться за `AP` першої половини й міряється на другій, потім
    навпаки. Середнє двох замірів — те, чого чекати поза цим val.
    """
    legs = np.unique(val_legs)
    halves = (np.isin(val_legs, legs[0::2]), np.isin(val_legs, legs[1::2]))
    out = []
    for pick, other in (halves, halves[::-1]):
        best, mark = None, -1.0
        for shot in shots:
            said = np.asarray(shot["said"], dtype=np.float64)
            got = average_precision(said[pick], shot["truth"][pick])
            if got > mark:
                best, mark = shot, got
        said = np.asarray(best["said"], dtype=np.float64)
        out.append({"epoch": best["epoch"],
                    "ap": average_precision(said[other],
                                            best["truth"][other]),
                    "auc": auc_of(said[other], best["truth"][other])})
    return {"halves": out,
            "ap": float(np.mean([one["ap"] for one in out])),
            "auc": float(np.mean([one["auc"] for one in out]))}


def run(built: dict, rows: list, epochs: int = EPOCHS, hidden: int = HIDDEN,
        heads: int = HEADS, lr: float = LR, patience: int = PATIENCE,
        seed: int = SEED, attention: bool = True, device: str | None = None,
        keep: Path | None = None, loss: str = "focal",
        pos_weight: float | None = None) -> dict:
    import torch
    from leg_end_net import LegEnd, parameters_of, spec_of

    device = device or device_name()
    torch.manual_seed(seed)
    train = [one for one, row in enumerate(rows) if row["part"] == "train"]
    val = [one for one, row in enumerate(rows) if row["part"] == "val"]
    # вага позитиву: сигнал рідкісний рівно настільки, наскільки він
    # вузький, і без неї мережа мовчить на всій нозі
    hit = sum(tip_of(rows[one]["events"]) for one in train)
    seen = sum(rows[one]["events"] for one in train)
    pos = float((seen - hit) / max(hit, 1)) if pos_weight is None \
        else float(pos_weight)
    print(f"сигнал у train: {hit} подій з {seen} "
          f"({hit / seen * 100:.2f} %), вага позитиву {pos:.1f}")
    model = LegEnd(features=built["x"].shape[1] + 1, hidden=hidden,
                   heads=heads, attention=attention, outputs=1).to(device)
    tune = torch.optim.AdamW(model.parameters(), lr=lr)
    curve, best, stale, shots = [], None, 0, []
    for epoch in range(1, epochs + 1):
        model.train()
        total, count = 0.0, 0

        def feed(picked: list, scale=None):
            x, y, mask, lengths, own, place, walk = tensors(
                built, rows, picked, device)
            share = own.float()
            if scale is None:
                scale = share.sum()
            out = model(x, mask, lengths)
            each = step_loss(out, y, place, loss, pos, walk)
            piece = (each * share).sum() / scale
            piece.backward()
            return float(piece.detach()), int(own.sum()), scale

        def learn(picked: list, scale=None):
            try:
                return feed(picked, scale)
            except RuntimeError as error:
                if len(picked) == 1 or not out_of_memory(error):
                    raise
                free_of(device)
                print(f"батч на {len(picked)} ніг не вліз у памʼять: "
                      f"ділю навпіл")
                if scale is None:
                    own = tensors(built, rows, picked, device)[4]
                    scale = own.float().sum()
                half = len(picked) // 2
                one = learn(picked[:half], scale)
                two = learn(picked[half:], scale)
                return one[0] + two[0], one[1] + two[1], scale

        for chunk in batches([rows[one] for one in train], seed=seed + epoch):
            picked = [train[one] for one in chunk]
            tune.zero_grad()
            got, seen_now, _ = learn(picked)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            tune.step()
            total += got * seen_now
            count += seen_now
        block = guess(model, built, rows, val, device)
        got = score(block)
        step = {"epoch": epoch, "loss": total / max(count, 1),
                "auc": got["auc"], "ap": got["ap"], "peak": got["peak"]}
        curve.append(step)
        shots.append({"epoch": epoch, "auc": got["auc"], "ap": got["ap"],
                      "peak": got["peak"], "by_decile": got["by_decile"],
                      "said": block["said"], "truth": block["truth"],
                      "legs": block["legs"]})
        print(f"епоха {epoch:>2}  втрата {step['loss']:.4f}  "
              f"AUC {got['auc']:.4f}  AP {got['ap']:.4f}  "
              f"пік {got['peak'] * 100:.0f} %")
        if best is None or got["ap"] > best["ap"]:
            best = {**got, "epoch": epoch}
            stale = 0
            if keep is not None:
                keep.mkdir(parents=True, exist_ok=True)
                torch.save(model.state_dict(), keep / "model.pt")
                torch.save(tune.state_dict(), keep / "tune.pt")
        else:
            stale += 1
            if stale >= patience:
                break
        if STOP["asked"]:
            break
    on_train = score(guess(model, built, rows, train, device))
    return {"curve": curve, "best": best, "train": on_train, "shots": shots,
            "val": val, "loss": loss, "seed": seed, "pos_weight": pos,
            "epochs": len(curve), "device": device,
            "params": parameters_of(model),
            "spec": spec_of(model, built["x"].shape[0],
                            built["x"].shape[1] + 1),
            "legs": {"train": len(train), "val": len(val)},
            "honest": honest(shots, shots[0]["legs"]),
            "base": counter_base(built, rows, train, val)}


def configs(grid: dict = GRID) -> list:
    rows = [{}]
    for name, values in grid.items():
        rows = [{**row, name: value} for row in rows for value in values]
    return rows


def label_of(config: dict) -> str:
    return " · ".join(f"{name} {value}" for name, value in config.items())


def report_of(built: dict, meta: dict, result: dict, tag: str) -> dict:
    base, best = result["base"], result["best"]
    return {
        "script": "research/29-class7dd-legs/scripts/legtip_train.py",
        "ready": True, "tag": tag, "data": meta, "tip": TIP,
        "channels": int(built["x"].shape[1]) + 1,
        "history": meta.get("history", 0),
        "classes": meta.get("classes", []),
        "seed": result.get("seed", SEED), "device": result["device"],
        "params": result["params"], "spec": result["spec"],
        "curve": result["curve"], "epochs": result["epochs"],
        "legs": result["legs"], "pos_weight": result["pos_weight"],
        "config": result.get("config", {"hidden": HIDDEN, "lr": LR}),
        "loss": result.get("loss", "focal"),
        "close": [list(one) for one in CLOSE]
        if result.get("loss") == "close" else [],
        "hush": {"events": HUSH, "cost": HUSH_COST}
        if result.get("loss") == "quiet" else None,
        "shots": [{"epoch": one["epoch"], "auc": one["auc"], "ap": one["ap"],
                   "peak": one["peak"], "by_decile": one["by_decile"]}
                  for one in result.get("shots", [])],
        "grid": result.get("grid", []), "honest": result["honest"],
        "best": best, "train": result["train"], "base": base,
        "gain": {"flat": float(best["ap"] / base["flat"]["ap"])
                 if base["flat"]["ap"] else 0.0,
                 "counter": float(best["ap"] / base["counter"]["ap"])
                 if base["counter"]["ap"] else 0.0},
    }


def epochs_of(built: dict, rows: list, result: dict, tag: str,
              meta: dict) -> dict:
    """Файл видач: ряд val кожної монети, факт і що казала кожна епоха."""
    val = sorted(result["val"], key=lambda one: (rows[one]["pair"],
                                                 rows[one]["first"]))
    legs, place = [], 0
    for one in val:
        row = rows[one]
        legs.append({"pair": row["pair"], "kind": row["kind"],
                     "events": row["events"], "history": row["history"],
                     "tip": tip_of(row["events"]), "start": place,
                     "order": result["val"].index(one)})
        place += row["events"]
    steps = {}
    walk = 0
    for one in result["val"]:
        steps[one] = walk
        walk += rows[one]["events"]

    def in_row(values) -> list:
        out = []
        for one in val:
            start = steps[one]
            out.extend(values[start:start + rows[one]["events"]])
        return out

    stamps, price, truth, coin = [], [], [], []
    for one in val:
        row = rows[one]
        piece = slice(row["first"], row["last"] + 1)
        stamps.extend(int(value) for value in built["t"][piece])
        price.extend(round(float(value), 6) for value in built["price"][piece])
        mark = [0] * row["events"]
        for index in range(row["events"] - tip_of(row["events"]),
                           row["events"]):
            mark[index] = 1
        truth.extend(mark)
        coin.extend([row["pair"]] * row["events"])
    return {
        "script": "research/29-class7dd-legs/scripts/legtip_train.py",
        "ready": bool(legs), "tag": tag, "history": meta.get("history", 0),
        "channels": int(meta.get("channels", 0)) + 1, "tip": TIP,
        "threshold": meta.get("threshold", 0.023),
        "period": meta.get("period", 10),
        "config": result.get("config", {}), "events": place,
        "loss": result.get("loss", "focal"),
        "best": result["best"]["epoch"], "legs": legs,
        "pairs": sorted({row["pair"] for row in legs}),
        "t": stamps, "price": price, "truth": truth, "pair": coin,
        "epochs": [{"epoch": one["epoch"], "auc": one["auc"],
                    "ap": one["ap"], "peak": one["peak"],
                    "by_decile": one["by_decile"],
                    "said": [round(float(value), 4)
                             for value in in_row(one["said"])]}
                   for one in result["shots"]],
    }


def show(report: dict) -> None:
    best, base = report["best"], report["base"]
    print(f"\nканали {report['channels']}, памʼять "
          f"{report.get('history', 0)} ніг, втрата {report.get('loss')}, "
          f"ваг {report['params']}, пристрій {report['device']}, ручки "
          f"{label_of(report['config'])}, епоха {best['epoch']} з "
          f"{report['epochs']}")
    print(f"на val: AUC {best['auc']:.4f} · AP {best['ap']:.4f} "
          f"(рівень сигналу {best['base']:.4f}) · пік у зоні на "
          f"{best['peak'] * 100:.0f} % ніг")
    print(f"лічильник: AUC {base['counter']['auc']:.4f} · "
          f"AP {base['counter']['ap']:.4f}")
    print(f"влучність серед найгучніших {TOP * 100:.0f} % подій: "
          f"{best['top']['precision'] * 100:.1f} % "
          f"(×{best['top']['lift']:.2f} до рівня), "
          f"повнота {best['top']['recall'] * 100:.1f} %")
    one = report["honest"]
    print(f"чесна оцінка (відбір на половині ніг, замір на другій): "
          f"AP {one['ap']:.4f} · AUC {one['auc']:.4f}")
    print("\nсередня видача по десятинах ноги")
    for name, line in (("мережа", best["by_decile"]),
                       ("лічильник", base["counter"]["by_decile"])):
        print(f"  {name:<10} " + " ".join(
            f"{one:>6.3f}" if one is not None else "     —" for one in line))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--blocks", action="store_true")
    parser.add_argument("--history", type=int, default=HISTORY)
    parser.add_argument("--norm", default=NORM, choices=NORMS)
    parser.add_argument("--clock", action="store_true",
                        help="датасет із причинними лічильниками")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--loss", default="focal", choices=LOSSES)
    parser.add_argument("--pos-weight", type=float, default=None,
                        help="вага позитиву; без ключа береться 19 — "
                             "стільки, щоб сигнал і фон важили порівну")
    parser.add_argument("--hidden", type=int, default=HIDDEN)
    parser.add_argument("--heads", type=int, default=HEADS)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--no-attention", action="store_true")
    parser.add_argument("--grid", action="store_true",
                        help="перебрати ручки гріда і лишити найкращу")
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    no_swap(force=args.force)
    listen()

    tag = tag_of(args.blocks, args.history, args.norm, args.clock)
    built = load(tag, args.data)
    meta = json.loads((args.data / f"legleft_{tag}.meta.json")
                      .read_text(encoding="utf-8"))
    tag = f"{tag}_{args.loss}"
    # вага позитиву міняє не лише рівень видачі, а й те, чого мережа
    # вчиться, тому прогони з різною вагою лежать окремими файлами
    if args.pos_weight is not None:
        tag = f"{tag}_w{args.pos_weight:g}"
    if args.seed != SEED:
        tag = f"{tag}_seed{args.seed}"
    rows = legs_of(built)
    plan = configs() if args.grid else [{"hidden": args.hidden,
                                         "lr": args.lr}]
    result, grid = None, []
    for config in plan:
        print(f"\n=== {label_of(config)} ===")
        got = run(built, rows, args.epochs, config["hidden"], args.heads,
                  config["lr"], patience=args.patience, seed=args.seed,
                  loss=args.loss, attention=not args.no_attention,
                  pos_weight=args.pos_weight,
                  keep=MODELS / f"legtip_{tag}" if len(plan) == 1 else None)
        grid.append({"config": config, "ap": got["best"]["ap"],
                     "auc": got["best"]["auc"], "epoch": got["best"]["epoch"],
                     "epochs": got["epochs"]})
        if result is None or got["best"]["ap"] > result["best"]["ap"]:
            result = {**got, "config": config}
    if len(plan) > 1:
        print(f"\n=== найкраща: {label_of(result['config'])} ===")
        result = {**run(built, rows, args.epochs, result["config"]["hidden"],
                        args.heads, result["config"]["lr"],
                        patience=args.patience, seed=args.seed,
                        loss=args.loss, attention=not args.no_attention,
                        pos_weight=args.pos_weight,
                        keep=MODELS / f"legtip_{tag}"),
                  "config": result["config"]}
    result["grid"] = grid
    report = report_of(built, meta, result, tag)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / f"legtip_{tag}.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    shown = epochs_of(built, rows, result, tag, meta)
    (args.out / f"legtip_{tag}_epochs.json").write_text(
        json.dumps(shown, ensure_ascii=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / f'legtip_{tag}.json'}")


if __name__ == "__main__":
    main()
