"""Етап 1: уточнювач сигналу — у зоні півота чи корекції мітку несе лише сигнал.

Дослідження: research/36-canvas600-pivots/ → Етап 1, «Уточнення сигналу»

## Хід

1. Канви — `canvas600_data.py` (`data/canvas600/`). Параметри обираються
   на базових канвах train (`kind == "base"`: нога на рядках 50 … 549),
   val — тільки замір.
2. **Сила сигналу рядка** з параметрами `(F, h, stat)`: `a(r)` — середнє
   `|x|` фіч набору `F` (одна з семи або всі сім) у рядку `r`;
   `s(r)` — `stat` (`mean` чи `max`) від `a` у вікні `r − h … r + h`.
3. **Пік** — за стандартом дослідження пік шукається **у вікні
   однакової довжини для всіх**: рядок півота (рядок канви, куди лягає
   запис півота) `± P` рядків, `P` той самий для півотів, корекцій і
   контролів. Розмір зони пошуку не задає: зона півота 2.3 ширша за
   зону корекції, і максимум, узятий з більшої кількості рядків, був
   би більшим сам собою. Пік — живий рядок вікна з найбільшим `s`.
   Зона має сигнал, коли `s(пік) ≥ τ_q`: `τ_q` — `q`-й квантиль `s` по
   рядках тіла (мітка 0, живі) базових канв train.
4. **Уточнений сигнал** — вікно канви `пік ± h` рядків × 7 фіч (усі сім,
   не набір `F`), `repr` — як є (`signed`) чи по модулю (`abs`).
5. **Частини датасету** на базових канвах: `start` — зона півота початку
   ноги, `end` — кінця, `corr` — зони корекцій 0.8, і три контролі —
   `pre` (рядки 0 … 49), `body` (50 … 549, 3 на канву), `post`
   (550 … 599): випадковий центр, у якого `± P_MAX` рядків поза зонами
   (seed `SEED`), і той самий хід — пік у `центр ± P`, поріг, вікно.
6. **Кореляції** — Пірсон між векторами вікон різних ніг (пари однієї
   ноги не беруться). `M[a, b]` — середня кореляція вікон частини `a` з
   вікнами частини `b`. **Розрив цілі** `T` =
   `M[T, T] − max(M[T, pre], M[T, body], M[T, post])`: наскільки сигнали
   цілі схожі між собою більше, ніж на звичайні частини ряду. **Бал** —
   середній розрив трьох цілей. На частину — до `SAMPLE` вікон.
7. **Грід** `F × h × stat × P × repr × q`; обирається найбільший бал серед
   варіантів, де сигнал є щонайменше в `MIN_KEPT` зон кожної цілі.
8. **Уточнені мітки** всіх вікон train і val: у кожній зоні мітку
   (2 — півот, 1 — корекція) отримує тільки суцільний відрізок рядків
   вікна пошуку навколо піку з `s ≥ τ`; решта рядків зони і вся зона без
   сигналу — `−1` (не штрафується і не нагороджується).
9. **Профіль фіч** обраного варіанта: середнє кожної з 7 фіч на зсувах
   `−12 … +12` рядків від піку — початок, кінець, корекції, звичайна
   частина ноги (`body`); по модулю і зі знаком окремо для вершин і
   днів; train і val.
10. **Сусідні півоти однієї ноги** (`--pairs`) — на базових канвах, де
    є і початок, і кінець ноги: кореляція вікна початку з вікном кінця
    тієї самої ноги, з кінцем випадкової іншої ноги (перестановка,
    seed 36) і кожного з тілом своєї канви; 95 % інтервал різниці «своя −
    чужа» — 2000 перевибірок ніг. Усі ноги і лише ті, де обидва півоти
    з сигналом.
11. **UMAP** уточнених сигналів обраного варіанта: початок, кінець,
   корекції і звичайні частини ніг (відрізки `body`), train і val,
   три метрики, `n_neighbors 15`, `min_dist 0.1`, seed 36.
12. **k-means на UMAP** (`--kmeans`) — на координатах кожної карти
    (train і val × три метрики) k-means на 2 кластери, `n_init 10`,
    seed 36; склад кластерів за частинами. Нумерація однакова для всіх
    карт: кластер 1 — той, де більша частка початків і кінців ноги.
    Там само — **HDBSCAN** на тих самих координатах: кількість кластерів
    визначає сам, `min_cluster_size 50`, `min_samples 10`, точки поза
    кластерами — шум; нумерація — за спаданням частки початків і кінців.
13. **3D UMAP кластерів** (`--cluster3d`) — точки кожного кластера
    кожної карти окремою 3D-картою: ті самі вектори уточненого сигналу,
    та сама метрика, 3 компоненти, `n_neighbors 15`, `min_dist 0.1`,
    seed 36.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas600_signal.py
    python3 research/36-canvas600-pivots/scripts/canvas600_signal.py --pairs
    python3 research/36-canvas600-pivots/scripts/canvas600_signal.py --kmeans
    python3 research/36-canvas600-pivots/scripts/canvas600_signal.py --cluster3d

Вихід: data/canvas600/<part>_refined.npy; results/canvas600.json (звід),
results/canvas600_umap.json (карти).
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from canvas600_data import OUT as DATA  # noqa: E402
from class210x10m1x7dd import FEATURES  # noqa: E402

RESULTS = RESEARCH / "results"
SETS = tuple((one,) for one in range(7)) + (tuple(range(7)),)
HALVES = (1, 2, 4, 7, 12)
REACHES = (2, 4, 8)            # P: рядків пошуку піку в кожен бік
P_MAX = max(REACHES)
PROFILE = 12                   # рядків профілю в кожен бік від піку
BOOT = 2000                    # перевибірок ніг для інтервалу різниці пар
STATS = ("mean", "max")
REPRS = ("signed", "abs")
QUANTILES = (0.5, 0.7, 0.8, 0.9)
TARGETS = ("start", "end", "corr")
CONTROLS = ("pre", "body", "post")
PARTS = TARGETS + CONTROLS
CONTROL_ROWS = {"pre": (0, 50), "body": (50, 550), "post": (550, 600)}
BODY_PER_WINDOW = 3
SAMPLE = 600
MIN_KEPT = 0.6
SEED = 36
UMAP_PARAMS = {"n_neighbors": 15, "min_dist": 0.1, "random_state": 36}
METRICS = ("cosine", "euclidean", "manhattan")
KMEANS = 2                     # кластерів k-means на картах UMAP
HDBSCAN_MIN_SIZE = 50          # найменший кластер HDBSCAN, точок
HDBSCAN_MIN_SAMPLES = 10       # щільність ядра HDBSCAN
UMAP_CAP = {"start": 800, "end": 800, "corr": 1200, "body": 1200}


def strength(x: np.ndarray, features: tuple, half: int, stat: str) -> np.ndarray:
    """`s(r)` на канвах `(N, rows, 7)`: `stat` від середнього `|x|` набору."""
    a = np.abs(x[..., list(features)]).mean(axis=-1)
    padded = np.pad(a, ((0, 0), (half, half)))
    view = np.lib.stride_tricks.sliding_window_view(padded, 2 * half + 1,
                                                    axis=1)
    return view.mean(axis=-1) if stat == "mean" else view.max(axis=-1)


def peak_of(s: np.ndarray, rows: np.ndarray) -> int:
    """Рядок зони з найбільшою силою."""
    return int(rows[np.argmax(s[rows])])


def window_at(x: np.ndarray, row: int, half: int) -> np.ndarray:
    """Вікно `row ± half` × 7; біля краю канви зсувається всередину."""
    row = min(max(row, half), x.shape[0] - 1 - half)
    return x[row - half:row + half + 1]


def run_around(s: np.ndarray, rows: np.ndarray, peak: int,
               floor: float) -> np.ndarray:
    """Суцільний відрізок рядків зони навколо піку з `s ≥ floor`."""
    inside = np.zeros(len(s), dtype=bool)
    inside[rows] = True
    strong = inside & (s >= floor)
    if not strong[peak]:
        return np.zeros(0, dtype=np.int64)
    lo = hi = peak
    while lo > 0 and strong[lo - 1]:
        lo -= 1
    while hi + 1 < len(s) and strong[hi + 1]:
        hi += 1
    return np.arange(lo, hi + 1)


def correlation_matrix(vectors: np.ndarray, part: np.ndarray,
                       leg: np.ndarray, parts=PARTS) -> np.ndarray:
    """`M[a, b]` — середній Пірсон вікон частини `a` з вікнами `b` інших ніг."""
    z = vectors - vectors.mean(axis=1, keepdims=True)
    norm = np.linalg.norm(z, axis=1, keepdims=True)
    z = np.divide(z, norm, out=np.zeros_like(z), where=norm > 0)
    gram = z @ z.T
    other = leg[:, None] != leg[None, :]
    out = np.full((len(parts), len(parts)), np.nan)
    for i, a in enumerate(parts):
        for j, b in enumerate(parts):
            pick = other & (part == a)[:, None] & (part == b)[None, :]
            if pick.any():
                out[i, j] = float(gram[pick].mean())
    return out


def gaps_of(matrix: np.ndarray, parts=PARTS) -> dict:
    """Розрив кожної цілі й бал."""
    at = {name: i for i, name in enumerate(parts)}
    gaps = {}
    for target in TARGETS:
        row = matrix[at[target]]
        gaps[target] = float(row[at[target]]
                             - np.nanmax([row[at[c]] for c in CONTROLS]))
    gaps["score"] = float(np.mean([gaps[t] for t in TARGETS]))
    return gaps


def load(part: str, data: Path = DATA) -> dict:
    x = np.load(data / f"{part}_x.npy")
    with np.load(data / f"{part}.npz") as store:
        meta = {name: store[name] for name in store.files}
    with np.load(data / f"{part}_zones.npz") as store:
        zones = {name: store[name] for name in store.files}
    return {"x": x, "meta": meta, "zones": zones}


def zone_rows_of(meta: dict, window: int, local: int, role: str) -> np.ndarray:
    """Живі рядки зони `local` вікна `window`."""
    owner = meta["corr" if role == "corr" else "pivot"][window]
    return np.flatnonzero((owner == local) & meta["mask"][window])


def local_numbers(zones: dict) -> np.ndarray:
    """Номер зони всередині свого вікна (порядок переліку)."""
    out = np.zeros(len(zones["window"]), dtype=np.int64)
    for window in np.unique(zones["window"]):
        where = np.flatnonzero(zones["window"] == window)
        out[where] = np.arange(len(where))
    return out


def pivot_row(meta: dict, window: int, index: int) -> int:
    """Рядок канви, куди лягає запис півота (найближчий живий)."""
    first, last = meta["first"][window], meta["last"][window]
    alive = first >= 0
    a = first + meta["start"][window]
    b = last + meta["start"][window]
    hit = np.flatnonzero(alive & (a <= index) & (b >= index))
    if len(hit):
        return int(hit[0])
    rows = np.flatnonzero(alive)
    return int(rows[np.argmin(np.abs(a[rows] - index))])


def search_rows(mask: np.ndarray, centre: int, reach: int) -> np.ndarray:
    """Живі рядки вікна пошуку `centre ± reach`."""
    lo, hi = max(centre - reach, 0), min(centre + reach, len(mask) - 1)
    rows = np.arange(lo, hi + 1)
    rows = rows[mask[rows]]
    return rows if len(rows) else np.array([centre])


def base_items(store: dict, rng) -> dict:
    """Усі частини базових канв: вікно, центр пошуку, частина, нога, вершина."""
    meta, zones = store["meta"], store["zones"]
    base = np.flatnonzero(meta["kind"] == "base")
    items = {"window": [], "centre": [], "part": [], "leg": [], "top": [],
             "index": []}
    is_base = np.zeros(len(meta["kind"]), dtype=bool)
    is_base[base] = True
    for number in np.flatnonzero(is_base[zones["window"]]):
        role = str(zones["role"][number])
        if role not in TARGETS:
            continue
        window = int(zones["window"][number])
        items["window"].append(window)
        items["centre"].append(pivot_row(meta, window,
                                         int(zones["index"][number])))
        items["part"].append(role)
        items["leg"].append(int(meta["leg"][window]))
        items["top"].append(bool(zones["top"][number]))
        items["index"].append(int(zones["index"][number]))
    width = 2 * P_MAX + 1
    for window in base:
        free = (meta["label"][window] == 0) & meta["mask"][window]
        for part, (lo, hi) in CONTROL_ROWS.items():
            starts = [r for r in range(max(lo, 0), hi - width + 1)
                      if free[r:r + width].all()]
            for _ in range(BODY_PER_WINDOW if part == "body" else 1):
                if not starts:
                    continue
                begin = int(rng.choice(starts))
                items["window"].append(int(window))
                items["centre"].append(begin + P_MAX)
                items["part"].append(part)
                items["leg"].append(int(meta["leg"][window]))
                items["top"].append(bool(meta["up"][window]))
                items["index"].append(-1)
    return {name: np.asarray(value) for name, value in items.items()}


def body_floor(x: np.ndarray, meta: dict, windows: np.ndarray,
               features: tuple, half: int, stat: str) -> np.ndarray:
    """Сили всіх живих рядків тіла (мітка 0) вікон `windows`."""
    s = strength(np.asarray(x[windows]), features, half, stat)
    free = (meta["label"][windows] == 0) & meta["mask"][windows]
    return s[free]


def peaks_of(store: dict, items: dict, features: tuple, half: int,
             stat: str, reach: int) -> tuple:
    """Пік кожної частини у вікні `центр ± reach` і його сила."""
    windows = np.unique(items["window"])
    s = strength(np.asarray(store["x"][windows]), features, half, stat)
    at = {int(w): i for i, w in enumerate(windows)}
    mask = store["meta"]["mask"]
    peaks, power = [], []
    for window, centre in zip(items["window"], items["centre"]):
        one = s[at[int(window)]]
        peak = peak_of(one, search_rows(mask[window], int(centre), reach))
        peaks.append(peak)
        power.append(one[peak])
    return np.asarray(peaks), np.asarray(power)


def evaluate(store: dict, items: dict, features: tuple, half: int,
             stat: str, reach: int, floors: dict, rng,
             sample: int = SAMPLE) -> list:
    """Усі `repr × q` для одного `(F, h, stat, P)`: бал, розриви, частка з сигналом."""
    peaks, power = peaks_of(store, items, features, half, stat, reach)
    vectors = np.asarray([window_at(store["x"][w], p, half).ravel()
                          for w, p in zip(items["window"], peaks)],
                         dtype=np.float32)
    out = []
    for q in QUANTILES:
        keep = power >= floors[q]
        kept = {part: float(keep[items["part"] == part].mean())
                for part in PARTS if (items["part"] == part).any()}
        chosen = []
        for part in PARTS:
            where = np.flatnonzero(keep & (items["part"] == part))
            if len(where) > sample:
                where = rng.choice(where, sample, replace=False)
            chosen.append(where)
        chosen = np.sort(np.concatenate(chosen))
        for kind in REPRS:
            v = vectors[chosen] if kind == "signed" else np.abs(vectors[chosen])
            matrix = correlation_matrix(v, items["part"][chosen],
                                        items["leg"][chosen])
            out.append({"features": list(features), "half": half,
                        "stat": stat, "reach": reach, "repr": kind, "q": q,
                        "floor": float(floors[q]), "kept": kept,
                        "matrix": matrix.tolist(),
                        **gaps_of(matrix)})
    return out


def grid(store: dict, items: dict, log=print) -> list:
    meta = store["meta"]
    base = np.flatnonzero(meta["kind"] == "base")
    out = []
    for features, half, stat in itertools.product(SETS, HALVES, STATS):
        body = body_floor(store["x"], meta, base, features, half, stat)
        floors = {q: float(np.quantile(body, q)) for q in QUANTILES}
        for reach in REACHES:
            rng = np.random.default_rng(SEED)
            out.extend(evaluate(store, items, features, half, stat, reach,
                                floors, rng))
        best = max(out, key=lambda one: one["score"])
        log(f"F={features} h={half} {stat}: найкращий бал {best['score']:.4f}")
    return out


def pick(rows: list, min_kept: float = MIN_KEPT) -> dict:
    """Найбільший бал серед варіантів, де сигнал є в ≥ `min_kept` зон цілей."""
    fit = [one for one in rows
           if all(one["kept"].get(t, 0.0) >= min_kept for t in TARGETS)]
    return max(fit or rows, key=lambda one: one["score"])


def refine(store: dict, best: dict, chunk: int = 256) -> tuple:
    """Уточнені мітки всіх вікон частини і скільки рядків / зон лишилось."""
    meta, zones = store["meta"], store["zones"]
    features, half, reach = tuple(best["features"]), best["half"], best["reach"]
    local = local_numbers(zones)
    label = meta["label"].copy()
    by_window = {}
    for number, window in enumerate(zones["window"]):
        by_window.setdefault(int(window), []).append(number)
    count = {"zones": {}, "signal": {}, "rows_before": {}, "rows_after": {}}
    for begin in range(0, len(label), chunk):
        stop = min(begin + chunk, len(label))
        s = strength(np.asarray(store["x"][begin:stop]), features, half,
                     best["stat"])
        for window in range(begin, stop):
            numbers = by_window.get(window, [])
            # спершу корекції, потім півоти: півот 2.3 важливіший
            numbers = sorted(numbers, key=lambda n: zones["role"][n] != "corr")
            for number in numbers:
                role = str(zones["role"][number])
                key = "corr" if role == "corr" else "pivot"
                value = 1 if role == "corr" else 2
                rows = zone_rows_of(meta, window, int(local[number]), role)
                if not len(rows):
                    continue
                one = s[window - begin]
                search = search_rows(meta["mask"][window],
                                     pivot_row(meta, window,
                                               int(zones["index"][number])),
                                     reach)
                peak = peak_of(one, search)
                keep = run_around(one, search, peak, best["floor"])
                mine = rows[label[window, rows] == value]
                label[window, mine] = -1
                if value == 1:
                    keep = keep[label[window, keep] != 2]
                label[window, keep] = value
                count["zones"][key] = count["zones"].get(key, 0) + 1
                count["signal"][key] = count["signal"].get(key, 0) + int(len(keep) > 0)
    for name, value in (("pivot", 2), ("corr", 1)):
        count["rows_before"][name] = int((meta["label"] == value).sum())
        count["rows_after"][name] = int((label == value).sum())
    count["rows_before"]["body"] = int((meta["label"] == 0).sum())
    count["rows_after"]["ignored"] = int((label == -1).sum())
    return label, count


def signal_set(store: dict, best: dict, seed: int = SEED,
               half: int | None = None) -> dict:
    """Уточнені сигнали базових канв: вікна `пік ± half` обраного варіанта."""
    items = base_items(store, np.random.default_rng(seed))
    peaks, power = peaks_of(store, items, tuple(best["features"]),
                            best["half"], best["stat"], best["reach"])
    half = best["half"] if half is None else half
    vectors = np.asarray([window_at(store["x"][w], p, half)
                          for w, p in zip(items["window"], peaks)],
                         dtype=np.float32)
    return {"part": items["part"], "leg": items["leg"], "top": items["top"],
            "window": items["window"], "row": peaks, "power": power,
            "index": items["index"],
            "raw": vectors,
            "vector": (vectors if best["repr"] == "signed"
                       else np.abs(vectors)).reshape(len(vectors), -1)}


def measure(store: dict, best: dict, seed: int = SEED) -> dict:
    """Матриця й розриви обраного варіанта на базових канвах частини."""
    got = signal_set(store, best, seed)
    keep = got["power"] >= best["floor"]
    matrix = correlation_matrix(got["vector"][keep], got["part"][keep],
                                got["leg"][keep])
    kept = {part: float(keep[got["part"] == part].mean())
            for part in PARTS if (got["part"] == part).any()}
    counts = {part: int((got["part"] == part).sum()) for part in PARTS}
    return {"matrix": matrix.tolist(), "kept": kept, "counts": counts,
            **gaps_of(matrix)}


def profile(store: dict, best: dict, seed: int = SEED,
            parts=("start", "end", "corr", "body")) -> dict:
    """Середнє кожної фічі на зсувах `−PROFILE … +PROFILE` від піку:
    по модулю і зі знаком для вершин і днів окремо. Цілі — лише зони з
    сигналом; `body` — без відбору."""
    got = signal_set(store, best, seed, half=PROFILE)
    keep = (got["power"] >= best["floor"]) | (got["part"] == "body")
    out = {"offsets": list(range(-PROFILE, PROFILE + 1)), "parts": {}}
    for part in parts:
        mine = keep & (got["part"] == part)
        one = {"count": int(mine.sum()),
               "abs": np.abs(got["raw"][mine]).mean(axis=0).T.tolist()}
        for name, flag in (("top", True), ("bottom", False)):
            pick = mine & (got["top"] == flag)
            one[f"{name}_count"] = int(pick.sum())
            one[name] = (got["raw"][pick].mean(axis=0).T.tolist()
                         if pick.any() else None)
        out["parts"][part] = one
    return out


def row_corr(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Пірсон рядок до рядка двох масивів векторів."""
    a = a - a.mean(axis=1, keepdims=True)
    b = b - b.mean(axis=1, keepdims=True)
    denom = np.sqrt((a * a).sum(axis=1) * (b * b).sum(axis=1))
    return np.divide((a * b).sum(axis=1), denom,
                     out=np.zeros(len(a)), where=denom > 0)


def pairs(store: dict, best: dict, seed: int = SEED,
          boot: int = BOOT) -> dict:
    """Сусідні півоти 2.3 однієї ноги: початок проти кінця тієї самої
    базової канви, проти кінця випадкової іншої ноги (перестановка) і
    проти тіла своєї канви; 95 % інтервал різниці «своя − чужа»
    перевибіркою ніг. Усі ноги і лише ті, де обидва півоти з сигналом."""
    got = signal_set(store, best, seed)
    keep = got["power"] >= best["floor"]
    out = {}
    for name, only in (("all", False), ("signal", True)):
        by_window = {}
        for i, (window, part) in enumerate(zip(got["window"], got["part"])):
            if part == "body" or not only or keep[i]:
                by_window.setdefault(int(window), {}).setdefault(part, i)
        rows = [(d["start"], d["end"], d["body"]) for d in by_window.values()
                if {"start", "end", "body"} <= set(d)]
        if not rows:
            out[name] = {"legs": 0}
            continue
        start, end, body = (np.asarray(one) for one in zip(*rows))
        rng = np.random.default_rng(seed)
        v = got["vector"]
        same = row_corr(v[start], v[end])
        other = row_corr(v[start], v[end][rng.permutation(len(end))])
        gap = same - other
        spread = [gap[rng.integers(0, len(gap), len(gap))].mean()
                  for _ in range(boot)]
        out[name] = {"legs": int(len(start)), "same": float(same.mean()),
                     "other": float(other.mean()),
                     "start_body": float(row_corr(v[start], v[body]).mean()),
                     "end_body": float(row_corr(v[end], v[body]).mean()),
                     "gap": float(gap.mean()),
                     "gap_ci": [float(q) for q in np.percentile(spread,
                                                                [2.5, 97.5])]}
    return out


def umap_of(store: dict, best: dict, seed: int = SEED) -> dict:
    import umap
    got = signal_set(store, best, seed)
    rng = np.random.default_rng(seed)
    chosen = []
    for part, cap in UMAP_CAP.items():
        where = np.flatnonzero(got["part"] == part)
        if part in TARGETS:
            where = where[got["power"][where] >= best["floor"]]
        if len(where) > cap:
            where = np.sort(rng.choice(where, cap, replace=False))
        chosen.append(where)
    chosen = np.concatenate(chosen)
    vectors = got["vector"][chosen].astype(np.float32)
    finite = np.isfinite(vectors).all(axis=1)
    chosen, vectors = chosen[finite], vectors[finite]
    maps = {}
    for metric in METRICS:
        reducer = umap.UMAP(n_components=2, metric=metric, **UMAP_PARAMS)
        maps[metric] = np.round(reducer.fit_transform(vectors), 4).tolist()
    return {"part": got["part"][chosen].tolist(),
            "top": got["top"][chosen].tolist(),
            "leg": got["leg"][chosen].tolist(),
            "window": got["window"][chosen].tolist(),
            "row": got["row"][chosen].tolist(),
            "power": np.round(got["power"][chosen].astype(float), 4).tolist(),
            "dim": int(vectors.shape[1]), "dropped_nan": int((~finite).sum()),
            "maps": maps}


def kmeans_of(points: np.ndarray, parts: list, k: int = KMEANS,
              seed: int = SEED) -> dict:
    """k-means на координатах карти UMAP: мітка кластера кожної точки і
    склад кластерів за частинами."""
    from sklearn.cluster import KMeans
    labels = KMeans(n_clusters=k, n_init=10,
                    random_state=seed).fit_predict(np.asarray(points))
    parts = np.asarray(parts)
    # нумерація однакова для всіх карт: кластер 1 — той, де більша частка
    # початків і кінців ноги («півотний»), далі за спаданням
    edge = np.isin(parts, ("start", "end"))
    share = [edge[labels == c].mean() if (labels == c).any() else 0.0
             for c in range(k)]
    order = np.argsort(share)[::-1]
    labels = np.argsort(order)[labels]
    names = [str(one) for one in dict.fromkeys(parts.tolist())]
    counts = [{name: int(((labels == c) & (parts == name)).sum())
               for name in names} for c in range(k)]
    return {"labels": labels.tolist(), "counts": counts}


def hdbscan_of(points: np.ndarray, parts: list,
               min_size: int = HDBSCAN_MIN_SIZE,
               min_samples: int = HDBSCAN_MIN_SAMPLES) -> dict:
    """HDBSCAN на координатах карти UMAP: кількість кластерів визначає сам,
    точки поза кластерами — шум (`−1`). Нумерація — за спаданням частки
    початків і кінців ноги в кластері."""
    from sklearn.cluster import HDBSCAN
    raw = HDBSCAN(min_cluster_size=min_size, copy=True,
                  min_samples=min_samples).fit_predict(np.asarray(points))
    parts = np.asarray(parts)
    edge = np.isin(parts, ("start", "end"))
    found = [c for c in np.unique(raw) if c >= 0]
    order = sorted(found, key=lambda c: -edge[raw == c].mean())
    rename = {old: new for new, old in enumerate(order)}
    labels = np.array([rename.get(c, -1) for c in raw])
    names = [str(one) for one in dict.fromkeys(parts.tolist())]
    counts = [{name: int(((labels == c) & (parts == name)).sum())
               for name in names} for c in range(len(order))]
    noise = {name: int(((labels < 0) & (parts == name)).sum()) for name in names}
    return {"labels": labels.tolist(), "counts": counts, "noise": noise}


def auc(a: np.ndarray, b: np.ndarray) -> float:
    """AUC «значення з `a` більше за значення з `b`» (ранги, з нічиїми)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    a, b = a[np.isfinite(a)], b[np.isfinite(b)]
    if not len(a) or not len(b):
        return float("nan")
    both = np.concatenate([a, b])
    order = both.argsort(kind="mergesort")
    ranks = np.empty(len(both))
    ranks[order] = np.arange(1, len(both) + 1)
    for value in np.unique(both):
        same = both == value
        if same.sum() > 1:
            ranks[same] = ranks[same].mean()
    return float((ranks[:len(a)].sum() - len(a) * (len(a) + 1) / 2)
                 / (len(a) * len(b)))


def zone_facts(store: dict, part: str, data_bars: Path | None = None) -> dict:
    """Властивості кожного півота 2.3 і корекції 0.8 частини за записом:
    розмір руху, який він закінчує (%), довжина цього руху (записів),
    місце в нозі 2.3 (частка) і відстань до найближчого півота 2.3 в
    частках ноги; для півота 2.3 — ще довжина і рух ноги, яку він
    починає або кінчає."""
    import canvas600_data as d
    from bars30 import DATA as BARS
    bars = data_bars or BARS
    table = json.loads((bars / "legs.json").read_text(encoding="utf-8"))
    out = {}
    for pair in np.unique(store["meta"]["pair"]):
        pair = str(pair)
        legs = table["legs"][pair][part]
        with np.load(bars / f"{pair}_{part}.npz") as one:
            opens, close = one["open"], one["close"]
        pivots = d.with_neighbours(d.pivots_of(legs, close), len(close))
        corrections = d.corrections_of(legs, opens, close, pivots)
        edge = pivots["index"]
        facts = {}
        for n, p in enumerate(edge):
            before = edge[n - 1] if n else None
            facts[int(p)] = {
                "move": (abs(close[p] / close[before] - 1) * 100
                         if before is not None else float("nan")),
                "bars": float(p - before) if before is not None else float("nan")}
        for n, q in enumerate(corrections["index"]):
            k = int(corrections["leg"][n])
            a, b = edge[k], edge[k + 1]
            left = corrections["left"][n]
            facts[int(q)] = {
                "move": abs(close[q] / close[left] - 1) * 100,
                "bars": float(q - left),
                "place": float((q - a) / (b - a)),
                "near": float(min(q - a, b - q) / (b - a))}
        out[pair] = facts
    return out


def decode(store: dict, best: dict, maps: dict, part: str,
           metric: str = "cosine") -> dict:
    """Чим кластер 1 k-means відрізняється від кластера 2 на карті
    `metric`: середнє `|x|` кожної фічі у вікні сигналу, AUC фічі
    «кластер 1 проти 2» — на всіх точках і на корекціях окремо, і
    властивості зон (розмір, довжина, місце в нозі, відстань до півота)."""
    got = signal_set(store, best)
    at = {(int(w), str(p), int(r)): i for i, (w, p, r) in
          enumerate(zip(got["window"], got["part"], got["row"]))}
    one = maps[part]
    labels = np.asarray(maps["kmeans"][part][metric]["labels"])
    item = np.asarray([at.get((w, p, r), -1) for w, p, r in
                       zip(one["window"], one["part"], one["row"])])
    raw = got["vector"][item].reshape(len(item), -1, 7)
    level = np.abs(raw).mean(axis=1)             # (точки, 7)
    parts = np.asarray(one["part"])
    facts = zone_facts(store, part)
    pair = store["meta"]["pair"][np.asarray(one["window"])]
    index = got["index"][item]
    names = ("move", "bars", "place", "near")
    zone = {name: np.array([facts[str(pr)].get(int(i), {}).get(name, np.nan)
                            if i >= 0 else np.nan
                            for pr, i in zip(pair, index)]) for name in names}
    out = {"metric": metric, "features": list(FEATURES), "clusters": []}
    for c in range(KMEANS):
        mine = labels == c
        row = {"cluster": c + 1, "points": int(mine.sum()),
               "level": level[mine].mean(axis=0).tolist(),
               "parts": {}}
        for name in ("start", "end", "corr", "body"):
            pick = mine & (parts == name)
            row["parts"][name] = {"count": int(pick.sum()),
                                  **{key: float(np.nanmedian(zone[key][pick]))
                                     if np.isfinite(zone[key][pick]).any()
                                     else None for key in names}}
        out["clusters"].append(row)
    first, second = labels == 0, labels == 1
    corr = parts == "corr"
    out["auc"] = [auc(level[first, f], level[second, f]) for f in range(7)]
    out["auc_corr"] = [auc(level[first & corr, f], level[second & corr, f])
                       for f in range(7)]
    out["auc_zone_corr"] = {key: auc(zone[key][first & corr],
                                     zone[key][second & corr])
                            for key in names}
    edges = np.isin(parts, ("start", "end"))
    out["auc_zone_edge"] = {key: auc(zone[key][first & edges],
                                     zone[key][second & edges])
                            for key in ("move", "bars")}
    return out


def kmeans_maps(path: Path) -> dict:
    """k-means на кожній карті файлу UMAP; результат — у той самий файл."""
    maps = json.loads(path.read_text(encoding="utf-8"))
    maps["kmeans"] = {"k": KMEANS, "seed": SEED, "n_init": 10}
    maps["hdbscan"] = {"min_cluster_size": HDBSCAN_MIN_SIZE,
                       "min_samples": HDBSCAN_MIN_SAMPLES}
    for part in ("train", "val"):
        if part not in maps:
            continue
        maps["kmeans"][part] = {
            metric: kmeans_of(points, maps[part]["part"])
            for metric, points in maps[part]["maps"].items()}
        maps["hdbscan"][part] = {
            metric: hdbscan_of(points, maps[part]["part"])
            for metric, points in maps[part]["maps"].items()}
    path.write_text(json.dumps(maps, ensure_ascii=False), encoding="utf-8")
    return maps["kmeans"]


def cluster_umap3d(store: dict, best: dict, one: dict, labels: list,
                   metric: str, cluster: int) -> dict:
    """3D UMAP точок одного кластера k-means: ті самі вектори уточненого
    сигналу (вікно `пік ± h` обраного варіанта), та сама метрика."""
    import umap
    pick = np.flatnonzero(np.asarray(labels) == cluster)
    vectors = np.asarray([window_at(store["x"][one["window"][i]],
                                    one["row"][i], best["half"]).ravel()
                          for i in pick], dtype=np.float32)
    if best["repr"] == "abs":
        vectors = np.abs(vectors)
    reducer = umap.UMAP(n_components=3, metric=metric, **UMAP_PARAMS)
    return {"index": pick.tolist(),
            "points": np.round(reducer.fit_transform(vectors), 4).tolist()}


def cluster_maps(path: Path, data: Path = DATA) -> dict:
    """3D UMAP кожного кластера k-means на кожній карті; у той самий файл."""
    maps = json.loads(path.read_text(encoding="utf-8"))
    best = json.loads((path.parent / "canvas600.json").read_text(
        encoding="utf-8"))["best"]
    out = {"clusters": list(range(1, KMEANS + 1)), "params": UMAP_PARAMS,
           "hdbscan": {}}
    for part in ("train", "val"):
        if part not in maps:
            continue
        store = load(part, data)
        out[part] = {metric: {str(c + 1): cluster_umap3d(
            store, best, maps[part], maps["kmeans"][part][metric]["labels"],
            metric, c) for c in range(KMEANS)} for metric in maps["metrics"]}
        if "hdbscan" in maps:
            out["hdbscan"][part] = {metric: {str(c + 1): cluster_umap3d(
                store, best, maps[part], maps["hdbscan"][part][metric]["labels"],
                metric, c) for c in range(len(maps["hdbscan"][part][metric]["counts"]))}
                for metric in maps["metrics"]}
    maps["cluster3d"] = out
    path.write_text(json.dumps(maps, ensure_ascii=False), encoding="utf-8")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--decode", action="store_true",
                        help="розшифровка кластерів 1 і 2 k-means (cosine)")
    parser.add_argument("--cluster3d", action="store_true",
                        help="3D UMAP кожного кластера k-means на готових картах")
    parser.add_argument("--kmeans", action="store_true",
                        help="k-means на 2 кластери на готових картах UMAP")
    parser.add_argument("--pairs", action="store_true",
                        help="лише сусідні півоти однієї ноги — у готовий звід")
    args = parser.parse_args()
    if args.decode:
        path = args.results / "canvas600.json"
        report = json.loads(path.read_text(encoding="utf-8"))
        maps = json.loads((args.results / "canvas600_umap.json").read_text(
            encoding="utf-8"))
        report["decode"] = {part: decode(load(part, args.data),
                                         report["best"], maps, part)
                            for part in ("train", "val")}
        path.write_text(json.dumps(report, ensure_ascii=False),
                        encoding="utf-8")
        print(json.dumps(report["decode"], ensure_ascii=False)[:3000])
        return
    if args.cluster3d:
        got = cluster_maps(args.results / "canvas600_umap.json", args.data)
        for part in ("train", "val"):
            for metric, one in got.get(part, {}).items():
                print(part, metric, {c: len(v["index"]) for c, v in one.items()})
        return
    if args.kmeans:
        got = kmeans_maps(args.results / "canvas600_umap.json")
        for part in ("train", "val"):
            for metric, one in got.get(part, {}).items():
                print(part, metric, one["counts"])
        maps = json.loads((args.results / "canvas600_umap.json").read_text(
            encoding="utf-8"))
        for part in ("train", "val"):
            for metric, one in maps["hdbscan"].get(part, {}).items():
                print("hdbscan", part, metric, len(one["counts"]),
                      one["counts"], "шум", one["noise"])
        return
    if args.pairs:
        path = args.results / "canvas600.json"
        report = json.loads(path.read_text(encoding="utf-8"))
        report["pairs"] = {part: pairs(load(part, args.data), report["best"])
                           for part in ("train", "val")}
        path.write_text(json.dumps(report, ensure_ascii=False),
                        encoding="utf-8")
        print(report["pairs"])
        return
    train = load("train", args.data)
    items = base_items(train, np.random.default_rng(SEED))
    rows = grid(train, items)
    best = pick(rows)
    print(f"обрано: {best['features']} h={best['half']} P={best['reach']} {best['stat']} "
          f"{best['repr']} q={best['q']} бал {best['score']:.4f}")
    report = {"features": list(FEATURES), "grid": rows,
              "best": {k: v for k, v in best.items()},
              "params": {"sets": [list(one) for one in SETS],
                         "halves": list(HALVES), "stats": list(STATS),
                         "reaches": list(REACHES), "profile": PROFILE,
                         "reprs": list(REPRS), "quantiles": list(QUANTILES),
                         "sample": SAMPLE, "min_kept": MIN_KEPT,
                         "seed": SEED}}
    build = args.data / "build.json"
    if build.exists():
        report["build"] = json.loads(build.read_text(encoding="utf-8"))
    report["measure"], report["refined"], report["profile"], maps = \
        {}, {}, {}, {}
    for part in ("train", "val"):
        store = train if part == "train" else load(part, args.data)
        report["measure"][part] = measure(store, best)
        report["profile"][part] = profile(store, best)
        report.setdefault("pairs", {})[part] = pairs(store, best)
        label, count = refine(store, best)
        np.save(args.data / f"{part}_refined.npy", label)
        report["refined"][part] = count
        maps[part] = umap_of(store, best)
        print(f"{part}: {report['measure'][part]['score']:.4f} {count}")
    args.results.mkdir(parents=True, exist_ok=True)
    (args.results / "canvas600.json").write_text(
        json.dumps(report, ensure_ascii=False), encoding="utf-8")
    (args.results / "canvas600_umap.json").write_text(json.dumps(
        {"params": UMAP_PARAMS, "metrics": list(METRICS),
         "best": {k: best[k] for k in ("features", "half", "stat", "reach",
                                       "repr", "q", "floor")},
         **maps}, ensure_ascii=False), encoding="utf-8")
    kmeans_maps(args.results / "canvas600_umap.json")
    cluster_maps(args.results / "canvas600_umap.json", args.data)


if __name__ == "__main__":
    main()
