"""Етап 15: найкраща довжина вікна канви окремо на train і val.

Дослідження: research/36-canvas600-pivots/ → Етап 15

## Хід

1. **Вікна** — сталі вікна рівномірної довжини етапу 14 (`pick_by_length`,
   довжина рівно від години до 12 діб, від 1 до 8 півотів): train —
   `FIXED` нових вікон зі шматків train до різу (ті, на яких учились,
   seed 12), val — `val_len` етапу 14.
2. **Модель** — найкраща епоха прогону `--run` (за замовчуванням
   `RL_tune`), пороги голів — з її відкладених.
3. **Міра** — лічильники кожного вікна як в етапі 11 (`counts_of`),
   вікна діляться за довжиною на кошики по `BIN_HOURS` годин; у кошику —
   F1 кожної голови і середній F1 трьох. Найкраща довжина — кошик з
   найбільшим середнім F1, окремо на train і на val.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_length.py --fixed
    python3 research/36-canvas600-pivots/scripts/canvas1100_length.py --run RL_tune

Вихід: data/canvas1100_random/train_len_*.npy;
results/canvas1100_random/<прогін>_length.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_grow as grow  # noqa: E402
import canvas1100_random as rnd  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_net import device_of  # noqa: E402

HEADS = grow.HEADS
BIN_HOURS = 24
LONGEST_HOURS = 12 * 24
PARTS = (("train", "train_len"), ("val", "val_len"))


def build_train(out: Path = rnd.DATA, size: int = rnd.FIXED, log=print) -> None:
    """Сталі вікна рівномірної довжини зі шматків train до різу."""
    cut = json.loads((grow.DATA / "train_build.json").read_text(encoding="utf-8"))["cut"]
    rng = np.random.default_rng(rnd.SEED)
    stream = rnd.regions("train", rnd.bounds_of("train", cut, "inside"), rng, length=True)
    rows = [next(stream) for _ in range(size)]
    out.mkdir(parents=True, exist_ok=True)
    for key in ("x", "code", "owner", "mask"):
        value = np.stack([r[key] for r in rows])
        np.save(out / f"train_len_{key}.npy", value.astype(np.float16) if key == "x" else value)
    np.savez(out / "train_len_meta.npz", pair=np.array([r["pair"] for r in rows]),
             n=np.array([r["n"] for r in rows]), start=np.array([r["start"] for r in rows]),
             end=np.array([r["end"] for r in rows]),
             scalars=np.stack([r["scalars"] for r in rows]))
    log(f"train_len: {len(rows)} вікон, N {np.bincount([r['n'] for r in rows]).tolist()}")


def hours_of(data: dict) -> np.ndarray:
    return (np.asarray(data["end"]) - np.asarray(data["start"]) + 1) * c.BAR / 3600


def bins_of(hours: np.ndarray, width: int = BIN_HOURS, longest: int = LONGEST_HOURS) -> np.ndarray:
    """Кошик довжини: `[0, width)` годин — 0, `[width, 2·width)` — 1, …"""
    return np.minimum((hours // width).astype(int), longest // width - 1)


def by_length(counts: np.ndarray, hours: np.ndarray, width: int = BIN_HOURS,
              longest: int = LONGEST_HOURS) -> list:
    """F1 голів і середній F1 у кожному кошику довжини."""
    where = bins_of(hours, width, longest)
    out = []
    for b in range(longest // width):
        pick = where == b
        if not pick.any():
            continue
        got = grow.summary_of(counts[pick])
        out.append({"from_h": b * width, "to_h": (b + 1) * width, "windows": int(pick.sum()),
                    **{h: got[h]["model"] for h in HEADS},
                    "base": {h: got[h]["base"]["f1"] for h in HEADS},
                    "mean_f1": grow.mean_f1(got)})
    return out


def best_of(rows: list) -> dict:
    return max(rows, key=lambda one: one["mean_f1"])


def measure(run: str, device, log=print) -> dict:
    result = json.loads((rnd.RESULTS / f"{run}.json").read_text(encoding="utf-8"))
    epoch, thresholds = result["best_epoch"], result["thresholds"]
    model = Finder3(rows=grow.ROWS, outputs=3)
    model.load_state_dict(torch.load(rnd.MODELS / run / f"epoch_{epoch:02d}.pt",
                                     map_location="cpu"))
    model.to(device).eval()
    out = {"run": run, "epoch": epoch, "thresholds": thresholds, "bin_hours": BIN_HOURS}
    for part, name in PARTS:
        data = rnd.load_fixed(name)
        _, counts = rnd.score(model, data, device, thresholds)
        rows = by_length(counts, hours_of(data))
        best = best_of(rows)
        out[part] = {"bins": rows, "best": {"from_h": best["from_h"], "to_h": best["to_h"],
                                            "mean_f1": best["mean_f1"]}}
        log(f"{part}: " + " | ".join(f"{r['from_h']}–{r['to_h']} год {r['mean_f1']:.3f}"
                                     for r in rows))
        log(f"{part}: найкраща довжина {best['from_h']}–{best['to_h']} год, "
            f"середній F1 {best['mean_f1']:.3f}")
    (rnd.RESULTS / f"{run}_length.json").write_text(
        json.dumps(clean(out), ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--fixed", action="store_true")
    parser.add_argument("--run")
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    if args.fixed:
        build_train()
    if args.run:
        measure(args.run, device_of(args.device))


if __name__ == "__main__":
    main()
