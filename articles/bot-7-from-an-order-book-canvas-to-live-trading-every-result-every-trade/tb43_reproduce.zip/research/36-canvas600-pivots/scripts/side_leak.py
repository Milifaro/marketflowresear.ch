"""Етап 16, крок 0: чи заглядає вперед голова «бік ноги».

Дослідження: research/36-canvas600-pivots/ → Етап 16

Голова «бік ноги» (дослідження 33, ряд `heads33_run.py --holes`)
будується ланцюжком мереж на ногах зігзага 2.3 % на ема10. Замір
прямий: копія продовжених датасетів усіх монет обрізається в момент `T`
(усі події пізніше `T` прибрано з val і test), на ній проганяється
**весь** ланцюжок `heads33_run` з винятком `/umap600` (відкрита нога
на хвості) — так голова виглядала б наживо в `T`. Потім на спільних
подіях до `T` порівнюється з готовим рядом, порахованим на всьому val.
Різниця — те, що ряд знав про майбутнє після `T`.

Вихід: results/side_leak/<T>.json — різниця p_side і її ема 200 за
відстанню від `T` (години).

**Етап 18** (`--live`): ланцюжок `heads33_run --live` (мережа зон на
ногах від 1 події), готовий ряд — `results/heads33_live/`. Копія
обрізається в `T` **повністю**: кожен `.npz`, у якому є події пізніше
`T`, переписується без них — і train теж (датасети `клас210х14х*` з
`BTC_USDT_29` і `<PAIR>_fill` перемішані по train / val / test за часом,
у старому режимі їхній train ішов посиланням цілим). Кілька монет
(`--pairs`), робоча копія стирається після кожного `T`. Вихід —
`results/side_leak_live/<PAIR>_<T>.json`.

Запуск:
    python3 research/36-canvas600-pivots/scripts/side_leak.py --at 2026-09-05T22:00 2026-09-18T12:00
    python3 research/36-canvas600-pivots/scripts/side_leak.py --live --pairs BTC_USDT ETH_USDT --at 2026-09-05T22:00
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import heads33_run as h  # noqa: E402

PAIR = "BTC_USDT"
WORK = RESEARCH / "data" / "side_leak"
OUT = RESEARCH / "results" / "side_leak"
FULL = h.OUT_HOLES
OUT_LIVE = RESEARCH / "results" / "side_leak_live"
EMA = 200
BANDS = (0, 1, 3, 6, 12, 24, 48, 96, 160)


def cut_root(at: int, root: Path, source: Path = h.EXT, whole: bool = False) -> None:
    """Копія датасетів монети без подій після `at`: train — посиланням,
    val і test — обрізані за часом події; `whole` — обрізається кожен
    файл, де є події після `at`, і train теж."""
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    for path in source.glob("*.json"):
        shutil.copy(path, root / path.name)
    for folder in sorted(p for p in source.iterdir() if p.is_dir()):
        for path in folder.rglob("*"):
            target = root / path.relative_to(source)
            if path.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix != ".npz" or (path.stem == "train" and not whole):
                target.symlink_to(path)
                continue
            with np.load(path, allow_pickle=True) as store:
                data = {key: store[key] for key in store.files}
            key = "t_start" if "t_start" in data else "timestamp"
            keep = data[key] <= at
            if whole and keep.all():
                target.symlink_to(path)
                continue
            size = len(keep)
            np.savez(target, **{k: (v[keep] if v.ndim and len(v) == size else v)
                                for k, v in data.items()})


PATCHED = False


def run_chain(root: Path, out: Path, legleft: Path, pair: str = PAIR,
              live: bool = False) -> None:
    """Увесь ланцюжок `heads33_run --holes` (`--live`) на обрізаній копії."""
    global PATCHED
    h.EXT, h.OUT, h.LEGLEFT = root, out, legleft
    h.PAIRS = (pair,)
    out.mkdir(parents=True, exist_ok=True)
    h.redirect()
    if not PATCHED:
        if live:
            h.allow_short()
        h.allow_holes()
        PATCHED = True
    h.legleft_cache(legleft)
    h.outputs((pair,), tail=True)
    h.heads((pair,))


def ema_of(values: np.ndarray, span: int = EMA) -> np.ndarray:
    """Ема по подіях, пропуски тримають попереднє значення."""
    alpha = 2.0 / (span + 1.0)
    out = np.full(len(values), np.nan)
    run = None
    for i, v in enumerate(values):
        if np.isfinite(v):
            run = v if run is None else alpha * v + (1 - alpha) * run
        out[i] = np.nan if run is None else run
    return out


def compare(at: int, full: dict, live: dict) -> dict:
    """Різниця живого ряду з готовим на спільних подіях до `at`, за
    відстанню від `at` у годинах."""
    def table(one):
        t = np.asarray(one["t"])
        p = np.array([np.nan if v is None else v for v in one["p_side"]], float)
        return t, p, ema_of(p)
    tf, pf, ef = table(full)
    tl, pl, el = table(live)
    common, a, b = np.intersect1d(tf[tf <= at], tl, return_indices=True)
    back = (at - common) / 3600
    out = {"at": at, "events": int(len(common)), "bands": []}
    for lo, hi in zip(BANDS, BANDS[1:]):
        pick = (back >= lo) & (back < hi)
        both = pick & np.isfinite(pf[a]) & np.isfinite(pl[b])
        raw = np.abs(pf[a][both] - pl[b][both])
        smooth = np.abs(ef[a][both] - el[b][both])
        out["bands"].append({
            "from_h": lo, "to_h": hi, "events": int(pick.sum()),
            "said_full": int(np.isfinite(pf[a][pick]).sum()),
            "said_live": int(np.isfinite(pl[b][pick]).sum()),
            "raw_max": float(raw.max()) if len(raw) else None,
            "raw_mean": float(raw.mean()) if len(raw) else None,
            "ema_max": float(smooth.max()) if len(smooth) else None,
            "ema_mean": float(smooth.mean()) if len(smooth) else None,
            "side_flip": float(((pf[a][both] >= 0.5) != (pl[b][both] >= 0.5)).mean())
            if both.any() else None})
    return out


def live_main(stamps: list, pairs: list) -> None:
    """Етап 18: живий ланцюжок, повне обрізання, кілька монет."""
    OUT_LIVE.mkdir(parents=True, exist_ok=True)
    for pair in pairs:
        full = json.loads((h.OUT_LIVE / f"legs_heads_series_{pair}_all.json")
                          .read_text(encoding="utf-8"))
        for text in stamps:
            at = int(datetime.fromisoformat(text).replace(tzinfo=timezone.utc).timestamp())
            tag = text.replace(":", "")
            spot = OUT_LIVE / f"{pair}_{tag}.json"
            if spot.exists():
                continue
            work = WORK / f"live_{pair}_{tag}"
            root, chain = work / "datasets", work / "chain"
            cut_root(at, root, whole=True)
            run_chain(root, chain, work / "legleft", pair, live=True)
            live = json.loads((chain / f"legs_heads_series_{pair}_all.json")
                              .read_text(encoding="utf-8"))
            got = compare(at, full, live)
            got["pair"] = pair
            spot.write_text(json.dumps(got, ensure_ascii=False, indent=1), encoding="utf-8")
            shutil.rmtree(work)
            first = got["bands"][0]
            print(f"{pair} {text}: подій {got['events']}, остання година "
                  f"{first['said_full']} / {first['said_live']}, найбільша різниця "
                  + str(max((b["raw_max"] or 0.0) for b in got["bands"])), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--at", nargs="+", required=True, help="моменти T, UTC ISO")
    parser.add_argument("--live", action="store_true", help="етап 18: живий ланцюжок")
    parser.add_argument("--pairs", nargs="+", default=[PAIR])
    args = parser.parse_args()
    if args.live:
        live_main(args.at, args.pairs)
        return
    OUT.mkdir(parents=True, exist_ok=True)
    full = json.loads((FULL / f"legs_heads_series_{PAIR}_all.json").read_text(encoding="utf-8"))
    for text in args.at:
        at = int(datetime.fromisoformat(text).replace(tzinfo=timezone.utc).timestamp())
        tag = text.replace(":", "")
        root, chain = WORK / tag / "datasets", WORK / tag / "chain"
        cut_root(at, root)
        run_chain(root, chain, WORK / tag / "legleft")
        live = json.loads((chain / f"legs_heads_series_{PAIR}_all.json").read_text(encoding="utf-8"))
        got = compare(at, full, live)
        (OUT / f"{tag}.json").write_text(json.dumps(got, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
        for band in got["bands"]:
            print(text, band, flush=True)


if __name__ == "__main__":
    main()
