#!/bin/zsh
# Етап 22: усі прогони етапу 19 на зонах вершин 2.3 % (--side top) тим самим
# порядком: з нуля bce, pos, focal, dice; донавчання з обраної епохи SELL_bce —
# far, ladder, l2; гріда мовчання l2s1 … l2s10 з обраної епохи SELL_l2; l3 — з
# l2s з найбільшим F1 на відкладених (рівний — AP), його мовчання, драбина 2 … 37;
# видача всіх епох SELL_bce на всіх T train.
cd "$(dirname "$0")/../../.."
S="research/36-canvas600-pivots/scripts/canvas1100_buy.py --side top"
L=research/36-canvas600-pivots/logs
R=research/36-canvas600-pivots/results/canvas1100_sell
best() { python3 -c "import json; print(json.load(open('$R/$1.json'))['best_epoch'])"; }
# готовий прогін (є його json) пропускається: перерваний хід продовжується тим самим запуском
go() { local run=$1 log=$2; shift 2; [ -f $R/$run.json ] && return 0
  python3 -u ${=S} --run $run "$@" --force > $L/$log.log 2>&1; }
for loss in bce pos focal dice; do
  go SELL_$loss sell_$loss --loss $loss || exit 1
done
b=$(best SELL_bce)
go SELL_far sell_far --loss far --init SELL_bce:$b --lr 1e-4 || exit 1
go SELL_ladder sell_ladder --loss ladder --init SELL_bce:$b --lr 1e-4 || exit 1
go SELL_l2 sell_l2 --loss ladder2 --init SELL_bce:$b --lr 1e-4 --silence 1 || exit 1
e=$(best SELL_l2)
init="SELL_l2:$e"
[ "$e" = "0" ] && init="SELL_bce:$b"
for s in 1 2 3 4 5 6 7 8 9 10; do
  go SELL_l2s$s sell_l2s$s --loss ladder2 --init $init --lr 1e-4 --silence $s || exit 1
done
pick=$(python3 -c "
import json
rows=[json.load(open(f'$R/SELL_l2s{s}.json'))|{'s':s} for s in range(1,11)]
one=max(rows,key=lambda r:(r['held']['zone']['f1'],r['held']['zone']['ap']))
print(one['s'], one['best_epoch'])")
s=${pick% *}; e=${pick#* }
go SELL_l3 sell_l3 --loss ladder2 --init SELL_l2s$s:$e --lr 1e-4 --silence $s \
  --steps 2,6,10,14,18,21,25,29,33,37 || exit 1
python3 -u ${=S} --series SELL_bce > $L/sell_series.log 2>&1 || exit 1
echo done
