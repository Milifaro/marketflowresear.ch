"""Етап 26: копія потенційно найкращих мереж (етап 25) для донавчання.

Бере `results/combo_potential.json` (вихід `combo_potential.mjs`), копіює ваги
кожної потенційно найкращої мережі `models/canvas1100_<бік>/<прогін>/epoch_NN.pt`
у `models/finetune/<бік>/<прогін>_eNN.pt` і пише перелік
`results/finetune/networks.json`: бік, прогін, функція, епоха, W і θ середини
зони 90 %, гроші, площа і межі зони, ★ (додана за грошима), звідки ваги і куди.

    python3 research/36-canvas600-pivots/scripts/finetune_copy.py
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STUDY = Path("research/36-canvas600-pivots")
POTENTIAL = STUDY / "results" / "combo_potential.json"
OUT = STUDY / "results" / "finetune" / "networks.json"
MODELS = {"buy": STUDY / "models" / "canvas1100_buy", "sell": STUDY / "models" / "canvas1100_sell"}
TARGET = STUDY / "models" / "finetune"
KEEP = ("fn", "run", "epoch", "money", "cells", "middle", "w0", "w1", "t0", "t1", "w", "theta", "added")


def copy_networks(root: Path = ROOT) -> dict:
    """Копіює ваги потенційно найкращих мереж і пише перелік; повертає його."""
    got = json.loads((root / POTENTIAL).read_text(encoding="utf-8"))
    networks = []
    for side in ("buy", "sell"):
        for group in got["sides"][side]["groups"]:
            for pick in group["picks"]:
                source = MODELS[side] / pick["run"] / f"epoch_{pick['epoch']:02d}.pt"
                target = TARGET / side / f"{pick['run']}_e{pick['epoch']:02d}.pt"
                if not (root / source).exists():
                    raise FileNotFoundError(root / source)
                (root / target).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(root / source, root / target)
                networks.append({"side": side, **{k: pick[k] for k in KEEP},
                                 "source": str(source), "weights": str(target)})
    out = {"from": str(POTENTIAL), "ratio": got.get("ratio"), "share": got.get("share"), "networks": networks}
    (root / OUT).parent.mkdir(parents=True, exist_ok=True)
    (root / OUT).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


if __name__ == "__main__":
    done = copy_networks()
    sides = [one["side"] for one in done["networks"]]
    print(f"купівля {sides.count('buy')}, продаж {sides.count('sell')} → {OUT}")
