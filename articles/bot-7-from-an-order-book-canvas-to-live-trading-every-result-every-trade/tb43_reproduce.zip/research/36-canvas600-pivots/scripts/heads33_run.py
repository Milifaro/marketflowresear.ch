"""Етап 9, крок 2: голова «бік ноги» дослідження 33 до 22.09.

Дослідження: research/36-canvas600-pivots/ → Етап 9

Той самий хід, що в дослідженні 33 (`calls_data.py` → `legs_heads.py`),
на продовженому до 22.09 ряді подій і **збережених вагах** — без
перенавчання жодної мережі:

1. Видачі чотирьох мереж на подіях кожної монети — `calls_data.series_*`:
   `split` (`legtooth`, `legline` дослідження 32) на кеші ніг
   `legleft_blocks4_gauss_clock`, зібраному `legleft_data.py` з
   `data/datasets_ext/` у `data/heads33/legleft/`; `hazard100` і
   `hazard4` (дослідження 20 / 32) на `клас210х14х4ц` з
   `data/datasets_ext/<BTC_USDT_29 | <PAIR>_fill>/`; `zone` (дослідження
   31 / 32) на `клас210х10-1х7д/д` з `data/datasets_ext/`.
2. Вісь і шов — `calls_data.skeleton` і `calls_data.join`.
3. Голова — `legs_heads.walked` з `models/legs_heads/model.pt` і
   нормування `models/legs_heads/norm.npz` дослідження 33; ряд —
   `legs_heads.series_of`.

Шляхи до даних перенаправляються **в памʼяті процесу** (атрибути модулів
`DATASETS`, `DATASET`, `DATA`); підтверджені `data/datasets/` і папки
досліджень 19–33 не пишуться. Вихід — `results/heads33/`.

Перевірка: на подіях, що є і в дослідженні 33, числа голови мають
збігтися з його `legs_heads_series_<PAIR>_all.json`.

**Виняток для вкладки `/umap600`** (`--holes`, дозвіл користувача
2026-09-26): нога, що **закінчується в val** (з 14.08), рахується і з
дірою в ряді понад годину — `hole_hours` таких ніг ставиться в 0 в
`edge_profile.legs_of` (і в модулях, що імпортували його за іменем);
хвіст ряду після останнього півота, коли кінець у val, додається
відкритою ногою до останньої події (`tail_of`) — голова говорить до
кінця val.
Нога, що перетинає 14.08, заходить і своїм шматком train у статистики
на train (ранги зон, нормування ніг), тож числа трохи зсуваються і на
старих подіях — розбіжність з рядом 33 міряє `check`.
Кеш ніг будується тут же (`legleft_data.build` / `save`) у
`data/heads33/legleft_holes/`, вихід — `results/heads33_holes/`.

**Живий ряд** (`--live`, етап 18): те саме, що `--holes`, плюс мережа
зон дослідження 31 бере ноги будь-якої довжини від 1 події
(`leg_common.MIN_LEG` = `LIVE_MIN_LEG`). Інакше відкрита нога після
останнього екстремуму, поки вона коротша за 20 подій, у мережу зон не
йде, і наживо голова на ній мовчить — звідси була затримка в годину.
Кеш ніг мережі `split` (`legleft_data`) — без стелі в 3000 подій: стеля
рахується від кінця ноги, і готовий ряд знав би, де нога скінчиться.
Правило однакове для готового ряду й живого: набір подій, по яких іде
памʼять мережі зон, від майбутнього не залежить. Кеш ніг —
`data/heads33/legleft_live/`, вихід — `results/heads33_live/`.

Запуск:
    python3 research/36-canvas600-pivots/scripts/heads33_run.py
    python3 research/36-canvas600-pivots/scripts/heads33_run.py --holes
    python3 research/36-canvas600-pivots/scripts/heads33_run.py --live
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
PROJECT = RESEARCH.parents[1]
EXT = PROJECT / "data" / "datasets_ext"
LEGLEFT = RESEARCH / "data" / "heads33" / "legleft"
OUT = RESEARCH / "results" / "heads33"
R33 = PROJECT / "research" / "33-buy-sell-signal"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT", "DOGE_USDT")
LEGLEFT_HOLES = RESEARCH / "data" / "heads33" / "legleft_holes"
OUT_HOLES = RESEARCH / "results" / "heads33_holes"
VAL_FROM = 1786665600            # 2026-08-14 00:00 UTC — межа train | val
LEGLEFT_LIVE = RESEARCH / "data" / "heads33" / "legleft_live"
OUT_LIVE = RESEARCH / "results" / "heads33_live"
LIVE_MIN_LEG = 1                 # мережа зон: ноги від 1 події, відкрита — теж
TAIL_MIN = 2                     # відкрита нога — від стількох подій
LIVE_LENGTH = 10 ** 9            # кеш ніг наживо: без стелі довжини

for path in (R33 / "scripts", PROJECT / "research" / "32-loss-ladder" / "scripts",
             PROJECT / "research" / "31-leg-common-part" / "scripts",
             PROJECT / "research" / "30-inleg-events" / "scripts",
             PROJECT / "research" / "29-class7dd-legs" / "scripts",
             PROJECT / "research" / "28-leg-edge-profile" / "scripts",
             PROJECT / "research" / "20-leg-loss" / "scripts",
             PROJECT / "research" / "19-leg-end-lstm" / "scripts",
             PROJECT / "rules" / "scripts"):
    sys.path.insert(0, str(path))


def redirect() -> None:
    """Усі читання датасетів і кешу ніг — з продовжених копій."""
    import ad_legleft
    import edge_profile
    import inleg_profile
    import leg_end_data
    edge_profile.DATASETS = EXT
    inleg_profile.DATASETS = EXT
    leg_end_data.DATASET = EXT
    ad_legleft.DATA = LEGLEFT


def allow_holes() -> None:
    """Нога, що закінчується в val, рахується і з дірою в ряді."""
    import edge_profile
    import inleg_profile
    import leg_common
    import legleft_data
    original = edge_profile.legs_of

    def legs_of(data: dict):
        place, legs = original(data)
        for leg in legs:
            if leg["to"] >= VAL_FROM:
                leg["hole_hours"] = 0.0
        tail = tail_of(data, legs)
        if tail is not None:
            place = place.copy()
            place[tail["first"]:] = tail.pop("place")
            legs.append(tail)
        return place, legs

    for module in (edge_profile, inleg_profile, leg_common, legleft_data):
        if hasattr(module, "legs_of"):
            module.legs_of = legs_of


def allow_short() -> None:
    """Мережа зон бере ноги будь-якої довжини: відкрита нога на хвості
    говорить з першої події після екстремуму. Кеш ніг мережі `split` —
    без стелі довжини: стеля `legleft_data.LENGTH` лишає останні 3000
    подій **від кінця ноги**, і де почнеться нога в кеші (а з нею вікна
    памʼяті `split`), залежало б від того, де нога скінчиться."""
    import leg_common
    import legleft_data
    global TAIL_MIN
    leg_common.MIN_LEG = LIVE_MIN_LEG
    legleft_data.LENGTH = LIVE_LENGTH
    TAIL_MIN = LIVE_MIN_LEG


def tail_of(data: dict, legs: list) -> dict | None:
    """Відкрита нога: від останнього півота ряду до його кінця, коли кінець
    у val — бік протилежний останній нозі; кінець ноги — остання подія."""
    if not legs or int(data["t"][-1]) < VAL_FROM:
        return None
    first, last = legs[-1]["last"] + 1, len(data["t"]) - 1
    if last - first + 1 < TAIL_MIN:
        return None
    length = last - first + 1
    return {"leg": len(legs) + 1, "kind": "down" if legs[-1]["kind"] == "up" else "up",
            "first": first, "last": last, "events": int(length),
            "from": int(data["t"][first]), "to": int(data["t"][last]),
            "hole_hours": 0.0,
            "move": float(np.log(data["close"][last] / data["open"][first])),
            "open": True,
            "place": np.minimum(np.floor(np.arange(length) / length * 10) + 1,
                                10).astype(np.int16)}


def legleft_cache(folder: Path) -> None:
    """Кеш ніг `legleft_blocks4_gauss_clock` — як `legleft_data.py
    --blocks --history 4 --norm gauss --clock`."""
    import legleft_data
    folder.mkdir(parents=True, exist_ok=True)
    tag = legleft_data.tag_of(True, 4, "gauss", True)
    built = legleft_data.build(list(PAIRS), True, EXT, legleft_data.LENGTH, 4,
                               into=folder / f"legleft_{tag}.npy", norm="gauss",
                               clock=True)
    legleft_data.save(built, folder)
    meta = legleft_data.meta_of(built)
    print(f"кеш ніг: {meta['legs']}", flush=True)


def open_known(known: np.ndarray) -> np.ndarray:
    """Маска `known` з відкритим хвостом: після останньої відомої події —
    теж видача."""
    out = np.asarray(known, dtype=bool).copy()
    seen = np.flatnonzero(out)
    if len(seen):
        out[seen[-1] + 1:] = True
    else:
        # у val ще жодного півота (наживо на початку val): крива мережі
        # причинна на кожній події — видача відкрита вся
        out[:] = True
    return out


def series_hazard_tail(name: str, pairs: tuple) -> dict:
    """`calls_data.series_hazard` з відкритим хвостом val: крива мережі
    рахується на всіх подіях (`known` у проході — лише для втрати), тож
    на val маска `known` береться через `open_known`."""
    import calls_data
    sys.path.insert(0, str(calls_data.LADDER / "scripts"))
    import hazard_common
    import hazard_net as hazard
    import torch

    ad = __import__("ad_hazard" if name == "hazard100" else "ad_hazard4")
    ctx = ad.prepare(force=True)
    model, _ = ad.build(ctx, calls_data.SEED)
    calls_data.lift(model, calls_data.LADDER / "models" / name / "model.pt")
    model.eval()
    step = {"wmul": 1.0, "gamma": 0.0, "near": (0, 1.0), "window": 75,
            "lift": hazard_common.LIFT}
    out = {}
    for pair in pairs:
        stamps, values = [], {}
        for part in ("train", "val"):
            stream = next((one for one in ctx[part] if one["pair"].startswith(pair)), None)
            if stream is None:
                continue
            with torch.no_grad():
                walked = hazard_common.walk(model, stream, ctx["knobs"], ctx["weights"], step)
            known = open_known(stream["known"]) if part == "val" else stream["known"]
            stamps.append(np.asarray(stream["t"], dtype=np.int64))
            for place, horizon in enumerate(hazard.HORIZONS):
                curve = np.where(known, walked["curve"][:, place], np.nan)
                values.setdefault(f"p{horizon}", []).append(curve)
        if not stamps:
            continue
        out[pair] = {"t": np.concatenate(stamps),
                     "values": {key: np.concatenate(parts) for key, parts in values.items()}}
        print(f"  {pair}: подій {len(out[pair]['t'])}", flush=True)
    return out


def outputs(pairs: tuple, tail: bool = False) -> None:
    """Видачі чотирьох мереж — `calls_data` дослідження 33, вихід в `OUT`;
    `tail` — відкритий хвіст val у горизонтах hazard."""
    import calls_data
    for name in calls_data.MODELS:
        print(f"=== {name}", flush=True)
        maker = (series_hazard_tail if tail and name.startswith("hazard")
                 else calls_data.MAKERS[name])
        blocks = maker(name, pairs) if name.startswith("hazard") else maker(pairs=pairs)
        calls_data.save(name, blocks, OUT)
    calls_data.join(OUT, pairs)


def heads(pairs: tuple) -> dict:
    """Голова на збережених вагах і нормуванні дослідження 33."""
    import torch
    import calls_train as train
    import legs_heads
    got = train.gather(pairs, OUT)
    coins = got["coins"]
    norm_file = np.load(R33 / "models" / "legs_heads" / "norm.npz")
    norm = {"mid": norm_file["mid"], "wide": norm_file["wide"]}
    columns = norm_file["columns"]
    model = legs_heads.build(len(columns))
    model.load_state_dict(torch.load(R33 / "models" / "legs_heads" / "model.pt",
                                     map_location="cpu"))
    written = {}
    for pair in pairs:
        one = coins[pair]
        data = one["data"]
        piece = train.applied(one["x"], norm)[:, columns]
        side, zone = legs_heads.target_of(len(data["t"]), data["pivot_at"],
                                          data["pivot_up"])
        proba = legs_heads.walked(model, piece, one["good"])
        for part in legs_heads.PARTS:
            block = legs_heads.series_of(pair, part, data, proba, side, zone)
            block["script"] = "research/36-canvas600-pivots/scripts/heads33_run.py"
            path = OUT / f"legs_heads_series_{pair}_{part}.json"
            path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
            written[(pair, part)] = block
    return written


def check(pairs: tuple) -> dict:
    """Збіг із дослідженням 33 на спільних подіях і нове покриття val."""
    out = {}
    for pair in pairs:
        old = json.loads((R33 / "results" / f"legs_heads_series_{pair}_all.json")
                         .read_text(encoding="utf-8"))
        new = json.loads((OUT / f"legs_heads_series_{pair}_all.json")
                         .read_text(encoding="utf-8"))
        val = json.loads((OUT / f"legs_heads_series_{pair}_val.json")
                         .read_text(encoding="utf-8"))
        a = {t: p for t, p in zip(old["t"], old["p_side"]) if p is not None}
        b = {t: p for t, p in zip(new["t"], new["p_side"]) if p is not None}
        common = sorted(set(a) & set(b))
        diff = np.abs(np.array([a[t] - b[t] for t in common])) if common else np.array([])
        told = [t for t, p in zip(val["t"], val["p_side"]) if p is not None]
        out[pair] = {"old": len(a), "new": len(b), "common": len(common),
                     "max_diff": float(diff.max()) if len(diff) else None,
                     "median_diff": float(np.median(diff)) if len(diff) else None,
                     "val_events": len(val["t"]), "val_said": len(told),
                     "val_from": int(told[0]) if told else None,
                     "val_to": int(told[-1]) if told else None}
        print(pair, out[pair], flush=True)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--heads-only", action="store_true",
                        help="видачі мереж уже пораховані — тільки голова")
    parser.add_argument("--holes", action="store_true",
                        help="виняток /umap600: ноги val рахуються і з дірами")
    parser.add_argument("--live", action="store_true",
                        help="етап 18: --holes і мережа зон на ногах від 1 події")
    args = parser.parse_args()
    pairs = tuple(args.pairs)
    global OUT, LEGLEFT
    if args.holes:
        OUT, LEGLEFT = OUT_HOLES, LEGLEFT_HOLES
    if args.live:
        args.holes = True
        OUT, LEGLEFT = OUT_LIVE, LEGLEFT_LIVE
    OUT.mkdir(parents=True, exist_ok=True)
    redirect()
    if args.live:
        allow_short()
    if args.holes:
        allow_holes()
        if not args.heads_only:
            legleft_cache(LEGLEFT)
    if not args.heads_only:
        outputs(pairs, tail=args.holes)
    heads(pairs)
    report = check(pairs)
    (OUT / "check.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                    encoding="utf-8")


if __name__ == "__main__":
    main()
