"""Етап 16: трансформер на канві 1100 × 7 × 160 год → момент T у зоні півота 2.3 %.

Дослідження: research/36-canvas600-pivots/ → Етап 16

## Хід

1. **Дані** — `canvas1100_future.py --build --zones`: на кожен момент T
   канва 1100 × 7 (видачі моделей), маска живих рядків і мітка `zone`.
   Стовпця маски у вході немає: мертві рядки — нулі, і увага їх не
   бачить (маска ключів).
2. **Розбиття** — train: моменти T до `HELD_FROM` частки часу train
   кожної монети; відкладені: після неї з проміжком `GAP` (вікно 160 год
   + запас 40 год, щоб вікна не перекривались); val — лише замір.
3. **Мережа** — латки по `PATCH` рядків (110 токенів × 70 чисел →
   `DIM`), позиція навчається, токен CLS, `LAYERS` шарів енкодера,
   `HEADS` голів уваги; вихід — один логіт.
4. **Навчання** — BCE, Adam `LR`, батч `BATCH`, seed `SEED`; епоха — усі
   моменти train у випадковому порядку; вибір епохи — AUC на відкладених;
   стоп після `PATIENCE` епох без покращення, стеля `EPOCHS`.
5. **Міра** — AUC, поріг з найкращим F1 на відкладених, точність,
   повнота й F1 на val при цьому порозі; база — частота зони (F1
   відповіді «завжди так»).
6. **Контроль** (`controls`) — одне число з останніх `LAST` рядків тієї
   самої канви без навчання: найбільша P(півот) `B_tune`, найбільша з
   P(вершина) і P(дно) `RL_tune`, 1 − середня P(кластер 2); AUC на train і
   val.

Вихід: models/canvas1100_future/<прогін>/epoch_NN.pt;
results/canvas1100_future/<прогін>.json, <прогін>_val_pred.npz.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_future_net.py --run Z_base --force
    python3 research/36-canvas600-pivots/scripts/canvas1100_future_net.py --run Z_base --controls
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100_future as fut  # noqa: E402
from edges30_net import device_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

MODELS = RESEARCH / "models" / "canvas1100_future"
RESULTS = RESEARCH / "results" / "canvas1100_future"
ROWS, CHANNELS = fut.ROWS, len(fut.CHANNELS)
PATCH, DIM, LAYERS, HEADS, DROPOUT = 10, 64, 3, 4, 0.1
LR, BATCH, EPOCHS, PATIENCE, SEED = 3e-4, 64, 30, 4, 16
HELD_FROM = 0.8
GAP = fut.BACK + fut.AHEAD
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
MEMORY_NEED = 1500
NAMES = ("zone",)
LAST = 10                        # рядків канви для контролю


class Future(nn.Module):
    """Латки канви → енкодер → CLS → три логіти."""

    def __init__(self, rows: int = ROWS, channels: int = CHANNELS, patch: int = PATCH,
                 dim: int = DIM, layers: int = LAYERS, heads: int = HEADS,
                 dropout: float = DROPOUT, outputs: int = len(NAMES)):
        super().__init__()
        self.patch = patch
        self.tokens = rows // patch
        self.embed = nn.Linear(patch * channels, dim)
        self.cls = nn.Parameter(torch.zeros(1, 1, dim))
        self.place = nn.Parameter(torch.zeros(1, self.tokens + 1, dim))
        nn.init.normal_(self.place, std=0.02)
        layer = nn.TransformerEncoderLayer(dim, heads, 2 * dim, dropout, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)
        self.out = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, outputs))

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        b = x.shape[0]
        x = x[:, :self.tokens * self.patch].reshape(b, self.tokens, -1)
        dead = ~mask[:, :self.tokens * self.patch].reshape(b, self.tokens, -1).any(-1)
        h = torch.cat([self.cls.expand(b, -1, -1), self.embed(x)], 1) + self.place
        dead = torch.cat([torch.zeros(b, 1, dtype=torch.bool, device=x.device), dead], 1)
        h = self.encoder(h, src_key_padding_mask=dead)
        return self.out(h[:, 0])


def load(part: str, data: Path = fut.DATA) -> dict:
    out = {key: np.load(data / f"{part}_{key}.npy", mmap_mode="r") for key in ("x", "mask")}
    out["labels"] = np.load(data / f"{part}_zone.npy")
    with np.load(data / f"{part}_meta.npz") as store:
        out.update({key: store[key] for key in store.files})
    return out


def split(meta: dict, held_from: float = HELD_FROM, gap: int = GAP) -> tuple:
    """Train і відкладені по кожній монеті за часом, з проміжком `gap`."""
    inside, held = [], []
    for pair in np.unique(meta["pair"]):
        where = np.flatnonzero(meta["pair"] == pair)
        t = meta["t"][where]
        edge = t.min() + held_from * (t.max() - t.min())
        inside.append(where[t < edge - gap])
        held.append(where[t >= edge])
    return np.concatenate(inside), np.concatenate(held)


def batch_of(data: dict, index: np.ndarray, device) -> tuple:
    index = np.sort(index)
    x = torch.from_numpy(np.asarray(data["x"][index], dtype=np.float32)).to(device)
    mask = torch.from_numpy(np.asarray(data["mask"][index])).to(device)
    return x, mask, torch.from_numpy(data["labels"][index]).to(device), index


def predict(model, data: dict, index: np.ndarray, device, size: int = 256) -> np.ndarray:
    model.eval()
    out = np.zeros((len(index), data["labels"].shape[1]), dtype=np.float32)
    with torch.no_grad():
        for begin in range(0, len(index), size):
            part = index[begin:begin + size]
            x, mask, _, _ = batch_of(data, part, device)
            out[begin:begin + len(part)] = torch.sigmoid(model(x, mask)).cpu().numpy()
    return out


def auc_of(score: np.ndarray, truth: np.ndarray) -> float:
    """AUC через ранги (Манн — Вітні); одна мітка — nan."""
    pos, neg = truth == 1, truth == 0
    if not pos.any() or not neg.any():
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(len(score))
    ranks[order] = np.arange(1, len(score) + 1)
    # однакові значення — середній ранг
    _, inverse, counts = np.unique(score, return_inverse=True, return_counts=True)
    sums = np.bincount(inverse, weights=ranks)
    ranks = (sums / counts)[inverse]
    return float((ranks[pos].sum() - pos.sum() * (pos.sum() + 1) / 2) / (pos.sum() * neg.sum()))


def f1_at(score: np.ndarray, truth: np.ndarray, threshold: float) -> dict:
    said = score >= threshold
    tp = int((said & (truth == 1)).sum())
    precision = tp / said.sum() if said.any() else float("nan")
    recall = tp / (truth == 1).sum() if (truth == 1).any() else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if said.any() and tp else 0.0)
    return {"threshold": float(threshold), "said": int(said.sum()), "precision": precision,
            "recall": recall, "f1": f1}


def measure(prob: np.ndarray, labels: np.ndarray, thresholds: dict | None = None,
            names: tuple = NAMES) -> tuple:
    """AUC, пороги (з найкращим F1, коли не дані) і F1 кожного виходу."""
    out, chosen = {}, {}
    for k, name in enumerate(names):
        truth = labels[:, k]
        if thresholds is None:
            best = max(THRESHOLDS, key=lambda t: f1_at(prob[:, k], truth, t)["f1"])
        else:
            best = thresholds[name]
        chosen[name] = float(best)
        rate = float(truth.mean())
        out[name] = {"auc": auc_of(prob[:, k], truth), "rate": rate,
                     "base_f1": 2 * rate / (1 + rate) if rate else 0.0,
                     **f1_at(prob[:, k], truth, best)}
    return out, chosen


def controls(data: dict, last: int = LAST) -> dict:
    """AUC одного числа з останніх `last` рядків канви без навчання."""
    tail = np.asarray(data["x"][:, -last:, :], dtype=np.float32)
    truth = data["labels"][:, 0]
    scores = {"B_tune P(півот)": tail[:, :, 3].max(1),
              "RL_tune max(P(вершина), P(дно))": np.maximum(tail[:, :, 0], tail[:, :, 2]).max(1),
              "1 − P(кластер 2)": 1.0 - tail[:, :, 5].mean(1)}
    return {name: auc_of(score, truth) for name, score in scores.items()}


def train(run: str, device, log=print) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    names = NAMES
    data, val = load("train"), load("val")
    inside, held = split(data)
    log(f"train {len(inside)}, відкладені {len(held)}, val {len(val['t'])}; "
        f"частки {' / '.join(names)}: train {data['labels'][inside].mean(0).round(3).tolist()}, "
        f"val {val['labels'].mean(0).round(3).tolist()}")
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = Future(outputs=len(names)).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    loss_fn = nn.BCEWithLogitsLoss()
    history, best, wait = [], None, 0
    val_index = np.arange(len(val["t"]))
    for epoch in range(1, EPOCHS + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total = 0.0
        for begin in range(0, len(order), BATCH):
            x, mask, y, _ = batch_of(data, order[begin:begin + BATCH], device)
            optimizer.zero_grad()
            value = loss_fn(model(x, mask), y)
            value.backward()
            optimizer.step()
            total += float(value.detach()) * len(y)
        held_prob = predict(model, data, np.sort(held), device)
        held_score, thresholds = measure(held_prob, data["labels"][np.sort(held)], names=names)
        val_score, _ = measure(predict(model, val, val_index, device), val["labels"], thresholds, names)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        mean = float(np.mean([held_score[k]["auc"] for k in names]))
        one = {"epoch": epoch, "loss": total / len(order), "held_auc": mean,
               "thresholds": thresholds, "held": held_score, "val": val_score,
               "seconds": time.time() - started}
        history.append(one)
        log(f"{run} е{epoch}: втрата {one['loss']:.4f}, AUC відкладені "
            + " ".join(f"{k} {held_score[k]['auc']:.3f}" for k in names)
            + " · val " + " ".join(f"{k} {val_score[k]['auc']:.3f} F1 {val_score[k]['f1']:.3f}"
                                   f" (база {val_score[k]['base_f1']:.3f})" for k in names)
            + f", {one['seconds']:.0f} с", flush=True)
        if best is None or mean > best["auc"]:
            best, wait = {"epoch": epoch, "auc": mean}, 0
        else:
            wait += 1
            if wait >= PATIENCE:
                break
    top = next(one for one in history if one["epoch"] == best["epoch"])
    model.load_state_dict(torch.load(folder / f"epoch_{best['epoch']:02d}.pt", map_location=device))
    prob = predict(model, val, val_index, device)
    np.savez(RESULTS / f"{run}_val_pred.npz", prob=prob, labels=val["labels"],
             pair=val["pair"], t=val["t"])
    out = {"run": run, "best_epoch": best["epoch"], "thresholds": top["thresholds"],
           "held": top["held"], "val": top["val"],
           "val_pairs": {str(p): measure(prob[val["pair"] == p], val["labels"][val["pair"] == p],
                                         top["thresholds"], names)[0] for p in np.unique(val["pair"])},
           "history": [{k: one[k] for k in ("epoch", "loss", "held_auc", "seconds")}
                       | {"val_auc": {k: one["val"][k]["auc"] for k in names}}
                       for one in history],
           "config": {"patch": PATCH, "dim": DIM, "layers": LAYERS, "heads": HEADS,
                      "dropout": DROPOUT, "lr": LR, "batch": BATCH, "epochs": EPOCHS,
                      "patience": PATIENCE, "seed": SEED, "held_from": HELD_FROM, "gap": GAP,
                      "channels": list(fut.CHANNELS), "labels": list(names),
                      "last": LAST},
           "controls": {"train": controls(data), "val": controls(val)},
           "counts": {"train": int(data["labels"].sum()), "train_all": int(len(data["labels"])),
                      "val": int(val["labels"].sum()), "val_all": int(len(val["labels"]))}}
    (RESULTS / f"{run}.json").write_text(json.dumps(out, ensure_ascii=False, indent=1,
                                                    default=float), encoding="utf-8")
    log(f"{run}: найкраща епоха {best['epoch']}")
    return out


def add_controls(run: str, log=print) -> dict:
    """Контроль і лічильники зони — у готовий результат прогону."""
    path = RESULTS / f"{run}.json"
    out = json.loads(path.read_text(encoding="utf-8"))
    data, val = load("train"), load("val")
    out["controls"] = {"train": controls(data), "val": controls(val)}
    out["counts"] = {"train": int(data["labels"].sum()), "train_all": int(len(data["labels"])),
                     "val": int(val["labels"].sum()), "val_all": int(len(val["labels"]))}
    out["config"]["last"] = LAST
    path.write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    log(f"{run}: контроль {out['controls']}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--run", default="Z_base")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--controls", action="store_true",
                        help="лише дописати контроль і лічильники в готовий <прогін>.json")
    args = parser.parse_args()
    RESULTS.mkdir(parents=True, exist_ok=True)
    if args.controls:
        add_controls(args.run)
        return
    no_swap(MEMORY_NEED, args.force)
    train(args.run, device_of(args.device))


if __name__ == "__main__":
    main()
