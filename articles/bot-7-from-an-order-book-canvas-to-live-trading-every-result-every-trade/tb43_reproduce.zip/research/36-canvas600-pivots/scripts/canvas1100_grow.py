"""Етап 11: голови вершини, корекції й дна на циклі вікна від 2 до 8 півотів.

Дослідження: research/36-canvas600-pivots/ → Етап 11

## Хід

1. **Ряд** — записи 100 с етапу 6 (`data/canvas1100/<PAIR>_<part>.npz`),
   ноги зігзага 2.3 (`legs_<part>.json`), півоти й корекції 0.8 з зонами —
   ті самі, що в етапах 6–8. train — до 14.08, val — 14.08 … 22.09.
2. **Сітка пів півота** `q` — півоти 2.3 і середини між сусідніми
   півотами, по порядку. Розмір вікна — у пів півотах: вікно з якоря `qⱼ`
   розміром `k` півотів кінчається на `qⱼ₊₂ₖ₋₂` (з якоря-півота розмір 2 —
   до наступного півота, у вікні 2 півоти; з якоря-середини — 1 півот).
   Лівий край вікна — якір мінус поле: ширина в часі зони останнього
   півота не пізніше якоря, не менше години.
3. **Цикл вікна** на кожному якорі, спершу на всіх якорях-півотах, потім
   на всіх якорях-серединах (якір, зсунутий на пів півота):
   - **ріст** (`grow`) — лівий край на місці, правий щогодини
     (`STEP` = 36 записів) від розміру 2 до розміру 8 півотів; сходинка —
     найменший цілий розмір `k`, що накриває правий край;
   - **стиск** (`shrink`) — правий край на розмірі 8, лівий щогодини
     вправо, поки у вікні не лишиться 2 півоти;
   - **ковзання** (`slide`) — повернення на якір: вікно розміром 2, 2.5,
     3 … 8 півотів сунеться вправо кроком в один рядок канви (записів
     вікна / 1100, не менше запису), поки лівий край не дійде до лівого
     краю наступного якоря; сходинка — розмір у пів півотах.
   Цикл на train дає ~4.7 млн вікон (ковзання — 4.3 млн); канви будуються
   на рівній вибірці: `CAP` вікон на фазу, порівну на монету, на вид якоря
   і сходинку (seed 0).
4. **Підтвердження** — півот 2.3 у вікні є міткою, лише коли до правого
   краю ціна (`close`) відійшла від нього на 2.3 % у зворотний бік;
   корекція 0.8 — на 0.8 %. Непідтверджені — рядки зони поза втратою і
   мірою всіх голів.
5. **Три голови** на кожен рядок: `0` — вершина 2.3 (продаж), `1` —
   корекція 0.8, `2` — дно 2.3 (купівля). Код рядка для кожної голови:
   - `POS` — зона свого класу (вершина / корекція, що не півот / дно);
   - `SWAP` — голова вершини чи дна на зоні корекції, голова корекції на
     зоні півота 2.3: вага `SWAP_WEIGHT`;
   - `REPEAT` — голова вершини після підтвердженої вершини (від кінця її
     зони до наступного півота — дна), так само голова дна після дна: до
     протилежного півота нової вершини бути не може, вага `REPEAT_WEIGHT`;
   - `ALT` — інша вершина в ціні зони півота: рядок між сусідніми півотами,
     чий `high` (для дна — `low`) у ціновій смузі зони (`zone` — 10 %
     ціни попередньої ноги) і найвищий (найнижчий) у ±`PEAK` рядках. Поза
     втратою, сигнал на ньому — добрий;
   - `NEG` — решта живих рядків; `IGNORE` — мертвий рядок, зона
     непідтвердженого чи захованого за вікном півота.
   Пріоритет: `POS` > `ALT` > `SWAP` > `REPEAT` > `NEG`.
6. **Втрата** на кожну голову: BCE — середнє на рядках `POS` плюс зважене
   середнє на решті живих рядків (`NEG` 1, `SWAP` 3, `REPEAT` 6), плюс
   `1 − soft dice` по канві; середнє трьох голів.
7. **Старт** — ваги `B_tune` етапу 8: вихід вершини і вихід дна — з виходу
   півота 2.3, вихід корекції — з виходу корекції; вихід боку не
   переноситься.
8. **Навчання за циклом** — сходинки в порядку циклу (якорі-півоти: ріст
   2 … 8, стиск, ковзання 2 … 8; далі те саме на якорях-серединах) — 42
   сходинки по одній епосі з `STAGE_SAMPLE` вікон: половина — нова
   сходинка, половина — порівну з усіх пройдених. Далі весь цикл разом:
   до `LAST_EPOCHS` епох по `SAMPLE` вікон порівну з усіх сходинок, стоп
   після `PATIENCE` без покращення; найкраща епоха — з цієї частини.
   Adam lr 1e-4, батч 8 кусками по 4, seed 0.
9. **Розбиття по часу** — різ монети на півоті `⌊0.8 · півотів train⌋`:
   навчання — вікна, що кінчаються до різу, відкладені — що починаються
   після. Замір між епохами — сталі `HELD_EACH` відкладених вікон на фазу
   і вид якоря: пороги голів і епоха за середнім F1 трьох голів.
10. **Міра** на голову: сигнал — пік ≥ порогу в ±`PEAK` рядках; добрий — на
   `POS` чи `ALT`; повнота — частка підтверджених зон свого класу з
   сигналом; F1; окремо — сигнали на `SWAP` (плутанина) і `REPEAT`
   (повтор). Базовий прогноз — стільки ж сигналів на випадкових живих
   рядках. val — усі побудовані вікна val, по монетах, фазах, видах якоря
   і числу півотів у вікні.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_grow.py --build
    python3 research/36-canvas600-pivots/scripts/canvas1100_grow.py --run G_tune --init B_tune

Вихід: data/canvas1100_grow/<part>_*.npy; models/canvas1100_grow/<прогін>/
epoch_NN.pt; results/canvas1100_grow/<прогін>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_heads as heads8  # noqa: E402
import canvas1100_net as net  # noqa: E402
from canvas600_data import (corrections_of, label_rows, row_extremes,  # noqa: E402
                            with_neighbours)
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_data import pivots_of  # noqa: E402
from edges30_net import device_of, peaks, scalars_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402
from zigzag import INNER_THRESHOLD, OUTER_THRESHOLD  # noqa: E402

SOURCE = net.DATA
DATA = RESEARCH / "data" / "canvas1100_grow"
MODELS = RESEARCH / "models" / "canvas1100_grow"
RESULTS = RESEARCH / "results" / "canvas1100_grow"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT", "DOGE_USDT")
ROWS = 1100
HEADS = ("top", "corr", "bottom")
STEP = 3600 // c.BAR             # година записів
K_MIN, K_MAX = 2, 8              # розмір вікна, півотів
SIZES = tuple(range(2 * K_MIN, 2 * K_MAX + 1))   # ковзання: розмір у пів півотах
PHASES = ("grow", "shrink", "slide")
KINDS = ("pivot", "mid")         # якір — півот чи середина між півотами
CAP = {"train": 60000, "val": 12000}   # вікон на фазу
IGNORE, NEG, POS, SWAP, REPEAT, ALT = -1, 0, 1, 2, 3, 4
POS_WEIGHT, SWAP_WEIGHT, REPEAT_WEIGHT = 3.0, 3.0, 6.0
WEIGHTS = (1.0, POS_WEIGHT, SWAP_WEIGHT, REPEAT_WEIGHT, 0.0)   # за кодом 0 … 4
PEAK = 10
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
LR, BATCH, MICRO, PREDICT = 1e-4, 8, 4, 8
STAGE_SAMPLE, SAMPLE = 2000, 4000
LAST_EPOCHS, PATIENCE = 10, 3
HELD_EACH, VAL_EACH = 350, 250   # вікон на фазу × вид якоря для заміру між епохами
CHUNK = 512
HELD = 0.8
SEED = 0
MEMORY_NEED = 2400
FIELDS = ("signals", "good", "swap", "repeat", "zones", "found")


# ------------------------------------------------------------------ вікна

def grid_of(index: np.ndarray) -> tuple:
    """Сітка пів півота: півоти і середини між сусідніми; вид точки."""
    mids = (index[:-1] + index[1:]) // 2
    q = np.unique(np.concatenate([index, mids]))
    return q, np.where(np.isin(q, index), 0, 1)


def cycle(index: np.ndarray, span: np.ndarray, size: int, step: int = STEP,
          rows: int = ROWS) -> np.ndarray:
    """Усі вікна циклу: рядки `(якір, вид, фаза, сходинка, start, end, n)`.

    Сходинка росту — розмір у півотах, стиску — 0, ковзання — розмір у
    пів півотах; `n` — півотів 2.3 у вікні."""
    q, kind = grid_of(index)
    far = 2 * (K_MAX - 1)

    def start_of(j: int) -> int:
        k = max(int(np.searchsorted(index, q[j], side="right")) - 1, 0)
        return int(q[j]) - max(int(np.ceil(span[k])), step)

    pieces = []

    def put(j, phase, stage, starts, ends):
        keep = (starts >= 0) & (ends <= size - 1) & (ends > starts)
        starts, ends = starts[keep], ends[keep]
        if not len(starts):
            return
        n = (np.searchsorted(index, ends, side="right")
             - np.searchsorted(index, starts, side="left"))
        pieces.append(np.stack([np.full(len(starts), j), np.full(len(starts), kind[j]),
                                np.full(len(starts), phase), np.asarray(stage) * np.ones(len(starts), int),
                                starts, ends, n], axis=1))

    for j in range(len(q) - 2):
        start = start_of(j)
        if start < 0:
            continue
        top = min(j + far, len(q) - 1)
        ends = np.arange(q[j + 2], q[top] + 1, step)
        if not len(ends) or ends[-1] != q[top]:
            ends = np.append(ends, q[top])
        marks = q[j + 2:top + 1:2]            # кінці розмірів 2, 3, … півотів
        stage = K_MIN + np.minimum(np.searchsorted(marks, ends, side="left"),
                                   len(marks) - 1)
        put(j, 0, stage, np.full(len(ends), start), ends)
        if j + far < len(q):
            edge = int(q[j + far])
            inside = index[(index >= start) & (index <= edge)]
            if len(inside) >= 2:
                lefts = np.arange(start + step, inside[-2] + 1, step)
                put(j, 1, 0, lefts, np.full(len(lefts), edge))
        if j + 1 < len(q) - 2:
            distance = max(start_of(j + 1) - start, 1)
            for half in SIZES:
                if j + half - 2 >= len(q):
                    break
                end = int(q[j + half - 2])
                move = max(1, int(round((end - start) / rows)))
                shift = np.arange(0, distance, move)
                put(j, 2, half, start + shift, end + shift)
    if not pieces:
        return np.zeros((0, 7), dtype=np.int64)
    return np.concatenate(pieces).astype(np.int64)


def stages() -> list:
    """Сходинки навчання в порядку циклу: `(вид якоря, фаза, сходинка)`."""
    out = []
    for kind in range(len(KINDS)):
        out += [(kind, 0, k) for k in range(K_MIN, K_MAX + 1)]
        out += [(kind, 1, 0)]
        out += [(kind, 2, half) for half in SIZES]
    return out


def sample(table: np.ndarray, cap: int, rng) -> np.ndarray:
    """Рівна вибірка: на кожну фазу до `cap` вікон, порівну на вид якоря і
    сходинку. Повертає номери рядків `table`."""
    out = []
    for phase in range(len(PHASES)):
        cells = [(kind, stage) for kind, p, stage in stages() if p == phase]
        each = cap // len(cells)
        for kind, stage in cells:
            pool = np.flatnonzero((table[:, 1] == kind) & (table[:, 2] == phase)
                                  & (table[:, 3] == stage))
            if len(pool):
                out.extend(rng.choice(pool, min(each, len(pool)), replace=False).tolist())
    return np.sort(np.asarray(out, dtype=np.int64))


def confirmed(close: np.ndarray, at: int, top: bool, end: int,
              threshold: float) -> bool:
    """Півот `at` підтверджений до запису `end`: ціна відійшла на `threshold`."""
    if end <= at:
        return False
    after = close[at + 1:end + 1]
    if top:
        return bool(after.min() <= close[at] * (1 - threshold))
    return bool(after.max() >= close[at] * (1 + threshold))


def codes_of(start: int, end: int, first: np.ndarray, last: np.ndarray,
             close: np.ndarray, pivots: dict, corrections: dict,
             peak: int = PEAK) -> dict:
    """Коди рядків канви `(rows, 3)` і власники підтверджених зон `(rows, 3)`
    для голів вершини, корекції й дна."""
    marks = label_rows(start, end, first, last, close, pivots, corrections)
    rows = len(first)
    alive = first >= 0
    code = np.full((rows, 3), NEG, dtype=np.int8)
    owner = np.full((rows, 3), -1, dtype=np.int16)
    code[~alive] = IGNORE
    code[marks["label"] < 0] = IGNORE
    zones = marks["zones"]
    ok = [confirmed(close, z["index"], z["top"], end,
                    OUTER_THRESHOLD if z["role"] == "pivot" else INNER_THRESHOLD)
          for z in zones]
    corr_rows = [np.flatnonzero((marks["corr"] == k) & (marks["label"] == 1))
                 for k in range(len(zones))]
    repeat = [np.zeros(rows, bool), np.zeros(rows, bool)]   # вершина, дно
    alt = [np.zeros(rows, bool), np.zeros(rows, bool)]
    a, b, high, low, _ = row_extremes(start, first, last, close)
    for k, z in enumerate(zones):
        if z["role"] != "pivot" or not ok[k]:
            continue
        number = int(np.searchsorted(pivots["index"], z["index"]))
        h = 0 if z["top"] else 1
        done = z["rows"].max()
        nxt = pivots["right"][number]
        repeat[h][(np.arange(rows) > done) & alive & (a <= nxt)] = True
        level = high if z["top"] else low
        edge = (level >= pivots["price"][number] - pivots["zone"][number]
                if z["top"] else level <= pivots["price"][number] + pivots["zone"][number])
        near = alive & (b >= pivots["left"][number]) & (a <= nxt) & edge
        own = level if z["top"] else -level
        padded = np.pad(np.where(alive, own, -np.inf), peak, constant_values=-np.inf)
        view = np.lib.stride_tricks.sliding_window_view(padded, 2 * peak + 1)
        alt[h] |= near & (own >= view.max(axis=1))
    for h, col in ((0, 0), (1, 2)):
        take = repeat[h] & (code[:, col] == NEG)
        code[take, col] = REPEAT
    for k, z in enumerate(zones):
        if z["role"] != "corr":
            continue
        got = corr_rows[k]
        if not ok[k]:
            code[got] = IGNORE
            continue
        code[got, 1] = POS
        owner[got, 1] = k
        for col in (0, 2):
            keep = code[got, col] >= 0
            code[got[keep], col] = SWAP
    for h, col in ((0, 0), (1, 2)):
        take = alt[h] & np.isin(code[:, col], (NEG, SWAP, REPEAT))
        code[take, col] = ALT
    for k, z in enumerate(zones):
        if z["role"] != "pivot":
            continue
        got = z["rows"]
        if not ok[k]:
            code[got] = IGNORE
            continue
        col = 0 if z["top"] else 2
        code[got] = np.where(code[got] == IGNORE, IGNORE, NEG)
        code[got, col] = POS
        owner[got, col] = k
        code[got, 1] = SWAP
    return {"code": code, "owner": owner, "zones": len(zones)}


def build_part(part: str, pairs=PAIRS, source: Path = SOURCE, out: Path = DATA,
               cap: int | None = None, root: Path | None = None, log=print) -> dict:
    """Вибірка вікон циклу частини: канви (float16), коди, власники, скаляри."""
    import bars30
    from numpy.lib.format import open_memmap
    out.mkdir(parents=True, exist_ok=True)
    cap = CAP[part] if cap is None else cap
    rng = np.random.default_rng(SEED)
    legs_all = json.loads((source / f"legs_{part}.json").read_text(encoding="utf-8"))
    series, chosen, full = {}, {}, {}
    for pair in pairs:
        with np.load(source / f"{pair}_{part}.npz") as store:
            bars = {name: store[name] for name in ("t", "open", "close")}
        legs = legs_all[pair]
        pivots = with_neighbours(pivots_of(legs, bars["close"]), len(bars["t"]))
        corrections = corrections_of(legs, bars["open"], bars["close"], pivots)
        series[pair] = (bars, pivots, corrections)
        table = cycle(pivots["index"], pivots["span"], len(bars["t"]))
        full[pair] = {PHASES[p]: int((table[:, 2] == p).sum()) for p in range(len(PHASES))}
        pick = table[sample(table, cap // len(pairs), rng)]
        chosen[pair] = pick[np.lexsort((pick[:, 5], pick[:, 4]))]
    total = sum(len(one) for one in chosen.values())
    log(f"{part}: цикл {full}; побудую {total}")
    x = open_memmap(out / f"{part}_x.npy", mode="w+", dtype=np.float16,
                    shape=(total, ROWS, 7))
    code = open_memmap(out / f"{part}_code.npy", mode="w+", dtype=np.int8,
                       shape=(total, ROWS, 3))
    owner = open_memmap(out / f"{part}_owner.npy", mode="w+", dtype=np.int16,
                        shape=(total, ROWS, 3))
    mask = open_memmap(out / f"{part}_mask.npy", mode="w+", dtype=bool,
                       shape=(total, ROWS))
    meta = {name: [] for name in ("pair", "anchor", "kind", "phase", "stage", "start",
                                  "end", "n", "step", "scalars")}
    k, started, cache = 0, time.time(), {}
    for pair in pairs:
        bars, pivots, corrections = series[pair]
        t, opens, close = bars["t"], bars["open"], bars["close"]
        rows = chosen[pair]
        # секунди — шматками по початку вікна, щоб доби читались раз
        begin = 0
        while begin < len(rows):
            stop = begin
            while stop < len(rows) and t[rows[stop, 4]] - t[rows[begin, 4]] < 86400:
                stop += 1
            piece = rows[begin:stop]
            holder = bars30.read_seconds(pair, int(t[piece[:, 4].min()]),
                                         int(t[piece[:, 5].max()]) + c.BAR - 1, cache, root)
            for anchor, kind, phase, stage, start, end, n in piece:
                canvas = c.canvas_of(holder, t, int(start), int(end))
                got = codes_of(int(start), int(end), canvas["first"], canvas["last"],
                               close, pivots, corrections)
                x[k] = canvas["net"]
                code[k] = got["code"]
                owner[k] = got["owner"]
                mask[k] = canvas["mask"]
                for name, value in (("pair", pair), ("anchor", anchor), ("kind", kind),
                                    ("phase", phase), ("stage", stage), ("start", start),
                                    ("end", end), ("n", n), ("step", canvas["step"])):
                    meta[name].append(value)
                meta["scalars"].append([np.log1p(end - start + 1), np.log1p(canvas["step"]),
                                        float(np.log(close[end] / opens[start])),
                                        float(canvas["mask"].mean())])
                k += 1
            begin = stop
            log(f"{part} {pair}: вікно {k} з {total}, {time.time() - started:.0f} с")
    for array in (x, code, owner, mask):
        array.flush()
    np.savez(out / f"{part}_meta.npz",
             **{name: np.array(value, np.float32 if name in ("step", "scalars") else None)
                for name, value in meta.items()})
    cuts = ({pair: int(series[pair][1]["index"][int(np.floor(HELD * len(series[pair][1]["index"])))])
             for pair in pairs} if part == "train" else {})
    info = {"part": part, "windows": total, "cycle": full, "cap": cap, "cut": cuts,
            "seconds": time.time() - started}
    (out / f"{part}_build.json").write_text(json.dumps(info, ensure_ascii=False),
                                            encoding="utf-8")
    log(f"{part}: готово, {info['seconds']:.0f} с")
    return info


def load(part: str, data: Path = DATA) -> dict:
    out = {name: np.load(data / f"{part}_{name}.npy", mmap_mode="r")
           for name in ("x", "code", "owner", "mask")}
    with np.load(data / f"{part}_meta.npz") as store:
        out.update({key: store[key] for key in store.files})
    out["numbers"] = scalars_of(out["scalars"])
    out["build"] = json.loads((data / f"{part}_build.json").read_text(encoding="utf-8"))
    return out


def split(data: dict, cuts: dict) -> tuple:
    """Навчання — вікна до різу монети, відкладені — після."""
    cut = np.array([cuts[str(p)] for p in data["pair"]])
    return np.flatnonzero(data["end"] < cut), np.flatnonzero(data["start"] > cut)


def cell_of(data: dict, index: np.ndarray, cell: tuple) -> np.ndarray:
    kind, phase, stage = cell
    return index[(data["kind"][index] == kind) & (data["phase"][index] == phase)
                 & (data["stage"][index] == stage)]


def fixed_pick(data: dict, index: np.ndarray, each: int, seed: int = SEED) -> np.ndarray:
    """Сталий замір: до `each` вікон на фазу × вид якоря."""
    rng = np.random.default_rng(seed)
    out = []
    for kind in range(len(KINDS)):
        for phase in range(len(PHASES)):
            pool = index[(data["kind"][index] == kind) & (data["phase"][index] == phase)]
            if len(pool):
                out.extend(rng.choice(pool, min(each, len(pool)), replace=False).tolist())
    return np.sort(np.asarray(out, dtype=np.int64))


def epoch_pick(data: dict, index: np.ndarray, cells: list, size: int, rng,
               new: tuple | None = None) -> np.ndarray:
    """Вікна епохи: з `new` — половина, решта — порівну з `cells`
    (без `new` — усе порівну з `cells`)."""
    out = []
    parts = [(new, size // 2)] if new is not None else []
    rest = size - sum(n for _, n in parts)
    pools = [cell_of(data, index, one) for one in cells]
    pools = [one for one in pools if len(one)]
    for pool in pools:
        parts.append((pool, rest // len(pools)))
    for pool, n in parts:
        if isinstance(pool, tuple):
            pool = cell_of(data, index, pool)
        if len(pool) and n:
            out.extend(rng.choice(pool, n, replace=len(pool) < n).tolist())
    return rng.permutation(np.asarray(out, dtype=np.int64))


# ------------------------------------------------------------------ мережа

def loss_of(logits: torch.Tensor, code: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """`dice` на три голови з вагами за кодом рядка: `logits`, `code` —
    `(B, rows, 3)`. BCE кожної голови — середнє на рядках `POS` плюс
    зважене середнє на решті живих рядків (`NEG`, `SWAP`, `REPEAT` у
    пропорції їхніх ваг): зона свого класу не тоне в негативах."""
    live = (mask[..., None] & (code >= 0) & (code != ALT)).float()
    table = torch.tensor(WEIGHTS, device=logits.device)
    weight = table[code.clamp(min=0).long()] * live
    t = (code == POS).float()
    each = F.binary_cross_entropy_with_logits(logits, t, reduction="none")
    pos = weight * t
    neg = weight * (1 - t)
    total = ((each * pos).sum(dim=(0, 1)) / pos.sum(dim=(0, 1)).clamp(min=1)
             + (each * neg).sum(dim=(0, 1)) / neg.sum(dim=(0, 1)).clamp(min=1)).sum() / 3
    p = torch.sigmoid(logits)
    inter = (p * t * live).sum(dim=1)
    denom = (p * live).sum(dim=1) + (t * live).sum(dim=1)
    dice = (2 * inter + 1) / (denom + 1)
    return total + (1 - dice).mean()


def start_model(init: str | None, device) -> Finder3:
    """`Finder3` на 3 виходи; з `init` етапу 8: вершина і дно — з виходу
    півота 2.3, корекція — з виходу корекції."""
    model = Finder3(rows=ROWS, outputs=3)
    if init:
        summary = json.loads((heads8.RESULTS / f"{init}.json").read_text(encoding="utf-8"))
        state = torch.load(heads8.MODELS / init / f"epoch_{summary['best_epoch']:02d}.pt",
                           map_location="cpu")
        for key in ("head.weight", "head.bias"):
            old = state[key]
            state[key] = torch.stack([old[0], old[1], old[0]])
        model.load_state_dict(state)
    return model.to(device)


def batch_of(data: dict, pick: np.ndarray, device) -> tuple:
    return (torch.from_numpy(np.asarray(data["x"][pick], dtype=np.float32)).to(device),
            torch.from_numpy(data["numbers"][pick]).to(device))


def predict(model, data: dict, index: np.ndarray, device) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for begin in range(0, len(index), PREDICT):
            pick = index[begin:begin + PREDICT]
            out.append(torch.sigmoid(model(*batch_of(data, pick, device))).float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS, 3), np.float32)


def window_counts(signal: np.ndarray, code: np.ndarray, owner: np.ndarray) -> np.ndarray:
    """Лічильники `FIELDS` однієї голови на кожне вікно: `(W, 6)`."""
    out = np.zeros((len(signal), len(FIELDS)), dtype=np.int64)
    out[:, 0] = signal.sum(axis=1)
    out[:, 1] = (signal & ((code == POS) | (code == ALT))).sum(axis=1)
    out[:, 2] = (signal & (code == SWAP)).sum(axis=1)
    out[:, 3] = (signal & (code == REPEAT)).sum(axis=1)
    for w, (s, o) in enumerate(zip(signal, owner)):
        ids = set(o[o >= 0].tolist())
        out[w, 4] = len(ids)
        out[w, 5] = len(ids & set(o[s].tolist()))
    return out


def signals_of(prob: np.ndarray, mask: np.ndarray, code: np.ndarray,
               threshold: float) -> np.ndarray:
    return peaks(prob, mask, threshold, PEAK) & mask & (code != IGNORE)


def f1_of(total: np.ndarray) -> dict:
    one = dict(zip(FIELDS, (int(v) for v in total)))
    precision = one["good"] / one["signals"] if one["signals"] else float("nan")
    recall = one["found"] / one["zones"] if one["zones"] else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if one["signals"] and one["zones"] and precision + recall > 0 else 0.0)
    return {**one, "precision": precision, "recall": recall, "f1": f1}


def counts_of(prob: np.ndarray, data: dict, index: np.ndarray, thresholds: dict,
              base: bool = True) -> np.ndarray:
    """Лічильники `(W, голова, модель | база, FIELDS)`."""
    mask = np.asarray(data["mask"][index])
    code = np.asarray(data["code"][index])
    owner = np.asarray(data["owner"][index])
    out = np.zeros((len(index), len(HEADS), 2, len(FIELDS)), dtype=np.int64)
    for h, head in enumerate(HEADS):
        signal = signals_of(prob[..., h], mask, code[..., h], thresholds[head])
        out[:, h, 0] = window_counts(signal, code[..., h], owner[..., h])
        if base:
            random = net.random_signals(signal, mask & (code[..., h] != IGNORE))
            out[:, h, 1] = window_counts(random, code[..., h], owner[..., h])
    return out


def thresholds_of(prob: np.ndarray, data: dict, index: np.ndarray) -> dict:
    mask = np.asarray(data["mask"][index])
    code = np.asarray(data["code"][index])
    owner = np.asarray(data["owner"][index])
    out = {}
    for h, head in enumerate(HEADS):
        def f1(t):
            signal = signals_of(prob[..., h], mask, code[..., h], t)
            return f1_of(window_counts(signal, code[..., h], owner[..., h]).sum(axis=0))["f1"]
        out[head] = float(max(THRESHOLDS, key=f1))
    return out


def summary_of(counts: np.ndarray) -> dict:
    total = counts.sum(axis=0)
    return {head: {"model": f1_of(total[h, 0]), "base": f1_of(total[h, 1])}
            for h, head in enumerate(HEADS)}


def mean_f1(result: dict) -> float:
    return float(np.mean([result[h]["model"]["f1"] for h in HEADS]))


def by_group(counts: np.ndarray, data: dict, index: np.ndarray) -> dict:
    """Усі, кожна монета, фаза, вид якоря, число півотів у вікні."""
    out = {"all": summary_of(counts)}
    groups = [(str(p), data["pair"][index] == p) for p in np.unique(data["pair"][index])]
    groups += [(name, data["phase"][index] == p) for p, name in enumerate(PHASES)]
    groups += [(f"anchor_{name}", data["kind"][index] == k) for k, name in enumerate(KINDS)]
    groups += [(f"n{n}", data["n"][index] == n) for n in np.unique(data["n"][index])]
    for name, where in groups:
        if where.any():
            out[name] = summary_of(counts[where])
            out[name]["windows"] = int(where.sum())
    return out


def run_epoch(model, optimizer, data: dict, order: np.ndarray, device) -> float:
    model.train()
    total, seen = 0.0, 0
    for begin in range(0, len(order), BATCH):
        pick = np.sort(order[begin:begin + BATCH])
        optimizer.zero_grad()
        for piece in range(0, len(pick), MICRO):
            part = pick[piece:piece + MICRO]
            value = loss_of(model(*batch_of(data, part, device)),
                            torch.from_numpy(np.asarray(data["code"][part])).to(device),
                            torch.from_numpy(np.asarray(data["mask"][part])).to(device))
            (value * len(part) / len(pick)).backward()
            total += float(value.detach()) * len(part)
            seen += len(part)
        optimizer.step()
    return total / max(seen, 1)


def train(run: str, init: str | None, device, log=print) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    data = load("train")
    val = load("val")
    inside, held = split(data, data["build"]["cut"])
    held_fix = fixed_pick(data, held, HELD_EACH)
    val_all = np.arange(len(val["n"]))
    val_fix = fixed_pick(val, val_all, VAL_EACH)
    log(f"{run}: вікон навчання {len(inside)}, відкладені {len(held)} "
        f"(замір {len(held_fix)}), val {len(val_all)} (замір {len(val_fix)})")
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = start_model(init, device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    cells = stages()
    plan = [(cells[:s + 1], cells[s], STAGE_SAMPLE) for s in range(len(cells))]
    plan += [(cells, None, SAMPLE)] * LAST_EPOCHS
    history, best, wait = [], None, 0
    for epoch, (seen, new, size) in enumerate(plan, start=1):
        started = time.time()
        order = epoch_pick(data, inside, seen, size, rng, new)
        loss = run_epoch(model, optimizer, data, order, device)
        held_prob = predict(model, data, held_fix, device)
        thresholds = thresholds_of(held_prob, data, held_fix)
        held_score = summary_of(counts_of(held_prob, data, held_fix, thresholds))
        val_score = summary_of(counts_of(predict(model, val, val_fix, device), val,
                                         val_fix, thresholds))
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        stage = ("весь цикл" if new is None else
                 f"{KINDS[new[0]]} {PHASES[new[1]]} {new[2]}")
        one = {"epoch": epoch, "stage": stage, "train_loss": loss,
               "thresholds": thresholds, "holdout": held_score, "val": val_score,
               "seconds": time.time() - started}
        history.append(one)
        log(f"{run} е{epoch} [{stage}]: втрата {loss:.4f}, пороги {thresholds}, "
            "F1 відкладені " + " ".join(f"{h} {held_score[h]['model']['f1']:.3f}" for h in HEADS)
            + " · val " + " ".join(f"{h} {val_score[h]['model']['f1']:.3f}" for h in HEADS)
            + f", {one['seconds']:.0f} с")
        if new is not None:
            continue
        f1 = mean_f1(held_score)
        if best is None or f1 > best["f1"]:
            best, wait = {"epoch": epoch, "f1": f1}, 0
        else:
            wait += 1
            if wait >= PATIENCE:
                break
    chosen = next(one for one in history if one["epoch"] == best["epoch"])
    model.load_state_dict(torch.load(folder / f"epoch_{best['epoch']:02d}.pt",
                                     map_location=device))
    counts = np.concatenate([
        counts_of(predict(model, val, val_all[b:b + CHUNK], device), val,
                  val_all[b:b + CHUNK], chosen["thresholds"])
        for b in range(0, len(val_all), CHUNK)])
    out = {"run": run, "init": init, "best_epoch": best["epoch"],
           "thresholds": chosen["thresholds"],
           "windows": {"inside": len(inside), "held": len(held),
                       "held_measure": len(held_fix), "val": len(val_all),
                       "cycle_train": data["build"]["cycle"],
                       "cycle_val": val["build"]["cycle"]},
           "holdout": chosen["holdout"],
           "val": by_group(counts, val, val_all),
           "history": [{"epoch": one["epoch"], "stage": one["stage"],
                        "train_loss": one["train_loss"], "thresholds": one["thresholds"],
                        "held_f1": {h: one["holdout"][h]["model"]["f1"] for h in HEADS},
                        "val_f1": {h: one["val"][h]["model"]["f1"] for h in HEADS},
                        "seconds": one["seconds"]} for one in history],
           "config": {"step": STEP, "k": [K_MIN, K_MAX], "cap": CAP, "weights": WEIGHTS,
                      "lr": LR, "batch": BATCH, "micro": MICRO,
                      "stage_sample": STAGE_SAMPLE, "sample": SAMPLE,
                      "last_epochs": LAST_EPOCHS, "patience": PATIENCE,
                      "held_each": HELD_EACH, "val_each": VAL_EACH, "peak": PEAK,
                      "held": HELD, "seed": SEED}}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / f"{run}.json").write_text(json.dumps(clean(out), ensure_ascii=False, indent=1),
                                         encoding="utf-8")
    log(f"{run}: найкраща епоха {best['epoch']}, val " + " ".join(
        f"{h} F1 {out['val']['all'][h]['model']['f1']:.3f}" for h in HEADS))
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--run")
    parser.add_argument("--init", default=None)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.build:
        for part in ("train", "val"):
            build_part(part)
    if args.run:
        no_swap(MEMORY_NEED, args.force)
        train(args.run, args.init, device_of(args.device))


if __name__ == "__main__":
    main()


# ------------------------------------------------------------------ дашборд

RANDOM_RESULTS = RESEARCH / "results" / "canvas1100_random"
RANDOM_MODELS = RESEARCH / "models" / "canvas1100_random"


def buttons(results: Path = RESULTS, models: Path = MODELS,
            random_results: Path = RANDOM_RESULTS,
            random_models: Path = RANDOM_MODELS) -> list:
    """Моделі для кнопок: прогін етапу 11 — найкраща епоха і по одній зліва
    й справа; прогін етапу 12 — три найкращі епохи. Поріг — своєї епохи."""
    out = []
    for stage, folder, weights in ((11, results, models), (12, random_results, random_models)):
        if not folder.exists():
            continue
        # прогони — у порядку появи: перший прогін етапу — кнопка за замовчуванням
        for path in sorted(folder.glob("*.json"), key=lambda one: one.stat().st_mtime):
            summary = json.loads(path.read_text(encoding="utf-8"))
            if "history" not in summary:
                continue  # не прогін: заміри поверх прогону (етап 15)
            history = {one["epoch"]: one for one in summary["history"]}
            best = summary["best_epoch"]
            epochs = ([best - 1, best, best + 1] if stage == 11 else summary["best"])
            for epoch in epochs:
                file = weights / summary["run"] / f"epoch_{epoch:02d}.pt"
                if epoch in history and file.exists():
                    out.append({"run": summary["run"], "stage": stage, "epoch": int(epoch),
                                "best": epoch == best,
                                "thresholds": history[epoch]["thresholds"],
                                "file": file})
    return out


def models_on(x: np.ndarray, scalars: np.ndarray, mask: np.ndarray, code: np.ndarray,
              **folders) -> list:
    """Кожна модель `buttons` на одній канві: три голови, сигнали, добрі
    (`POS` чи `ALT` своєї голови)."""
    device = torch.device("cpu")
    one = {"x": x[None], "numbers": scalars_of(scalars)}
    out = []
    for button in buttons(**folders):
        model = Finder3(rows=ROWS, outputs=3)
        model.load_state_dict(torch.load(button["file"], map_location=device))
        prob = predict(model, one, np.array([0]), device)[0]
        got = {key: value for key, value in button.items() if key != "file"}
        for h, head in enumerate(HEADS):
            signal = signals_of(prob[None, :, h], mask[None], code[None, :, h],
                                button["thresholds"][head])[0]
            got[f"{head}_prob"] = prob[:, h]
            got[f"{head}_signal"] = np.flatnonzero(signal)
            got[f"{head}_good"] = np.isin(code[signal, h], (POS, ALT))
        out.append(got)
    return out
