"""Етап 16: канва 1100 × 7 × 160 год з видач моделей і мітка «момент T у зоні півота 2.3 %».

Дослідження: research/36-canvas600-pivots/ → Етап 16

## Хід

1. **Моменти T** — щогодини на записах 100 с кожної монети (train і
   val окремо): вікно `[T − 160 год, T]`; потрібні повні 160 год до T і
   40 год після T — запас, за який зона півота біля T стає відомою.
2. **Канва 1100 × 7** — на вікні будується канва 1100 тим самим ходом,
   що на «канві руками» (`canvas1100.canvas_of`), і на ній — видачі:
   1–3 — P(вершина 2.3), P(корекція 0.8), P(дно 2.3) моделі `RL_tune` е19
   (етап 14); 4–5 — P(півот 2.3), P(корекція 0.8) моделі `B_tune`
   (етап 8); 6 — P(кластер 2) = 1 − p правила кластера 1 на канві 600
   того самого вікна (записи 30 с, `canvas600_c1.rule_rows` / `cover`),
   рядок канви 1100 бере рядок канви 600, що закінчився не пізніше його
   кінця; 7 — голова «бік ноги» з емою 200 по подіях, рядок бере останню
   подію з видачею не пізніше свого кінця мінус година (`side_rows`);
   ряд голови — `results/heads33_holes/` (train і val), без заглядання
   вперед за заміром `side_leak.py`.
3. **Мітка** (`--zones`, `zone_of`) — запис T у зоні півота зігзага
   2.3 % (записи 100 с, півоти й зони `canvas1100_random.series_of`).
4. Шматки по `CHUNK` моментів читають секунди раз.

Вихід: data/canvas1100_future/<part>_{x,mask,ends,zone}.npy (x — 1100 × 7),
<part>_meta.npz.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_future.py --build --zones
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_grow as grow  # noqa: E402
import canvas1100_random as rnd  # noqa: E402
from canvas600_net import Finder3  # noqa: E402
from edges30_net import scalars_of  # noqa: E402

DATA = RESEARCH / "data" / "canvas1100_future"
PAIRS = grow.PAIRS
ROWS = c.ROWS
BACK = 160 * 3600                # вікно канви
AHEAD = 40 * 3600                # запас після T: зона півота біля T уже відома
STEP = 3600                      # крок T
CHUNK = 48                       # моментів T на одне читання секунд
GROW_RUN, GROW_EPOCH = "RL_tune", 19
HEADS_RUN = "B_tune"
CHANNELS = ("top", "corr", "bottom", "pivot8", "corr8", "cluster2", "side")


def moments(t: np.ndarray, back: int = BACK, ahead: int = AHEAD, step: int = STEP) -> np.ndarray:
    """Індекси записів T: запис, що закінчує годину, з повними `back` до
    і `ahead` після."""
    first = int(np.ceil((t[0] + back) / step) * step)
    stamps = np.arange(first, int(t[-1]) - ahead + 1, step)
    index = np.searchsorted(t, stamps, side="right") - 1
    return np.unique(index[index >= 0])


def zone_of(close: np.ndarray, pivots: dict, at: int) -> float:
    """1 — запис `at` у зоні півота 2.3: до півота не далі за `span`
    записів (5 % тривалості ноги) і ціна не далі за `zone` (10 % ціни
    ноги) за його бік — та сама зона, що в `canvas600_data.zone_rows`."""
    near = np.flatnonzero(np.abs(pivots["index"] - at) <= np.maximum(pivots["span"], 0.5))
    for k in near:
        gap = (pivots["price"][k] - close[at] if pivots["top"][k]
               else close[at] - pivots["price"][k])
        if max(gap, 0.0) <= max(pivots["zone"][k], 1e-12):
            return 1.0
    return 0.0


def build_zones(part: str, out: Path = DATA, log=print) -> None:
    """Мітка «момент T у зоні півота 2.3» для готових канв частини."""
    with np.load(out / f"{part}_meta.npz") as store:
        pairs, ends = store["pair"], store["end"]
    zone = np.zeros(len(ends), dtype=np.float32)
    for pair in np.unique(pairs):
        one = rnd.series_of(pair, part)
        where = np.flatnonzero(pairs == pair)
        zone[where] = [zone_of(one["close"], one["pivots"], int(e)) for e in ends[where]]
    np.save(out / f"{part}_zone.npy", zone[:, None])
    log(f"{part}: у зоні півота {int(zone.sum())} з {len(zone)} ({zone.mean():.3f})")


def rows_from(ends: np.ndarray, live: np.ndarray, other_end: np.ndarray,
              other_live: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Значення іншої канви на рядках цієї: рядок бере живий рядок іншої
    канви, що закінчився не пізніше його кінця (останній такий)."""
    order = np.flatnonzero(other_live)
    out = np.zeros(len(ends), dtype=np.float32)
    if not len(order):
        return out
    place = np.searchsorted(other_end[order], ends, side="right") - 1
    ok = live & (place >= 0)
    out[ok] = values[order[place[ok]]]
    return out


SIDE_LAG = 3600                  # голова «бік ноги» — із затримкою на годину


def side_rows(ends: np.ndarray, live: np.ndarray, t: np.ndarray, values: np.ndarray,
              lag: int = SIDE_LAG) -> np.ndarray:
    """Голова «бік ноги» на рядках: остання подія з видачею не пізніше
    `кінець рядка − lag`; до першої — 0.5. Затримка — з заміру
    `side_leak.py`: значення живого ряду й готового збігаються на всіх
    подіях до T, але в останню годину перед T наживо видач менше (канал
    `zone` відкидає короткий хвостовий блок подій)."""
    good = np.isfinite(values)
    t, values = t[good], values[good]
    out = np.full(len(ends), 0.5, dtype=np.float32)
    place = np.searchsorted(t, ends - lag, side="right") - 1
    ok = live & (place >= 0)
    out[ok] = values[place[ok]]
    return out


SIDE = RESEARCH / "results" / "heads33_holes"
SIDE_EMA = 200


def ema_events(values: np.ndarray, span: int = SIDE_EMA) -> np.ndarray:
    """Ема по подіях з видачею (як на дашборді): пропуск не рухає ему і
    сам лишається пропуском."""
    alpha = 2.0 / (span + 1.0)
    out = np.full(len(values), np.nan, dtype=np.float64)
    run = None
    for i, v in enumerate(values):
        if not np.isfinite(v):
            continue
        run = v if run is None else alpha * v + (1 - alpha) * run
        out[i] = run
    return out


def side_series(pair: str, folder: Path = SIDE) -> tuple:
    """Голова «бік ноги» всього ряду монети (train і val) з емою 200."""
    got = json.loads((folder / f"legs_heads_series_{pair}_all.json").read_text(encoding="utf-8"))
    values = np.array([np.nan if v is None else v for v in got["p_side"]], dtype=np.float64)
    return np.asarray(got["t"], dtype=np.int64), ema_events(values)


def models() -> dict:
    """RL_tune е19, B_tune і правило кластера 1."""
    import canvas1100_heads as heads
    grow_model = Finder3(rows=ROWS, outputs=3)
    grow_model.load_state_dict(torch.load(
        rnd.MODELS / GROW_RUN / f"epoch_{GROW_EPOCH:02d}.pt", map_location="cpu"))
    summary = json.loads((heads.RESULTS / f"{HEADS_RUN}.json").read_text(encoding="utf-8"))
    heads_model = Finder3(rows=ROWS, outputs=heads.OUTPUTS)
    heads_model.load_state_dict(torch.load(
        heads.MODELS / HEADS_RUN / f"epoch_{summary['best_epoch']:02d}.pt", map_location="cpu"))
    import canvas600_c1 as c1
    assigner = json.loads((c1.MODELS / "assigner.json").read_text(encoding="utf-8"))
    return {"grow": grow_model.eval(), "heads": heads_model.eval(), "assigner": assigner}


def window_of(holder, rec: dict, bars: dict, s: int, e: int, got: dict) -> tuple:
    """Шість каналів однієї канви, маска і кінці рядків."""
    import canvas600_c1 as c1
    import canvas600_data as d
    canvas = c.canvas_of(holder, rec["t"], s, e)
    live = canvas["first"] >= 0
    ends = np.where(live, rec["t"][s + np.maximum(canvas["last"], 0)] + c.BAR, 0)
    scalars = np.array([[np.log1p(e - s + 1), np.log1p(canvas["step"]),
                         float(np.log(rec["close"][e] / rec["open"][s])),
                         float(canvas["mask"].mean())]], dtype=np.float32)
    x = torch.from_numpy(canvas["net"][None].astype(np.float32))
    numbers = torch.from_numpy(scalars_of(scalars))
    with torch.no_grad():
        p_grow = torch.sigmoid(got["grow"](x, numbers))[0].numpy()
        p_heads = torch.sigmoid(got["heads"](x, numbers))[0].numpy()
    # канва 600 того самого вікна на записах 30 с
    first, last = int(rec["t"][s]), int(rec["t"][e]) + c.BAR - 1
    a = int(np.searchsorted(bars["t"], first, side="left"))
    b = int(np.searchsorted(bars["t"], last - 29, side="right")) - 1
    six = d.canvas_of(holder, bars["t"], bars["open"], bars["close"], a, b)
    window, _, _ = c1.rule_rows(six["net"], six["mask"], got["assigner"])
    prob2, _ = c1.cover(np.where(six["mask"], 1.0 - window, 0.0), six["mask"])
    live6 = six["first"] >= 0
    end6 = np.where(live6, bars["t"][a + np.maximum(six["last"], 0)] + 30, 0)
    cluster2 = rows_from(ends, live, end6, live6, prob2)
    x6 = np.stack([p_grow[:, 0], p_grow[:, 1], p_grow[:, 2],
                   p_heads[:, 0], p_heads[:, 1], cluster2], axis=1)
    x6[~live] = 0.0
    return x6.astype(np.float16), live, ends


def build(part: str, out: Path = DATA, log=print) -> None:
    import bars30
    from numpy.lib.format import open_memmap
    got = models()
    out.mkdir(parents=True, exist_ok=True)
    plan = []
    series = {}
    for pair in PAIRS:
        with np.load(grow.SOURCE / f"{pair}_{part}.npz") as store:
            rec = {k: store[k] for k in ("t", "open", "close")}
        with np.load(bars30.DATA / f"{pair}_{part}.npz") as store:
            bars = {k: store[k] for k in ("t", "open", "close")}
        series[pair] = (rec, bars)
        plan += [(pair, int(e)) for e in moments(rec["t"])]
    size = len(plan)
    x7 = open_memmap(out / f"{part}_x.npy", "w+", np.float16, (size, ROWS, len(CHANNELS)))
    mask = open_memmap(out / f"{part}_mask.npy", "w+", bool, (size, ROWS))
    ends = open_memmap(out / f"{part}_ends.npy", "w+", np.int64, (size, ROWS))
    starts = np.zeros(size, dtype=np.int64)
    log(f"{part}: {size} моментів T")
    started = time.time()
    row = 0
    for pair in PAIRS:
        rec, bars = series[pair]
        side_t, side_v = side_series(pair)
        mine = [e for p, e in plan if p == pair]
        for begin in range(0, len(mine), CHUNK):
            piece = mine[begin:begin + CHUNK]
            index = [int(np.searchsorted(rec["t"], rec["t"][e] - BACK, side="left"))
                     for e in piece]
            holder = bars30.read_seconds(pair, int(rec["t"][min(index)]),
                                         int(rec["t"][piece[-1]]) + c.BAR - 1, {})
            for e, s0 in zip(piece, index):
                x6, live, end = window_of(holder, rec, bars, s0, e, got)
                x7[row, :, :6] = x6
                x7[row, :, 6] = np.where(live, side_rows(end, live, side_t, side_v), 0.0)
                mask[row], ends[row] = live, end
                starts[row] = s0
                row += 1
            del holder
            log(f"{part}: {row}/{size}, {time.time() - started:.0f} с", flush=True)
    x7.flush(); mask.flush(); ends.flush()
    np.savez(out / f"{part}_meta.npz", pair=np.array([p for p, _ in plan]),
             end=np.array([e for _, e in plan]), start=starts,
             t=np.array([series[p][0]["t"][e] for p, e in plan]))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--zones", action="store_true",
                        help="мітка «момент T у зоні півота 2.3»")
    parser.add_argument("--parts", nargs="+", default=["val", "train"])
    args = parser.parse_args()
    for part in args.parts:
        if args.build:
            build(part)
        if args.zones:
            build_zones(part)


if __name__ == "__main__":
    main()
