"""Канва 200: канва 600 нарізана на 200 блоків по 3 рядки підряд.

Дослідження: research/36-canvas600-pivots/ → розділ «Канва 200»

## Хід

1. **Блоки.** Базова канва 600 × 7 (нормована, `data/canvas600/<part>_x.npy`)
   ріжеться на 200 блоків без перекриття: блок `b` — рядки `3b … 3b + 2`.
   Блок з мертвим рядком (`mask = 0`) не береться.
2. **Два вигляди блоку.**
   - `sum7` — сума модулів трьох рядків по кожній фічі:
     `S[f] = |x[3b, f]| + |x[3b + 1, f]| + |x[3b + 2, f]|`, 7 чисел;
   - `cat21` — модулі трьох рядків підряд, 7 | 7 | 7 = 21 число, як
     вектор уточненого сигналу, але на сталій сітці блоків, а не на піку.
3. **Клас блоку** — з уточнених міток рядків (`<part>_refined.npy`):
   `pivot` — у блоці є рядок уточненого сигналу півота 2.3 (мітка 2);
   `corr` — рядок уточненого сигналу корекції 0.8 (мітка 1), півота
   немає; `zone` — рядок зони без сигналу (мітка −1), сигналу немає;
   `body` — решта рядків ноги (рядки 50 … 549); `out` — решта рядків
   поза ногою (0 … 49, 550 … 599).
4. **Вибірка** на карту — до `CAP` блоків кожного класу, seed 36; той
   самий набір блоків для `sum7` і `cat21`.
5. **UMAP** — 2 компоненти, метрики cosine, euclidean, manhattan,
   `n_neighbors 15`, `min_dist 0.1`, seed 36 — train і val окремо.
6. **Перевірка «чи те саме, що поточний UMAP»** (`check`) — на точках
   поточної карти уточнених сигналів (`canvas600_umap.json`): для точки з
   піком у рядку `p` береться блок сітки, що містить `p` (`b = p // 3`),
   і його `cat21` `T` порівнюється з вектором точки `V` (вікно `p ± 1`):
   частка точок, де `T = V` (пік — середній рядок блоку); косинус `V` і
   `T`; збіг правила кластера 1 (`models/canvas600_c1/assigner.json`) на
   `V` і на `T` і кожного з k-means карти `cosine`; і куди `T` лягла б на
   поточній карті — більшість кластерів k-means серед 15 найближчих за
   cosine точок `V` проти кластера самої точки.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas200.py

Вихід: results/canvas200_umap.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import canvas600_signal as sig  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "canvas600"
RESULTS = ROOT / "results"
ASSIGNER = ROOT / "models" / "canvas600_c1" / "assigner.json"
SEED = 36
BLOCK = 3
BLOCKS = 200
LEG = (50, 550)                 # рядки ноги в канві 600
CLASSES = ("pivot", "corr", "zone", "body", "out")
CAP = {"pivot": 1000, "corr": 1200, "zone": 600, "body": 1200, "out": 600}
REPRS = ("sum7", "cat21")
METRICS = ("cosine", "euclidean", "manhattan")
UMAP_PARAMS = {"n_neighbors": 15, "min_dist": 0.1, "random_state": SEED}
NEIGHBOURS = 15


def blocks_of(x: np.ndarray) -> np.ndarray:
    """Канва `(600, 7)` → модулі блоків `(200, 3, 7)`."""
    return np.abs(np.asarray(x, dtype=np.float64)).reshape(BLOCKS, BLOCK, -1)


def sum7(blocks: np.ndarray) -> np.ndarray:
    """Сума модулів трьох рядків блоку по кожній фічі: `(…, 3, 7)` → `(…, 7)`."""
    return blocks.sum(axis=-2)


def cat21(blocks: np.ndarray) -> np.ndarray:
    """Модулі трьох рядків блоку підряд: `(…, 3, 7)` → `(…, 21)`."""
    return blocks.reshape(*blocks.shape[:-2], -1)


def block_class(refined: np.ndarray) -> np.ndarray:
    """Клас кожного з 200 блоків за уточненими мітками рядків канви."""
    rows = np.asarray(refined).reshape(BLOCKS, BLOCK)
    first = np.arange(BLOCKS) * BLOCK
    inside = (first >= LEG[0]) & (first + BLOCK - 1 < LEG[1])
    out = np.where(inside, "body", "out").astype("<U5")
    out[(rows == -1).any(axis=1)] = "zone"
    out[(rows == 1).any(axis=1)] = "corr"
    out[(rows == 2).any(axis=1)] = "pivot"
    return out


def collect(part: str, data: Path = DATA) -> dict:
    """Усі живі блоки базових канв частини: вигляди, клас, вікно, нога."""
    x = np.load(data / f"{part}_x.npy", mmap_mode="r")
    refined = np.load(data / f"{part}_refined.npy", mmap_mode="r")
    with np.load(data / f"{part}.npz") as store:
        kind, mask = store["kind"], store["mask"]
        leg, up = store["leg"], store["up"]
    out = {"sum7": [], "cat21": [], "cls": [], "window": [], "block": [],
           "leg": [], "top": []}
    for window in np.flatnonzero(kind == "base"):
        live = np.asarray(mask[window]).reshape(BLOCKS, BLOCK).all(axis=1)
        blocks = blocks_of(x[window])[live]
        out["sum7"].append(sum7(blocks))
        out["cat21"].append(cat21(blocks))
        out["cls"].append(block_class(refined[window])[live])
        out["window"].append(np.full(live.sum(), window))
        out["block"].append(np.flatnonzero(live))
        out["leg"].append(np.full(live.sum(), int(leg[window])))
        out["top"].append(np.full(live.sum(), bool(up[window])))
    return {name: np.concatenate(value) for name, value in out.items()}


def sample(cls: np.ndarray, cap: dict = CAP, seed: int = SEED) -> np.ndarray:
    """До `cap[клас]` блоків кожного класу, по порядку в масиві."""
    rng = np.random.default_rng(seed)
    chosen = []
    for name in CLASSES:
        where = np.flatnonzero(cls == name)
        if len(where) > cap[name]:
            where = np.sort(rng.choice(where, cap[name], replace=False))
        chosen.append(where)
    return np.concatenate(chosen)


def umap_maps(vectors: np.ndarray) -> dict:
    import umap
    maps = {}
    for metric in METRICS:
        reducer = umap.UMAP(n_components=2, metric=metric, **UMAP_PARAMS)
        maps[metric] = np.round(reducer.fit_transform(vectors), 4).tolist()
    return maps


def rule_p(vectors: np.ndarray, assigner: dict) -> np.ndarray:
    """Правило кластера 1: імовірність на векторах із 21 числа."""
    z = vectors @ np.asarray(assigner["coef"]) + assigner["intercept"]
    return 1.0 / (1.0 + np.exp(-z))


def unit(v: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(v, axis=1, keepdims=True)
    return v / np.where(norm > 0, norm, 1.0)


def check(x: np.ndarray, points: dict, labels: np.ndarray,
          assigner: dict, k: int = NEIGHBOURS) -> dict:
    """Точки поточної карти: вікно на піку `V` проти блоку сітки `T`."""
    window = np.asarray(points["window"])
    row = np.asarray(points["row"])
    V = np.stack([np.abs(sig.window_at(np.asarray(x[w], dtype=np.float64),
                                       r, 1)).ravel()
                  for w, r in zip(window, row)])
    T = np.stack([cat21(blocks_of(x[w])[r // BLOCK])
                  for w, r in zip(window, row)])
    cluster1 = np.asarray(labels) == 0
    same = np.all(np.isclose(V, T), axis=1)
    cos = (unit(V) * unit(T)).sum(axis=1)
    rule_v = rule_p(V, assigner) > 0.5
    rule_t = rule_p(T, assigner) > 0.5
    base = unit(V)

    def vote(query: np.ndarray, skip_self: bool) -> np.ndarray:
        sim = unit(query) @ base.T
        if skip_self:
            np.fill_diagonal(sim, -np.inf)
        near = np.argpartition(-sim, k, axis=1)[:, :k]
        return cluster1[near].mean(axis=1) > 0.5

    parts = np.asarray(points["part"])
    by_part = {}
    for name in ("start", "end", "corr", "body"):
        mine = parts == name
        if mine.any():
            by_part[name] = {"points": int(mine.sum()),
                             "same": float(same[mine].mean()),
                             "cos_median": float(np.median(cos[mine])),
                             "rule_agree": float((rule_v == rule_t)[mine].mean())}
    return {"points": int(len(V)),
            "same": float(same.mean()),
            "cos_median": float(np.median(cos)),
            "cos_p10": float(np.percentile(cos, 10)),
            "rule_agree": float((rule_v == rule_t).mean()),
            "rule_v_kmeans": float((rule_v == cluster1).mean()),
            "rule_t_kmeans": float((rule_t == cluster1).mean()),
            "knn_v_kmeans": float((vote(V, True) == cluster1).mean()),
            "knn_t_kmeans": float((vote(T, False) == cluster1).mean()),
            "by_part": by_part}


def run(part: str, data: Path = DATA) -> dict:
    got = collect(part, data)
    finite = np.isfinite(got["cat21"]).all(axis=1)
    got = {name: value[finite] for name, value in got.items()}
    chosen = sample(got["cls"])
    counts = {name: {"all": int((got["cls"] == name).sum()),
                     "shown": int((got["cls"][chosen] == name).sum())}
              for name in CLASSES}
    return {"cls": got["cls"][chosen].tolist(),
            "window": got["window"][chosen].tolist(),
            "block": got["block"][chosen].tolist(),
            "leg": got["leg"][chosen].tolist(),
            "top": got["top"][chosen].tolist(),
            "counts": counts, "dropped_nan": int((~finite).sum()),
            "maps": {name: umap_maps(got[name][chosen].astype(np.float32))
                     for name in REPRS}}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()
    current = json.loads((args.results / "canvas600_umap.json")
                         .read_text(encoding="utf-8"))
    assigner = json.loads(ASSIGNER.read_text(encoding="utf-8"))
    out = {"params": UMAP_PARAMS, "metrics": list(METRICS),
           "reprs": list(REPRS), "classes": list(CLASSES), "cap": CAP}
    for part in ("train", "val"):
        out[part] = run(part, args.data)
        x = np.load(args.data / f"{part}_x.npy", mmap_mode="r")
        out[part]["check"] = check(x, current[part],
                                   current["kmeans"][part]["cosine"]["labels"],
                                   assigner)
        print(part, json.dumps(out[part]["counts"], ensure_ascii=False))
        print(part, json.dumps({k: v for k, v in out[part]["check"].items()},
                               ensure_ascii=False))
    (args.results / "canvas200_umap.json").write_text(
        json.dumps(out, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
