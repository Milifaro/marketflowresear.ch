"""Етап 19: півот на купівлю — момент T у зоні дна 2.3 % на канві 1100 × 8, лише train BTC.

Дослідження: research/36-canvas600-pivots/ → Етап 19

## Хід

1. **Дані** — тільки BTC_USDT, тільки train (до 14.08.2026): записи 100 с
   (`canvas1100_grow.SOURCE`), записи 30 с (`bars30`), ноги й півоти
   train (`canvas1100_random.series_of`). Val і інші монети не беруться.
2. **Моменти T** — кінець запису на сітці 10 хв з повними 160 год до T і
   40 год після T (запас, за який зона біля T стає відомою).
3. **Розбиття за часом** — межа на `HELD_FROM` = 80 % часу між першим і
   останнім T: навчання — T до межі мінус `GAP` = 200 год (вікно 160 год
   + запас 40 год), відкладені — T від межі. Моменти проміжку не
   беруться.
4. **Кластер 2 тільки на навчальній частині** (`--cluster`): канви 600
   етапу 1 лише BTC, що закінчуються не пізніше останнього навчального
   T; на них увесь хід етапу 1 заново — грід уточнювача (1920 варіантів,
   `canvas600_signal.grid` / `pick`), UMAP уточнених сигналів (cosine),
   k-means на 2 кластери (кластер 1 — де більша частка початків і кінців
   ноги), правило кластера 1 — логістична регресія на 21 числі `|x|`
   вікна `пік ± 1` (C = 1, seed 36). P(кластер 2) = 1 − p правила ковзним
   вікном з 3 рядків канви 600 (`canvas600_c1.rule_rows` / `cover`).
5. **Канва 1100 × 8** (`--build`) — вікно 160 год, що закінчується в T
   (`canvas1100.canvas_of`): 7 фіч `клас210х10-1х7д/д` (нормування лише
   на канву) і P(кластер 2) з канви 600 того самого вікна; рядок бере
   рядок канви 600, що закінчився не пізніше його кінця. Мертві рядки —
   нулі, стовпця маски немає.
6. **Мітка** — запис T у зоні **дна** 2.3 %: до дна не далі за `span`
   записів (5 % тривалості ноги) і ціна не вище за дно більше ніж на
   `zone` (10 % ціни ноги) — `canvas1100_future.zone_of` лише на днях
   ніг ≥ 7 год (`long_bottoms`: дно лишається, коли хоч одна з двох його
   ніг не коротша за 7 год); дна коротших ніг у мітку не йдуть.
7. **Мережа** — трансформер `Future` етапу 16 на 8 каналів з нуля:
   латки по 10 рядків, 64, 3 шари, 4 голови, dropout 0.1, один логіт.
8. **Навчання** — Adam 3e-4, батч 64, seed 19; епоха — усі навчальні T у
   випадковому порядку; функція втрат — одна з `LOSSES` (`--loss`: BCE,
   BCE з вагою позитиву, focal, BCE + soft dice); вибір епохи — F1 при
   найкращому порозі на відкладених (рівний F1 — більший AP), терпіння 6,
   не раніше 12-ї епохи, стеля 30; поріг — найкращий F1 на відкладених. Видача кожної епохи на val
   BTC (`--val` — канви val тим самим ходом) пишеться для вкладки й
   заміру обраної епохи; у вибір val не йде.
9. **Міра** — на відкладених: AUC, точність, повнота, F1 при порозі; база —
   частота зони і F1 відповіді «завжди так»; число днів 2.3 у відкладених
   (незалежні одиниці).

**Бік півота** (`--side`, етап 22): `top` — те саме на зонах **вершин**
2.3 % (півот на продаж): відбір `top == True` і ціна не нижче вершини
більше ніж на `zone`; канви, кластер 2, розбиття, мережа й навчання ті
самі (`--share` бере канви й правило кластера з `canvas1100_buy`), теки —
`canvas1100_sell`, прогони `SELL_*`.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --cluster
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --build
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --labels
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --run BUY_bce
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --series BUY_bce
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --side top --share
    python3 research/36-canvas600-pivots/scripts/canvas1100_buy.py --side top --run SELL_bce

Вихід: models/canvas1100_buy/assigner.json;
data/canvas1100_buy/{x,mask}.npy, meta.npz;
models/canvas1100_buy/<прогін>/epoch_NN.pt;
results/canvas1100_buy/<прогін>.json, <прогін>_held_pred.npz, cluster.json,
<прогін>_series.npz (видача кожної епохи на всіх T, дна 2.3 і їхні зони —
для вкладки `/buy`).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_early as early  # noqa: E402
import canvas1100_future as fut  # noqa: E402
import canvas1100_future_net as fnet  # noqa: E402
import canvas1100_grow as grow  # noqa: E402
import canvas1100_random as rnd  # noqa: E402
import canvas600_c1 as c1  # noqa: E402
import canvas600_signal as sig  # noqa: E402
from edges30_net import device_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

DATA = RESEARCH / "data" / "canvas1100_buy"
MODELS = RESEARCH / "models" / "canvas1100_buy"
RESULTS = RESEARCH / "results" / "canvas1100_buy"
PAIR = "BTC_USDT"
ROWS, BAR = c.ROWS, c.BAR
CHANNELS = ("class",) * 7 + ("cluster2",)
HOURS = 160
BACK = HOURS * 3600
AHEAD = 40 * 3600
STEP_T = 600
HELD_FROM = 0.8
GAP = BACK + AHEAD
READ = 144                       # T на одне читання секунд
LR, BATCH, EPOCHS, PATIENCE, SEED = 3e-4, 64, 30, 6, 19
FLAT_EPOCHS, FLAT_GAIN = 3, 0.01  # донавчання: стоп, коли 3 епохи втрата навчання не падає на 1 %
MIN_EPOCHS = 12                  # до 12-ї епохи стопу немає: мережа стоїть перші ~8 епох
MEMORY_NEED = 1500
NAME = "zone"
MIN_LEG = 7 * 3600              # нога коротша за 7 год не рахується
SIDE = "bottom"                  # `--side`: bottom — зона дна (бай, BUY_*), top — зона вершини (селл, SELL_*)
SIDES = {"bottom": {"folder": "canvas1100_buy", "prefix": "BUY", "word": "дна"},
         "top": {"folder": "canvas1100_sell", "prefix": "SELL", "word": "вершини"}}
SHARED = ("x.npy", "mask.npy", "val_x.npy", "val_mask.npy")


def use_side(side: str) -> None:
    """Бік півота: `bottom` — дна (етап 19), `top` — вершини (етап 22). Усе,
    крім мітки, те саме; теки — `canvas1100_buy` або `canvas1100_sell`."""
    global SIDE, DATA, MODELS, RESULTS
    folder = SIDES[side]["folder"]
    SIDE = side
    DATA = RESEARCH / "data" / folder
    MODELS = RESEARCH / "models" / folder
    RESULTS = RESEARCH / "results" / folder


def word() -> str:
    return SIDES[SIDE]["word"]


# ------------------------------------------------------------------ ряд і межі

def series() -> dict:
    """Train BTC: записи 100 с, записи 30 с, півоти train."""
    import bars30
    one = rnd.series_of(PAIR, "train")
    with np.load(bars30.DATA / f"{PAIR}_train.npz") as store:
        bars = {k: store[k] for k in ("t", "open", "close")}
    return {**one, "bars": bars, "pair": PAIR}


def plan(t: np.ndarray, held_from: float = HELD_FROM, gap: int = GAP) -> dict:
    """Записи T на сітці 10 хв з повними `BACK` до і `AHEAD` після; межа
    80 % часу; навчання — до межі мінус `gap`, відкладені — від межі."""
    ends = t + BAR
    index = np.flatnonzero((ends % STEP_T == 0) & (ends - BACK >= t[0])
                           & (ends <= t[-1] + BAR - AHEAD))
    stamps = ends[index]
    edge = stamps.min() + held_from * (stamps.max() - stamps.min())
    inside = index[stamps < edge - gap]
    held = index[stamps >= edge]
    return {"inside": inside, "held": held, "edge": int(edge),
            "last_inside": int(ends[inside[-1]])}


def bottoms_of(pivots: dict, keep: np.ndarray | None = None, side: str | None = None) -> dict:
    """Лише півоти свого боку: дна — `top == False`, вершини (`side` =
    `top`) — `top == True` (і за `keep`, коли він даний)."""
    tops = (side or SIDE) == "top"
    keep = (np.asarray(pivots["top"], dtype=bool) == tops) & (True if keep is None else keep)
    size = len(keep)
    return {k: (np.asarray(v)[keep] if np.ndim(v) and len(v) == size else v)
            for k, v in pivots.items()}


def long_bottoms(one: dict, min_leg: int = MIN_LEG) -> dict:
    """Дна 2.3 лише ніг ≥ 7 год: дно лишається, коли хоч одна з двох його
    ніг (до попереднього й до наступного півота) не коротша за `min_leg`."""
    stamps = one["t"][one["pivots"]["index"]]
    left = np.diff(stamps, prepend=stamps[0])
    right = np.diff(stamps, append=stamps[-1])
    return bottoms_of(one["pivots"], np.maximum(left, right) >= min_leg)


def labels_of(one: dict, records: np.ndarray) -> np.ndarray:
    """Мітка «запис T у зоні дна 2.3 ноги ≥ 7 год»."""
    bottoms = long_bottoms(one)
    return np.array([[fut.zone_of(one["close"], bottoms, int(e))] for e in records],
                    dtype=np.float32)


def pivot_zones(one: dict, whole: bool = False) -> list:
    """Зона кожного дна 2.3 ноги ≥ 7 год — усі записи, де `zone_of` = 1
    (та сама зона, що в мітці): до дна не далі за `span` записів і ціна не
    вище дна більше ніж на `zone`; для вершин (`SIDE` = `top`) — ціна не
    нижче вершини більше ніж на `zone`. Ціна може вийти із зони і повернутись,
    тому зона — кілька шматків: час початку першого запису шматка і кінця
    останнього. `whole` — одна зона на дно: від першого шматка до
    останнього."""
    bottoms = long_bottoms(one)
    close, stamps = one["close"], one["t"]
    out = []
    for at, span, price, zone in zip(bottoms["index"], bottoms["span"], bottoms["price"],
                                     bottoms["zone"]):
        reach = int(np.floor(max(span, 0.5)))
        rows = np.arange(max(int(at) - reach, 0), min(int(at) + reach, len(close) - 1) + 1)
        gap = price - close[rows] if SIDE == "top" else close[rows] - price
        inside = rows[np.maximum(gap, 0.0) <= max(zone, 1e-12)]
        if not len(inside):
            continue
        if whole:
            out.append((int(stamps[inside[0]]), int(stamps[inside[-1]]) + BAR))
            continue
        breaks = np.flatnonzero(np.diff(inside) > 1)
        for a, b in zip(np.r_[0, breaks + 1], np.r_[breaks, len(inside) - 1]):
            out.append((int(stamps[inside[a]]), int(stamps[inside[b]]) + BAR))
    return out


# ------------------------------------------------------------------ кластер 2

def subset(store: dict, windows: np.ndarray) -> dict:
    """Частина сховища канв 600: вікна `windows` і їхні зони з новими номерами."""
    renumber = np.full(len(store["meta"]["kind"]), -1, dtype=np.int64)
    renumber[windows] = np.arange(len(windows))
    zones = store["zones"]
    pick = renumber[zones["window"]] >= 0
    new_zones = {k: v[pick] for k, v in zones.items()}
    new_zones["window"] = renumber[zones["window"][pick]]
    return {"x": np.asarray(store["x"][windows]),
            "meta": {k: v[windows] for k, v in store["meta"].items()},
            "zones": new_zones}


def fit_cluster(cutoff: int, log=print) -> dict:
    """Увесь хід кластерів етапу 1 на канвах 600 BTC, що закінчуються не
    пізніше `cutoff` (секунди): грід уточнювача, UMAP cosine, k-means,
    правило кластера 1."""
    import bars30
    import umap
    from sklearn.linear_model import LogisticRegression
    store = sig.load("train")
    meta = store["meta"]
    with np.load(bars30.DATA / f"{PAIR}_train.npz") as bars:
        stamps = bars["t"]
    mine = np.flatnonzero(meta["pair"] == PAIR)
    ends = stamps[meta["end"][mine]] + 30
    windows = mine[ends <= cutoff]
    sub = subset(store, windows)
    del store
    base = int((sub["meta"]["kind"] == "base").sum())
    log(f"канв 600: {len(windows)} (базових {base}), кінець ≤ {cutoff}")
    items = sig.base_items(sub, np.random.default_rng(sig.SEED))
    rows = sig.grid(sub, items, log=log)
    best = sig.pick(rows)
    best = {k: v for k, v in best.items() if k != "matrix"}
    log(f"уточнювач: {best}")
    got = sig.signal_set(sub, best)
    rng = np.random.default_rng(sig.SEED)
    chosen = []
    for part, cap in sig.UMAP_CAP.items():
        where = np.flatnonzero(got["part"] == part)
        if part in sig.TARGETS:
            where = where[got["power"][where] >= best["floor"]]
        if len(where) > cap:
            where = np.sort(rng.choice(where, cap, replace=False))
        chosen.append(where)
    chosen = np.concatenate(chosen)
    vectors = got["vector"][chosen].astype(np.float32)
    finite = np.isfinite(vectors).all(axis=1)
    chosen, vectors = chosen[finite], vectors[finite]
    points = umap.UMAP(n_components=2, metric=c1.METRIC, **sig.UMAP_PARAMS).fit_transform(vectors)
    parts = got["part"][chosen]
    km = sig.kmeans_of(points, parts.tolist())
    y = np.asarray(km["labels"]) == c1.CLUSTER
    model = LogisticRegression(C=1.0, max_iter=2000, random_state=36).fit(vectors, y)
    score = model.decision_function(vectors)
    assigner = {"metric": c1.METRIC, "cluster": c1.CLUSTER + 1,
                "coef": model.coef_[0].tolist(), "intercept": float(model.intercept_[0]),
                "train": {"points": int(len(y)), "cluster1": int(y.sum()),
                          "accuracy": float((model.predict(vectors) == y).mean()),
                          "auc": sig.auc(score[y], score[~y])},
                "counts": km["counts"], "best": best, "cutoff": int(cutoff),
                "windows": int(len(windows)), "base": base}
    MODELS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    (MODELS / "assigner.json").write_text(json.dumps(assigner, ensure_ascii=False, indent=1),
                                          encoding="utf-8")
    (RESULTS / "cluster.json").write_text(json.dumps(
        {**{k: v for k, v in assigner.items() if k not in ("coef",)},
         "umap": {"x": np.round(points, 4).tolist(), "part": parts.tolist(),
                  "cluster": [int(v) + 1 for v in km["labels"]]}},
        ensure_ascii=False), encoding="utf-8")
    log(f"правило кластера 1: {assigner['train']}, склад {km['counts']}")
    return assigner


def assigner_of() -> dict:
    return json.loads((MODELS / "assigner.json").read_text(encoding="utf-8"))


# ------------------------------------------------------------------ канви

def sample_of(one: dict, holder, e: int, assigner: dict) -> tuple:
    """Канва 1100 × 8 вікна 160 год, що закінчується записом `e`."""
    s = early.start_of(one, e, HOURS)
    canvas = c.canvas_of(holder, one["t"], s, e)
    live = canvas["first"] >= 0
    ends = np.where(live, one["t"][s + np.maximum(canvas["last"], 0)] + BAR, 0)
    x = np.zeros((ROWS, len(CHANNELS)), dtype=np.float32)
    x[:, :7] = canvas["net"]
    x[:, 7] = early.cluster2_rows(holder, one, s, e, ends, live, assigner)
    x[~live] = 0.0
    return x, canvas["mask"]


def build(out: Path | None = None, log=print) -> None:
    out = out or DATA
    from numpy.lib.format import open_memmap
    out.mkdir(parents=True, exist_ok=True)
    one = series()
    parts = plan(one["t"])
    assigner = assigner_of()
    if assigner["cutoff"] != parts["last_inside"]:
        raise ValueError("правило кластера порахуване на іншій межі — спершу --cluster")
    index = np.concatenate([parts["inside"], parts["held"]])
    side = np.concatenate([np.zeros(len(parts["inside"]), np.int8),
                           np.ones(len(parts["held"]), np.int8)])
    labels = labels_of(one, index)
    log(f"T: навчання {len(parts['inside'])}, відкладені {len(parts['held'])}; "
        f"у зоні дна {labels[side == 0].mean():.3f} / {labels[side == 1].mean():.3f}")
    x = open_memmap(out / "x.npy", "w+", np.float16, (len(index), ROWS, len(CHANNELS)))
    mask = open_memmap(out / "mask.npy", "w+", bool, (len(index), ROWS))
    started = time.time()
    for b in range(0, len(index), READ):
        piece = index[b:b + READ]
        first = int(one["t"][early.start_of(one, int(piece[0]), HOURS)])
        holder = early.seconds_of(PAIR, first, int(one["t"][piece[-1]]) + BAR - 1)
        for k, e in enumerate(piece):
            x[b + k], mask[b + k] = sample_of(one, holder, int(e), assigner)
        del holder
        log(f"канви {b + len(piece)}/{len(index)}, {time.time() - started:.0f} с", flush=True)
    x.flush()
    mask.flush()
    np.savez(out / "meta.npz", t=(one["t"][index] + BAR).astype(np.int64), record=index,
             side=side, labels=labels, edge=parts["edge"], last_inside=parts["last_inside"])


VAL_FROM = early.VAL_FROM        # 2026-08-15 00:00 UTC — перший T val


def series_full() -> dict:
    """Train + val BTC підряд (канва в T val бере хвіст train як історію);
    півоти — лише val, індекси зсунуті на довжину train."""
    import bars30
    a, b = rnd.series_of(PAIR, "train"), rnd.series_of(PAIR, "val")
    rec = {k: np.concatenate([a[k], b[k]]) for k in ("t", "open", "close")}
    halves = []
    for part in ("train", "val"):
        with np.load(bars30.DATA / f"{PAIR}_{part}.npz") as store:
            halves.append({k: store[k] for k in ("t", "open", "close")})
    bars = {k: np.concatenate([h[k] for h in halves]) for k in ("t", "open", "close")}
    offset = len(a["t"])
    pivots = {k: (np.asarray(v) + offset if k in ("index", "left", "right") else v)
              for k, v in b["pivots"].items()}
    return {**rec, "bars": bars, "pivots": pivots, "pair": PAIR}


def build_val(out: Path | None = None, log=print) -> None:
    out = out or DATA
    """Канви 1100 × 8 на val BTC: T кожні 10 хв від `VAL_FROM` до кінця ряду
    мінус 40 год, тим самим ходом і тим самим правилом кластера 2."""
    from numpy.lib.format import open_memmap
    one = series_full()
    assigner = assigner_of()
    ends = one["t"] + BAR
    index = np.flatnonzero((ends % STEP_T == 0) & (ends >= VAL_FROM) & (ends - BACK >= one["t"][0])
                           & (ends <= one["t"][-1] + BAR - AHEAD))
    labels = labels_of(one, index)
    log(f"val: {len(index)} T, у зоні дна {int(labels.sum())} ({labels.mean():.3f}), "
        f"днів 2.3 {len(long_bottoms(one)['index'])}")
    x = open_memmap(out / "val_x.npy", "w+", np.float16, (len(index), ROWS, len(CHANNELS)))
    mask = open_memmap(out / "val_mask.npy", "w+", bool, (len(index), ROWS))
    started = time.time()
    for b in range(0, len(index), READ):
        piece = index[b:b + READ]
        first = int(one["t"][early.start_of(one, int(piece[0]), HOURS)])
        holder = early.seconds_of(PAIR, first, int(one["t"][piece[-1]]) + BAR - 1)
        for k, e in enumerate(piece):
            x[b + k], mask[b + k] = sample_of(one, holder, int(e), assigner)
        del holder
        log(f"val канви {b + len(piece)}/{len(index)}, {time.time() - started:.0f} с", flush=True)
    x.flush()
    mask.flush()
    zones = np.array(pivot_zones(one), dtype=np.int64).reshape(-1, 2)
    np.savez(out / "val_meta.npz", t=ends[index].astype(np.int64), record=index, labels=labels,
             close=one["close"][index], bottoms=len(long_bottoms(one)["index"]),
             zone_from=zones[:, 0], zone_to=zones[:, 1])


def load_val(data: Path | None = None) -> dict:
    data = data or DATA
    out = {key: np.load(data / f"val_{key}.npy", mmap_mode="r") for key in ("x", "mask")}
    with np.load(data / "val_meta.npz") as store:
        out.update({key: store[key] for key in store.files})
    return out


def relabel(out: Path | None = None, log=print) -> None:
    out = out or DATA
    """Мітки готових канв заново (`labels_of`) — канви не перебудовуються."""
    with np.load(out / "meta.npz") as store:
        meta = {key: store[key] for key in store.files}
    meta["labels"] = labels_of(rnd.series_of(PAIR, "train"), meta["record"])
    np.savez(out / "meta.npz", **meta)
    side = meta["side"]
    log(f"мітки: у зоні {word()} навчання {int(meta['labels'][side == 0].sum())}, "
        f"відкладені {int(meta['labels'][side == 1].sum())}")
    if (out / "val_meta.npz").exists():
        with np.load(out / "val_meta.npz") as store:
            val = {key: store[key] for key in store.files}
        one = series_full()
        val["labels"] = labels_of(one, val["record"])
        zones = np.array(pivot_zones(one), dtype=np.int64).reshape(-1, 2)
        val.update(bottoms=len(long_bottoms(one)["index"]), zone_from=zones[:, 0], zone_to=zones[:, 1])
        np.savez(out / "val_meta.npz", **val)
        log(f"val: у зоні {word()} {int(val['labels'].sum())}, півотів 2.3 {int(val['bottoms'])}")


def share(log=print) -> None:
    """Канви й кластер 2 від мітки не залежать: тека боку бере канви
    `canvas1100_buy` посиланнями, мета й правило кластера — копіями, і
    мітки рахуються заново (`relabel`)."""
    import shutil
    source = SIDES["bottom"]["folder"]
    data, models, results = (RESEARCH / kind / source for kind in ("data", "models", "results"))
    if DATA == data:
        raise SystemExit("--share — лише для --side top")
    for path in (DATA, MODELS, RESULTS):
        path.mkdir(parents=True, exist_ok=True)
    for name in SHARED:
        link = DATA / name
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(data / name)
    for name in ("meta.npz", "val_meta.npz"):
        shutil.copyfile(data / name, DATA / name)
    shutil.copyfile(models / "assigner.json", MODELS / "assigner.json")
    shutil.copyfile(results / "cluster.json", RESULTS / "cluster.json")
    log(f"канви {', '.join(SHARED)} → {data}; мета, assigner.json, cluster.json скопійовані")
    relabel(log=log)


def load(data: Path | None = None) -> dict:
    data = data or DATA
    out = {key: np.load(data / f"{key}.npy", mmap_mode="r") for key in ("x", "mask")}
    with np.load(data / "meta.npz") as store:
        out.update({key: store[key] for key in store.files})
    return out


# ------------------------------------------------------------------ навчання

def held_bottoms(data: dict, held: np.ndarray) -> int:
    """Скільки різних днів 2.3 дають зону у відкладених (незалежні одиниці)."""
    bottoms = long_bottoms(rnd.series_of(PAIR, "train"))
    records = data["record"][held][data["labels"][held, 0] == 1]
    near = set()
    for at in records:
        hit = np.flatnonzero(np.abs(bottoms["index"] - at) <= np.maximum(bottoms["span"], 0.5))
        near.update(int(k) for k in hit)
    return len(near)


LOSSES = ("bce", "pos", "focal", "dice", "far", "ladder", "ladder2")
FOCAL_GAMMA, FOCAL_ALPHA = 2.0, 0.25
FAR_ALPHA, FAR_SCALE = 4.0, 48.0    # хибний сигнал: вага 1 + 4 · min(відстань / 48 год, 1)


def distance_of(stamps: np.ndarray, zones: list) -> np.ndarray:
    """Години від кожного T до найближчого шматка зони дна (0 — усередині)."""
    out = np.full(len(stamps), np.inf)
    for lo, hi in zones:
        gap = np.where(stamps < lo, lo - stamps, np.where(stamps > hi, stamps - hi, 0))
        out = np.minimum(out, gap)
    return out / 3600.0


LADDER_PAD = 2 * 3600             # зона попадання: зона дна ± 2 год
LADDER_PARTS = 10                 # відрізок між зонами — на 10 рівних частин
LADDER_STEP = 2.0                 # частина 1 (біля поточної зони) ×2 … частина 10 ×20
# `ladder2`: частини 2–5 на +1; ціль — зона дна ± 2 год, мовчання в ній — `silence`
LADDER2_STEPS = (2.0, 5.0, 7.0, 9.0, 11.0, 12.0, 14.0, 16.0, 18.0, 20.0)


def wide_labels(stamps: np.ndarray, zones: list, pad: int = LADDER_PAD) -> np.ndarray:
    """Мітка `ladder2`: T у зоні дна цілком ± 2 год."""
    out = np.zeros((len(stamps), 1), dtype=np.float32)
    for lo, hi in zones:
        out[(stamps > lo - pad) & (stamps <= hi + pad), 0] = 1.0
    return out


def ladder_weight(stamps: np.ndarray, y: np.ndarray, zones: list, pad: int = LADDER_PAD,
                  parts: int = LADDER_PARTS, step: float = LADDER_STEP,
                  steps: tuple | None = None, silence: float = 1.0) -> np.ndarray:
    """Вага прикладу в `ladder`; `zones` — зона кожного дна цілком (від
    першого шматка до останнього). Мітка 1 (T у зоні дна) — 1. Зона
    попадання (зона дна ± 2 год, злиті за часом) без мітки — 0: сигнал там не
    штрафується. Між попередньою і поточною зоною (від кінця попередньої
    + 2 год до початку поточної − 2 год) відрізок ділиться на 10 рівних
    частин від поточної зони: частина 1 — ×2, частина k — ×2k, частина 10
    (біля попередньої зони) — ×20. До першої зони й після останньої — 0:
    вони не лежать між двома зонами. `steps` — свої ваги частин 1 … 10,
    `silence` — вага мітки 1 (мовчання в цілі)."""
    wide = sorted((lo - pad, hi + pad) for lo, hi in zones)
    merged = []
    for lo, hi in wide:
        if merged and lo <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    out = np.zeros(len(stamps))
    for (_, left), (right, _) in zip(merged[:-1], merged[1:]):
        inside = (stamps > left) & (stamps < right)
        share = (right - stamps[inside]) / (right - left)            # 0 біля поточної, 1 біля попередньої
        part = np.minimum(np.floor(share * parts).astype(int) + 1, parts)
        out[inside] = (np.asarray(steps)[part - 1] if steps is not None else step * part)
    return np.where(y > 0, silence, out)


def far_weight(distance: np.ndarray, y: np.ndarray, alpha: float = FAR_ALPHA,
               scale: float = FAR_SCALE) -> np.ndarray:
    """Вага прикладу в `far`: позитив — 1; негатив — 1 + α · min(d / scale, 1):
    хибний сигнал тим дорожчий, чим далі T від зони дна."""
    return np.where(y > 0, 1.0, 1.0 + alpha * np.minimum(distance / scale, 1.0))


def loss_of(name: str, pos_weight: float):
    """Функції втрат перебору: `bce` — BCE; `pos` — BCE з вагою позитиву
    негативів / позитивів навчання; `focal` — focal (γ 2, α 0.25);
    `dice` — BCE плюс `1 − soft dice` на батчі; `far` — BCE з вагою
    прикладу (`far_weight`, вага передається третім аргументом)."""
    bce = nn.BCEWithLogitsLoss()
    if name == "bce":
        return bce
    if name == "pos":
        return nn.BCEWithLogitsLoss(pos_weight=torch.tensor([pos_weight]))
    if name == "focal":
        def focal(logits, y):
            p = torch.sigmoid(logits)
            ce = nn.functional.binary_cross_entropy_with_logits(logits, y, reduction="none")
            hit = p * y + (1 - p) * (1 - y)
            weight = FOCAL_ALPHA * y + (1 - FOCAL_ALPHA) * (1 - y)
            return (weight * (1 - hit) ** FOCAL_GAMMA * ce).mean()
        return focal
    if name == "dice":
        def dice(logits, y):
            p = torch.sigmoid(logits)
            soft = (2 * (p * y).sum() + 1) / (p.sum() + y.sum() + 1)
            return bce(logits, y) + 1 - soft
        return dice
    if name in ("far", "ladder", "ladder2"):
        def far(logits, y, weight):
            ce = nn.functional.binary_cross_entropy_with_logits(logits, y, reduction="none")
            return (weight * ce).sum() / weight.sum()
        return far
    raise ValueError(name)


def average_precision(score: np.ndarray, truth: np.ndarray) -> float:
    """Середня влучність (площа під кривою точність — повнота)."""
    pos = int((truth == 1).sum())
    if not pos:
        return float("nan")
    order = np.argsort(-score, kind="mergesort")
    hits = (truth[order] == 1).astype(float)
    precision = np.cumsum(hits) / np.arange(1, len(hits) + 1)
    return float((precision * hits).sum() / pos)


def score_of(prob: np.ndarray, labels: np.ndarray, thresholds: dict | None = None) -> tuple:
    got, chosen = fnet.measure(prob, labels, thresholds, names=(NAME,))
    got[NAME]["ap"] = average_precision(prob[:, 0], labels[:, 0])
    return got, chosen


def train(run: str, device, loss: str = "bce", init: str | None = None, lr: float = LR,
          silence: float = 1.0, steps: tuple = LADDER2_STEPS, log=print) -> dict:
    """Навчання на навчальній частині train BTC; епоха — за F1 при
    найкращому порозі на відкладених (рівний F1 — більший AP); видача
    кожної епохи на val BTC — лише для вкладки й заміру обраної епохи, у
    вибір не йде. `init` — `<прогін>:<епоха>`: донавчання з цих ваг,
    стартова епоха 0 міряється тим самим ходом і теж може бути обрана."""
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    data = load()
    val = load_val()
    if loss == "ladder2":
        # ціль — зона дна цілком ± 2 год: і в навчанні, і в мірах
        data["labels"] = wide_labels(data["t"], pivot_zones(rnd.series_of(PAIR, "train"), whole=True))
        val["labels"] = wide_labels(val["t"], pivot_zones(series_full(), whole=True))
    inside = np.flatnonzero(data["side"] == 0)
    held = np.flatnonzero(data["side"] == 1)
    positive = float(data["labels"][inside].sum())
    pos_weight = (len(inside) - positive) / max(positive, 1.0)
    log(f"{run} ({loss}): train {len(inside)}, відкладені {len(held)}, val {len(val['t'])}; частка "
        f"зони {word()}: train {data['labels'][inside].mean():.3f}, відкладені "
        f"{data['labels'][held].mean():.3f}, val {val['labels'].mean():.3f}")
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = fnet.Future(channels=len(CHANNELS), outputs=1).to(device)
    if init:
        source, number = init.split(":")
        model.load_state_dict(torch.load(MODELS / source / f"epoch_{int(number):02d}.pt",
                                         map_location=device))
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = loss_of(loss, pos_weight)
    if loss == "pos":
        loss_fn = loss_fn.to(device)
    zones = pivot_zones(rnd.series_of(PAIR, "train"))
    distance = distance_of(data["t"], zones)
    ladder = ladder_weight(data["t"], data["labels"][:, 0],
                           pivot_zones(rnd.series_of(PAIR, "train"), whole=True),
                           steps=steps if loss == "ladder2" else None, silence=silence)
    history, best, wait = [], None, 0
    val_index = np.arange(len(val["t"]))
    val_prob = []
    min_epochs = 0 if init else MIN_EPOCHS
    floor, flat = None, 0
    for epoch in range(0 if init else 1, EPOCHS + 1):
        started = time.time()
        order = rng.permutation(inside)
        total = 0.0
        model.train()
        for begin in range(0, len(order) if epoch else 0, BATCH):
            x, mask, y, index = fnet.batch_of(data, order[begin:begin + BATCH], device)
            optimizer.zero_grad()
            if loss in ("far", "ladder", "ladder2"):
                w = (far_weight(distance[index], data["labels"][index]) if loss == "far"
                     else ladder[index][:, None])
                weight = torch.from_numpy(w.astype(np.float32)).to(device)
                value = loss_fn(model(x, mask), y, weight)
            else:
                value = loss_fn(model(x, mask), y)
            value.backward()
            optimizer.step()
            total += float(value.detach()) * len(y)
        prob = fnet.predict(model, data, held, device)
        score, thresholds = score_of(prob, data["labels"][held])
        val_prob.append(fnet.predict(model, val, val_index, device)[:, 0])
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        one = {"epoch": epoch, "loss": total / len(order) if epoch else None,
               "held_ap": score[NAME]["ap"],
               "held_auc": score[NAME]["auc"], "thresholds": thresholds, "held": score,
               "seconds": time.time() - started}
        history.append(one)
        log(f"{run} е{epoch}: втрата {one['loss'] or 0:.4f}, відкладені AP {score[NAME]['ap']:.3f} "
            f"AUC {score[NAME]['auc']:.3f} F1 {score[NAME]['f1']:.3f} (база {score[NAME]['base_f1']:.3f}) "
            f"поріг {thresholds[NAME]:.2f}, {one['seconds']:.0f} с", flush=True)
        key = (score[NAME]["f1"], one["held_ap"])
        if best is None or key > best["key"]:
            best, wait = {"epoch": epoch, "key": key}, 0
        else:
            wait += 1
        if init:
            # донавчання йде, поки мережа вчиться: втрата навчання падає
            if epoch and (floor is None or one["loss"] < floor * (1 - FLAT_GAIN)):
                floor, flat = one["loss"], 0
            elif epoch:
                flat += 1
            if flat >= FLAT_EPOCHS:
                break
        elif wait >= PATIENCE and epoch >= min_epochs:
            break
    top = next(one for one in history if one["epoch"] == best["epoch"])
    prob = np.stack(val_prob)
    epochs = [one["epoch"] for one in history]
    val_score, _ = score_of(prob[epochs.index(best["epoch"])][:, None], val["labels"], top["thresholds"])
    RESULTS.mkdir(parents=True, exist_ok=True)
    np.savez(RESULTS / f"{run}_val.npz", epochs=np.array(epochs),
             prob=prob.astype(np.float16), t=val["t"], close=val["close"], labels=val["labels"][:, 0])
    out = {"run": run, "loss": loss, "init": init, "lr": lr, "pair": PAIR, "best_epoch": best["epoch"],
           "thresholds": top["thresholds"], "held": top["held"], "val": val_score,
           "history": [{k: one[k] for k in ("epoch", "loss", "held_ap", "held_auc", "seconds")}
                       | {"f1": one["held"][NAME]["f1"], "threshold": one["thresholds"][NAME]}
                       for one in history],
           "config": {"patch": fnet.PATCH, "dim": fnet.DIM, "layers": fnet.LAYERS,
                      "heads": fnet.HEADS, "dropout": fnet.DROPOUT, "lr": lr, "batch": BATCH,
                      "epochs": EPOCHS, "patience": PATIENCE, "min_epochs": min_epochs, "seed": SEED,
                      "hours": HOURS, "step_t": STEP_T, "ahead": AHEAD, "held_from": HELD_FROM,
                      "gap": GAP, "channels": list(CHANNELS), "loss": loss, "pos_weight": pos_weight,
                      "focal": [FOCAL_GAMMA, FOCAL_ALPHA], "far": [FAR_ALPHA, FAR_SCALE],
                      "ladder": [LADDER_PAD, LADDER_PARTS, LADDER_STEP],
                      "ladder2": list(steps), "silence": silence,
                      "init": init, "select": "F1 при найкращому порозі на відкладених, рівний — AP",
                      "stop": ("донавчання: 3 епохи втрата навчання не падає на 1 %, стеля 30" if init
                               else "терпіння 6 за F1 на відкладених, не раніше 12-ї, стеля 30"),
                      "side": SIDE,
                      "label": (f"зона {word()} 2.3 % цілком ± 2 год, ноги ≥ 7 год" if loss == "ladder2"
                                else f"зона {word()} 2.3 %, ноги ≥ 7 год")},
           "split": {"edge": int(data["edge"]), "last_inside": int(data["last_inside"]),
                     "inside_from": int(data["t"][inside[0]]), "inside_to": int(data["t"][inside[-1]]),
                     "held_from": int(data["t"][held[0]]), "held_to": int(data["t"][held[-1]]),
                     "val_from": int(val["t"][0]), "val_to": int(val["t"][-1])},
           "counts": {"inside": int(len(inside)), "inside_zone": int(data["labels"][inside].sum()),
                      "held": int(len(held)), "held_zone": int(data["labels"][held].sum()),
                      "held_bottoms": held_bottoms(data, held), "val": int(len(val["t"])),
                      "val_zone": int(val["labels"].sum()), "val_bottoms": int(val["bottoms"])}}
    (RESULTS / f"{run}.json").write_text(json.dumps(out, ensure_ascii=False, indent=1,
                                                    default=float), encoding="utf-8")
    log(f"{run}: найкраща епоха {best['epoch']}, відкладені {top['held'][NAME]}, val {val_score[NAME]}")
    return out


def save_series(run: str, device, log=print) -> None:
    """Видача кожної збереженої епохи на всіх T (навчання і відкладені),
    ціна в T, мітка, частина; півоти train — для графіка вкладки."""
    data = load()
    one = rnd.series_of(PAIR, "train")
    every = np.arange(len(data["t"]))
    epochs = sorted(int(path.stem.split("_")[1]) for path in (MODELS / run).glob("epoch_*.pt"))
    prob = np.zeros((len(epochs), len(every)), dtype=np.float16)
    model = fnet.Future(channels=len(CHANNELS), outputs=1).to(device)
    for k, epoch in enumerate(epochs):
        model.load_state_dict(torch.load(MODELS / run / f"epoch_{epoch:02d}.pt", map_location=device))
        prob[k] = fnet.predict(model, data, every, device)[:, 0]
        log(f"{run} е{epoch}: видача на {len(every)} T", flush=True)
    bottoms = long_bottoms(one)
    zones = np.array(pivot_zones(one), dtype=np.int64).reshape(-1, 2)
    np.savez(RESULTS / f"{run}_series.npz", epochs=np.array(epochs), prob=prob, t=data["t"],
             close=one["close"][data["record"]], labels=data["labels"][:, 0], side=data["side"],
             pivot_t=(one["t"][bottoms["index"]] + BAR).astype(np.int64),
             pivot_price=np.asarray(bottoms["price"], dtype=np.float64),
             zone_from=zones[:, 0], zone_to=zones[:, 1])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--side", default="bottom", choices=tuple(SIDES),
                        help="bottom — зона дна (BUY_*), top — зона вершини (SELL_*)")
    parser.add_argument("--share", action="store_true",
                        help="--side top: канви й кластер 2 з canvas1100_buy, мітки заново")
    parser.add_argument("--cluster", action="store_true", help="кластер 2 на навчальній частині")
    parser.add_argument("--build", action="store_true", help="канви 1100 × 8 і мітки")
    parser.add_argument("--val", action="store_true", help="канви 1100 × 8 на val BTC")
    parser.add_argument("--run", help="навчання прогону")
    parser.add_argument("--loss", default="bce", choices=LOSSES)
    parser.add_argument("--init", help="донавчання з ваг <прогін>:<епоха>")
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--silence", type=float, default=1.0, help="ladder2: вага мовчання в цілі")
    parser.add_argument("--steps", help="ladder2: ваги частин 1 … 10 через кому")
    parser.add_argument("--series", help="видача всіх епох прогону на всіх T")
    parser.add_argument("--labels", action="store_true", help="мітки готових канв заново")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    use_side(args.side)
    if args.share:
        share()
    if args.cluster:
        one = series()
        fit_cluster(plan(one["t"])["last_inside"])
    if args.build:
        build()
    if args.labels:
        relabel()
    if args.val:
        build_val()
    if args.run:
        no_swap(MEMORY_NEED, args.force)
        steps = (tuple(float(v) for v in args.steps.split(",")) if args.steps else LADDER2_STEPS)
        if len(steps) != LADDER_PARTS:
            raise SystemExit(f"--steps: потрібно {LADDER_PARTS} ваг")
        train(args.run, device_of(args.device), args.loss, args.init, args.lr, args.silence, steps)
    if args.series:
        save_series(args.series, device_of(args.device))


if __name__ == "__main__":
    main()
