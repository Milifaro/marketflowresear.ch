#!/bin/zsh
# Етап 19: донавчання BUY_bce е16 втратою ladder2 (мовчання ×1), далі
# гріда штрафу за мовчання ×1 … ×10 з обраної епохи BUY_l2.
cd "$(dirname "$0")/../../.."
S=research/36-canvas600-pivots/scripts/canvas1100_buy.py
L=research/36-canvas600-pivots/logs
R=research/36-canvas600-pivots/results/canvas1100_buy
python3 -u $S --run BUY_l2 --loss ladder2 --init BUY_bce:16 --lr 1e-4 --silence 1 --force > $L/buy_l2.log 2>&1 || exit 1
best=$(python3 -c "import json; print(json.load(open('$R/BUY_l2.json'))['best_epoch'])")
init="BUY_l2:$best"
[ "$best" = "0" ] && init="BUY_bce:16"
for s in 1 2 3 4 5 6 7 8 9 10; do
  python3 -u $S --run BUY_l2s$s --loss ladder2 --init $init --lr 1e-4 --silence $s --force > $L/buy_l2s$s.log 2>&1 || exit 1
done
