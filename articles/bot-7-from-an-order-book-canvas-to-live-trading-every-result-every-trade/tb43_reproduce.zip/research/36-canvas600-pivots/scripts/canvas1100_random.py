"""Етап 12: три голови на випадкових вікнах від 1 до 8 півотів, канва на льоту.

Дослідження: research/36-canvas600-pivots/ → Етап 12

## Хід

1. **Ряд і мітки** — як в етапі 11 (`canvas1100_grow`): записи 100 с,
   півоти 2.3 і корекції 0.8 етапу 6, коди рядків трьох голів
   (`codes_of`: вершина, корекція, дно; `SWAP`, `REPEAT`, `ALT`,
   підтвердження до правого краю), та сама втрата (`loss_of`).
2. **Випадкове вікно** — число півотів `N` рівно з тих 1 … 8, що
   вміщаються в шматок, початок `s` — випадковий запис, після якого в
   шматку є ще `N` півотів; правий край — випадковий запис між `N`-м і
   `N + 1`-м півотом після `s`: у вікні рівно `N` півотів. Канва 1100 —
   `canvas1100.canvas_of` на секундах, щоразу нова, вікна не
   повторюються.
3. **Подача** — `WORKERS` процесів: процес бере випадкову монету (вага —
   довжина її частини) і випадковий шматок `REGION_DAYS` діб, читає його
   секунди раз і ріже з нього `PER_REGION` випадкових вікон, далі — новий
   шматок. Головний процес тримає буфер на `BUFFER` вікон і бере з нього
   випадково: у батчі — вікна з десятків різних шматків різних монет.
4. **Розбиття** — навчання: шматки train до різу монети етапу 11
   (півот ⌊0.8 · півотів train⌋); відкладені — сталі `FIXED` випадкових
   вікон після різу; val — сталі `FIXED` випадкових вікон val (seed 12).
5. **Навчання** — з найкращих ваг прогону етапу 11 (`--init`); епоха —
   `EPOCH` свіжих вікон; після епохи — пороги голів і міра на відкладених,
   міра на val; стоп після `PATIENCE` епох без покращення середнього F1
   трьох голів на відкладених, стеля `EPOCHS`. Adam lr 1e-4, батч 8
   кусками по 4, seed 12.
6. **Міра** — як в етапі 11; наприкінці три найкращі епохи міряються ще й
   на всіх вікнах циклу val етапу 11 — поряд із прогоном етапу 11.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --fixed
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --run R_tune --init G_tune

Етап 13 — ті самі вікна рівно з одним півотом (`--n 1 1`: сталі вікна
`held_n1-1`, `val_n1-1`), старт — найкраща епоха `R_tune`:
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --fixed --n 1 1
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --run R1_tune --init R_tune --n 1 1

Етап 14 — вікна рівномірної довжини (`--length`, `pick_by_length`): довжина
рівно від години до шматка (12 діб), початок випадковий, у вікні від 1 до
8 півотів; сталі вікна `held_len`, `val_len`; старт — найкраща епоха `R_tune`:
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --fixed --length
    python3 research/36-canvas600-pivots/scripts/canvas1100_random.py --run RL_tune --init R_tune --length

Вихід: data/canvas1100_random/<held|val>_*.npy; models/canvas1100_random/
<прогін>/epoch_NN.pt; results/canvas1100_random/<прогін>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_grow as grow  # noqa: E402
from canvas600_data import corrections_of, with_neighbours  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_data import pivots_of  # noqa: E402
from edges30_net import device_of, scalars_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

DATA = RESEARCH / "data" / "canvas1100_random"
MODELS = RESEARCH / "models" / "canvas1100_random"
RESULTS = RESEARCH / "results" / "canvas1100_random"
PAIRS = grow.PAIRS
ROWS = grow.ROWS
HEADS = grow.HEADS
N_MIN, N_MAX = 1, 8
REGION_DAYS = 12
PER_REGION = 32
WORKERS = 2
BUFFER = 1024
EPOCH = 20000                    # свіжих вікон на епоху
EPOCHS, PATIENCE = 30, 4
FIXED = 2100                     # сталих вікон у відкладених і val
LR, BATCH, MICRO = 1e-4, 8, 4
SEED = 12
MEMORY_NEED = 2400
BEST = 3


def series_of(pair: str, part: str, source: Path = grow.SOURCE) -> dict:
    """Записи частини монети, півоти й корекції."""
    with np.load(source / f"{pair}_{part}.npz") as store:
        bars = {name: store[name] for name in ("t", "open", "close")}
    legs = json.loads((source / f"legs_{part}.json").read_text(encoding="utf-8"))[pair]
    pivots = with_neighbours(pivots_of(legs, bars["close"]), len(bars["t"]))
    corrections = corrections_of(legs, bars["open"], bars["close"], pivots)
    return {**bars, "pivots": pivots, "corrections": corrections}


def pick_window(index: np.ndarray, lo: int, hi: int, rng, n_min: int = N_MIN,
                n_max: int = N_MAX) -> tuple | None:
    """Випадкове вікно `[s, e]` у межах `[lo, hi]` з рівно `N` півотами:
    `N` рівно з тих `n_min … n_max`, що вміщаються в межі; `s` — випадковий
    запис, після якого до `hi` є ще `N` півотів; `e` — випадковий запис між
    `N`-м і `N + 1`-м півотом після `s`."""
    inside = index[(index >= lo) & (index <= hi)]
    fits = [n for n in range(n_min, n_max + 1) if n <= len(inside)]
    if not fits:
        return None
    n = int(rng.choice(fits))
    s = int(rng.integers(lo, int(inside[len(inside) - n]) + 1))
    a = int(np.searchsorted(index, s, side="left"))
    first = int(index[a + n - 1])
    last = min(int(index[a + n]) - 1 if a + n < len(index) else hi, hi)
    return s, int(rng.integers(first, last + 1)), n


def pick_by_length(index: np.ndarray, lo: int, hi: int, rng, n_min: int = N_MIN,
                   n_max: int = N_MAX, shortest: int = 3600 // c.BAR,
                   tries: int = 40) -> tuple | None:
    """Випадкове вікно рівномірної довжини: довжина `L` рівно з `shortest …
    hi − lo + 1` записів, початок — випадковий; вікно береться, коли в ньому
    від `n_min` до `n_max` півотів. Для тієї самої `L` пробується до `tries`
    початків, і лише тоді тягнеться нова довжина — так довжини взятих
    вікон лишаються рівномірними."""
    longest = hi - lo + 1
    if longest < shortest:
        return None
    for _ in range(tries):
        length = int(rng.integers(shortest, longest + 1))
        for _ in range(tries):
            s = int(rng.integers(lo, hi - length + 2))
            e = s + length - 1
            n = int(np.searchsorted(index, e, side="right")
                    - np.searchsorted(index, s, side="left"))
            if n_min <= n <= n_max:
                return s, e, n
    return None


def sample_of(one: dict, holder, start: int, end: int, n: int) -> dict:
    """Канва, коди, власники й скаляри одного вікна."""
    canvas = c.canvas_of(holder, one["t"], start, end)
    got = grow.codes_of(start, end, canvas["first"], canvas["last"], one["close"],
                        one["pivots"], one["corrections"])
    scalars = np.array([np.log1p(end - start + 1), np.log1p(canvas["step"]),
                        float(np.log(one["close"][end] / one["open"][start])),
                        float(canvas["mask"].mean())], dtype=np.float32)
    return {"x": canvas["net"], "code": got["code"], "owner": got["owner"],
            "mask": canvas["mask"], "scalars": scalars, "n": n,
            "start": start, "end": end}


def regions(part: str, bounds: dict, rng, per_region: int = PER_REGION,
            days: int = REGION_DAYS, root: Path | None = None,
            n: tuple = (N_MIN, N_MAX), length: bool = False):
    """Нескінченний потік вікон: шматок монети → `per_region` вікон;
    `length` — вікна рівномірної довжини (`pick_by_length`)."""
    import bars30
    data = {pair: series_of(pair, part) for pair in bounds}
    pairs = list(bounds)
    weight = np.array([bounds[p][1] - bounds[p][0] for p in pairs], float)
    weight /= weight.sum()
    span = days * 86400 // c.BAR
    while True:
        pair = pairs[int(rng.choice(len(pairs), p=weight))]
        one = data[pair]
        lo_all, hi_all = bounds[pair]
        lo = int(rng.integers(lo_all, max(hi_all - span, lo_all) + 1))
        hi = min(lo + span, hi_all)
        pick = pick_by_length if length else pick_window
        windows = [w for w in (pick(one["pivots"]["index"], lo, hi, rng, *n)
                               for _ in range(per_region)) if w is not None]
        if not windows:
            continue
        holder = bars30.read_seconds(pair, int(one["t"][min(w[0] for w in windows)]),
                                     int(one["t"][max(w[1] for w in windows)]) + c.BAR - 1,
                                     {}, root)
        for s, e, count in windows:
            got = sample_of(one, holder, s, e, count)
            got["pair"] = pair
            yield got
        del holder


def bounds_of(part: str, cut: dict | None, side: str) -> dict:
    """Межі записів на монету: train до різу, відкладені після, val — усе."""
    out = {}
    for pair in PAIRS:
        with np.load(grow.SOURCE / f"{pair}_{part}.npz") as store:
            size = len(store["t"])
        if side == "inside":
            out[pair] = (0, int(cut[pair]) - 1)
        elif side == "held":
            out[pair] = (int(cut[pair]) + 1, size - 1)
        else:
            out[pair] = (0, size - 1)
    return out


class Stream(torch.utils.data.IterableDataset):
    """Потік вікон навчання; кожен процес — свій seed."""

    def __init__(self, bounds: dict, seed: int, n: tuple = (N_MIN, N_MAX),
                 length: bool = False):
        self.bounds, self.seed, self.n, self.length = bounds, seed, n, length

    def __iter__(self):
        info = torch.utils.data.get_worker_info()
        rng = np.random.default_rng([self.seed, info.id if info else 0])
        for got in regions("train", self.bounds, rng, n=self.n, length=self.length):
            yield {key: got[key] for key in ("x", "code", "mask", "scalars")}


def shuffled(loader, size: int = BUFFER, seed: int = SEED):
    """Буфер перемішування: бере вікно з потоку, віддає випадкове з буфера."""
    rng = np.random.default_rng(seed)
    buffer = []
    for got in loader:
        if len(buffer) < size:
            buffer.append(got)
            continue
        k = int(rng.integers(len(buffer)))
        yield buffer[k]
        buffer[k] = got


def suffix_of(n: tuple, length: bool = False) -> str:
    """Сталі вікна на `N` 1 … 8 — без суфікса, інакше `_n<від>-<до>`;
    вікна рівномірної довжини — ще `_len`."""
    out = "" if tuple(n) == (N_MIN, N_MAX) else f"_n{n[0]}-{n[1]}"
    return out + ("_len" if length else "")


def build_fixed(out: Path = DATA, n: tuple = (N_MIN, N_MAX), length: bool = False,
                log=print) -> None:
    """Сталі випадкові вікна відкладених (train після різу) і val."""
    out.mkdir(parents=True, exist_ok=True)
    cut = json.loads((grow.DATA / "train_build.json").read_text(encoding="utf-8"))["cut"]
    for name, part, side in (("held", "train", "held"), ("val", "val", "all")):
        rng = np.random.default_rng(SEED)
        stream = regions(part, bounds_of(part, cut, side), rng, n=n, length=length)
        rows = [next(stream) for _ in range(FIXED)]
        name = f"{name}{suffix_of(n, length)}"
        np.save(out / f"{name}_x.npy", np.stack([r["x"] for r in rows]).astype(np.float16))
        np.save(out / f"{name}_code.npy", np.stack([r["code"] for r in rows]))
        np.save(out / f"{name}_owner.npy", np.stack([r["owner"] for r in rows]))
        np.save(out / f"{name}_mask.npy", np.stack([r["mask"] for r in rows]))
        np.savez(out / f"{name}_meta.npz", pair=np.array([r["pair"] for r in rows]),
                 n=np.array([r["n"] for r in rows]),
                 start=np.array([r["start"] for r in rows]),
                 end=np.array([r["end"] for r in rows]),
                 scalars=np.stack([r["scalars"] for r in rows]))
        log(f"{name}: {len(rows)} вікон, N " +
            str(np.bincount([r["n"] for r in rows]).tolist()) + ", годин (0/25/50/75/100 %) " +
            str(np.percentile([(r["end"] - r["start"] + 1) * c.BAR / 3600 for r in rows],
                              [0, 25, 50, 75, 100]).round(1).tolist()))


def load_fixed(name: str, data: Path = DATA) -> dict:
    out = {key: np.load(data / f"{name}_{key}.npy", mmap_mode="r")
           for key in ("x", "code", "owner", "mask")}
    with np.load(data / f"{name}_meta.npz") as store:
        out.update({key: store[key] for key in store.files})
    out["numbers"] = scalars_of(out["scalars"])
    return out


def score(model, fixed: dict, device, thresholds: dict | None = None) -> tuple:
    index = np.arange(len(fixed["n"]))
    prob = grow.predict(model, fixed, index, device)
    thresholds = thresholds or grow.thresholds_of(prob, fixed, index)
    counts = grow.counts_of(prob, fixed, index, thresholds)
    return thresholds, counts


def cycle_val(model, device, thresholds: dict) -> dict:
    """Усі вікна циклу val етапу 11 — поряд із його прогоном."""
    val = grow.load("val")
    index = np.arange(len(val["n"]))
    counts = np.concatenate([
        grow.counts_of(grow.predict(model, val, index[b:b + grow.CHUNK], device), val,
                       index[b:b + grow.CHUNK], thresholds)
        for b in range(0, len(index), grow.CHUNK)])
    return grow.by_group(counts, val, index)


def train(run: str, init: str, device, log=print, n: tuple = (N_MIN, N_MAX),
          length: bool = False) -> dict:
    torch.manual_seed(SEED)
    cut = json.loads((grow.DATA / "train_build.json").read_text(encoding="utf-8"))["cut"]
    held = load_fixed(f"held{suffix_of(n, length)}")
    val = load_fixed(f"val{suffix_of(n, length)}")
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = Finder3(rows=ROWS, outputs=3)
    # старт — прогін етапу 12, коли він є, інакше — етапу 11
    results, models = ((RESULTS, MODELS) if (RESULTS / f"{init}.json").exists()
                       else (grow.RESULTS, grow.MODELS))
    start = json.loads((results / f"{init}.json").read_text(encoding="utf-8"))
    model.load_state_dict(torch.load(models / init / f"epoch_{start['best_epoch']:02d}.pt",
                                     map_location="cpu"))
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    loader = torch.utils.data.DataLoader(Stream(bounds_of("train", cut, "inside"), SEED, n, length),
                                         batch_size=None, num_workers=WORKERS,
                                         persistent_workers=True)
    feed = shuffled(loader)
    history, best, wait = [], None, 0
    for epoch in range(1, EPOCHS + 1):
        started = time.time()
        model.train()
        total, seen = 0.0, 0
        for _ in range(EPOCH // BATCH):
            items = [next(feed) for _ in range(BATCH)]
            optimizer.zero_grad()
            for piece in range(0, BATCH, MICRO):
                part = items[piece:piece + MICRO]
                x = torch.from_numpy(np.stack([np.asarray(i["x"]) for i in part])).to(device)
                numbers = torch.from_numpy(scalars_of(np.stack([np.asarray(i["scalars"])
                                                                 for i in part]))).to(device)
                code = torch.from_numpy(np.stack([np.asarray(i["code"]) for i in part])).to(device)
                mask = torch.from_numpy(np.stack([np.asarray(i["mask"]) for i in part])).to(device)
                value = grow.loss_of(model(x, numbers), code, mask)
                (value * len(part) / BATCH).backward()
                total += float(value.detach()) * len(part)
                seen += len(part)
            optimizer.step()
        thresholds, held_counts = score(model, held, device)
        _, val_counts = score(model, val, device, thresholds)
        held_score = grow.summary_of(held_counts)
        val_score = grow.summary_of(val_counts)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        one = {"epoch": epoch, "train_loss": total / max(seen, 1), "thresholds": thresholds,
               "holdout": held_score, "val": val_score, "seconds": time.time() - started,
               "mean_f1": grow.mean_f1(held_score)}
        history.append(one)
        log(f"{run} е{epoch}: втрата {one['train_loss']:.4f}, пороги {thresholds}, "
            "F1 відкладені " + " ".join(f"{h} {held_score[h]['model']['f1']:.3f}" for h in HEADS)
            + " · val " + " ".join(f"{h} {val_score[h]['model']['f1']:.3f}" for h in HEADS)
            + f", {one['seconds']:.0f} с")
        if best is None or one["mean_f1"] > best["f1"]:
            best, wait = {"epoch": epoch, "f1": one["mean_f1"]}, 0
        else:
            wait += 1
            if wait >= PATIENCE:
                break
    ranked = sorted(history, key=lambda one: -one["mean_f1"])[:BEST]
    top = []
    for one in ranked:
        model.load_state_dict(torch.load(folder / f"epoch_{one['epoch']:02d}.pt",
                                         map_location=device))
        top.append({"epoch": one["epoch"], "held_mean_f1": one["mean_f1"],
                    "thresholds": one["thresholds"], "holdout": one["holdout"],
                    "val": one["val"],
                    "cycle_val": cycle_val(model, device, one["thresholds"])})
        log(f"{run} е{one['epoch']} на циклі val: " + " ".join(
            f"{h} F1 {top[-1]['cycle_val']['all'][h]['model']['f1']:.3f}" for h in HEADS))
    out = {"run": run, "init": init, "best_epoch": ranked[0]["epoch"],
           "best": [one["epoch"] for one in ranked], "thresholds": ranked[0]["thresholds"],
           "top": top,
           "history": [{"epoch": one["epoch"], "train_loss": one["train_loss"],
                        "thresholds": one["thresholds"], "held_mean_f1": one["mean_f1"],
                        "held_f1": {h: one["holdout"][h]["model"]["f1"] for h in HEADS},
                        "val_f1": {h: one["val"][h]["model"]["f1"] for h in HEADS},
                        "seconds": one["seconds"]} for one in history],
           "config": {"n": list(n), "uniform_length": length, "region_days": REGION_DAYS,
                      "per_region": PER_REGION, "workers": WORKERS, "buffer": BUFFER,
                      "epoch": EPOCH, "epochs": EPOCHS, "patience": PATIENCE,
                      "fixed": FIXED, "lr": LR, "batch": BATCH, "micro": MICRO,
                      "seed": SEED, "weights": grow.WEIGHTS}}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / f"{run}.json").write_text(json.dumps(clean(out), ensure_ascii=False, indent=1),
                                         encoding="utf-8")
    log(f"{run}: найкращі епохи {out['best']}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--fixed", action="store_true")
    parser.add_argument("--run")
    parser.add_argument("--init", default="G_tune")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--n", type=int, nargs=2, default=[N_MIN, N_MAX],
                        help="півотів у вікні: від, до")
    parser.add_argument("--length", action="store_true",
                        help="вікна рівномірної довжини (етап 14)")
    args = parser.parse_args()
    if args.fixed:
        build_fixed(n=tuple(args.n), length=args.length)
    if args.run:
        no_swap(MEMORY_NEED, args.force)
        train(args.run, args.init, device_of(args.device), n=tuple(args.n),
              length=args.length)


if __name__ == "__main__":
    main()
