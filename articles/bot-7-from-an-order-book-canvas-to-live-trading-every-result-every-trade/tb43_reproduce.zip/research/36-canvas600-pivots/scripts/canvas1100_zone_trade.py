"""Етап 17: торгівля на val шести монет за сигналом «момент T у зоні півота 2.3 %».

Дослідження: research/36-canvas600-pivots/ → Етап 17

## Хід (без заглядання вперед)

1. **Сигнал** — видача мережі етапу 16 (`Z_base`, найкраща епоха) на
   кожен момент T val кожної монети щогодини: P(T у зоні півота) ≥ порогу прогону
   (з відкладених train) — «півот», інакше «не півот». Вхід мережі в T —
   лише дані до T.
2. **Опорний півот** `R` — останній прийнятий півот (ціна close запису T,
   вершина чи дно). На сигналі з ціною `p`:
   - `R` немає — дивимось на ціну раніше: `p` вище найменшого close від
     початку на `MOVE` і більше — нога була вгору, це вершина; `p` нижче
     найбільшого close на `MOVE` і більше — нога вниз, це дно; інакше —
     хибний півот, ігнор;
   - `R` — дно: `p ≥ R · (1 + MOVE)` — нога вгору пройшла 2.3 %, це
     вершина; `p < R` — нога вниз продовжилась, нове дно (позначка на
     графіку, угода не міняється, `R` = нове дно); інакше — хибний
     півот, ігнор;
   - `R` — вершина: дзеркально.
3. **Угода** — на вершині продаж (коротка), на дні купівля (довга);
   нова вершина чи дно, що змінює бік, закриває попередню угоду і
   відкриває нову в той самий момент. Продовження ноги угоди не міняє —
   угода завжди від точки входу.
4. **Виконання** — ціною open наступного запису 100 с після T
   (`rules/04-trading.md` → Бектест), комісія `FEE` і сліпедж `SLIP` за
   бік; гроші — `Decimal`, старт $1000; остання угода закривається на
   останньому записі val. Порівняння — «купив і тримав» тим самим
   механізмом.

Вихід: results/canvas1100_future/zone_trade_<PAIR>.json — історія ціни
щогодини до першого T, кроки T (ціна, P, сигнал), півоти з роллю, угоди,
крива грошей і метрики.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_zone_trade.py
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100_future as fut  # noqa: E402
import canvas1100_future_net as fnet  # noqa: E402
import canvas1100_grow as grow  # noqa: E402

RUN = "Z_base"
PAIR = "BTC_USDT"
MOVE = 0.023
FEE = Decimal("0.0005")          # taker за бік
SLIP = Decimal("0.0002")         # сліпедж за бік
START = Decimal("1000")


def decide(price: float, ref: dict | None, low: float, high: float, move: float = MOVE) -> str:
    """Роль сигналу: `top`, `bottom` — новий півот зі зміною боку;
    `top_more`, `bottom_more` — нога продовжилась; `false` — ігнор."""
    if ref is None:
        if price >= low * (1 + move):
            return "top"
        if price <= high / (1 + move):
            return "bottom"
        return "false"
    if ref["kind"] == "bottom":
        if price >= ref["price"] * (1 + move):
            return "top"
        return "bottom_more" if price < ref["price"] else "false"
    if price <= ref["price"] / (1 + move):
        return "bottom"
    return "top_more" if price > ref["price"] else "false"


def simulate(t: np.ndarray, price: np.ndarray, prob: np.ndarray, threshold: float,
             exec_t: np.ndarray, exec_price: np.ndarray, last_t: int, last_price: float,
             low: np.ndarray, high: np.ndarray, move: float = MOVE) -> dict:
    """Прохід по моментах T по одному. `exec_*` — запис після T, `low` і
    `high` — найменший і найбільший close від початку до T."""
    cost = FEE + SLIP
    money = START
    ref, side, entry = None, 0, None
    pivots, trades, steps, curve = [], [], [], []
    for k in range(len(t)):
        signal = bool(prob[k] >= threshold)
        role = decide(float(price[k]), ref, float(low[k]), float(high[k]), move) if signal else None
        if role in ("top", "bottom", "top_more", "bottom_more"):
            kind = role.split("_")[0]
            pivots.append({"t": int(t[k]), "price": float(price[k]), "kind": kind,
                           "role": "more" if role.endswith("more") else "new"})
            ref = {"kind": kind, "price": float(price[k])}
        elif role == "false":
            pivots.append({"t": int(t[k]), "price": float(price[k]), "kind": None, "role": "false"})
        if role in ("top", "bottom"):
            fill = Decimal(str(exec_price[k]))
            if side:
                money *= (1 + side * (fill / entry["price"] - 1)) * (1 - cost)
                trades[-1].update({"close_t": int(exec_t[k]), "close_price": float(fill),
                                   "money": float(money)})
            side = -1 if role == "top" else 1
            money *= (1 - cost)
            entry = {"price": fill}
            trades.append({"side": "short" if side < 0 else "long", "open_t": int(exec_t[k]),
                           "open_price": float(fill), "signal_t": int(t[k])})
        now = Decimal(str(price[k]))
        value = money * (1 + side * (now / entry["price"] - 1)) if side else money
        curve.append(float(value))
        steps.append({"t": int(t[k]), "price": float(price[k]), "p": float(prob[k]),
                      "signal": signal, "role": role})
    if side:
        fill = Decimal(str(last_price))
        money *= (1 + side * (fill / entry["price"] - 1)) * (1 - cost)
        trades[-1].update({"close_t": int(last_t), "close_price": float(fill),
                           "money": float(money), "open_end": True})
    return {"steps": steps, "pivots": pivots, "trades": trades, "curve": curve,
            "final": float(money)}


def metrics(got: dict, hold: float) -> dict:
    """PnL, угоди, частка прибуткових, середня угода, найбільша просадка."""
    results = []
    for one in got["trades"]:
        if "close_price" not in one:
            continue
        sign = 1 if one["side"] == "long" else -1
        results.append(sign * (one["close_price"] / one["open_price"] - 1))
    curve = np.asarray(got["curve"])
    peak = np.maximum.accumulate(curve) if len(curve) else curve
    drawdown = float(((peak - curve) / peak).max()) if len(curve) else 0.0
    hourly = np.diff(curve) / curve[:-1] if len(curve) > 1 else np.array([])
    sharpe = (float(hourly.mean() / hourly.std() * np.sqrt(24 * 365))
              if len(hourly) and hourly.std() > 0 else 0.0)
    return {"final": got["final"], "pnl": got["final"] - float(START), "hold": hold,
            "trades": len(results), "win_rate": float(np.mean([r > 0 for r in results])) if results else 0.0,
            "mean_trade": float(np.mean(results)) if results else 0.0,
            "max_drawdown": drawdown, "sharpe": sharpe,
            "signals": int(sum(one["signal"] for one in got["steps"])),
            "pivots": int(sum(one["role"] == "new" for one in got["pivots"])),
            "more": int(sum(one["role"] == "more" for one in got["pivots"])),
            "false": int(sum(one["role"] == "false" for one in got["pivots"]))}


def run(pair: str = PAIR, run_name: str = RUN, log=print) -> dict:
    summary = json.loads((fnet.RESULTS / f"{run_name}.json").read_text(encoding="utf-8"))
    threshold = float(summary["thresholds"]["zone"])
    with np.load(fnet.RESULTS / f"{run_name}_val_pred.npz") as store:
        pred = {key: store[key] for key in store.files}
    with np.load(fut.DATA / "val_meta.npz") as store:
        ends = store["end"][store["pair"] == pair]
    with np.load(grow.SOURCE / f"{pair}_val.npz") as store:
        rec = {key: store[key] for key in ("t", "open", "close")}
    where = pred["pair"] == pair
    t, prob = pred["t"][where], pred["prob"][where, 0]
    first = int(ends[0])
    low = np.array([rec["close"][first:e + 1].min() for e in ends])
    high = np.array([rec["close"][first:e + 1].max() for e in ends])
    nxt = np.minimum(ends + 1, len(rec["t"]) - 1)
    got = simulate(t, rec["close"][ends], prob, threshold, rec["t"][nxt], rec["open"][nxt],
                   int(rec["t"][-1]), float(rec["close"][-1]), low, high)
    cost = FEE + SLIP
    buy = Decimal(str(rec["open"][nxt[0]]))
    hold = float(START * (1 - cost) * (Decimal(str(rec["close"][-1])) / buy) * (1 - cost))
    # історія до першого T щогодини — те, що вже є на канві першого моменту
    marks = np.arange(int(rec["t"][0]) // 3600 * 3600 + 3600, int(t[0]), 3600)
    back = np.searchsorted(rec["t"], marks, side="right") - 1
    history = [{"t": int(m), "price": float(rec["close"][b])} for m, b in zip(marks, back) if b >= 0]
    out = {"pair": pair, "run": run_name, "epoch": summary["best_epoch"], "threshold": threshold,
           "history": history,
           "move": MOVE, "fee": str(FEE), "slip": str(SLIP), "start": str(START),
           "metrics": metrics(got, hold), "zone": pred["labels"][where, 0].astype(int).tolist(),
           **got}
    path = fnet.RESULTS / f"zone_trade_{pair}.json"
    path.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    log(f"{pair}: {out['metrics']}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(grow.PAIRS))
    parser.add_argument("--run", default=RUN)
    args = parser.parse_args()
    for pair in args.pairs:
        run(pair, args.run)


if __name__ == "__main__":
    main()
