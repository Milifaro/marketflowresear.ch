"""Етап 6: записи 100 с, датасет класу, 4 ноги в канві 1100 і UMAP подій.

Дослідження: research/36-canvas600-pivots/ → Етап 6

## Хід

1. **Секунди → записи по 100 с** (`bars30.bars_of_frame(bar=100)`): уся
   train-частина кожної монети (до 2026-08-14), доба за добою
   стандартним читанням; запис — суми 8 колонок `клас210х8` і
   `price_avg` на сітці UTC, кратній 100 с, і кількість секунд `n`.
2. **Датасет класу** `клас210х10-1х7д/д` на записах — той самий хід, що
   стандарт 30 с дослідження 35: середні запису → рівні на обʼєм свого
   запису → перша похідна (лише коли попередній запис впритул, 100 с) →
   сім відношень похідних і `d_price_avg`; нульовий знаменник дає 0.
   `data/canvas1100/<PAIR>_train.npz`.
3. **Півоти** — зігзаг 2.3 % прямо по `open` записів і точка кінця ноги
   (`snap`, екстремум `close` у ±25 записах, `rules/02-markup.md`). Нога
   від запису після півота до наступного півота. Ноги коротші за
   7 годин (`MIN_LEG` = 252 записи) у канву не йдуть.
4. **Корекції 0.8** — `canvas600_data.corrections_of`: усередині кожної
   ноги 2.3 зігзаг 0.8 % по `open` і `snap`; корекція — внутрішній
   півот, далі за 25 записів від обох півотів 2.3. Зони півотів і
   корекцій — як у канві 600: `± 0.05` тривалості й 10 % ціни.
5. **Канва 1100** — кожні 4 ноги підряд (ноги стоять впритул, кожна ≥
   7 годин), крок — одна нога. Вікно — від першого запису першої ноги
   мінус поле до останнього запису четвертої плюс поле, поле = 5 %
   записів чотирьох ніг з кожного боку: 4 ноги лягають на 1000 рядків,
   по 50 рядків — за їхніми межами в тому самому масштабі. 1100
   відрізків на межах записів (≥ 1100 записів) або рівних часових
   відрізків із секунд (менше), клас `клас210х10-1х7д/д`, нормування
   тільки на канву (`bars30.normalize`).
   **Зсунуті канви** (`SHIFTS` = 4 на кожні 4 ноги, seed 36): те саме
   вікно, зсунуте на `δ · L / 4` записів, `δ ~ U[−1, 1]`, `L` — записи
   чотирьох ніг; півоти в них стоять у будь-яких рядках. На них вчиться
   і міряється мережа етапу 7; UMAP — тільки на базових канвах.
6. **Розмітка рядків** — `canvas600_data.label_rows`: `2` — зона півота
   2.3, `1` — зона корекції (не півота), `0` — тіло, `−1` — зона, чий
   півот поза вікном.
7. **Вектор події** — сам рядок канви, куди лягає запис півота чи
   корекції: 7 фіч нормованої канви як є, без пошуку піку, без вікна і
   без порогу сигналу.
8. **Події** — півоти 2.3 і корекції 0.8, що лежать у рядках 49 … 1050
   хоча б однієї канви (півот перед першою ногою — рядок 49); подію, що
   є в кількох канвах, узято з тієї, де вона найближче до середини
   канви; події беруться лише з базових канв. На карту — усі події, до
   `CAP` на клас, seed 36.
9. **UMAP** — 2 компоненти, cosine, euclidean, manhattan,
   `n_neighbors 15`, `min_dist 0.1`, seed 36.

Частина val (`--part val`, 14.08 … 22.09) будується тим самим ходом, без
UMAP — для заміру мережі етапу 7.

Канви на 6 і 8 ніг (`--legs N`, етап 8) — той самий хід: ті самі 1100
рядків, `N` ніг на рядках 50 … 1049, поле 5 % з кожного боку, зсунуті
канви; файли `<part>_L<N>_x.npy`, `<part>_L<N>.npz`, без UMAP.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100.py
    python3 research/36-canvas600-pivots/scripts/canvas1100.py --part val

Вихід: data/canvas1100/<PAIR>_<part>.npz (записи й фічі класу),
legs_<part>.json, <part>_x.npy (канви), <part>.npz (маска, мітки,
власники зон, скаляри); results/canvas1100.json (звід і карти train),
results/canvas1100_val.json (звід val).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
PROJECT = RESEARCH.parents[1]
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(PROJECT / "research" / "35-leg-fullness" / "scripts"))
sys.path.insert(0, str(PROJECT / "rules" / "scripts"))

import bars30  # noqa: E402
import classes30  # noqa: E402
from canvas600_data import corrections_of, label_rows, with_neighbours  # noqa: E402
from data_source import load_day  # noqa: E402
from edges30_data import pivots_of, row_records  # noqa: E402
from zigzag import OUTER_THRESHOLD, SNAP_SPAN, snap, zigzag  # noqa: E402

OUT = RESEARCH / "data" / "canvas1100"
RESULTS = RESEARCH / "results"
BAR = 100                        # секунд у записі
LEGS = 4                         # ніг у канві
ROWS = 1100                      # рядків канви
INNER = 1000                     # рядків під 4 ноги
MARGIN = (ROWS - INNER) / 2 / INNER   # поле з кожного боку, частка ніг
MIN_LEG = 7 * 3600 // BAR        # 7 годин записів
KEY = classes30.DEFAULT          # клас210х10-1х7д/д
CAP = {"pivot": 4000, "corr": 4000}
METRICS = ("cosine", "euclidean", "manhattan")
UMAP_PARAMS = {"n_neighbors": 15, "min_dist": 0.1, "random_state": 36}
SEED = 36
SHIFTS = 4                       # зсунутих канв на кожні 4 ноги


def read_bars(pair: str, root: Path | None = None, bar: int = BAR,
              part: str = "train") -> dict:
    """Записи частини монети по `bar` с."""
    first, last = bars30.part_range(part, pair, root)
    pieces = []
    for path in bars30.day_files(pair, first, last, root):
        frame, _ = load_day(path)
        if len(frame):
            pieces.append(bars30.bars_of_frame(frame, bar))
    return {name: np.concatenate([one[name] for one in pieces],
                                 axis=1 if name == "sums" else 0)
            for name in ("t", "n", "sums", "open", "close", "net", "absm")}


def legs_of(bars: dict, threshold: float = OUTER_THRESHOLD,
            span: int = SNAP_SPAN, bar: int = BAR) -> list:
    """Ноги зігзага по `open` записів з точкою кінця ноги."""
    pivots = snap(zigzag(bars["open"], threshold), bars["close"], span)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        legs.append({"leg": len(legs) + 1,
                     "kind": "up" if pivot.kind == "high" else "down",
                     "first": int(first), "last": int(last),
                     "bars": int(last - first + 1),
                     "hours": float((bars["t"][last] + bar - bars["t"][first]) / 3600),
                     "move": float(np.log(bars["close"][last]
                                          / bars["open"][first]))})
    return legs


def plan(legs: list, size: int, legs_in: int = LEGS,
         min_leg: int = MIN_LEG, shifts: int = 0, rng=None) -> list:
    """Канви: кожні `legs_in` ніг підряд, впритул і не коротші за `min_leg`.
    Повертає (номер першої ноги, вид, початок, кінець вікна в записах):
    `base` — 4 ноги на рядках 50 … 1049; `shift` × `shifts` — те саме
    вікно, зсунуте на `δ · L / legs_in` записів, `δ ~ U[−1, 1]`, `L` —
    записи чотирьох ніг: півоти лягають у будь-які рядки."""
    out = []
    for number in range(len(legs) - legs_in + 1):
        chain = legs[number:number + legs_in]
        if any(leg["bars"] < min_leg for leg in chain):
            continue
        if any(b["first"] != a["last"] + 1 for a, b in zip(chain, chain[1:])):
            continue
        first, last = chain[0]["first"], chain[-1]["last"]
        margin = int(round(MARGIN * (last - first + 1)))
        a, b = first - margin, last + margin
        if a < 0 or b > size - 1:
            continue
        out.append((number, "base", a, b))
        for _ in range(shifts):
            move = int(round(rng.uniform(-1.0, 1.0) * (last - first + 1) / legs_in))
            if a + move >= 0 and b + move <= size - 1:
                out.append((number, "shift", a + move, b + move))
    return out


def canvas_of(holder, stamps: np.ndarray, start: int, end: int,
              rows: int = ROWS, bar: int = BAR) -> dict:
    """Канва вікна `[start, end]`: `rows × 7` нормована, маска, записи рядків."""
    window = stamps[start:end + 1]
    last = int(window[-1]) + bar - 1
    block, fit, step = bars30.canvas_blocks(holder, window, last, rows)
    x, mask = bars30.place(classes30.features(KEY, block), block, rows)
    net = bars30.normalize(x[None], mask[None])[0].astype(np.float32)
    edges, fit = bars30.edges_of(window, last, rows)
    first, last_rec = row_records(window, edges, fit, rows)
    return {"net": net, "mask": mask, "first": first, "last": last_rec,
            "step": float(step)}


def row_of(first: np.ndarray, last: np.ndarray, index: int) -> int:
    """Рядок канви, куди лягає запис `index` (відносно початку вікна)."""
    alive = first >= 0
    hit = np.flatnonzero(alive & (first <= index) & (last >= index))
    if len(hit):
        return int(hit[0])
    rows = np.flatnonzero(alive)
    return int(rows[np.argmin(np.abs(first[rows] - index))])


def suffix_of(legs_in: int) -> str:
    """Файли канв на `legs_in` ніг: 4 — без суфікса, інакше `_L<N>`."""
    return "" if legs_in == LEGS else f"_L{legs_in}"


def build(pairs: list, out: Path = OUT, root: Path | None = None,
          part: str = "train", legs_in: int = LEGS, log=print) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    name = f"{part}{suffix_of(legs_in)}"
    report, legs_all, canvases = {}, {}, []
    rng = np.random.default_rng(SEED)
    for pair in pairs:
        bars = read_bars(pair, root, part=part)
        features = bars30.features_of(bars, KEY, BAR)
        if legs_in == LEGS:
            np.savez(out / f"{pair}_{part}.npz", t=bars["t"], n=bars["n"],
                     open=bars["open"], close=bars["close"], x=features)
        legs = legs_of(bars)
        legs_all[pair] = legs
        pivots = with_neighbours(pivots_of(legs, bars["close"]), len(bars["t"]))
        corrections = corrections_of(legs, bars["open"], bars["close"], pivots)
        windows = plan(legs, len(bars["t"]), legs_in=legs_in, shifts=SHIFTS,
                       rng=rng)
        long = [leg for leg in legs if leg["bars"] >= MIN_LEG]
        report[pair] = {
            "bars": int(len(bars["t"])),
            "gaps": int((np.diff(bars["t"]) != BAR).sum()),
            "no_derivative": float(np.isnan(features).all(axis=1).mean()),
            "legs": len(legs), "legs_7h": len(long),
            "hours_median": float(np.median([leg["hours"] for leg in legs])) if legs else None,
            "pivots": int(len(pivots["index"])),
            "corrections": int(len(corrections["index"])),
            "canvases": sum(kind == "base" for _, kind, _, _ in windows),
            "shifted": sum(kind == "shift" for _, kind, _, _ in windows)}
        log(pair, report[pair])
        cache = {}
        for number, kind, start, end in windows:
            holder = bars30.read_seconds(pair, int(bars["t"][start]),
                                         int(bars["t"][end]) + BAR - 1, cache, root)
            got = canvas_of(holder, bars["t"], start, end)
            marks = label_rows(start, end, got["first"], got["last"],
                               bars["close"], pivots, corrections)
            scalars = np.array([np.log1p(end - start + 1), np.log1p(got["step"]),
                                float(np.log(bars["close"][end] / bars["open"][start])),
                                float(got["mask"].mean())], dtype=np.float32)
            canvases.append({"pair": pair, "leg": number, "kind": kind,
                             "start": start,
                             "end": end, **got, "label": marks["label"],
                             "pivot": marks["pivot"], "corr": marks["corr"],
                             "scalars": scalars, "zones": marks["zones"]})
    if legs_in == LEGS:
        (out / f"legs_{part}.json").write_text(
            json.dumps(legs_all, ensure_ascii=False), encoding="utf-8")
    x = np.stack([one["net"] for one in canvases]) if canvases else \
        np.zeros((0, ROWS, 7), np.float32)
    np.save(out / f"{name}_x.npy", x)
    np.savez(out / f"{name}.npz",
             mask=np.stack([one["mask"] for one in canvases]),
             label=np.stack([one["label"] for one in canvases]),
             pivot=np.stack([one["pivot"] for one in canvases]),
             corr=np.stack([one["corr"] for one in canvases]),
             scalars=np.stack([one["scalars"] for one in canvases]),
             first=np.stack([one["first"] for one in canvases]),
             last=np.stack([one["last"] for one in canvases]),
             pair=np.array([one["pair"] for one in canvases]),
             leg=np.array([one["leg"] for one in canvases]),
             kind=np.array([one["kind"] for one in canvases]),
             start=np.array([one["start"] for one in canvases]),
             end=np.array([one["end"] for one in canvases]),
             step=np.array([one["step"] for one in canvases]))
    return {"report": report, "canvases": canvases, "x": x}


def events_of(canvases: list, x: np.ndarray) -> dict:
    """Півоти 2.3 і корекції 0.8 у рядках 49 … 1050: рядок події і його
    7 фіч; подія з кількох канв — з тієї, де вона найближче до середини."""
    # півот перед першою ногою лягає в рядок 49, після четвертої — у 1049
    lo, hi = (ROWS - INNER) // 2 - 1, (ROWS + INNER) // 2
    middle = (ROWS - 1) / 2
    best = {}
    for number, one in enumerate(canvases):
        if one["kind"] != "base":
            continue
        for zone in one["zones"]:
            kind = "corr" if zone["role"] == "corr" else "pivot"
            row = row_of(one["first"], one["last"], zone["index"] - one["start"])
            if not lo <= row <= hi:
                continue
            key = (one["pair"], zone["index"], kind)
            distance = abs(row - middle)
            if key in best and best[key][0] <= distance:
                continue
            best[key] = (distance, number, row, bool(zone["top"]))
    out = {name: [] for name in ("kind", "pair", "index", "top", "canvas",
                                 "row", "vector")}
    for (pair, index, kind), (_, number, row, top) in sorted(best.items()):
        out["kind"].append(kind)
        out["pair"].append(pair)
        out["index"].append(int(index))
        out["top"].append(top)
        out["canvas"].append(number)
        out["row"].append(row)
        out["vector"].append(np.asarray(x[number, row], dtype=np.float64))
    return {name: np.asarray(value) for name, value in out.items()}


def sample(events: dict, cap: dict = CAP, seed: int = SEED) -> np.ndarray:
    rng = np.random.default_rng(seed)
    chosen = []
    for kind in ("pivot", "corr"):
        where = np.flatnonzero((events["kind"] == kind)
                               & np.isfinite(events["vector"]).all(axis=1))
        if len(where) > cap[kind]:
            where = np.sort(rng.choice(where, cap[kind], replace=False))
        chosen.append(where)
    return np.concatenate(chosen)


def umap_maps(vectors: np.ndarray) -> dict:
    import umap
    return {metric: np.round(umap.UMAP(n_components=2, metric=metric,
                                       **UMAP_PARAMS).fit_transform(vectors),
                             4).tolist()
            for metric in METRICS}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pairs", nargs="+", default=list(bars30.PAIRS))
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--part", choices=("train", "val"), default="train",
                        help="val — тільки канви для заміру мережі, без UMAP")
    parser.add_argument("--legs", type=int, default=LEGS,
                        help="ніг у канві; не 4 — тільки канви для мережі, без UMAP")
    args = parser.parse_args()
    got = build(args.pairs, part=args.part, legs_in=args.legs)
    if args.legs != LEGS:
        (args.results / f"canvas1100_L{args.legs}_{args.part}.json").write_text(
            json.dumps({"report": got["report"], "legs_in": args.legs,
                        "canvases": sum(one["kind"] == "base" for one in got["canvases"])},
                       ensure_ascii=False), encoding="utf-8")
        return
    if args.part == "val":
        (args.results / "canvas1100_val.json").write_text(json.dumps(
            {"report": got["report"],
             "canvases": sum(one["kind"] == "base" for one in got["canvases"])},
            ensure_ascii=False), encoding="utf-8")
        return
    events = events_of(got["canvases"], got["x"])
    chosen = sample(events)
    counts = {kind: {"all": int((events["kind"] == kind).sum()),
                     "shown": int((events["kind"][chosen] == kind).sum())}
              for kind in ("pivot", "corr")}
    print("події", counts)
    steps = [one["step"] for one in got["canvases"] if one["kind"] == "base"]
    out = {"bar": BAR, "legs_in": LEGS, "rows": ROWS, "inner": INNER,
           "min_leg": MIN_LEG, "cap": CAP,
           "params": UMAP_PARAMS, "metrics": list(METRICS),
           "report": got["report"],
           "canvases": sum(one["kind"] == "base" for one in got["canvases"]),
           "step_median": float(np.median(steps)) if steps else None,
           "counts": counts,
           "points": {"kind": events["kind"][chosen].tolist(),
                      "pair": events["pair"][chosen].tolist(),
                      "top": events["top"][chosen].tolist(),
                      "canvas": events["canvas"][chosen].tolist(),
                      "row": events["row"][chosen].tolist(),
                      "maps": umap_maps(events["vector"][chosen].astype(np.float32))}}
    (args.results / "canvas1100.json").write_text(
        json.dumps(out, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
