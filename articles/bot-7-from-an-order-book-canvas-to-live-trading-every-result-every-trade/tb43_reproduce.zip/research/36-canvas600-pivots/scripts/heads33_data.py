"""Етап 9, крок 1: датасет `клас210х14х4ц` до 22.09 для гілки hazard.

Дослідження: research/36-canvas600-pivots/ → Етап 9

Голова «бік ноги» дослідження 33 має видачу лише там, де є всі канали
входу, і гілка hazard (дослідження 20, 32) читає `клас210х14х4ц` із
датасетів `BTC_USDT_29` (без заповнення пропусків) і `<PAIR>_fill`
(пропуски до 60 с заповнюються). Підтверджені датасети скінчуються
29.08 і раніше. Тут той самий хід `rules/scripts` — `build_dataset`
(`клас210х14х4`) → `build_class210x14x5` → `build_class210x14x3` →
`build_class210x14x4c` — з кінцем 22.09 і в окрему папку
`data/datasets_ext/`, підтверджені `data/datasets/` не чіпаються.

Джерелом стає робоча копія `data/`: `copy_to_work` тоді нічого не
копіює, і робоча копія лишається як є.

Запуск:
    python3 research/36-canvas600-pivots/scripts/heads33_data.py
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[3]
RULES = PROJECT / "rules" / "scripts"
sys.path.insert(0, str(RULES))

import build_dataset  # noqa: E402
from data_source import WORK_ROOT  # noqa: E402

EXT = PROJECT / "data" / "datasets_ext"
END = "2026-09-22"
# назва датасету → (монета, заповнення пропусків) — як у підтверджених
SETS = {"BTC_USDT_29": ("BTC_USDT", 0), "ETH_USDT_fill": ("ETH_USDT", 60),
        "SOL_USDT_fill": ("SOL_USDT", 60), "XRP_USDT_fill": ("XRP_USDT", 60),
        "BNB_USDT_fill": ("BNB_USDT", 60), "DOGE_USDT_fill": ("DOGE_USDT", 60)}


def run(script: str, *args: str) -> None:
    done = subprocess.run([sys.executable, str(RULES / script), *args])
    if done.returncode:
        raise SystemExit(f"{script} {args}: впав")


def build(name: str, pair: str, gap: int) -> None:
    folder = EXT / name
    base = folder / "class210x14x4"
    report = build_dataset.build_pair(pair, END, 210, 0, base,
                                      source_root=WORK_ROOT, work_root=WORK_ROOT,
                                      max_gap=gap)
    (base / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False),
                                      encoding="utf-8")
    run("build_class210x14x5.py", "--pair", pair, "--fill-gaps", str(gap),
        "--split", str(base), "--out", str(folder / "class210x14x5"),
        "--data", str(WORK_ROOT))
    run("build_class210x14x3.py", "--pair", pair, "--in", str(folder / "class210x14x5"),
        "--out", str(folder / "class210x14x3"))
    run("build_class210x14x4c.py", "--pair", pair, "--fill-gaps", str(gap),
        "--in", str(folder / "class210x14x3"), "--out", str(folder / "class210x14x4c"),
        "--data", str(WORK_ROOT))


def main() -> None:
    for name, (pair, gap) in SETS.items():
        print(f"=== {name}", flush=True)
        build(name, pair, gap)


if __name__ == "__main__":
    main()
