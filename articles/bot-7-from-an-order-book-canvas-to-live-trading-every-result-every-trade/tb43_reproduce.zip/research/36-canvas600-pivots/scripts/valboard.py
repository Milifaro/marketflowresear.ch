"""Вкладка «Ряд val: кластери, нога і голови»: усі видачі на обраному відрізку.

Дослідження: research/36-canvas600-pivots/ → Вкладка «Ряд val: кластери,
нога і голови»

## Хід

Відрізок val `[first, last]` (секунди UTC) обирається на головному графіку
вкладки. На ньому рахуються:

1. **Кластери 1 і 2 і півоти 2.3** — `canvas600_c1.rule_probe`: канва 600
   з відрізка, правило кластера 1 вікном з 3 рядків (кластер 2 — `1 − p`),
   P(півот 2.3) мережі етапу 2; правда — зони півотів 2.3 і корекцій 0.8.
2. **Повнота ноги** — мережа дослідження 35 (прогін і епоха з
   `/api/seq30`, за замовчуванням `g12-5`) на канві 500 з того самого
   відрізка (`windows30.window_canvas`), вхід 500 × 7 без стовпця маски
   і 4 скаляри, як у `probe30.probe`: вихід 2 — P(рядок уже належить
   наступній нозі) на кожному рядку, вихід 1 — сходинки P(q ≥ c).
   Правда рядка — нога, в якій відрізок починається: рядок, що лежить
   від першої секунди наступної ноги й далі.
3. **Дві голови** — ряд двоголової мережі дослідження 33
   (`results/legs_heads_series_<PAIR>_val.json`), події всередині
   відрізка: P(нога вгору), P(зона розвороту) і ціль зігзага — бік ноги
   і зона. Коли є ряд, дорахований до 22.09 етапом 9
   (`results/heads33/`), береться він.

Запуск (перевірка одного відрізка):
    python3 research/36-canvas600-pivots/scripts/valboard.py BTC_USDT <від> <до>
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
PROJECT = RESEARCH.parents[1]
FULLNESS_SCRIPTS = PROJECT / "research" / "35-leg-fullness" / "scripts"
for extra in (SCRIPTS, FULLNESS_SCRIPTS):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

import canvas600_c1  # noqa: E402
from bars30 import BAR, DATA, edges_of, read_seconds  # noqa: E402

HEADS = PROJECT / "research" / "33-buy-sell-signal" / "results"
# ряд голів, дорахований до 22.09 етапом 9 (`heads33_run.py`) — тим самим
# ходом і на тих самих вагах дослідження 33; немає його — ряд дослідження 33
HEADS_EXT = RESEARCH / "results" / "heads33"
# виняток вкладки /umap600: ноги val рахуються і з дірами в ряді
HEADS_HOLES = RESEARCH / "results" / "heads33_holes"
RUN = "g12-5"                    # мережа повноти, як на /seq30


def span_of(stamps: np.ndarray, first: int, last: int) -> tuple:
    start = int(np.searchsorted(stamps, first, side="left"))
    end = int(np.searchsorted(stamps, last, side="right")) - 1
    return max(start, 0), min(end, len(stamps) - 1)


def fullness(pair: str, first: int, last: int, run: str = RUN,
             data: Path = DATA, root: Path | None = None) -> dict:
    """Мережа повноти ноги на канві 500 з відрізка `[first, last]`."""
    import torch
    import probe30
    from fullness_data30 import row_labels
    from fullness_net30 import scalars_of
    from windows30 import window_canvas
    name, _, epoch = run.partition("-")
    model, config = probe30.model_of(int(epoch or 0), run=name)
    with np.load(data / f"{pair}_val.npz") as store:
        stamps, opens, closes = store["t"], store["open"], store["close"]
    start, end = span_of(stamps, first, last)
    if end - start + 1 < 2:
        raise ValueError("відрізок коротший за 2 записи")
    window = stamps[start:end + 1]
    holder = read_seconds(pair, int(window[0]), int(window[-1]) + BAR - 1,
                          {}, root)
    net, mask, step = window_canvas(holder, window, config["key"])
    legs = json.loads((data / "legs.json").read_text(encoding="utf-8"))[
        "legs"][pair]["val"]
    number = next((k for k, leg in enumerate(legs)
                   if leg["first"] - 1 <= start <= leg["last"]), None)
    next_start = None
    if number is not None and number + 1 < len(legs) \
            and legs[number + 1]["first"] == legs[number]["last"] + 1:
        next_start = int(stamps[legs[number + 1]["first"]])
    rows_true = row_labels(window, next_start) * mask
    scalars = np.array([[np.log1p(len(window)), np.log1p(step),
                         float(np.log(closes[end] / opens[start])),
                         float(mask.mean())]], dtype=np.float32)
    with torch.no_grad():
        ladder, rows = model(torch.from_numpy(net[None]),
                             torch.from_numpy(mask[None].astype(np.float32)),
                             torch.from_numpy(scalars_of(scalars)))
    edges, fit = edges_of(window, int(window[-1]) + BAR - 1)
    row_start = np.zeros(len(mask), dtype=np.int64)
    row_end = np.zeros(len(mask), dtype=np.int64)
    row_start[len(mask) - fit:] = edges[:-1]
    row_end[len(mask) - fit:] = edges[1:]
    return {"run": run, "rows": torch.sigmoid(rows)[0].numpy(),
            "ladder": torch.sigmoid(ladder)[0].numpy(),
            "names": config["names"], "mask": mask, "rows_true": rows_true,
            "row_start": row_start, "row_end": row_end,
            "leg": None if number is None else number + 1}


def heads(pair: str, first: int, last: int, folder: Path | None = None) -> dict:
    """Події ряду двоголової мережі всередині відрізка: продовжений ряд
    етапу 9, коли він є, інакше — ряд дослідження 33."""
    if folder is None:
        folder = HEADS_EXT if (HEADS_EXT / f"legs_heads_series_{pair}_val.json").exists() \
            else HEADS
    path = folder / f"legs_heads_series_{pair}_val.json"
    if not path.exists():
        return {"ready": False}
    got = json.loads(path.read_text(encoding="utf-8"))
    t = np.asarray(got["t"])
    pick = np.flatnonzero((t >= first) & (t <= last))
    out = {"ready": True, "edge": got["edge"], "events": int(len(pick)),
           "covered": [int(got["from"]), int(got["to"])]}
    for key in ("t", "p_side", "p_zone", "want_side", "want_zone"):
        out[key] = [got[key][i] for i in pick]
    return out


def board(pair: str, first: int, last: int, run: str = RUN,
          data: Path = DATA, root: Path | None = None,
          holes: bool = False) -> dict:
    """Усі видачі вкладки на відрізку `[first, last]`; `holes` — ряд голів
    з винятком вкладки /umap600 (ноги val і з дірами), коли він є."""
    folder = HEADS_HOLES if holes and (
        HEADS_HOLES / f"legs_heads_series_{pair}_val.json").exists() else None
    return {"clusters": canvas600_c1.rule_probe(pair, first, last, data=data,
                                                root=root),
            "fullness": fullness(pair, first, last, run, data, root),
            "heads": heads(pair, first, last, folder)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("pair")
    parser.add_argument("first", type=int)
    parser.add_argument("last", type=int)
    args = parser.parse_args()
    got = board(args.pair, args.first, args.last)
    print(f"кластери: {got['clusters']['counts']}")
    f = got["fullness"]
    print(f"повнота: нога {f['leg']}, вихід 2 середнє {f['rows'][f['mask']].mean():.3f}")
    print(f"голови: подій {got['heads'].get('events', 0)}")


if __name__ == "__main__":
    main()
