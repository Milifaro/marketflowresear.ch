"""Етап 10: скільки даних брати у вікно канви 1100 — пошук на val BTC.

Дослідження: research/36-canvas600-pivots/ → Етап 10

## Хід

1. **Ряд** — val BTC (з 14.08) на записах 100 с (`canvas1100_net.val_marks`),
   півоти 2.3 і корекції 0.8 з їхніми зонами — як на вкладці. Вікно
   `[s, e]` цілком у val.
2. **Мапа вікон** — кожне вікно решітки: початок `s` і кінець `e` кратні
   `GRID` записам (72 записи = 2 год) від першого запису val, довжина
   `MIN_LEN … MAX_LEN` записів. На кожному вікні — канва 1100
   (`canvas1100.canvas_of`), три голови прогону етапу 8 `RUN` на його
   найкращій епосі, мітки рядків (`label_rows`). Сигнал голови — пік ≥
   порогу в ±10 рядках (`PEAK`), міра — як в етапах 7–8: точність
   (сигнал у зоні свого класу), повнота (частка зон свого класу у вікні з
   сигналом), F1. Голова 1 — півоти 2.3 (зони півота), голова 2 —
   корекції 0.8 (зони корекції, що не півот). Пороги — `THRESHOLDS`
   кожної голови. Для кожного вікна зберігаються лічильники і які зони
   знайдені.
3. **Обхід** (`walk`) — «ріст правого краю, крок лівого»: початок
   фіксується, правий край росте кроком `right`, поки F1 голови у вікні
   тримається; найкраще вікно цього початку запамʼятовується. Коли F1
   падає нижче найкращого на `drop` і не повертається `patience` кроків
   (або вікно досягло `MAX_LEN`), найкраще вікно записується, лівий край
   зсувається на `left`, правий лишається де був (не коротше за
   `min_len`), і ріст іде далі. `drop = 1` — «співпадіння зникло»: F1
   впав до 0.
4. **Грід** — голова × поріг × `right` × `left` × `min_len` × `drop` ×
   `patience`. На кожну клітинку: скільки найкращих вікон, їхня довжина
   (записи, години, півотів 2.3 у вікні, рядків канви на запис), середній
   F1, точність усіх сигналів найкращих вікон і повнота — частка зон val,
   знайдених хоча б одним найкращим вікном.
5. **Сталі вікна** — контроль: одна довжина на весь val, початок кожні
   `GRID` записів, середній F1 за довжиною і повнота обʼєднання.
6. **Зв'язок довжини з рядом** — найкраща довжина кожного початку (з мапи)
   проти числа півотів 2.3 і корекцій у вікні та годин — чим пояснюється
   оптимум: часом чи кількістю ніг; і F1 усіх вікон мапи за числом
   півотів 2.3 у вікні (`by_pivots`).

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_window.py --map
    python3 research/36-canvas600-pivots/scripts/canvas1100_window.py --grid

Вихід: data/canvas1100_window/<PAIR>_map.npz (мапа вікон);
results/canvas1100_window_<PAIR>.json (грід, сталі вікна, звʼязок довжини).
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_heads as heads  # noqa: E402
import canvas1100_net as net  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_net import peaks, scalars_of  # noqa: E402

RESEARCH = SCRIPTS.parent
DATA = RESEARCH / "data" / "canvas1100_window"
RESULTS = RESEARCH / "results"
PAIR = "BTC_USDT"
RUN = "B_tune"
GRID = 72                        # записів між сусідніми s і e решітки (2 год)
MIN_LEN = 1100                   # записів — не менше рядків канви
MAX_LEN = 16128                  # записів (~18.7 доби)
BATCH = 16
THRESHOLDS = {"pivot": (0.3, 0.4, 0.5, 0.6, 0.7, 0.8),
              "corr": (0.1, 0.15, 0.2, 0.25, 0.3, 0.4)}
RIGHTS = (72, 144, 288)
LEFTS = (72, 144, 288, 576)
MIN_LENS = (1152, 2232, 4392)    # кратні GRID: ~32, 62, 122 год
DROPS = (0.05, 0.1, 0.2, 0.3, 1.0)
PATIENCES = (1, 3)


def windows_of(size: int, grid: int = GRID, min_len: int = MIN_LEN,
               max_len: int = MAX_LEN) -> np.ndarray:
    """Решітка вікон `(s, e)` відносно першого запису val, `e` включно."""
    out = []
    for s in range(0, size - min_len + 1, grid):
        first = s + int(np.ceil(min_len / grid)) * grid - 1
        for e in range(first, min(s + max_len - 1, size - 1) + 1, grid):
            out.append((s, e))
    return np.asarray(out, dtype=np.int64).reshape(-1, 2)


def count(signal: np.ndarray, own: np.ndarray, other: np.ndarray) -> tuple:
    """Сигнали, добрі, сплутані і номери знайдених зон свого класу."""
    good = signal & (own >= 0)
    swapped = signal & (own < 0) & (other >= 0)
    return int(signal.sum()), int(good.sum()), int(swapped.sum()), \
        np.unique(own[good])


def f1_of(signals, good, zones, found) -> np.ndarray:
    """F1 з лічильників (масиви): без сигналів або зон — 0."""
    signals, good = np.asarray(signals, float), np.asarray(good, float)
    zones, found = np.asarray(zones, float), np.asarray(found, float)
    p = np.divide(good, signals, out=np.zeros_like(good), where=signals > 0)
    r = np.divide(found, zones, out=np.zeros_like(found), where=zones > 0)
    return np.divide(2 * p * r, p + r, out=np.zeros_like(p), where=p + r > 0)


def build_map(pair: str = PAIR, run: str = RUN, out: Path = DATA,
              root: Path | None = None, log=print) -> Path:
    import bars30
    from canvas600_data import label_rows
    got = net.val_marks(pair)
    stamps, opens, close = got["t"], got["open"], got["close"]
    first_val = int(np.searchsorted(stamps, got["val_from"]))
    size = len(stamps) - first_val
    grid = windows_of(size)
    tables = {"pivot": got["pivots"], "corr": got["corrections"]}
    # зони val: номер півота / корекції в таблиці ряду
    ids = {name: np.flatnonzero(t["index"] >= first_val) for name, t in tables.items()}
    summary = json.loads((heads.RESULTS / f"{run}.json").read_text(encoding="utf-8"))
    model = Finder3(rows=heads.ROWS, outputs=heads.OUTPUTS)
    model.load_state_dict(torch.load(heads.MODELS / run / f"epoch_{summary['best_epoch']:02d}.pt",
                                     map_location="cpu"))
    model.eval()
    holder = bars30.read_seconds(pair, int(stamps[first_val]),
                                 int(stamps[-1]) + c.BAR - 1, {}, root)
    n = len(grid)
    store = {"s": grid[:, 0], "e": grid[:, 1],
             "rows": np.zeros(n, np.int32), "step": np.zeros(n, np.float32)}
    for name, ths in THRESHOLDS.items():
        for key in ("signals", "good", "swapped"):
            store[f"{name}_{key}"] = np.zeros((n, len(ths)), np.int32)
        store[f"{name}_zones"] = np.zeros(n, np.int32)
        store[f"{name}_hit"] = np.zeros((n, len(ths), len(ids[name])), bool)
    started = time.time()
    batch = []

    def flush():
        if not batch:
            return
        with torch.no_grad():
            logits = model(torch.from_numpy(np.stack([b[1] for b in batch])),
                           torch.from_numpy(np.stack([b[2] for b in batch])))
            prob = torch.sigmoid(logits).numpy()
        for (k, _, _, mask, marks), p in zip(batch, prob):
            for h, name in enumerate(heads.HEADS):
                own = marks[name]
                other = marks["corr" if name == "pivot" else "pivot"]
                if name == "corr":
                    own = np.where(marks["label"] == 1, own, -1)
                zone_ids = marks["zone_ids"][name]
                store[f"{name}_zones"][k] = len(set(own[own >= 0].tolist()))
                for j, th in enumerate(THRESHOLDS[name]):
                    signal = peaks(p[None, :, h], mask[None], th, heads.PEAK)[0]
                    sig, good, swapped, found = count(signal, own, other)
                    store[f"{name}_signals"][k, j] = sig
                    store[f"{name}_good"][k, j] = good
                    store[f"{name}_swapped"][k, j] = swapped
                    hit = zone_ids[found]
                    store[f"{name}_hit"][k, j, hit[hit >= 0]] = True
        batch.clear()

    for k, (s, e) in enumerate(grid):
        start, end = first_val + int(s), first_val + int(e)
        canvas = c.canvas_of(holder, stamps, start, end)
        marks = label_rows(start, end, canvas["first"], canvas["last"], close,
                           got["pivots"], got["corrections"])
        # номер зони вікна → номер зони val
        zone_ids = {}
        for name in heads.HEADS:
            where = {int(v): i for i, v in enumerate(tables[name]["index"][ids[name]])}
            zone_ids[name] = np.asarray([where.get(z["index"], -1) if z["role"] == name
                                         else -1 for z in marks["zones"]] or [-1],
                                        dtype=np.int64)
        marks["zone_ids"] = zone_ids
        scalars = np.array([[np.log1p(end - start + 1), np.log1p(canvas["step"]),
                             float(np.log(close[end] / opens[start])),
                             float(canvas["mask"].mean())]], dtype=np.float32)
        store["rows"][k] = int(canvas["mask"].sum())
        store["step"][k] = canvas["step"]
        batch.append((k, canvas["net"], scalars_of(scalars)[0], canvas["mask"], marks))
        if len(batch) == BATCH:
            flush()
        if k % 2000 == 0:
            log(f"вікно {k} з {n}, {time.time() - started:.0f} с")
    flush()
    for name, t in tables.items():
        store[f"{name}_index"] = t["index"][ids[name]] - first_val
    store["t"] = stamps[first_val:]
    store["close"] = close[first_val:]
    store["meta"] = np.asarray(json.dumps({
        "pair": pair, "run": run, "epoch": summary["best_epoch"], "grid": GRID,
        "min_len": MIN_LEN, "max_len": MAX_LEN, "bar": c.BAR,
        "thresholds": THRESHOLDS, "val_from": int(got["val_from"])}))
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{pair}_map.npz"
    np.savez_compressed(path, **store)
    log(f"мапа: {n} вікон, {time.time() - started:.0f} с → {path}")
    return path


def load_map(path: Path) -> dict:
    with np.load(path) as f:
        out = {k: f[k] for k in f.files}
    out["meta"] = json.loads(str(out["meta"]))
    out["at"] = {(int(s), int(e)): k for k, (s, e) in enumerate(zip(out["s"], out["e"]))}
    return out


def f1_table(m: dict, head: str, j: int) -> np.ndarray:
    return f1_of(m[f"{head}_signals"][:, j], m[f"{head}_good"][:, j],
                 m[f"{head}_zones"], m[f"{head}_hit"][:, j].sum(axis=1))


def walk(m: dict, f1: np.ndarray, right: int, left: int, min_len: int,
         drop: float, patience: int) -> list:
    """Ріст правого краю, крок лівого: номери найкращих вікон мапи.
    Усі кроки кратні `GRID`, тож вікно завжди лежить на решітці мапи."""
    max_len = m["meta"]["max_len"]
    size = len(m["t"])
    at = m["at"]
    chosen = []
    s, e = 0, min_len - 1
    while True:
        e = max(e, s + min_len - 1)
        if e > size - 1:
            break                          # правий край дійшов до кінця ряду
        while e - s + 1 > max_len:
            s += left
        best, best_k, miss = -1.0, None, 0
        while (s, e) in at:
            k = at[(s, e)]
            if f1[k] > best:
                best, best_k, miss = f1[k], k, 0
            elif (f1[k] <= 0 if drop >= 1 else f1[k] < best - drop):
                miss += 1
                if miss >= patience:
                    break
            e += right
        if best_k is not None:
            chosen.append(best_k)
        s += left
    return chosen


def describe(m: dict, head: str, j: int, f1: np.ndarray, chosen: list) -> dict:
    """Звід найкращих вікон клітинки гріду."""
    if not chosen:
        return {"windows": 0}
    k = np.unique(np.asarray(chosen))
    length = m["e"][k] - m["s"][k] + 1
    signals = int(m[f"{head}_signals"][k, j].sum())
    good = int(m[f"{head}_good"][k, j].sum())
    union = m[f"{head}_hit"][k, j].any(axis=0)
    covered = within(m, head, k)
    return {"windows": int(len(k)),
            "f1_mean": float(f1[k].mean()), "f1_median": float(np.median(f1[k])),
            "len_median": float(np.median(length)),
            "len_q25": float(np.quantile(length, 0.25)),
            "len_q75": float(np.quantile(length, 0.75)),
            "hours_median": float(np.median(length) * m["meta"]["bar"] / 3600),
            "pivots_median": float(np.median(inside(m, "pivot", k))),
            "signals": signals, "good": good,
            "precision": good / signals if signals else float("nan"),
            "found": int(union.sum()), "zones": int(covered.sum()),
            "recall": float(union.sum() / covered.sum()) if covered.sum() else float("nan")}


def inside(m: dict, head: str, k: np.ndarray) -> np.ndarray:
    """Скільки подій класу лежить у вікнах `k`."""
    index = m[f"{head}_index"]
    return (np.searchsorted(index, m["e"][k], side="right")
            - np.searchsorted(index, m["s"][k], side="left"))


def within(m: dict, head: str, k: np.ndarray) -> np.ndarray:
    """Зони val, що лежать хоча б в одному з вікон `k`."""
    index = m[f"{head}_index"]
    out = np.zeros(len(index), bool)
    for s, e in zip(m["s"][k], m["e"][k]):
        out |= (index >= s) & (index <= e)
    return out


def fixed(m: dict, head: str, j: int, f1: np.ndarray) -> list:
    """Сталі вікна: кожна довжина решітки на всіх початках."""
    length = m["e"] - m["s"] + 1
    out = []
    for size in np.unique(length):
        k = np.flatnonzero(length == size)
        union = m[f"{head}_hit"][k, j].any(axis=0)
        covered = within(m, head, k)
        signals = int(m[f"{head}_signals"][k, j].sum())
        good = int(m[f"{head}_good"][k, j].sum())
        out.append({"len": int(size), "hours": float(size * m["meta"]["bar"] / 3600),
                    "windows": int(len(k)), "f1_mean": float(f1[k].mean()),
                    "precision": good / signals if signals else float("nan"),
                    "recall": float(union.sum() / covered.sum()) if covered.sum() else float("nan")})
    return out


def best_by_start(m: dict, head: str, j: int, f1: np.ndarray) -> dict:
    """Найкраща довжина кожного початку мапи і що в цьому вікні лежить."""
    rows = []
    for s in np.unique(m["s"]):
        k = np.flatnonzero(m["s"] == s)
        if f1[k].max() <= 0:
            continue
        top = k[f1[k] == f1[k].max()]
        best = top[0]                      # найкоротше з рівних
        rows.append(best)
    k = np.asarray(rows)
    length = (m["e"][k] - m["s"][k] + 1).astype(float)
    pivots = inside(m, "pivot", k).astype(float)
    corr = inside(m, "corr", k).astype(float)

    def r(a, b):
        return float(np.corrcoef(a, b)[0, 1]) if np.std(a) > 0 and np.std(b) > 0 else float("nan")

    return {"starts": int(len(np.unique(m["s"]))), "with_hit": int(len(k)),
            "f1_mean": float(f1[k].mean()),
            "len_median": float(np.median(length)),
            "len_q25": float(np.quantile(length, 0.25)),
            "len_q75": float(np.quantile(length, 0.75)),
            "pivots_median": float(np.median(pivots)),
            "pivots_q25": float(np.quantile(pivots, 0.25)),
            "pivots_q75": float(np.quantile(pivots, 0.75)),
            "corr_median": float(np.median(corr)),
            "r_len_pivots": r(length, pivots), "r_len_corr": r(length, corr),
            "r_f1_len": r(f1[k], length),
            "pivot_hist": {int(v): int((pivots == v).sum()) for v in np.unique(pivots)},
            "s": m["s"][k].tolist(), "e": m["e"][k].tolist(),
            "f1": np.round(f1[k], 4).tolist()}


def by_pivots(m: dict, head: str, j: int, f1: np.ndarray) -> list:
    """F1 вікон за числом півотів 2.3 у вікні — усі довжини разом."""
    pivots = inside(m, "pivot", np.arange(len(m["s"])))
    length = m["e"] - m["s"] + 1
    out = []
    for v in np.unique(pivots):
        k = np.flatnonzero(pivots == v)
        signals = int(m[f"{head}_signals"][k, j].sum())
        good = int(m[f"{head}_good"][k, j].sum())
        out.append({"pivots": int(v), "windows": int(len(k)),
                    "len_median": float(np.median(length[k])),
                    "f1_mean": float(f1[k].mean()),
                    "precision": good / signals if signals else float("nan")})
    return out


def grid_run(path: Path, log=print) -> dict:
    m = load_map(path)
    out = {"meta": m["meta"], "size": int(len(m["t"])),
           "zones_val": {h: int(len(m[f"{h}_index"])) for h in heads.HEADS},
           "grid": [], "fixed": {}, "by_start": {}, "by_pivots": {}}
    for head in heads.HEADS:
        for j, th in enumerate(m["meta"]["thresholds"][head]):
            f1 = f1_table(m, head, j)
            out["fixed"][f"{head}_{th}"] = fixed(m, head, j, f1)
            out["by_start"][f"{head}_{th}"] = best_by_start(m, head, j, f1)
            out["by_pivots"][f"{head}_{th}"] = by_pivots(m, head, j, f1)
            for right, left, min_len, drop, patience in itertools.product(
                    RIGHTS, LEFTS, MIN_LENS, DROPS, PATIENCES):
                chosen = walk(m, f1, right, left, min_len, drop, patience)
                row = {"head": head, "threshold": th, "right": right, "left": left,
                       "min_len": min_len, "drop": drop, "patience": patience}
                row.update(describe(m, head, j, f1, chosen))
                out["grid"].append(row)
            log(f"{head} поріг {th}: готово")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--map", action="store_true", help="порахувати мапу вікон")
    parser.add_argument("--grid", action="store_true", help="грід обходу по мапі")
    args = parser.parse_args()
    path = DATA / f"{args.pair}_map.npz"
    if args.map:
        build_map(args.pair)
    if args.grid:
        out = grid_run(path)
        target = RESULTS / f"canvas1100_window_{args.pair}.json"
        target.write_text(json.dumps(clean(out), ensure_ascii=False), encoding="utf-8")
        print(f"→ {target}")


if __name__ == "__main__":
    main()
