"""Етап 2: мережа на канві 600 — на кожен рядок тіло / корекція / півот 2.3.

Дослідження: research/36-canvas600-pivots/ → Етап 2

## Хід

1. Вікна — `canvas600_data.py`, уточнені мітки — `canvas600_signal.py`
   (`data/canvas600/<part>_refined.npy`): `2` — сигнал півота 2.3,
   `1` — сигнал корекції, `0` — тіло, `−1` — не вчиться (рядки зони поза
   сигналом, зони без сигналу, зони поза вікном). Вхід — канва 600 × 7
   без стовпця маски і 4 скаляри.
2. **Мережа** — трансформер як `Finder` дослідження 35: рядок + 4 скаляри
   → лінійно в ширину 64, вивчена позиція кожного з 600 рядків, 2 шари
   уваги по 4 голови (norm first, ff 128, dropout 0) → 3 логіти на рядок.
3. **Втрата** — крос-ентропія по живих рядках з мітками 0 / 1 / 2 з
   вагами класів `CLASS_WEIGHT` плюс **штраф за плутанину**:
   `λ · (−log(1 − p_півот))` на рядках корекції і
   `λ · (−log(1 − p_корекція))` на рядках півота — корекція, названа
   півотом, і півот, названий корекцією, коштують окремо.
4. **Сигнал** класу — рядок, де імовірність класу ≥ порогу і найбільша
   в ±`PEAK` рядках. Сигнал **добрий**, коли рядок у зоні свого класу
   (зона розмітки, до уточнення). Точність — частка добрих сигналів,
   повнота — частка зон із сигналом уточнювача, у яких є сигнал свого
   класу, F1. **Плутанина** — сигнали півота в зоні корекції (поза
   зоною півота) і сигнали корекції в зоні півота.
5. **Батч** 32 рахується кусками по `MICRO = 8` з накопиченням градієнта,
   передбачення — батчем 16: увага 600 × 600 на 8 ГБ машини інакше йде
   в своп.
6. **Відкладені** — 20 % ніг train (seed 0): за ними поріг кожного класу
   (найкращий F1) і епоха — найкраще середнє F1 двох класів; стоп після
   `PATIENCE` епох без покращення, стеля `EPOCHS`. val — тільки замір,
   по монетах окремо.

7. **Ряд val** (`--outputs`) — найкраща епоха ± 2 на ковзних вікнах
   ряду val (`canvas600_data.py --series`): імовірність запису кожного
   класу — найбільша з рядків усіх вікон, що його накривають; сигнал —
   запис з імовірністю ≥ порогу класу, найбільшою в ±60 записах;
   добрий — запис у зоні свого класу (95 … 105 % тривалості × 10 %
   ціни); повнота — частка півотів (корекцій) ряду, у зоні яких є
   сигнал; сплутано — сигнал у зоні чужого класу.
8. **Канва руками** (`probe`) — відрізок val, обраний на дашборді, тим
   самим ходом у канву 600 і видача обраної епохи на кожному рядку.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas600_net.py
    python3 research/36-canvas600-pivots/scripts/canvas600_net.py --outputs

Вихід: models/canvas600/epoch_NN.pt, history.json;
results/canvas600_val.json, results/val/series_<PAIR>_eNN.npz.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
PROJECT = RESEARCH.parents[1]
for extra in (PROJECT / "research" / "19-leg-end-lstm" / "scripts",
              PROJECT / "research" / "35-leg-fullness" / "scripts", SCRIPTS):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from canvas600_data import OUT as DATA, ROWS  # noqa: E402
from edges30_net import device_of, peaks, scalars_of, split  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

MODELS = RESEARCH / "models" / "canvas600"
RESULTS = RESEARCH / "results"
AROUND = 2                      # епох з кожного боку від найкращої на ряді val
WIDTH, HEADS, LAYERS = 64, 4, 2
LR, BATCH = 1e-3, 32
MICRO = 8                       # батч рахується кусками по 8 з накопиченням
PREDICT = 16                    # батч передбачення: увага 600 × 600 важка
EPOCHS, PATIENCE = 30, 3
CLASS_WEIGHT = (1.0, 3.0, 3.0)      # тіло, корекція, півот 2.3
CONFUSION = 1.0                     # λ штрафу за плутанину
PEAK = 10
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
SEED = 0
MEMORY_NEED = 800               # канва — memmap; мітки й власники ≈ 60 МБ
CLASSES = {1: "corr", 2: "pivot"}


class Finder3(nn.Module):
    """Трансформер на 600 рядках канви: на кожен рядок 3 логіти."""

    def __init__(self, channels: int = 7, scalars: int = 4,
                 width: int = WIDTH, heads: int = HEADS,
                 layers: int = LAYERS, rows: int = ROWS, outputs: int = 3):
        super().__init__()
        self.embed = nn.Linear(channels + scalars, width)
        self.position = nn.Parameter(torch.randn(1, rows, width) * 0.02)
        layer = nn.TransformerEncoderLayer(width, heads, 2 * width,
                                           dropout=0.0, batch_first=True,
                                           norm_first=True)
        self.trunk = nn.TransformerEncoder(layer, layers,
                                           enable_nested_tensor=False)
        self.norm = nn.LayerNorm(width)
        self.head = nn.Linear(width, outputs)

    def forward(self, x: torch.Tensor, numbers: torch.Tensor) -> torch.Tensor:
        joined = torch.cat([x, numbers[:, None, :].expand(-1, x.shape[1], -1)],
                           dim=2)
        h = self.trunk(self.embed(joined) + self.position[:, :x.shape[1]])
        return self.head(self.norm(h))


def loss_of(logits: torch.Tensor, label: torch.Tensor, mask: torch.Tensor,
            weight=CLASS_WEIGHT, confusion: float = CONFUSION) -> torch.Tensor:
    """Зважена крос-ентропія по рядках з мітками 0 / 1 / 2 плюс штраф за
    плутанину корекції з півотом."""
    live = mask & (label >= 0)
    target = label.clamp(min=0).long()
    w = torch.tensor(weight, device=logits.device)[target] * live
    each = F.cross_entropy(logits.permute(0, 2, 1), target, reduction="none")
    prob = logits.softmax(dim=2)
    wrong = torch.where(target == 1, prob[..., 2],
                        torch.where(target == 2, prob[..., 1],
                                    torch.zeros_like(prob[..., 0])))
    swap = -torch.log((1 - wrong).clamp(min=1e-6)) * live * (target > 0)
    total = (each * w).sum() + confusion * (swap * w).sum()
    return total / w.sum().clamp(min=1e-6)


KEEP = ("mask", "pivot", "corr", "scalars", "leg", "pair")


def load(part: str, folder: Path = DATA) -> dict:
    """Лише потрібне навчанню; канва — з диска (memmap), у памʼять іде
    тільки батч."""
    with np.load(folder / f"{part}.npz") as store:
        out = {name: store[name] for name in KEEP}
    out["x"] = np.load(folder / f"{part}_x.npy", mmap_mode="r")
    out["refined"] = np.load(folder / f"{part}_refined.npy")
    out["numbers"] = scalars_of(out["scalars"])
    return out


def predict(model: nn.Module, data: dict, index: np.ndarray,
            device: torch.device, batch: int = PREDICT) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(index), batch):
            pick = index[start:start + batch]
            logits = model(torch.from_numpy(np.asarray(data["x"][pick])).to(device),
                           torch.from_numpy(data["numbers"][pick]).to(device))
            out.append(logits.softmax(dim=2).float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS, 3), np.float32)


def score_class(signal: np.ndarray, value: int, data: dict,
                index: np.ndarray) -> dict:
    """Точність, повнота, F1 і плутанина сигналів одного класу."""
    own = data["corr" if value == 1 else "pivot"][index]
    other = data["pivot" if value == 1 else "corr"][index]
    refined = data["refined"][index]
    signals = int(signal.sum())
    good = int((signal & (own >= 0)).sum())
    swapped = int((signal & (own < 0) & (other >= 0)).sum())
    total = found = 0
    for row_signal, row_own, row_refined in zip(signal, own, refined):
        zones = set(row_own[row_refined == value].tolist())
        total += len(zones)
        found += len(zones & set(row_own[row_signal].tolist()))
    precision = good / signals if signals else float("nan")
    recall = found / total if total else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if signals and total and precision + recall > 0 else 0.0)
    return {"signals": signals, "good": good, "swapped": swapped,
            "zones": total, "found": found, "precision": precision,
            "recall": recall, "f1": f1}


def scores(prob: np.ndarray, data: dict, index: np.ndarray,
           thresholds: dict) -> dict:
    mask = data["mask"][index]
    return {name: score_class(peaks(prob[..., value], mask,
                                    thresholds[name], PEAK),
                              value, data, index)
            for value, name in CLASSES.items()}


def best_thresholds(prob: np.ndarray, data: dict, index: np.ndarray) -> dict:
    out = {}
    mask = data["mask"][index]
    for value, name in CLASSES.items():
        best = max(THRESHOLDS, key=lambda t: score_class(
            peaks(prob[..., value], mask, t, PEAK), value, data, index)["f1"])
        out[name] = float(best)
    return out


def by_pair(prob: np.ndarray, data: dict, thresholds: dict) -> dict:
    index = np.arange(len(data["leg"]))
    out = {"all": scores(prob, data, index, thresholds)}
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        out[str(pair)] = scores(prob[where], data, where, thresholds)
    return out


def clean(value):
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, dict):
        return {key: clean(one) for key, one in value.items()}
    if isinstance(value, list):
        return [clean(one) for one in value]
    return value


def write_history(folder: Path, history: list, best: dict) -> None:
    (folder / "history.json").write_text(json.dumps(clean({
        "config": {"width": WIDTH, "heads": HEADS, "layers": LAYERS,
                   "lr": LR, "batch": BATCH, "micro": MICRO,
                   "class_weight": list(CLASS_WEIGHT),
                   "confusion": CONFUSION, "peak": PEAK,
                   "patience": PATIENCE, "epochs": EPOCHS, "seed": SEED},
        "best_epoch": best["epoch"], "history": history}),
        ensure_ascii=False, indent=1), encoding="utf-8")


def train(train_part: dict, val: dict, device: torch.device, log=print,
          epochs: int = EPOCHS, patience: int = PATIENCE,
          folder: Path = MODELS) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    inside, held = split(train_part["leg"])
    folder.mkdir(parents=True, exist_ok=True)
    model = Finder3().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    history, best = [], None
    val_index = np.arange(len(val["leg"]))
    for epoch in range(1, epochs + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for start in range(0, len(order), BATCH):
            pick = np.sort(order[start:start + BATCH])
            optimizer.zero_grad()
            for piece in range(0, len(pick), MICRO):
                part = pick[piece:piece + MICRO]
                loss = loss_of(
                    model(torch.from_numpy(np.asarray(train_part["x"][part])).to(device),
                          torch.from_numpy(train_part["numbers"][part]).to(device)),
                    torch.from_numpy(train_part["refined"][part]).to(device),
                    torch.from_numpy(train_part["mask"][part]).to(device))
                (loss * len(part) / len(pick)).backward()
                total += float(loss.detach()) * len(part)
                count += len(part)
            optimizer.step()
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        held_prob = predict(model, train_part, held, device)
        thresholds = best_thresholds(held_prob, train_part, held)
        held_score = scores(held_prob, train_part, held, thresholds)
        val_prob = predict(model, val, val_index, device)
        val_score = by_pair(val_prob, val, thresholds)
        mean_f1 = float(np.mean([held_score[n]["f1"] for n in CLASSES.values()]))
        step = {"epoch": epoch, "train_loss": total / count,
                "thresholds": thresholds, "holdout": held_score,
                "holdout_f1": mean_f1, "val": val_score,
                "seconds": round(time.time() - started, 1)}
        history.append(step)
        v = val_score["all"]
        log(f"епоха {epoch:2d}: втрата {step['train_loss']:.4f} · відкладені "
            f"F1 півот {held_score['pivot']['f1']:.3f}, корекція "
            f"{held_score['corr']['f1']:.3f} · val півот P "
            f"{v['pivot']['precision']:.3f} R {v['pivot']['recall']:.3f}, "
            f"корекція P {v['corr']['precision']:.3f} R "
            f"{v['corr']['recall']:.3f} · {step['seconds']} c")
        if best is None or mean_f1 > best["holdout_f1"]:
            best = step
        write_history(folder, history, best)
        if epoch - best["epoch"] >= patience:
            log(f"{patience} епохи без покращення — стоп, найкраща "
                f"{best['epoch']}")
            break
    return {"history": history, "best": best}


def model_of(epoch: int, device: torch.device,
             folder: Path = MODELS) -> Finder3:
    model = Finder3().to(device)
    model.load_state_dict(torch.load(folder / f"epoch_{epoch:02d}.pt",
                                     map_location=device))
    model.eval()
    return model


def series_curve(prob: np.ndarray, series: dict, pick: np.ndarray,
                 size: int) -> np.ndarray:
    """Імовірність запису ряду — найбільша з рядків усіх вікон, що його
    накривають; `prob` — `(вікна, рядки)`."""
    curve = np.full(size, np.nan)
    for one in pick:
        start = series["start"][one]
        for row in np.flatnonzero(series["first"][one] >= 0):
            a = start + series["first"][one][row]
            b = start + series["last"][one][row]
            value = prob[one][row]
            current = curve[a:b + 1]
            curve[a:b + 1] = np.where(np.isnan(current) | (current < value),
                                      value, current)
    return curve


def series_score(signals: np.ndarray, own: np.ndarray, other: np.ndarray,
                 total: int) -> dict:
    """Міри сигналів ряду: власник зони свого класу і чужого по записах."""
    hit = own[signals]
    good = int((hit >= 0).sum())
    found = len(set(hit[hit >= 0].tolist()))
    swapped = int(((hit < 0) & (other[signals] >= 0)).sum())
    precision = good / len(signals) if len(signals) else float("nan")
    recall = found / total if total else float("nan")
    return {"signals": int(len(signals)), "good": good, "swapped": swapped,
            "zones": int(total), "found": found, "precision": precision,
            "recall": recall,
            "f1": (2 * precision * recall / (precision + recall)
                   if len(signals) and precision + recall > 0 else 0.0)}


def outputs(device: torch.device, log=print, folder: Path = MODELS,
            data_dir: Path = DATA, results: Path = RESULTS) -> None:
    """Видача найкращої епохи ± 2 на ряді val: імовірність запису кожного
    класу, сигнали, міри по монетах."""
    import canvas600_data as d
    from bars30 import DATA as BARS
    from edges30_net import record_zones, series_signals
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    best = history["best_epoch"]
    steps = {one["epoch"]: one for one in history["history"]}
    epochs = [e for e in steps if abs(e - best) <= AROUND]
    series = {name: value for name, value in
              np.load(data_dir / "series.npz").items()}
    series["x"] = np.load(data_dir / "series_x.npy", mmap_mode="r")
    series["numbers"] = scalars_of(series["scalars"])
    table = json.loads((BARS / "legs.json").read_text(encoding="utf-8"))
    out = results / "val"
    out.mkdir(parents=True, exist_ok=True)
    report = {"best_epoch": best, "epochs": epochs, "val": {}}
    marks = {}
    for pair in np.unique(series["pair"]):
        pair = str(pair)
        with np.load(BARS / f"{pair}_val.npz") as store:
            opens, close = store["open"], store["close"]
        legs = table["legs"][pair]["val"]
        pivots = d.with_neighbours(d.pivots_of(legs, close), len(close))
        corrections = d.corrections_of(legs, opens, close, pivots)
        marks[pair] = {"pivot": pivots, "corr": corrections,
                       "zones": {"pivot": record_zones(close, pivots),
                                 "corr": record_zones(close, corrections)},
                       "size": len(close)}
    for epoch in epochs:
        model = model_of(epoch, device, folder)
        thresholds = steps[epoch]["thresholds"]
        prob = predict(model, series, np.arange(len(series["pair"])), device)
        one = {"thresholds": thresholds, "windows": steps[epoch]["val"],
               "series": {}}
        for pair, mark in marks.items():
            pick = np.flatnonzero(series["pair"] == pair)
            curves, signals, scores_ = {}, {}, {}
            for value, name in CLASSES.items():
                curves[name] = series_curve(prob[..., value], series, pick,
                                            mark["size"])
                signals[name] = series_signals(curves[name], thresholds[name])
                other = "pivot" if name == "corr" else "corr"
                scores_[name] = series_score(signals[name],
                                             mark["zones"][name],
                                             mark["zones"][other],
                                             len(mark[name]["index"]))
            one["series"][pair] = scores_
            np.savez_compressed(
                out / f"series_{pair}_e{epoch:02d}.npz",
                prob_pivot=curves["pivot"].astype(np.float16),
                prob_corr=curves["corr"].astype(np.float16),
                sig_pivot=signals["pivot"], sig_corr=signals["corr"],
                good_pivot=mark["zones"]["pivot"][signals["pivot"]] >= 0,
                good_corr=mark["zones"]["corr"][signals["corr"]] >= 0,
                pivots=mark["pivot"]["index"], top=mark["pivot"]["top"],
                zone=mark["pivot"]["zone"], span=mark["pivot"]["span"],
                corr=mark["corr"]["index"], corr_top=mark["corr"]["top"],
                corr_zone=mark["corr"]["zone"], corr_span=mark["corr"]["span"],
                threshold_pivot=np.float32(thresholds["pivot"]),
                threshold_corr=np.float32(thresholds["corr"]))
        report["val"][str(epoch)] = one
        log(f"епоха {epoch}: ряд val готовий")
    (results / "canvas600_val.json").write_text(
        json.dumps(clean(report), ensure_ascii=False, indent=1),
        encoding="utf-8")


def probe(pair: str, first: int, last: int, epoch: int,
          data: Path | None = None, folder: Path = MODELS,
          root: Path | None = None) -> dict:
    """Канва 600 з відрізка val `[first, last]` (секунди UTC), обраного
    руками, і видача мережі епохи `epoch`: імовірність півота й корекції
    на кожному рядку, сигнали; правда — зони півотів і корекцій у канві."""
    import canvas600_data as d
    from bars30 import BAR, DATA as BARS, read_seconds
    data = data or BARS
    with np.load(data / f"{pair}_val.npz") as store:
        stamps, opens, close = store["t"], store["open"], store["close"]
    start = int(np.searchsorted(stamps, first, side="left"))
    end = int(np.searchsorted(stamps, last, side="right")) - 1
    start, end = max(start, 0), min(end, len(stamps) - 1)
    if end - start + 1 < ROWS:
        raise ValueError(f"відрізок коротший за {ROWS} записів (5 год)")
    legs = json.loads((data / "legs.json").read_text(encoding="utf-8"))[
        "legs"][pair]["val"]
    pivots = d.with_neighbours(d.pivots_of(legs, close), len(close))
    corrections = d.corrections_of(legs, opens, close, pivots)
    holder = read_seconds(pair, int(stamps[start]),
                          int(stamps[end]) + BAR - 1, {}, root)
    got = d.canvas_of(holder, stamps, opens, close, start, end)
    marks = d.label_rows(start, end, got["first"], got["last"], close,
                         pivots, corrections)
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    thresholds = next(one["thresholds"] for one in history["history"]
                      if one["epoch"] == epoch)
    device = torch.device("cpu")
    data_one = {"x": got["net"][None], "numbers": scalars_of(got["scalars"][None])}
    prob = predict(model_of(epoch, device, folder), data_one, np.array([0]),
                   device)[0]
    live = got["first"] >= 0
    out = {"pair": pair, "epoch": epoch, "thresholds": thresholds,
           "start": start, "end": end, "t": stamps[start:end + 1],
           "close": close[start:end + 1], "live": live,
           "row_start": np.where(live, stamps[start + np.maximum(got["first"], 0)], 0),
           "row_end": np.where(live, stamps[start + np.maximum(got["last"], 0)] + BAR, 0),
           "label": marks["label"]}
    for value, name in CLASSES.items():
        signal = peaks(prob[None, :, value], got["mask"][None],
                       thresholds[name], PEAK)[0]
        out[f"prob_{name}"] = prob[:, value]
        out[f"signal_{name}"] = np.flatnonzero(signal)
        out[f"good_{name}"] = marks["label"][signal] == value
        table = pivots if name == "pivot" else corrections
        inside = (table["index"] >= start) & (table["index"] <= end)
        out[f"{name}_index"] = table["index"][inside] - start
        out[f"{name}_top"] = table["top"][inside]
        out[f"{name}_zone"] = table["zone"][inside]
        out[f"{name}_span"] = table["span"][inside]
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--outputs", action="store_true",
                        help="ряд val на найкращій епосі ± 2")
    args = parser.parse_args()
    no_swap(MEMORY_NEED, args.force)
    device = device_of(args.device)
    if args.outputs:
        outputs(device)
        return
    print(f"пристрій: {device}")
    got = train(load("train"), load("val"), device)
    print(f"найкраща епоха {got['best']['epoch']}")


if __name__ == "__main__":
    main()
