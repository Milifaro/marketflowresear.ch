"""Етап 8, торгівля: голова боку в живому часі на val, завжди в ринку.

Дослідження: research/36-canvas600-pivots/ → Етап 8

## Хід

1. **Ряд** — val кожної монети, записи 100 с (`canvas1100_net.val_marks`:
   хвіст train — не менше 3 півотів 2.3 і не коротший за вікно канви — і
   весь val). Торгівля — тільки на val (з 14.08): перше рішення — на
   першому записі val.
2. **Живий час** — кожні `STEP` записів (30 хв) канва 1100 будується з
   вікна, що **закінчується на поточному записі**: `WIDTH` записів до
   нього (медіана вікна канви train). Даних після поточного запису канва
   не бачить. Хід той самий, що в навчанні (`canvas1100.canvas_of`).
3. **Рішення** — середнє `P(купити)` голови боку на останніх `LAST`
   живих рядках канви: ≥ 0.5 — довга позиція, < 0.5 — коротка. Позиція
   завжди в ринку; перевертання — коли рішення змінилось.
4. **Виконання** — ціною `open` наступного запису після рішення
   (`rules/04-trading.md` → Бектест). Гроші — `Decimal`, старт $1000,
   весь капітал у позиції. Витрати — комісія taker 0.05 % + сліпедж
   0.02 % **за бік**; перевертання — два боки (закрити і відкрити).
5. **Проти**: «купив і тримав» з тими самими витратами на вхід і вихід;
   випадкові перевертання — стільки ж перевертань у випадкові моменти
   рішень, 20 прогонів (seed 36), медіана і найкращий.
6. **Півоти** — частка перевертань, що стоять у зоні півота 2.3, і частка
   півотів val, біля яких є перевертання в правильний бік.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_trade.py --run <прогін етапу 8>

Вихід: results/canvas1100_trade_<прогін>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_heads as heads  # noqa: E402
import canvas1100_net as net  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_net import scalars_of  # noqa: E402

STEP = 18                        # записів між рішеннями (30 хв)
WIDTH = 4430                     # записів у вікні канви (медіана train)
LAST = 3                         # останніх живих рядків для рішення
FEE = Decimal("0.0005")          # taker за бік
SLIP = Decimal("0.0002")         # сліпедж за бік
START = Decimal("1000")
RANDOMS = 20
SEED = 36
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT", "DOGE_USDT")


def decisions(pair: str, model, device, step: int = STEP, width: int = WIDTH,
              last: int = LAST, root: Path | None = None) -> dict:
    """Рішення голови боку в живому часі: запис рішення, P(купити)."""
    import bars30
    got = net.val_marks(pair, min_tail=width)
    stamps, opens, close = got["t"], got["open"], got["close"]
    first_val = int(np.searchsorted(stamps, got["val_from"]))
    moments = np.arange(max(first_val, width - 1), len(stamps) - 1, step)
    holder = bars30.read_seconds(pair, int(stamps[moments[0] - width + 1]),
                                 int(stamps[-1]) + c.BAR - 1, {}, root)
    probs = []
    batch_x, batch_n = [], []

    def flush():
        if not batch_x:
            return
        with torch.no_grad():
            logits = model(torch.from_numpy(np.stack(batch_x)).to(device),
                           torch.from_numpy(np.stack(batch_n)).to(device))
            p = torch.sigmoid(logits[..., 2]).cpu().numpy()
        for row, (mask_one) in zip(p, batch_mask):
            rows = np.flatnonzero(mask_one)[-last:]
            probs.append(float(row[rows].mean()) if len(rows) else 0.5)
        batch_x.clear()
        batch_n.clear()
        batch_mask.clear()

    batch_mask = []
    for now in moments:
        start = now - width + 1
        canvas = c.canvas_of(holder, stamps, start, now)
        scalars = np.array([[np.log1p(now - start + 1), np.log1p(canvas["step"]),
                             float(np.log(close[now] / opens[start])),
                             float(canvas["mask"].mean())]], dtype=np.float32)
        batch_x.append(canvas["net"])
        batch_n.append(scalars_of(scalars)[0])
        batch_mask.append(canvas["mask"])
        if len(batch_x) == 8:
            flush()
    flush()
    return {"moments": moments, "prob": np.asarray(probs), "marks": got}


def simulate(sides: np.ndarray, moments: np.ndarray, opens: np.ndarray,
             close_last: float) -> dict:
    """Завжди в ринку: позиція `sides[k]` (+1 / −1) з запису `moments[k] + 1`
    до наступного перевертання; у кінці позиція закривається."""
    cost = FEE + SLIP
    money = START
    position, entry = 0, None
    trades = 0
    curve = []
    for k, side in enumerate(sides):
        price = Decimal(str(opens[moments[k] + 1]))
        if side != position:
            if position != 0:
                money *= (Decimal(1) + position * (price / entry - 1)) * (1 - cost)
            money *= (1 - cost)
            position, entry = int(side), price
            trades += 1
        curve.append(float(money * (Decimal(1) + position * (price / entry - 1))))
    final = Decimal(str(close_last))
    money *= (Decimal(1) + position * (final / entry - 1)) * (1 - cost)
    return {"final": float(money), "flips": trades - 1, "curve": curve}


def hold(opens: np.ndarray, first: int, close_last: float) -> float:
    cost = FEE + SLIP
    price = Decimal(str(opens[first]))
    return float(START * (1 - cost) * (Decimal(str(close_last)) / price) * (1 - cost))


def pivot_hits(sides: np.ndarray, moments: np.ndarray, marks: dict) -> dict:
    """Перевертання в зоні півота 2.3 і півоти val з перевертанням у
    правильний бік (після дна — купити) у межах зони."""
    pivots = marks["pivots"]
    flips = np.flatnonzero(np.diff(sides) != 0) + 1
    at = moments[flips] + 1
    to_buy = sides[flips] > 0
    first_val = int(np.searchsorted(marks["t"], marks["val_from"]))
    inside = (pivots["index"] >= first_val) & (pivots["index"] <= moments[-1])
    good = 0
    hit_pivots = set()
    for record, buy in zip(at, to_buy):
        near = np.flatnonzero(np.abs(pivots["index"] - record) <= pivots["span"])
        ok = [p for p in near if buy == (not pivots["top"][p])]
        if ok:
            good += 1
            hit_pivots.update(ok)
    total = int(inside.sum())
    found = len([p for p in hit_pivots if inside[p]])
    return {"flips": int(len(at)), "good": good, "pivots": total, "found": found,
            "precision": good / len(at) if len(at) else float("nan"),
            "recall": found / total if total else float("nan")}


def run(name: str, device=torch.device("cpu"), log=print) -> dict:
    summary = json.loads((heads.RESULTS / f"{name}.json").read_text(encoding="utf-8"))
    model = Finder3(rows=heads.ROWS, outputs=heads.OUTPUTS)
    model.load_state_dict(torch.load(heads.MODELS / name / f"epoch_{summary['best_epoch']:02d}.pt",
                                     map_location=device))
    model.eval()
    out = {"run": name, "epoch": summary["best_epoch"], "step": STEP, "width": WIDTH,
           "last": LAST, "fee": str(FEE), "slip": str(SLIP), "pairs": {}}
    rng = np.random.default_rng(SEED)
    for pair in PAIRS:
        got = decisions(pair, model, device)
        marks = got["marks"]
        sides = np.where(got["prob"] >= 0.5, 1, -1)
        opens = marks["open"]
        last_close = float(marks["close"][-1])
        mine = simulate(sides, got["moments"], opens, last_close)
        flips = max(mine["flips"], 0)
        randoms = []
        for _ in range(RANDOMS):
            fake = np.empty(len(sides), dtype=int)
            cuts = np.sort(rng.choice(np.arange(1, len(sides)), min(flips, len(sides) - 1),
                                      replace=False))
            side = int(rng.choice([-1, 1]))
            prev = 0
            for cut in list(cuts) + [len(sides)]:
                fake[prev:cut] = side
                side, prev = -side, cut
            randoms.append(simulate(fake, got["moments"], opens, last_close)["final"])
        out["pairs"][pair] = {
            "decisions": int(len(sides)), "flips": flips,
            "final": mine["final"],
            "hold": hold(opens, int(got["moments"][0]) + 1, last_close),
            "random_median": float(np.median(randoms)),
            "random_best": float(np.max(randoms)),
            "pivots": pivot_hits(sides, got["moments"], marks),
            "t": [int(v) for v in marks["t"][got["moments"]]],
            "prob": np.round(got["prob"], 4).tolist(),
            "curve": np.round(mine["curve"], 2).tolist()}
        one = out["pairs"][pair]
        log(f"{pair}: рішень {one['decisions']}, перевертань {flips}, ${one['final']:.2f} "
            f"проти холду ${one['hold']:.2f} і випадкових ${one['random_median']:.2f} "
            f"(найкращий ${one['random_best']:.2f}); у зоні півота {one['pivots']['good']} "
            f"з {one['pivots']['flips']}, півотів з перевертанням {one['pivots']['found']} "
            f"з {one['pivots']['pivots']}")
    path = heads.RESULTS.parent / f"canvas1100_trade_{name}.json"
    path.write_text(json.dumps(clean(out), ensure_ascii=False), encoding="utf-8")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run(args.run)


if __name__ == "__main__":
    main()
