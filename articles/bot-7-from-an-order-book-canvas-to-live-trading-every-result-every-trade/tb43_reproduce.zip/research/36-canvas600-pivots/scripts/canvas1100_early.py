"""Етап 18: півот 2.3 раніше за зігзаг — одна голова на канві 1100 × 9, що закінчується в T.

Дослідження: research/36-canvas600-pivots/ → Етап 18

## Хід

1. **Ряд монети** — записи 100 с train і val етапу 6 підряд
   (`data/canvas1100/<PAIR>_{train,val}.npz`); ноги зігзага 2.3
   (`canvas1100.legs_of`), півоти, зони й корекції 0.8 — по всьому ряду
   (`series_of`). Мітки беруться з готового зігзага, вхід — лише дані до T.
2. **Момент T** — кінець запису на сітці 10 хв (`STEP_T`). Вікно
   `[T − L, T]`, `L` — з гріду `LENGTHS` (40 … 300 год кроком 10). Канва
   1100 закінчується на T: даних після T вона не бачить.
3. **Вхід 1100 × 9**:
   - 1–7 — `клас210х10-1х7д/д` канви (`canvas1100.canvas_of`), нормування
     лише на канву;
   - 8 — P(кластер 2) = 1 − p правила кластера 1 на канві 600 того самого
     вікна (записи 30 с), рядок бере рядок канви 600, що закінчився не
     пізніше його кінця (`cluster2_rows`);
   - 9 — голова «бік ноги» **сира, без ема і без затримки в годину**, з
     живого ряду `results/heads33_live/` (`heads33_run.py --live`): рядок
     бере останню подію, чия видача готова не пізніше кінця рядка —
     `t_start + SIDE_READY` (подія 210 с + пів події, на яку `nearest`
     дослідження 33 може зсунути видачу сусідньої мережі).
   Мертві рядки — нулі; стовпця маски немає.
4. **Мітка рядка** (`codes_of`) — `canvas600_data.label_rows`: зона півота
   2.3 — `POS`, **підтверджений він до T чи ні**; зона корекції 0.8 —
   `CORR`; тіло — `NEG`; зона півота за межею вікна і мертвий рядок —
   `IGNORE`. Зона з'являється в канві, коли сам півот (запис екстремуму)
   зайшов у вікно справа.
5. **Штраф за пізнє виявлення** — вага рядка `POS` росте з віком півота в
   канві: `1 + SLOPE · min(вік, CAP_H)`, вік — години від запису півота до
   T. Щойно зайшов — пропуск коштує 1, через `CAP_H` год — `1 + SLOPE ·
   CAP_H`. `CORR` — вага `CORR_WEIGHT`, `NEG` — 1.
6. **Втрата** — BCE: середнє на `POS` плюс середнє на решті живих рядків
   (з вагами) плюс `1 − soft dice` (`loss_of`), як в етапі 11.
7. **Мережа** — `Finder3` на 9 каналів і 1 вихід зі старту `RL_tune` е19
   (етап 14): стовпці двох нових каналів у першому шарі — нулі (на старті
   мережа видає те саме, що `RL_tune`), вихід — середнє виходів вершини й
   дна (`start_model`).
8. **Розбиття** — різ монети етапу 11 (півот ⌊0.8 · півотів train⌋):
   навчання — T не пізніше різу мінус `AHEAD` (40 год: мітки біля T
   встигли стати відомими); відкладені — вікна, що цілком після різу, T до
   14.08; val — T від `VAL_FROM` (15.08 00:00 UTC: мережа hazard під
   головою «бік ноги» вчилась до 14.08 15:27, і її мітки дивляться вперед
   на ~100 подій) до кінця ряду мінус `AHEAD`. Вікно val може заходити в
   train — це лише вхід.
9. **Подача** — як в етапі 12: `WORKERS` процесів беруть випадковий шматок
   `REGION_DAYS` діб train, читають секунди раз і ріжуть `PER_REGION`
   випадкових пар (T, L); буфер перемішування `BUFFER`.
10. **Міра** (`measure`) на сітці T:
    - сигнал — пік ≥ порогу в ±`PEAK` рядках канви T;
    - **свіжий** сигнал — на рядку, що закінчився за останню годину перед T
      (`FRESH`); точність — частка свіжих сигналів у зоні півота;
    - півот **виявлено** в T, коли в канві T є сигнал на рядку його зони;
      затримка — від запису півота до першого такого T;
    - **зігзаг підтверджує** півот першим записом, де `close` відійшов від
      нього на 2.3 %; повнота — частка півотів, виявлених **не пізніше**
      за зігзаг; F1 — з точності й цієї повноти;
    - випередження — години й відсотки ціни між виявленням і зігзагом.
    Поріг і епоха — за F1 на відкладених.
11. **Контролі**: `RL_tune` е19 без довчання (P = більша з вершини й дна,
    свій поріг на відкладених) і випадкові сигнали — стільки ж свіжих
    сигналів на випадкових свіжих живих рядках кожного T (seed 18).
12. **Найкраще вікно** — грід `LENGTHS` на відкладених (T щогодини): на
    кожному вікні і мережа, і контроль беруть свій поріг з найбільшим F1
    на відкладених; `L` з найбільшим F1 мережі; val — усі `L` щогодини з
    порогами свого вікна і найкраще `L` кожні 10 хв; ряд найкращого `L` на
    val — для вкладки (`save_series`).

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_early.py --held
    python3 research/36-canvas600-pivots/scripts/canvas1100_early.py --run E_tune
    python3 research/36-canvas600-pivots/scripts/canvas1100_early.py --grid E_tune
    python3 research/36-canvas600-pivots/scripts/canvas1100_early.py --series E_tune

Вихід: data/canvas1100_early/held_*.npy (сталі канви відкладених для вибору
епохи); models/canvas1100_early/<прогін>/epoch_NN.pt;
results/canvas1100_early/<прогін>.json, <прогін>_grid.json,
<прогін>_val_<PAIR>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_future as fut  # noqa: E402
import canvas1100_grow as grow  # noqa: E402
import canvas1100_random as rnd  # noqa: E402
from canvas600_data import corrections_of, label_rows, with_neighbours  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_data import pivots_of  # noqa: E402
from edges30_net import device_of, peaks, scalars_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402
from zigzag import OUTER_THRESHOLD  # noqa: E402

DATA = RESEARCH / "data" / "canvas1100_early"
MODELS = RESEARCH / "models" / "canvas1100_early"
RESULTS = RESEARCH / "results" / "canvas1100_early"
SIDE = RESEARCH / "results" / "heads33_live"
PAIRS = grow.PAIRS
ROWS = c.ROWS
BAR = c.BAR
CHANNELS = ("class",) * 7 + ("cluster2", "side")
STEP_T = 600                     # крок T, секунд
LENGTHS = tuple(range(40, 301, 10))   # довжина вікна, годин
VAL_FROM = 1786752000            # 2026-08-15 00:00 UTC — перший T val
TRAIN_TO = 1786665600            # 2026-08-14 00:00 UTC — останній T відкладених
AHEAD = 40 * 3600                # мітки біля T відомі із запасом
SIDE_READY = 210 + 105           # видача голови готова через подію й пів події
FRESH = 3600                     # свіжий сигнал — рядок за останню годину
SLOPE = 1.0                      # вага POS: +1 за годину віку півота
CAP_H = 6.0                      # … до 6 год
CORR_WEIGHT = 3.0
POS, CORR, NEG, IGNORE = 1, 2, 0, -1
PEAK = 10
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
INIT_RUN, INIT_EPOCH = "RL_tune", 19
REGION_DAYS = 16
PER_REGION = 32
WORKERS = 2
BUFFER = 1024
EPOCH = 12000                    # свіжих вікон на епоху
EPOCHS = 16
PATIENCE = 3
LR = 1e-4
BATCH = 8
MICRO = 4
PREDICT = 16
SEED = 18
MEMORY_NEED = 2400
HELD_LENGTHS = (80, 160, 240)    # сталі відкладені для вибору епохи
HELD_EVERY = 6                   # … T щогодини
GRID_EVERY = 6                   # грід вікон — T щогодини
READ = 144                       # T на одне читання секунд
FILE_PAD = 3 * 3600              # запас читання секунд за кінцем вікна


def seconds_of(pair: str, first: int, last: int):
    """Секунди `[first, last]` для канви. Добові файли робочої копії названі
    за місцевою датою (UTC+2 / UTC+3): файл дати D починається о 21:00 чи
    22:00 UTC дати D − 1. `bars30.read_seconds` бере файли за датою UTC,
    і коли вікно кінчається пізніше 21:00 UTC, файл наступної дати не
    читається — губляться до 3 год найсвіжіших секунд. Тому читання йде
    із запасом `FILE_PAD` за кінцем; канва бере лише секунди до свого
    кінця, запас у неї не потрапляє."""
    import bars30
    return bars30.read_seconds(pair, first, last + FILE_PAD, {})


# ------------------------------------------------------------------ ряд

def series_of(pair: str) -> dict:
    """Записи 100 с train + val підряд, записи 30 с, півоти й корекції
    всього ряду, підтвердження зігзагом, голова «бік ноги» живого ряду."""
    import bars30
    parts = []
    for part in ("train", "val"):
        with np.load(grow.SOURCE / f"{pair}_{part}.npz") as store:
            parts.append({k: store[k] for k in ("t", "open", "close")})
    rec = {k: np.concatenate([p[k] for p in parts]) for k in ("t", "open", "close")}
    halves = []
    for part in ("train", "val"):
        with np.load(bars30.DATA / f"{pair}_{part}.npz") as store:
            halves.append({k: store[k] for k in ("t", "open", "close")})
    bars = {k: np.concatenate([p[k] for p in halves]) for k in ("t", "open", "close")}
    legs = c.legs_of(rec)
    pivots = with_neighbours(pivots_of(legs, rec["close"]), len(rec["t"]))
    corrections = corrections_of(legs, rec["open"], rec["close"], pivots)
    pivots["confirm"] = confirmations(rec["close"], pivots)
    side_t, side_v = side_series(pair)
    return {**rec, "bars": bars, "pivots": pivots, "corrections": corrections,
            "side_t": side_t, "side_v": side_v, "pair": pair}


def confirmations(close: np.ndarray, pivots: dict,
                  threshold: float = OUTER_THRESHOLD) -> np.ndarray:
    """Запис, яким зігзаг 2.3 підтверджує півот: перший після нього, де
    `close` відійшов на `threshold` у зворотний бік; −1 — не підтверджено."""
    out = np.full(len(pivots["index"]), -1, dtype=np.int64)
    for k, (p, top) in enumerate(zip(pivots["index"], pivots["top"])):
        after = close[p + 1:]
        hit = (np.flatnonzero(after <= close[p] * (1 - threshold)) if top
               else np.flatnonzero(after >= close[p] * (1 + threshold)))
        if len(hit):
            out[k] = p + 1 + int(hit[0])
    return out


def side_series(pair: str, folder: Path = SIDE) -> tuple:
    """Голова «бік ноги» живого ряду: час початку події і сира видача."""
    got = json.loads((folder / f"legs_heads_series_{pair}_all.json").read_text(encoding="utf-8"))
    values = np.array([np.nan if v is None else v for v in got["p_side"]], dtype=np.float64)
    stamps = np.asarray(got["t"], dtype=np.int64)
    good = np.isfinite(values)
    return stamps[good], values[good]


def moments(one: dict, lo: int, hi: int) -> np.ndarray:
    """Індекси записів T на сітці `STEP_T` з кінцем запису в `[lo, hi]`."""
    ends = one["t"] + BAR
    pick = (ends % STEP_T == 0) & (ends >= lo) & (ends <= hi)
    return np.flatnonzero(pick)


def start_of(one: dict, e: int, hours: int) -> int:
    """Перший запис вікна `L` годин, що закінчується записом `e`."""
    return int(np.searchsorted(one["t"], one["t"][e] + BAR - hours * 3600, side="left"))


# ------------------------------------------------------------------ канва

def cluster2_rows(holder, one: dict, s: int, e: int, ends: np.ndarray,
                  live: np.ndarray, assigner: dict) -> np.ndarray:
    """P(кластер 2) на рядках канви 1100 — з канви 600 того самого вікна."""
    import canvas600_c1 as c1
    import canvas600_data as d
    bars = one["bars"]
    first, last = int(one["t"][s]), int(one["t"][e]) + BAR - 1
    a = int(np.searchsorted(bars["t"], first, side="left"))
    b = int(np.searchsorted(bars["t"], last - 29, side="right")) - 1
    six = d.canvas_of(holder, bars["t"], bars["open"], bars["close"], a, b)
    window, _, _ = c1.rule_rows(six["net"], six["mask"], assigner)
    prob2, _ = c1.cover(np.where(six["mask"], 1.0 - window, 0.0), six["mask"])
    live6 = six["first"] >= 0
    end6 = np.where(live6, bars["t"][a + np.maximum(six["last"], 0)] + 30, 0)
    return fut.rows_from(ends, live, end6, live6, prob2)


def codes_of(one: dict, s: int, e: int, canvas: dict) -> dict:
    """Код рядка, власник-півот (номер у ряду) і вік півота в годинах."""
    marks = label_rows(s, e, canvas["first"], canvas["last"], one["close"],
                       one["pivots"], one["corrections"])
    label = marks["label"]
    live = canvas["first"] >= 0
    code = np.full(ROWS, NEG, dtype=np.int8)
    code[label == 1] = CORR
    code[label == 2] = POS
    code[(label < 0) | ~live] = IGNORE
    owner = np.full(ROWS, -1, dtype=np.int32)
    age = np.zeros(ROWS, dtype=np.float32)
    index = one["pivots"]["index"]
    for k, zone in enumerate(marks["zones"]):
        if zone["role"] != "pivot":
            continue
        rows = np.flatnonzero(marks["pivot"] == k)
        number = int(np.searchsorted(index, zone["index"]))
        owner[rows] = number
        age[rows] = (one["t"][e] - one["t"][zone["index"]]) / 3600
    return {"code": code, "owner": owner, "age": age}


def sample_of(one: dict, holder, e: int, hours: int, assigner: dict,
              labels: bool = True) -> dict:
    """Канва 1100 × 9 вікна `L` годин, що закінчується записом `e`."""
    s = start_of(one, e, hours)
    canvas = c.canvas_of(holder, one["t"], s, e)
    live = canvas["first"] >= 0
    ends = np.where(live, one["t"][s + np.maximum(canvas["last"], 0)] + BAR, 0)
    x = np.zeros((ROWS, len(CHANNELS)), dtype=np.float32)
    x[:, :7] = canvas["net"]
    x[:, 7] = cluster2_rows(holder, one, s, e, ends, live, assigner)
    x[:, 8] = fut.side_rows(ends, live, one["side_t"], one["side_v"], lag=SIDE_READY)
    x[~live] = 0.0
    scalars = np.array([np.log1p(e - s + 1), np.log1p(canvas["step"]),
                        float(np.log(one["close"][e] / one["open"][s])),
                        float(canvas["mask"].mean())], dtype=np.float32)
    out = {"x": x, "mask": canvas["mask"], "scalars": scalars, "ends": ends,
           "start": s, "end": e, "hours": hours}
    if labels:
        out.update(codes_of(one, s, e, canvas))
    return out


def assigner_of() -> dict:
    import canvas600_c1 as c1
    return json.loads((c1.MODELS / "assigner.json").read_text(encoding="utf-8"))


# ------------------------------------------------------------------ межі

def cuts_of() -> dict:
    """Різ монети етапу 11 — запис у train (той самий у ряду train + val)."""
    return json.loads((grow.DATA / "train_build.json").read_text(encoding="utf-8"))["cut"]


def bounds_of(one: dict, side: str, cut: int) -> tuple:
    """Межі кінця T (секунди) і найраніший початок вікна для частини."""
    last = int(one["t"][-1]) + BAR
    if side == "inside":
        return int(one["t"][0]), int(one["t"][cut]) - AHEAD, int(one["t"][0])
    if side == "held":
        return int(one["t"][cut]), TRAIN_TO, int(one["t"][cut])
    return VAL_FROM, last - AHEAD, int(one["t"][0])


# ------------------------------------------------------------------ подача

def regions(bounds: dict, data: dict, rng, per_region: int = PER_REGION,
            days: int = REGION_DAYS):
    """Нескінченний потік вікон train: шматок монети → `per_region` пар
    (T, L); вікно цілком у межах частини навчання."""
    assigner = assigner_of()
    pairs = list(bounds)
    weight = np.array([bounds[p][1] - bounds[p][0] for p in pairs], float)
    weight /= weight.sum()
    span = days * 86400
    while True:
        pair = pairs[int(rng.choice(len(pairs), p=weight))]
        one = data[pair]
        lo_all, hi_all, _ = bounds[pair]
        lo = int(rng.integers(lo_all, max(hi_all - span, lo_all) + 1))
        hi = min(lo + span, hi_all)
        chosen = []
        for _ in range(per_region):
            hours = int(rng.choice(LENGTHS))
            pool = moments(one, lo + hours * 3600, hi)
            if len(pool):
                chosen.append((int(rng.choice(pool)), hours))
        if not chosen:
            continue
        first = min(int(one["t"][start_of(one, e, h)]) for e, h in chosen)
        last = max(int(one["t"][e]) for e, _ in chosen) + BAR - 1
        holder = seconds_of(pair, first, last)
        for e, hours in chosen:
            got = sample_of(one, holder, e, hours, assigner)
            yield {key: got[key] for key in ("x", "code", "age", "mask", "scalars")}
        del holder


class Stream(torch.utils.data.IterableDataset):
    """Потік вікон навчання; кожен процес — свій seed."""

    def __init__(self, seed: int):
        self.seed = seed

    def __iter__(self):
        info = torch.utils.data.get_worker_info()
        rng = np.random.default_rng([self.seed, info.id if info else 0])
        cuts = cuts_of()
        data = {pair: series_of(pair) for pair in PAIRS}
        bounds = {pair: bounds_of(data[pair], "inside", int(cuts[pair])) for pair in PAIRS}
        yield from regions(bounds, data, rng)


# ------------------------------------------------------------------ мережа

def loss_of(logits: torch.Tensor, code: torch.Tensor, age: torch.Tensor,
            mask: torch.Tensor) -> torch.Tensor:
    """BCE з вагою рядка: `POS` — `1 + SLOPE · min(вік, CAP_H)`, `CORR` —
    `CORR_WEIGHT`, `NEG` — 1; середнє на `POS` плюс середнє на решті живих
    рядків плюс `1 − soft dice`. `logits` — `(B, rows, 1)`."""
    z = logits[..., 0]
    live = (mask & (code >= 0)).float()
    t = (code == POS).float()
    weight = torch.where(code == POS, 1.0 + SLOPE * age.clamp(min=0, max=CAP_H),
                         torch.where(code == CORR, torch.full_like(age, CORR_WEIGHT),
                                     torch.ones_like(age))) * live
    each = F.binary_cross_entropy_with_logits(z, t, reduction="none")
    pos, neg = weight * t, weight * (1 - t)
    total = ((each * pos).sum() / pos.sum().clamp(min=1)
             + (each * neg).sum() / neg.sum().clamp(min=1))
    p = torch.sigmoid(z)
    inter = (p * t * live).sum(dim=1)
    denom = (p * live).sum(dim=1) + (t * live).sum(dim=1)
    dice = (2 * inter + 1) / (denom + 1)
    return total + (1 - dice).mean()


def init_state() -> dict:
    return torch.load(rnd.MODELS / INIT_RUN / f"epoch_{INIT_EPOCH:02d}.pt", map_location="cpu")


def grown_state(state: dict) -> dict:
    """Ваги `Finder3` на 7 каналів і 3 виходи → на 9 каналів і 1 вихід:
    нові канали — нульові стовпці першого шару, вихід — середнє вершини й
    дна. На старті логіт — середнє логітів вершини й дна старої мережі."""
    state = dict(state)
    old = state["embed.weight"]                       # (width, 7 + 4)
    width = old.shape[0]
    grown = torch.zeros(width, len(CHANNELS) + 4, dtype=old.dtype)
    grown[:, :7] = old[:, :7]
    grown[:, len(CHANNELS):] = old[:, 7:]
    state["embed.weight"] = grown
    state["head.weight"] = ((state["head.weight"][0] + state["head.weight"][2]) / 2)[None]
    state["head.bias"] = ((state["head.bias"][0] + state["head.bias"][2]) / 2)[None]
    return state


def start_model(device) -> Finder3:
    """`Finder3` на 9 каналів і 1 вихід зі старту `RL_tune` е19."""
    model = Finder3(channels=len(CHANNELS), rows=ROWS, outputs=1)
    model.load_state_dict(grown_state(init_state()))
    return model.to(device)


def control_model(device) -> Finder3:
    model = Finder3(rows=ROWS, outputs=3)
    model.load_state_dict(init_state())
    return model.to(device).eval()


def forward(model, x: np.ndarray, scalars: np.ndarray, device, control: bool = False) -> np.ndarray:
    """P(зона півота) рядків: `(N, rows)`; контроль — більша з вершини й дна."""
    model.eval()
    out = []
    with torch.no_grad():
        for b in range(0, len(x), PREDICT):
            xb = np.asarray(x[b:b + PREDICT], dtype=np.float32)
            if control:
                xb = xb[..., :7]
            numbers = torch.from_numpy(scalars_of(np.asarray(scalars[b:b + PREDICT])))
            p = torch.sigmoid(model(torch.from_numpy(xb).to(device), numbers.to(device)))
            p = p[..., [0, 2]].max(dim=2).values if control else p[..., 0]
            out.append(p.float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS), np.float32)


# ------------------------------------------------------------------ сталі набори

FIELDS = ("x", "code", "owner", "mask", "ends")


def collect(one: dict, index: np.ndarray, hours: int, assigner: dict, log=print) -> dict:
    """Канви T `index` з вікном `hours`: секунди читаються шматками по
    `READ` моментів."""
    rows = {k: [] for k in FIELDS + ("scalars", "t")}
    for b in range(0, len(index), READ):
        piece = index[b:b + READ]
        first = int(one["t"][start_of(one, int(piece[0]), hours)])
        holder = seconds_of(one["pair"], first, int(one["t"][piece[-1]]) + BAR - 1)
        for e in piece:
            got = sample_of(one, holder, int(e), hours, assigner)
            for k in FIELDS + ("scalars",):
                rows[k].append(got[k])
            rows["t"].append(int(one["t"][e]) + BAR)
        del holder
    return {k: np.stack(v) if k != "t" else np.asarray(v, dtype=np.int64)
            for k, v in rows.items()}


def build_held(out: Path = DATA, log=print) -> None:
    """Сталі канви відкладених для вибору епохи: T щогодини, вікна
    `HELD_LENGTHS`."""
    from numpy.lib.format import open_memmap
    out.mkdir(parents=True, exist_ok=True)
    cuts = cuts_of()
    assigner = assigner_of()
    plan = []
    data = {}
    for pair in PAIRS:
        one = series_of(pair)
        data[pair] = one
        for hours in HELD_LENGTHS:
            lo, hi, floor = bounds_of(one, "held", int(cuts[pair]))
            index = moments(one, max(lo, floor + hours * 3600), hi)[::HELD_EVERY]
            plan.append((pair, hours, index))
    total = sum(len(i) for _, _, i in plan)
    log(f"відкладені: {total} канв")
    x = open_memmap(out / "held_x.npy", "w+", np.float16, (total, ROWS, len(CHANNELS)))
    code = open_memmap(out / "held_code.npy", "w+", np.int8, (total, ROWS))
    owner = open_memmap(out / "held_owner.npy", "w+", np.int32, (total, ROWS))
    mask = open_memmap(out / "held_mask.npy", "w+", bool, (total, ROWS))
    ends = open_memmap(out / "held_ends.npy", "w+", np.int64, (total, ROWS))
    meta = {"pair": [], "hours": [], "t": [], "scalars": []}
    k, started = 0, time.time()
    for pair, hours, index in plan:
        got = collect(data[pair], index, hours, assigner)
        n = len(index)
        x[k:k + n], code[k:k + n], owner[k:k + n] = got["x"], got["code"], got["owner"]
        mask[k:k + n], ends[k:k + n] = got["mask"], got["ends"]
        meta["pair"] += [pair] * n
        meta["hours"] += [hours] * n
        meta["t"] += got["t"].tolist()
        meta["scalars"].append(got["scalars"])
        k += n
        log(f"відкладені {pair} {hours} год: {k}/{total}, {time.time() - started:.0f} с", flush=True)
    for array in (x, code, owner, mask, ends):
        array.flush()
    np.savez(out / "held_meta.npz", pair=np.array(meta["pair"]), hours=np.array(meta["hours"]),
             t=np.array(meta["t"], dtype=np.int64), scalars=np.concatenate(meta["scalars"]))


def load_held(data: Path = DATA) -> dict:
    out = {k: np.load(data / f"held_{k}.npy", mmap_mode="r") for k in FIELDS}
    with np.load(data / "held_meta.npz") as store:
        out.update({k: store[k] for k in store.files})
    return out


# ------------------------------------------------------------------ міра

def pivot_table(one: dict, lo: int, hi: int) -> dict:
    """Півоти, що міряються на сітці T `[lo, hi]`: запис півота не раніше
    за `lo`, підтвердження зігзагом не пізніше за `hi`."""
    piv = one["pivots"]
    t = one["t"]
    confirm = piv["confirm"]
    ok = confirm >= 0
    at = t[piv["index"]] + BAR
    conf_t = np.where(ok, t[np.maximum(confirm, 0)] + BAR, np.iinfo(np.int64).max)
    keep = np.flatnonzero((at >= lo) & ok & (conf_t <= hi))
    return {"number": keep, "at": at[keep], "confirm_t": conf_t[keep],
            "price": one["close"][piv["index"][keep]], "top": piv["top"][keep]}


def measure(prob: np.ndarray, code: np.ndarray, owner: np.ndarray, mask: np.ndarray,
            ends: np.ndarray, stamps: np.ndarray, pivots: dict, threshold: float,
            close_at: np.ndarray | None = None, rng=None) -> dict:
    """Точність свіжих сигналів, виявлення півотів раніше за зігзаг і
    затримки на одній сітці T однієї монети. `rng` — замість сигналів
    мережі стільки ж свіжих сигналів на випадкових свіжих живих рядках."""
    fresh = mask & (ends > (stamps[:, None] - FRESH))
    signal = peaks(prob, mask, threshold, PEAK)
    if rng is not None:
        count = (signal & fresh).sum(axis=1)
        signal = np.zeros_like(signal)
        for i, n in enumerate(count):
            pool = np.flatnonzero(fresh[i])
            if n and len(pool):
                signal[i, rng.choice(pool, min(int(n), len(pool)), replace=False)] = True
    fresh_sig = signal & fresh
    good = fresh_sig & (code == POS)
    hit = signal & (code == POS)
    first = {}
    for i in np.argsort(stamps, kind="stable"):
        for number in np.unique(owner[i][hit[i]]):
            first.setdefault(int(number), int(stamps[i]))
    detected = np.array([first.get(int(n), -1) for n in pivots["number"]], dtype=np.int64)
    found = detected >= 0
    early = found & (detected <= pivots["confirm_t"])
    signals, goods = int(fresh_sig.sum()), int(good.sum())
    precision = goods / signals if signals else float("nan")
    recall = float(early.mean()) if len(early) else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if signals and len(early) and precision + recall > 0 else 0.0)
    delay = (detected - pivots["at"]) / 3600
    zig = (pivots["confirm_t"] - pivots["at"]) / 3600
    lead = (pivots["confirm_t"] - detected) / 3600
    out = {"threshold": float(threshold), "fresh_signals": signals, "good": goods,
           "precision": precision, "pivots": int(len(early)), "found": int(found.sum()),
           "early": int(early.sum()), "recall_early": recall, "f1": f1,
           "delay_h": float(np.median(delay[early])) if early.any() else None,
           "zigzag_h": float(np.median(zig[early])) if early.any() else None,
           "zigzag_all_h": float(np.median(zig)) if len(zig) else None,
           "lead_h": float(np.median(lead[early])) if early.any() else None,
           "signals_per_day": signals / max((stamps.max() - stamps.min()) / 86400, 1e-9)
           if len(stamps) else 0.0}
    if close_at is not None and early.any():
        seen = np.searchsorted(close_at[0], detected[early])
        price = close_at[1][np.clip(seen, 0, len(close_at[1]) - 1)]
        move = np.abs(price / pivots["price"][early] - 1) * 100
        out["retrace_pct"] = float(np.median(move))
    out["detected"] = detected.tolist()
    return out


def pooled(parts: list) -> dict:
    """Сума мір кількох монет: лічильники складаються, медіани — по всіх
    півотах разом."""
    signals = sum(p["fresh_signals"] for p in parts)
    goods = sum(p["good"] for p in parts)
    pivots = sum(p["pivots"] for p in parts)
    early = sum(p["early"] for p in parts)
    precision = goods / signals if signals else float("nan")
    recall = early / pivots if pivots else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if signals and pivots and precision + recall > 0 else 0.0)
    out = {"fresh_signals": signals, "good": goods, "precision": precision,
           "pivots": pivots, "found": sum(p["found"] for p in parts), "early": early,
           "recall_early": recall, "f1": f1,
           "signals_per_day": float(np.mean([p["signals_per_day"] for p in parts]))}
    for key in ("delay_h", "zigzag_h", "lead_h", "retrace_pct", "zigzag_all_h"):
        values = [v for p in parts for v in p.get(f"_{key}", [])]
        out[key] = float(np.median(values)) if values else None
    return out


def with_lists(one: dict, detected: np.ndarray, pivots: dict, early: np.ndarray,
               close_at=None) -> dict:
    """Сирі значення для зведення кількох монет."""
    one["_delay_h"] = ((detected[early] - pivots["at"][early]) / 3600).tolist()
    one["_zigzag_h"] = ((pivots["confirm_t"][early] - pivots["at"][early]) / 3600).tolist()
    one["_zigzag_all_h"] = ((pivots["confirm_t"] - pivots["at"]) / 3600).tolist()
    one["_lead_h"] = ((pivots["confirm_t"][early] - detected[early]) / 3600).tolist()
    if close_at is not None and early.any():
        seen = np.searchsorted(close_at[0], detected[early])
        price = close_at[1][np.clip(seen, 0, len(close_at[1]) - 1)]
        one["_retrace_pct"] = (np.abs(price / pivots["price"][early] - 1) * 100).tolist()
    return one


def score_set(prob: np.ndarray, got: dict, pairs: np.ndarray, series: dict,
              threshold: float, rng=None, lists: bool = False) -> dict:
    """Міра на наборі канв кількох монет (одна довжина вікна): по монетах і разом."""
    per = {}
    for pair in np.unique(pairs):
        pick = np.flatnonzero(pairs == pair)
        stamps = got["t"][pick]
        one = series[str(pair)]
        piv = pivot_table(one, int(stamps.min()), int(stamps.max()))
        close_at = (one["t"] + BAR, one["close"])
        m = measure(prob[pick], np.asarray(got["code"][pick]), np.asarray(got["owner"][pick]),
                    np.asarray(got["mask"][pick]), np.asarray(got["ends"][pick]), stamps, piv,
                    threshold, close_at, rng)
        detected = np.asarray(m.pop("detected"))
        early = (detected >= 0) & (detected <= piv["confirm_t"])
        per[str(pair)] = with_lists(m, detected, piv, early, close_at)
    total = pooled(list(per.values()))
    if not lists:
        for one in per.values():
            for key in [k for k in one if k.startswith("_")]:
                one.pop(key)
    return {"all": total, "pairs": per}


def choose(prob: np.ndarray, got: dict, pairs: np.ndarray, series: dict,
           groups: np.ndarray) -> tuple:
    """Поріг з найбільшим середнім F1 по групах (довжинах вікна)."""
    best = None
    for threshold in THRESHOLDS:
        f1s = []
        for g in np.unique(groups):
            pick = np.flatnonzero(groups == g)
            sub = {k: (v[pick] if hasattr(v, "__len__") and len(v) == len(groups) else v)
                   for k, v in got.items()}
            f1s.append(score_set(prob[pick], sub, pairs[pick], series, threshold)["all"]["f1"])
        mean = float(np.mean(f1s))
        if best is None or mean > best[1]:
            best = (float(threshold), mean)
    return best


# ------------------------------------------------------------------ навчання

def train(run: str, device, log=print) -> dict:
    torch.manual_seed(SEED)
    held = load_held()
    series = {pair: series_of(pair) for pair in PAIRS}
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = start_model(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    loader = torch.utils.data.DataLoader(Stream(SEED), batch_size=None, num_workers=WORKERS,
                                         persistent_workers=True)
    feed = rnd.shuffled(loader, BUFFER, SEED)
    pairs, groups = held["pair"], held["hours"]
    history, best, wait = [], None, 0

    def held_score(epoch: int) -> dict:
        prob = forward(model, held["x"], held["scalars"], device)
        threshold, f1 = choose(prob, held, pairs, series, groups)
        by = {}
        for g in np.unique(groups):
            pick = np.flatnonzero(groups == g)
            sub = {k: (v[pick] if hasattr(v, "__len__") and len(v) == len(groups) else v)
                   for k, v in held.items()}
            by[str(int(g))] = score_set(prob[pick], sub, pairs[pick], series, threshold)["all"]
        return {"epoch": epoch, "threshold": threshold, "mean_f1": f1, "by_hours": by}

    start = held_score(0)
    log(f"{run} старт (RL_tune е19, нові канали нульові): поріг {start['threshold']}, "
        f"F1 {start['mean_f1']:.3f}")
    for epoch in range(1, EPOCHS + 1):
        started = time.time()
        model.train()
        total, seen = 0.0, 0
        for _ in range(EPOCH // BATCH):
            items = [next(feed) for _ in range(BATCH)]
            optimizer.zero_grad()
            for piece in range(0, BATCH, MICRO):
                part = items[piece:piece + MICRO]
                stack = lambda key, kind=None: torch.from_numpy(  # noqa: E731
                    np.stack([np.asarray(i[key]) for i in part])).to(device)
                x = stack("x")
                numbers = torch.from_numpy(scalars_of(np.stack(
                    [np.asarray(i["scalars"]) for i in part]))).to(device)
                value = loss_of(model(x, numbers), stack("code").long(), stack("age"),
                                stack("mask"))
                (value * len(part) / BATCH).backward()
                total += float(value.detach()) * len(part)
                seen += len(part)
            optimizer.step()
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        one = held_score(epoch)
        one.update({"train_loss": total / max(seen, 1), "seconds": time.time() - started})
        history.append(one)
        log(f"{run} е{epoch}: втрата {one['train_loss']:.4f}, поріг {one['threshold']}, "
            f"F1 відкладені {one['mean_f1']:.3f} · " + " · ".join(
                f"{h} год: точн {v['precision']:.3f} повн {v['recall_early']:.3f}"
                for h, v in one["by_hours"].items()) + f", {one['seconds']:.0f} с", flush=True)
        if best is None or one["mean_f1"] > best["f1"]:
            best, wait = {"epoch": epoch, "f1": one["mean_f1"]}, 0
        else:
            wait += 1
            if wait >= PATIENCE:
                break
    out = {"run": run, "init": f"{INIT_RUN} е{INIT_EPOCH}", "best_epoch": best["epoch"],
           "threshold": next(h["threshold"] for h in history if h["epoch"] == best["epoch"]),
           "start": start, "history": history,
           "config": {"lengths": list(LENGTHS), "step_t": STEP_T, "fresh": FRESH,
                      "slope": SLOPE, "cap_h": CAP_H, "corr_weight": CORR_WEIGHT,
                      "side_ready": SIDE_READY, "val_from": VAL_FROM, "train_to": TRAIN_TO,
                      "ahead": AHEAD, "region_days": REGION_DAYS, "per_region": PER_REGION,
                      "workers": WORKERS, "buffer": BUFFER, "epoch": EPOCH, "epochs": EPOCHS,
                      "patience": PATIENCE, "lr": LR, "batch": BATCH, "micro": MICRO,
                      "seed": SEED, "held_lengths": list(HELD_LENGTHS),
                      "held_every_min": HELD_EVERY * STEP_T // 60, "peak": PEAK}}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / f"{run}.json").write_text(json.dumps(clean(out), ensure_ascii=False, indent=1),
                                         encoding="utf-8")
    log(f"{run}: найкраща епоха {best['epoch']}, F1 {best['f1']:.3f}")
    return out


# ------------------------------------------------------------------ грід вікон

def trained(run: str, device) -> tuple:
    summary = json.loads((RESULTS / f"{run}.json").read_text(encoding="utf-8"))
    model = Finder3(channels=len(CHANNELS), rows=ROWS, outputs=1)
    model.load_state_dict(torch.load(MODELS / run / f"epoch_{summary['best_epoch']:02d}.pt",
                                     map_location="cpu"))
    return model.to(device).eval(), summary


def run_set(models: dict, series: dict, side: str, hours: int, every: int, cuts: dict,
            assigner: dict, pairs: tuple = PAIRS) -> dict:
    """Видачі всіх моделей на сітці T однієї частини й довжини вікна.

    Канви будуються шматками по `READ` моментів і одразу йдуть у мережі;
    у памʼяті лишаються лише компактні масиви міри (`int8`, `int16`,
    `int32`, `float16`) — сама канва 1100 × 9 не накопичується."""
    probs = {name: [] for name in models}
    keep = {k: [] for k in ("code", "owner", "mask", "ends", "t", "pair")}
    kinds = {"code": np.int8, "owner": np.int16, "mask": bool, "ends": np.int32,
             "t": np.int64}
    for pair in pairs:
        one = series[pair]
        lo, hi, floor = bounds_of(one, side, int(cuts[pair]))
        index = moments(one, max(lo, floor + hours * 3600), hi)[::every]
        for b in range(0, len(index), READ):
            piece = index[b:b + READ]
            got = collect(one, piece, hours, assigner)
            for name, (model, device, control) in models.items():
                probs[name].append(forward(model, got["x"], got["scalars"], device, control)
                                   .astype(np.float16))
            for k, kind in kinds.items():
                keep[k].append(np.asarray(got[k]).astype(kind))
            keep["pair"].append(np.array([pair] * len(piece)))
            del got
    if not keep["t"]:
        return {}
    out = {k: np.concatenate(v) for k, v in keep.items()}
    out["ends"] = out["ends"].astype(np.int64)
    out["prob"] = {name: np.concatenate(v) for name, v in probs.items()}
    return out


def grid(run: str, device, log=print) -> dict:
    """Грід вікон: відкладені щогодини → найкраще `L`; val щогодини на всіх
    `L` і кожні 10 хв на найкращому; контролі — `RL_tune` е19 і випадкові."""
    model, summary = trained(run, device)
    models = {"model": (model, device, False), "control": (control_model(device), device, True)}
    series = {pair: series_of(pair) for pair in PAIRS}
    cuts = cuts_of()
    assigner = assigner_of()
    rows = []
    started = time.time()
    for hours in LENGTHS:
        got = run_set(models, series, "held", hours, GRID_EVERY, cuts, assigner)
        got["prob"] = {k: v.astype(np.float32) for k, v in got["prob"].items()}
        row = {"hours": hours, "thresholds": {}}
        for name in models:
            # поріг кожної моделі — свій на кожному вікні, з відкладених
            threshold = choose(got["prob"][name], got, got["pair"], series,
                               np.zeros(len(got["t"])))[0]
            row["thresholds"][name] = threshold
            row[f"held_{name}"] = score_set(got["prob"][name], got, got["pair"], series, threshold)
        rows.append(row)
        log(f"відкладені {hours} год: F1 мережа {row['held_model']['all']['f1']:.3f} "
            f"(поріг {row['thresholds']['model']}), контроль "
            f"{row['held_control']['all']['f1']:.3f} (поріг {row['thresholds']['control']}), "
            f"{time.time() - started:.0f} с", flush=True)
    best_row = max(rows, key=lambda r: r["held_model"]["all"]["f1"])
    best = best_row["hours"]
    thresholds = best_row["thresholds"]
    log(f"найкраще вікно на відкладених: {best} год, пороги {thresholds}")
    for row in rows:
        hours = row["hours"]
        got = run_set(models, series, "val", hours, GRID_EVERY, cuts, assigner)
        got["prob"] = {k: v.astype(np.float32) for k, v in got["prob"].items()}
        for name in models:
            row[f"val_{name}"] = score_set(got["prob"][name], got, got["pair"], series,
                                           row["thresholds"][name])
        log(f"val {hours} год: F1 мережа {row['val_model']['all']['f1']:.3f}, контроль "
            f"{row['val_control']['all']['f1']:.3f}, {time.time() - started:.0f} с", flush=True)
    # найкраще вікно кожні 10 хв: відкладені й val, контролі — монета за
    # монетою, щоб у памʼяті була одна монета
    fine = {}
    for side in ("held", "val"):
        per = {name: {} for name in ("model", "control", "random")}
        for pair in PAIRS:
            got = run_set(models, series, side, best, 1, cuts, assigner, (pair,))
            if not got:
                continue
            prob = {k: v.astype(np.float32) for k, v in got["prob"].items()}
            for name in models:
                per[name].update(score_set(prob[name], got, got["pair"], series,
                                           thresholds[name], lists=True)["pairs"])
            per["random"].update(score_set(prob["model"], got, got["pair"], series,
                                           thresholds["model"], rng=np.random.default_rng(SEED),
                                           lists=True)["pairs"])
            if side == "val":
                save_series(run, {**got, "prob": prob}, series, thresholds["model"], best,
                            summary)
            del got, prob
        fine[side] = {}
        for name, pairs_of in per.items():
            total = pooled(list(pairs_of.values()))
            for one in pairs_of.values():
                for key in [k for k in one if k.startswith("_")]:
                    one.pop(key)
            fine[side][name] = {"all": total, "pairs": pairs_of}
        log(f"{side} кожні 10 хв, {best} год: " + " · ".join(
            f"{name} F1 {v['all']['f1']:.3f} точн {v['all']['precision']:.3f} "
            f"повн {v['all']['recall_early']:.3f}" for name, v in fine[side].items()), flush=True)
    out = {"run": run, "epoch": summary["best_epoch"], "thresholds": thresholds,
           "best_hours": best, "grid_every_min": GRID_EVERY * STEP_T // 60,
           "rows": rows, "fine": fine}
    (RESULTS / f"{run}_grid.json").write_text(json.dumps(clean(out), ensure_ascii=False, indent=1),
                                              encoding="utf-8")
    return out


def save_series(run: str, got: dict, series: dict, threshold: float, hours: int,
                summary: dict) -> None:
    """Ряд val найкращого вікна кожні 10 хв: на кожен T —
    найбільша P на свіжих рядках, свіжий сигнал і чи він у зоні півота;
    півоти з часом підтвердження зігзагом і першим виявленням мережею."""
    prob = got["prob"]["model"]
    signal = peaks(prob, got["mask"], threshold, PEAK)
    fresh = got["mask"] & (got["ends"] > (got["t"][:, None] - FRESH))
    for pair in PAIRS:
        pick = np.flatnonzero(got["pair"] == pair)
        if not len(pick):
            continue
        one = series[pair]
        stamps = got["t"][pick]
        piv = pivot_table(one, int(stamps.min()), int(stamps.max()))
        m = measure(prob[pick], got["code"][pick], got["owner"][pick], got["mask"][pick],
                    got["ends"][pick], stamps, piv, threshold)
        detected = np.asarray(m.pop("detected"))
        live_p = np.where(fresh[pick], prob[pick], 0.0).max(axis=1)
        fresh_sig = (signal[pick] & fresh[pick]).any(axis=1)
        fresh_good = (signal[pick] & fresh[pick] & (got["code"][pick] == POS)).any(axis=1)
        at = np.searchsorted(one["t"] + BAR, stamps)
        index = one["pivots"]["index"]
        all_piv = [{"t": int(one["t"][p]) + BAR, "price": float(one["close"][p]),
                    "top": bool(top), "confirm_t": int(one["t"][cf]) + BAR if cf >= 0 else None}
                   for p, top, cf in zip(index, one["pivots"]["top"], one["pivots"]["confirm"])
                   if stamps.min() - hours * 3600 <= one["t"][p] <= stamps.max()]
        found = {int(n): int(d) for n, d in zip(piv["number"], detected) if d >= 0}
        for k, p in enumerate(all_piv):
            number = int(np.searchsorted(index, np.searchsorted(one["t"] + BAR, p["t"])))
            p["detected_t"] = found.get(number)
        payload = {"run": run, "epoch": summary["best_epoch"], "threshold": threshold,
                   "hours": hours, "pair": pair, "step": STEP_T, "fresh": FRESH,
                   "t": stamps.tolist(), "close": one["close"][at].round(8).tolist(),
                   "p": np.round(live_p, 4).tolist(), "signal": fresh_sig.tolist(),
                   "good": fresh_good.tolist(), "pivots": all_piv, "metrics": m}
        (RESULTS / f"{run}_val_{pair}.json").write_text(
            json.dumps(clean(payload), ensure_ascii=False), encoding="utf-8")


# ------------------------------------------------------------------ канва в момент T

_CACHE: dict = {}


def cached(key: tuple, make):
    """Ряд монети й модель для вкладки рахуються раз на процес."""
    if key not in _CACHE:
        _CACHE[key] = make()
    return _CACHE[key]


def probe(pair: str, at: int, run: str, hours: int | None = None) -> dict:
    """Канва вікна, що закінчується в `at` (секунди UTC, кінець запису
    на сітці 10 хв), і видача мережі на кожному рядку — тим самим ходом,
    що в навчанні. Правда — зони півотів готового зігзага: відома лише
    пізніше, показується для порівняння."""
    one = cached(("series", pair), lambda: series_of(pair))
    model, summary = cached(("model", run), lambda: trained(run, torch.device("cpu")))
    grid_file = RESULTS / f"{run}_grid.json"
    chosen = (json.loads(grid_file.read_text(encoding="utf-8"))
              if grid_file.exists() else None)
    if hours is None:
        hours = chosen["best_hours"] if chosen else 160
    e = int(np.searchsorted(one["t"] + BAR, at, side="right")) - 1
    if e < 0 or one["t"][e] + BAR < VAL_FROM - 7 * 86400:
        raise ValueError("момент поза рядом val")
    s = start_of(one, e, hours)
    first, last = int(one["t"][s]), int(one["t"][e]) + BAR - 1
    # секунди читаються з запасом на добу вперед: кроки по 10 хв беруть той
    # самий шматок; канва бере з нього лише записи свого вікна
    spot = _CACHE.get(("seconds", pair))
    if spot is None or spot[0] > first or spot[1] < last:
        end = min(last + 86400, int(one["t"][-1]) + BAR - 1)
        spot = (first, end, seconds_of(pair, first, end))
        _CACHE[("seconds", pair)] = spot
    got = sample_of(one, spot[2], e, hours, cached(("assigner",), assigner_of))
    prob = forward(model, got["x"][None], got["scalars"][None], torch.device("cpu"))[0]
    threshold = chosen["thresholds"]["model"] if chosen else summary["threshold"]
    # поріг обраного вікна — свій з гріду відкладених
    for row in (chosen or {}).get("rows", []):
        if row["hours"] == hours and "thresholds" in row:
            threshold = row["thresholds"]["model"]
    signal = peaks(prob[None], got["mask"][None], threshold, PEAK)[0]
    live = got["mask"]
    ends = got["ends"]
    last = np.clip(np.searchsorted(one["t"] + BAR, ends, side="right") - 1, 0, len(one["t"]) - 1)
    row_close = np.where(live, one["close"][last], np.nan)
    now = int(one["t"][e]) + BAR
    index = one["pivots"]["index"]
    near = np.flatnonzero((one["t"][index] + BAR >= one["t"][s]) & (one["t"][index] + BAR <= now))
    pivots = [{"t": int(one["t"][index[k]]) + BAR, "price": float(one["close"][index[k]]),
               "top": bool(one["pivots"]["top"][k]),
               "confirm_t": (int(one["t"][one["pivots"]["confirm"][k]]) + BAR
                             if one["pivots"]["confirm"][k] >= 0 else None)} for k in near]
    return {"pair": pair, "at": now, "hours": hours, "threshold": threshold,
            "epoch": summary["best_epoch"], "row_end": ends, "live": live, "prob": prob,
            "signal": np.flatnonzero(signal), "code": got["code"], "cluster2": got["x"][:, 7],
            "side": got["x"][:, 8], "row_close": row_close,
            "fresh_from": now - FRESH, "pivots": pivots}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--held", action="store_true", help="сталі канви відкладених")
    parser.add_argument("--run", help="навчання прогону")
    parser.add_argument("--grid", help="грід вікон і ряд val для прогону")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.held:
        build_held()
    if args.run:
        no_swap(MEMORY_NEED, args.force)
        train(args.run, device_of(args.device))
    if args.grid:
        grid(args.grid, device_of(args.device))


if __name__ == "__main__":
    main()
