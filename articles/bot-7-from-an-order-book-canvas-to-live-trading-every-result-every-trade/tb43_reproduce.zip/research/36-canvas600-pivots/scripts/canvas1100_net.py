"""Етап 7: мережа на канві 1100 знаходить півоти 2.3 %.

Дослідження: research/36-canvas600-pivots/ → Етап 7

## Хід

1. **Дані** — **зсунуті** канви 1100 етапу 6 (`data/canvas1100/<part>_x.npy`,
   `<part>.npz`, вид `shift`): вікно чотирьох ніг ≥ 7 год, зсунуте на
   `δ · L / 4`, `δ ~ U[−1, 1]` — півоти стоять у будь-яких рядках; записи
   100 с, клас `клас210х10-1х7д/д`, нормування на канву; train — до
   14.08, val — 14.08 … 22.09. Базові канви (півоти завжди в рядках 49 і
   1049) не беруться: на них мережа з вивченою позицією рядка вчить
   позицію, а не півот — перевірено першим прогоном: 131 з 136 крайніх
   півотів val знайдено, 0 з 227 внутрішніх.
2. **Мітка рядка** — `1`, коли рядок у зоні півота 2.3 (`label = 2`),
   `0` — тіло й зони корекцій 0.8; рядок `−1` (зона, чий півот поза
   канвою) і мертвий рядок у втрату не йдуть.
3. **Розбиття по часу** (`rules/03-models.md` → Розбиття по часу):
   відкладені — канви, що починаються з ноги `cut + 1` і далі, де `cut` —
   нога на 80 % ніг монети (різ по півоту); навчання — канви, чиї 4 ноги
   і ще одна (зсув) цілком до `cut`. Спільних ніг у навчання й
   відкладених немає. val —
   тільки замір.
4. **Мережа** — `Finder3` етапу 2 (`canvas600_net.Finder3`) на 1100
   рядках з двома виходами: рядок + 4 скаляри канви → 64, вивчена
   позиція рядка, 2 шари уваги по 4 голови, norm first, ff 128,
   dropout 0.
5. **Втрата** — крос-ентропія з вагами 1 / 3 (тіло / півот). Adam
   lr 1e-3, батч 8 кусками по 4, seed 0, стеля 30 епох, стоп після 4
   епох без покращення F1 на відкладених.
6. **Сигнал і міра** — як в етапі 2: сигнал — рядок, де `P(півот)` ≥
   порогу і найбільша в ±10 рядках; добрий — у зоні півота; повнота —
   частка зон півота, у яких є сигнал; сплутано — сигнал у зоні
   корекції поза зоною півота. Поріг і епоха — за F1 на відкладених.
7. **Базовий прогноз** — стільки ж сигналів у кожній канві, скільки дала
   мережа, на випадкових живих рядках (seed 36): та сама міра.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_net.py

Вихід: models/canvas1100/epoch_NN.pt, history.json;
results/canvas1100_net.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(RESEARCH.parent / "35-leg-fullness" / "scripts"))
sys.path.insert(0, str(RESEARCH.parents[1] / "rules" / "scripts"))

from canvas600_net import Finder3, clean  # noqa: E402
from edges30_net import device_of, peaks, scalars_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

DATA = RESEARCH / "data" / "canvas1100"
MODELS = RESEARCH / "models" / "canvas1100"
RESULTS = RESEARCH / "results"
ROWS = 1100
HELD = 0.8                       # нога-різ: частка ніг монети до відкладених
LEGS_IN = 4
PAD = 1                          # зсув канви сягає до ноги в кожен бік
WEIGHT = (1.0, 3.0)              # тіло, півот
LR, BATCH, MICRO, PREDICT = 1e-3, 8, 4, 4
EPOCHS, PATIENCE = 30, 4
PEAK = 10
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
SEED = 0
BASE_SEED = 36
KIND = "shift"                   # мережа вчиться й міряється на зсунутих канвах
MEMORY_NEED = 2400


def load(part: str, data: Path = DATA, kind: str = KIND) -> dict:
    """Канви частини одного виду (`shift` — зсунуті)."""
    with np.load(data / f"{part}.npz") as store:
        out = {name: store[name] for name in store.files}
    keep = np.flatnonzero(out["kind"] == kind)
    out = {name: value[keep] for name, value in out.items()}
    out["x"] = np.load(data / f"{part}_x.npy", mmap_mode="r")[keep]
    out["target"] = np.where(out["label"] == 2, 1,
                             np.where(out["label"] < 0, -1, 0)).astype(np.int64)
    out["numbers"] = scalars_of(out["scalars"])
    return out


def split(data: dict, share: float = HELD, legs_in: int = LEGS_IN,
          pad: int = PAD) -> tuple:
    """Навчання — канви, чиї ноги (з запасом `pad` на зсув) цілком до
    ноги-різу; відкладені — ті, що починаються за `pad` ніг після неї."""
    inside, held = [], []
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        legs = data["leg"][where]
        cut = int(np.floor(share * (legs.max() + legs_in)))
        inside.extend(where[legs + legs_in - 1 + pad < cut].tolist())
        held.extend(where[legs - pad >= cut].tolist())
    return np.asarray(inside), np.asarray(held)


def loss_of(logits: torch.Tensor, target: torch.Tensor, mask: torch.Tensor,
            weight=WEIGHT) -> torch.Tensor:
    live = mask & (target >= 0)
    t = target.clamp(min=0)
    w = torch.tensor(weight, device=logits.device)[t] * live
    each = F.cross_entropy(logits.permute(0, 2, 1), t, reduction="none")
    return (each * w).sum() / w.sum().clamp(min=1e-6)


def predict(model, data: dict, index: np.ndarray, device) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(index), PREDICT):
            pick = index[start:start + PREDICT]
            logits = model(torch.from_numpy(data["x"][pick]).to(device),
                           torch.from_numpy(data["numbers"][pick]).to(device))
            out.append(logits.softmax(dim=2)[..., 1].float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS), np.float32)


def score(signal: np.ndarray, data: dict, index: np.ndarray) -> dict:
    """Точність, повнота, F1, сплутано з корекцією; зон півота."""
    own = data["pivot"][index]
    other = data["corr"][index]
    signals = int(signal.sum())
    good = int((signal & (own >= 0)).sum())
    swapped = int((signal & (own < 0) & (other >= 0)).sum())
    total = found = 0
    for row_signal, row_own in zip(signal, own):
        zones = set(row_own[row_own >= 0].tolist())
        total += len(zones)
        found += len(zones & set(row_own[row_signal].tolist()))
    precision = good / signals if signals else float("nan")
    recall = found / total if total else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if signals and total and precision + recall > 0 else 0.0)
    return {"signals": signals, "good": good, "swapped": swapped,
            "zones": total, "found": found, "precision": precision,
            "recall": recall, "f1": f1}


def best_threshold(prob: np.ndarray, data: dict, index: np.ndarray) -> float:
    mask = data["mask"][index]
    return float(max(THRESHOLDS, key=lambda t: score(
        peaks(prob, mask, t, PEAK), data, index)["f1"]))


def random_signals(signal: np.ndarray, mask: np.ndarray,
                   seed: int = BASE_SEED) -> np.ndarray:
    """Базовий прогноз: у кожній канві стільки ж сигналів на випадкових
    живих рядках."""
    rng = np.random.default_rng(seed)
    out = np.zeros_like(signal)
    for number, (row_signal, live) in enumerate(zip(signal, mask)):
        count = int(row_signal.sum())
        rows = np.flatnonzero(live)
        if count and len(rows):
            out[number, rng.choice(rows, min(count, len(rows)), replace=False)] = True
    return out


def measure(prob: np.ndarray, data: dict, index: np.ndarray,
            threshold: float) -> dict:
    signal = peaks(prob, data["mask"][index], threshold, PEAK)
    return {"model": score(signal, data, index),
            "base": score(random_signals(signal, data["mask"][index]),
                          data, index)}


def by_pair(prob: np.ndarray, data: dict, threshold: float) -> dict:
    index = np.arange(len(data["pair"]))
    out = {"all": measure(prob, data, index, threshold)}
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        out[str(pair)] = measure(prob[where], data, where, threshold)
    return out


def train(data: dict, val: dict, device, log=print, folder: Path = MODELS,
          epochs: int = EPOCHS, patience: int = PATIENCE) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    inside, held = split(data)
    log(f"канв: навчання {len(inside)}, відкладені {len(held)}, val {len(val['pair'])}")
    folder.mkdir(parents=True, exist_ok=True)
    model = Finder3(rows=ROWS, outputs=2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    history, best, wait = [], None, 0
    val_index = np.arange(len(val["pair"]))
    for epoch in range(1, epochs + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for start in range(0, len(order), BATCH):
            pick = np.sort(order[start:start + BATCH])
            optimizer.zero_grad()
            for piece in range(0, len(pick), MICRO):
                part = pick[piece:piece + MICRO]
                loss = loss_of(
                    model(torch.from_numpy(data["x"][part]).to(device),
                          torch.from_numpy(data["numbers"][part]).to(device)),
                    torch.from_numpy(data["target"][part]).to(device),
                    torch.from_numpy(data["mask"][part]).to(device))
                (loss * len(part) / len(pick)).backward()
                total += float(loss) * len(part)
                count += len(part)
            optimizer.step()
        held_prob = predict(model, data, held, device)
        threshold = best_threshold(held_prob, data, held)
        held_score = measure(held_prob, data, held, threshold)
        val_prob = predict(model, val, val_index, device)
        one = {"epoch": epoch, "train_loss": total / max(count, 1),
               "threshold": threshold, "holdout": held_score,
               "val": by_pair(val_prob, val, threshold),
               "seconds": time.time() - started}
        history.append(one)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        f1 = held_score["model"]["f1"]
        log(f"епоха {epoch}: втрата {one['train_loss']:.4f}, поріг {threshold}, "
            f"F1 відкладені {f1:.3f} (база {held_score['base']['f1']:.3f}), "
            f"val {one['val']['all']['model']['f1']:.3f} "
            f"(база {one['val']['all']['base']['f1']:.3f}), {one['seconds']:.0f} с")
        if best is None or f1 > best["f1"]:
            best, wait = {"epoch": epoch, "f1": f1}, 0
        else:
            wait += 1
            if wait >= patience:
                break
    (folder / "history.json").write_text(json.dumps(clean(
        {"best_epoch": best["epoch"], "history": history,
         "config": {"rows": ROWS, "weight": WEIGHT, "lr": LR, "batch": BATCH,
                    "micro": MICRO, "epochs": epochs, "patience": patience,
                    "peak": PEAK, "held": HELD, "seed": SEED}}),
        ensure_ascii=False, indent=1), encoding="utf-8")
    return {"best": best, "history": history, "inside": len(inside),
            "held": len(held), "val": len(val_index)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    no_swap(MEMORY_NEED, args.force)
    device = device_of(args.device)
    data, val = load("train"), load("val")
    got = train(data, val, device)
    best = [one for one in got["history"] if one["epoch"] == got["best"]["epoch"]][0]
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "canvas1100_net.json").write_text(json.dumps(clean(
        {"best_epoch": got["best"]["epoch"], "canvases": {
            "inside": got["inside"], "held": got["held"], "val": got["val"]},
         "zones": {"held": best["holdout"]["model"]["zones"],
                   "val": best["val"]["all"]["model"]["zones"]},
         "threshold": best["threshold"], "holdout": best["holdout"],
         "val": best["val"],
         "history": [{"epoch": one["epoch"], "train_loss": one["train_loss"],
                      "threshold": one["threshold"],
                      "held_f1": one["holdout"]["model"]["f1"],
                      "val_f1": one["val"]["all"]["model"]["f1"],
                      "seconds": one["seconds"]} for one in got["history"]]}),
        ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()


MIN_RECORDS = 1100               # відрізок канви руками — не коротший


BEFORE = 3                       # півотів train перед val на ряді канви руками


def val_marks(pair: str, data: Path = DATA, before: int = BEFORE,
              min_tail: int = 0) -> dict:
    """Ряд канви руками: хвіст train від `before`-го з кінця півота 2.3 і
    весь val, записи 100 с; зігзаг 2.3 і корекції 0.8 — по цьому ряду.
    `min_tail` — хвіст train не коротший за стільки записів (торгівля в
    живому часі: перше вікно канви має вміститись до початку val)."""
    import canvas1100 as c
    from canvas600_data import corrections_of, with_neighbours
    from edges30_data import pivots_of
    parts = {}
    for part in ("train", "val"):
        with np.load(data / f"{pair}_{part}.npz") as store:
            parts[part] = {name: store[name] for name in ("t", "open", "close")}
    legs = json.loads((data / "legs_train.json").read_text(encoding="utf-8"))[pair]
    edge = pivots_of(legs, parts["train"]["close"])["index"]
    val_from = int(parts["val"]["t"][0])
    # зігзаг, запущений з хвоста заново, першої точки півотом не ставить —
    # хвіст відступає на півот, поки перед val не стане `before` півотів
    for back in range(before, len(edge) + 1):
        tail = int(edge[-back])
        bars = {name: np.concatenate([parts["train"][name][tail:], parts["val"][name]])
                for name in ("t", "open", "close")}
        legs = c.legs_of(bars)
        found = pivots_of(legs, bars["close"])
        if (bars["t"][found["index"]] < val_from).sum() >= before \
                and len(parts["train"]["t"]) - tail >= min_tail:
            break
    pivots = with_neighbours(found, len(bars["close"]))
    corrections = corrections_of(legs, bars["open"], bars["close"], pivots)
    return {**bars, "pivots": pivots, "corrections": corrections, "bar": c.BAR,
            "val_from": val_from}


def probe(pair: str, first: int, last: int, data: Path = DATA,
          results: Path = RESULTS, folder: Path = MODELS,
          root: Path | None = None, heads_results: Path | None = None,
          heads_models: Path | None = None, grow_folders: dict | None = None) -> dict:
    """Канва 1100 з відрізка `[first, last]` (секунди UTC) ряду `val_marks` і
    мережа етапу 7 на найкращій епосі: P(півот) рядків, сигнали, правда.
    На тій самій канві — кожен прогін етапу 8 (`heads`): три голови,
    сигнали півота й корекції за їхніми порогами, бік рядка — правда.
    На тій самій канві — моделі етапів 11–12 (`grow`,
    `canvas1100_grow.buttons`): вершина, корекція, дно, сигнали за порогом
    своєї епохи, добрий — на `POS` чи `ALT` своєї голови.
    """
    import bars30
    import canvas1100 as c
    from canvas600_data import label_rows
    got = val_marks(pair, data)
    stamps, opens, close = got["t"], got["open"], got["close"]
    start = max(int(np.searchsorted(stamps, first, side="left")), 0)
    end = min(int(np.searchsorted(stamps, last, side="right")) - 1, len(stamps) - 1)
    if end - start + 1 < MIN_RECORDS:
        raise ValueError(f"відрізок коротший за {MIN_RECORDS} записів по {c.BAR} с "
                         f"({MIN_RECORDS * c.BAR / 3600:.1f} год)")
    holder = bars30.read_seconds(pair, int(stamps[start]),
                                 int(stamps[end]) + c.BAR - 1, {}, root)
    canvas = c.canvas_of(holder, stamps, start, end)
    marks = label_rows(start, end, canvas["first"], canvas["last"], close,
                       got["pivots"], got["corrections"])
    scalars = np.array([[np.log1p(end - start + 1), np.log1p(canvas["step"]),
                         float(np.log(close[end] / opens[start])),
                         float(canvas["mask"].mean())]], dtype=np.float32)
    summary = json.loads((results / "canvas1100_net.json").read_text(encoding="utf-8"))
    epoch, threshold = summary["best_epoch"], summary["threshold"]
    device = torch.device("cpu")
    model = Finder3(rows=ROWS, outputs=2)
    model.load_state_dict(torch.load(folder / f"epoch_{epoch:02d}.pt",
                                     map_location=device))
    one = {"x": canvas["net"][None], "numbers": scalars_of(scalars)}
    prob = predict(model, one, np.array([0]), device)[0]
    signal = peaks(prob[None], canvas["mask"][None], threshold, PEAK)[0]
    live = canvas["first"] >= 0
    out = {"pair": pair, "start": start, "end": end, "epoch": epoch,
           "threshold": float(threshold), "bar": c.BAR,
           "t": stamps[start:end + 1], "close": close[start:end + 1],
           "live": live, "label": marks["label"], "prob": prob,
           "signal": np.flatnonzero(signal),
           "good": marks["label"][signal] == 2,
           "row_start": np.where(live, stamps[start + np.maximum(canvas["first"], 0)], 0),
           "row_end": np.where(live, stamps[start + np.maximum(canvas["last"], 0)] + c.BAR, 0)}
    for name, table in (("pivot", got["pivots"]), ("corr", got["corrections"])):
        inside = (table["index"] >= start) & (table["index"] <= end)
        out[f"{name}_index"] = table["index"][inside] - start
        out[f"{name}_top"] = table["top"][inside]
        out[f"{name}_zone"] = table["zone"][inside]
        out[f"{name}_span"] = table["span"][inside]
    out["side"] = row_sides(canvas, start, got["pivots"])
    out["heads"] = heads_on(canvas["net"], scalars, canvas["mask"], marks,
                            heads_results, heads_models)
    # етапи 11–12: вершина, корекція, дно з кодами рядків свого навчання
    import canvas1100_grow as grow
    codes = grow.codes_of(start, end, canvas["first"], canvas["last"], close,
                          got["pivots"], got["corrections"])
    out["grow_code"] = codes["code"]
    out["grow"] = grow.models_on(canvas["net"], scalars, canvas["mask"], codes["code"],
                                 **(grow_folders or {}))
    zones = set(marks["pivot"][marks["pivot"] >= 0].tolist())
    out["counts"] = {"records": int(end - start + 1), "rows": int(live.sum()),
                     "step": float(canvas["step"]), "zones": len(zones),
                     "found": len(zones & set(marks["pivot"][signal].tolist())),
                     "signals": int(signal.sum()),
                     "good": int((marks["label"][signal] == 2).sum())}
    return out


def row_sides(canvas: dict, start: int, pivots: dict) -> np.ndarray:
    """Бік рядка канви: 1 — нога вгору (наступний півот — вершина), 0 —
    нога вниз, −1 — мертвий рядок або після останнього півота."""
    first, last = canvas["first"], canvas["last"]
    live = first >= 0
    record = start + (first + last) // 2
    after = np.searchsorted(pivots["index"], record, side="left")
    ok = live & (after < len(pivots["index"]))
    side = np.full(len(first), -1, dtype=np.int64)
    side[ok] = np.where(pivots["top"][after[ok]], 1, 0)
    return side


def heads_on(x: np.ndarray, scalars: np.ndarray, mask: np.ndarray, marks: dict,
             results: Path | None = None, models: Path | None = None) -> list:
    """Кожен прогін етапу 8 на одній канві: три голови і сигнали."""
    import canvas1100_heads as heads
    results = results or heads.RESULTS
    models = models or heads.MODELS
    if not results.exists():
        return []
    device = torch.device("cpu")
    one = {"x": x[None], "numbers": scalars_of(scalars)}
    out = []
    for path in sorted(results.glob("*.json")):
        summary = json.loads(path.read_text(encoding="utf-8"))
        weights = models / summary["run"] / f"epoch_{summary['best_epoch']:02d}.pt"
        if not weights.exists():
            continue
        model = Finder3(rows=ROWS, outputs=heads.OUTPUTS)
        model.load_state_dict(torch.load(weights, map_location=device))
        prob = heads.predict(model, one, np.array([0]), device)[0]
        got = {"run": summary["run"], "loss": summary["loss"],
               "legs": summary["legs"], "init": summary.get("init"),
               "epoch": summary["best_epoch"],
               "thresholds": summary["thresholds"],
               "pivot_prob": prob[:, 0], "corr_prob": prob[:, 1],
               "side_prob": prob[:, 2]}
        for h, name in enumerate(heads.HEADS):
            signal = peaks(prob[None, :, h], mask[None], summary["thresholds"][name],
                           PEAK)[0]
            got[f"{name}_signal"] = np.flatnonzero(signal)
            got[f"{name}_good"] = marks["label"][signal] == heads.LABEL[name]
        out.append(got)
    return out

