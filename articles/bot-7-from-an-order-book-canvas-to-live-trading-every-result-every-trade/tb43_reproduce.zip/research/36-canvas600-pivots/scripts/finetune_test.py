"""Етап 26: видача потенційно найкращих мереж на тесті — BTC після val — і на відкладених train.

Тест — моменти T, яких не бачили ні навчання, ні вибір W і θ: від першого T
після останнього T val (21.09 05:00 UTC) до кінця робочої копії `data/`
(дані датаколектора). Хід той самий, що в `canvas1100_buy.build_val`:

1. **Записи** — секунди BTC_USDT з `data/` від 14.08 (початок val) до
   останньої доби → записи 100 с і 30 с (`bars30.bars_of_frame`).
2. **Ноги й зони** — зігзаг 2.3 % по `open` записів (`canvas1100.legs_of`)
   на всьому ряду val + тест, півоти (`pivots_of`), дна й вершини лише ніг
   ≥ 7 год (`long_bottoms`), мітка «T у зоні» (`labels_of`) і шматки зон
   (`pivot_zones`) — кожен бік своїм `use_side`.
3. **Канва** в T — 1100 × 8 вікна 160 год, що закінчується в T
   (`canvas1100_buy.sample_of`, правило кластера 2 —
   `models/canvas1100_buy/assigner.json`), округлення до `float16`, як у
   канвах val. T без запису 100 с, що кінчається в T, не береться.
4. **Видача** — кожна мережа `results/finetune/networks.json` (ваги копії
   `models/finetune/<бік>/<прогін>_eNN.pt`) → P(T у зоні) на кожен T,
   `float16`, як видача val.

Зони в кінці ряду неповні: останній півот ще не підтверджений.

**Відкладені** (`--part held`) — T відкладених train BTC етапу 19
(08.07 20:30 … 12.08 05:00 UTC, `side == 1` у `data/canvas1100_buy/meta.npz`),
на яких під час навчання обиралась епоха: готові канви
`data/canvas1100_buy/x.npy`, мітки кожного боку — з `meta.npz` своєї теки,
зони — `pivot_zones` на півотах train, видача — ті самі ваги копії.

    python3 research/36-canvas600-pivots/scripts/finetune_test.py               # тест
    python3 research/36-canvas600-pivots/scripts/finetune_test.py --part held   # відкладені

Вихід: `results/finetune/test.json` і `results/finetune/held.json` — t, close,
зони й мітки обох боків і видача кожної мережі (`<бік>:<прогін>:<епоха>`).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
ROOT = RESEARCH.parents[1]
sys.path.insert(0, str(SCRIPTS))

import canvas1100 as c  # noqa: E402
import canvas1100_buy as buy  # noqa: E402
import canvas1100_early as early  # noqa: E402
import canvas1100_future_net as fnet  # noqa: E402
import canvas1100_random as rnd  # noqa: E402
from canvas600_data import with_neighbours  # noqa: E402
from data_source import load_day  # noqa: E402
from edges30_data import pivots_of  # noqa: E402
from edges30_net import device_of  # noqa: E402
import bars30  # noqa: E402

PAIR = buy.PAIR
BAR = buy.BAR
TEST_FROM = 1789967400            # 2026-09-21 05:10 UTC — перший T після останнього T val
SERIES_FROM = bars30.CUT          # 2026-08-14 — ряд для зігзага від початку val
NETWORKS = RESEARCH / "results" / "finetune" / "networks.json"
OUT = RESEARCH / "results" / "finetune" / "test.json"
HELD_OUT = RESEARCH / "results" / "finetune" / "held.json"
SIDES = {"buy": "bottom", "sell": "top"}


def records(bar: int, first: str, last: str = "9999-12-31") -> dict:
    """Записи `bar` с з добових файлів робочої копії, доба за добою."""
    pieces = []
    for path in bars30.day_files(PAIR, first, last):
        frame, _ = load_day(path)
        if len(frame):
            pieces.append(bars30.bars_of_frame(frame, bar))
    rec = {k: np.concatenate([one[k] for one in pieces]) for k in ("t", "open", "close")}
    _, keep = np.unique(rec["t"], return_index=True)
    return {k: v[keep] for k, v in rec.items()}


def series() -> dict:
    """Ряд val + тест: записи 100 с і 30 с, півоти зігзага 2.3 % на ньому."""
    rec = records(BAR, SERIES_FROM)
    legs = c.legs_of(rec)
    pivots = with_neighbours(pivots_of(legs, rec["close"]), len(rec["t"]))
    return {**rec, "bars": records(30, SERIES_FROM), "pivots": pivots, "pair": PAIR}


def moments(one: dict) -> np.ndarray:
    """Записи, що кінчаються на T тесту з повними 160 год до T."""
    ends = one["t"] + BAR
    return np.flatnonzero((ends % buy.STEP_T == 0) & (ends >= TEST_FROM)
                          & (ends - buy.BACK >= one["t"][0]))


def canvases(one: dict, index: np.ndarray, log=print) -> tuple:
    assigner = buy.assigner_of()
    x = np.zeros((len(index), buy.ROWS, len(buy.CHANNELS)), dtype=np.float16)
    mask = np.zeros((len(index), buy.ROWS), dtype=bool)
    started = time.time()
    for b in range(0, len(index), buy.READ):
        piece = index[b:b + buy.READ]
        first = int(one["t"][early.start_of(one, int(piece[0]), buy.HOURS)])
        holder = early.seconds_of(PAIR, first, int(one["t"][piece[-1]]) + BAR - 1)
        for k, e in enumerate(piece):
            x[b + k], mask[b + k] = buy.sample_of(one, holder, int(e), assigner)
        del holder
        log(f"канви тесту {b + len(piece)}/{len(index)}, {time.time() - started:.0f} с", flush=True)
    return x, mask


def run(device_name: str = "auto", log=print) -> dict:
    one = series()
    index = moments(one)
    t = (one["t"][index] + BAR).astype(np.int64)
    log(f"тест: {len(index)} T, {time.strftime('%Y-%m-%d %H:%M', time.gmtime(t[0]))} … "
        f"{time.strftime('%Y-%m-%d %H:%M', time.gmtime(t[-1]))} UTC")
    sides = {}
    for side, name in SIDES.items():
        buy.use_side(name)
        labels = buy.labels_of(one, index)[:, 0]
        zones = [z for z in buy.pivot_zones(one) if z[1] > t[0] - buy.STEP_T]
        sides[side] = {"labels": labels, "zones": zones}
        log(f"{side}: у зоні {int(labels.sum())} T, шматків зон {len(zones)}")
    buy.use_side("bottom")
    x, mask = canvases(one, index, log)
    data = {"x": x, "mask": mask, "labels": np.zeros((len(index), 1), dtype=np.float32)}
    return save(OUT, t, one["close"][index], sides, data, np.arange(len(index)), device_name, log)


def held(device_name: str = "auto", log=print) -> dict:
    """Відкладені train BTC етапу 19 — готові канви, мітки кожного боку з його `meta.npz`."""
    one = rnd.series_of(PAIR, "train")
    sides, base = {}, None
    for side, name in SIDES.items():
        buy.use_side(name)
        meta = buy.load()
        part = np.flatnonzero(meta["side"] == 1)
        t = meta["t"][part].astype(np.int64)
        base = base if base is not None else {"data": meta, "part": part, "t": t}
        if not np.array_equal(t, base["t"]):
            raise ValueError(f"{side}: T відкладених не ті самі, що в canvas1100_buy")
        zones = [z for z in buy.pivot_zones(one) if z[1] > t[0] - buy.STEP_T and z[0] <= t[-1]]
        sides[side] = {"labels": meta["labels"][part, 0], "zones": zones}
        log(f"{side}: у зоні {int(sides[side]['labels'].sum())} T, шматків зон {len(zones)}")
    buy.use_side("bottom")
    t = base["t"]
    log(f"відкладені: {len(t)} T, {time.strftime('%Y-%m-%d %H:%M', time.gmtime(t[0]))} … "
        f"{time.strftime('%Y-%m-%d %H:%M', time.gmtime(t[-1]))} UTC")
    close = one["close"][base["data"]["record"][base["part"]]]
    return save(HELD_OUT, t, close, sides, base["data"], base["part"], device_name, log)


def save(out_path: Path, t: np.ndarray, close: np.ndarray, sides: dict, data: dict, every: np.ndarray,
         device_name: str, log=print) -> dict:
    """Видача кожної мережі копії на T `every` канв `data` і запис ряду."""
    device = device_of(device_name)
    model = fnet.Future(channels=len(buy.CHANNELS), outputs=1).to(device)
    prob = {}
    for net in json.loads(NETWORKS.read_text(encoding="utf-8"))["networks"]:
        model.load_state_dict(torch.load(ROOT / net["weights"], map_location=device))
        p = fnet.predict(model, data, every, device)[:, 0].astype(np.float16)
        prob[f"{net['side']}:{net['run']}:{net['epoch']}"] = [round(float(v), 4) for v in p]
        log(f"{net['side']} {net['run']} е{net['epoch']}: видача на {len(every)} T", flush=True)
    out = {"pair": PAIR, "from": int(t[0]), "to": int(t[-1]), "t": [int(v) for v in t],
           "close": [round(float(v), 8) for v in close],
           "sides": {side: {"zone": [int(v) for v in got["labels"]],
                            "zones": [[int(a), int(b)] for a, b in got["zones"]]}
                     for side, got in sides.items()},
           "prob": prob}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    log(f"→ {out_path.relative_to(ROOT)}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--part", default="test", choices=("test", "held"),
                        help="test — після val, held — відкладені train")
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    (held if args.part == "held" else run)(args.device)


if __name__ == "__main__":
    main()
