"""Алгоритм на вікні канви: півот 2.3, корекція чи тіло — формулою по фічах.

Дослідження: research/36-canvas600-pivots/ → Етап 5

## Хід

1. **Вхід рядка** — вікно з 3 рядків навколо рядка `r` (`r − 1 … r + 1`,
   біля краю канви зсувається всередину), як уточнений сигнал:
   - `sum7` — рівень кожної фічі у вікні, `L[f] = (|x[r−1, f]| + |x[r, f]|
     + |x[r+1, f]|) / 3`, 7 чисел;
   - `cat21` — модулі трьох рядків підряд, 21 число.
2. **Формула** — три лінійні оцінки `z_k = Σ w_k · вхід + b_k` (тіло,
   корекція, півот 2.3), `p_k = softmax(z)_k`: багатокласова логістична
   регресія, ваги класів 1 / 3 / 3 як у мережі етапу 2, `C = 1`,
   стандартизація входу (ваги перераховані назад у сирі одиниці).
   Мітки — уточнені (`<part>_refined.npy`): рядок, де збігаються
   корекція й півот, уже півот; `−1` і мертві рядки не вчаться.
   Навчання — на 300 000 рядках ніг train без відкладених, seed 36.
3. **Сигнал і міра — як у мережі етапу 2** (`canvas600_net.scores`):
   сигнал класу — рядок, де `p` ≥ порогу і найбільша в ±10 рядках;
   добрий — у зоні свого класу; повнота — частка зон із сигналом
   уточнювача, у яких є сигнал; сплутано — сигнал півота в зоні корекції
   і навпаки. Поріг кожного класу — за F1 на відкладених 20 % ніг train
   (seed 0); val — тільки замір, по монетах окремо.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas600_rule.py

Вихід: results/canvas600_rule.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import canvas600_net as net  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FEATURES = ("d_up", "d_down", "d_resist_buy", "d_bal_resist_buy",
            "d_support_sell", "d_bal_support_sell", "d_price_avg")
KINDS = ("sum7", "cat21")
HALF = 1
ROWS_FIT = 300_000
CLASS_WEIGHT = {0: 1.0, 1: 3.0, 2: 3.0}
SEED = 36
CHUNK = 512


def window_rows(x: np.ndarray, half: int = HALF) -> np.ndarray:
    """`(N, rows, 7)` → модулі вікна кожного рядка `(N, rows, 2·half+1, 7)`;
    біля краю вікно зсувається всередину."""
    rows = x.shape[1]
    centre = np.clip(np.arange(rows), half, rows - 1 - half)
    index = centre[:, None] + np.arange(-half, half + 1)[None, :]
    return np.abs(np.asarray(x, dtype=np.float32))[:, index, :]


def inputs(x: np.ndarray, kind: str) -> np.ndarray:
    """Вхід формули на кожному рядку: `sum7` — `(N, rows, 7)`,
    `cat21` — `(N, rows, 21)`."""
    w = window_rows(x)
    if kind == "sum7":
        return w.mean(axis=2)
    return w.reshape(w.shape[0], w.shape[1], -1)


def fit(data: dict, index: np.ndarray, kind: str, rows: int = ROWS_FIT,
        seed: int = SEED) -> dict:
    """Логістична регресія на рядках вікон `index`; ваги в сирих одиницях."""
    from sklearn.linear_model import LogisticRegression
    rng = np.random.default_rng(seed)
    label = data["refined"][index]
    ok = (label >= 0) & data["mask"][index]
    where = np.argwhere(ok)
    if len(where) > rows:
        where = where[np.sort(rng.choice(len(where), rows, replace=False))]
    X, y = [], []
    for start in range(0, len(index), CHUNK):
        mine = where[(where[:, 0] >= start) & (where[:, 0] < start + CHUNK)]
        if not len(mine):
            continue
        got = inputs(data["x"][index[start:start + CHUNK]], kind)
        X.append(got[mine[:, 0] - start, mine[:, 1]])
        y.append(label[mine[:, 0], mine[:, 1]])
    X, y = np.concatenate(X).astype(np.float64), np.concatenate(y)
    mean, std = X.mean(axis=0), X.std(axis=0)
    std[std == 0] = 1.0
    model = LogisticRegression(C=1.0, class_weight=CLASS_WEIGHT, max_iter=1000)
    model.fit((X - mean) / std, y)
    weight = model.coef_ / std
    bias = model.intercept_ - weight @ mean
    return {"weight": weight.tolist(), "bias": bias.tolist(),
            "rows": int(len(y)),
            "classes": {str(k): int((y == k).sum()) for k in (0, 1, 2)}}


def probability(x: np.ndarray, formula: dict, kind: str,
                chunk: int = CHUNK) -> np.ndarray:
    """`p` трьох класів на кожному рядку: `(N, rows, 3)`."""
    weight = np.asarray(formula["weight"], dtype=np.float32)
    bias = np.asarray(formula["bias"], dtype=np.float32)
    out = []
    for start in range(0, len(x), chunk):
        z = inputs(x[start:start + chunk], kind) @ weight.T + bias
        z -= z.max(axis=-1, keepdims=True)
        e = np.exp(z)
        out.append((e / e.sum(axis=-1, keepdims=True)).astype(np.float32))
    return np.concatenate(out) if out else np.zeros((0, x.shape[1], 3), np.float32)


def names_of(kind: str) -> list:
    if kind == "sum7":
        return list(FEATURES)
    return [f"{name}[{shift:+d}]" for shift in range(-HALF, HALF + 1)
            for name in FEATURES]


def run(kind: str, train: dict, val: dict, log=print) -> dict:
    inside, held = net.split(train["leg"])
    formula = fit(train, inside, kind)
    log(kind, "формула на", formula["rows"], "рядках", formula["classes"])
    held_prob = probability(train["x"][held], formula, kind)
    thresholds = net.best_thresholds(held_prob, train, held)
    out = {"formula": formula, "inputs": names_of(kind),
           "thresholds": thresholds,
           "holdout": net.scores(held_prob, train, held, thresholds)}
    del held_prob
    val_prob = probability(val["x"], formula, kind)
    out["val"] = net.by_pair(val_prob, val, thresholds)
    log(kind, "пороги", thresholds,
        {k: round(v["f1"], 3) for k, v in out["holdout"].items()},
        {k: round(v["f1"], 3) for k, v in out["val"]["all"].items()})
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--results", type=Path, default=RESULTS)
    args = parser.parse_args()
    train, val = net.load("train"), net.load("val")
    out = {"half": HALF, "rows_fit": ROWS_FIT, "class_weight": CLASS_WEIGHT,
           "seed": SEED, "peak": net.PEAK}
    for kind in KINDS:
        out[kind] = run(kind, train, val)
    (args.results / "canvas600_rule.json").write_text(
        json.dumps(net.clean(out), ensure_ascii=False, indent=1),
        encoding="utf-8")


if __name__ == "__main__":
    main()
