"""Етап 4: мережа знаходить на канві 600 події кластера 1 k-means.

Дослідження: research/36-canvas600-pivots/ → Етап 4

## Хід

1. **Правило кластера 1** (`assigner`). Кластер 1 k-means (карта
   `cosine`, «рух без рівнів») визначений лише на точках карти UMAP.
   Логістична регресія (C = 1, seed 36) на векторі уточненого сигналу
   тих самих точок train — 21 число, `|x|` вікна `пік ± 1` рядок × 7
   фіч — вчиться віддавати кластер 1; перевірка — на точках val проти
   їхнього власного k-means.
2. **Мітки рядків** (`c1_labels`) для всіх вікон train і val. Для кожної
   зони півота 2.3 і корекції 0.8 вікна — пік уточнювача (рядок півота
   ± P, стандарт дослідження) і його вектор; якщо сила піку ≥ τ і
   правило каже «кластер 1» — рядки уточненого сигналу цієї зони
   отримують `1`; сигнал кластера 2 — `0`; тіло — `0`; решта рядків
   зон і рядки з уточненою міткою `−1` — `−1` (не вчиться). Для рядка
   зберігається номер зони кластера 1 (`−1` — немає).
3. **Мережа** — `Finder3` етапу 2 з двома виходами (не подія / подія
   кластера 1), крос-ентропія з вагами 1 / 3, батч 32 кусками по 8,
   Adam lr 1e-3, відкладені 20 % ніг train (seed 0), епоха й поріг — за
   F1 на відкладених, стоп після 3 епох без покращення, стеля 30.
4. **Міри на вікнах**: сигнал — пік імовірності ≥ порогу в ±10 рядках;
   добрий — рядок у зоні з сигналом кластера 1; повнота — частка таких
   зон, у яких є сигнал; і куди лягають сигнали — у зону півота 2.3,
   у зону корекції, поза зонами.
5. **Ряд val** (`--outputs`) — ті самі ковзні вікна, що в етапі 3
   (`canvas600_data.py --series`), найкраща епоха ± 2: імовірність
   запису — найбільша з вікон, сигнал — пік ≥ порогу в ±60 записах;
   частка сигналів у зонах півотів 2.3, у зонах корекцій і поза
   зонами; повнота півотів і корекцій.
6. **Канва руками з правилом** (`rule_probe`) — відрізок ряду, обраний на
   дашборді, у канву 600; правило кластера 1 ковзним вікном з 3 рядків з
   кроком 1 (`rule_rows`): імовірність вікна, рядок у зоні кластера 1,
   коли його накриває хоч одне вікно з імовірністю > 0.5; правда — зони
   півотів 2.3 і корекцій 0.8 у канві. На тій самій канві — мережа
   етапу 2 (найкраща епоха): P(півот 2.3) рядків і сигнали за її порогом.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas600_c1.py --labels
    python3 research/36-canvas600-pivots/scripts/canvas600_c1.py
    python3 research/36-canvas600-pivots/scripts/canvas600_c1.py --outputs

Вихід: data/canvas600/<part>_c1.npy, <part>_c1_owner.npy;
models/canvas600_c1/epoch_NN.pt, history.json, assigner.json;
results/canvas600_c1.json, results/c1/series_<PAIR>_eNN.npz.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import canvas600_net as net  # noqa: E402
import canvas600_signal as sig  # noqa: E402
from canvas600_data import OUT as DATA  # noqa: E402
from edges30_net import device_of, peaks, split  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

RESEARCH = SCRIPTS.parent
MODELS = RESEARCH / "models" / "canvas600_c1"
RESULTS = RESEARCH / "results"
METRIC = "cosine"
CLUSTER = 0                      # кластер 1 у нумерації k-means
CLASS_WEIGHT = (1.0, 3.0)
EPOCHS, PATIENCE = 30, 3
SEED = 0
MEMORY_NEED = 800


# --- 1. правило кластера 1 ------------------------------------------------

def point_vectors(store: dict, best: dict, one: dict) -> np.ndarray:
    """Вектори точок карти UMAP: `|x|` вікна `пік ± h` × 7."""
    out = np.asarray([sig.window_at(store["x"][w], r, best["half"]).ravel()
                      for w, r in zip(one["window"], one["row"])],
                     dtype=np.float32)
    return np.abs(out) if best["repr"] == "abs" else out


def fit_assigner(results: Path = RESULTS, data: Path = DATA) -> dict:
    """Логістична регресія «вектор сигналу → кластер 1» на точках train;
    замір на точках val проти їхнього k-means."""
    from sklearn.linear_model import LogisticRegression
    maps = json.loads((results / "canvas600_umap.json").read_text(
        encoding="utf-8"))
    best = json.loads((results / "canvas600.json").read_text(
        encoding="utf-8"))["best"]
    out = {"metric": METRIC, "cluster": CLUSTER + 1}
    model = None
    for part in ("train", "val"):
        store = sig.load(part, data)
        x = point_vectors(store, best, maps[part])
        y = np.asarray(maps["kmeans"][part][METRIC]["labels"]) == CLUSTER
        if part == "train":
            model = LogisticRegression(C=1.0, max_iter=2000,
                                       random_state=36).fit(x, y)
            out["coef"] = model.coef_[0].tolist()
            out["intercept"] = float(model.intercept_[0])
        guess = model.predict(x)
        out[part] = {"points": int(len(y)), "accuracy": float((guess == y).mean()),
                     "cluster1": int(y.sum()),
                     "auc": sig.auc(model.decision_function(x)[y],
                                    model.decision_function(x)[~y])}
    return out


def is_cluster1(vector: np.ndarray, assigner: dict) -> bool:
    return float(np.dot(vector, assigner["coef"]) + assigner["intercept"]) > 0


# --- 2. мітки рядків -----------------------------------------------------

def c1_labels(store: dict, best: dict, assigner: dict,
              chunk: int = 256) -> tuple:
    """Мітка рядків «подія кластера 1» і номер такої зони для кожного рядка."""
    meta, zones = store["meta"], store["zones"]
    refined = store["refined"]
    local = sig.local_numbers(zones)
    label = np.where(refined >= 0, 0, -1).astype(np.int8)
    label[refined > 0] = -1                     # зони — поки не вирішено
    owner = np.full(refined.shape, -1, dtype=np.int32)
    by_window = {}
    for number, window in enumerate(zones["window"]):
        by_window.setdefault(int(window), []).append(number)
    count = {"zones": 0, "signal": 0, "cluster1": 0}
    for begin in range(0, len(label), chunk):
        stop = min(begin + chunk, len(label))
        s = sig.strength(np.asarray(store["x"][begin:stop]),
                         tuple(best["features"]), best["half"], best["stat"])
        for window in range(begin, stop):
            for number in by_window.get(window, []):
                role = str(zones["role"][number])
                value = 1 if role == "corr" else 2
                rows = sig.zone_rows_of(meta, window, int(local[number]), role)
                mine = rows[refined[window, rows] == value]
                count["zones"] += 1
                if not len(mine):
                    continue
                count["signal"] += 1
                search = sig.search_rows(meta["mask"][window],
                                         sig.pivot_row(meta, window,
                                                       int(zones["index"][number])),
                                         best["reach"])
                peak = sig.peak_of(s[window - begin], search)
                vector = sig.window_at(store["x"][window], peak,
                                       best["half"]).ravel()
                if best["repr"] == "abs":
                    vector = np.abs(vector)
                if is_cluster1(vector, assigner):
                    label[window, mine] = 1
                    owner[window, mine] = number
                    count["cluster1"] += 1
                else:
                    label[window, mine] = np.where(label[window, mine] == 1,
                                                   1, 0)
    return label, owner, count


def cover(p: np.ndarray, mask: np.ndarray, half: int = 1) -> tuple:
    """Імовірність рядка — найбільша з вікон, що його накривають; рядок у
    зоні, коли вона > 0.5."""
    rows = len(p)
    prob = np.zeros(rows)
    for shift in range(-half, half + 1):
        index = np.clip(np.arange(rows) + shift, 0, rows - 1)
        prob = np.maximum(prob, p[index])
    prob = np.where(mask, prob, 0.0)
    return prob, prob > 0.5


def rule_rows(net_x: np.ndarray, mask: np.ndarray, assigner: dict,
              half: int = 1) -> tuple:
    """Правило кластера 1 ковзним вікном `2·half + 1` рядків з кроком 1:
    імовірність кожного вікна (центр — рядок), а рядок належить зоні
    кластера 1, коли його накриває хоч одне вікно з імовірністю > 0.5.
    Імовірність рядка — найбільша з вікон, що його накривають."""
    rows = len(net_x)
    centre = np.clip(np.arange(rows), half, rows - 1 - half)
    windows = np.stack([np.abs(net_x[c - half:c + half + 1]).ravel()
                        for c in centre])
    p = 1.0 / (1.0 + np.exp(-(windows @ np.asarray(assigner["coef"])
                              + assigner["intercept"])))
    p = np.where(mask, p, 0.0)
    prob, zone = cover(p, mask, half)
    return p, prob, zone


def rule_probe(pair: str, first: int, last: int, part: str = "val",
               data: Path | None = None, folder: Path = MODELS,
               root: Path | None = None) -> dict:
    """Канва 600 з відрізка `[first, last]` (секунди UTC) і правило
    кластера 1 ковзним вікном з 3 рядків; правда — зони півотів 2.3 і
    корекцій 0.8 у канві."""
    import canvas600_data as d
    from bars30 import BAR, DATA as BARS, read_seconds
    data = data or BARS
    with np.load(data / f"{pair}_{part}.npz") as store:
        stamps, opens, close = store["t"], store["open"], store["close"]
    start = int(np.searchsorted(stamps, first, side="left"))
    end = int(np.searchsorted(stamps, last, side="right")) - 1
    start, end = max(start, 0), min(end, len(stamps) - 1)
    if end - start + 1 < d.ROWS:
        raise ValueError(f"відрізок коротший за {d.ROWS} записів (5 год)")
    legs = json.loads((data / "legs.json").read_text(encoding="utf-8"))[
        "legs"][pair][part]
    pivots = d.with_neighbours(d.pivots_of(legs, close), len(close))
    corrections = d.corrections_of(legs, opens, close, pivots)
    holder = read_seconds(pair, int(stamps[start]),
                          int(stamps[end]) + BAR - 1, {}, root)
    got = d.canvas_of(holder, stamps, opens, close, start, end)
    marks = d.label_rows(start, end, got["first"], got["last"], close,
                         pivots, corrections)
    assigner = json.loads((folder / "assigner.json").read_text(encoding="utf-8"))
    window, prob, zone = rule_rows(got["net"], got["mask"], assigner)
    # кластер 2 — те саме вікно, імовірність 1 − p (кластерів два)
    prob2, zone2 = cover(np.where(got["mask"], 1.0 - window, 0.0),
                         got["mask"])
    live = got["first"] >= 0
    out = {"pair": pair, "start": start, "end": end,
           "t": stamps[start:end + 1], "close": close[start:end + 1],
           "live": live, "prob": prob, "zone": zone, "label": marks["label"],
           "prob2": prob2, "zone2": zone2,
           "row_start": np.where(live, stamps[start + np.maximum(got["first"], 0)], 0),
           "row_end": np.where(live, stamps[start + np.maximum(got["last"], 0)] + BAR, 0)}
    for name, table in (("pivot", pivots), ("corr", corrections)):
        inside = (table["index"] >= start) & (table["index"] <= end)
        out[f"{name}_index"] = table["index"][inside] - start
        out[f"{name}_top"] = table["top"][inside]
        out[f"{name}_zone"] = table["zone"][inside]
        out[f"{name}_span"] = table["span"][inside]
    # півоти 2.3 на тій самій канві — мережа етапу 2, найкраща епоха
    history = json.loads((net.MODELS / "history.json").read_text(encoding="utf-8"))
    epoch = history["best_epoch"]
    threshold = next(one["thresholds"]["pivot"] for one in history["history"]
                     if one["epoch"] == epoch)
    device = torch.device("cpu")
    one = {"x": got["net"][None], "numbers": net.scalars_of(got["scalars"][None])}
    pivot_prob = net.predict(net.model_of(epoch, device), one, np.array([0]),
                             device)[0][:, 2]
    signal = peaks(pivot_prob[None], got["mask"][None], threshold, net.PEAK)[0]
    out.update({"pivot_epoch": epoch, "pivot_threshold": float(threshold),
                "pivot_prob": pivot_prob,
                "pivot_signal": np.flatnonzero(signal),
                "pivot_good": marks["label"][signal] == 2})
    label = marks["label"]
    out["counts"] = {
        "rows": int(live.sum()), "cluster1": int(zone.sum()),
        "cluster1_pivot": int((zone & (label == 2)).sum()),
        "cluster1_corr": int((zone & (label == 1)).sum()),
        "pivot_rows": int((label == 2).sum()), "corr_rows": int((label == 1).sum()),
        "pivot_rows_c1": int((zone & (label == 2)).sum()),
        "corr_rows_c1": int((zone & (label == 1)).sum()),
        "cluster2": int(zone2.sum()),
        "pivot_rows_c2": int((zone2 & (label == 2)).sum()),
        "corr_rows_c2": int((zone2 & (label == 1)).sum())}
    return out


def load(part: str, folder: Path = DATA) -> dict:
    out = net.load(part, folder)
    out["target"] = np.load(folder / f"{part}_c1.npy")
    out["c1owner"] = np.load(folder / f"{part}_c1_owner.npy")
    return out


# --- 3. мережа -----------------------------------------------------------

def loss_of(logits: torch.Tensor, label: torch.Tensor,
            mask: torch.Tensor) -> torch.Tensor:
    live = mask & (label >= 0)
    target = label.clamp(min=0).long()
    w = torch.tensor(CLASS_WEIGHT, device=logits.device)[target] * live
    each = F.cross_entropy(logits.permute(0, 2, 1), target, reduction="none")
    return (each * w).sum() / w.sum().clamp(min=1e-6)


def score(signal: np.ndarray, data: dict, index: np.ndarray) -> dict:
    """Точність і повнота на зонах кластера 1; куди лягають сигнали."""
    own = data["c1owner"][index]
    pivot = data["pivot"][index] >= 0
    corr = data["corr"][index] >= 0
    signals = int(signal.sum())
    good = int((signal & (own >= 0)).sum())
    total = found = 0
    for row_signal, row_own in zip(signal, own):
        zones = set(row_own[row_own >= 0].tolist())
        total += len(zones)
        found += len(zones & set(row_own[row_signal].tolist()))
    precision = good / signals if signals else float("nan")
    recall = found / total if total else float("nan")
    return {"signals": signals, "good": good, "zones": total, "found": found,
            "precision": precision, "recall": recall,
            "f1": (2 * precision * recall / (precision + recall)
                   if signals and total and precision + recall > 0 else 0.0),
            "in_pivot": int((signal & pivot).sum()),
            "in_corr": int((signal & corr & ~pivot).sum()),
            "outside": int((signal & ~pivot & ~corr).sum())}


def best_threshold(prob: np.ndarray, data: dict, index: np.ndarray) -> float:
    mask = data["mask"][index]
    return float(max(net.THRESHOLDS, key=lambda t: score(
        peaks(prob, mask, t, net.PEAK), data, index)["f1"]))


def by_pair(prob: np.ndarray, data: dict, threshold: float) -> dict:
    index = np.arange(len(data["leg"]))
    signal = peaks(prob, data["mask"], threshold, net.PEAK)
    out = {"all": score(signal, data, index)}
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        out[str(pair)] = score(signal[where], data, where)
    return out


def train(train_part: dict, val: dict, device: torch.device, log=print,
          folder: Path = MODELS) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    inside, held = split(train_part["leg"])
    folder.mkdir(parents=True, exist_ok=True)
    model = net.Finder3(outputs=2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=net.LR)
    history, best = [], None
    val_index = np.arange(len(val["leg"]))
    for epoch in range(1, EPOCHS + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for start in range(0, len(order), net.BATCH):
            pick = np.sort(order[start:start + net.BATCH])
            optimizer.zero_grad()
            for piece in range(0, len(pick), net.MICRO):
                part = pick[piece:piece + net.MICRO]
                loss = loss_of(
                    model(torch.from_numpy(np.asarray(train_part["x"][part])).to(device),
                          torch.from_numpy(train_part["numbers"][part]).to(device)),
                    torch.from_numpy(train_part["target"][part]).to(device),
                    torch.from_numpy(train_part["mask"][part]).to(device))
                (loss * len(part) / len(pick)).backward()
                total += float(loss.detach()) * len(part)
                count += len(part)
            optimizer.step()
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        held_prob = net.predict(model, train_part, held, device)[..., 1]
        threshold = best_threshold(held_prob, train_part, held)
        held_score = score(peaks(held_prob, train_part["mask"][held],
                                 threshold, net.PEAK), train_part, held)
        val_prob = net.predict(model, val, val_index, device)[..., 1]
        val_score = by_pair(val_prob, val, threshold)
        step = {"epoch": epoch, "train_loss": total / count,
                "threshold": threshold, "holdout": held_score,
                "val": val_score, "seconds": round(time.time() - started, 1)}
        history.append(step)
        v = val_score["all"]
        log(f"епоха {epoch:2d}: втрата {step['train_loss']:.4f} · відкладені "
            f"F1 {held_score['f1']:.3f} (поріг {threshold:.2f}) · val P "
            f"{v['precision']:.3f} R {v['recall']:.3f} F1 {v['f1']:.3f} · "
            f"{step['seconds']} c")
        if best is None or held_score["f1"] > best["holdout"]["f1"]:
            best = step
        (folder / "history.json").write_text(json.dumps(net.clean({
            "config": {"width": net.WIDTH, "heads": net.HEADS,
                       "layers": net.LAYERS, "lr": net.LR,
                       "batch": net.BATCH, "micro": net.MICRO,
                       "class_weight": list(CLASS_WEIGHT), "peak": net.PEAK,
                       "patience": PATIENCE, "epochs": EPOCHS, "seed": SEED},
            "best_epoch": best["epoch"], "history": history}),
            ensure_ascii=False, indent=1), encoding="utf-8")
        if epoch - best["epoch"] >= PATIENCE:
            log(f"{PATIENCE} епохи без покращення — стоп, найкраща "
                f"{best['epoch']}")
            break
    return {"history": history, "best": best}


# --- 5. ряд val ------------------------------------------------------------

def outputs(device: torch.device, log=print, folder: Path = MODELS,
            data_dir: Path = DATA, results: Path = RESULTS) -> None:
    import canvas600_data as d
    from bars30 import DATA as BARS
    from edges30_net import record_zones, series_signals
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    best = history["best_epoch"]
    steps = {one["epoch"]: one for one in history["history"]}
    epochs = [e for e in steps if abs(e - best) <= net.AROUND]
    series = {name: value for name, value in
              np.load(data_dir / "series.npz").items()}
    series["x"] = np.load(data_dir / "series_x.npy", mmap_mode="r")
    series["numbers"] = net.scalars_of(series["scalars"])
    table = json.loads((BARS / "legs.json").read_text(encoding="utf-8"))
    out = results / "c1"
    out.mkdir(parents=True, exist_ok=True)
    assigner = json.loads((folder / "assigner.json").read_text(encoding="utf-8"))
    report = {"best_epoch": best, "epochs": epochs, "assigner": assigner,
              "val": {}}
    marks = {}
    for pair in np.unique(series["pair"]):
        pair = str(pair)
        with np.load(BARS / f"{pair}_val.npz") as store:
            opens, close = store["open"], store["close"]
        legs = table["legs"][pair]["val"]
        pivots = d.with_neighbours(d.pivots_of(legs, close), len(close))
        corrections = d.corrections_of(legs, opens, close, pivots)
        marks[pair] = {"pivot": pivots, "corr": corrections,
                       "zones": {"pivot": record_zones(close, pivots),
                                 "corr": record_zones(close, corrections)},
                       "size": len(close)}
    for epoch in epochs:
        model = net.Finder3(outputs=2).to(device)
        model.load_state_dict(torch.load(folder / f"epoch_{epoch:02d}.pt",
                                         map_location=device))
        threshold = steps[epoch]["threshold"]
        prob = net.predict(model, series, np.arange(len(series["pair"])),
                           device)[..., 1]
        one = {"threshold": threshold, "windows": steps[epoch]["val"],
               "series": {}}
        for pair, mark in marks.items():
            pick = np.flatnonzero(series["pair"] == pair)
            curve = net.series_curve(prob, series, pick, mark["size"])
            signals = series_signals(curve, threshold)
            pz = mark["zones"]["pivot"][signals]
            cz = mark["zones"]["corr"][signals]
            one["series"][pair] = {
                "signals": int(len(signals)),
                "in_pivot": int((pz >= 0).sum()),
                "in_corr": int(((pz < 0) & (cz >= 0)).sum()),
                "outside": int(((pz < 0) & (cz < 0)).sum()),
                "pivots": int(len(mark["pivot"]["index"])),
                "pivots_found": len(set(pz[pz >= 0].tolist())),
                "corrs": int(len(mark["corr"]["index"])),
                "corrs_found": len(set(cz[cz >= 0].tolist()))}
            np.savez_compressed(
                out / f"series_{pair}_e{epoch:02d}.npz",
                prob=curve.astype(np.float16), signals=signals,
                in_pivot=pz >= 0, in_corr=(pz < 0) & (cz >= 0),
                threshold=np.float32(threshold))
        report["val"][str(epoch)] = one
        log(f"епоха {epoch}: ряд val готовий")
    (results / "canvas600_c1.json").write_text(
        json.dumps(net.clean(report), ensure_ascii=False, indent=1),
        encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--labels", action="store_true",
                        help="правило кластера 1 і мітки рядків")
    parser.add_argument("--outputs", action="store_true",
                        help="ряд val на найкращій епосі ± 2")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.labels:
        MODELS.mkdir(parents=True, exist_ok=True)
        assigner = fit_assigner()
        (MODELS / "assigner.json").write_text(
            json.dumps(assigner, ensure_ascii=False, indent=1), encoding="utf-8")
        print({k: v for k, v in assigner.items() if k not in ("coef",)})
        best = json.loads((RESULTS / "canvas600.json").read_text(
            encoding="utf-8"))["best"]
        counts = {}
        for part in ("train", "val"):
            store = sig.load(part)
            store["refined"] = np.load(DATA / f"{part}_refined.npy")
            label, owner, count = c1_labels(store, best, assigner)
            np.save(DATA / f"{part}_c1.npy", label)
            np.save(DATA / f"{part}_c1_owner.npy", owner)
            counts[part] = {**count, "rows1": int((label == 1).sum()),
                            "rows0": int((label == 0).sum()),
                            "ignored": int((label < 0).sum())}
            print(part, counts[part])
        assigner["labels"] = counts
        (MODELS / "assigner.json").write_text(
            json.dumps(assigner, ensure_ascii=False, indent=1), encoding="utf-8")
        return
    no_swap(MEMORY_NEED, args.force)
    device = device_of(args.device)
    print(f"пристрій: {device}")
    if args.outputs:
        outputs(device)
        return
    got = train(load("train"), load("val"), device)
    print(f"найкраща епоха {got['best']['epoch']}")


if __name__ == "__main__":
    main()
