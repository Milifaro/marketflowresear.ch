"""Етап 1: канва 600 — вікна навколо ніг, півоти 2.3 і корекції 0.8 по рядках.

Дослідження: research/36-canvas600-pivots/ → Етап 1

## Хід

1. Записи 30 с і ноги зігзага 2.3 % — етап 3 дослідження 35
   (`research/35-leg-fullness/data/bars30/legs.json`, `<PAIR>_<part>.npz`);
   train до 2026-08-14, val 14.08 … 22.09. Якорем вікна стає лише нога
   ≥ `MIN_LEG` записів (7 год); коротші лишаються в розмітці.
2. **Півоти 2.3** — `edges30_data.pivots_of`: кінці ніг і початок першої,
   ціна — `close` запису; зона — `p ± 0.05·L` записів і 10 % цінової
   довжини ноги, яку півот закінчує.
3. **Корекції 0.8** — усередині кожної ноги 2.3 (від півота до півота)
   зігзаг 0.8 % по `open` записів і `snap` на екстремум `close` у ±25
   записах (`rules/02-markup.md` → Точка кінця ноги). Корекція — кожен
   внутрішній півот 0.8, далі за 25 записів від обох півотів 2.3 (ті,
   що ближче, — це самі краї ноги). Зона — від відрізка 0.8, який
   півот закінчує: `q ± 0.05·(q − q₋)` записів і 10 % його цінової довжини.
4. **Вікна** (`plan_windows`, seed `SEED`) на кожну ногу-якір довжини `L`:
   - `base` — `first − 0.1·L … last + 0.1·L`: нога на рядках 50 … 549;
   - `shift` × `SHIFTS` — та сама ширина, зсув на `δ·L`, `δ ~ U[−1, 1]`:
     у канві один півот ноги, жодного чи сусідні;
   - `inner` × `INNERS` — ширина `U[0.3, 0.8]·L`, не менше 600 записів,
     цілком усередині ноги (без півотів 2.3 цієї ноги);
   - `long` — від `first − 0.1·Lₜ` до кінця 1.5, 2 і 3 ніг підряд
     (`Lₜ` — записи всіх узятих ніг), якщо ноги є;
   - `near` — корекція біля півота: на кожну корекцію ноги ближче
     `0.2·L` до її початку чи кінця (до 4 на ногу) вікно ширини
     `max(U[0.5, 0.8]·L, 600)` з центром посередині між корекцією і
     півотом, зсув центру `U[−0.1, 0.1]·L`: корекція і півот в одній
     канві.
   Вікно ≥ 600 записів: канва тільки стискається.
5. **Канва** — `windows30.window_canvas(rows=600)`: 600 відрізків на
   межах записів, клас `клас210х10-1х7д/д`, нормування тільки на канву,
   без стовпця маски. Скаляри — `log1p(записів)`, `log1p(крок, с)`,
   `log(close/open)` вікна, частка живих рядків.
6. **Розмітка рядка**: рядок у зоні, коли хоча б один його запис у ній і за
   часом, і за ціною. `2` — зона півота 2.3 у вікні; `1` — зона корекції
   у вікні (і не півота); `0` — тіло; `−1` — зона півота чи корекції, що
   сама поза вікном. Для кожного рядка — номер зони півота і зони
   корекції (`−1` — немає); перелік зон вікна — роль (`start`, `end` —
   краї ноги-якоря, `pivot` — інші півоти 2.3, `corr` — корекція),
   запис, вершина / дно, нога.
7. **Ряд val** (`--series`) — ковзні вікна без розмітки: 2400 записів
   (20 год), крок 300 записів, по всьому ряду val кожної монети; для
   кожного рядка — його перший і останній запис.
8. **Графік** (`--marks`) — півоти 2.3 і корекції 0.8 ряду train кожної
   монети з шириною їхніх зон: ціна train під ними на вкладці.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas600_data.py
    python3 research/36-canvas600-pivots/scripts/canvas600_data.py --marks
    python3 research/36-canvas600-pivots/scripts/canvas600_data.py --series

Вихід: data/canvas600/<part>_x.npy (memmap `N × 600 × 7`), <part>.npz —
маска, мітка, номери зон рядків, скаляри, вікно; <part>_zones.npz —
перелік зон; series_x.npy, series.npz — ковзні вікна ряду val;
results/marks/<PAIR>_train.npz — півоти й корекції ряду.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
PROJECT = RESEARCH.parents[1]
for extra in (PROJECT / "research" / "35-leg-fullness" / "scripts",
              PROJECT / "rules" / "scripts"):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

import classes30  # noqa: E402
from bars30 import BAR, DATA, PARTS, edges_of, read_seconds  # noqa: E402
from edges30_data import pivots_of, row_records  # noqa: E402
from windows30 import window_canvas  # noqa: E402
from zigzag import SNAP_SPAN, snap, zigzag  # noqa: E402

OUT = RESEARCH / "data" / "canvas600"
MARKS = RESEARCH / "results" / "marks"
KEY = classes30.DEFAULT
ROWS = 600
MARGIN = 0.1                   # частка ноги в полі з кожного боку
MIN_LEG = 840                  # 7 годин записів 30 с
INNER_THRESHOLD = 0.008
ZONE, SPAN = 0.10, 0.05
SHIFTS, INNERS = 4, 2
LONGS = (1.5, 2.0, 3.0)
SERIES_BARS, SERIES_STEP = 2400, 300   # ряд val: 20 год, крок 2.5 год
NEAR, NEAR_MAX = 0.2, 4        # корекція біля півота: ближче 0.2·L, до 4 на ногу
SEED = 36
ROLES = ("start", "end", "pivot", "corr")


def corrections_of(legs: list, opens: np.ndarray, closes: np.ndarray,
                   pivots: dict, threshold: float = INNER_THRESHOLD,
                   span: int = SNAP_SPAN) -> dict:
    """Внутрішні півоти 0.8 усіх ніг частини і ширина їхніх зон."""
    out = {"index": [], "top": [], "price": [], "zone": [], "span": [],
           "left": [], "right": [], "leg": []}
    edge = pivots["index"]
    for a, b in zip(edge[:-1], edge[1:]):
        if b - a < 2:
            continue
        found = snap(zigzag(opens[a:b + 1], threshold), closes[a:b + 1],
                     span)
        inner = [one for one in found
                 if span < one.index < (b - a) - span]
        chain = [a] + [a + one.index for one in inner] + [b]
        for number, one in enumerate(inner, start=1):
            q, before = chain[number], chain[number - 1]
            out["index"].append(q)
            out["top"].append(one.kind == "high")
            out["price"].append(closes[q])
            out["zone"].append(ZONE * abs(closes[q] - closes[before]))
            out["span"].append(SPAN * (q - before))
            out["left"].append(before)
            out["right"].append(chain[number + 1])
            out["leg"].append(int(np.searchsorted(edge, q)) - 1)
    kinds = {"index": np.int64, "top": bool, "leg": np.int64,
             "left": np.int64, "right": np.int64}
    return {name: np.asarray(value, dtype=kinds.get(name, float))
            for name, value in out.items()}


def with_neighbours(pivots: dict, size: int) -> dict:
    """Межі «сусідства» півота 2.3 — сусідні півоти (край ряду для крайніх)."""
    index = pivots["index"]
    out = dict(pivots)
    out["left"] = np.concatenate([[0], index[:-1]]).astype(np.int64)
    out["right"] = np.concatenate([index[1:], [size - 1]]).astype(np.int64)
    return out


def row_extremes(start: int, first: np.ndarray, last: np.ndarray,
                 close: np.ndarray) -> tuple:
    """Записи рядка в ряду частини і найвищий / найнижчий `close` рядка."""
    rows = len(first)
    a, b = first + start, last + start
    high, low = np.full(rows, -np.inf), np.full(rows, np.inf)
    live = np.flatnonzero(first >= 0)
    if len(live):
        piece = close[:b[live[-1]] + 1]
        starts = a[live]
        high[live] = np.maximum.reduceat(piece, starts)
        low[live] = np.minimum.reduceat(piece, starts)
        same = np.append(starts[1:] == starts[:-1], False)
        high[live[same]] = close[starts[same]]
        low[live[same]] = close[starts[same]]
    return a, b, high, low, first >= 0


def zone_rows(rows: tuple, pivots: dict, number: int) -> np.ndarray:
    """Рядки зони півота `number`: перетин часу (`p ± span`) і ціни."""
    a, b, high, low, alive = rows
    p = pivots["index"][number]
    near = alive & (b >= pivots["left"][number]) & (a <= pivots["right"][number])
    if not near.any():
        return near
    width = max(pivots["zone"][number], 1e-12)
    gap = (pivots["price"][number] - high if pivots["top"][number]
           else low - pivots["price"][number])
    reach = max(pivots["span"][number], 0.5)
    late = np.maximum(np.maximum(p - b, a - p), 0) / reach
    return near & (np.maximum(np.maximum(gap, 0.0) / width, late) <= 1.0)


def label_rows(start: int, end: int, first: np.ndarray, last: np.ndarray,
               close: np.ndarray, pivots: dict, corrections: dict,
               anchor: tuple | None = None) -> dict:
    """Мітка рядків вікна `[start, end]` і перелік його зон.

    `anchor` — (півот початку, півот кінця) ноги-якоря: їхні зони мають
    ролі `start` і `end`, решта півотів 2.3 — `pivot`."""
    rows = row_extremes(start, first, last, close)
    size = len(first)
    label = np.zeros(size, dtype=np.int8)
    owner = {"pivot": np.full(size, -1, dtype=np.int32),
             "corr": np.full(size, -1, dtype=np.int32)}
    zones = []
    hidden = np.zeros(size, dtype=bool)
    for kind, table in (("corr", corrections), ("pivot", pivots)):
        index = table["index"]
        if not len(index):
            continue
        # зона може зачепити вікно, лише коли півот біля нього
        lo = np.searchsorted(index, start - (end - start) - 1)
        hi = np.searchsorted(index, end + (end - start) + 1)
        for number in range(lo, hi):
            got = zone_rows(rows, table, number)
            if not got.any():
                continue
            p = int(index[number])
            if not start <= p <= end:
                hidden |= got
                continue
            role = kind
            if kind == "pivot" and anchor is not None:
                role = ("start" if p == anchor[0] else
                        "end" if p == anchor[1] else "pivot")
            owner[kind][got] = len(zones)
            zones.append({"role": role, "index": p,
                          "top": bool(table["top"][number]),
                          "rows": np.flatnonzero(got)})
    label[owner["corr"] >= 0] = 1
    label[owner["pivot"] >= 0] = 2
    label[hidden & (label == 0)] = -1
    return {"label": label, "pivot": owner["pivot"], "corr": owner["corr"],
            "zones": zones}


def near_windows(leg: dict, corrections: np.ndarray, rng,
                 rows: int = ROWS) -> list:
    """Вікна «корекція біля півота»: корекції ноги ближче `NEAR·L` до її
    початку чи кінця, до `NEAR_MAX` на ногу; вікно ширини
    `max(U[0.5, 0.8]·L, 600)` з центром посередині між корекцією і
    півотом, зсув центру `U[−0.1, 0.1]·L`."""
    length = leg["bars"]
    start, end = leg["first"] - 1, leg["last"]
    reach = NEAR * length
    close = [(int(q), start if q - start <= end - q else end)
             for q in corrections
             if start < q < end and min(q - start, end - q) <= reach]
    if len(close) > NEAR_MAX:
        pick = rng.choice(len(close), NEAR_MAX, replace=False)
        close = [close[i] for i in sorted(pick)]
    out = []
    for q, p in close:
        width = max(int(round(rng.uniform(0.5, 0.8) * length)), rows)
        centre = (q + p) / 2 + rng.uniform(-0.1, 0.1) * length
        begin = int(round(centre - width / 2))
        out.append(("near", begin, begin + width - 1))
    return out


def plan_windows(legs: list, size: int, rng, min_leg: int = MIN_LEG,
                 rows: int = ROWS, corrections: np.ndarray | None = None) -> list:
    """Вікна частини: (нога-якір, вид, початок, кінець) у записах."""
    out = []
    for number, leg in enumerate(legs):
        length = leg["bars"]
        if length < min_leg:
            continue
        first, last = leg["first"], leg["last"]
        margin = int(round(MARGIN * length))
        span = []
        span.append(("base", first - margin, last + margin))
        for _ in range(SHIFTS):
            move = int(round(rng.uniform(-1.0, 1.0) * length))
            span.append(("shift", first - margin + move, last + margin + move))
        edge = int(round(SPAN * length)) + 1
        room = (last - edge) - (first + edge) + 1
        for _ in range(INNERS):
            width = max(int(round(rng.uniform(0.3, 0.8) * length)), rows)
            if width > room:
                continue
            begin = int(rng.integers(first + edge, last - edge - width + 2))
            span.append(("inner", begin, begin + width - 1))
        for count in LONGS:
            whole = int(np.ceil(count))
            chain = legs[number:number + whole]
            if len(chain) < whole or any(
                    b["first"] != a["last"] + 1 for a, b in zip(chain, chain[1:])):
                continue
            tail = chain[-1]
            stop = tail["last"] if count == whole else \
                tail["first"] + int(round((count - whole + 1) * tail["bars"])) - 1
            total = stop - first + 1
            extra = int(round(MARGIN * total))
            span.append((f"long{count:g}", first - extra, stop + extra))
        if corrections is not None:
            span.extend(near_windows(leg, corrections, rng, rows))
        for kind, a, b in span:
            a, b = max(a, 0), min(b, size - 1)
            if b - a + 1 >= rows:
                out.append((number, kind, a, b))
    return out


def canvas_of(holder, stamps: np.ndarray, opens: np.ndarray,
              closes: np.ndarray, start: int, end: int, key: str = KEY,
              rows: int = ROWS) -> dict:
    """Канва вікна `[start, end]`: 600 × 7, маска, скаляри, записи рядків."""
    window = stamps[start:end + 1]
    net, mask, step = window_canvas(holder, window, key, rows)
    edges, fit = edges_of(window, int(window[-1]) + BAR - 1, rows)
    first, last = row_records(window, edges, fit, rows)
    return {"net": net, "mask": mask, "first": first, "last": last,
            "scalars": np.array([
                np.log1p(len(window)), np.log1p(step),
                float(np.log(closes[end] / opens[start])),
                float(mask.mean())], dtype=np.float32)}


def build(part: str, data: Path = DATA, out: Path = OUT,
          root: Path | None = None, seed: int = SEED, log=print) -> dict:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(seed)
    plan, sizes = {}, {}
    for pair, parts in table["legs"].items():
        legs = parts.get(part, [])
        if not legs:
            continue
        with np.load(data / f"{pair}_{part}.npz") as store:
            sizes[pair] = len(store["t"])
            opens, closes = store["open"], store["close"]
        pivots = with_neighbours(pivots_of(legs, closes), sizes[pair])
        corrections = corrections_of(legs, opens, closes, pivots)["index"]
        plan[pair] = plan_windows(legs, sizes[pair], rng,
                                  corrections=corrections)
    total = sum(len(one) for one in plan.values())
    out.mkdir(parents=True, exist_ok=True)
    features = len(classes30.BY_KEY[KEY]["features"])
    canvas = np.lib.format.open_memmap(out / f"{part}_x.npy", mode="w+",
                                       dtype=np.float32,
                                       shape=(total, ROWS, features))
    keep = {name: [] for name in (
        "mask", "label", "pivot", "corr", "first", "last", "scalars",
        "leg", "pair", "kind", "start", "end", "up")}
    zones = {name: [] for name in ("window", "role", "index", "top", "leg",
                                   "lo", "hi", "rows")}
    position, leg_base = 0, 0
    for pair, windows in plan.items():
        legs = table["legs"][pair][part]
        with np.load(data / f"{pair}_{part}.npz") as store:
            stamps, opens, closes = store["t"], store["open"], store["close"]
        pivots = with_neighbours(pivots_of(legs, closes), sizes[pair])
        corrections = corrections_of(legs, opens, closes, pivots)
        cache = {}
        by_leg = {}
        for number, kind, start, end in windows:
            by_leg.setdefault(number, []).append((kind, start, end))
        for number, spans in by_leg.items():
            leg = legs[number]
            low = min(start for _, start, _ in spans)
            high = max(end for _, _, end in spans)
            holder = read_seconds(pair, int(stamps[low]),
                                  int(stamps[high]) + BAR - 1, cache, root)
            anchor = (leg["first"] - 1, leg["last"])
            for kind, start, end in spans:
                got = canvas_of(holder, stamps, opens, closes, start, end)
                marks = label_rows(start, end, got["first"], got["last"],
                                   closes, pivots, corrections, anchor)
                canvas[position] = got["net"]
                for name in ("mask", "first", "last", "scalars"):
                    keep[name].append(got[name])
                for name in ("label", "pivot", "corr"):
                    keep[name].append(marks[name])
                keep["leg"].append(leg_base + number)
                keep["pair"].append(pair)
                keep["kind"].append(kind)
                keep["start"].append(start)
                keep["end"].append(end)
                keep["up"].append(leg["kind"] == "up")
                for zone in marks["zones"]:
                    zones["window"].append(position)
                    zones["role"].append(zone["role"])
                    zones["index"].append(zone["index"])
                    zones["top"].append(zone["top"])
                    zones["leg"].append(leg_base + number)
                    zones["lo"].append(int(zone["rows"][0]))
                    zones["hi"].append(int(zone["rows"][-1]))
                    zones["rows"].append(len(zone["rows"]))
                position += 1
        leg_base += len(legs)
        log(f"{pair} {part}: ніг {len(legs)}, вікон {position}")
    canvas.flush()
    del canvas
    np.savez(out / f"{part}.npz",
             **{name: np.asarray(value) for name, value in keep.items()})
    np.savez(out / f"{part}_zones.npz",
             **{name: np.asarray(value) for name, value in zones.items()})
    roles = {role: int(sum(one == role for one in zones["role"]))
             for role in ROLES}
    return {"windows": position, "legs": leg_base, "zones": roles}


def build_series(data: Path = DATA, out: Path = OUT,
                 root: Path | None = None, bars: int = SERIES_BARS,
                 step: int = SERIES_STEP, log=print) -> dict:
    """Ковзні вікна ряду val без розмітки: `bars` записів з кроком `step`."""
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    plan = {}
    for pair in table["legs"]:
        path = data / f"{pair}_val.npz"
        if not path.exists():
            continue
        with np.load(path) as store:
            size = len(store["t"])
        starts = list(range(0, max(size - bars, 0) + 1, step))
        if starts and starts[-1] + bars < size:
            starts.append(size - bars)
        plan[pair] = [(start, min(start + bars, size) - 1) for start in starts]
    total = sum(len(one) for one in plan.values())
    out.mkdir(parents=True, exist_ok=True)
    features = len(classes30.BY_KEY[KEY]["features"])
    canvas = np.lib.format.open_memmap(out / "series_x.npy", mode="w+",
                                       dtype=np.float32,
                                       shape=(total, ROWS, features))
    keep = {name: [] for name in ("mask", "scalars", "pair", "start", "end",
                                  "first", "last")}
    position = 0
    for pair, windows in plan.items():
        with np.load(data / f"{pair}_val.npz") as store:
            stamps, opens, closes = store["t"], store["open"], store["close"]
        cache = {}
        for start, end in windows:
            holder = read_seconds(pair, int(stamps[start]),
                                  int(stamps[end]) + BAR - 1, cache, root)
            got = canvas_of(holder, stamps, opens, closes, start, end)
            canvas[position] = got["net"]
            for name in ("mask", "scalars", "first", "last"):
                keep[name].append(got[name])
            keep["pair"].append(pair)
            keep["start"].append(start)
            keep["end"].append(end)
            position += 1
        log(f"{pair} ряд val: вікон {len(windows)}")
    canvas.flush()
    del canvas
    np.savez(out / "series.npz",
             **{name: np.asarray(value) for name, value in keep.items()})
    return {"windows": position}


def marks_of(pair: str, part: str, data: Path = DATA) -> dict:
    """Півоти 2.3 і корекції 0.8 ряду монети — для графіка ціни."""
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    legs = table["legs"][pair][part]
    with np.load(data / f"{pair}_{part}.npz") as store:
        opens, closes = store["open"], store["close"]
    pivots = with_neighbours(pivots_of(legs, closes), len(closes))
    corrections = corrections_of(legs, opens, closes, pivots)
    return {"pivot_index": pivots["index"], "pivot_top": pivots["top"],
            "pivot_zone": pivots["zone"], "pivot_span": pivots["span"],
            "corr_index": corrections["index"], "corr_top": corrections["top"],
            "corr_zone": corrections["zone"], "corr_span": corrections["span"]}


def build_marks(part: str = "train", data: Path = DATA,
                out: Path = MARKS, log=print) -> None:
    table = json.loads((data / "legs.json").read_text(encoding="utf-8"))
    out.mkdir(parents=True, exist_ok=True)
    for pair, parts in table["legs"].items():
        if not parts.get(part):
            continue
        got = marks_of(pair, part, data)
        np.savez(out / f"{pair}_{part}.npz", **got)
        log(f"{pair} {part}: півотів 2.3 {len(got['pivot_index'])}, "
            f"корекцій {len(got['corr_index'])}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--marks", action="store_true",
                        help="півоти 2.3 і корекції 0.8 ряду train для графіка")
    parser.add_argument("--series", action="store_true",
                        help="ковзні вікна ряду val без розмітки")
    args = parser.parse_args()
    if args.marks:
        build_marks("train", args.data)
        return
    if args.series:
        print(f"ряд val: {build_series(args.data, args.out, args.root)}")
        return
    report = {}
    for part in PARTS:
        report[part] = build(part, args.data, args.out, args.root)
        print(f"{part}: {report[part]}")
    (args.out / "build.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
