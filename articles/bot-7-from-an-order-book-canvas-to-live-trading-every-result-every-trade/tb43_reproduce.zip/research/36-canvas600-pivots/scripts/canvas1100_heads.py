"""Етап 8: три голови на канві 1100 — півоти 2.3, корекції 0.8 і бік
(купити / продати), функції втрат і довші вікна.

Дослідження: research/36-canvas600-pivots/ → Етап 8

## Хід

1. **Дані** — зсунуті канви 1100 етапів 6–7 на 4 ноги
   (`data/canvas1100/<part>_x.npy`) і на 6 і 8 ніг (`<part>_L6`,
   `<part>_L8`, `canvas1100.py --legs N`): ті самі 1100 рядків, ноги ≥
   7 год на рядках 50 … 1049, поле 5 %, зсув до ноги в кожен бік. train —
   до 14.08, val — 14.08 … 22.09.
2. **Три голови** — `Finder3` етапу 2 на 1100 рядках з трьома виходами,
   кожен — окрема голова з сигмоїдою: `P(півот 2.3)`, `P(корекція 0.8)` і
   **бік** `P(купити)`. Мітки: півот — рядок у зоні півота (`label = 2`),
   корекція — рядок у зоні корекції, що не півот (`label = 1`); рядок
   `−1` і мертвий рядок — поза втратою цих голів. Бік — нога, в якій
   лежить середній запис рядка: наступний півот 2.3 — вершина → `1`
   (купити, нога вгору), дно → `0` (продати, нога вниз); бік
   перемикається рівно на півоті, позиція завжди в ринку. Рядок після
   останнього півота частини — поза втратою боку.
3. **Функції втрат** (на кожну голову, сума двох голів):
   - `wbce` — BCE з вагою позитиву 3;
   - `focal` — focal loss, γ = 2, α = 0.75;
   - `dice` — BCE + (1 − soft dice) по канві;
   - `swap` — `wbce` плюс штраф за плутанину: `−log(1 − P(півот))` на
     рядках корекції і `−log(1 − P(корекція))` на рядках півота, вага 3.
   Голова боку — завжди BCE з вагою 1, додається до втрати.
4. **Розбиття по часу** — нога-різ `cut` = 80 % ніг монети (за
   `legs_train.json`); навчання — канви, чиї ноги і ще одна (зсув) цілком
   до `cut`; відкладені — з ноги `cut + 1`. Однаково для канв на 4, 6 і 8
   ніг. val — тільки замір.
5. **Навчання** — Adam lr 1e-3, батч 8 кусками по 4, seed 0, стеля 30
   епох, стоп після 4 епох без покращення. Поріг голів півота й корекції —
   за їхнім F1 на відкладених.
   `--init <прогін>` — довчання з найкращих ваг іншого прогону.
6. **Міра** — як в етапі 7 для кожної голови: сигнал — пік ≥ порогу в
   ±10 рядках; добрий — у зоні свого класу; повнота — частка зон свого
   класу з сигналом; сплутано — сигнал у зоні іншого класу поза своєю.
   Бік: частка рядків із правильним боком (`P ≥ 0.5` — купити); перемикання
   боку по живих рядках — добре, коли стоїть у зоні півота і йде в
   правильний бік (на дні — у купити, на вершині — у продати); повнота —
   частка зон півота з добрим перемиканням; F1 перемикань. Епоха — за
   середнім F1 півота, корекції і перемикань.
   Базовий прогноз — стільки ж сигналів на випадкових живих рядках.
   val — по монетах і окремо на канвах 4, 6 і 8 ніг.

Кола:
- **A — функції втрат**: 4 ноги, `wbce`, `focal`, `dice`, `swap`.
- **B — довші вікна** з найкращою втратою кола A: з нуля на канвах 4 + 6 +
  8 ніг; довчання найкращого прогону кола A на канвах 4 + 6 + 8 ніг.

Запуск:
    python3 research/36-canvas600-pivots/scripts/canvas1100_heads.py --run A_wbce --loss wbce --legs 4
    python3 research/36-canvas600-pivots/scripts/canvas1100_heads.py --run B_mix --loss <краща> --legs 4 6 8
    python3 research/36-canvas600-pivots/scripts/canvas1100_heads.py --run B_tune --loss <краща> --legs 4 6 8 --init A_<краща>

Вихід: models/canvas1100_heads/<прогін>/epoch_NN.pt;
results/canvas1100_heads/<прогін>.json.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

SCRIPTS = Path(__file__).resolve().parent
RESEARCH = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import canvas1100_net as net  # noqa: E402
from canvas600_net import Finder3, clean  # noqa: E402
from edges30_net import device_of, peaks, scalars_of  # noqa: E402
from leg_end_train import no_swap  # noqa: E402

DATA = net.DATA
MODELS = RESEARCH / "models" / "canvas1100_heads"
RESULTS = RESEARCH / "results" / "canvas1100_heads"
ROWS = 1100
HEADS = ("pivot", "corr")        # вихід 0 — півот 2.3, вихід 1 — корекція 0.8
OUTPUTS = 3                      # вихід 2 — бік: 1 — купити, 0 — продати
LABEL = {"pivot": 2, "corr": 1}
POS_WEIGHT = 3.0
GAMMA, ALPHA = 2.0, 0.75
SWAP = 3.0
LOSSES = ("wbce", "focal", "dice", "swap")
LR, BATCH, MICRO, PREDICT = 1e-3, 8, 4, 4
EPOCHS, PATIENCE = 30, 4
PEAK = 10
THRESHOLDS = np.round(np.arange(0.05, 0.96, 0.05), 2)
SEED = 0
HELD, PAD = 0.8, 1
MEMORY_NEED = 2400


def suffix_of(legs_in: int) -> str:
    return "" if legs_in == 4 else f"_L{legs_in}"


def load(part: str, legs: tuple, data: Path = DATA) -> dict:
    """Зсунуті канви частини на кожну кількість ніг з `legs`, разом."""
    pieces = []
    for legs_in in legs:
        name = f"{part}{suffix_of(legs_in)}"
        with np.load(data / f"{name}.npz") as store:
            one = {key: store[key] for key in store.files}
        keep = np.flatnonzero(one["kind"] == "shift")
        one = {key: value[keep] for key, value in one.items()}
        one["x"] = np.asarray(np.load(data / f"{name}_x.npy", mmap_mode="r")[keep])
        one["legs_in"] = np.full(len(keep), legs_in)
        pieces.append(one)
    keys = [key for key in pieces[0] if all(key in one for one in pieces)]
    out = {key: np.concatenate([one[key] for one in pieces]) for key in keys}
    out["numbers"] = scalars_of(out["scalars"])
    label = out["label"]
    zones = [np.where(label == LABEL[h], 1, np.where(label < 0, -1, 0)) for h in HEADS]
    out["side"] = sides_of(out, part, data)
    out["target"] = np.stack(zones + [out["side"]], axis=-1).astype(np.float32)
    return out


def sides_of(out: dict, part: str, data: Path = DATA) -> np.ndarray:
    """Бік кожного рядка: 1 — нога вгору (наступний півот — вершина),
    0 — нога вниз, −1 — рядок мертвий або після останнього півота."""
    from edges30_data import pivots_of
    legs = json.loads((data / f"legs_{part}.json").read_text(encoding="utf-8"))
    table = {}
    for pair, one in legs.items():
        with np.load(data / f"{pair}_{part}.npz") as store:
            close = store["close"]
        got = pivots_of(one, close)
        table[pair] = (got["index"], got["top"])
    side = np.full(out["first"].shape, -1, dtype=np.int64)
    for number, pair in enumerate(out["pair"]):
        index, top = table[str(pair)]
        first, last = out["first"][number], out["last"][number]
        live = first >= 0
        record = out["start"][number] + (first + last) // 2
        after = np.searchsorted(index, record, side="left")
        ok = live & (after < len(index))
        side[number, ok] = np.where(top[after[ok]], 1, 0)
    return side


def split(data: dict, counts: dict, share: float = HELD, pad: int = PAD) -> tuple:
    """Нога-різ монети — `share` її ніг train; навчання — канви, чиї ноги
    і ще `pad` цілком до різу, відкладені — з `cut + pad`."""
    inside, held = [], []
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        cut = int(np.floor(share * counts[str(pair)]))
        first = data["leg"][where]
        last = first + data["legs_in"][where] - 1
        inside.extend(where[last + pad < cut].tolist())
        held.extend(where[first - pad >= cut].tolist())
    return np.asarray(inside), np.asarray(held)


def loss_of(logits: torch.Tensor, target: torch.Tensor, mask: torch.Tensor,
            kind: str) -> torch.Tensor:
    """Втрата трьох голів: `logits`, `target` — `(B, rows, 3)`; зони
    півота й корекції — за `kind`, бік — BCE."""
    side_live = (mask & (target[..., 2] >= 0)).float()
    side = F.binary_cross_entropy_with_logits(
        logits[..., 2], target[..., 2].clamp(min=0), reduction="none")
    side = (side * side_live).sum() / side_live.sum().clamp(min=1)
    return zone_loss(logits[..., :2], target[..., :2], mask, kind) + side


def zone_loss(logits: torch.Tensor, target: torch.Tensor, mask: torch.Tensor,
              kind: str) -> torch.Tensor:
    """Втрата голів півота й корекції: `(B, rows, 2)`."""
    live = (mask[..., None] & (target >= 0)).float()
    t = target.clamp(min=0)
    p = torch.sigmoid(logits)
    if kind == "focal":
        each = F.binary_cross_entropy_with_logits(logits, t, reduction="none")
        pt = torch.where(t > 0, p, 1 - p)
        a = torch.where(t > 0, torch.full_like(p, ALPHA), torch.full_like(p, 1 - ALPHA))
        each = a * (1 - pt) ** GAMMA * each
        return (each * live).sum() / live.sum().clamp(min=1)
    weight = torch.where(t > 0, torch.full_like(p, POS_WEIGHT), torch.ones_like(p)) * live
    each = F.binary_cross_entropy_with_logits(logits, t, reduction="none")
    total = (each * weight).sum() / weight.sum().clamp(min=1)
    if kind == "dice":
        inter = (p * t * live).sum(dim=1)
        denom = (p * live).sum(dim=1) + (t * live).sum(dim=1)
        dice = (2 * inter + 1) / (denom + 1)
        total = total + (1 - dice).mean()
    if kind == "swap":
        # голова півота на рядках корекції і голова корекції на рядках півота
        other = t.flip(-1) * live.flip(-1) * live
        wrong = -torch.log((1 - p).clamp(min=1e-6)) * other
        total = total + SWAP * wrong.sum() / weight.sum().clamp(min=1)
    return total


def predict(model, data: dict, index: np.ndarray, device) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(index), PREDICT):
            pick = index[start:start + PREDICT]
            logits = model(torch.from_numpy(data["x"][pick]).to(device),
                           torch.from_numpy(data["numbers"][pick]).to(device))
            out.append(torch.sigmoid(logits).float().cpu().numpy())
    if device.type == "mps":
        torch.mps.empty_cache()
    return np.concatenate(out) if out else np.zeros((0, ROWS, OUTPUTS), np.float32)


def score(signal: np.ndarray, own: np.ndarray, other: np.ndarray) -> dict:
    """Точність, повнота, F1 сигналів однієї голови; власник зони рядка."""
    return net.score(signal, {"pivot": own, "corr": other}, np.arange(len(own)))


def head_score(prob: np.ndarray, data: dict, index: np.ndarray, head: str,
               threshold: float) -> dict:
    other = "corr" if head == "pivot" else "pivot"
    own = data[head][index]
    if head == "corr":
        # рядок, де корекція збігається з півотом, — півот
        own = np.where(data["label"][index] == 1, own, -1)
    signal = peaks(prob, data["mask"][index], threshold, PEAK)
    model = score(signal, own, data[other][index])
    base = score(net.random_signals(signal, data["mask"][index]), own,
                 data[other][index])
    return {"model": model, "base": base}


def thresholds_of(prob: np.ndarray, data: dict, index: np.ndarray) -> dict:
    return {head: float(max(THRESHOLDS, key=lambda t: head_score(
        prob[..., h], data, index, head, t)["model"]["f1"]))
        for h, head in enumerate(HEADS)}


def flip_ok(row: int, to_buy: bool, owner: np.ndarray, true: np.ndarray) -> bool:
    """Перемикання в рядку `row` добре, коли рядок у зоні півота, а новий
    бік — бік ноги одразу за цією зоною (після дна — купити)."""
    zone = owner[row]
    if zone < 0:
        return False
    after = int(np.flatnonzero(owner == zone)[-1]) + 1
    if after >= len(true) or true[after] < 0:
        return True
    return bool(to_buy) == (true[after] == 1)


def side_score(prob: np.ndarray, data: dict, index: np.ndarray) -> dict:
    """Бік: частка рядків із правильним боком і перемикання на півотах."""
    side = data["side"][index]
    mask = data["mask"][index]
    own = data["pivot"][index]
    rows_ok = (side >= 0) & mask
    right = int(((prob >= 0.5) == (side == 1))[rows_ok].sum())
    flips = good = total = found = 0
    for p, live, owner, true in zip(prob, mask, own, side):
        rows = np.flatnonzero(live)
        if len(rows) < 2:
            continue
        buy = p[rows] >= 0.5
        change = buy[1:] != buy[:-1]
        at = rows[1:][change]
        to_buy = buy[1:][change]
        hit = np.array([flip_ok(a, b, owner, true) for a, b in zip(at, to_buy)],
                       dtype=bool)
        flips += len(at)
        good += int(hit.sum())
        zones = set(owner[owner >= 0].tolist())
        total += len(zones)
        found += len(zones & set(owner[at[hit]].tolist()))
    precision = good / flips if flips else float("nan")
    recall = found / total if total else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if flips and total and precision + recall > 0 else 0.0)
    return {"rows": int(rows_ok.sum()), "right": right,
            "accuracy": right / max(int(rows_ok.sum()), 1),
            "flips": flips, "good": good, "zones": total, "found": found,
            "precision": precision, "recall": recall, "f1": f1}


def measure(prob: np.ndarray, data: dict, index: np.ndarray,
            thresholds: dict) -> dict:
    out = {head: head_score(prob[..., h], data, index, head, thresholds[head])
           for h, head in enumerate(HEADS)}
    out["side"] = side_score(prob[..., 2], data, index)
    return out


def by_group(prob: np.ndarray, data: dict, thresholds: dict) -> dict:
    """val: усі, кожна монета, кожна кількість ніг."""
    index = np.arange(len(data["pair"]))
    out = {"all": measure(prob, data, index, thresholds)}
    for pair in np.unique(data["pair"]):
        where = np.flatnonzero(data["pair"] == pair)
        out[str(pair)] = measure(prob[where], data, where, thresholds)
    for legs_in in np.unique(data["legs_in"]):
        where = np.flatnonzero(data["legs_in"] == legs_in)
        out[f"legs{int(legs_in)}"] = measure(prob[where], data, where, thresholds)
    return out


def mean_f1(result: dict) -> float:
    return float(np.mean([result[h]["model"]["f1"] for h in HEADS]
                         + [result["side"]["f1"]]))


def train(run: str, loss: str, legs: tuple, init: str | None, device,
          log=print, epochs: int = EPOCHS, patience: int = PATIENCE) -> dict:
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    counts = {pair: len(one) for pair, one in json.loads(
        (DATA / "legs_train.json").read_text(encoding="utf-8")).items()}
    data = load("train", legs)
    val = load("val", (4, 6, 8))
    inside, held = split(data, counts)
    log(f"{run}: канв навчання {len(inside)}, відкладені {len(held)}, val {len(val['pair'])}")
    folder = MODELS / run
    folder.mkdir(parents=True, exist_ok=True)
    model = Finder3(rows=ROWS, outputs=OUTPUTS).to(device)
    if init:
        start = json.loads((RESULTS / f"{init}.json").read_text(encoding="utf-8"))
        model.load_state_dict(torch.load(MODELS / init / f"epoch_{start['best_epoch']:02d}.pt",
                                         map_location=device))
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    history, best, wait = [], None, 0
    for epoch in range(1, epochs + 1):
        started = time.time()
        model.train()
        order = rng.permutation(inside)
        total, count = 0.0, 0
        for begin in range(0, len(order), BATCH):
            pick = np.sort(order[begin:begin + BATCH])
            optimizer.zero_grad()
            for piece in range(0, len(pick), MICRO):
                part = pick[piece:piece + MICRO]
                value = loss_of(
                    model(torch.from_numpy(data["x"][part]).to(device),
                          torch.from_numpy(data["numbers"][part]).to(device)),
                    torch.from_numpy(data["target"][part]).to(device),
                    torch.from_numpy(data["mask"][part]).to(device), loss)
                (value * len(part) / len(pick)).backward()
                total += float(value.detach()) * len(part)
                count += len(part)
            optimizer.step()
        held_prob = predict(model, data, held, device)
        thresholds = thresholds_of(held_prob, data, held)
        held_score = measure(held_prob, data, held, thresholds)
        val_score = by_group(predict(model, val, np.arange(len(val["pair"])), device),
                             val, thresholds)
        one = {"epoch": epoch, "train_loss": total / max(count, 1),
               "thresholds": thresholds, "holdout": held_score, "val": val_score,
               "seconds": time.time() - started}
        history.append(one)
        torch.save(model.state_dict(), folder / f"epoch_{epoch:02d}.pt")
        f1 = mean_f1(held_score)
        log(f"{run} е{epoch}: втрата {one['train_loss']:.4f}, пороги {thresholds}, "
            f"F1 відкладені півот {held_score['pivot']['model']['f1']:.3f} "
            f"корекція {held_score['corr']['model']['f1']:.3f} · val півот "
            f"{val_score['all']['pivot']['model']['f1']:.3f} корекція "
            f"{val_score['all']['corr']['model']['f1']:.3f} · бік val "
            f"{val_score['all']['side']['accuracy']:.3f}, перемикання F1 "
            f"{val_score['all']['side']['f1']:.3f}, {one['seconds']:.0f} с")
        if best is None or f1 > best["f1"]:
            best, wait = {"epoch": epoch, "f1": f1}, 0
        else:
            wait += 1
            if wait >= patience:
                break
    chosen = next(one for one in history if one["epoch"] == best["epoch"])
    out = {"run": run, "loss": loss, "legs": list(legs), "init": init,
           "best_epoch": best["epoch"], "thresholds": chosen["thresholds"],
           "canvases": {"inside": len(inside), "held": len(held),
                        "val": len(val["pair"])},
           "holdout": chosen["holdout"], "val": chosen["val"],
           "history": [{"epoch": one["epoch"], "train_loss": one["train_loss"],
                        "held_f1": {**{h: one["holdout"][h]["model"]["f1"] for h in HEADS},
                                    "side": one["holdout"]["side"]["f1"]},
                        "val_f1": {**{h: one["val"]["all"][h]["model"]["f1"] for h in HEADS},
                                   "side": one["val"]["all"]["side"]["f1"]},
                        "val_side_accuracy": one["val"]["all"]["side"]["accuracy"],
                        "seconds": one["seconds"]} for one in history],
           "config": {"pos_weight": POS_WEIGHT, "gamma": GAMMA, "alpha": ALPHA,
                      "swap": SWAP, "lr": LR, "batch": BATCH, "micro": MICRO,
                      "epochs": epochs, "patience": patience, "peak": PEAK,
                      "held": HELD, "pad": PAD, "seed": SEED}}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / f"{run}.json").write_text(json.dumps(clean(out), ensure_ascii=False,
                                                    indent=1), encoding="utf-8")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--run", required=True)
    parser.add_argument("--loss", choices=LOSSES, required=True)
    parser.add_argument("--legs", type=int, nargs="+", default=[4])
    parser.add_argument("--init", default=None)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    no_swap(MEMORY_NEED, args.force)
    train(args.run, args.loss, tuple(args.legs), args.init, device_of(args.device))


if __name__ == "__main__":
    main()
