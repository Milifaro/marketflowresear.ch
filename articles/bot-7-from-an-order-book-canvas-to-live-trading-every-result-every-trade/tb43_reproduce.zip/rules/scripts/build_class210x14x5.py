"""Побудова датасету клас210х14х5 з робочої копії data/.

Правила: rules/01-data-and-db.md → Класи (події) → клас210х14х5

Пʼята фіча (`vol_balance` по блоках) рахується з посекундних обʼємів, тому
`клас210х14х4` для неї не годиться — потрібен `клас210х8`, а він не
зберігається. Тому події будуються заново з робочої копії `data/`, а потім
**розкладаються по вже наявному розбиттю** `клас210х14х4` за `timestamp`:
train/val/test лишаються тими самими, порядок подій у файлах теж.

Джерело ~/DATA не читається — тільки `data/`.

Пропуски часу заповнюються так само, як у розбитті: якщо `клас210х14х4`
зібраний з `--fill-gaps 60`, тут потрібен той самий прапорець — інакше
подій розбиття у робочій копії не знайдеться.

Запуск:
    python3 rules/scripts/build_class210x14x5.py --pair BTC_USDT
    python3 rules/scripts/build_class210x14x5.py --pair BTC_USDT --fill-gaps 60
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x8
import class210x14x4
import class210x14x5
import fill_gaps
from class210x8 import EVENT_LENGTH
from data_source import PROJECT_ROOT, load_day, to_array

PARTS = ("train", "val", "test")
WORK_ROOT = PROJECT_ROOT / "data"


def work_files(pair: str, root: Path | None = None) -> list[Path]:
    """Файли робочої копії data/<рік>/<місяць>/<PAIR>/."""
    root = Path(root) if root is not None else WORK_ROOT
    return sorted(root.glob(f"*/*/{pair}/1S_*_{pair}.csv"))


def build_events(files: list[Path], step: int = EVENT_LENGTH, log=print,
                 max_gap: int = 0
                 ) -> tuple[class210x14x5.Class210x14x5, dict]:
    """Усі події клас210х14х5 з переліку файлів."""
    parts, rows_read, duplicates = [], 0, 0
    filled = fill_gaps.empty_report(max_gap)
    for index, path in enumerate(files, 1):
        frame, report = load_day(path)
        rows_read += report.rows_read
        duplicates += report.duplicates_removed
        rows, day_fill = fill_gaps.fill(to_array(frame), max_gap)
        filled += day_fill
        parts.append(class210x8.build(rows, step=step))
        if index % 40 == 0 or index == len(files):
            log(f"      {index}/{len(files)} файлів, "
                f"подій: {sum(len(p) for p in parts)}")
    base = class210x8.concat(parts)
    dataset, report = class210x14x5.build(base)
    return dataset, {"files": len(files), "rows_read": rows_read,
                     "duplicates_removed": duplicates,
                     "fill_gaps": asdict(filled), **asdict(report)}


def take_by_timestamp(dataset: class210x14x5.Class210x14x5,
                      wanted: np.ndarray) -> class210x14x5.Class210x14x5:
    """Події у порядку `wanted`. Немає хоч однієї — помилка."""
    position = {int(ts): i for i, ts in enumerate(dataset.timestamp)}
    missing = [int(ts) for ts in wanted if int(ts) not in position]
    if missing:
        raise SystemExit(f"немає {len(missing)} подій розбиття у робочій копії "
                         f"(перша: {missing[0]})")
    index = np.array([position[int(ts)] for ts in wanted])
    return class210x14x5.Class210x14x5(
        x=dataset.x[index], timestamp=dataset.timestamp[index],
        price_open=dataset.price_open[index],
        price_close=dataset.price_close[index])


def build_pair(pair: str, split_dir: Path, out_dir: Path, step: int,
               root: Path | None = None, max_gap: int = 0) -> dict:
    files = work_files(pair, root)
    if not files:
        raise SystemExit(f"немає робочої копії data/ для {pair}")
    print(f"[1/3] файлів у робочій копії: {len(files)}")

    dataset, report = build_events(files, step, max_gap=max_gap)
    print(f"[2/3] клас210х14х5: {len(dataset)} подій, відкинуто "
          f"(нульовий обʼєм): {report['dropped_zero_volume']}, "
          f"NaN-блоків vol_balance: {report['nan_vol_balance']}")

    out_dir.mkdir(parents=True, exist_ok=True)
    report["parts"] = {}
    for name in PARTS:
        source = split_dir / f"{name}.npz"
        if not source.exists():
            raise SystemExit(f"немає файлу розбиття {source}")
        wanted = class210x14x4.load(source).timestamp
        part = take_by_timestamp(dataset, wanted)
        class210x14x5.save(part, out_dir / f"{name}.npz")
        nan_blocks = int(np.isnan(part.x[:, :, -1]).sum())
        report["parts"][name] = {"events": len(part),
                                 "nan_vol_balance": nan_blocks}
        print(f"      {name}: {len(part)} подій, NaN-блоків: {nan_blocks}")
    print(f"[3/3] записано в {out_dir}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--step", type=int, default=EVENT_LENGTH)
    parser.add_argument("--fill-gaps", type=int, default=0,
                        help="той самий прапорець, що й у build_dataset.py")
    parser.add_argument("--split", type=Path, default=None,
                        help="звідки брати розбиття; типово class210x14x4")
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=None,
                        help="корінь робочої копії; типово data/")
    args = parser.parse_args()

    datasets = PROJECT_ROOT / "data" / "datasets" / args.pair
    split_dir = args.split or datasets / "class210x14x4"
    out_dir = args.out or datasets / "class210x14x5"

    report = build_pair(args.pair, split_dir, out_dir, args.step, args.data,
                        max_gap=args.fill_gaps)
    report["split_from"] = str(split_dir)
    (out_dir / "report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
