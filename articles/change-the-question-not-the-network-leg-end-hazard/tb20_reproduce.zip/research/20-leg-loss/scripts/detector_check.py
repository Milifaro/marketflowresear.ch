"""Чи лежить свідчення детектора в памʼяті: частка додатних подій.

Дослідження: research/20-leg-loss/

## Навіщо

Детектор відповідає «розворот стався не далі ніж N подій тому». Щоб
відповісти, півот має бути **всередині** памʼяті: після примусового
обнулення по стелі мережа не бачить нічого раніше за нього.

Замір рахує, на якій частці **додатних** подій кожного горизонту півот
справді лежить у поточній памʼяті: `пройдено ≤ вік памʼяті`, де вік —
скільки подій минуло від останнього обнулення по стелі.

Моделі тут немає — рахується сама розмітка.

Запуск:

    python3 research/20-leg-loss/scripts/detector_check.py --force
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_train as base            # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "detector_check.json"
CAPS = (500, 1500)
HORIZONS = (10, 40, 160, 500)


def build_report(caps=CAPS, horizons=HORIZONS, part="train", log=print) -> dict:
    started = time.time()
    cut = legs_module.cut_stamp(base.CUT)
    streams = []
    for name in [base.PAIR] + list(base.EXTRA):
        one = base.stream_of(name, cut, part, base.BEHIND)
        if one:
            streams.append(one)
    made = []
    for cap in caps:
        shares = {}
        for horizon in horizons:
            per_coin = []
            for one in streams:
                since = one["left"]
                # Вік памʼяті: скільки подій минуло від обнулення по стелі.
                age = np.arange(len(since)) % cap
                mark = one["known"] & (since >= 0) & (since < horizon)
                if not mark.any():
                    continue
                per_coin.append(float((since[mark] <= age[mark]).mean()))
            shares[str(horizon)] = train_module.number(
                float(np.mean(per_coin)) * 100, 1)
        made.append({"cap": cap, "share": shares})
        log(f"  стеля {cap}: " + " · ".join(
            f"p{key} {value} %" for key, value in shares.items()))
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "setup": {"part": part, "cut": base.CUT, "caps": list(caps),
                  "horizons": list(horizons), "coins": len(streams),
                  "label": "розворот стався не далі ніж N подій тому",
                  "about": "моделі немає — рахується сама розмітка"},
        "caps": made,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--part", default="train")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(part=args.part)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
