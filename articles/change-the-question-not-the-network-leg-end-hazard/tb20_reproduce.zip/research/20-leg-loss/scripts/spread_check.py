"""Що саме в події видно перед кінцем ноги: розмах блоків проти середнього.

Дослідження: research/20-leg-loss/
Правила: rules/01-data-and-db.md → клас210х14х4ц

## Навіщо

Мережа з памʼяттю дає `AUC 0.73` на питанні «нога скінчиться в наступні
10 подій», а мережа без памʼяті на тих самих фічах — `0.58`. Питання
цього заміру: **що саме у фічах події несе цей сигнал** і чи однаково
він видно перед верхнім і перед нижнім півотом.

Модель тут не бере участі: рахуються самі фічі.

## Що рахується

Подія `клас210х14х4ц` — це 15 блоків по 14 с × 4 фічі. З кожної фічі
беруться два числа події:

| Число | Формула |
| ----- | ------- |
| середнє | `mean` по 15 блоках |
| розмах | `max − min` по 15 блоках |

Кожне окремо ранжує події проти мітки «нога скінчиться в наступні 10».
Розмах іде **зі знаком мінус**: перед півотом блоки однорідні, розмах
малий, тому мала величина має стояти вище.

Розбиття по типу півота: додатні події діляться за тим, який півот
завершує їхню ногу — `high` чи `low`, — а відʼємні спільні для обох.

Запуск:

    python3 research/20-leg-loss/scripts/spread_check.py --force
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_net as hazard            # noqa: E402
import hazard_train as base            # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "spread_check.json"
NAMES = ("balance", "d_balance", "vol_balance", "ціна")
HORIZON = 10


def blocks_of(x: np.ndarray) -> np.ndarray:
    """(подій, 60) → (подій, 15 блоків, 4 фічі)."""
    return x[:, :base.BLOCKS * base.BASE_FEATURES].reshape(
        len(x), base.BLOCKS, base.BASE_FEATURES)


def kinds_of(stream: dict, total: int) -> np.ndarray:
    """Тип півота, який завершує ногу кожної події: `1` high, `0` low."""
    kind = np.full(total, -1, dtype=np.int64)
    start = 0
    for item in sorted(stream["pivots"], key=lambda one: one.index):
        place = item.index - stream["offset"]
        if place < 0:
            continue
        stop = min(place, total - 1)
        kind[start:stop + 1] = 1 if item.kind == "high" else 0
        start = stop + 1
    return kind


def coin_of(pair: str, cut: int, part: str) -> dict:
    """Один потік: AUC середнього і розмаху на кожну фічу."""
    stream = base.stream_of(pair, cut, part)
    if not stream:
        return {}
    total = len(stream["y"])
    left = stream["left"]
    known = stream["known"]
    kind = kinds_of(stream, total)
    label = (left < HORIZON) & known
    blocks = blocks_of(stream["x"])
    means = blocks.mean(axis=1)
    spread = blocks.max(axis=1) - blocks.min(axis=1)

    def auc(score: np.ndarray, mask: np.ndarray) -> float | None:
        return train_module.number(
            hazard.auc_of(score[mask], label[mask].astype(np.float32)), 4)

    negative = known & ~label
    highs = label & (kind == 1)
    lows = label & (kind == 0)
    features = []
    for index, name in enumerate(NAMES):
        features.append({
            "name": name,
            # Розмах іде зі знаком мінус: мала величина = близько до півота.
            "spread": auc(-spread[:, index], known),
            "mean": auc(means[:, index], known),
            "spread_high": auc(-spread[:, index], negative | highs),
            "spread_low": auc(-spread[:, index], negative | lows),
        })
    return {"pair": pair, "part": part, "events": total,
            "labelled": int(known.sum()), "marked": int(label.sum()),
            "pivots_high": int(sum(1 for one in stream["pivots"]
                                   if one.kind == "high")),
            "pivots_low": int(sum(1 for one in stream["pivots"]
                                  if one.kind == "low")),
            "features": features}


def build_part(part: str, cut: int, log=print) -> dict:
    """Одна вибірка: кожна монета окремо і середнє по монатах."""
    coins = []
    for name in [base.PAIR] + list(base.EXTRA):
        got = coin_of(name, cut, part)
        if not got:
            continue
        coins.append(got)
        best = max(got["features"], key=lambda one: one["spread"] or 0)
        log(f"  {got['pair']}: розмах {best['name']} {best['spread']} · "
            f"півотів {got['pivots_high']} вгору / {got['pivots_low']} вниз")

    def across(key: str, index: int) -> float | None:
        values = [one["features"][index][key] for one in coins
                  if one["features"][index][key] is not None]
        return (train_module.number(float(np.mean(values)), 4)
                if values else None)

    total = [{"name": name,
              "spread": across("spread", index),
              "mean": across("mean", index),
              "spread_high": across("spread_high", index),
              "spread_low": across("spread_low", index)}
             for index, name in enumerate(NAMES)]
    return {
        "part": part,
        "coins": coins,
        "total": {"features": total,
                  "events": int(sum(one["events"] for one in coins)),
                  "pivots_high": int(sum(one["pivots_high"] for one in coins)),
                  "pivots_low": int(sum(one["pivots_low"] for one in coins))},
    }


def build_report(parts=("train", "val"), log=print) -> dict:
    """Обидві вибірки в одному звіті.

    Вони тут не для «навчання і перевірки» — модель не бере участі, — а
    щоб було видно **розмір вибірки**: після межі розбиття на всі шість
    монет припадає 63 півоти проти 608 до неї. Різниця між частинами
    показує, скільки з побаченого тримається, а скільки було рахунком
    по десятку подій.
    """
    started = time.time()
    cut = legs_module.cut_stamp(base.CUT)
    made = {}
    for part in parts:
        log(f"{part}:")
        made[part] = build_part(part, cut, log)
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "setup": {"parts": list(parts), "cut": base.CUT, "horizon": HORIZON,
                  "blocks": base.BLOCKS, "features": list(NAMES),
                  "label": f"нога скінчиться в наступні {HORIZON} подій",
                  "about": "модель не бере участі — рахуються самі фічі"},
        "parts": made,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--parts", nargs="+", default=["train", "val"])
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(tuple(args.parts))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    for part, got in report["parts"].items():
        print(f"{part} · півотів {got['total']['pivots_high']} вгору / "
              f"{got['total']['pivots_low']} вниз")
        print("  фіча · розмах · середнє · верхні · нижні")
        for row in got["total"]["features"]:
            print(f"    {row['name']}: {row['spread']} · {row['mean']} · "
                  f"{row['spread_high']} · {row['spread_low']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
