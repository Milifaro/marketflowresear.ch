"""Готова модель `p₁₀₀` поза BTC: усі шість монет після межі розбиття.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

## Навіщо

Val у розділах 7–9 — це 3 800 подій самого BTC і **шість** півотів.
На такій вибірці `AUC 0.604` має широкий довірчий інтервал, а все, що
рахується по півотах — своїх обнулень, влучань — не рахується взагалі.

Після межі `2026-08-14 15:27` UTC дані є не тільки в BTC: решта пʼяти
монет дає ще 25 070 подій, яких **не було в train** — train обрізаний
тією самою датою. Разом 28 870 подій і 63 півоти, у сім разів більше.

Навчання тут не йде: береться **готова** модель і проганяється по
кожній монеті окремо.

## Як читати числа

`AUC` рахується **на кожній монеті окремо** і зводиться двома
способами, бо в них різний сенс:

| Число | Що означає |
| ----- | ---------- |
| середнє по монетах | як модель тримається на типовій монеті |
| спільне | усі події в один список, ранги наскрізні |

Спільне число нижче за середнє, коли базова частота мітки різна на
різних монетах: у XRP вона `0.37`, у ETH `0.09`, і наскрізне
ранжування починає міряти різницю **між** монетами, а не всередині.
Тому основне число тут — **середнє по монетах**.

Запуск:

    python3 research/20-leg-loss/scripts/hazard_wide.py --force
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_net as hazard            # noqa: E402
import hazard_train as base            # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
MODELS = HERE.parent / "models"
REPORT = RESULTS / "hazard_wide.json"
SOURCE = RESULTS / "hazard_one.json"


def model_of(report: dict, folder: Path):
    """Мережа тієї самої будови, що навчалась, із її вагами."""
    knobs = report["model"]
    hazard.set_horizons(knobs["horizons"])
    net = hazard.HazardNet(features=report["dataset"]["features"],
                           hidden=knobs["hidden"], heads=knobs["heads"],
                           outputs=knobs["outputs"],
                           # Будова мережі береться зі звіту цілком:
                           # інакше глибша модель не завантажиться, а
                           # вужча голова завантажиться беззвучно чужою.
                           layers=knobs.get("layers", 1),
                           head=knobs.get("head", hazard.HEAD))
    net.load_state_dict(torch.load(folder / "model.pt", map_location="cpu"))
    net.eval()
    return net


def check(net, stream: dict, knobs: dict, spans, weights) -> dict:
    """Один прохід монетою без навчання."""
    with torch.no_grad():
        walked = base.walk_stream(net, stream, knobs, spans, weights)
    known = stream["known"]
    score = walked["curve"][known, 0]
    truth = stream["labels"][known, 0]
    own = [one for one in walked["resets"] if one["kind"] == "поріг"]
    # `auc` лишається AUC короткого горизонту — з ним порівнюються всі
    # попередні розділи; `horizons` додає решту кривої.
    per_horizon = {
        str(horizon): train_module.number(
            hazard.auc_of(walked["curve"][known, index],
                          stream["labels"][known, index]), 4)
        for index, horizon in enumerate(hazard.HORIZONS)}
    return {"pair": stream["pair"],
            "events": int(len(stream["y"])),
            "labelled": int(known.sum()),
            "base_rate": round(float(truth.mean()), 4),
            "pivots": len(stream["pivots"]),
            "auc": train_module.number(hazard.auc_of(score, truth), 4),
            "horizons": per_horizon,
            "loss": train_module.number(walked["loss"], 4),
            "resets_own": len(own),
            "resets_forced": len(walked["resets"]) - len(own),
            "gate_min": train_module.number(walked["gate_min"]),
            "score": score, "truth": truth}


def build_report(source: Path, log=print) -> dict:
    started = time.time()
    source = source.resolve()
    report = json.loads(source.read_text(encoding="utf-8"))
    folder = HERE.parents[2] / report["model"]["path"]
    net = model_of(report, folder)
    knobs = report["model"]
    log(f"модель {report['model']['params']} ваг · горизонт "
        f"{knobs['horizons'][0]} · епоха {knobs['best_epoch']}")

    cut = legs_module.cut_stamp(base.CUT)
    walking = {"cap": knobs["cap"], "window": knobs["window"],
               "smooth": knobs["smooth"], "threshold": knobs["threshold"],
               "counter": knobs["counter"], "weight": knobs["weights"][0],
               "base": knobs["base_rate"], "gate": True,
               "slide": knobs.get("slide", False)}
    # Тип цілі береться зі звіту, а не з умовчання: детектор, зміряний
    # прогнозною міткою, дає осмислені на вигляд і повністю чужі числа.
    target = report["dataset"].get("distance", base.AHEAD)
    log(f"ціль: {target}")
    coins = []
    for name in [base.PAIR] + list(base.EXTRA):
        stream = base.stream_of(name, cut, "val", target,
                                report["dataset"].get("spread", False))
        if not stream:
            continue
        got = check(net, stream, walking, knobs["spans"], knobs["weights"])
        coins.append(got)
        log(f"  {got['pair']}: AUC {got['auc']} · подій {got['events']} "
            f"· мітка {got['base_rate']} · півотів {got['pivots']} "
            f"· своїх обнулень {got['resets_own']}")

    score = np.concatenate([one.pop("score") for one in coins])
    truth = np.concatenate([one.pop("truth") for one in coins])
    aucs = [one["auc"] for one in coins if one["auc"] is not None]
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "setup": {"source": str(source.relative_to(HERE.parents[2])),
                  "target": target,
                  "horizon": knobs["horizons"][0], "cut": base.CUT,
                  "best_epoch": knobs["best_epoch"],
                  "params": report["model"]["params"],
                  "narrow": {"auc": report["val"]["auc"][
                      str(knobs["horizons"][0])],
                      "events": report["val"]["events"],
                      "pivots": report["val"]["pivots"],
                      "about": "той самий прогін, тільки BTC"}},
        "coins": coins,
        "total": {
            "events": int(sum(one["events"] for one in coins)),
            "labelled": int(len(truth)),
            "pivots": int(sum(one["pivots"] for one in coins)),
            "resets_own": int(sum(one["resets_own"] for one in coins)),
            "resets_forced": int(sum(one["resets_forced"] for one in coins)),
            "auc_mean": train_module.number(float(np.mean(aucs)), 4),
            "auc_horizons": {
                str(horizon): train_module.number(float(np.mean(
                    [one["horizons"][str(horizon)] for one in coins
                     if one["horizons"][str(horizon)] is not None])), 4)
                for horizon in hazard.HORIZONS},
            "auc_pooled": train_module.number(hazard.auc_of(score, truth), 4),
            "base_rate": round(float(truth.mean()), 4),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(args.source)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    total = report["total"]
    print(f"шість монет · {total['events']} подій · {total['pivots']} півотів")
    print(f"AUC середнє по монетах {total['auc_mean']} · спільне "
          f"{total['auc_pooled']} · тільки BTC "
          f"{report['setup']['narrow']['auc']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
