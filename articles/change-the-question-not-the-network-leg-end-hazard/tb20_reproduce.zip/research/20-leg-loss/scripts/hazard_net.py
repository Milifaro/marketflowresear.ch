"""Чотири горизонти замість десятини: причинна ціль «нога скоро скінчиться».

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

## Чому не десятина

Розділ 5 заміряв: у 60 фічах події **немає** інформації про десятину
ноги — перцептрон без памʼяті дає рівно випадковість (`0.107` влучності
при `0.100` базовій). Причина не в мережі: десятина визначається повною
довжиною ноги, а вона відома лише заднім числом.

Той самий перцептрон на тих самих фічах відповідає на інше питання
помітно краще за випадковість:

| Горизонт | Частка мітки | AUC фіч |
| -------- | -----------: | ------: |
| 10 подій · 35 хв | 0.018 | **0.655** |
| 40 подій · 2.3 год | 0.072 | 0.631 |
| 160 подій · 9.3 год | 0.274 | 0.577 |

Дані знають, що **півот близько**, і не знають, яка це десятина ноги.
Перше — локальна властивість ціни, друге вимагає майбутнього.

## Чотири виходи

Мережа каже не «яка десятина», а чотири ймовірності:

    p₁₀ = P(лишилось ≤ 10)     p₄₀ = P(лишилось ≤ 40)
    p₁₆₀ = P(лишилось ≤ 160)   p₆₄₀ = P(лишилось ≤ 640)

Це одна крива — функція розподілу того, скільки подій лишилось до кінця
ноги, заміряна в чотирьох точках. Події вкладені: скінчиться за 10 —
скінчиться й за 40. Тому крива **мусить** зростати, і це вбудовано в
саму мережу, а не лишене на сподівання:

    h_k = сигмоїда(логіт_k)                    умовний ризик у корзині k
    F_1 = h_1
    F_k = F_{k−1} + (1 − F_{k−1}) · h_k        k = 2, 3, 4

`F_k` за побудовою лежить у `[0, 1]` і не спадає. Кожен логіт має свій
сенс: `h_k` — ймовірність, що нога скінчиться в корзині `k`, **якщо
дожила** до її початку.

## Навіщо саме четвертий горизонт

Три горизонти лишають дірку: `73 %` подій падають у хвіст «лишилось
понад 160», де оцінка стискається в одне число на всіх. Заміряна стеля
методу при **ідеальних** ймовірностях:

| Горизонти | Влучність десятини | Схожість | Подій у хвості |
| --------- | -----------------: | -------: | -------------: |
| 10 · 40 · 160 | 0.399 | 0.765 | 73 % |
| **10 · 40 · 160 · 640** | 0.508 | **0.951** | 26 % |

Один додатковий вихід піднімає стелю схожості з `0.765` до `0.951`.

## Де я в нозі — без знання довжини наперед

Різниці сусідніх точок кривої дають масу в кожній корзині, маса на
середнє «лишилось» усередині корзини дає очікуване лишилось:

    m₁ = F₁            m₂ = F₂ − F₁       m₃ = F₃ − F₂
    m₄ = F₄ − F₃       m₅ = 1 − F₄

    лишилось ≈ Σ mₖ · середнє_k

Середні по корзинах беруться з train і зберігаються у звіті. Далі
довжина ноги **оцінюється**, а не вгадується:

    пройдено = подій від останнього обнулення   ← лічильник, точно
    довжина  ≈ пройдено + лишилось
    десятина = 1 + ⌊10 · пройдено / довжина⌋

Обидві величини причинні. Десятина перестає бути міткою, яку треба
вгадати, і стає наслідком оцінки.

## Чому мережа з памʼяттю програвала перцептрону без неї

Замір без памʼяті дав `AUC 0.687`, та сама задача в LSTM з увагою —
`0.531`. Дві причини, обидві в тому, як побудований крок.

**1. Ворота стирали памʼять щокроку.** `ворота = 1 − p₁₀` бралися від
**зваженої** ймовірності, а вона для середньої події дорівнює `0.5`.
Стан множився на `0.65` на кожному кроці: за десять кроків від нього
лишалось `0.65¹⁰ ≈ 0.013`. Памʼять не доживала до наступної події.
Ворота від каліброваної `q` дають `1 − 0.018 = 0.982` — памʼять живе,
а стирається лише там, де модель справді бачить кінець.

**2. Голова була лінійна.** Перцептрон, який дав `0.687`, мав два шари
по 128 із `ReLU` над сирими фічами. Голова тут — один `Linear` над
виходом LSTM, тобто на подію припадало менше нелінійності, ніж у
базового рівня, який вона мала побити.

Обидві правки в `HazardNet`: ворота від `q` і **прямий шлях сирої
події в голову**. Голова бачить `[вихід LSTM, увага, сама подія]`, тому
не може виявитись гіршою за перцептрон без памʼяті: у неї є все, що
було в нього, і ще памʼять зверху.

## Обнулення

По короткому горизонту: памʼять стирають мʼякі лінійні ворота
`ворота = 1 − p₁₀`, жорсткий розрив — коли згладжене `p₁₀` перейшло
поріг. `POWER = 4` у розділі 5 глушив градієнт на чотири порядки, тому
крутизни тут немає взагалі.
"""

from __future__ import annotations

import numpy as np
import torch
from torch import nn

HORIZONS = (10, 40, 160, 640)          # подій уперед
LIFT = 10.0                            # у скільки разів вище за базову частоту
HIDDEN = 64                            # ширина LSTM
HEAD = 128                             # ширина голови
LAYERS = 1                             # скільки шарів LSTM один над одним
DROPOUT = 0.1


def set_horizons(values) -> tuple:
    """Змінити перелік горизонтів на весь модуль.

    Горизонти — не деталь голови, а сама постановка: від них залежать
    мітка, ваги класів, середні по корзинах і ширина видачі. Тому вони
    живуть одним числом у модулі, а прогін на іншому переліку міняє
    його тут, а не протягує список крізь десяток викликів.
    """
    global HORIZONS
    HORIZONS = tuple(int(value) for value in values)
    return HORIZONS


def labels_of(left: np.ndarray, horizons=None) -> np.ndarray:
    """Мітка на кожен горизонт: чи скінчиться нога в наступні `n` подій."""
    return np.stack([left < value for value in (horizons or HORIZONS)],
                    axis=-1)


def curve_of(logits: torch.Tensor) -> torch.Tensor:
    """Логіти → функція розподілу, яка не спадає за побудовою.

    `F_k = F_{k−1} + (1 − F_{k−1})·h_k`, де `h_k` — умовний ризик
    корзини. Працює і на одному кроці `(K,)`, і на пачці `(..., K)`.
    """
    hazard = torch.sigmoid(logits)
    parts, alive = [], torch.ones_like(hazard[..., 0])
    for index in range(hazard.shape[-1]):
        step = alive * hazard[..., index]
        previous = parts[-1] if parts else torch.zeros_like(step)
        parts.append(previous + step)
        alive = alive - step
    return torch.stack(parts, dim=-1)


def spans_of(left: np.ndarray, horizons=None) -> list:
    """Середнє «лишилось» усередині кожної корзини — рахується на train."""
    edges = list(horizons or HORIZONS)
    bucket = np.digitize(left, edges)
    out = []
    for index in range(len(edges) + 1):
        picked = left[bucket == index]
        out.append(float(picked.mean()) if len(picked)
                   else float(edges[min(index, len(edges) - 1)]))
    return out


def left_of(curve: np.ndarray, spans) -> np.ndarray:
    """Очікуване «лишилось до кінця ноги» з кривої розподілу."""
    curve = np.asarray(curve, dtype=np.float64)
    before = np.concatenate([np.zeros(curve.shape[:-1] + (1,)), curve],
                            axis=-1)
    after = np.concatenate([curve, np.ones(curve.shape[:-1] + (1,))], axis=-1)
    mass = np.clip(after - before, 0.0, 1.0)
    return (mass * np.asarray(spans)).sum(axis=-1)


def place_of(passed: np.ndarray, left: np.ndarray, parts: int = 10):
    """Десятина з пройденого і оціненого лишилось; довжина не потрібна."""
    total = np.maximum(np.asarray(passed) + np.asarray(left), 1.0)
    share = np.asarray(passed) / total
    return np.clip((share * parts).astype(int) + 1, 1, parts)


def weights_of(labels: np.ndarray) -> list:
    """Вага додатного класу на кожен горизонт: мітка рідка, 1.8 % на p₁₀."""
    out = []
    for index in range(labels.shape[-1]):
        column = labels[..., index]
        positive = float(column.sum())
        out.append(float((column.size - positive) / max(positive, 1.0)))
    return out


def calibrate(probability, weight: float):
    """Зважена ймовірність назад у справжню.

    Втрата множить додатний клас на `w`, тому її оптимум зсунутий угору:

        p* = w·q / (w·q + 1 − q)

    Для середньої події з базовою частотою `q = 0.018` і `w = 54` це
    дає `p* = 0.497`. Тобто **половина на виході означає звичайну
    подію**, а не «тут півот»: поріг 0.5 на такій шкалі відділяє «трохи
    вище за середнє» від «трохи нижче» і рве памʼять на 5.6 % подій.

    Зворотне перетворення повертає шкалу, на якій число знову означає
    те, що написано:

        q = p / ( w·(1 − p) + p )
    """
    return probability / (weight * (1.0 - probability) + probability)


def gate_of(probability, base: float):
    """Мʼякі ворота від **перевищення** над базовою частотою.

        ворота = 1 − (q − base) / (1 − base),   обрізано в [0, 1]

    Просте `1 − q` прив'язане до горизонту: на `10 подіях` базова
    частота `0.018` і середня подія майже не стирає памʼять, а на
    `100 подіях` вона вже `0.19` — стан множився б на `0.81` щокроку,
    і від памʼяті за десять кроків лишалось би `0.12`. Це рівно та
    поломка, через яку мережа з памʼяттю програвала перцептрону без неї.

    Відлік від базової частоти прибирає цю залежність: **звичайна подія
    памʼять не чіпає** на будь-якому горизонті, а стирає її лише те,
    що вище за звичайне. При `base = 0.018` формула збігається зі
    старою з точністю до 1.8 %.
    """
    excess = (probability - base) / max(1.0 - base, 1e-6)
    if isinstance(excess, torch.Tensor):
        return 1.0 - excess.clamp(0.0, 1.0)
    return 1.0 - min(max(excess, 0.0), 1.0)


def base_rate(labels: np.ndarray, index: int = 0) -> float:
    """Частка подій із міткою короткого горизонту — база для порога."""
    column = labels[..., index]
    return float(column.sum()) / max(column.size, 1)


def threshold_of(labels: np.ndarray, lift: float = LIFT) -> float:
    """Поріг обнулення як кратність базовій частоті.

    Абсолютне число тут нічого не значить: базова частота залежить від
    горизонту й від монети. Поріг задається в разах — «рвати памʼять,
    коли модель упевнена вдесятеро сильніше, ніж буває на випадковій
    події», — і сам підлаштовується під дані.
    """
    return min(lift * base_rate(labels), 0.99)


def masked_bce(curve: torch.Tensor, truth: torch.Tensor,
               weights: torch.Tensor) -> torch.Tensor:
    """Двійкова ентропія з вагою **додатного класу** на кожен горизонт.

    `torch.nn.functional.binary_cross_entropy(weight=...)` множить обидва
    класи однаково і рідку мітку не піднімає, тому вага пишеться руками:

        L_k = −( w_k · y · ln F_k + (1 − y) · ln(1 − F_k) )

    Мітка `p₁₀` стоїть на 1.8 % подій — без `w_k` мережа мінімізує
    втрату, завжди кажучи «ні».
    """
    safe = curve.clamp(1e-6, 1.0 - 1e-6)
    loss = -(weights * truth * torch.log(safe)
             + (1.0 - truth) * torch.log(1.0 - safe))
    return loss.mean()


def auc_of(score: np.ndarray, truth: np.ndarray) -> float:
    """Площа під ROC через ранги.

    При мітці на 2 % подій влучність не міряє нічого: модель, яка
    завжди каже «ні», має 98 %. AUC питає інше — **чи ставить модель
    подію з міткою вище за подію без неї**:

        AUC = ( Σ_{i ∈ додатні} rank_i − P·(P+1)/2 ) / ( P · N )

    `rank_i` — місце події у списку, впорядкованому за виданою оцінкою
    від меншої до більшої, рахуючи з 1; `P` — скільки подій із міткою,
    `N` — скільки без неї.

    Це рівно ймовірність того, що навмання взята подія з міткою дістане
    вищу оцінку, ніж навмання взята подія без неї. `0.5` — підкидання
    монети, `1.0` — ідеальний розділ, `0.0` — ідеальний навпаки.

    Віднімання `P·(P+1)/2` прибирає ранги, які додатні події займають
    одна щодо одної: рахується тільки те, скільки разів додатна подія
    обійшла відʼємну.
    """
    score, truth = np.asarray(score), np.asarray(truth, dtype=bool)
    order = np.argsort(score)
    rank = np.empty(len(score), dtype=np.float64)
    rank[order] = np.arange(1, len(score) + 1)
    positive, negative = truth.sum(), (~truth).sum()
    if not positive or not negative:
        return float("nan")
    return float((rank[truth].sum() - positive * (positive + 1) / 2)
                 / (positive * negative))


class HazardNet(nn.Module):
    """LSTM + причинна увага + прямий шлях події в голову.

    Голова бачить три речі одразу: стан LSTM, підсумок уваги на власну
    памʼять від обнулення і **сиру подію**. Останнє й відрізняє цю
    мережу від попередньої: без нього крок мав менше нелінійності, ніж
    перцептрон без памʼяті, який вона мала побити.

    Ходить по одній події (`step`) — так само, як іде і навчання, і
    прогін на вкладці, тому видача в них та сама.
    """

    def __init__(self, features: int, hidden: int = HIDDEN, heads: int = 2,
                 outputs: int | None = None, head: int = HEAD,
                 dropout: float = DROPOUT, layers: int = LAYERS,
                 attend: bool = True):
        super().__init__()
        outputs = len(HORIZONS) if outputs is None else outputs
        if hidden % heads:
            raise ValueError("ширина має ділитись на кількість голів")
        self.features, self.hidden, self.heads = features, hidden, heads
        self.outputs, self.layers, self.attend = outputs, layers, attend
        self.lstm = nn.LSTM(features, hidden, num_layers=layers,
                            batch_first=True,
                            dropout=dropout if layers > 1 else 0.0)
        self.norm = nn.LayerNorm(hidden)
        if attend:
            self.query = nn.Linear(hidden, hidden)
            self.key = nn.Linear(hidden, hidden)
            self.value = nn.Linear(hidden, hidden)
            self.mix = nn.LayerNorm(hidden)
        width = hidden * (2 if attend else 1) + features
        self.head = nn.Sequential(
            nn.Linear(width, head), nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(head, head), nn.ReLU(),
            nn.Linear(head, outputs))

    def look_back(self, now: torch.Tensor,
                  memory: torch.Tensor) -> torch.Tensor:
        """Увага однієї події на всю памʼять від останнього обнулення."""
        size = self.hidden // self.heads
        q = self.query(now).view(1, 1, self.heads, size).transpose(1, 2)
        k = self.key(memory).view(1, -1, self.heads, size).transpose(1, 2)
        v = self.value(memory).view(1, -1, self.heads, size).transpose(1, 2)
        weight = torch.softmax((q @ k.transpose(-2, -1))
                               / (size ** 0.5), dim=-1)
        return self.mix((weight @ v).transpose(1, 2).reshape(1, 1,
                                                             self.hidden))

    def step(self, event: torch.Tensor, state, memory: list):
        """Одна подія: логіти горизонтів, новий стан і новий крок памʼяті."""
        out, state = self.lstm(event.view(1, 1, -1), state)
        now = self.norm(out)
        parts = [now]
        if self.attend:
            parts.append(self.look_back(now, torch.cat(memory + [now], dim=1)))
        parts.append(event.view(1, 1, -1))
        return self.head(torch.cat(parts, dim=-1))[0, 0], state, now

    def zero(self, device=None):
        """Порожній стан: нова нога починається з чистої памʼяті."""
        shape = (self.layers, 1, self.hidden)
        return (torch.zeros(shape, device=device),
                torch.zeros(shape, device=device))


def parameters_of(model: nn.Module) -> int:
    """Скільки ваг навчається."""
    return sum(one.numel() for one in model.parameters() if one.requires_grad)
