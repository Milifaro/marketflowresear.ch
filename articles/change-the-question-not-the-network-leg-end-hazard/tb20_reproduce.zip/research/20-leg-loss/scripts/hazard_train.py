"""Навчання на чотири горизонти, памʼять обнуляє сама модель.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання, Навчання без свопа

Постановка, побудова кривої і виведення десятини описані в
[`hazard_net.py`](hazard_net.py). Тут — потік, втрата й міри.

## Дані

Ряд не ріжеться на ноги: кожна монета йде одним потоком, мережа сама
вирішує, де кінець. Розбиття **за датою**, межа `2026-08-14 15:27` UTC.
Train — шість монет до межі, валідація — BTC після межі.

Мітка на кожній події — чотири нулі й одиниці: чи скінчиться нога в
наступні 10, 40, 160, 640 подій. Зігзаг лишається тільки джерелом
міток, місце обнулення він більше не задає.

## Втрата

Проста двійкова ентропія на кожен горизонт, зважена рідкістю мітки:

    L = Σ_k w_k · BCE(F_k, [лишилось < n_k]) / 4

`w_k` рахується на train: додатних подій на `p₁₀` лише 1.8 %, і без ваги
мережа просто завжди казала б «ні». Жодних штрафів за сходинку,
пониження чи затримку — розділ 5 показав, що вони гальмують навчання, а
монотонність тут забезпечена самою побудовою кривої.

## Обнулення

Мʼякі ворота стирають памʼять пропорційно **перевищенню над базовою
частотою** (`hazard_net.gate_of`), жорсткий розрив — коли згладжена
ймовірність перейшла поріг. Стеля `CAP` лишається запобіжником і
рахується окремо.

## Один горизонт

`--horizons 100` лишає **один** вихід: «півот у наступні 100 подій».
Тоді ніякої кривої розподілу немає — є одне число, і питання до нього
одне: чи ставить воно подію перед півотом вище за звичайну. Тому
найкраща епоха вибирається за **AUC цього горизонту**, а не за
схожістю десятини: десятина з одного числа виводиться з двох середніх
і сходинкою стрибає між ними — міряти нею нічого.

## Скільки епох

Стелі немає: прогін іде, **поки росте схожість**. Зупиняє його не
лічильник епох, а `patience` — стільки епох підряд без нового максимуму,
і далі міняється постановка, а не кількість проходів. У звіт і у
збережені ваги йде **найкраща** епоха, а не остання: після максимуму
`val` уже росте.

## Що міряється

- **AUC на кожен горизонт** — чи є сигнал; при мітці на 2 % влучність
  міряє лише вміння мовчати.
- **Схожість виведеної десятини** — те саме число, що й раніше, тому
  порівнюється напряму з рівнями: лічильник `0.5625`, константа
  `0.300`, стеля методу `0.951`.
- **Свої обнулення проти примусових** — чи знайшла мережа півот сама.

Запуск:

    python3 research/20-leg-loss/scripts/hazard_train.py
    python3 research/20-leg-loss/scripts/hazard_train.py --epochs 4
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_net as hazard            # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
MODELS = HERE.parent / "models"
REPORT = RESULTS / "hazard_train.json"

PAIR = walk_train.PAIR
EXTRA = walk_train.EXTRA
CUT = walk_train.CUT
CAP = walk_train.CAP
WINDOW = walk_train.WINDOW
EPOCHS = 60                            # стеля; зупиняє схожість, а не це
LR = 3e-4
PATIENCE = 3
SMOOTH = 10                            # ЕМА згладження p₁₀ перед розривом
SEED = 0


AHEAD = "лишилось"                     # скільки подій до кінця ноги
BEHIND = "пройдено"                    # скільки подій від початку ноги
FIRST = "перша_десятина"               # подія в перших 10 % ноги
NEARER = "ближче"                      # наступний півот ближчий за минулий
UPWARD = "вгору"                       # наступний півот вище поточної ціни

# Двійкові цілі: одне питання, один вихід, горизонтів немає.
BINARY = {
    FIRST: "чи лежить подія в перших 10 % ноги",
    NEARER: "чи ближчий наступний півот, ніж минулий",
    UPWARD: "чи буде наступний півот вище поточної ціни",
}


def stream_of(pair: str, cut: int, part: str, target: str = AHEAD,
              spread: bool = False) -> dict:
    """Потік монети з міткою відстані до півота — уперед або назад.

    `лишилось` — прогноз: скільки подій **до** кінця ноги. Мітка
    горизонту `n` означає «нога скінчиться в наступні `n` подій».

    `пройдено` — детектор: скільки подій **від** останнього півота.
    Мітка означає «розворот уже стався, і не далі ніж `n` подій тому».
    Питання дзеркальне і принципово легше: подія після півота вже
    бачить, що ціна повернула, а подія перед ним мусить це вгадати.

    Обидві відстані причинні по-різному. «Пройдено» видно на місці, без
    майбутнього взагалі; «лишилось» відоме тільки заднім числом і йде
    у мітку, а не у фічі.
    """
    one = walk_train.stream_of(pair, cut, part)
    if not one:
        return {}
    if spread:
        one["x"] = np.concatenate([one["x"], spread_of(one["x"])], axis=1)
    total = len(one["y"])
    places = sorted(item.index - one["offset"] for item in one["pivots"])
    left = np.full(total, -1, dtype=np.int64)
    since = np.full(total, -1, dtype=np.int64)
    start = 0
    for place in places:
        if place < 0:
            continue
        stop = min(place, total - 1)
        left[start:stop + 1] = np.arange(stop - start, -1, -1)
        if start:                      # до першого півота «пройдено» невідоме
            since[start:stop + 1] = np.arange(stop - start + 1)
        start = stop + 1
    if start and start < total:        # хвіст після останнього півота
        since[start:] = np.arange(total - start)
    if target in BINARY:
        one.update(binary_of(one, left, since, target))
        one["target"] = target
        return one
    distance = left if target == AHEAD else since
    one["left"] = distance             # −1 там, де відстань невідома
    one["known"] = distance >= 0
    one["labels"] = hazard.labels_of(np.maximum(distance, 0))
    one["target"] = target
    return one


BLOCKS = 15                            # блоків по 14 с у події
BASE_FEATURES = 4                      # balance · d_balance · vol_balance · ціна


def spread_of(x: np.ndarray) -> np.ndarray:
    """Розмах кожної фічі між 15 блоками події — `max − min`.

    Замір показав, що середнє значення фічі по події не каже нічого
    (`AUC 0.50 … 0.52`), а **розмах** каже багато: перед півотом блоки
    події стають однорідними, далеко від нього — розкидані. Одна ця
    ознака дає `AUC 0.687` на `d_balance` проти `0.732` у всієї мережі.

    Мережа могла б порахувати її сама, але не з такої голови: `max` по
    блоках — не те, що складається з лінійних шарів і `ReLU` за
    розумну кількість кроків. Тому вона подається готовою.
    """
    blocks = x.reshape(len(x), BLOCKS, BASE_FEATURES)
    return (blocks.max(axis=1) - blocks.min(axis=1)).astype(np.float32)


def binary_of(one: dict, left: np.ndarray, since: np.ndarray,
              target: str) -> dict:
    """Мітка й маска для двійкової цілі — один вихід замість кривої.

    `перша_десятина` — `пройдено < 0.1 · довжина`. Довжина відома лише
    заднім числом, тому це та сама десятина, яку розділ 5 визнав
    невивчуваною; тут вона питається одним двійковим питанням, і
    відповідь на нього може виявитись іншою.

    `ближче` — `лишилось < пройдено`. Мітка збалансована за побудовою
    (половина подій у кожній нозі), тому ваги класу не потрібні, а AUC
    міряє рівно «в якій половині ноги подія».

    `вгору` — ціна наступного півота вище поточної. Питання не про час,
    а про **напрямок**, і воно єдине з трьох прямо потрібне торгівлі.
    """
    total = len(left)
    price = np.asarray(one["price"], dtype=np.float64)
    both = (left >= 0) & (since >= 0)
    if target == FIRST:
        length = np.maximum(since + left, 1)
        label = since < 0.1 * length
        known = both
    elif target == NEARER:
        label = left < since
        known = both
    else:                              # UPWARD: ціна в точці півота
        at = np.arange(total) + np.maximum(left, 0)
        at = np.minimum(at, total - 1)
        label = price[at] > price
        known = left >= 0
    return {"left": np.where(known, np.maximum(since, 0), -1),
            "known": known,
            "labels": label[:, None].astype(bool)}


def walk_stream(model, stream: dict, knobs: dict, spans, weights,
                optimizer=None) -> dict:
    """Один прохід потоком: крок, крива, мʼякі ворота, розрив по `p₁₀`."""
    device = next(model.parameters()).device
    steps = torch.tensor(stream["x"], device=device)
    labels = torch.tensor(stream["labels"].astype(np.float32), device=device)
    known = stream["known"]
    total = len(known)
    state = model.zero(device)
    memory: list[torch.Tensor] = []
    weight = torch.tensor(weights, device=device, dtype=torch.float32)
    curves = np.zeros((total, len(hazard.HORIZONS)), dtype=np.float32)
    calibrated = np.zeros(total, dtype=np.float32)
    passed = np.zeros(total, dtype=np.int64)
    losses, chunk, resets, gates = [], [], [], []
    alpha = 2.0 / (knobs["smooth"] + 1.0)
    run = None

    for index in range(total):
        held = len(memory)
        step = steps[index]
        if knobs["counter"]:
            step = torch.cat([step, walk_train.counter_of(held, knobs["cap"],
                                                          device)])
        logits, state, now_step = model.step(step, state, memory)
        curve = hazard.curve_of(logits)
        # Втрата множить додатний клас на `w`, тому вихід зсунутий угору:
        # для середньої події він дорівнює 0.5. Ворота й поріг беруться
        # від **каліброваної** ймовірності, інакше стан множиться на 0.65
        # щокроку і памʼять не доживає до наступної події.
        short = hazard.calibrate(curve[0], knobs["weight"])

        if knobs.get("gate", True):
            gate = hazard.gate_of(short, knobs["base"])
            state = (state[0] * gate, state[1] * gate)
        else:
            gate = torch.ones((), device=device)

        if known[index]:
            loss = hazard.masked_bce(curve, labels[index], weight)
            chunk.append(loss)
            losses.append(float(loss.item()))
        memory.append(now_step)
        curves[index] = curve.detach().cpu().numpy()
        calibrated[index] = float(short.detach())
        passed[index] = held
        gates.append(float(gate.detach()))

        value = float(short.detach())
        run = value if run is None else alpha * value + (1 - alpha) * run

        if optimizer is not None and len(chunk) >= knobs["window"]:
            optimizer.zero_grad()
            torch.stack(chunk).mean().backward()
            optimizer.step()
            chunk = []
            state = tuple(part.detach() for part in state)
            memory = [item.detach() for item in memory]

        if knobs.get("slide"):
            # Памʼять не обнуляється взагалі: стан іде наскрізь усім
            # потоком, увага дивиться ковзним вікном останніх `cap`
            # подій. Обнулення лишало нуль історії одразу після себе —
            # для питання «розворот у цих N подіях» це означало, що
            # доказу немає в принципі. Тут вікно завжди повне.
            if len(memory) > knobs["cap"]:
                memory = memory[-knobs["cap"]:]
            continue

        forced = len(memory) >= knobs["cap"]
        if run >= knobs["threshold"] or forced:
            resets.append({"at": index, "after": len(memory),
                           "kind": "стеля" if forced and run < knobs["threshold"]
                                   else "поріг"})
            state = model.zero(device)
            memory = []
            run = None
            if optimizer is not None and chunk:
                optimizer.zero_grad()
                torch.stack(chunk).mean().backward()
                optimizer.step()
                chunk = []

    if optimizer is not None and chunk:
        optimizer.zero_grad()
        torch.stack(chunk).mean().backward()
        optimizer.step()
    return {"loss": float(np.mean(losses)) if losses else None,
            "curve": curves, "calibrated": calibrated,
            "passed": passed, "resets": resets,
            "gate_min": float(np.min(gates)) if gates else None,
            "gate_mean": float(np.mean(gates)) if gates else None}


def scores_of(stream: dict, walked: dict, spans) -> dict:
    """AUC на кожен горизонт і схожість виведеної десятини."""
    known = stream["known"]
    curve, passed = walked["curve"], walked["passed"]
    aucs = {}
    for index, horizon in enumerate(hazard.HORIZONS):
        aucs[str(horizon)] = train_module.number(
            hazard.auc_of(curve[known, index],
                          stream["labels"][known, index]), 3)
    left = hazard.left_of(curve, spans)
    said = hazard.place_of(passed, left)
    truth = stream["y"]
    seen = known & (truth > 0)
    own = [item for item in walked["resets"] if item["kind"] == "поріг"]
    return {
        "events": int(len(truth)),
        "auc": aucs,
        "resets_own": len(own),
        "resets_forced": len(walked["resets"]) - len(own),
        "pivots": len(stream["pivots"]),
        "left_mean": train_module.number(float(left[known].mean()), 1)
        if known.any() else None,
        "max_said": train_module.number(float(said[seen].max()), 2)
        if seen.any() else None,
        "kinds": sorted({int(value) for value in said[seen]}) if seen.any()
        else [],
        "accuracy": train_module.number(float((said[seen] == truth[seen])
                                              .mean())) if seen.any() else None,
        "distance": train_module.number(
            float(np.abs(said[seen] - truth[seen]).mean()), 3)
        if seen.any() else None,
        "similar": train_module.number(
            float((np.abs(said[seen] - truth[seen]) <= 1).mean()))
        if seen.any() else None,
        "said": said,
    }


def score_of(got: dict) -> float:
    """Число, за яким вибирається найкраща епоха.

    Багато горизонтів — схожість виведеної десятини: вона зводить усю
    криву в одну міру. Один горизонт — AUC цього горизонту: більше в
    видачі нічого й немає.
    """
    if "wide" in got:
        return got["wide"]
    if len(hazard.HORIZONS) > 1:
        return got["similar"] or 0.0
    value = got["auc"][str(hazard.HORIZONS[0])]
    return 0.0 if value is None or value != value else float(value)


def wide_score(model, streams: list, knobs: dict, spans, weights) -> dict:
    """Середнє AUC по всіх монетах після межі — стійка міра епохи.

    Вибір епохи по одному BTC — це відбір на 3 800 подіях і шести
    півотах. Розділ 11 показав, чим це кінчається: епоха з `AUC 0.703`
    на BTC дала `0.6589` середнього по шести монетах, тобто **гірше**
    за епоху з `0.604`. Пік на вузькому val не переносився нікуди.

    Тут епоха вибирається по 28 870 подіях і 63 півотах одразу.
    """
    aucs, per_coin = [], {}
    for stream in streams:
        with torch.no_grad():
            walked = walk_stream(model, stream, knobs, spans, weights)
        known = stream["known"]
        # Міра йде по **всіх** горизонтах, а не по короткому: модель
        # видає криву цілком, і епоха, яка виграла на `p₁₀`, могла
        # зіпсувати решту. Один горизонт — та сама формула, один доданок.
        got = [hazard.auc_of(walked["curve"][known, index],
                             stream["labels"][known, index])
               for index in range(len(hazard.HORIZONS))]
        good = [float(one) for one in got if one == one]
        if good:
            aucs.append(float(np.mean(good)))
        per_coin[stream["pair"]] = {
            str(horizon): train_module.number(value, 3)
            for horizon, value in zip(hazard.HORIZONS, got)}
    return {"wide": float(np.mean(aucs)) if aucs else 0.0,
            "coins": per_coin}


def build_report(epochs: int = EPOCHS, lift: float = hazard.LIFT,
                 counter: bool = True, patience: int = PATIENCE,
                 shape: dict | None = None, wide: bool = False,
                 log=print) -> dict:
    shape = shape or {}
    cut = legs_module.cut_stamp(CUT)
    torch.manual_seed(SEED)
    device = "cpu"
    target = shape.get("target", AHEAD)
    spread = shape.get("spread", False)
    train_streams = [stream_of(PAIR, cut, "train", target, spread)]
    for name in EXTRA:
        train_streams.append(stream_of(name, cut, "train", target, spread))
    val_stream = stream_of(PAIR, cut, "val", target, spread)
    wide_streams = []
    if wide:
        wide_streams = [val_stream] + [
            one for one in (stream_of(name, cut, "val", target, spread)
                            for name in EXTRA) if one]

    # Ширина входу береться з самих потоків, а не з константи: додані
    # ознаки міняють її, і мовчазна незбіжність тут коштувала б прогону.
    width = int(train_streams[0]["x"].shape[1]) + (1 if counter else 0)
    model = hazard.HazardNet(features=width, heads=2,
                             outputs=len(hazard.HORIZONS),
                             hidden=shape.get("hidden", hazard.HIDDEN),
                             head=shape.get("head", hazard.HEAD),
                             dropout=shape.get("dropout", hazard.DROPOUT),
                             layers=shape.get("layers", hazard.LAYERS),
                             ).to(device)
    rate = shape.get("lr", LR)
    optimizer = torch.optim.Adam(model.parameters(), lr=rate)

    # Середні по корзинах і ваги класів — тільки з train.
    left = np.concatenate([one["left"][one["known"]] for one in train_streams])
    spans = hazard.spans_of(left)
    labels = np.concatenate([one["labels"][one["known"]]
                             for one in train_streams])
    weights = hazard.weights_of(labels)
    base = hazard.base_rate(labels)
    threshold = hazard.threshold_of(labels, lift)
    knobs = {"cap": shape.get("cap", CAP),
             "window": shape.get("window", WINDOW),
             "smooth": SMOOTH,
             "threshold": threshold, "counter": counter,
             "weight": weights[0], "base": base,
             "slide": shape.get("slide", False)}
    log(f"мережа {hazard.parameters_of(model)} ваг · виходів "
        f"{len(hazard.HORIZONS)} · шарів {model.layers} · "
        + (f"ковзне вікно {knobs['cap']}" if knobs["slide"]
           else f"стеля {knobs['cap']}")
        + f" · вікно градієнта {knobs['window']}")
    log(f"поріг обнулення: базова частота {base:.4f} × {lift:g} "
        f"= {threshold:.3f} каліброваної ймовірності")
    log("середнє лишилось по корзинах: "
        + " · ".join(f"{value:.1f}" for value in spans))
    log("ваги класів: " + " · ".join(f"{value:.0f}" for value in weights))

    streams = [{"pair": one["pair"], "part": one["part"],
                "events": int(len(one["y"])),
                "labelled": int(one["known"].sum()),
                "from_utc": legs_module.utc(int(one["t"][0])),
                "to_utc": legs_module.utc(int(one["t"][-1]))}
               for one in train_streams + [val_stream]]
    log("потоки train: " + " · ".join(
        f"{one['pair']} {len(one['y'])}" for one in train_streams)
        + f" · val {len(val_stream['y'])}")

    started, curve, best_score = time.time(), [], -1.0
    best_state, best_epoch = None, None
    metric = ("широке AUC" if wide else
              ("схожість" if len(hazard.HORIZONS) > 1 else "AUC"))
    for epoch in range(1, epochs + 1):
        model.train()
        losses = [walk_stream(model, one, knobs, spans, weights,
                              optimizer)["loss"] for one in train_streams]
        model.eval()
        with torch.no_grad():
            checked = walk_stream(model, val_stream, knobs, spans, weights)
        got = scores_of(val_stream, checked, spans)
        if wide_streams:
            got.update(wide_score(model, wide_streams, knobs, spans, weights))
        # Округлення одне на всіх: у криву і в порівняння йде те саме
        # число. Інакше найкраща епоха порівнюється округленою з власним
        # неокругленим максимумом, виходить «менша за себе», і `patience`
        # зупиняє прогін одразу після неї.
        score = train_module.number(score_of(got))
        curve.append({"epoch": epoch,
                      "wide": train_module.number(got.get("wide")),
                      "coins": got.get("coins"),
                      "train": train_module.number(float(np.mean(losses)), 4),
                      "val": train_module.number(checked["loss"], 4),
                      "auc": got["auc"],
                      "similar": got["similar"], "distance": got["distance"],
                      "accuracy": got["accuracy"],
                      "left_mean": got["left_mean"],
                      "kinds": len(got["kinds"]),
                      "resets_own": got["resets_own"],
                      "resets_forced": got["resets_forced"],
                      "gate_min": train_module.number(checked["gate_min"]),
                      "score": score})
        log(f"  епоха {epoch}: train {curve[-1]['train']} · val "
            f"{curve[-1]['val']} · AUC "
            + "/".join(str(got["auc"][str(one)]) for one in hazard.HORIZONS)
            + (f" · широке {curve[-1]['wide']}" if wide_streams else "")
            + f" · схожість {got['similar']} · своїх обнулень "
            f"{got['resets_own']} · стелею {got['resets_forced']} "
            f"· ворота min {curve[-1]['gate_min']}")
        # Вчимо, поки схожість росте, і лишаємо ваги **найкращої**
        # епохи: останні йдуть уже вниз по val.
        if score > best_score:
            best_score = score
            best_epoch = epoch
            best_state = {key: value.detach().clone()
                          for key, value in model.state_dict().items()}
        stale = sum(1 for row in curve[-patience:]
                    if (row["score"] or 0) < best_score) \
            if len(curve) > patience else 0
        if stale >= patience:
            log(f"  {metric} не росте {patience} епохи підряд — зупинка")
            break

    if best_state is not None:
        model.load_state_dict(best_state)
        log(f"  беремо ваги епохи {best_epoch}: {metric} {best_score}")
    folder = MODELS / (shape.get("name") or
                       ("hazard" if len(hazard.HORIZONS) > 1
                        else f"hazard{hazard.HORIZONS[0]}"))
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "model.pt")
    model.eval()
    with torch.no_grad():
        checked = walk_stream(model, val_stream, knobs, spans, weights)
    got = scores_of(val_stream, checked, spans)
    said = got.pop("said")
    levels = walk_train.baseline_of()
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "model": {"path": str(folder.relative_to(HERE.parents[2])),
                  "params": hazard.parameters_of(model),
                  "hidden": model.hidden, "heads": 2,
                  "layers": model.layers, "head": model.head[0].out_features,
                  "outputs": len(hazard.HORIZONS),
                  "horizons": list(hazard.HORIZONS),
                  "threshold": round(threshold, 4), "lift": lift,
                  "base_rate": round(base, 4),
                  "cap": knobs["cap"], "window": knobs["window"], "lr": rate,
                  "slide": knobs["slide"],
                  "epochs": epochs,
                  "smooth": SMOOTH, "counter": counter, "seed": SEED,
                  "best_epoch": best_epoch, "patience": patience,
                  "picked_by": metric, "wide_val": bool(wide_streams),
                  "spans": [round(value, 1) for value in spans],
                  "weights": [round(value, 1) for value in weights]},
        "dataset": {"pair": PAIR, "extra": list(EXTRA), "cut": CUT,
                    "class": "клас210х14х4ц", "scaler": "розподіл",
                    "event_seconds": legs_module.EVENT_SECONDS,
                    "features": width, "spread": spread,
                    "target": BINARY.get(
                        target,
                        "чи скінчиться нога в наступні N подій"
                        if target == AHEAD else
                        "чи стався розворот у попередні N подій"),
                    "distance": target,
                    "streams": streams,
                    "train_events": sum(one["events"] for one in streams
                                        if one["part"] == "train"),
                    "val_events": sum(one["events"] for one in streams
                                      if one["part"] == "val")},
        "baseline": levels,
        "ceiling": {"similar": 0.951, "accuracy": 0.508,
                    "about": "виведена десятина при ідеальних чотирьох "
                             "ймовірностях"}
        if len(hazard.HORIZONS) > 1 else None,
        "curve": curve,
        "val": got,
        "series": {
            "events": int(len(val_stream["y"])),
            "from_utc": legs_module.utc(int(val_stream["t"][0])),
            "to_utc": legs_module.utc(int(val_stream["t"][-1])),
            "t": val_stream["t"].astype(int).tolist(),
            "price": [round(float(value), 2) for value in val_stream["price"]],
            "ema": [round(float(value), 2) for value in val_stream["ema"]],
            "y": [float(value) for value in val_stream["y"]],
            "cls": [float(value) for value in said],
            "p": [round(float(value), 4) for value in checked["calibrated"]],
            "left": [round(float(value), 1) for value
                     in hazard.left_of(checked["curve"], spans)],
            "resets": [item["at"] for item in checked["resets"]],
            "own": [item["at"] for item in checked["resets"]
                    if item["kind"] == "поріг"],
            "pivots": [{"t": int(val_stream["t"][item.index
                                                 - val_stream["offset"]]),
                        "price": round(float(val_stream["price"][
                            item.index - val_stream["offset"]]), 2),
                        "ema": round(float(val_stream["ema"][
                            item.index - val_stream["offset"]]), 2),
                        "kind": item.kind}
                       for item in val_stream["pivots"]],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--horizons", type=int, nargs="+",
                        default=list(hazard.HORIZONS),
                        help="горизонти в подіях; один — одна ймовірність")
    parser.add_argument("--lift", type=float, default=hazard.LIFT,
                        help="у скільки разів вище за базову частоту рвати")
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--no-counter", dest="counter", action="store_false")
    parser.add_argument("--layers", type=int, help="шарів LSTM один над одним")
    parser.add_argument("--hidden", type=int, help="ширина стану LSTM")
    parser.add_argument("--head", type=int, help="ширина голови")
    parser.add_argument("--dropout", type=float)
    parser.add_argument("--lr", type=float, help="крок навчання")
    parser.add_argument("--window", type=int, help="вікно градієнта, подій")
    parser.add_argument("--cap", type=int, help="стеля памʼяті, подій")
    parser.add_argument("--target", default=AHEAD,
                        choices=(AHEAD, BEHIND, *BINARY),
                        help="лишилось — прогноз, пройдено — детектор, "
                             "решта — двійкові питання")
    parser.add_argument("--slide", action="store_true",
                        help="не обнуляти памʼять: ковзне вікно на cap подій")
    parser.add_argument("--spread", action="store_true",
                        help="додати розмах кожної фічі між блоками події")
    parser.add_argument("--name", help="папка для ваг у models/")
    parser.add_argument("--wide-val", dest="wide", action="store_true",
                        help="вибирати епоху за середнім AUC шести монет")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    # Двійкова ціль — один вихід і жодних горизонтів; список лишається
    # одноелементним тільки щоб форми збіглися з рештою машинерії.
    hazard.set_horizons([1] if args.target in BINARY else args.horizons)
    train_module.no_swap(force=args.force)
    shape = {key: getattr(args, key)
             for key in ("layers", "hidden", "head", "dropout", "lr",
                         "window", "cap", "name", "target", "slide",
                         "spread")
             if getattr(args, key) is not None}
    report = build_report(args.epochs, args.lift, args.counter,
                          args.patience, shape, args.wide)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    got = report["val"]
    print("AUC: " + " · ".join(f"{one} {got['auc'][str(one)]}"
                               for one in hazard.HORIZONS))
    if len(hazard.HORIZONS) > 1:
        print(f"схожість виведеної десятини {got['similar']} ", end="· ")
    print(f"своїх обнулень {got['resets_own']} з {got['pivots']} півотів")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
