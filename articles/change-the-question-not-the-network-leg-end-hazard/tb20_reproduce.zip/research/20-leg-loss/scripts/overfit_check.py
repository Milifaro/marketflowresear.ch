"""Чи здатна мережа перевчити напамʼять маленький шматок ряду.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання, Навчання без свопа

## Навіщо

Розділи 3 і 4 дали видачу, яка **не відрізняється від константи**:

| Що відповідає | Влучність | Схожість |
| ------------- | --------: | -------: |
| таблиця пошуку по «скільки подій від початку ноги» | 0.281 | 0.550 |
| постійна відповідь «6», без жодних даних | 0.100 | 0.300 |
| мережа, 46 282 ваги, 336 471 подія за епоху | 0.089 | 0.299 |

Поки видача вироджена, міняти функцію втрат немає сенсу: вона чесно
мінімізується відмовою відповідати. Спершу треба відповісти на інше
питання — **чи працює сам механізм навчання**.

Перевірка стандартна: дати мережі шматок, який вона фізично може
запамʼятати, і вчити доти, доки втрата не впаде майже в нуль.

- **Перевчила** — код і градієнт справні, причина в постановці задачі
  або в силі членів втрати на повному ряді.
- **Не перевчила** — баг у самому навчанні: усічений BPTT, мʼякі
  ворота, обнулення памʼяті. Тоді ручки втрати ні до чого.

## Прогони

Усі — на першому шматку потоку train `BTC_USDT_29`, `EVENTS` подій,
той самий seed, та сама мережа `ширина 64 · увага 2 гол.`

| Прогін | Втрата | Ворота | Лічильник |
| ------ | ------ | ------ | --------- |
| `ентропія` | тільки CE | `POWER 4` | ні |
| `ентропія+лічильник` | тільки CE | `POWER 4` | так |
| `повна` | CE + затримка + пониження + стрибок | `POWER 1` | так |

Перші два розділяють два питання: «чи вчиться взагалі» і «чи допомагає
ознака-лічильник». Третій показує, чи не заважає навчанню сама втрата
з памʼяттю про час.

Оцінка йде **на тому самому шматку** — це навмисно: тут міряється
здатність запамʼятати, а не узагальнити.

Запуск:

    python3 research/20-leg-loss/scripts/overfit_check.py
    python3 research/20-leg-loss/scripts/overfit_check.py --epochs 40
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_net as net_module       # noqa: E402
import leg_end_train as train_module   # noqa: E402
import timed_loss                      # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "overfit_check.json"

EVENTS = 2000                          # подій у шматку
EPOCHS = 60
LR = 3e-4
SEED = 0
GOOD = 0.90                            # схожість, з якої вважаємо перевченим

ZERO = {"late": 0.0, "ahead": 0.0, "back": 0.0, "jump": 0.0}
FULL = {"late": timed_loss.LATE, "ahead": timed_loss.AHEAD,
        "back": timed_loss.BACK, "jump": timed_loss.JUMP}

RUNS = {
    "ентропія": {"knobs": ZERO, "power": 4.0, "counter": False,
                 "about": "тільки перехресна ентропія, ворота 4, без лічильника"},
    "ентропія+лічильник": {"knobs": ZERO, "power": 4.0, "counter": True,
                           "about": "тільки ентропія, ворота 4, з лічильником"},
    "повна": {"knobs": FULL, "power": 1.0, "counter": True,
              "about": "повна втрата, ворота 1, з лічильником"},
}


def slice_of(events: int = EVENTS, log=print) -> dict:
    """Перші `events` подій потоку train BTC — шматок, який має влізти."""
    cut = legs_module.cut_stamp(walk_train.CUT)
    stream = walk_train.stream_of(walk_train.PAIR, cut, "train")
    keep = slice(0, min(events, len(stream["y"])))
    small = {key: stream[key] for key in ("pair", "part", "offset")}
    for key in ("x", "y", "t", "price", "ema", "spans"):
        small[key] = stream[key][keep]
    small["pivots"] = [item for item in stream["pivots"]
                       if item.index - stream["offset"] < keep.stop]
    known = int((small["y"] > 0).sum())
    log(f"шматок: {len(small['y'])} подій · з міткою {known} · "
        f"{legs_module.utc(int(small['t'][0]))} … "
        f"{legs_module.utc(int(small['t'][-1]))}")
    return small


def one_run(small: dict, name: str, plan: dict, epochs: int,
            lr: float = LR, log=print) -> dict:
    """Один прогін: вчимо і міряємо на тому самому шматку."""
    classes = legs_module.PARTS_OF_LEG
    torch.manual_seed(SEED)
    device = "cpu"
    model = net_module.LegEnd(features=walk_train.features_of(plan["counter"]),
                              hidden=64, heads=2, attention=True,
                              outputs=classes).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    knobs = {"cap": walk_train.CAP, "window": walk_train.WINDOW,
             "smooth": train_module.SMOOTH, "power": plan["power"],
             "counter": plan["counter"], **plan["knobs"]}
    log(f"[{name}] {plan['about']} · {net_module.parameters_of(model)} ваг")
    started, curve, reached = time.time(), [], None
    for epoch in range(1, epochs + 1):
        model.train()
        walk_train.walk_stream(model, small, classes, knobs, optimizer, log)
        model.eval()
        with torch.no_grad():
            checked = walk_train.walk_stream(model, small, classes, knobs,
                                             None, log)
        got = walk_train.scores_of(small, checked, classes)
        curve.append({"epoch": epoch,
                      "loss": train_module.number(checked["loss"]),
                      "similar": got["similar"], "accuracy": got["accuracy"],
                      "distance": got["distance"],
                      "kinds": len(got["kinds"]),
                      "max_said": got["max_said"],
                      "resets_own": got["resets_own"],
                      "gate_min": train_module.number(checked["gate_min"])})
        if reached is None and (got["similar"] or 0) >= GOOD:
            reached = epoch
        if epoch == 1 or epoch % 5 == 0 or epoch == epochs:
            log(f"  епоха {epoch}: втрата {curve[-1]['loss']} · схожість "
                f"{curve[-1]['similar']} · влучність {curve[-1]['accuracy']} "
                f"· значень {curve[-1]['kinds']} · макс {curve[-1]['max_said']}"
                f" · ворота min {curve[-1]['gate_min']}")
    best = max(curve, key=lambda row: row["similar"] or 0)
    return {"name": name, "about": plan["about"], "power": plan["power"],
            "lr": lr,
            "counter": plan["counter"], "knobs": plan["knobs"],
            "minutes": train_module.number((time.time() - started) / 60, 2),
            "curve": curve, "best": best, "reached_epoch": reached,
            "overfit": bool(reached),
            "series": {"y": [float(v) for v in small["y"]],
                       "cls": [float(v) for v in checked["said"]]}}


def build_report(names=tuple(RUNS), events: int = EVENTS,
                 epochs: int = EPOCHS, lr: float = LR, log=print) -> dict:
    small = slice_of(events, log)
    runs = [one_run(small, name, RUNS[name], epochs, lr, log)
            for name in names]
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "events": int(len(small["y"])),
        "labelled": int((small["y"] > 0).sum()),
        "epochs": epochs, "lr": lr, "seed": SEED, "good": GOOD,
        "from_utc": legs_module.utc(int(small["t"][0])),
        "to_utc": legs_module.utc(int(small["t"][-1])),
        "baseline": {"constant": {"accuracy": 0.100, "similar": 0.300},
                     "counter": {"accuracy": 0.281, "similar": 0.550}},
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--runs", nargs="+", default=list(RUNS),
                        choices=list(RUNS))
    parser.add_argument("--events", type=int, default=EVENTS)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(tuple(args.runs), args.events, args.epochs, args.lr)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    for run in report["runs"]:
        best = run["best"]
        verdict = (f"перевчила на епосі {run['reached_epoch']}"
                   if run["overfit"] else "НЕ перевчила")
        print(f"{run['name']}: {verdict} · краща схожість {best['similar']} "
              f"· влучність {best['accuracy']} · значень видачі {best['kinds']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
