"""Навчання, де памʼять обнуляє сама модель, а не зігзаг.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання, Навчання без свопа

## Чим це відрізняється від усього попереднього

Досі ряд **різався на ноги по півотах зігзага**, і кожна нога заходила
в мережу з чистим станом `h = c = 0`. Півот підтверджується заднім
числом, тому «чистий старт рівно на першій події ноги» — знання, якого
наживо немає. Модель його отримувала безкоштовно і тому ніколи не
вчилась знаходити кінець ноги: за неї це робив зігзаг.

Тут ряд не ріжеться. Мережа йде потоком подія за подією і **сама
вирішує, де кінець**:

    крок t -> LSTM(стан) -> причинна увага на памʼять від обнулення
           -> сказаний клас десятини 1 ... 10
    сказала 10  ->  тут півот  ->  h, c = 0, памʼять порожня
                    наступна подія починає нову ногу з класу 1

Зігзаг лишається **тільки міткою**: він каже, яка десятина правильна на
кожній події. Де починати нову ногу — не його справа.

## Мʼякі ворота: обнулення, крізь яке проходить градієнт

Жорстке `if сказала 10 -> h, c = 0` — **дискретна дія**, і градієнт
через неї не тече: мережа ніколи не дізнається, що обнулення в цьому
місці зменшило б втрату. Тому памʼять стирає сама впевненість у кінці
ноги:

    ворота = 1 − p₁₀ ^ POWER
    h ← h · ворота        c ← c · ворота        на кожному кроці

`POWER` задає крутизну. Перші прогони йшли з `POWER = 4` — і саме він
глушив усе навчання: при `p₁₀ = 0.1` ворота дорівнюють `0.9999`, а
похідна по `p₁₀` — `−4·p₁₀³ = −0.004`. Сигнал «тут варто було стерти
памʼять» приходив у ваги ослабленим на чотири порядки, і заміряні
ворота ніколи не опускались нижче `0.9995`: памʼять не стиралась взагалі.

`POWER = 1` робить ворота лінійними — `ворота = 1 − p₁₀`, похідна рівно
`−1` на будь-якій упевненості. Градієнт проходить крізь них у повну
силу: якщо стерти було корисно, `p₁₀` отримає плюс, якщо шкідливо —
мінус.

Жорстке обнулення лишається поруч і рахується як **своє обнулення**:
коли згладжений сказаний клас дійшов до останнього, памʼять і буфер
уваги чистяться повністю. Мʼякі ворота вчать, жорсткий розрив показує
результат.

## Лічильник подій від обнулення

Проста таблиця пошуку, яка знає **тільки скільки подій минуло від
початку ноги**, дає влучність `0.281` і схожість `0.550`. Мережа з
46 282 вагами давала `0.089` і `0.299` — рівно стільки, скільки дає
постійна відповідь «6». Тобто найінформативнішу величину задачі LSTM
із 60 фіч не виводив.

Тому вона подається **ознакою**, 61-ю:

    лічильник = log1p(подій від останнього обнулення) / log1p(CAP)

Величина причинна: скільки кроків минуло від обнулення, модель знає
наживо, нічого з майбутнього тут немає. Логарифм дає густу роздільність
там, де вона потрібна, — на перших десятках подій ноги, — і стискає
хвіст довгих ніг. Ділення на `log1p(CAP)` тримає ознаку в `[0, 1]`, як
решта входу.

## Запобіжник

Якщо мережа не скаже 10 ніколи, памʼять не обнулиться сама. Стеля
`CAP` подій обнуляє примусово, і такі обнулення рахуються **окремо** —
по них видно, чи навчилась модель робити це сама.

## Усічений BPTT

Градієнт іде назад на `WINDOW` кроків, далі стан відривається
(`detach`). Без цього граф ріс би на весь потік і памʼяті не
вистачило б (`rules/03` → Навчання без свопа).

Втрата — та сама, що в розділі 2, на кожному кроці:

    CE + ordinal·(E − y)² + reach·max(C − E, 0)² на подіях класу C
       + jump·max(Δ−1,0)² + down·max(−Δ,0)²  на сусідніх кроках

Запуск:

    python3 research/20-leg-loss/scripts/walk_train.py
    python3 research/20-leg-loss/scripts/walk_train.py --epochs 2
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))

import leg_end_data as legs_module     # noqa: E402
import leg_end_net as net_module       # noqa: E402
import leg_end_train as train_module   # noqa: E402
import leg_end_walk as walk_module     # noqa: E402

sys.path.insert(0, str(HERE))
import timed_loss                      # noqa: E402

RESULTS = HERE.parent / "results"
MODELS = HERE.parent / "models"
REPORT = RESULTS / "walk_train.json"

PAIR = legs_module.PAIR                # BTC_USDT_29 — і train, і val
EXTRA = legs_module.EXTRA_PAIRS        # пʼять монет, тільки train
CUT = legs_module.CUT
CAP = 1500                             # стеля памʼяті, подій
WINDOW = 150                           # кроків до відриву градієнта
EPOCHS = 8
LR = 3e-4
PATIENCE = 2                           # епох без зростання схожості
POWER = 1                              # крутизна мʼяких воріт: 1 − p₁₀^POWER
COUNTER = True                         # подій від обнулення — 61-ю ознакою
ORDINAL = 0.1
REACH = 0.1
SEED = 0


def stream_of(pair: str, cut: int, part: str) -> dict:
    """Потік однієї монети: події, мітка десятини, півоти — без нарізки."""
    one = legs_module.prepare(pair, None, legs_module.LENGTH,
                              legs_module.SHARE, "decile", 10)
    stamps = one["data"]["t"]
    keep = stamps <= cut if part == "train" else stamps > cut
    span = np.flatnonzero(keep)
    if not len(span):
        return {}
    window = slice(int(span[0]), int(span[-1]) + 1)
    x = np.nan_to_num(one["data"]["x"].reshape(len(one["data"]["x"]), -1),
                      nan=0.0)
    return {"pair": pair, "part": part,
            "x": x[window].astype(np.float32),
            "y": one["label"][window].astype(np.float32),
            "t": stamps[window],
            "price": one["data"]["price"][window],
            "ema": one["ema"][window],
            "spans": timed_loss.class_spans(one["label"][window]),
            "pivots": [item for item in one["pivots"]
                       if window.start <= item.index < window.stop],
            "offset": int(window.start)}





def features_of(counter: bool = COUNTER) -> int:
    """Ширина входу мережі: фічі події плюс лічильник, якщо він увімкнений."""
    return legs_module.FEATURES + (1 if counter else 0)


def counter_of(held: int, cap: int, device) -> torch.Tensor:
    """Лічильник подій від обнулення, стиснутий у `[0, 1]` логарифмом."""
    value = float(np.log1p(held) / np.log1p(max(cap, 2)))
    return torch.tensor([min(value, 1.0)], device=device,
                        dtype=torch.float32)


def walk_stream(model, stream: dict, classes: int, knobs: dict,
                optimizer=None, log=print) -> dict:
    """Один прохід потоком. З `optimizer` — навчання, без нього — оцінка.

    Памʼять обнуляється, коли **модель** сказала останній клас; стеля
    обнуляє примусово і рахується окремо.
    """
    device = next(model.parameters()).device
    steps = torch.tensor(stream["x"], device=device)
    truth = stream["y"]
    hidden = model.hidden
    zero = lambda: torch.zeros(1, 1, hidden, device=device)   # noqa: E731
    state = (zero(), zero())
    # Памʼять — список кроків, а не один буфер: запис у буфер на місці
    # ламає граф градієнта (autograd бачить змінений тензор).
    memory: list[torch.Tensor] = []
    previous = None
    said = np.zeros(len(truth), dtype=np.float32)
    levels = torch.arange(1, classes + 1, device=device, dtype=torch.float32)
    spans = stream["spans"]
    delay = timed_loss.Delay()
    losses, chunk, resets, gates = [], [], [], []
    behind, ahead_of, worst = 0, 0, 0
    previous_true = None
    alpha = 2.0 / (knobs["smooth"] + 1.0) if knobs["smooth"] > 1 else 1.0
    run = None

    for index in range(len(truth)):
        # Скільки подій минуло від останнього обнулення. Величина
        # причинна — з майбутнього тут нічого немає, — і саме вона дає
        # базовому лічильнику 0.550 схожості проти 0.299 у мережі.
        step = steps[index]
        if knobs.get("counter"):
            step = torch.cat([step, counter_of(len(memory), knobs["cap"],
                                               device)])
        out, state = model.lstm(step.view(1, 1, -1), state)
        now = model.norm(out)
        memory.append(now)
        held = len(memory)
        if model.attention:
            feature = torch.cat(
                [now, walk_module.look_back_step(model, now,
                                                 torch.cat(memory, dim=1))],
                dim=-1)
        else:
            feature = now
        logits = model.head(model.drop(feature))[0, 0]
        spread = torch.softmax(logits, dim=-1)
        expected = (spread * levels).sum()

        # Мʼякі ворота: впевненість у кінці ноги сама стирає памʼять, і
        # градієнт проходить крізь неї — на відміну від жорсткого розриву.
        gate = 1.0 - spread[classes - 1].pow(knobs["power"])
        state = (state[0] * gate, state[1] * gate)

        if truth[index] > 0:
            loss, _ = timed_loss.step_loss(
                logits, expected, truth[index], spans[index], delay,
                previous, previous_true, knobs, classes)
            chunk.append(loss)
            losses.append(float(loss.item()))
            behind += int(delay.late > 0)
            ahead_of += int(delay.ahead > 0)
            worst = max(worst, delay.late, delay.ahead)
        previous_true = truth[index]
        previous = expected
        gates.append(float(gate.detach()))

        value = float(expected.detach())
        run = value if run is None else alpha * value + (1 - alpha) * run
        said[index] = min(max(round(run), 1), classes)

        if optimizer is not None and len(chunk) >= knobs["window"]:
            optimizer.zero_grad()
            torch.stack(chunk).mean().backward()
            optimizer.step()
            chunk = []
            state = tuple(part.detach() for part in state)
            memory = [item.detach() for item in memory]
            previous = previous.detach()

        forced = held >= knobs["cap"]
        if said[index] == classes or forced:
            resets.append({"at": index, "after": held,
                           "kind": "стеля" if forced and said[index] != classes
                                   else "клас 10"})
            state = (zero(), zero())
            memory = []
            previous, run = None, None
            delay.reset()
            if optimizer is not None and chunk:
                optimizer.zero_grad()
                torch.stack(chunk).mean().backward()
                optimizer.step()
                chunk = []

    if optimizer is not None and chunk:
        optimizer.zero_grad()
        torch.stack(chunk).mean().backward()
        optimizer.step()
    counted = max(len(losses), 1)
    return {"loss": float(np.mean(losses)) if losses else None,
            "said": said, "resets": resets,
            "gate_min": float(np.min(gates)) if gates else None,
            "gate_mean": float(np.mean(gates)) if gates else None,
            "behind": behind / counted, "ahead": ahead_of / counted,
            "worst_delay": int(worst)}


def scores_of(stream: dict, walked: dict, classes: int) -> dict:
    """Що вийшло: свої обнулення, влучність класу, чи доходить до кінця."""
    said = walked["said"]
    truth = stream["y"]
    known = truth > 0
    own = [item for item in walked["resets"] if item["kind"] == "клас 10"]
    pivots = [item.index - stream["offset"] for item in stream["pivots"]]
    near = 0
    for item in own:                       # обнулення в останній десятині
        gap = min((abs(item["at"] - place) for place in pivots), default=None)
        if gap is not None and gap <= max(1, int(0.1 * len(truth) / max(
                len(pivots), 1))):
            near += 1
    return {
        "events": int(len(truth)),
        "resets_own": len(own),
        "resets_forced": len(walked["resets"]) - len(own),
        "near_pivot": near,
        "pivots": len(pivots),
        "max_said": train_module.number(float(said.max()), 2),
        "kinds": sorted({float(value) for value in said}),
        "said_top": int((said == classes).sum()),
        "accuracy": train_module.number(float((said[known] == truth[known])
                                              .mean())) if known.any() else None,
        "distance": train_module.number(
            float(np.abs(said[known] - truth[known]).mean()), 3)
        if known.any() else None,
        # Схожість ряду видачі на ціль: частка подій, де промах не
        # більший за один клас. Саме за нею видно, чи стають графіки
        # дедалі подібнішими від епохи до епохи.
        "similar": train_module.number(
            float((np.abs(said[known] - truth[known]) <= 1).mean()))
        if known.any() else None,
    }


def baseline_of() -> dict | None:
    """Рівень, який треба побити: таблиця пошуку по одному лічильнику.

    Береться з готового виводу `baseline_check.py`; якщо його немає,
    вкладка просто не показує рядок порівняння.
    """
    where = RESULTS / "baseline_check.json"
    if not where.exists():
        return None
    got = json.loads(where.read_text(encoding="utf-8"))
    return {"counter": got["baselines"]["counter"],
            "constant": got["baselines"]["constant"],
            "entropy": got["entropy"]}


def build_report(epochs: int = EPOCHS, knobs_in: dict | None = None,
                 patience: int = PATIENCE, log=print) -> dict:
    """Навчання потоком і оцінка на val — усе під самообнуленням."""
    knobs_in = knobs_in or {}
    cut = legs_module.cut_stamp(CUT)
    classes = legs_module.PARTS_OF_LEG
    knobs = {"cap": CAP, "window": WINDOW, "smooth": train_module.SMOOTH,
             "late": knobs_in.get("late", timed_loss.LATE),
             "ahead": knobs_in.get("ahead", timed_loss.AHEAD),
             "back": knobs_in.get("back", timed_loss.BACK),
             "jump": knobs_in.get("jump", timed_loss.JUMP),
             "power": knobs_in.get("power", POWER),
             "counter": knobs_in.get("counter", COUNTER)}
    torch.manual_seed(SEED)
    device = "cpu"                     # хід по одній події: CPU швидший
    model = net_module.LegEnd(features=features_of(knobs["counter"]),
                              hidden=64, heads=2, attention=True,
                              outputs=classes).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    log(f"мережа {net_module.parameters_of(model)} ваг · стеля памʼяті {CAP} "
        f"· вікно градієнта {WINDOW} · lr {LR}")

    train_streams = [stream_of(PAIR, cut, "train")]
    for name in EXTRA:
        train_streams.append(stream_of(name, cut, "train"))
    val_stream = stream_of(PAIR, cut, "val")
    streams = [{"pair": one["pair"], "part": "train",
                "events": int(len(one["y"])),
                "from_utc": legs_module.utc(int(one["t"][0])),
                "to_utc": legs_module.utc(int(one["t"][-1]))}
               for one in train_streams]
    streams.append({"pair": val_stream["pair"], "part": "val",
                    "events": int(len(val_stream["y"])),
                    "from_utc": legs_module.utc(int(val_stream["t"][0])),
                    "to_utc": legs_module.utc(int(val_stream["t"][-1]))})
    log("потоки train: " + " · ".join(
        f"{one['pair']} {len(one['y'])}" for one in train_streams)
        + f" · val {len(val_stream['y'])}")

    started, curve = time.time(), []
    for epoch in range(1, epochs + 1):
        model.train()
        losses = []
        for one in train_streams:
            walked = walk_stream(model, one, classes, knobs, optimizer, log)
            losses.append(walked["loss"])
        model.eval()
        with torch.no_grad():
            checked = walk_stream(model, val_stream, classes, knobs, None, log)
        got = scores_of(val_stream, checked, classes)
        curve.append({"epoch": epoch,
                      "train": train_module.number(float(np.mean(losses))),
                      "val": train_module.number(checked["loss"]),
                      "gate_min": train_module.number(checked["gate_min"]),
                      "gate_mean": train_module.number(checked["gate_mean"]),
                      "behind": train_module.number(checked["behind"]),
                      "ahead": train_module.number(checked["ahead"]),
                      "worst_delay": checked["worst_delay"],
                      "distance": got["distance"], "similar": got["similar"],
                      "kinds": len(got["kinds"]),
                      **{key: got[key] for key in ("resets_own",
                                                   "resets_forced",
                                                   "max_said", "accuracy")}})
        best = max((row["similar"] or 0) for row in curve)
        stale = sum(1 for row in curve[-patience:]
                    if (row["similar"] or 0) < best) if len(curve) > patience \
            else 0
        log(f"  епоха {epoch}: train {curve[-1]['train']} · val "
            f"{curve[-1]['val']} · своїх обнулень {got['resets_own']} "
            f"· стелею {got['resets_forced']} · макс класу {got['max_said']} "
            f"· влучність {got['accuracy']} · ворота min "
            f"{curve[-1]['gate_min']} · позаду {curve[-1]['behind']:.0%} "
            f"· попереду {curve[-1]['ahead']:.0%} "
            f"· найдовша затримка {curve[-1]['worst_delay']} "
            f"· схожість {curve[-1]['similar']} · відстань "
            f"{curve[-1]['distance']} · значень видачі {curve[-1]['kinds']}")
        if stale >= patience:
            log(f"  схожість не росте {patience} епохи підряд — зупинка")
            break

    folder = MODELS / "walk_self_reset"
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "model.pt")
    model.eval()
    with torch.no_grad():
        checked = walk_stream(model, val_stream, classes, knobs, None, log)
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "model": {"path": str(folder.relative_to(HERE.parents[2])),
                  "params": net_module.parameters_of(model),
                  "hidden": 64, "heads": 2, "classes": classes,
                  "cap": CAP, "window": WINDOW, "lr": LR, "epochs": epochs,
                  "seed": SEED, **{key: knobs[key] for key in
                                   ("late", "ahead", "back", "jump",
                                    "smooth", "power", "counter")}},
        "dataset": {"pair": PAIR, "extra": list(EXTRA), "cut": CUT,
                    "class": "клас210х14х4ц", "scaler": "розподіл",
                    "event_seconds": legs_module.EVENT_SECONDS,
                    "features": features_of(knobs["counter"]),
                    "target": "десятина ноги зігзага 2.3 % на ема10",
                    "streams": streams,
                    "train_events": sum(one["events"] for one in streams
                                        if one["part"] == "train"),
                    "val_events": sum(one["events"] for one in streams
                                      if one["part"] == "val")},
        "baseline": baseline_of(),
        "loss": {
            "formula": "L = CE(логіти, y)"
                       " + late·(кроків позаду / T)·max(y − E, 0)"
                       " + ahead·(кроків попереду / T)·max(E − y, 0)"
                       " + back·max(E_{t−1} − E_t, 0)²  (крім межі ноги)"
                       " + jump·max(Δ − 1, 0)²",
            "terms": [
                {"name": "CE", "when": "завжди",
                 "what": "перехресна ентропія до правильної десятини"},
                {"name": "затримка", "when": "E < y — не дійшла",
                 "what": "ціна росте з кожною подією позаду, поділена на "
                         "тривалість десятини T"},
                {"name": "випередження", "when": "E > y — не відпустила",
                 "what": "те саме в другий бік: нога скінчилась, а видача "
                         "тримає старий клас"},
                {"name": "пониження", "when": "E впало, а ціль не падала",
                 "what": "найдорожчий член: крок униз (2→1, 3→2, … 10→9) "
                         "коштує рівно back, бо мітка всередині ноги тільки "
                         "росте; на межі ноги, де ціль падає сама, "
                         "штрафу немає"},
                {"name": "стрибок", "when": "E зросло більше ніж на клас",
                 "what": "видача має йти сходинками по +1"},
            ],
        },
        "curve": curve,
        "val": scores_of(val_stream, checked, classes),
        "series": {
            "events": int(len(val_stream["y"])),
            "from_utc": legs_module.utc(int(val_stream["t"][0])),
            "to_utc": legs_module.utc(int(val_stream["t"][-1])),
            "t": val_stream["t"].astype(int).tolist(),
            "price": [round(float(value), 2) for value in val_stream["price"]],
            "ema": [round(float(value), 2) for value in val_stream["ema"]],
            "y": [float(value) for value in val_stream["y"]],
            "cls": [float(value) for value in checked["said"]],
            "resets": [item["at"] for item in checked["resets"]],
            "own": [item["at"] for item in checked["resets"]
                    if item["kind"] == "клас 10"],
            "pivots": [{"t": int(val_stream["t"][item.index
                                                 - val_stream["offset"]]),
                        "price": round(float(val_stream["price"][
                            item.index - val_stream["offset"]]), 2),
                        "ema": round(float(val_stream["ema"][
                            item.index - val_stream["offset"]]), 2),
                        "kind": item.kind}
                       for item in val_stream["pivots"]],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--late", type=float, default=timed_loss.LATE)
    parser.add_argument("--ahead", type=float, default=timed_loss.AHEAD)
    parser.add_argument("--back", type=float, default=timed_loss.BACK,
                        help="ціна пониження видачі всередині ноги")
    parser.add_argument("--jump", type=float, default=timed_loss.JUMP)
    parser.add_argument("--patience", type=int, default=PATIENCE,
                        help="епох без зростання схожості до зупинки")
    parser.add_argument("--power", type=float, default=POWER,
                        help="крутизна мʼяких воріт: 1 − p₁₀^POWER")
    parser.add_argument("--no-counter", dest="counter", action="store_false",
                        help="без ознаки «подій від обнулення»")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(args.epochs,
                          {"late": args.late, "ahead": args.ahead,
                           "back": args.back, "jump": args.jump,
                           "power": args.power, "counter": args.counter},
                          args.patience)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    got = report["val"]
    print(f"val: своїх обнулень {got['resets_own']} з {got['pivots']} півотів "
          f"· стелею {got['resets_forced']} · максимум класу {got['max_said']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
