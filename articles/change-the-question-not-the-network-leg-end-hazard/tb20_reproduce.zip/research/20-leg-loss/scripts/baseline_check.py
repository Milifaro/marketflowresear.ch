"""Базові рівні: з чим порівнювати мережу на задачі десятини ноги.

Дослідження: research/20-leg-loss/
Правила: rules/01-data-and-db.md → класи, rules/03-models.md → Правила навчання

## Навіщо

Втрата 30 або 26 сама по собі не каже нічого. Питання завжди одне: **чи
краще це за тривіальну відповідь**. Тут рахуються дві такі відповіді на
тих самих ногах, що йдуть у навчання.

| Рівень | Що знає | Як відповідає |
| ------ | ------- | ------------- |
| **константа** | нічого | завжди той самий клас |
| **лічильник** | скільки подій минуло від початку ноги | найчастіша десятина на цьому елапсі |

Лічильник — це таблиця пошуку по одному цілому числу, без жодної фічі
ціни. Величина причинна: скільки кроків минуло від початку ноги, модель
знає наживо. Якщо мережа з 46 282 вагами не б'є цю таблицю, справа не в
ручках функції втрат.

## Метод

1. Ноги будуються тим самим викликом, що й у навчанні:
   `leg_end_data.build(mode="decile", period=10)`, шість монет, межа
   `2026-08-14 15:27` — рівно те, що бачить мережа на train.
2. Для кожної події рахується її десятина `d = ⌊t·10 / n⌋`, де `t` —
   номер події в нозі, `n` — довжина ноги.
3. Елапс кладеться в корзини по `BIN` подій. У кожній корзині
   береться найчастіша десятина — це і є відповідь лічильника.
4. Міряються ті самі два числа, що й у навчанні: **влучність** класу і
   **схожість** — частка подій, де промах не більший за один клас.

Заразом рахується **ентропія десятини при відомому елапсі**: скільки
невизначеності лишається, коли час від початку ноги вже відомий. Це
стеля для будь-якої моделі, яка спирається тільки на лічильник.

Запуск:

    python3 research/20-leg-loss/scripts/baseline_check.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "baseline_check.json"

BIN = 10                               # подій у корзині елапсу
CAP_BIN = 300                          # далі всі елапси в одну корзину


def deciles_of(lengths) -> list:
    """Десятина кожної події кожної ноги: `⌊t·10 / n⌋`, значення 0 … 9."""
    return [np.minimum((np.arange(int(n)) * 10) // int(n), 9)
            for n in lengths]


def table_of(lengths, rows, bin_size: int = BIN) -> dict:
    """Розподіл десятин у кожній корзині елапсу."""
    table: dict[int, np.ndarray] = {}
    for row in rows:
        for step, value in enumerate(row):
            key = min(step // bin_size, CAP_BIN)
            table.setdefault(key, np.zeros(10))[int(value)] += 1
    return table


def score(said, truth) -> dict:
    """Ті самі два числа, що в навчанні: влучність і схожість."""
    said, truth = np.asarray(said), np.asarray(truth)
    return {"accuracy": train_module.number(float((said == truth).mean())),
            "similar": train_module.number(
                float((np.abs(said - truth) <= 1).mean())),
            "distance": train_module.number(
                float(np.abs(said - truth).mean()), 3)}


def build_report(log=print) -> dict:
    built = legs_module.build(legs_module.PAIR, mode="decile", period=10,
                              extra=legs_module.EXTRA_PAIRS,
                              cut=legs_module.CUT, log=lambda *a: None)
    legs = built["legs"]
    lengths = np.array([len(one["events"]) for one in legs])
    rows = deciles_of(lengths)
    truth = np.concatenate(rows)
    log(f"ніг {len(legs)} · подій {len(truth)} · довжина ноги: медіана "
        f"{np.median(lengths):.0f} · 25% {np.percentile(lengths, 25):.0f} "
        f"· 75% {np.percentile(lengths, 75):.0f} · max {lengths.max()}")

    table = table_of(lengths, rows)
    best = {key: int(value.argmax()) for key, value in table.items()}
    said = np.concatenate([[best[min(step // BIN, CAP_BIN)]
                            for step in range(len(row))] for row in rows])
    counter = score(said, truth)

    # Константа: найкращий сталий клас — по суті будь-який, десятини рівні.
    counts = np.bincount(truth, minlength=10)
    constant = max((score(np.full_like(truth, value), truth)
                    for value in range(10)),
                   key=lambda got: got["similar"])

    share = np.array([value / value.sum() for value in table.values()])
    entropy = -(share * np.log(np.clip(share, 1e-9, 1))).sum(1)

    log(f"лічильник: влучність {counter['accuracy']} · схожість "
        f"{counter['similar']}")
    log(f"константа: влучність {constant['accuracy']} · схожість "
        f"{constant['similar']}")
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "dataset": {"class": "клас210х14х4ц", "pair": built["pair"],
                    "extra": list(built["extra"]), "cut": built["cut"],
                    "legs": int(len(legs)), "events": int(len(truth))},
        "leg_length": {"median": int(np.median(lengths)),
                       "q25": int(np.percentile(lengths, 25)),
                       "q75": int(np.percentile(lengths, 75)),
                       "max": int(lengths.max())},
        "bin": BIN,
        "baselines": {"constant": constant, "counter": counter},
        "decile_counts": [int(value) for value in counts],
        "entropy": {"mean_nats": train_module.number(float(entropy.mean()), 3),
                    "max_nats": train_module.number(float(np.log(10)), 3),
                    "explained": train_module.number(
                        float(1 - entropy.mean() / np.log(10)))},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    report = build_report()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    got = report["entropy"]
    print(f"ентропія десятини при відомому елапсі {got['mean_nats']} ніт "
          f"з {got['max_nats']} — час знімає {got['explained']:.0%}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
