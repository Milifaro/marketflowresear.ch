"""Скільки сигналу про десятину ноги взагалі є у фічах події.

Дослідження: research/20-leg-loss/
Правила: rules/01-data-and-db.md → класи, rules/03-models.md → Правила навчання

## Навіщо

До цього моменту всі невдачі списувались на щось усередині мережі:
функцію втрат, ворота, обнулення памʼяті, критерій зупинки. Розділ 5
показав, що жодне з цього не винне — механізм навчання справний, а
результат не рухається.

Лишилось питання, якого ще ніхто не ставив: **чи є в 60 фічах події
взагалі інформація про десятину ноги**. Воно перевіряється без памʼяті,
без уваги і без обнулень — звичайним класифікатором подія → десятина.

| Модель | Що бачить | Що доводить |
| ------ | --------- | ----------- |
| `лічильник` | тільки скільки подій від початку ноги | рівень, який дає сам час |
| `фічі` | тільки 60 фіч ціни й обʼєму | чи є сигнал у самих даних |
| `фічі+лічильник` | і те, і те | чи додають фічі щось понад час |

- **`фічі` на рівні випадковості** — у даних сигналу немає, і жодна
  архітектура його не знайде. Міняти треба ціль або клас, а не мережу.
- **`фічі+лічильник` не кращі за `лічильник`** — фічі не додають нічого
  понад те, що вже дає час від початку ноги.
- **`фічі+лічильник` помітно кращі** — сигнал є, і провал у мережі з
  памʼяттю треба шукати в тому, як вона цю памʼять веде.

## Метод

Ноги будуються тим самим викликом, що й у навчанні
(`leg_end_data.build(mode="decile", period=10)`), розбиття **за ногами**:
кожна нога цілком іде або в train, або у val, щоб події однієї ноги не
опинились в обох вибірках.

Класифікатор — двошаровий перцептрон `вхід → HIDDEN → 10`, без памʼяті:
кожна подія рахується сама по собі. Перемішування повне, тому жодного
знання про порядок подій він не має — тільки те, що записано в самій
події.

Міряються ті самі два числа, що й у навчанні: **влучність** класу і
**схожість** — частка подій, де промах не більший за один клас.

Запуск:

    python3 research/20-leg-loss/scripts/signal_check.py
    python3 research/20-leg-loss/scripts/signal_check.py --epochs 20
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "signal_check.json"

HIDDEN = 128
EPOCHS = 12
BATCH = 4096
LR = 1e-3
SEED = 0
VAL_SHARE = 0.2                        # частка ніг у валідацію

RUNS = {
    "лічильник": {"features": False, "counter": True,
                  "about": "тільки подій від початку ноги"},
    "фічі": {"features": True, "counter": False,
             "about": "тільки 60 фіч ціни й обʼєму"},
    "фічі+лічильник": {"features": True, "counter": True,
                       "about": "60 фіч і лічильник разом"},
}


def rows_of(built: dict, log=print) -> dict:
    """Плоска таблиця подій: фічі, лічильник, десятина, номер ноги.

    Береться з того самого пакунку, що йде в мережу: `x` (ноги × події ×
    фічі), `y` (десятина 1 … 10) і `mask` — де подія справжня, а де
    добивка до спільної довжини.
    """
    x, y, mask = built["x"], built["y"], built["mask"]
    legs, steps = np.nonzero(mask)
    place = np.zeros(len(legs), dtype=np.float32)
    lengths = np.asarray(built["lengths"], dtype=np.float32)
    place = steps / np.maximum(lengths[legs], 1.0)          # частка ноги
    table = {
        "x": np.nan_to_num(x[legs, steps], nan=0.0).astype(np.float32),
        "counter": (np.log1p(steps) / np.log1p(walk_train.CAP))
        .clip(0, 1).astype(np.float32).reshape(-1, 1),
        "y": np.minimum((place * 10).astype(np.int64), 9),
        "leg": legs.astype(np.int64),
    }
    log(f"подій {len(table['y'])} · ніг {len(np.unique(table['leg']))} "
        f"· фіч {table['x'].shape[1]}")
    return table


def split_of(table: dict, share: float = VAL_SHARE) -> tuple:
    """Розбиття за ногами: нога цілком в одній вибірці."""
    legs = np.unique(table["leg"])
    rng = np.random.default_rng(SEED)
    picked = set(rng.choice(legs, size=max(int(len(legs) * share), 1),
                            replace=False).tolist())
    keep = np.array([value in picked for value in table["leg"]])
    return ~keep, keep


def input_of(table: dict, plan: dict) -> np.ndarray:
    """Вхід моделі за планом прогону."""
    columns = []
    if plan["features"]:
        columns.append(table["x"])
    if plan["counter"]:
        columns.append(table["counter"])
    return np.concatenate(columns, axis=1)


def score(said: np.ndarray, truth: np.ndarray) -> dict:
    return {"accuracy": train_module.number(float((said == truth).mean())),
            "similar": train_module.number(
                float((np.abs(said - truth) <= 1).mean())),
            "distance": train_module.number(
                float(np.abs(said - truth).mean()), 3)}


def one_run(table: dict, name: str, plan: dict, train_mask, val_mask,
            epochs: int, log=print) -> dict:
    """Перцептрон без памʼяті: подія всередині, десятина назовні."""
    torch.manual_seed(SEED)
    data = input_of(table, plan)
    x_train = torch.tensor(data[train_mask])
    y_train = torch.tensor(table["y"][train_mask])
    x_val = torch.tensor(data[val_mask])
    y_val = table["y"][val_mask]
    model = torch.nn.Sequential(
        torch.nn.Linear(data.shape[1], HIDDEN), torch.nn.ReLU(),
        torch.nn.Linear(HIDDEN, HIDDEN), torch.nn.ReLU(),
        torch.nn.Linear(HIDDEN, 10))
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    log(f"[{name}] {plan['about']} · вхід {data.shape[1]} · "
        f"train {len(y_train)} · val {len(y_val)}")
    started, curve = time.time(), []
    generator = torch.Generator().manual_seed(SEED)
    for epoch in range(1, epochs + 1):
        model.train()
        order = torch.randperm(len(y_train), generator=generator)
        losses = []
        for start in range(0, len(order), BATCH):
            batch = order[start:start + BATCH]
            optimizer.zero_grad()
            loss = torch.nn.functional.cross_entropy(model(x_train[batch]),
                                                     y_train[batch])
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        model.eval()
        with torch.no_grad():
            said = model(x_val).argmax(dim=-1).numpy()
        got = score(said, y_val)
        curve.append({"epoch": epoch,
                      "train": train_module.number(float(np.mean(losses))),
                      **got})
        log(f"  епоха {epoch}: train {curve[-1]['train']} · влучність "
            f"{got['accuracy']} · схожість {got['similar']}")
    best = max(curve, key=lambda row: row["similar"])
    return {"name": name, "about": plan["about"],
            "inputs": int(data.shape[1]),
            "minutes": train_module.number((time.time() - started) / 60, 2),
            "curve": curve, "best": best}


def build_report(names=tuple(RUNS), epochs: int = EPOCHS, log=print) -> dict:
    built = legs_module.build(legs_module.PAIR, mode="decile", period=10,
                              extra=legs_module.EXTRA_PAIRS,
                              cut=legs_module.CUT, log=lambda *a: None)
    table = rows_of(built, log)
    train_mask, val_mask = split_of(table)
    runs = [one_run(table, name, RUNS[name], train_mask, val_mask, epochs, log)
            for name in names]
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "events": int(len(table["y"])),
        "legs": int(len(np.unique(table["leg"]))),
        "val_share": VAL_SHARE, "hidden": HIDDEN, "epochs": epochs,
        "lr": LR, "batch": BATCH, "seed": SEED,
        "chance": {"accuracy": 0.100, "similar": 0.300},
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--runs", nargs="+", default=list(RUNS),
                        choices=list(RUNS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    report = build_report(tuple(args.runs), args.epochs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    for run in report["runs"]:
        best = run["best"]
        print(f"{run['name']}: влучність {best['accuracy']} · схожість "
              f"{best['similar']} · відстань {best['distance']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
