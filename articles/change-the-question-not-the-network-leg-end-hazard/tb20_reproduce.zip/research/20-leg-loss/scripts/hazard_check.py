"""Який горизонт N брати для причинної цілі «нога скоро скінчиться».

Дослідження: research/20-leg-loss/
Правила: rules/01-data-and-db.md → класи, rules/03-models.md → Правила навчання

## Навіщо

Розділ 5 довів, що в 60 фічах події немає інформації про десятину ноги:
перцептрон без памʼяті дає рівно випадковість. Причина — десятина
визначається **повною довжиною ноги**, відомою лише заднім числом.

Причинна заміна питання: замість «яка я десятина» — **«чи скінчиться
нога в наступні N подій»**. Тут не потрібно знати довжину ноги, потрібно
впізнати, що півот близько. Це локальна властивість, і фічі можуть її
нести.

Питання одне: **скільки брати N**. Воно вирішує три речі одразу —
рідкість мітки, її сенс і те, скільки в ній узагалі сигналу.

## Що міряється

Для кожного N рахується частка додатних подій і **AUC** трьох моделей
без памʼяті: тільки фічі, тільки лічильник подій від початку ноги, і
обидва разом. AUC, а не влучність: при мітці на 2 % подій влучність
міряє лише вміння завжди казати «ні».

`AUC 0.5` — випадковість, `1.0` — ідеальний розділ.

Розбиття за ногами: нога цілком в одній вибірці. Класи зважені
(`pos_weight`), інакше рідка мітка просто ігнорується.

Запуск:

    python3 research/20-leg-loss/scripts/hazard_check.py
    python3 research/20-leg-loss/scripts/hazard_check.py --horizons 10 40
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "hazard_check.json"

HORIZONS = (5, 10, 20, 40, 80, 160)
HIDDEN = 128
EPOCHS = 8
BATCH = 4096
LR = 1e-3
SEED = 0
VAL_SHARE = 0.2

PLANS = {"фічі": (True, False), "лічильник": (False, True),
         "фічі+лічильник": (True, True)}


def auc_of(score: np.ndarray, truth: np.ndarray) -> float:
    """Площа під ROC через ранги: частка правильно впорядкованих пар."""
    order = np.argsort(score)
    rank = np.empty(len(score), dtype=np.float64)
    rank[order] = np.arange(1, len(score) + 1)
    positive, negative = truth.sum(), (~truth).sum()
    if not positive or not negative:
        return float("nan")
    return float((rank[truth].sum() - positive * (positive + 1) / 2)
                 / (positive * negative))


def table_of(built: dict) -> dict:
    """Події, фічі, лічильник і скільки подій лишилось до кінця ноги."""
    mask, lengths = built["mask"], np.asarray(built["lengths"])
    legs, steps = np.nonzero(mask)
    return {
        "x": np.nan_to_num(built["x"][legs, steps], nan=0.0).astype(np.float32),
        "counter": (np.log1p(steps) / np.log1p(walk_train.CAP))
        .clip(0, 1).astype(np.float32).reshape(-1, 1),
        "left": (lengths[legs] - 1 - steps).astype(np.int64),
        "leg": legs.astype(np.int64),
        "lengths": lengths,
    }


def split_of(table: dict, share: float = VAL_SHARE) -> tuple:
    """Розбиття за ногами: події однієї ноги не потрапляють в обидві частини."""
    legs = np.unique(table["leg"])
    rng = np.random.default_rng(SEED)
    picked = set(rng.choice(legs, size=max(int(len(legs) * share), 1),
                            replace=False).tolist())
    keep = np.isin(table["leg"], list(picked))
    return ~keep, keep


def one_model(data: np.ndarray, truth: np.ndarray, train_mask, val_mask,
              epochs: int = EPOCHS) -> float:
    """Перцептрон без памʼяті на одну мітку; повертає AUC на валідації."""
    torch.manual_seed(SEED)
    x = torch.tensor(data[train_mask])
    y = torch.tensor(truth[train_mask].astype(np.float32))
    model = torch.nn.Sequential(
        torch.nn.Linear(data.shape[1], HIDDEN), torch.nn.ReLU(),
        torch.nn.Linear(HIDDEN, HIDDEN), torch.nn.ReLU(),
        torch.nn.Linear(HIDDEN, 1))
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    weight = torch.tensor(float((~truth[train_mask]).sum()
                                / max(truth[train_mask].sum(), 1)))
    generator = torch.Generator().manual_seed(SEED)
    for _ in range(epochs):
        order = torch.randperm(len(y), generator=generator)
        for start in range(0, len(order), BATCH):
            batch = order[start:start + BATCH]
            optimizer.zero_grad()
            torch.nn.functional.binary_cross_entropy_with_logits(
                model(x[batch]).squeeze(-1), y[batch],
                pos_weight=weight).backward()
            optimizer.step()
    with torch.no_grad():
        said = model(torch.tensor(data[val_mask])).squeeze(-1).numpy()
    return auc_of(said, truth[val_mask])


def build_report(horizons=HORIZONS, epochs: int = EPOCHS, log=print) -> dict:
    built = legs_module.build(legs_module.PAIR, mode="decile", period=10,
                              extra=legs_module.EXTRA_PAIRS,
                              cut=legs_module.CUT, log=lambda *a: None)
    table = table_of(built)
    train_mask, val_mask = split_of(table)
    seconds = built["event_seconds"]
    lengths = table["lengths"]
    log(f"подія {seconds} с · ніг {len(lengths)} · подій {len(table['left'])} "
        f"· довжина ноги: медіана {np.median(lengths):.0f}")
    rows = []
    for horizon in horizons:
        truth = table["left"] < horizon
        got = {}
        for name, (features, counter) in PLANS.items():
            columns = ([table["x"]] if features else []) \
                + ([table["counter"]] if counter else [])
            got[name] = train_module.number(
                one_model(np.concatenate(columns, axis=1), truth,
                          train_mask, val_mask, epochs), 3)
        rows.append({
            "horizon": int(horizon),
            "hours": train_module.number(horizon * seconds / 3600, 2),
            "share": train_module.number(float(truth.mean())),
            "legs_over_half": int((lengths < 2 * horizon).sum()),
            "auc": got,
        })
        log(f"  N={horizon:<4d} частка {rows[-1]['share']} · "
            + " · ".join(f"{name} AUC {value}" for name, value in got.items()))
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "event_seconds": int(seconds),
        "legs": int(len(lengths)), "events": int(len(table["left"])),
        "leg_length": {"median": int(np.median(lengths)),
                       "q25": int(np.percentile(lengths, 25)),
                       "q75": int(np.percentile(lengths, 75)),
                       "max": int(lengths.max())},
        "hidden": HIDDEN, "epochs": epochs, "lr": LR, "seed": SEED,
        "val_share": VAL_SHARE,
        "rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--horizons", type=int, nargs="+", default=list(HORIZONS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    report = build_report(tuple(args.horizons), args.epochs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    best = max(report["rows"], key=lambda row: row["auc"]["фічі+лічильник"])
    print(f"найбільше сигналу на N={best['horizon']} "
          f"({best['hours']} год): AUC {best['auc']['фічі+лічильник']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
