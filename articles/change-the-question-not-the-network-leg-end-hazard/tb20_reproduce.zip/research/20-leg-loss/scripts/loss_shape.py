"""Форма функції втрат дослідження 19: що вона насправді штрафує.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

Функція втрат розділу 9 дослідження 19:

    L = Σ_маска CE(логіти, клас) / N
      + Σ_пари (jump·max(Δ-1, 0)² + down·max(-Δ, 0)²) / M

    Δ = очікуваний клас(t+1) - очікуваний клас(t),  jump = 5, down = 25

Криві тут **не виводяться формулою наново**: вони рахуються викликом
самої `masked_loss` з `leg_end_train.py` на побудованих логітах. Що
намальовано — те й оптимізується.

## Як будуються логіти під задане число

Щоб отримати рівно потрібний очікуваний клас `e`, ймовірність
розкладається на дві сусідні десятини:

    a = floor(e),  p(a) = 1 - (e - a),  p(a+1) = e - a
    логіти = log(p)      бо softmax(log p) = p

## Що рахується

| Крива | Що показує |
| ----- | ---------- |
| `step` | штраф за сходинку як функція від Δ, від -3 до +3 |
| `confidence` | CE як функція від упевненості в правильному класі |
| `ordinal` | CE при впевненій відповіді, коли правда — клас 10 |

Запуск:

    python3 research/20-leg-loss/scripts/loss_shape.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "19-leg-end-lstm" / "scripts"))

import leg_end_train as train_module   # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "loss_shape.json"
SOURCE = (HERE.parent.parent / "19-leg-end-lstm" / "results"
          / "train_steps_ema10_2_3.json")

CLASSES = 10
FLOOR = 1e-6          # щоб log(0) не давав -inf у логітах


def logits_for(values: list[float], classes: int = CLASSES) -> torch.Tensor:
    """Логіти, у яких очікуваний клас дорівнює заданому числу.

    Ймовірність кладеться на дві сусідні десятини, решта — `FLOOR`.
    """
    out = torch.full((1, len(values), classes), FLOOR)
    for step, value in enumerate(values):
        edge = min(max(float(value), 1.0), float(classes))
        low = min(int(np.floor(edge)), classes - 1)
        part = edge - low
        out[0, step, low - 1] = 1.0 - part
        out[0, step, low] = part
    return out.clamp(min=FLOOR).log()


def loss_of(values: list[float], true: float, jump: float,
            down: float, classes: int = CLASSES) -> float:
    """Втрата на послідовності з заданими очікуваними класами."""
    out = logits_for(values, classes)
    target = torch.full((1, len(values)), float(true))
    mask = torch.ones(1, len(values), dtype=torch.float32)
    return float(train_module.masked_loss(out, target, mask, None, classes,
                                          jump, down))


def step_curve(jump: float, down: float, classes: int = CLASSES) -> list[dict]:
    """Штраф за сходинку як функція від Δ — без внеску ентропії.

    Ентропія обох кроків однакова при будь-якому Δ, тому віднімається
    той самий прогін з нульовими штрафами.
    """
    rows = []
    for delta in np.round(np.arange(-3.0, 3.01, 0.05), 2):
        start = 5.0
        stop = float(np.clip(start + delta, 1.0, classes))
        if abs(stop - start - delta) > 1e-9:
            continue
        pair = [start, stop]
        clean = loss_of(pair, 5.0, 0.0, 0.0, classes)
        full = loss_of(pair, 5.0, jump, down, classes)
        rows.append({"delta": float(delta),
                     "penalty": train_module.number(full - clean, 5)})
    return rows


def confidence_curve(classes: int = CLASSES) -> list[dict]:
    """CE як функція від упевненості в правильному класі."""
    rows = []
    for share in np.round(np.arange(0.02, 1.0, 0.02), 2):
        probability = torch.full((1, 1, classes), (1.0 - share) / (classes - 1))
        probability[0, 0, classes - 1] = share
        loss = float(train_module.masked_loss(
            probability.log(), torch.full((1, 1), float(classes)),
            torch.ones(1, 1), None, classes, 0.0, 0.0))
        rows.append({"p": float(share), "ce": train_module.number(loss, 4)})
    return rows


def ordinal_curve(share: float = 0.9, classes: int = CLASSES) -> list[dict]:
    """CE при впевненій відповіді, коли правда — клас 10.

    Показує, що ентропія **не бачить відстані**: сказати 9 замість 10
    коштує рівно стільки ж, скільки сказати 1.
    """
    rows = []
    for said in range(1, classes + 1):
        probability = torch.full((1, 1, classes), (1.0 - share) / (classes - 1))
        probability[0, 0, said - 1] = share
        loss = float(train_module.masked_loss(
            probability.log(), torch.full((1, 1), float(classes)),
            torch.ones(1, 1), None, classes, 0.0, 0.0))
        rows.append({"said": said, "distance": classes - said,
                     "ce": train_module.number(loss, 4)})
    return rows


def marks(rows: list[dict]) -> dict:
    """Точки, за якими читається крива штрафу: де нуль, де скільки."""
    free = [row["delta"] for row in rows if row["penalty"] <= 1e-9]
    return {
        "free_from": min(free) if free else None,
        "free_to": max(free) if free else None,
        "at": {str(value): next((row["penalty"] for row in rows
                                 if abs(row["delta"] - value) < 1e-9), None)
               for value in (-2.0, -1.0, -0.5, 0.0, 0.5, 1.0, 2.0, 3.0)},
    }


def build_report(source: Path = SOURCE) -> dict:
    """Форма функції втрат плюс крива навчання кращої моделі розділу 9."""
    train = json.loads(source.read_text(encoding="utf-8"))
    config = train["config"]
    jump, down = float(config["jump"]), float(config["down"])
    step = step_curve(jump, down)
    return {
        "source": str(source.relative_to(source.parents[3])),
        "model": {"label": train["label"], "path": train["model_path"],
                  "classes": train["classes"], "best_epoch": train["best_epoch"],
                  "epochs_run": train["epochs_run"],
                  "target": train["target"], "class": train["class"],
                  "cut": train["cut"], "legs": train["legs"],
                  "smooth": config["smooth"], "batch": config["batch"],
                  "lr": config["lr"], "seed": config["seed"]},
        "loss": {"jump": jump, "down": down, "classes": train["classes"],
                 "formula": "L = CE(логіти, клас) + jump·max(Δ−1,0)² "
                            "+ down·max(−Δ,0)²"},
        "step": step, "marks": marks(step),
        "confidence": confidence_curve(),
        "ordinal": ordinal_curve(),
        "curve": train["curve"],
        "grid": [{"label": row["label"], "val_loss": row["val_loss"],
                  "best_epoch": row["best_epoch"], "params": row["params"]}
                 for row in train["grid"]],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    report = build_report()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    hole = report["marks"]
    print(f"штраф нульовий на Δ від {hole['free_from']} до {hole['free_to']}")
    print(f"Δ = -1 коштує {hole['at']['-1.0']}, Δ = +2 коштує {hole['at']['2.0']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
