"""Грід ручок моделі на один горизонт: чи є конфігурація краща за базову.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання, Навчання без свопа

## Навіщо

Розділ 7 дав `AUC 0.604` на `p₁₀₀` однією конфігурацією — тією, що
дісталась від чотиригоризонтної моделі. Питання, на яке відповідає цей
грід: **чи впирається результат у постановку, чи в ручки**. Якщо жодна
конфігурація не перебиває базову, стеля `0.604` належить даним, а не
мережі.

## Чому на урізаному train

Повний прогін — 55 хв, і гріду з тридцяти прогонів на нього не
вистачить доби. Тому кожен прогін іде на **однаковому урізаному**
шматку: перші `EVENTS` подій кожної монети. Порівнюються конфігурації
між собою на тому самому вході, а не з повним прогоном; переможець
потім переучується на всіх даних.

Урізання чесне рівно настільки, наскільки порядок конфігурацій на
частині даних збігається з порядком на всіх. Це не гарантовано, тому
базова конфігурація йде в грід теж — її місце в таблиці показує, чи
зберігся масштаб чисел.

## Стадії

Повний перебір усіх ручок — тисячі прогонів. Грід іде **стадіями**:
кожна бере переможця попередньої і крутить дві нові ручки.

| Стадія | Що крутить | Прогонів |
| ------ | ---------- | -------: |
| `розмір` | шарів LSTM × ширина стану | 9 |
| `голова` | ширина голови × dropout | 9 |
| `навчання` | крок навчання × вікно градієнта | 9 |
| `будова` | ворота, увага, лічильник, стеля памʼяті | 6 |

Стадія `будова` — не пошук ручки, а **абляція**: кожен прогін вимикає
одну частину архітектури. Падіння AUC каже, що частина працює;
відсутність падіння — що вона не потрібна.

Запуск:

    python3 research/20-leg-loss/scripts/hazard_grid.py --force
    python3 research/20-leg-loss/scripts/hazard_grid.py --stages розмір
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_net as hazard            # noqa: E402
import hazard_train as base            # noqa: E402
import walk_train                      # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "hazard_grid.json"

HORIZON = 100
EVENTS = 12_000                        # подій з кожної монети у train
EPOCHS = 4
SEED = 0

# Базова конфігурація — та, якою зроблений розділ 7.
BASE = {"layers": 1, "hidden": 64, "head": 128, "dropout": 0.1,
        "lr": 3e-4, "window": 150, "cap": 1500,
        "gate": True, "attend": True, "counter": True}

STAGES = {
    "розмір": [{"layers": one, "hidden": two}
               for one in (1, 2, 3) for two in (32, 64, 128)],
    "голова": [{"head": one, "dropout": two}
               for one in (64, 128, 256) for two in (0.0, 0.1, 0.3)],
    "навчання": [{"lr": one, "window": two}
                 for one in (1e-4, 3e-4, 1e-3) for two in (75, 150, 300)],
    "будова": [{"gate": False}, {"attend": False}, {"counter": False},
               {"cap": 500}, {"cap": 3000}, {}],
}


def name_of(knobs: dict) -> str:
    """Коротка назва прогону — тільки те, чим він відрізняється від бази."""
    parts = [f"{key}={value}" for key, value in knobs.items()
             if BASE.get(key) != value]
    return " · ".join(parts) if parts else "база"


def cut_stream(one: dict, limit: int) -> dict:
    """Перші `limit` подій потоку; мітки перераховуються під нову довжину."""
    if not one or limit <= 0 or len(one["y"]) <= limit:
        return one
    keep = slice(0, limit)
    stop = one["offset"] + limit
    out = dict(one)
    for key in ("x", "y", "t", "price", "ema", "spans"):
        out[key] = one[key][keep]
    out["pivots"] = [item for item in one["pivots"] if item.index < stop]
    total = limit
    places = sorted(item.index - one["offset"] for item in out["pivots"])
    left = np.full(total, -1, dtype=np.int64)
    start = 0
    for place in places:
        if place < 0:
            continue
        end = min(place, total - 1)
        left[start:end + 1] = np.arange(end - start, -1, -1)
        start = end + 1
    out["left"] = left
    out["known"] = left >= 0
    out["labels"] = hazard.labels_of(np.maximum(left, 0))
    return out


def load(limit: int, log=print) -> tuple:
    """Потоки вантажаться **один раз** на весь грід — це половина часу."""
    cut = legs_module.cut_stamp(base.CUT)
    trains = [cut_stream(base.stream_of(base.PAIR, cut, "train"), limit)]
    for name in base.EXTRA:
        trains.append(cut_stream(base.stream_of(name, cut, "train"), limit))
    val = base.stream_of(base.PAIR, cut, "val")
    log("потоки: " + " · ".join(f"{one['pair']} {len(one['y'])}"
                                for one in trains)
        + f" · val {len(val['y'])}")
    return trains, val


def run_one(knobs: dict, trains: list, val: dict, epochs: int,
            log=print) -> dict:
    """Один прогін гріду: навчання на урізаному train, оцінка на val."""
    started = time.time()
    torch.manual_seed(SEED)
    features = walk_train.features_of(knobs["counter"])
    model = hazard.HazardNet(features=features, hidden=knobs["hidden"],
                             heads=2, outputs=1, head=knobs["head"],
                             dropout=knobs["dropout"], layers=knobs["layers"],
                             attend=knobs["attend"])
    optimizer = torch.optim.Adam(model.parameters(), lr=knobs["lr"])

    labels = np.concatenate([one["labels"][one["known"]] for one in trains])
    spans = hazard.spans_of(np.concatenate(
        [one["left"][one["known"]] for one in trains]))
    weights = hazard.weights_of(labels)
    rate = hazard.base_rate(labels)
    walking = {"cap": knobs["cap"], "window": knobs["window"],
               "smooth": base.SMOOTH,
               "threshold": hazard.threshold_of(labels, hazard.LIFT),
               "counter": knobs["counter"], "weight": weights[0],
               "base": rate, "gate": knobs["gate"]}

    curve, best, best_epoch = [], -1.0, None
    for epoch in range(1, epochs + 1):
        model.train()
        losses = [base.walk_stream(model, one, walking, spans, weights,
                                   optimizer)["loss"] for one in trains]
        model.eval()
        with torch.no_grad():
            checked = base.walk_stream(model, val, walking, spans, weights)
        got = base.scores_of(val, checked, spans)
        auc = got["auc"][str(HORIZON)]
        curve.append({"epoch": epoch,
                      "train": train_module.number(float(np.mean(losses)), 4),
                      "val": train_module.number(checked["loss"], 4),
                      "auc": auc,
                      "gate_min": train_module.number(checked["gate_min"])})
        if auc is not None and auc == auc and auc > best:
            best, best_epoch = auc, epoch
    return {"knobs": dict(knobs), "name": name_of(knobs),
            "params": hazard.parameters_of(model),
            "auc": round(best, 4), "best_epoch": best_epoch,
            "minutes": train_module.number((time.time() - started) / 60, 2),
            "curve": curve}


def build_report(stages: list, events: int, epochs: int, out: Path,
                 log=print) -> dict:
    hazard.set_horizons([HORIZON])
    started = time.time()
    trains, val = load(events, log)
    winner = dict(BASE)
    runs, done = [], []
    for stage in stages:
        log(f"[{stage}] {len(STAGES[stage])} прогонів від «{name_of(winner)}»")
        picked, top = None, -1.0
        for change in STAGES[stage]:
            knobs = dict(winner)
            knobs.update(change)
            got = run_one(knobs, trains, val, epochs, log)
            got["stage"] = stage
            runs.append(got)
            log(f"  {got['name']}: AUC {got['auc']} · епоха "
                f"{got['best_epoch']} · {got['params']} ваг · "
                f"{got['minutes']} хв")
            if got["auc"] > top:
                top, picked = got["auc"], knobs
            out.write_text(json.dumps(
                report_of(runs, done, winner, started, events, epochs),
                ensure_ascii=False, indent=2), encoding="utf-8")
        if stage != "будова":       # абляція нічого не вибирає
            winner = picked
            log(f"[{stage}] виграла «{name_of(winner)}» з AUC {top}")
        done.append(stage)
    return report_of(runs, done, winner, started, events, epochs)


def report_of(runs: list, done: list, winner: dict, started: float,
              events: int, epochs: int) -> dict:
    best = max(runs, key=lambda one: one["auc"]) if runs else None
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "setup": {"horizon": HORIZON, "events": events, "epochs": epochs,
                  "seed": SEED, "pair": base.PAIR, "extra": list(base.EXTRA),
                  "cut": base.CUT, "base": BASE,
                  "full_run": {"auc": 0.604, "events": 336471,
                               "about": "розділ 7 на всіх даних"}},
        "stages": done,
        "winner": {"knobs": winner, "name": name_of(winner)},
        "best": {"name": best["name"], "auc": best["auc"],
                 "stage": best["stage"]} if best else None,
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--stages", nargs="+", default=list(STAGES),
                        choices=list(STAGES))
    parser.add_argument("--events", type=int, default=EVENTS)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    report = build_report(args.stages, args.events, args.epochs, args.out)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    print(f"кращий: {report['best']['name']} · AUC {report['best']['auc']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
