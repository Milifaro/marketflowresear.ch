"""Навчання під виправленою функцією втрат: ординальність і недохід.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

Розділ 1 показав дві дірки у втраті розділу 9 дослідження 19:

    штраф за сходинку нульовий на Δ ∈ [0, 1]   -> стояти на місці безплатно
    перехресна ентропія не бачить відстані     -> «9 замість 10» = «1 замість 10»

Тут закриті обидві. До втрати додано два члени (`leg_end_train.masked_loss`):

    ordinal · сер((E − y)²)                    відстань очікуваного класу до правди
    reach   · сер(max(C − E, 0)²) на подіях класу C   недохід до кінця ноги

Обидва нульові за замовчуванням, тому розділ 9 дослідження 19
відтворюється незмінним.

## Батч за бюджетом подій

Причинна увага квадратична по довжині ноги: батч із восьми ніг по 3000
подій дає матрицю на 549 МБ і жене машину в підкачку. Тому батч
збирається **за бюджетом подій** (`BUDGET`), а не за кількістю ніг:
довгі ноги йдуть по одній, короткі — вісімками, як раніше. Медіана
ноги train — 413 подій, у стелю 3000 упирається одна нога з 602, тому
склад більшості батчів не міняється.

## Памʼять

Навчання не починається при зайнятому свопі
(`rules/03-models.md` → Навчання без свопа): у свопі прогін і рахується
в рази довше, і тягне за собою всю машину. Датасет лишається в
оперативній памʼяті, на пристрій їде тільки обрізаний батч.

## Три прогони

| Прогін | Ваги | Що перевіряє |
| ------ | ---- | ------------ |
| `свіжа` | з нуля | чи вчиться під новою втратою взагалі |
| `свіжа+` | з нуля, штрафи втричі більші | чи впирається в силу штрафу |
| `донавчання` | ваги розділу 9 | чи можна виправити готову модель |

Дані, розбиття, ручки мережі й seed — ті самі, що в розділі 9
дослідження 19: `клас210х14х4ц`, ноги всіх шести монет, межа
`2026-08-14 15:27`, ширина 64 · увага 2 гол.

## Що міряється окремо від розділу 9

Головне питання не «менша втрата», а **чи доходить видача до класу 10**:
скільки подій названо десятим класом і який максимум сказаного класу.
Під старою втратою це був нуль.

Запуск:

    python3 research/20-leg-loss/scripts/loss_train.py
    python3 research/20-leg-loss/scripts/loss_train.py --runs свіжа
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402

RESULTS = HERE.parent / "results"
MODELS = HERE.parent / "models"
REPORT = RESULTS / "loss_train.json"
BEST19 = LEG19 / "models" / "leg_end_steps_ema10_2_3" / "model.pt"

CONFIG = {"hidden": 64, "heads": 2, "lr": train_module.LR, "attention": True}
ORDINAL = 0.1                 # ціна відстані очікуваного класу до правди
REACH = 0.1                   # ціна недоходу до класу 10 у зоні кінця
BUDGET = 4800                 # подій у батчі; довгі ноги йдуть по одній

RUNS = {
    "свіжа": {"ordinal": ORDINAL, "reach": REACH, "epochs": 5,
              "lr": train_module.LR, "from_best": False,
              "about": "з нуля, ordinal 0.1 · reach 0.1"},
    "свіжа+": {"ordinal": 3 * ORDINAL, "reach": 3 * REACH, "epochs": 5,
               "lr": train_module.LR, "from_best": False,
               "about": "з нуля, ordinal 0.3 · reach 0.3"},
    "донавчання": {"ordinal": ORDINAL, "reach": REACH, "epochs": 3,
                   "lr": 3e-4, "from_best": True,
                   "about": "ваги розділу 9, lr 3e-4, три епохи"},
}


def reach_scores(result: dict, classes: int) -> dict:
    """Чи доходить видача до останнього класу — на train і на val."""
    out = {}
    for name in ("train", "val"):
        said = result["probs"][name]["cls"]
        mask = said > 0
        values = said[mask]
        out[name] = {
            "max_said": train_module.number(float(values.max()), 2)
            if values.size else None,
            "events": int(values.size),
            "said_top": int((values == classes).sum()),
            "share_top": train_module.number(
                float((values == classes).mean())) if values.size else None,
        }
    return out


def one_run(built: dict, name: str, plan: dict, log=print) -> dict:
    """Один прогін під новою втратою; ваги йдуть у власну теку."""
    start = None
    if plan["from_best"]:
        start = torch.load(BEST19, map_location="cpu")
    config = {**CONFIG, "lr": plan["lr"]}
    log(f"[{name}] {plan['about']}")
    result = train_module.run(built, config, epochs=plan["epochs"],
                              batch=train_module.BATCH,
                              patience=train_module.PATIENCE,
                              jump=train_module.JUMP, down=train_module.DOWN,
                              smooth=train_module.SMOOTH,
                              ordinal=plan["ordinal"], reach=plan["reach"],
                              start=start, budget=BUDGET, log=log)
    folder = MODELS / f"loss_{name}"
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(result["model"].state_dict(), folder / "model.pt")
    classes = built["classes"]
    measured = result["measured"]
    return {
        "name": name, "about": plan["about"],
        "ordinal": plan["ordinal"], "reach": plan["reach"],
        "lr": plan["lr"], "epochs": plan["epochs"],
        "from_best": plan["from_best"],
        "model_path": str(folder.relative_to(HERE.parents[2])),
        "params": result["spec"]["params"],
        "best_epoch": result["best"]["epoch"],
        "minutes": train_module.number(result["minutes"], 2),
        "curve": result["curve"],
        "reach_scores": reach_scores(result, classes),
        # Ряд val: ціль і видача поруч — головне, що дивимось очима.
        "series": train_module.part_series(built, result, "val"),
        "measured": {name: {"classes": part["classes"], "steps": part["steps"],
                            "legs": part["legs"],
                            "events": part["events"]}
                     for name, part in measured.items()},
    }


def build_report(names=tuple(RUNS), log=print) -> dict:
    """Усі прогони на одному датасеті — рівно тому, що в розділі 9."""
    built = legs_module.build(legs_module.PAIR, mode="decile", period=10,
                              extra=legs_module.EXTRA_PAIRS,
                              cut=legs_module.CUT, log=log)
    started = time.time()
    runs = [one_run(built, name, RUNS[name], log) for name in names]
    base = json.loads((LEG19 / "results" / "train_steps_ema10_2_3.json")
                      .read_text(encoding="utf-8"))
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "dataset": {"class": built["class"], "scaler": built["scaler"],
                    "pair": built["pair"], "extra": list(built["extra"]),
                    "cut": built["cut"], "legs": len(built["legs"]),
                    "train": len(built["parts"]["train"]),
                    "val": len(built["parts"]["val"]),
                    "classes": built["classes"], "coins": built["coins"]},
        "loss": {"jump": train_module.JUMP, "down": train_module.DOWN,
                 "smooth": train_module.SMOOTH,
                 "formula": "L = CE + jump·max(Δ−1,0)² + down·max(−Δ,0)² "
                            "+ ordinal·(E−y)² + reach·max(C−E,0)²"},
        "base": {"label": base["label"], "best_epoch": base["best_epoch"],
                 "curve": base["curve"],
                 "classes": base["measured"]["val"]["classes"]["accuracy"],
                 "distance": base["measured"]["val"]["classes"]["distance"],
                 "path": base["model_path"]},
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--runs", nargs="+", default=list(RUNS),
                        choices=list(RUNS))
    parser.add_argument("--force", action="store_true",
                        help="почати навчання навіть при зайнятому свопі")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(tuple(args.runs))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    for run in report["runs"]:
        top = run["reach_scores"]["val"]
        print(f"{run['name']}: максимум сказаного класу на val "
              f"{top['max_said']} · подій класу 10 {top['said_top']}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
