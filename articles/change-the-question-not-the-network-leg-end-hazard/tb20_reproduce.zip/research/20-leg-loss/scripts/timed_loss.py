"""Втрата з памʼяттю про час: свій штраф на кожну ціль, ціна затримки.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

## Навіщо

Стара втрата дивилась на подію окремо: перехресна ентропія плюс штраф
за сходинку між сусідніми кроками. Через це вона не бачила двох речей,
які й вирішують задачу:

1. **Пониження всередині ноги неможливе.** Мітка десятини росте від 1
   до 10 і не падає, поки нога не закінчилась. Видача `3 -> 2` — це не
   «трохи гірше», це рух, якого не буває.
2. **Затримка коштує тим більше, чим вона довша.** Сказати 9, коли вже
   10, на одній події — дрібниця. Простояти так десяту частину
   десятини — велика помилка. Стара втрата платила за обидва випадки
   однаково.

## Що штрафується

Позначення на кроці `t`: `y` — ціль (десятина 1 … 10), `E` — очікуваний
клас `Σ pᵢ·i`, `T` — **тривалість тієї десятини, у якій стоїть подія**,
у подіях.

| Член | Коли | Скільки |
| ---- | ---- | ------- |
| `CE` | завжди | перехресна ентропія до `y` |
| **затримка** | `E < y` — не дійшла | `late · (кроків підряд позаду / T) · (y − E)` |
| **випередження** | `E > y` — не відпустила | `ahead · (кроків підряд попереду / T) · (E − y)` |
| **пониження** | `E` впало, а ціль **не** падала | `back · (E_{t−1} − E_t)²` |
| **стрибок** | `E` зросло більше ніж на клас | `jump · (Δ − 1)²` |

- **Влучила — не платить.** `E = y` дає нуль в обох напрямках.
- **Лічильник затримки росте, поки модель позаду**, і скидається в нуль,
  щойно вона наздогнала. Тому ціна першої події затримки маленька, а
  довгого простою — велика:

| Затримка на десятині завдовжки 100 подій | Частка | Штраф при `late = 2` і розриві в 1 клас |
| ---------------------------------------- | -----: | --------------------------------------: |
| 1 подія | 1 % | 0.02 |
| 10 подій | 10 % | **0.20** |
| 20 подій | 20 % | **0.40** |

- **Випередження рахується так само.** Найважливіший його випадок —
  нога вже закінчилась, ціль впала в 1, а модель усе ще каже 10: що
  довше вона так стоїть, то більший штраф.
- **Пониження — найдорожчий член.** Мітка десятини всередині ноги тільки
  росте, тому будь-який крок униз — `2 → 1`, `3 → 2`, … `10 → 9` — це рух,
  якого в даних не буває. Крок рівно на клас коштує `back = 30`: більше,
  ніж повна десятина затримки (`late = 6`), і в шість разів більше, ніж
  стрибок через клас (`jump = 5`).
- **Пониження карається тільки там, де воно неможливе.** На межі ноги
  ціль сама падає з 10 в 1 — там падіння видачі правильне і безплатне.
  Стара ручка `down` цієї різниці не робила і штрафувала саме те, що
  модель мала робити.

## Тривалість десятини

`T` — довжина суцільного відрізка однакової цілі, у якому стоїть подія.
Для десятин це рівно десята частина ноги, тому «10 подій затримки»
на короткій нозі важить більше, ніж на довгій, — як і має бути.
"""

from __future__ import annotations

import numpy as np
import torch

# Ціни членів. `back` більший за все інше: пониження всередині ноги —
# рух, якого в мітці не буває взагалі. Один крок униз (`2 -> 1`, `3 -> 2`,
# ... `10 -> 9`) коштує рівно `back`, бо різниця класів там дорівнює 1.
LATE = 6.0
AHEAD = 6.0
BACK = 30.0
JUMP = 5.0


def class_spans(y: np.ndarray) -> np.ndarray:
    """Тривалість десятини під кожною подією, у подіях.

    Подія поза ногами (`y = 0`) отримує `1`, щоб ділення не падало;
    у втрату такі події все одно не заходять.
    """
    spans = np.ones(len(y), dtype=np.float32)
    start = 0
    for index in range(1, len(y) + 1):
        if index == len(y) or y[index] != y[start]:
            spans[start:index] = max(index - start, 1)
            start = index
    return spans


class Delay:
    """Скільки кроків підряд модель позаду цілі або попереду неї."""

    __slots__ = ("late", "ahead")

    def __init__(self) -> None:
        self.late = 0
        self.ahead = 0

    def update(self, gap: float, edge: float = 0.5) -> None:
        """`gap = y − E`: додатний — позаду, відʼємний — попереду."""
        if gap > edge:
            self.late += 1
            self.ahead = 0
        elif gap < -edge:
            self.ahead += 1
            self.late = 0
        else:                      # наздогнала — обидва лічильники з нуля
            self.late = 0
            self.ahead = 0

    def reset(self) -> None:
        self.late = 0
        self.ahead = 0


def step_loss(logits, expected, true: float, span: float, delay: Delay,
              previous=None, previous_true: float | None = None,
              knobs: dict | None = None, classes: int = 10):
    """Втрата однієї події. Лічильник затримки оновлюється тут же.

    `span` — тривалість десятини під подією; `previous` — очікуваний
    клас попередньої події; `previous_true` — її ціль (щоб відрізнити
    межу ноги, де падіння видачі правильне).
    """
    knobs = knobs or {}
    late = knobs.get("late", LATE)
    ahead = knobs.get("ahead", AHEAD)
    back = knobs.get("back", BACK)
    jump = knobs.get("jump", JUMP)

    target = int(true) - 1
    loss = torch.nn.functional.cross_entropy(
        logits.unsqueeze(0), torch.tensor([target], device=logits.device))
    parts = {"ce": float(loss.detach())}

    gap = float(true) - float(expected.detach())
    delay.update(gap)
    span = max(float(span), 1.0)

    if delay.late and late:                    # не дійшла до цілі
        weight = late * delay.late / span
        term = weight * (float(true) - expected).clamp(min=0.0)
        loss = loss + term
        parts["late"] = float(term.detach())
    if delay.ahead and ahead:                  # не відпустила ціль
        weight = ahead * delay.ahead / span
        term = weight * (expected - float(true)).clamp(min=0.0)
        loss = loss + term
        parts["ahead"] = float(term.detach())

    if previous is not None:
        step = expected - previous
        fell = previous_true is not None and float(true) < float(previous_true)
        if back and not fell:                  # межа ноги — падіння дозволене
            term = back * (-step).clamp(min=0.0).pow(2)
            loss = loss + term
            parts["back"] = float(term.detach())
        if jump:
            term = jump * (step - 1.0).clamp(min=0.0).pow(2)
            loss = loss + term
            parts["jump"] = float(term.detach())
    return loss, parts
