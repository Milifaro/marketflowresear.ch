"""Чи потрібна памʼять на `p₁₀₀`: та сама задача мережею **без** памʼяті.

Дослідження: research/20-leg-loss/
Правила: rules/03-models.md → Правила навчання

## Навіщо

Розділ 7 дав `AUC 0.604` мережею з памʼяттю. Розділ 6 міряв перцептрон
без памʼяті й отримав на сусідніх горизонтах `0.624` (N=80) і `0.584`
(N=160). Числа близькі, і напрошується висновок «памʼять не додає
нічого» — але **порівнювати їх не можна**: там розбиття по ногах на
всіх 336 тисячах подій, тут розбиття за датою і val із 3 800 подій
самого BTC.

Цей скрипт прибирає різницю. Той самий потік, те саме розбиття за
датою, та сама мітка, та сама вага класу, той самий val — і мережа
**без жодної памʼяті**: подія на вхід, ймовірність на вихід.

Різниця AUC між нею і моделлю з памʼяттю — це і є те, що памʼять
справді дає. Якщо різниці немає, LSTM, увага і ворота на цьому
горизонті не потрібні.

## Лічильник

У прогоні з памʼяттю лічильник «скільки подій від обнулення» рахувався
від фактичних обнулень. На val їх було рівно два, обидва по стелі
`CAP = 1500`, своїх — жодного. Тобто лічильник там був **детермінованою
пилкою** з періодом 1500, і сюди він подається такою самою: інакше
базовий рівень бачив би не те, що бачила модель.

Три прогони:

| Прогін | Вхід |
| ------ | ---- |
| `фічі` | 60 фіч події |
| `лічильник` | сама пилка |
| `фічі+лічильник` | те саме, що бачить модель з памʼяттю |

Запуск:

    python3 research/20-leg-loss/scripts/hazard_flat.py --force
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
LEG19 = HERE.parent.parent / "19-leg-end-lstm"
sys.path.insert(0, str(LEG19 / "scripts"))
sys.path.insert(0, str(HERE))

import leg_end_data as legs_module     # noqa: E402
import leg_end_train as train_module   # noqa: E402
import hazard_net as hazard            # noqa: E402
import hazard_train as base            # noqa: E402

RESULTS = HERE.parent / "results"
REPORT = RESULTS / "hazard_flat.json"

HORIZON = 100
HIDDEN = 128
EPOCHS = 30
BATCH = 4096
LR = 1e-3
SEED = 0
KINDS = ("фічі", "лічильник", "фічі+лічильник")


def counter_column(total: int, cap: int) -> np.ndarray:
    """Та сама пилка, що бачила модель: подій від обнулення по стелі."""
    held = np.arange(total) % cap
    return (np.log1p(held) / np.log1p(max(cap, 2))).astype(np.float32)


def rows_of(stream: dict, kind: str, cap: int) -> tuple:
    """Вхід і мітка одного потоку під обраний прогін."""
    known = stream["known"]
    counter = counter_column(len(known), cap)[:, None]
    if kind == "лічильник":
        x = counter
    elif kind == "фічі":
        x = stream["x"]
    else:
        x = np.concatenate([stream["x"], counter], axis=1)
    return (x[known].astype(np.float32),
            stream["labels"][known, 0].astype(np.float32))


def train_one(kind: str, trains: list, val: dict, cap: int, epochs: int,
              log=print) -> dict:
    torch.manual_seed(SEED)
    parts = [rows_of(one, kind, cap) for one in trains]
    x = torch.tensor(np.concatenate([one[0] for one in parts]))
    y = torch.tensor(np.concatenate([one[1] for one in parts]))
    vx, vy = rows_of(val, kind, cap)
    vx = torch.tensor(vx)

    weight = float((len(y) - y.sum()) / max(float(y.sum()), 1.0))
    model = nn.Sequential(nn.Linear(x.shape[1], HIDDEN), nn.ReLU(),
                          nn.Linear(HIDDEN, HIDDEN), nn.ReLU(),
                          nn.Linear(HIDDEN, 1))
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    loss_of = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(weight))

    best, curve = -1.0, []
    for epoch in range(1, epochs + 1):
        model.train()
        order = torch.randperm(len(x))
        losses = []
        for start in range(0, len(x), BATCH):
            picked = order[start:start + BATCH]
            optimizer.zero_grad()
            loss = loss_of(model(x[picked]).squeeze(-1), y[picked])
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))
        model.eval()
        with torch.no_grad():
            score = torch.sigmoid(model(vx).squeeze(-1)).numpy()
        auc = hazard.auc_of(score, vy.astype(bool))
        curve.append({"epoch": epoch,
                      "train": train_module.number(float(np.mean(losses)), 4),
                      "auc": train_module.number(auc, 3)})
        best = max(best, auc)
    log(f"  {kind}: AUC {round(best, 4)} · вхід {x.shape[1]} · "
        f"вага класу {weight:.1f}")
    return {"kind": kind, "features": int(x.shape[1]),
            "weight": round(weight, 1), "auc": round(best, 4),
            "curve": curve}


def build_report(epochs: int = EPOCHS, target: str = base.AHEAD,
                 log=print) -> dict:
    hazard.set_horizons([1] if target in base.BINARY else [HORIZON])
    started = time.time()
    cut = legs_module.cut_stamp(base.CUT)
    trains = [base.stream_of(base.PAIR, cut, "train", target)]
    for name in base.EXTRA:
        trains.append(base.stream_of(name, cut, "train", target))
    val = base.stream_of(base.PAIR, cut, "val", target)
    log("потоки: " + " · ".join(f"{one['pair']} {len(one['y'])}"
                                for one in trains)
        + f" · val {len(val['y'])}")
    runs = [train_one(kind, trains, val, base.CAP, epochs, log)
            for kind in KINDS]
    top = max(runs, key=lambda one: one["auc"])
    return {
        "built_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "minutes": train_module.number((time.time() - started) / 60, 2),
        "setup": {"horizon": HORIZON, "target": target,
                  "question": base.BINARY.get(target, target),
                  "hidden": HIDDEN, "epochs": epochs,
                  "batch": BATCH, "lr": LR, "seed": SEED, "cap": base.CAP,
                  "cut": base.CUT, "pair": base.PAIR,
                  "extra": list(base.EXTRA),
                  "train_events": int(sum(len(one["y"]) for one in trains)),
                  "val_events": int(len(val["y"]))},
        "runs": runs,
        "best": {"kind": top["kind"], "auc": top["auc"]},
        "memory": {"auc": 0.604, "about": "розділ 7, та сама val"},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--target", default=base.AHEAD,
                        choices=(base.AHEAD, base.BEHIND, *base.BINARY))
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--out", type=Path, default=REPORT)
    args = parser.parse_args()
    train_module.no_swap(force=args.force)
    report = build_report(args.epochs, args.target)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    gap = report["memory"]["auc"] - report["best"]["auc"]
    print(f"без памʼяті {report['best']['auc']} ({report['best']['kind']}) "
          f"· з памʼяттю {report['memory']['auc']} · памʼять дає "
          f"{gap:+.3f}")
    print(f"записано {args.out}")


if __name__ == "__main__":
    main()
