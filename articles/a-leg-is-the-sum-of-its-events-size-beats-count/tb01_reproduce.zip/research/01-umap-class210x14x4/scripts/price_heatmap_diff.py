"""Ціна BTC і хітмап різниць resist − support під нею.

Дослідження: research/01-umap-class210x14x4/
Правила: rules/05-visualization.md.

Показує, що від чого віднімалось: вхідні смуги стоять безпосередньо над
своєю різницею.

Вихід: results/price_heatmap_diff.png / .meta.json

Запуск:
    python3 research/01-umap-class210x14x4/scripts/price_heatmap_diff.py \
        --from 2026-05-01 --to 2026-08-21
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import Normalize  # noqa: E402
import numpy as np  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import zigzag  # noqa: E402
from price_heatmap import (BG, DIVERGING, DOWN, DPI, MUTED, PANEL,  # noqa: E402
                           PRICE_STEP, SEQUENTIAL, TEXT, UP, BUCKET, collect,
                           day_files, grid, scale)

RESEARCH_DIR = Path(__file__).resolve().parents[1]

RESIST, D_RESIST, SUPPORT, D_SUPPORT = 0, 1, 2, 3

# (підпис, як рахувати смугу, чи нормована шкала [-1, 1])
ROWS = [
    ("resist − support", lambda c: c[:, :, RESIST] - c[:, :, SUPPORT], False),
    ("(resist − support)\n/ (resist + support)",
     lambda c: normalized(c[:, :, RESIST], c[:, :, SUPPORT]), True),
    ("d_resist − d_support", lambda c: c[:, :, D_RESIST] - c[:, :, D_SUPPORT],
     False),
    ("(d_resist − d_support)\n/ (d_resist + d_support)",
     lambda c: normalized(c[:, :, D_RESIST], c[:, :, D_SUPPORT]), True),
]


def normalized(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """(a − b) / (a + b). Знаменник ≤ 0 — величина не визначена, ставимо NaN.

    Для resist/support знаменник завжди додатний. Для d_resist/d_support
    обидві частини мають знак, тому сума може бути нульовою або відʼємною —
    відношення тоді не інтерпретується.
    """
    total = a + b
    with np.errstate(invalid="ignore", divide="ignore"):
        value = (a - b) / total
    return np.where(total > 0, value, np.nan)


def band(cells: np.ndarray, source) -> np.ndarray:
    """Смуга (15, колонки) за формулою рядка."""
    return source(cells).T


def hourly_ratio(events, ratio: np.ndarray, t0: int, t1: int,
                 bucket: int) -> np.ndarray:
    """Середнє mean(vol_buy)/mean(vol_sell) по подіях години."""
    columns = int((t1 - t0) // bucket) + 1
    total = np.zeros(columns)
    count = np.zeros(columns)
    position = ((events.timestamp - t0) // bucket).astype(int)
    inside = (position >= 0) & (position < columns)
    np.add.at(total, position[inside], ratio[inside])
    np.add.at(count, position[inside], 1)
    out = np.full(columns, np.nan)
    filled = count > 0
    out[filled] = total[filled] / count[filled]
    return out


def draw_zigzag(ax, pivots, times, values, width: float) -> None:
    """Зігзаг за rules/02-markup.md: рух вгору зелений, вниз червоний;
    півот зверху зелений, знизу червоний."""
    for a, b in zip(pivots, pivots[1:]):
        ax.plot([times[a.index], times[b.index]],
                [values[a.index], values[b.index]],
                color=UP if values[b.index] >= values[a.index] else DOWN,
                linewidth=width, zorder=3)
    ax.scatter([times[p.index] for p in pivots], [values[p.index] for p in pivots],
               c=[UP if p.kind == "high" else DOWN for p in pivots],
               s=6 + 8 * width, linewidths=0, zorder=4)


def render(stamps, prices, events, ratio, start: str, end: str, out: Path,
           bucket: int) -> dict:
    t0, t1 = int(stamps[0]), int(stamps[-1])
    cells, count = grid(events, t0, t1, bucket)
    span = [mdates.date2num(datetime.fromtimestamp(t, timezone.utc))
            for t in (t0, t1)]

    rows = len(ROWS) + 3                  # ціна + 2 осцилятори + смуги
    fig = plt.figure(figsize=(18, 15))
    spec = fig.add_gridspec(rows, 2,
                            height_ratios=[2.4, 0.9, 0.9] + [1.3] * len(ROWS),
                            width_ratios=[60, 1], hspace=0.1, wspace=0.012)
    axes = [fig.add_subplot(spec[0, 0])]
    axes += [fig.add_subplot(spec[row, 0], sharex=axes[0]) for row in range(1, rows)]
    bars = [fig.add_subplot(spec[row, 1]) for row in range(rows)]
    for bar in bars[:3]:
        bar.axis("off")
    for ax in axes[:-1]:
        ax.tick_params(labelbottom=False)

    fig.patch.set_facecolor(PANEL)
    for ax in axes:
        ax.set_facecolor(BG)
        ax.tick_params(colors=MUTED, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color("#2c313d")

    keep = np.arange(0, len(stamps), PRICE_STEP)
    times = mdates.date2num([datetime.fromtimestamp(t, timezone.utc)
                             for t in stamps[keep]])
    axes[0].plot(times, prices[keep], color="#4c8dff", linewidth=0.7, zorder=2)
    axes[0].set_ylabel("ціна, USDT", color=MUTED, fontsize=8)

    # зігзаги — по ряду price_open подій (rules/02-markup.md)
    event_price = events.price_open.astype(float)
    event_times = mdates.date2num([datetime.fromtimestamp(int(t), timezone.utc)
                                   for t in events.timestamp])
    outer_pivots = zigzag.zigzag(event_price, zigzag.OUTER_THRESHOLD)
    inner_pivots = zigzag.nested_zigzag(event_price, outer_pivots,
                                        zigzag.INNER_THRESHOLD)
    draw_zigzag(axes[0], inner_pivots, event_times, event_price, 0.8)
    draw_zigzag(axes[0], outer_pivots, event_times, event_price, 2.0)
    axes[0].set_title(
        f"BTC_USDT, {start} … {end} UTC — ціна (price_avg, крок {PRICE_STEP} с)\n"
        f"Нижче — різниці фіч подій клас210х14х4 на тій самій осі часу: "
        f"{len(events)} подій, колонка = {bucket // 3600} год "
        f"(середнє по подіях години), 15 рядків у смузі — блоки по 14 с.\n"
        f"На ціну накладено зігзаг 2.3 (товсті лінії) і вкладений у кожен рух "
        f"зігзаг 0.8 (тонкі), побудовані по ряду price_open подій.\n"
        f"Під ціною — осцилятор mean(vol_buy) / mean(vol_sell) за 210 с події, "
        f"усереднений по годині. Нижче — різниці фіч, поблочно: значення блоку "
        f"однієї фічі мінус значення того самого блоку іншої, у тій самій події.",
        color=TEXT, fontsize=9, loc="left")

    # осцилятор: mean(vol_buy) / mean(vol_sell), синхронно з графіком
    ratio_hour = hourly_ratio(events, ratio, t0, t1, bucket)
    edges = mdates.date2num([datetime.fromtimestamp(t0 + i * bucket, timezone.utc)
                             for i in range(len(ratio_hour))])
    osc = axes[1]
    osc.axhline(1.0, color=MUTED, linewidth=0.8, linestyle="--")
    osc.fill_between(edges, 1.0, ratio_hour, where=ratio_hour >= 1.0,
                     color=UP, alpha=0.75, linewidth=0)
    osc.fill_between(edges, 1.0, ratio_hour, where=ratio_hour < 1.0,
                     color=DOWN, alpha=0.75, linewidth=0)
    osc.set_yscale("log")
    osc.set_ylim(np.nanpercentile(ratio_hour, 0.5),
                 np.nanpercentile(ratio_hour, 99.5))
    osc.set_ylabel("mean(vol_buy)\n/ mean(vol_sell)", color=TEXT, fontsize=8)

    # нормований дисбаланс обʼємів: (buy − sell) / (buy + sell), межі [−1, 1]
    imbalance = (ratio - 1.0) / (ratio + 1.0)
    imbalance_hour = hourly_ratio(events, imbalance, t0, t1, bucket)
    osc2 = axes[2]
    osc2.axhline(0.0, color=MUTED, linewidth=0.8, linestyle="--")
    osc2.fill_between(edges, 0.0, imbalance_hour, where=imbalance_hour >= 0,
                      color=UP, alpha=0.75, linewidth=0)
    osc2.fill_between(edges, 0.0, imbalance_hour, where=imbalance_hour < 0,
                      color=DOWN, alpha=0.75, linewidth=0)
    osc2.set_ylabel("(vol_buy − vol_sell)\n/ (vol_buy + vol_sell)",
                    color=TEXT, fontsize=8)

    ranges = {}
    for ax, bar, (label, source, bounded) in zip(axes[3:], bars[3:], ROWS):
        values = band(cells, source)
        if bounded:
            norm, (low, high) = Normalize(-1, 1), (-1.0, 1.0)
        else:
            norm, (low, high) = scale(values, diverging=True)
        ranges[label.replace("\n", " ")] = [low, high]
        image = ax.imshow(values, aspect="auto", origin="lower",
                          interpolation="nearest", cmap=DIVERGING, norm=norm,
                          extent=[span[0], span[1], 0, 15])
        ax.set_yticks([0, 15])
        ax.set_yticklabels(["1", "15"])
        ax.set_ylabel(label, color=TEXT, fontsize=8, fontweight="bold")
        colorbar = fig.colorbar(image, cax=bar)
        colorbar.ax.tick_params(colors=MUTED, labelsize=7)
        colorbar.outline.set_edgecolor("#2c313d")

    axes[-1].xaxis.set_major_locator(mdates.AutoDateLocator())
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    axes[-1].set_xlabel("час, UTC", color=MUTED, fontsize=8)
    fig.text(
        0.5, -0.02,
        "зігзаг: рух вгору зелений, вниз червоний; півот зверху зелений, "
        "знизу червоний; товсті лінії — 2.3, тонкі — вкладений 0.8\n"
        "осцилятор 1:  mean(vol_buy) / mean(vol_sell)  — логарифмічна шкала, "
        "база 1\n"
        "осцилятор 2:  (vol_buy − vol_sell) / (vol_buy + vol_sell)  — межі "
        "[−1, 1], база 0\n"
        "смуга 1:  resist − support        смуга 2:  (resist − support) / "
        "(resist + support)\n"
        "смуга 3:  d_resist − d_support    смуга 4:  (d_resist − d_support) / "
        "(d_resist + d_support)\n"
        "де d_resist = Σ14(resist_plus − resist_minus) / mean(vol_buy), "
        "d_support = Σ14(support_plus − support_minus) / mean(vol_sell)\n"
        "зелене — перша величина більша, червоне — друга; абсолютні різниці на "
        "симетричній логарифмічній шкалі (межі ±99-й процентиль вікна), "
        "нормовані — на лінійній [−1, 1]\n"
        "нормована різниця не визначена там, де сума ≤ 0 (3.5% клітинок "
        "у смузі 4) — такі клітинки порожні",
        color=MUTED, fontsize=8, ha="center", va="top")

    fig.savefig(out, dpi=DPI, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)

    finite = lambda v: v[np.isfinite(v)]
    diff = finite(band(cells, ROWS[0][1]))
    d_diff = finite(band(cells, ROWS[2][1]))
    norm_diff = band(cells, ROWS[1][1])
    norm_d_diff = band(cells, ROWS[3][1])
    defined = np.isfinite(cells[:, :, D_RESIST] + cells[:, :, D_SUPPORT]).T
    return {
        "ranges": ranges,
        "zigzag": {"outer": len(outer_pivots), "inner": len(inner_pivots),
                   "outer_threshold": zigzag.OUTER_THRESHOLD,
                   "inner_threshold": zigzag.INNER_THRESHOLD,
                   "series": "price_open подій у вікні"},
        "volume_ratio": {
            "median": float(np.median(ratio)),
            "share_above_one": float((ratio > 1).mean()),
        },
        "volume_imbalance": {
            "median": float(np.median(imbalance)),
            "share_positive": float((imbalance > 0).mean()),
        },
        "resist_support_normalized": {
            "median": float(np.nanmedian(norm_diff)),
            "share_positive": float((finite(norm_diff) > 0).mean()),
            "cells": int(np.isfinite(norm_diff).sum()),
        },
        "d_resist_d_support_normalized": {
            "median": float(np.nanmedian(norm_d_diff)),
            "share_positive": float((finite(norm_d_diff) > 0).mean()),
            "cells": int(np.isfinite(norm_d_diff).sum()),
            # знаменник ≤ 0 серед клітинок, де подія є
            "share_undefined": float(
                (np.isnan(norm_d_diff) & defined).sum() / max(defined.sum(), 1)),
        },
        "columns": int(cells.shape[0]),
        "empty_columns": int((count == 0).sum()),
        "resist_minus_support": {
            "median": float(np.median(diff)),
            "share_positive": float((diff > 0).mean()),
        },
        "d_resist_minus_d_support": {
            "median": float(np.median(d_diff)),
            "share_positive": float((d_diff > 0).mean()),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from", dest="start", default="2026-05-01")
    parser.add_argument("--to", dest="end", default="2026-08-21")
    parser.add_argument("--bucket", type=int, default=BUCKET)
    parser.add_argument("--out", type=Path, default=RESEARCH_DIR / "results")
    args = parser.parse_args()

    files = day_files(args.start, args.end)
    if not files:
        raise SystemExit("немає файлів у вікні — скопіюй їх у data/")
    print(f"[1/4] днів у вікні: {len(files)}")

    stamps, prices, events, ratio = collect(files)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / "price_heatmap_diff.png"
    info = render(stamps, prices, events, ratio, args.start, args.end, path,
                  args.bucket)
    print(f"[3/4] {path.name}: {path.stat().st_size // 1024} KB")

    meta = {"pair": "BTC_USDT", "from": args.start, "to": args.end,
            "days": len(files), "events": int(len(events)),
            "bucket_seconds": args.bucket, **info}
    (args.out / "price_heatmap_diff.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    r = info["resist_minus_support"]
    d = info["d_resist_minus_d_support"]
    z = info["zigzag"]
    print(f"      зігзаг 2.3: {z['outer']} півотів, вкладений 0.8: {z['inner']}")
    v = info["volume_ratio"]
    i = info["volume_imbalance"]
    n = info["resist_support_normalized"]
    dn = info["d_resist_d_support_normalized"]
    print(f"      vol_buy/vol_sell: медіана {v['median']:.3f}, "
          f"понад 1: {v['share_above_one']:.1%}")
    print(f"      (buy−sell)/(buy+sell): медіана {i['median']:+.4f}, "
          f"додатних {i['share_positive']:.1%}")
    print(f"      (r−s)/(r+s): медіана {n['median']:+.4f}, "
          f"додатних {n['share_positive']:.1%}")
    print(f"      (dr−ds)/(dr+ds): медіана {dn['median']:+.4f}, "
          f"додатних {dn['share_positive']:.1%}, "
          f"не визначено {dn['share_undefined']:.1%}")
    print(f"[4/4] resist−support: медіана {r['median']:.1f}, "
          f"додатних {r['share_positive']:.1%}; "
          f"d_resist−d_support: медіана {d['median']:.1f}, "
          f"додатних {d['share_positive']:.1%}")


if __name__ == "__main__":
    main()
