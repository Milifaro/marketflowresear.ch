"""Події зростання і падіння в нозі: чи повʼязаний рух ноги з подіями.

Дослідження: research/01-umap-class210x14x4/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Питання: нога зігзага 2.3 % проходить свій рух подіями по 210 с. Чи
повʼязаний цей рух із подіями, з яких він складається, і чим саме —
тим, що подій одного напрямку **більше**, чи тим, що вони **більші**.

Рух події береться з неї самої: `r = ln(price_close / price_open)`.
Рух ноги — `ln(price_close останньої / price_open першої)`. Тоді

    рух ноги = сума рухів її подій + рух у розривах між ними

а сума рухів подій точно розкладається на дві частини:

    Σr = m · (n↑ − n↓)              скільки     — подій одного знака більше
       + [n↑·(m↑ − m) − n↓·(m↓ − m)]  які саме  — вони ще й більші за модулем

де `m↑`, `m↓` — середній модуль руху зростаючих і спадних подій,
`m` — середній модуль по всій нозі. Обидві частини в тих самих одиницях,
тому їх видно поруч.

Ряд і ноги — той самий рецепт, що на вкладці `/umap`:

    ема10(price_open) -> півоти зігзага 2.3 % -> ноги -> десятини

Рахується на **повному ряді кожної монети** (`train` + `val` класу
`клас210х10х7`), а не на дірявому train дослідження 01: питання про рух
усередині ноги, тому ряд має бути суцільним.

Вхід : data/datasets/<PAIR>/class210x10x7/{train,val}.npz
Вихід: results/leg_events.json      — нога за ногою + зведення по монетах
       results/leg_events.meta.json — те саме зведення без переліку ніг

Запуск:
    python3 research/01-umap-class210x14x4/scripts/leg_events.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x10x7  # noqa: E402
from build_class210x10x7dc import PAIRS, PARTS  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

# Розмітка ніг — рецепт дослідження 21, без копіювання формул.
_spec = importlib.util.spec_from_file_location(
    "x7dc_leg_deciles",
    PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
    / "leg_deciles.py")
leg_deciles = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(leg_deciles)

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
THRESHOLD = leg_deciles.THRESHOLD      # 0.023
PERIOD = leg_deciles.PERIOD            # ема10
DECILES = leg_deciles.DECILES          # 10


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def series(pair: str, root: Path | None = None) -> dict:
    """Повний ряд монети за часом: час, ціна відкриття й закриття події."""
    folder = (root or DATASETS) / pair / "class210x10x7"
    t, opens, closes = [], [], []
    for part in PARTS:
        data = class210x10x7.load(folder / f"{part}.npz")
        t.append(data.t_start)
        opens.append(data.price_open)
        closes.append(data.price_close)
    t = np.concatenate(t)
    order = np.argsort(t, kind="stable")
    return {"t": t[order].astype(np.int64),
            "open": np.concatenate(opens)[order].astype(float),
            "close": np.concatenate(closes)[order].astype(float)}


def split(move: np.ndarray) -> dict:
    """Розклад суми рухів на «скільки подій» і «які вони за модулем»."""
    up, down = move > 0, move < 0
    n_up, n_down = int(up.sum()), int(down.sum())
    size = np.abs(move[up | down])
    mean = float(size.mean()) if size.size else 0.0
    mean_up = float(move[up].mean()) if n_up else 0.0
    mean_down = float(-move[down].mean()) if n_down else 0.0
    count_part = mean * (n_up - n_down)
    size_part = n_up * (mean_up - mean) - n_down * (mean_down - mean)
    return {"events": int(move.size), "up": n_up, "down": n_down,
            "flat": int(move.size) - n_up - n_down,
            "share_up": n_up / move.size if move.size else 0.0,
            "sum": float(move.sum()), "mean_abs": mean,
            "mean_up": mean_up, "mean_down": mean_down,
            "count_part": count_part, "size_part": size_part}


def leg_rows(data: dict, pair: str) -> list:
    """Нога за ногою: рух ноги, її події й розклад суми їх рухів."""
    smooth = ema(data["open"], PERIOD)
    pivots = zigzag(smooth, THRESHOLD)
    group, legs = leg_deciles.cohorts(pivots, len(smooth))
    move = np.log(data["close"] / data["open"])
    rows = []
    for leg in legs:
        first, last = leg["from"], leg["to"]
        piece = move[first:last + 1]
        total = float(np.log(data["close"][last] / data["open"][first]))
        row = {"pair": pair, "leg": len(rows) + 1, "kind": leg["kind"],
               "from": int(data["t"][first]), "to": int(data["t"][last]),
               "total": total, **split(piece)}
        row["gaps"] = total - row["sum"]
        row["deciles"] = [float(np.mean(piece[group[first:last + 1]
                                              % DECILES == part % DECILES] > 0))
                          if np.any(group[first:last + 1] % DECILES
                                    == part % DECILES) else None
                          for part in range(1, DECILES + 1)]
        rows.append(row)
    return rows


def spearman(one: np.ndarray, other: np.ndarray) -> float:
    """Кореляція рангів: питання про звʼязок, а не про його форму."""
    rank = lambda values: np.argsort(np.argsort(values))  # noqa: E731
    return pearson(rank(one).astype(float), rank(other).astype(float))


def pearson(one: np.ndarray, other: np.ndarray) -> float:
    if one.size < 2 or one.std() == 0 or other.std() == 0:
        return 0.0
    return float(np.corrcoef(one, other)[0, 1])


def gaps_digest(rows: list, total: np.ndarray, inside: np.ndarray) -> dict:
    """Скільки руху ноги лягло **між** подіями, а не в них.

    Стик двох суміжних подій — це одна секунда, і рух там нульовий; помітні
    розриви дає лише те, що ряд подекуди рветься (подія з нульовим обʼємом
    або пропуск у джерелі). Тому окремо рахується частка ніг, де розриви
    зʼїли понад 10 % руху, і те, як сходиться решта.
    """
    gaps = np.abs(np.array([row["gaps"] for row in rows]))
    relative = gaps / np.abs(total)
    clean = relative <= 0.02
    return {"share": float(gaps.sum() / np.abs(total).sum()),
            "median_relative": float(np.median(relative)),
            "legs_over_10pct": int((relative > 0.1).sum()),
            "clean_legs": int(clean.sum()),
            "clean_inside_share": float(np.abs(inside[clean]).sum()
                                        / np.abs(total[clean]).sum())
            if clean.any() else 0.0}


def digest(rows: list) -> dict:
    """Зведення по ногах: звʼязок руху ноги з подіями, з яких він склався."""
    total = np.array([row["total"] for row in rows])
    share = np.array([row["share_up"] for row in rows])
    count_part = np.array([row["count_part"] for row in rows])
    size_part = np.array([row["size_part"] for row in rows])
    inside = np.array([row["sum"] for row in rows])
    events = np.array([row["events"] for row in rows], dtype=float)
    weight = np.abs(count_part) + np.abs(size_part)
    up = np.array([row["kind"] == "up" for row in rows])
    same = np.sign(share - 0.5) == np.sign(total)
    return {
        "legs": len(rows),
        "up": int(up.sum()), "down": int((~up).sum()),
        "events": int(events.sum()),
        "share_up": {"up_legs": float(share[up].mean()) if up.any() else 0.0,
                     "down_legs": float(share[~up].mean()) if (~up).any()
                     else 0.0,
                     "all": float(share.mean())},
        "corr": {
            "total_share_up": pearson(total, share),
            "total_share_up_rank": spearman(total, share),
            "total_count_part": pearson(total, count_part),
            "total_size_part": pearson(total, size_part),
            "total_inside": pearson(total, inside),
            "abs_total_events": pearson(np.abs(total), events),
        },
        "parts": {
            "count": float(np.abs(count_part).sum() / weight.sum())
            if weight.sum() else 0.0,
            "size": float(np.abs(size_part).sum() / weight.sum())
            if weight.sum() else 0.0,
            "count_same_sign": float(np.mean(np.sign(count_part)
                                             == np.sign(total))),
            "size_same_sign": float(np.mean(np.sign(size_part)
                                            == np.sign(total))),
        },
        "inside": {"share": float(np.abs(inside).sum() / np.abs(total).sum()),
                   "same_sign": float(np.mean(np.sign(inside)
                                              == np.sign(total)))},
        "gaps": gaps_digest(rows, total, inside),
        "size": {kind: {
            "mean_up": float(np.mean([row["mean_up"] for row in rows
                                      if row["kind"] == kind])),
            "mean_down": float(np.mean([row["mean_down"] for row in rows
                                        if row["kind"] == kind])),
        } for kind in ("up", "down")},
        "events_per_leg": {"median": float(np.median(events)),
                           "shortest": float(events.min()),
                           "longest": float(events.max())},
        "total_abs": {"median": float(np.median(np.abs(total)))},
        "majority_matches_leg": float(same.mean()),
        "decile_share_up": {
            kind: [float(np.mean([row["deciles"][part] for row in rows
                                  if row["kind"] == kind
                                  and row["deciles"][part] is not None]))
                   for part in range(DECILES)]
            for kind in ("up", "down")},
    }


def build(pairs=PAIRS, root: Path | None = None) -> dict:
    by_pair, rows = {}, []
    for pair in pairs:
        data = series(pair, root)
        one = leg_rows(data, pair)
        by_pair[pair] = {**digest(one),
                         "window": {"from_utc": utc(data["t"][0]),
                                    "to_utc": utc(data["t"][-1])}}
        rows.extend(one)
    return {"script": "research/01-umap-class210x14x4/scripts/leg_events.py",
            "threshold": THRESHOLD, "period": PERIOD, "deciles": DECILES,
            "class": "class210x10x7", "parts": list(PARTS),
            "pairs": list(pairs), "by_pair": by_pair,
            "all": digest(rows), "legs": rows, "ready": bool(rows)}


def show(report: dict) -> None:
    everything = report["all"]
    print(f"ноги: {everything['legs']} "
          f"(вгору {everything['up']}, вниз {everything['down']}), "
          f"подій {everything['events']}")
    print("\nчастка подій зростання в нозі")
    for kind, value in (("нога вгору", "up_legs"), ("нога вниз", "down_legs")):
        print(f"  {kind}: {everything['share_up'][value]:.4f}")
    print(f"  більшість подій збігається з напрямком ноги: "
          f"{everything['majority_matches_leg']:.3f}")
    print("\nзвʼязок руху ноги з її подіями")
    for name, value in everything["corr"].items():
        print(f"  {name:<24} {value:+.3f}")
    print("\nз чого склалась сума рухів подій")
    print(f"  «скільки подій» {everything['parts']['count']:.3f} · "
          f"«які події» {everything['parts']['size']:.3f}")
    print(f"  знак збігається з ногою: скільки "
          f"{everything['parts']['count_same_sign']:.3f}, "
          f"які {everything['parts']['size_same_sign']:.3f}")
    print(f"  сума рухів подій до руху ноги: "
          f"{everything['inside']['share']:.3f}, "
          f"знак збігається {everything['inside']['same_sign']:.3f}")
    print("\nсередній модуль руху події, частками")
    for kind, title in (("up", "нога вгору"), ("down", "нога вниз")):
        block = everything["size"][kind]
        print(f"  {title}: зростання {block['mean_up']:.6f} · "
              f"падіння {block['mean_down']:.6f} · "
              f"перекіс {block['mean_up'] - block['mean_down']:+.6f}")
    print(f"  подій у нозі: медіана {everything['events_per_leg']['median']:.0f}"
          f" (від {everything['events_per_leg']['shortest']:.0f} "
          f"до {everything['events_per_leg']['longest']:.0f}), "
          f"рух ноги за модулем медіана "
          f"{everything['total_abs']['median']:.4f}")
    gaps = everything["gaps"]
    print(f"  рух у розривах між подіями: {gaps['share']:.3f} руху ніг, "
          f"медіана по нозі {gaps['median_relative']:.3f}; "
          f"ніг із розривами понад 10 % — {gaps['legs_over_10pct']}")
    print(f"  на {gaps['clean_legs']} ногах без розривів сума рухів подій "
          f"дає {gaps['clean_inside_share']:.3f} руху ноги")
    print("\nчастка подій зростання по десятинах ноги")
    for kind in ("up", "down"):
        line = " ".join(f"{value:.3f}"
                        for value in everything["decile_share_up"][kind])
        print(f"  {'вгору' if kind == 'up' else 'вниз':<6} {line}")
    print("\nпо монетах")
    print(f"  {'монета':<10} {'ніг':>4} {'↑ у нозі вгору':>15} "
          f"{'↑ у нозі вниз':>14} {'corr(рух, ↑)':>13}")
    for pair, block in report["by_pair"].items():
        print(f"  {pair:<10} {block['legs']:>4} "
              f"{block['share_up']['up_legs']:>15.4f} "
              f"{block['share_up']['down_legs']:>14.4f} "
              f"{block['corr']['total_share_up']:>13.3f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_events.json").write_text(
        json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "legs"}
    (args.out / "leg_events.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'leg_events.json'}")


if __name__ == "__main__":
    main()
