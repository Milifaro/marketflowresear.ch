"""Ноги, де кількість подій не збігається з напрямком ноги.

Дослідження: research/01-umap-class210x14x4/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Етап 10 показав: у нозі вгору подій зростання більше лише на 5 п. п.
Отже, є ноги, де їх **менше** — нога йде вгору, а подій падіння в ній
більше. Цей скрипт бере саме такі ноги й дивиться, чим їх події
відрізняються від подій ніг, де кількість збігається з напрямком.

    збіг       нога вгору й n↑ > n↓   або   нога вниз і n↓ > n↑
    незбіг     нога вгору й n↑ < n↓   або   нога вниз і n↓ < n↑
    порівну    n↑ = n↓

Те саме питання ставиться й до **розміру** подій: частина «які»
(`n↑(m↑−m) − n↓(m↓−m)`) теж має знак, і він теж буває проти ноги — тоді
події потрібного знака в нозі **менші** за протилежні.

    збіг за розміром     частина «які» тягне в бік ноги
    незбіг за розміром   частина «які» тягне проти ноги

Питання по кожній групі: чим нога робить свій рух, якщо подій потрібного
знака менше або вони менші — більшими подіями, кількома великими
стрибками чи довгими серіями поспіль, і де в нозі цей рух стається.
Окремо дивиться на ноги, де **обидві** частини йдуть проти ноги.

Ряд, ноги й рух події — ті самі, що в
[`leg_events.py`](leg_events.py): повний ряд монети (`train` + `val`
класу `клас210х10х7`), ема10, зігзаг 2.3 %, `r = ln(price_close /
price_open)`.

Вхід : data/datasets/<PAIR>/class210x10x7/{train,val}.npz
Вихід: results/leg_mismatch.json      — нога за ногою + зведення по групах
       results/leg_mismatch.meta.json — те саме зведення без переліку ніг

Запуск:
    python3 research/01-umap-class210x14x4/scripts/leg_mismatch.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

from class210ema4 import ema  # noqa: E402
from zigzag import zigzag  # noqa: E402

# Ряд, ноги й рух події — з етапу 10, без копіювання формул.
_spec = importlib.util.spec_from_file_location(
    "research01_leg_events", Path(__file__).resolve().parent / "leg_events.py")
leg_events = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(leg_events)

PAIRS = leg_events.PAIRS
DATASETS = leg_events.DATASETS
RESULTS = RESEARCH_DIR / "results"
THRESHOLD = leg_events.THRESHOLD
PERIOD = leg_events.PERIOD
DECILES = leg_events.DECILES
TOP = 10                       # скільки найбільших подій дивимось окремо


def runs(sign: np.ndarray) -> int:
    """Найдовша серія подій одного знака поспіль."""
    best = current = 0
    previous = 0
    for value in sign.tolist():
        if value == 0:
            current, previous = 0, 0
            continue
        current = current + 1 if value == previous else 1
        previous = value
        best = max(best, current)
    return best


def shape(move: np.ndarray, direction: int) -> dict:
    """Чим зроблено рух ноги: перекіс розміру, стрибки, серії.

    `direction` — напрямок ноги: +1 вгору, −1 вниз. Усе, що «за ногою»,
    рахується в її бік, тому числа ніг вгору й вниз лягають в один ряд.
    """
    net = float(move.sum())
    with_leg = move * direction                       # додатне — за ногою
    size = np.abs(move)
    order = np.argsort(size)[::-1]
    top = with_leg[order[:TOP]].sum()
    tenth = with_leg[order[:max(1, round(size.size * 0.1))]].sum()
    mean = float(size.mean()) if size.size else 0.0
    for_leg = with_leg > 0
    against = with_leg < 0
    mean_for = float(with_leg[for_leg].mean()) if for_leg.any() else 0.0
    mean_against = float(-with_leg[against].mean()) if against.any() else 0.0
    return {
        "net_with_leg": net * direction,
        "for": int(for_leg.sum()), "against": int(against.sum()),
        "mean_for": mean_for, "mean_against": mean_against,
        "skew": (mean_for - mean_against) / mean if mean else 0.0,
        "top_share": float(top / (net * direction)) if net else 0.0,
        "tenth_share": float(tenth / (net * direction)) if net else 0.0,
        "biggest": float(size.max() / abs(net)) if net and size.size else 0.0,
        "run_for": runs(np.sign(with_leg)),
        "kurtosis": float(((move - move.mean()) ** 4).mean()
                          / (move.std() ** 4)) if move.std() else 0.0,
    }


def leg_rows(data: dict, pair: str) -> list:
    """Ноги монети: група за кількістю подій і те, чим зроблено рух."""
    smooth = ema(data["open"], PERIOD)
    pivots = zigzag(smooth, THRESHOLD)
    group, legs = leg_events.leg_deciles.cohorts(pivots, len(smooth))
    move = np.log(data["close"] / data["open"])
    rows = []
    for leg in legs:
        first, last = leg["from"], leg["to"]
        piece = move[first:last + 1]
        place = group[first:last + 1] % DECILES
        direction = 1 if leg["kind"] == "up" else -1
        counted = leg_events.split(piece)
        edge = counted["up"] - counted["down"]
        row = {"pair": pair, "leg": len(rows) + 1, "kind": leg["kind"],
               "from": int(data["t"][first]), "to": int(data["t"][last]),
               "total": float(np.log(data["close"][last]
                                     / data["open"][first])),
               "events": counted["events"], "up": counted["up"],
               "down": counted["down"], "share_up": counted["share_up"],
               "count_part": counted["count_part"],
               "size_part": counted["size_part"],
               "count_group": ("match" if edge * direction > 0
                               else "tie" if edge == 0 else "mismatch"),
               "size_group": ("match"
                              if counted["size_part"] * direction > 0
                              else "mismatch"),
               **shape(piece, direction)}
        # Розрив ряду: скільки руху ноги лягло не в події, а між ними,
        # і скільки годин ряду в цій нозі просто немає.
        row["gaps"] = row["total"] * direction - row["net_with_leg"]
        step = np.diff(data["t"][first:last + 1])
        row["hole_hours"] = float((step[step > 210] - 210).sum() / 3600)
        row["by_decile"] = [
            float(piece[place == part % DECILES].sum() * direction)
            for part in range(1, DECILES + 1)]
        rows.append(row)
    return rows


def digest(rows: list) -> dict:
    """Зведення групи: чим її ноги роблять свій рух."""
    if not rows:
        return {"legs": 0}
    take = lambda key: np.array([row[key] for row in rows], dtype=float)  # noqa: E731
    total = np.abs(take("total"))
    events = take("events")
    net = take("net_with_leg")
    by_decile = np.array([row["by_decile"] for row in rows], dtype=float)
    share = by_decile.sum(axis=0) / by_decile.sum() if by_decile.sum() else \
        np.zeros(DECILES)
    return {
        "legs": len(rows),
        "up": sum(1 for row in rows if row["kind"] == "up"),
        "events": int(events.sum()),
        "events_median": float(np.median(events)),
        "total_median": float(np.median(total)),
        "share_up": float(take("share_up").mean()),
        "skew_median": float(np.median(take("skew"))),
        "top_share_median": float(np.median(take("top_share"))),
        "tenth_share_median": float(np.median(take("tenth_share"))),
        "biggest_median": float(np.median(take("biggest"))),
        "run_median": float(np.median(take("run_for"))),
        "kurtosis_median": float(np.median(take("kurtosis"))),
        "net_positive": float(np.mean(net > 0)),
        "net_against": int((net <= 0).sum()),
        "gaps_median": float(np.median(np.abs(take("gaps")) / total)),
        "gaps_over_10pct": int((np.abs(take("gaps")) / total > 0.1).sum()),
        "hole_hours_median": float(np.median(take("hole_hours"))),
        "legs_with_holes": int((take("hole_hours") > 1).sum()),
        "count_part_median": float(np.median(take("count_part"))),
        "size_part_median": float(np.median(take("size_part"))),
        "move_by_decile": share.tolist(),
    }


def build(pairs=PAIRS, root: Path | None = None) -> dict:
    rows = []
    for pair in pairs:
        rows.extend(leg_rows(leg_events.series(pair, root), pair))
    groups = {}
    for field, names in (("count_group", ("match", "mismatch", "tie")),
                         ("size_group", ("match", "mismatch"))):
        key = field.split("_")[0]
        for name in names:
            groups[f"{key}_{name}"] = digest(
                [row for row in rows if row[field] == name])
    # Обидві частини проти ноги: чим тоді зроблено її рух.
    groups["both_mismatch"] = digest(
        [row for row in rows if row["count_group"] == "mismatch"
         and row["size_group"] == "mismatch"])
    cross = {count: {size: sum(1 for row in rows
                               if row["count_group"] == count
                               and row["size_group"] == size)
                     for size in ("match", "mismatch")}
             for count in ("match", "mismatch", "tie")}
    by_pair = {pair: {"count": {name: sum(
        1 for row in rows if row["pair"] == pair
        and row["count_group"] == name)
        for name in ("match", "mismatch", "tie")},
        "size": {name: sum(1 for row in rows if row["pair"] == pair
                           and row["size_group"] == name)
                 for name in ("match", "mismatch")}}
        for pair in pairs}
    return {"script": "research/01-umap-class210x14x4/scripts/leg_mismatch.py",
            "threshold": THRESHOLD, "period": PERIOD, "deciles": DECILES,
            "top": TOP, "class": "class210x10x7", "pairs": list(pairs),
            "groups": groups, "cross": cross, "by_pair": by_pair,
            "all": digest(rows), "legs": rows, "ready": bool(rows)}


NAMES = {"count_match": "кількість збіг", "count_mismatch": "кількість незбіг",
         "count_tie": "кількість порівну", "size_match": "розмір збіг",
         "size_mismatch": "розмір незбіг", "both_mismatch": "обидві проти"}


def show(report: dict) -> None:
    everything = report["all"]
    print(f"ніг {everything['legs']}, подій {everything['events']}")
    print(f"\n  {'група':<18} {'ніг':>5} {'подій':>7} {'рух ноги':>9} "
          f"{'частка ↑':>9} {'перекіс':>8} {'топ-10':>7} {'десята':>7} "
          f"{'серія':>6} {'сума за ногою':>14} {'розриви':>8}")
    for name, block in report["groups"].items():
        if not block["legs"]:
            continue
        print(f"  {NAMES[name]:<18} {block['legs']:>5} "
              f"{block['events_median']:>7.0f} "
              f"{block['total_median']:>9.4f} {block['share_up']:>9.4f} "
              f"{block['skew_median']:>8.3f} "
              f"{block['top_share_median']:>7.3f} "
              f"{block['tenth_share_median']:>7.3f} "
              f"{block['run_median']:>6.0f} "
              f"{block['net_positive']:>14.3f} "
              f"{block['gaps_median']:>8.3f}")
    print("\nрух ноги по десятинах, частка руху групи")
    for name, block in report["groups"].items():
        if not block["legs"]:
            continue
        line = " ".join(f"{value:+.3f}" for value in block["move_by_decile"])
        print(f"  {NAMES[name]:<18} {line}")
    print("\nкількість × розмір, ніг")
    print(f"  {'':<10} {'розмір збіг':>12} {'розмір незбіг':>14}")
    for count, block in report["cross"].items():
        print(f"  {count:<10} {block['match']:>12} {block['mismatch']:>14}")
    print("\nпо монетах: кількість збіг/незбіг/порівну · розмір збіг/незбіг")
    for pair, block in report["by_pair"].items():
        print(f"  {pair:<10} {block['count']['match']:>4} "
              f"{block['count']['mismatch']:>4} {block['count']['tie']:>4}"
              f"   ·  {block['size']['match']:>4} "
              f"{block['size']['mismatch']:>4}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair or list(PAIRS), args.data)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_mismatch.json").write_text(
        json.dumps(report, ensure_ascii=False), encoding="utf-8")
    meta = {key: value for key, value in report.items() if key != "legs"}
    (args.out / "leg_mismatch.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    show(report)
    print(f"\nзаписано в {args.out / 'leg_mismatch.json'}")


if __name__ == "__main__":
    main()
