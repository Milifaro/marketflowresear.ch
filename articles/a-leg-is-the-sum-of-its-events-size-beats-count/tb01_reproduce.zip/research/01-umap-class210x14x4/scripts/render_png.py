"""Рендер одобрених виводів у PNG високої роздільності.

Дослідження: research/01-umap-class210x14x4/
Правила: CLAUDE.md розділ 7 (Збереження одобреного),
         rules/05-visualization.md (компоновка, кольори, якість).

Вихід: results/umap_train_cosine.png, results/chart_train.png

Запуск:
    python3 research/01-umap-class210x14x4/scripts/render_png.py
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

RESEARCH_DIR = Path(__file__).resolve().parents[1]
RESULTS = RESEARCH_DIR / "results"

DPI = 200
UP = "#46c882"
DOWN = "#eb5a5a"
BG = "#0d0f14"
PANEL = "#1b1e26"
TEXT = "#e6e8ee"
MUTED = "#98a0b3"


def _style(fig, axes):
    fig.patch.set_facecolor(PANEL)
    for ax in np.atleast_1d(axes):
        ax.set_facecolor(BG)
        ax.tick_params(colors=MUTED, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color("#2c313d")


def colors(delta: np.ndarray, limit: float) -> np.ndarray:
    """Зелене вгору, червоне вниз; насиченість — величина зміни (±3σ)."""
    scaled = np.clip(delta / (limit or 1e-9), -1, 1)
    rgba = np.zeros((len(delta), 4))
    up = scaled >= 0
    rgba[up] = matplotlib.colors.to_rgba(UP)
    rgba[~up] = matplotlib.colors.to_rgba(DOWN)
    rgba[:, 3] = 0.25 + 0.65 * np.abs(scaled)
    return rgba


def render_umap(out: Path) -> Path:
    with np.load(RESULTS / "umap_train_cosine.npz") as data:
        coords = data["coords"]
        delta = data["price_change"]
    meta = json.loads((RESULTS / "umap_train_cosine.meta.json").read_text("utf-8"))
    params = meta["params"]

    fig, ax = plt.subplots(figsize=(9, 7.5))
    _style(fig, ax)
    ax.scatter(coords[:, 0], coords[:, 1], s=1.4, linewidths=0,
               c=colors(delta, 3 * float(np.std(delta))))
    ax.set_title(
        f"UMAP клас210х14х4 (BTC_USDT, train): {meta['events']:,} подій, "
        f"вектор {meta['vector_size']} → 2 виміри\n"
        f"metric={params['metric']}, n_neighbors={params['n_neighbors']}, "
        f"min_dist={params['min_dist']}, seed={params['random_state']}. "
        f"Кожна точка — одна подія.".replace(",", " "),
        color=TEXT, fontsize=9, loc="left")
    ax.set_xlabel(
        "осі UMAP значень не мають; зелене — ціна за подію вгору, "
        "червоне — вниз, насиченість — величина зміни (±3σ)",
        color=MUTED, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=DPI, facecolor=fig.get_facecolor())
    plt.close(fig)
    return out


def render_chart(out: Path) -> Path:
    data = json.loads((RESULTS / "chart_train.json").read_text("utf-8"))
    times = np.array([p["t"] for p in data["points"]], dtype="datetime64[s]")
    prices = np.array([p["p"] for p in data["points"]])
    delta = np.array([p["d"] for p in data["points"]])

    fig, ax = plt.subplots(figsize=(16, 6))
    _style(fig, ax)
    ax.scatter(times, prices, s=1.2, linewidths=0,
               c=colors(delta, 3 * float(np.std(delta))))

    for pivots, width in ((data["pivots_inner"], 0.8), (data["pivots_outer"], 2.0)):
        for a, b in zip(pivots, pivots[1:]):
            ax.plot([np.datetime64(a["t"], "s"), np.datetime64(b["t"], "s")],
                    [a["p"], b["p"]],
                    color=UP if b["p"] >= a["p"] else DOWN, linewidth=width)
        ax.scatter([np.datetime64(p["t"], "s") for p in pivots],
                   [p["p"] for p in pivots],
                   c=[UP if p["k"] == "high" else DOWN for p in pivots],
                   s=6 + 8 * width, linewidths=0, zorder=3)

    span = [datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d")
            for t in data["period"]]
    ax.set_title(
        f"Ціна BTC_USDT по подіях класу {data['class_name']} "
        f"({data['sample']}): {data['events']:,} подій, {span[0]} … {span[1]} UTC. "
        f"Ряд ціни — {data['price_field']} кожної події. Зігзаг "
        f"{data['thresholds']['outer'] * 100:.1f} "
        f"({len(data['pivots_outer'])} півотів) і вкладений "
        f"{data['thresholds']['inner'] * 100:.1f} "
        f"({len(data['pivots_inner'])} півотів).".replace(",", " "),
        color=TEXT, fontsize=9, loc="left")
    ax.set_ylabel("ціна, USDT", color=MUTED, fontsize=8)
    ax.set_xlabel(
        "час, UTC · точки — події там, де вони були (зелене вгору, червоне вниз) · "
        "товсті лінії — зігзаг 2.3, тонкі — вкладений 0.8 · "
        "півот зверху зелений, знизу червоний",
        color=MUTED, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=DPI, facecolor=fig.get_facecolor())
    plt.close(fig)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    for path in (render_umap(args.out / "umap_train_cosine.png"),
                 render_chart(args.out / "chart_train.png")):
        print(f"записано {path} ({path.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
