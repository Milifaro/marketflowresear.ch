"""UMAP-проєкція подій будь-якого збереженого класу датасету (train.npz).

Дослідження: research/01-umap-class210x14x4/

Вхід : data/datasets/BTC_USDT/<клас>/train.npz
Вихід: results/umap_train_<metric>[_<клас>].npz  — 2D: координати + метадані
       results/umap_train_<metric>[_<клас>].json — те саме для дашборду
       results/umap3d_train_<metric>[_<клас>].* — те саме для 3D

Суфікс класу додається до імені для всіх класів, крім `клас210х14х4`:
його імена (`umap_train_cosine.*`) лишаються без суфікса — це одобрений
вивід етапів 1–4.

Запуск:
    python3 research/01-umap-class210x14x4/scripts/run_umap.py
    python3 research/01-umap-class210x14x4/scripts/run_umap.py --metric cosine
    python3 research/01-umap-class210x14x4/scripts/run_umap.py --all-metrics
    python3 research/01-umap-class210x14x4/scripts/run_umap.py \
        --class class210x14x5 --metric cosine
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210ema4  # noqa: E402
import class210ema4c  # noqa: E402
import class210x14x2  # noqa: E402
import class210x14x3  # noqa: E402
import class210x14x4  # noqa: E402
import class210x14x4c  # noqa: E402
import class210x210x3  # noqa: E402
import class210x210x4c  # noqa: E402
import class210x4bema10x10x130  # noqa: E402
import class210x14x5  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets" / "BTC_USDT"
DEFAULT_OUT = RESEARCH_DIR / "results"

# Класи датасету, які вміє читати скрипт: усі, що зберігаються в data/.
# `клас210х8` не зберігається, тому карти для нього немає.
# BASE не дістає суфікса в іменах файлів — це одобрений вивід етапів 1–4.
BASE = "class210x14x4"
CLASSES = {"class210x14x2": class210x14x2, "class210x14x3": class210x14x3,
           "class210x14x4": class210x14x4, "class210x14x4c": class210x14x4c,
           "class210x14x5": class210x14x5,
           "class210x210x3": class210x210x3,
           "class210x210x4c": class210x210x4c,
           "class210ema4": class210ema4, "class210ema4c": class210ema4c,
           "class210x4bema10x10x130": class210x4bema10x10x130}
DEFAULT_INPUT = DATASETS / BASE / "train.npz"

# Три метрики відстані на кожен клас (rules/05-visualization.md → UMAP)
METRICS = ["cosine", "euclidean", "manhattan"]


# Вимірності проєкції: 2 — площина, 3 — обʼєм (обертається на вкладці)
DIMS = (2, 3)


def stem(metric: str, class_name: str = BASE, dims: int = 2) -> str:
    """Імʼя виводу: базовий клас — без суфікса, решта — з суфіксом класу.

    2D лишається `umap_train_*` — це одобрений вивід етапів 1–6.
    3D дістає власний префікс `umap3d_train_*`, щоб файли не змішувались.
    """
    prefix = "umap_train" if dims == 2 else f"umap{dims}d_train"
    return (f"{prefix}_{metric}" if class_name == BASE
            else f"{prefix}_{metric}_{class_name}")


def flatten(x: np.ndarray) -> np.ndarray:
    """(N, B, F) -> (N, B * F). Порядок: фіча за фічею.

    Клас на один блок (`клас210х210х3`, `клас210ема4`) зберігається як
    (N, F) — там розгортати нічого, вектор події вже готовий.
    """
    if x.ndim == 2:
        return x.astype(np.float64)
    if x.ndim != 3:
        raise ValueError("очікується масив (N, B, F) або (N, F)")
    return x.transpose(0, 2, 1).reshape(len(x), -1).astype(np.float64)


def standardize(x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """z-score. Статистики рахуються на цьому ж масиві (train) — без витоку."""
    mean = x.mean(axis=0)
    std = x.std(axis=0)
    std[std == 0] = 1.0
    return (x - mean) / std, mean, std


def price_change(price_open: np.ndarray, price_close: np.ndarray) -> np.ndarray:
    """Зміна ціни за подію, частками (0.01 = 1%). Не фіча — тільки для розмітки."""
    return (price_close - price_open) / price_open


def run(input_path: Path, out_dir: Path, n_neighbors: int, min_dist: float,
        metric: str, seed: int, class_name: str = BASE, dims: int = 2) -> dict:
    import time

    import umap  # імпорт тут: важкий, не потрібен для тестів формул

    dataset = CLASSES[class_name].load(input_path)
    tag = f"{metric} {dims}D"
    print(f"[1/4] {tag}: завантажено {len(dataset)} подій з {input_path.name}")

    flat = flatten(dataset.x)
    # Подія з NaN хоч в одному значенні не проєктується: UMAP не приймає
    # пропусків, а заповнювати їх — вигадувати дані. Скільки таких —
    # у meta. Класи без NaN проходять цей крок без змін.
    finite = np.isfinite(flat).all(axis=1)
    dropped = int((~finite).sum())
    if dropped:
        flat = flat[finite]
        dataset = type(dataset)(
            x=dataset.x[finite], timestamp=dataset.timestamp[finite],
            price_open=dataset.price_open[finite],
            price_close=dataset.price_close[finite])
        print(f"      {tag}: подій з NaN відкинуто {dropped}")
    scaled, mean, std = standardize(flat)
    print(f"[2/4] {tag}: вектор події {flat.shape[1]} значень, z-score")

    started = time.time()
    reducer = umap.UMAP(n_components=dims, n_neighbors=n_neighbors,
                        min_dist=min_dist, metric=metric, random_state=seed,
                        verbose=False)
    coords = reducer.fit_transform(scaled).astype(np.float32)
    elapsed = time.time() - started
    print(f"[3/4] {tag}: готово {coords.shape} за {elapsed:.0f} с")

    delta = price_change(dataset.price_open, dataset.price_close)
    out_dir.mkdir(parents=True, exist_ok=True)
    name = stem(metric, class_name, dims)
    np.savez_compressed(
        out_dir / f"{name}.npz",
        coords=coords, timestamp=dataset.timestamp,
        price_open=dataset.price_open, price_close=dataset.price_close,
        price_change=delta.astype(np.float32),
        feature_mean=mean, feature_std=std,
    )

    meta = {
        "source": str(input_path.relative_to(PROJECT_ROOT)),
        "class_name": class_name,
        "dims": dims,
        "events": len(dataset),
        "dropped_nan": dropped,
        "vector_size": int(flat.shape[1]),
        "features": list(dataset.features),
        "params": {"n_components": dims, "n_neighbors": n_neighbors,
                   "min_dist": min_dist, "metric": metric,
                   "random_state": seed},
        "seconds": round(elapsed, 1),
        "price_change": {
            "min": float(delta.min()), "max": float(delta.max()),
            "mean": float(delta.mean()), "std": float(delta.std()),
        },
    }
    payload = dict(meta)
    keys = ("x", "y", "z")
    payload["points"] = [
        {**{keys[i]: round(float(value), 3) for i, value in enumerate(point)},
         "t": int(ts), "d": round(float(dd), 6)}
        for point, ts, dd in zip(coords, dataset.timestamp, delta)
    ]
    (out_dir / f"{name}.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    (out_dir / f"{name}.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[4/4] {tag}: записано в {out_dir}")
    return meta


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--class", dest="class_name", default=BASE,
                        choices=sorted(CLASSES))
    parser.add_argument("--input", type=Path, default=None,
                        help="за замовчуванням train.npz обраного класу")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--n-neighbors", type=int, default=30)
    parser.add_argument("--min-dist", type=float, default=0.1)
    parser.add_argument("--metric", default="cosine", choices=METRICS)
    parser.add_argument("--all-metrics", action="store_true",
                        help=f"прогнати всі метрики: {', '.join(METRICS)}")
    parser.add_argument("--all-classes", action="store_true",
                        help="усі класи × усі метрики")
    parser.add_argument("--dims", type=int, default=2, choices=DIMS,
                        help="вимірність проєкції: 2 — площина, 3 — обʼєм")
    parser.add_argument("--all-dims", action="store_true",
                        help=f"прогнати всі вимірності: {', '.join(map(str, DIMS))}")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    classes = sorted(CLASSES) if args.all_classes else [args.class_name]
    metrics = (METRICS if args.all_metrics or args.all_classes
               else [args.metric])

    dims = DIMS if args.all_dims else (args.dims,)

    for class_name in classes:
        source = args.input or DATASETS / class_name / "train.npz"
        for metric in metrics:
            for size in dims:
                run(source, args.out, args.n_neighbors, args.min_dist, metric,
                    args.seed, class_name, size)


if __name__ == "__main__":
    main()
