"""Дані графіка train: ціна по подіях + зігзаг 2.3 і вкладений 0.8.

Дослідження: research/01-umap-class210x14x4/

Ряд ціни — `price_open` подій train у хронологічному порядку (той самий набір
подій, що йде в UMAP). Зігзаги — rules/02-markup.md, реалізація —
rules/scripts/zigzag.py.

Вихід: results/chart_train.json

Запуск:
    python3 research/01-umap-class210x14x4/scripts/build_chart.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x14x4  # noqa: E402
import zigzag  # noqa: E402

DEFAULT_INPUT = (PROJECT_ROOT / "data" / "datasets" / "BTC_USDT"
                 / "class210x14x4" / "train.npz")
DEFAULT_OUT = RESEARCH_DIR / "results" / "chart_train.json"


def build(input_path: Path, outer: float, inner: float) -> dict:
    dataset = class210x14x4.load(input_path)
    order = np.argsort(dataset.timestamp)

    timestamps = dataset.timestamp[order]
    price_open = dataset.price_open[order].astype(float)
    price_close = dataset.price_close[order].astype(float)
    delta = (price_close - price_open) / price_open
    print(f"[1/3] {len(order)} подій, ціна — price_open у порядку часу")

    outer_pivots = zigzag.zigzag(price_open, outer)
    inner_pivots = zigzag.nested_zigzag(price_open, outer_pivots, inner)
    print(f"[2/3] зігзаг {outer * 100:.1f}: {len(outer_pivots)} півотів, "
          f"вкладений {inner * 100:.1f}: {len(inner_pivots)} півотів")

    return {
        "available": True,
        "pair": "BTC_USDT",
        "class_name": "клас210х14х4",
        "sample": "train",
        "source": str(input_path.relative_to(PROJECT_ROOT)),
        "events": len(order),
        "price_field": "price_open",
        "thresholds": {"outer": outer, "inner": inner},
        "period": [int(timestamps[0]), int(timestamps[-1])],
        "points": [
            {"t": int(t), "p": round(float(p), 2), "d": round(float(d), 6)}
            for t, p, d in zip(timestamps, price_open, delta)
        ],
        "pivots_outer": [p.as_dict(price_open, timestamps) for p in outer_pivots],
        "pivots_inner": [p.as_dict(price_open, timestamps) for p in inner_pivots],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--outer", type=float, default=zigzag.OUTER_THRESHOLD)
    parser.add_argument("--inner", type=float, default=zigzag.INNER_THRESHOLD)
    args = parser.parse_args()

    payload = build(args.input, args.outer, args.inner)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    print(f"[3/3] записано {args.out}")


if __name__ == "__main__":
    main()
