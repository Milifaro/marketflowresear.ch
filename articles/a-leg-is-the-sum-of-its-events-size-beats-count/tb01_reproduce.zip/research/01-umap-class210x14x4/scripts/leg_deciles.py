"""Десятина ноги зігзага 2.3 % для кожної події train (BTC_USDT).

Дослідження: research/01-umap-class210x14x4/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Рецепт той самий, що в дослідженні 21
([`leg_deciles.py`](../../21-class210x10x7dc/scripts/leg_deciles.py)):

    ема10(price_open) -> півоти зігзага 2.3 % -> ноги -> десятини

Нога — відрізок від події після попереднього півота до самого півота
включно; ділиться на **десять рівних частин за кількістю подій**: `1` —
перші 10 % подій ноги, `10` — останні 10 %. Напрямок ноги — за півотом,
яким вона закінчується: `high` закриває ногу вгору, `low` — вниз.

    0            подія поза ногами (до першого півота і після останнього)
    1 … 10       десятина ноги вгору
    11 … 20      десятина ноги вниз

Ряд — події карти в хронологічному порядку: час і ціна відкриття беруться
з `.npz` самої карти, тому кнопки лягають на неї подія в подію навіть
після перебудови датасету. Розбиття рендомне, тому ряд дірявий: півоти
відповідають тому ряду, який видно на карті, а не суцільній ціні
(те саме рішення, що в `build_chart.py`).

Вхід : results/umap_train_cosine.npz (ряд подій карти)
Вихід: results/deciles.json — `t`, `g`, `n` подія за подією + звіт по
       когортах і перелік ніг (`legs.list`) для лічильника ноги

Запуск:
    python3 research/01-umap-class210x14x4/scripts/leg_deciles.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x14x4  # noqa: E402
from class210ema4 import ema  # noqa: E402
from zigzag import Pivot, zigzag  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets" / "BTC_USDT"
RESULTS = RESEARCH_DIR / "results"
# Ряд береться з .npz самої карти, а не з датасету: карта — це той ряд,
# на який лягають кнопки, і він мусить збігтися з нею подія в подію.
DEFAULT_INPUT = RESULTS / "umap_train_cosine.npz"

THRESHOLD = 0.023          # зігзаг 2.3 %
PERIOD = 10                # ема ціни, на якій стоять півоти
DECILES = 10               # на скільки частин ділиться нога


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def series(path: Path) -> dict:
    """Події одним рядом за часом: час і ціна відкриття.

    Приймає і `.npz` карти (`coords`, `timestamp`, `price_open`), і `.npz`
    датасету — потрібні лише час і ціна події.
    """
    with np.load(path) as store:
        if "coords" in store:
            stamps, price = store["timestamp"], store["price_open"]
        else:
            dataset = class210x14x4.load(path)
            stamps, price = dataset.timestamp, dataset.price_open
    order = np.argsort(stamps, kind="stable")
    return {"t": np.asarray(stamps, dtype=np.int64)[order],
            "price": np.asarray(price, dtype=float)[order]}


def cohorts(pivots: list[Pivot], count: int, parts: int = DECILES
            ) -> tuple[np.ndarray, list]:
    """Когорта кожної події: 0 поза ногами, 1…10 вгору, 11…20 вниз.

    Ноги нумеруються підряд з одиниці — це число вводить лічильник ноги
    на вкладці.
    """
    group = np.zeros(count, dtype=np.int16)
    legs = []
    for previous, pivot in zip(pivots, pivots[1:]):
        first, last = previous.index + 1, pivot.index
        if last <= first:
            continue
        length = last - first + 1
        place = np.arange(length) / length
        decile = np.minimum(np.floor(place * parts) + 1, parts).astype(np.int16)
        up = pivot.kind == "high"
        group[first:last + 1] = decile + (0 if up else parts)
        legs.append({"leg": len(legs) + 1, "kind": "up" if up else "down",
                     "events": int(length), "first": first, "last": last})
    return group, legs


def leg_cards(legs: list, data: dict) -> list:
    """Нога рядком для лічильника: номер, напрямок, події, період, рух ціни."""
    cards = []
    for leg in legs:
        first, last = leg["first"], leg["last"]
        start, end = float(data["price"][first]), float(data["price"][last])
        cards.append({"leg": leg["leg"], "kind": leg["kind"],
                      "events": leg["events"],
                      "from": int(data["t"][first]), "to": int(data["t"][last]),
                      "from_utc": utc(data["t"][first]),
                      "to_utc": utc(data["t"][last]),
                      "change": (end - start) / start if start else 0.0})
    return cards


def build(path: Path = DEFAULT_INPUT, period: int = PERIOD,
          threshold: float = THRESHOLD) -> dict:
    data = series(path)
    smooth = ema(data["price"], period)
    pivots = zigzag(smooth, threshold)
    group, legs = cohorts(pivots, len(smooth))
    return {"data": data, "pivots": pivots, "group": group, "legs": legs,
            "period": period, "threshold": threshold,
            "cards": leg_cards(legs, data)}


def report(one: dict, source: Path = DEFAULT_INPUT) -> dict:
    group, data, legs = one["group"], one["data"], one["legs"]
    counts = [{"group": value,
               "kind": "up" if value <= DECILES else "down",
               "decile": value if value <= DECILES else value - DECILES,
               "events": int((group == value).sum())}
              for value in range(1, DECILES * 2 + 1)]
    lengths = [leg["events"] for leg in legs]
    return {
        "source": str(source.relative_to(PROJECT_ROOT)),
        "threshold": one["threshold"],
        "period": one["period"],
        "deciles": DECILES,
        "events": int(len(group)),
        "window": {"from_utc": utc(data["t"][0]), "to_utc": utc(data["t"][-1])},
        "pivots": len(one["pivots"]),
        "legs": {"total": len(legs),
                 "up": sum(1 for leg in legs if leg["kind"] == "up"),
                 "down": sum(1 for leg in legs if leg["kind"] == "down"),
                 "shortest": min(lengths, default=0),
                 "longest": max(lengths, default=0),
                 "median": int(np.median(lengths)) if lengths else 0,
                 "list": one.get("cards", leg_cards(legs, data))},
        "outside": int((group == 0).sum()),
        "cohorts": counts,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--period", type=int, default=PERIOD)
    parser.add_argument("--threshold", type=float, default=THRESHOLD)
    args = parser.parse_args()

    one = build(args.input, args.period, args.threshold)
    meta = report(one, args.input)
    args.out.mkdir(parents=True, exist_ok=True)
    payload = dict(meta)
    payload["t"] = one["data"]["t"].tolist()
    payload["g"] = one["group"].tolist()
    (args.out / "deciles.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    (args.out / "deciles.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"подій {meta['events']}, півотів {meta['pivots']}, "
          f"ніг {meta['legs']['total']}, поза ногами {meta['outside']}")
    print(f"записано в {args.out}")


if __name__ == "__main__":
    main()
