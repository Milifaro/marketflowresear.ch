"""Перелік ніг зігзага 2.3 % для лічильника ноги на вкладці `/umap`.

Дослідження: research/01-umap-class210x14x4/
Правила: rules/02-markup.md → Порядок орієнтовної розмітки

Лічильник ноги стоїть над кнопками десятин і працює **на кожному класі
вкладки**, а класи приходять із двох тек:

    research/01-umap-class210x14x4/results   ряд подій карти BTC_USDT
    research/21-class210x10x7dc/results      ряд подій шести монет

Обидві теки вже мають розмітку ніг тим самим рецептом
(`ема10(price_open) -> півоти зігзага 2.3 % -> ноги`), тому цей скрипт
нічого не рахує заново: він **збирає ноги в один перелік** і нумерує їх
підряд з одиниці — це те число, яке вводиться в лічильник.

    дослідження 01  ноги беруться з results/deciles.json (`legs.list`)
    дослідження 21  ноги збираються з results/deciles.npz (когорта події)
                    і півотів results/legs_<PAIR>.json (рух ноги за ема10)

Нумерація в межах теки наскрізна: монети йдуть у порядку `PAIRS`, ноги
кожної монети — за часом.

Вхід : research/01-umap-class210x14x4/results/deciles.json
       research/21-class210x10x7dc/results/deciles.npz, legs_<PAIR>.json
Вихід: results/legs_index.json — ноги обох тек із номером, монетою,
       напрямком, кількістю подій, періодом і рухом ціни

Запуск:
    python3 research/01-umap-class210x14x4/scripts/leg_index.py
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]

RESULTS = RESEARCH_DIR / "results"
X7DC_RESULTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "results"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
DECILES = 10


def utc(seconds) -> str:
    return dt.datetime.fromtimestamp(int(seconds), dt.timezone.utc) \
             .strftime("%Y-%m-%d %H:%M:%S")


def own_legs(path: Path) -> list:
    """Ноги дослідження 01: готовий перелік із deciles.json."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    legs = []
    for card in payload["legs"]["list"]:
        legs.append({**card, "pair": "BTC_USDT", "leg": len(legs) + 1})
    return legs


def runs(stamps: np.ndarray, group: np.ndarray) -> list:
    """Ноги одного ряду з когорт: напрямок міняється — почалась нова нога.

    Когорта — 1…10 нога вгору, 11…20 нога вниз, 0 поза ногами. Зігзаг
    чергує напрямки, тому межа ноги — це або нуль, або зміна смуги, або
    десятина, що пішла назад (10 → 1).
    """
    legs = []
    start = None
    for index, value in enumerate(group.tolist()):
        if not value:
            start = None
            continue
        band = value <= DECILES
        decile = value if band else value - DECILES
        if start is not None:
            previous = int(group[index - 1])
            back = decile < (previous if previous <= DECILES
                             else previous - DECILES)
            if band != (previous <= DECILES) or back:
                legs.append((start, index - 1))
                start = index
        else:
            start = index
        if index + 1 == len(group) or not group[index + 1]:
            legs.append((start, index))
            start = None
    return [{"first": first, "last": last,
             "kind": "up" if group[last] <= DECILES else "down",
             "events": last - first + 1,
             "from": int(stamps[first]), "to": int(stamps[last]),
             "from_utc": utc(stamps[first]), "to_utc": utc(stamps[last])}
            for first, last in legs]


def moves(path: Path) -> dict:
    """Рух ноги за ема10: від півота до півота, ключ — час другого півота."""
    if not path.exists():
        return {}
    pivots = json.loads(path.read_text(encoding="utf-8"))["pivots"]
    return {pivot["t"]: (pivot["e"] - previous["e"]) / previous["e"]
            for previous, pivot in zip(pivots, pivots[1:]) if previous["e"]}


def pair_legs(folder: Path, pairs=PAIRS) -> list:
    """Ноги дослідження 21: когорти з deciles.npz, рух — з півотів ема10."""
    source = folder / "deciles.npz"
    if not source.exists():
        return []
    legs = []
    with np.load(source) as store:
        for pair in pairs:
            if f"{pair}_t" not in store:
                continue
            stamps, group = store[f"{pair}_t"], store[f"{pair}_g"]
            change = moves(folder / f"legs_{pair}.json")
            for leg in runs(stamps, group):
                leg.pop("first"), leg.pop("last")
                legs.append({**leg, "pair": pair, "leg": len(legs) + 1,
                             "change": change.get(leg["to"])})
    return legs


def build(results: Path = RESULTS, x7dc: Path = X7DC_RESULTS) -> dict:
    own = own_legs(results / "deciles.json")
    other = pair_legs(x7dc)
    relative = lambda path: str(path.relative_to(PROJECT_ROOT))  # noqa: E731
    return {
        "script": "research/01-umap-class210x14x4/scripts/leg_index.py",
        "threshold": 0.023, "period": 10, "deciles": DECILES,
        "sources": {
            relative(results): {"pairs": ["BTC_USDT"], "legs": own},
            relative(x7dc): {"pairs": list(PAIRS), "legs": other},
        },
        "ready": bool(own or other),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--x7dc", type=Path, default=X7DC_RESULTS)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    index = build(args.results, args.x7dc)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "legs_index.json").write_text(
        json.dumps(index, ensure_ascii=False), encoding="utf-8")
    for folder, block in index["sources"].items():
        print(f"{folder}: ніг {len(block['legs'])}, "
              f"монет {len(block['pairs'])}")
    print(f"записано в {args.out / 'legs_index.json'}")


if __name__ == "__main__":
    main()
