"""Ціна BTC і хітмап подій клас210х14х4 під нею, спільна вісь часу.

Дослідження: research/01-umap-class210x14x4/
Правила: rules/05-visualization.md (опис зверху, підвал під графіком синхронно,
         легенда знизу), rules/01-data-and-db.md (побудова класів).

Вхід : data/2026/<MM>/BTC_USDT/1S_*.csv (робоча копія)
Вихід: results/price_heatmap.png
       results/price_heatmap.meta.json

Запуск:
    python3 research/01-umap-class210x14x4/scripts/price_heatmap.py \
        --from 2026-05-01 --to 2026-08-21
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import (LinearSegmentedColormap, LogNorm,  # noqa: E402
                               SymLogNorm)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x8  # noqa: E402
import class210x14x4  # noqa: E402
from data_source import WORK_ROOT, load_day, to_array  # noqa: E402

DPI = 200
SLOT = class210x8.EVENT_LENGTH          # 210 с — довжина події
BUCKET = 3600                            # колонка хітмапа: усереднення за годину
PRICE_STEP = 60                          # проріджування ціни для рендера, с
BG, PANEL, TEXT, MUTED = "#0d0f14", "#1b1e26", "#e6e8ee", "#98a0b3"
UP, DOWN = "#46c882", "#eb5a5a"

# Зелене/червоне зарезервовані за напрямком (rules/05-visualization.md),
# тому шкала величини — багатокольорова, але без них: синє → блакитне →
# фіолетове → жовте → біле.
SEQUENTIAL = LinearSegmentedColormap.from_list("level", [
    "#0b1020", "#16305c", "#2f6fae", "#4c8dff", "#59c8e8", "#9d8cf0",
    "#e0c341", "#ffe9a8", "#ffffff"])
DIVERGING = LinearSegmentedColormap.from_list("down_up", [
    "#ff8f8f", DOWN, "#8c2b2e", "#3a1416", BG, "#0f3324", "#1c7a4d", UP,
    "#9dedc0"])

BANDS = [
    ("resist", SEQUENTIAL, False),
    ("d_resist", DIVERGING, True),
    ("support", SEQUENTIAL, False),
    ("d_support", DIVERGING, True),
]


def day_files(start: str, end: str, root: Path = None) -> list[Path]:
    root = root or WORK_ROOT
    files = sorted(root.glob("*/*/BTC_USDT/1S_*_BTC_USDT.csv"))
    return [f for f in files if start <= f.name.split("_")[1] <= end]


def collect(files: list[Path]):
    """Ціна посекундно, події клас210х14х4 і їхні середні обʼєми у вікні.

    Повертає (stamps, prices, events, ratio), де ratio — відношення
    mean(vol_buy) / mean(vol_sell) за 210 с кожної події.
    """
    stamps, prices, parts = [], [], []
    for i, path in enumerate(files, 1):
        frame, _ = load_day(path)
        rows = to_array(frame)
        stamps.append(rows[:, 0])
        prices.append(rows[:, 1])
        parts.append(class210x8.build(rows))
        if i % 25 == 0 or i == len(files):
            print(f"      {i}/{len(files)} днів")
    base = class210x8.concat(parts)
    mean_buy = base.x[:, :, class210x8.FEATURES.index("vol_buy")].mean(axis=1)
    mean_sell = base.x[:, :, class210x8.FEATURES.index("vol_sell")].mean(axis=1)
    keep = (mean_buy != 0) & (mean_sell != 0)   # той самий відсів, що в build()

    events, report = class210x14x4.build(base)
    print(f"[2/4] подій клас210х14х4: {len(events)} "
          f"(відкинуто через нульовий обʼєм: {report.dropped_zero_volume})")
    ratio = mean_buy[keep] / mean_sell[keep]
    return np.concatenate(stamps), np.concatenate(prices), events, ratio


def grid(events: class210x14x4.Class210x14x4, t0: int, t1: int,
         bucket: int = BUCKET) -> tuple[np.ndarray, np.ndarray]:
    """Події на рівномірну сітку: колонка = bucket секунд, середнє по подіях.

    Повертає (значення (колонки, 15, 4), кількість подій у колонці).
    """
    columns = int((t1 - t0) // bucket) + 1
    total = np.zeros((columns, 15, 4))
    count = np.zeros(columns)
    position = ((events.timestamp - t0) // bucket).astype(int)
    inside = (position >= 0) & (position < columns)
    np.add.at(total, position[inside], events.x[inside])
    np.add.at(count, position[inside], 1)

    values = np.full_like(total, np.nan)
    filled = count > 0
    values[filled] = total[filled] / count[filled][:, None, None]
    return values, count


def scale(values: np.ndarray, diverging: bool):
    """Шкала кольору. Значення сильно скошені, тому логарифмічна.

    Лінійна шкала робить майже все темним: 5-й і 95-й процентилі
    відрізняються в десятки разів.
    """
    finite = values[np.isfinite(values)]
    if diverging:
        high = float(np.percentile(np.abs(finite), 99))
        middle = float(np.percentile(np.abs(finite), 50))
        return SymLogNorm(linthresh=max(middle, 1e-6), vmin=-high, vmax=high,
                          base=10), (-high, high)
    low = max(float(np.percentile(finite, 2)), 1e-6)
    high = float(np.percentile(finite, 98))
    return LogNorm(vmin=low, vmax=high), (low, high)


def render(stamps, prices, events, start: str, end: str, out: Path,
           bucket: int = BUCKET) -> dict:
    t0, t1 = int(stamps[0]), int(stamps[-1])
    cells, count = grid(events, t0, t1, bucket)
    span = [mdates.date2num(datetime.fromtimestamp(t, timezone.utc))
            for t in (t0, t1)]

    fig = plt.figure(figsize=(18, 11))
    spec = fig.add_gridspec(5, 2, height_ratios=[3.2, 1, 1, 1, 1],
                            width_ratios=[60, 1], hspace=0.08, wspace=0.012)
    axes = [fig.add_subplot(spec[0, 0])]
    axes += [fig.add_subplot(spec[row, 0], sharex=axes[0]) for row in range(1, 5)]
    bars = [fig.add_subplot(spec[row, 1]) for row in range(5)]
    bars[0].axis("off")
    for ax in axes[:-1]:
        ax.tick_params(labelbottom=False)

    fig.patch.set_facecolor(PANEL)
    for ax in axes:
        ax.set_facecolor(BG)
        ax.tick_params(colors=MUTED, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color("#2c313d")

    keep = np.arange(0, len(stamps), PRICE_STEP)
    times = mdates.date2num([datetime.fromtimestamp(t, timezone.utc)
                             for t in stamps[keep]])
    axes[0].plot(times, prices[keep], color="#4c8dff", linewidth=0.7)
    axes[0].set_ylabel("ціна, USDT", color=MUTED, fontsize=8)
    hours = bucket // 3600
    axes[0].set_title(
        f"BTC_USDT, {start} … {end} UTC — ціна (price_avg, крок {PRICE_STEP} с)\n"
        f"Під нею хітмап подій клас210х14х4 на тій самій осі часу: "
        f"{len(events)} подій, колонка = {hours} год "
        f"(середнє по подіях години, у середньому "
        f"{count[count > 0].mean():.1f} події), 15 рядків у смузі — блоки по 14 с.\n"
        f"Порожні колонки — години без жодної події (пропуски в даних): "
        f"{int((count == 0).sum())} з {len(count)}.",
        color=TEXT, fontsize=9, loc="left")

    ranges = {}
    for feature, (ax, bar, (name, cmap, diverging)) in enumerate(
            zip(axes[1:], bars[1:], BANDS)):
        band = cells[:, :, feature].T          # (15, колонки)
        norm, (low, high) = scale(band, diverging)
        ranges[name] = [low, high]
        image = ax.imshow(band, aspect="auto", origin="lower",
                          interpolation="nearest", cmap=cmap, norm=norm,
                          extent=[span[0], span[1], 0, 15])
        ax.set_yticks([0, 15])
        ax.set_yticklabels(["1", "15"])
        ax.set_ylabel(name, color=MUTED, fontsize=8)

        colorbar = fig.colorbar(image, cax=bar)
        colorbar.ax.tick_params(colors=MUTED, labelsize=7)
        colorbar.outline.set_edgecolor("#2c313d")

    axes[-1].xaxis.set_major_locator(mdates.AutoDateLocator())
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    axes[-1].set_xlabel("час, UTC", color=MUTED, fontsize=8)
    fig.text(
        0.5, -0.01,
        "resist і support — рівні в одиницях обʼєму, шкала логарифмічна: "
        "синє (мало) → блакитне → фіолетове → жовте → біле (багато)\n"
        "d_resist і d_support мають знак: зелене — плюс, червоне — мінус, "
        "шкала симетрична логарифмічна\n"
        "межі шкал: 2-й і 98-й процентилі вікна для рівнів, ±99-й для знакових; "
        "значення поза межами малюються кольором краю",
        color=MUTED, fontsize=8, ha="center", va="top")

    fig.savefig(out, dpi=DPI, facecolor=fig.get_facecolor(),
                bbox_inches="tight")
    plt.close(fig)
    return {"ranges": ranges, "bucket_seconds": bucket,
            "columns": int(cells.shape[0]),
            "empty_columns": int((count == 0).sum()),
            "events_per_column_mean": float(count[count > 0].mean())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from", dest="start", default="2026-05-01")
    parser.add_argument("--to", dest="end", default="2026-08-21")
    parser.add_argument("--bucket", type=int, default=BUCKET,
                        help="секунд на колонку хітмапа")
    parser.add_argument("--out", type=Path, default=RESEARCH_DIR / "results")
    args = parser.parse_args()

    files = day_files(args.start, args.end)
    if not files:
        raise SystemExit("немає файлів у вікні — скопіюй їх у data/")
    print(f"[1/4] днів у вікні: {len(files)}")

    stamps, prices, events, _ = collect(files)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / "price_heatmap.png"
    info = render(stamps, prices, events, args.start, args.end, path,
                  args.bucket)
    print(f"[3/4] {path.name}: {path.stat().st_size // 1024} KB")

    meta = {
        "pair": "BTC_USDT", "from": args.start, "to": args.end,
        "days": len(files), "seconds": int(len(stamps)),
        "events": int(len(events)), "event_seconds": SLOT,
        "price_step_seconds": PRICE_STEP,
        "note": ("вікно виходить за відсічку основного датасету 2026-08-16 — "
                 "це вивід, не навчальні дані"),
        **info,
    }
    (args.out / "price_heatmap.meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[4/4] колонок {info['columns']}, порожніх {info['empty_columns']}, "
          f"подій на колонку {info['events_per_column_mean']:.1f}")


if __name__ == "__main__":
    main()
