"""Наскільки test незалежний від train: сусід за часом і його ціль.

Дослідження: research/12-zigzag-net/ (етап 6)

Розбиття (`rules/scripts/split.py`) перемішує події випадково, тому подія
з test лежить у часі поруч із подіями train. Скрипт міряє, наскільки
поруч, і скільки з цього можна взяти без жодної моделі:

    розрив   — скільки секунд від події val/test до найближчої події train
    базовий  — «взяти ціль найближчої події train» як прогноз

Якщо базовий прогноз не гірший за модель, то test міряє інтерполяцію між
сусідами, а не роботу на нових даних.

Вихід: results/neighbours_0_8.json

Запуск:
    python3 research/12-zigzag-net/scripts/neighbours.py --target 0.8
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import zigzag_targets  # noqa: E402
from data import (DATASET, DEFAULT_LEG, KINDS, LEGS, PARTS,  # noqa: E402
                  PICKED, target_file, target_period, target_title)

RESULTS = RESEARCH_DIR / "results"


def part_target(in_dir: Path, name: str, period: int, threshold: str,
                kind: str = "ema", leg: str = DEFAULT_LEG
                ) -> tuple[np.ndarray, np.ndarray]:
    """Час і ціль однієї вибірки; події без цілі відкидаються."""
    dataset = klass.load(in_dir / f"{name}.npz")
    targets = zigzag_targets.load(in_dir / target_file(name, kind, leg))
    if not np.array_equal(dataset.timestamp, targets.timestamp):
        raise SystemExit(f"{name}: фічі й цілі зібрані на різних подіях")
    y = targets.column(period, threshold)
    good = np.isfinite(y)
    return dataset.timestamp[good].astype(np.int64), y[good]


def nearest(stamps: np.ndarray, values: np.ndarray, train_t: np.ndarray,
            train_y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Розрив до найближчої події train і її ціль."""
    index = np.searchsorted(train_t, stamps).clip(1, len(train_t) - 1)
    left = np.abs(stamps - train_t[index - 1])
    right = np.abs(train_t[index] - stamps)
    choice = np.where(left <= right, index - 1, index)
    return np.minimum(left, right), train_y[choice]


def build(pair: str = "BTC_USDT", threshold: str = "0.8",
          root: Path | None = None, kind: str = "ema",
          leg: str = DEFAULT_LEG) -> dict:
    in_dir = (root or DATASET) / pair / "class210x4bema10x10x130"
    period = target_period(threshold, kind)
    parts = {name: part_target(in_dir, name, period, threshold, kind, leg)
             for name in PARTS}
    train_t, train_y = parts["train"]
    order = np.argsort(train_t, kind="stable")
    train_t, train_y = train_t[order], train_y[order]

    report = {
        "pair": pair,
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": target_title(threshold, kind, leg),
        "split": "випадкове перемішування подій (rules/scripts/split.py)",
        "event_seconds": 210,
        "events": {name: int(len(values)) for name, (_, values) in parts.items()},
        "parts": {},
    }
    for name in ("val", "test"):
        stamps, values = parts[name]
        gap, guess = nearest(stamps, values, train_t, train_y)
        report["parts"][name] = {
            "gap_seconds": {
                "median": int(np.median(gap)),
                "p90": int(np.percentile(gap, 90)),
                "share_one_event": round(float((gap <= 210).mean()), 4),
            },
            "neighbour_baseline": {
                "mae": round(float(np.abs(guess - values).mean()), 4),
                "sign_accuracy": round(
                    float((np.sign(guess) == np.sign(values)).mean()), 4),
            },
        }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--kind", default="ema", choices=KINDS,
                        help="ціль: ema — зігзаг на ЕМА ціни, "
                             "ind — незалежний зігзаг, ЕМА на нозі")
    parser.add_argument("--leg", default=DEFAULT_LEG, choices=LEGS,
                        help="чим нормована нога цілі")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target, kind=args.kind, leg=args.leg)
    args.out.mkdir(parents=True, exist_ok=True)
    tail = args.target.replace(".", "_")
    tag = args.kind if args.leg == DEFAULT_LEG else f"{args.kind}_{args.leg}"
    name = (f"neighbours_{tail}.json" if args.kind == "ema"
            else f"neighbours_{tag}_{tail}.json")
    path = args.out / name
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    for part, item in report["parts"].items():
        print(f"{part}: розрив до train {item['gap_seconds']['median']} c, "
              f"сусід дає MAE {item['neighbour_baseline']['mae']}, знак "
              f"{item['neighbour_baseline']['sign_accuracy']}")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
