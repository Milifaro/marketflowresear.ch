"""Навчання мережі на клас210х4бема10х10х130 → нормований зігзаг.

Дослідження: research/12-zigzag-net/
Правила: rules/03-models.md (Підбір даних для навчання, Правила навчання,
         Що логувати, Метрики)

Крок 1 порядку — **підбір технології**: кілька типів моделі на однакових
даних, однаковому seed і однаковому бюджеті навчання. Вибір іде за
метриками на `val`; `test` на цьому кроці не чіпається.

Ціль неперервна (`[-1, 1]`), тому основні метрики — регресійні (MAE,
RMSE, R², кореляція), а класифікаційні рахуються за знаком: «верхня
половина ноги» проти «нижньої».

Запуск:
    python3 research/12-zigzag-net/scripts/train.py --target 0.8 --model all
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from correlation import pearson  # noqa: E402
from data import PICKED, Scaler, load  # noqa: E402

PERIODS, FEATURES = 13, 4
SEED = 0

# Вагова MSE: подія тим дорожча, чим далі вона від середини ноги.
#
#     loss = Σ w·(p − y)² / Σ w,      w = 1 + α·|y|^β
#
# `α = 0` дає рівно MSE, тому старі прогони лишаються порівнюваними.
# Вага рахується **з цілі**, не з прогнозу: вона не веде модель у бік
# більшої відповіді, а тільки міняє ціну помилки на краях ноги. Сума
# ваг у знаменнику тримає лосс у шкалі MSE — інакше α міняв би ще й
# ефективну швидкість навчання.
DEFAULT_ALPHA = 0.0
DEFAULT_BETA = 1.0


def weights(true, alpha: float = DEFAULT_ALPHA, beta: float = DEFAULT_BETA):
    """Вага події: `w = 1 + α·|y|^β`. Працює і на torch, і на numpy."""
    if alpha == 0:
        return None
    return 1.0 + alpha * abs(true) ** beta


def wmse(pred, true, alpha: float = DEFAULT_ALPHA,
         beta: float = DEFAULT_BETA):
    """Зважений MSE, нормований на суму ваг; при `α = 0` — звичайний MSE."""
    error = (pred - true) ** 2
    w = weights(true, alpha, beta)
    return error.mean() if w is None else (w * error).sum() / w.sum()


def loss_name(alpha: float, beta: float) -> str:
    return "MSE" if alpha == 0 else f"WMSE α{alpha} β{beta}"


def device_name() -> str:
    """Відеопамʼять, якщо є; інакше процесор (rules/03 → Правила навчання)."""
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def flat(out, outputs: int):
    """Вихід голови: один стовпчик стає вектором, кілька лишаються матрицею.

    `outputs = 1` — звичайна регресія, форма `(N,)`. Більше одного —
    пінбол по квантилях: форма `(N, outputs)`, по стовпчику на квантиль
    (`losses.py`).
    """
    return out.squeeze(1) if outputs == 1 else out


class Linear(nn.Module):
    """Базова лінія: одна лінійна комбінація 52 значень."""

    def __init__(self, outputs=1):
        super().__init__()
        self.outputs = outputs
        self.net = nn.Linear(PERIODS * FEATURES, outputs)

    def forward(self, x):
        return flat(self.net(x.flatten(1)), self.outputs)


class Mlp(nn.Module):
    """Повнозвʼязна: 52 → 64 → 32 → 1."""

    def __init__(self, hidden=(64, 32), dropout=0.1, outputs=1):
        super().__init__()
        self.outputs = outputs
        sizes = [PERIODS * FEATURES, *hidden]
        layers = []
        for a, b in zip(sizes, sizes[1:]):
            layers += [nn.Linear(a, b), nn.ReLU(), nn.Dropout(dropout)]
        layers.append(nn.Linear(sizes[-1], outputs))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return flat(self.net(x.flatten(1)), self.outputs)


class Gru(nn.Module):
    """Рекурентна по осі періодів: 13 кроків по 4 фічі."""

    def __init__(self, hidden=32, layers=1, dropout=0.0, outputs=1):
        super().__init__()
        self.outputs = outputs
        self.rnn = nn.GRU(FEATURES, hidden, num_layers=layers,
                          batch_first=True, dropout=dropout)
        self.head = nn.Linear(hidden, outputs)

    def forward(self, x):
        out, _ = self.rnn(x)
        return flat(self.head(out[:, -1]), self.outputs)


class Cnn(nn.Module):
    """Згорткова по осі періодів: ядро 3, два шари."""

    def __init__(self, channels=32, dropout=0.1, outputs=1):
        super().__init__()
        self.outputs = outputs
        self.net = nn.Sequential(
            nn.Conv1d(FEATURES, channels, 3, padding=1), nn.ReLU(),
            nn.Conv1d(channels, channels, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.head = nn.Sequential(nn.Dropout(dropout),
                                  nn.Linear(channels, outputs))

    def forward(self, x):
        out = self.net(x.transpose(1, 2)).squeeze(2)
        return flat(self.head(out), self.outputs)


class Dilated(nn.Module):
    """Розріджена (dilated) згортка по осі періодів: ядро 3, кроки 1-2-4.

    Звичайна згортка ядром 3 за два шари бачить 5 періодів із 13. Тут
    третій шар іде з кроком 4, і поле зору стає 15 — уся вісь ЕМА від 10
    до 130 разом, без пулінгу й без зайвих параметрів.
    """

    def __init__(self, channels=32, dropout=0.1, dilations=(1, 2, 4),
                 outputs=1):
        super().__init__()
        self.outputs = outputs
        layers, width = [], FEATURES
        for step in dilations:
            layers += [nn.Conv1d(width, channels, 3, padding=step,
                                 dilation=step), nn.ReLU()]
            width = channels
        self.net = nn.Sequential(*layers, nn.AdaptiveAvgPool1d(1))
        self.head = nn.Sequential(nn.Dropout(dropout),
                                  nn.Linear(channels, outputs))

    def forward(self, x):
        out = self.net(x.transpose(1, 2)).squeeze(2)
        return flat(self.head(out), self.outputs)


class Transformer(nn.Module):
    """Енкодер уваги по осі періодів: 13 кроків по 4 фічі.

    Крок послідовності — один період ЕМА (10 … 130), тому увага дивиться,
    які масштаби згладжування важливі для цієї події. Позиція періоду
    вчиться окремим параметром: порядок періодів має значення.

    `width` має ділитись на `heads` — інакше багатоголова увага не
    розкладається.
    """

    def __init__(self, width=32, heads=4, layers=2, dropout=0.1, outputs=1):
        super().__init__()
        if width % heads:
            raise ValueError("width має ділитись на heads")
        self.outputs = outputs
        self.into = nn.Linear(FEATURES, width)
        self.place = nn.Parameter(torch.zeros(1, PERIODS, width))
        layer = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=width * 4,
            dropout=dropout, batch_first=True, norm_first=True)
        self.net = nn.TransformerEncoder(layer, num_layers=layers,
                                         enable_nested_tensor=False)
        self.head = nn.Linear(width, outputs)

    def forward(self, x):
        out = self.net(self.into(x) + self.place)
        return flat(self.head(out.mean(dim=1)), self.outputs)


MODELS = {"linear": Linear, "mlp": Mlp, "gru": Gru, "cnn": Cnn,
          "dilated": Dilated, "transformer": Transformer}

# Крок 2 стандарту: невеликий грід з великим кроком.
# Батч фіксований (256) — міняємо по одному сімейству параметрів за раз.
COARSE = [{"hidden": hidden, "dropout": dropout, "lr": lr}
          for hidden in ((32, 16), (64, 32), (128, 64), (256, 128))
          for dropout in (0.0, 0.1, 0.2)
          for lr in (3e-4, 1e-3)]

# Крок 5 стандарту: грід-пошук в околі кращого з великого гріду
# (256→128, dropout 0.1, lr 1e-3). Оскільки кращою виявилась найширша
# конфігурація сітки, окіл розширений угору: ширші шари й третій шар.
FINE = [{"hidden": hidden, "dropout": dropout, "lr": lr}
        for hidden in ((256, 128), (384, 192), (512, 256),
                       (256, 128, 64), (512, 256, 128))
        for dropout in (0.05, 0.1, 0.15)
        for lr in (5e-4, 1e-3)]

GRIDS = {"coarse": COARSE, "fine": FINE}

def model_params(config: dict) -> tuple[str, dict]:
    """Імʼя моделі й параметри з конфігурації прогону.

    Форм дві: старі прогони писали `{hidden, dropout, lr}` для mlp, нові —
    `{model, params, lr}` для будь-якої моделі.
    """
    if "params" in config:
        params = dict(config["params"])
        if "hidden" in params:
            params["hidden"] = tuple(params["hidden"])
        return config.get("model", "mlp"), params
    return "mlp", {"hidden": tuple(config["hidden"]),
                   "dropout": config["dropout"]}


def load_saved(report: dict, root: Path) -> tuple[nn.Module, Scaler]:
    """Збережена модель прогону і скейлер, яким її вчили.

    Скейлер читається з `scaler.npz` тим самим `data.Scaler` — і z-score,
    і квантиль лежать в одному форматі.
    """
    folder = Path(root) / report["model_path"]
    name, params = model_params(report["config"])
    model = MODELS[name](**params)
    model.load_state_dict(torch.load(folder / "model.pt", map_location="cpu"))
    model.eval()
    return model, Scaler.load(folder / "scaler.npz")


def number(value: float, digits: int = 4):
    """Число для JSON: NaN і нескінченність стають `null`.

    `NaN` у JSON недопустимий — браузер такий файл не читає. Кореляція
    константного прогнозу невизначена, і це чесно показується як `null`,
    а не як число.
    """
    value = float(value)
    return round(value, digits) if np.isfinite(value) else None


# Край ноги: з якого |y| подія вважається такою, де ціль біля ±1.
EDGE = 0.5


def edge_metrics(true: np.ndarray, pred: np.ndarray,
                 edge: float = EDGE) -> dict:
    """Що робиться на краях ноги — там, де ціль біля −1 і +1.

    Загальний MAE рахується по всіх подіях, а більшість із них сидить у
    середині ноги, де відповідь «близько нуля» і дешева, і правильна.
    Тому окремо міряється те, що насправді потрібно:

        mae_up / mae_down    MAE на подіях, де ціль вище +0.5 і нижче −0.5
        mae_edge             обидва краї разом
        reach_up / reach_down   середня видача на цих подіях — наскільки
                                вона взагалі доходить до ±1
        edge_share           яка частка подій вважається краєм
    """
    true = np.asarray(true, dtype=float)
    pred = np.asarray(pred, dtype=float)
    up = true >= edge
    down = true <= -edge
    both = up | down

    def mae(mask):
        return number(np.abs(pred[mask] - true[mask]).mean()) \
            if mask.any() else None

    def reach(mask):
        return number(pred[mask].mean()) if mask.any() else None

    return {
        "edge": edge,
        "edge_share": number(both.mean()),
        "mae_up": mae(up),
        "mae_down": mae(down),
        "mae_edge": mae(both),
        "reach_up": reach(up),
        "reach_down": reach(down),
        "true_up": reach_of(true, up),
        "true_down": reach_of(true, down),
    }


def reach_of(values: np.ndarray, mask: np.ndarray):
    return number(np.asarray(values, dtype=float)[mask].mean()) \
        if mask.any() else None


def metrics(true: np.ndarray, pred: np.ndarray) -> dict:
    """Регресійні метрики, край ноги і класифікаційні за знаком."""
    true = np.asarray(true, dtype=float)
    pred = np.asarray(pred, dtype=float)
    error = pred - true
    variance = true.var()
    hit = np.sign(pred) == np.sign(true)
    positive = true > 0
    guessed = pred > 0
    true_positive = int((positive & guessed).sum())
    precision = true_positive / max(int(guessed.sum()), 1)
    recall = true_positive / max(int(positive.sum()), 1)
    return {
        "mae": number(np.abs(error).mean()),
        "rmse": number(np.sqrt((error ** 2).mean())),
        "r2": number(1 - (error ** 2).mean() / variance) if variance else None,
        "pearson": number(pearson(true, pred)),
        "sign_accuracy": number(hit.mean()),
        "precision": number(precision),
        "recall": number(recall),
        "f1": number(2 * precision * recall / max(precision + recall, 1e-9)),
        **edge_metrics(true, pred),
    }


def predict(model: nn.Module, x: torch.Tensor, batch: int = 4096) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for start in range(0, len(x), batch):
            out.append(model(x[start:start + batch]).cpu().numpy())
    return np.concatenate(out) if out else np.empty(0)


def run(name: str, parts: dict, epochs: int = 80, batch: int = 256,
        lr: float = 1e-3, patience: int = 10, seed: int = SEED,
        device: str | None = None, params: dict | None = None,
        alpha: float = DEFAULT_ALPHA, beta: float = DEFAULT_BETA,
        loss=None, point=None, loss_title: str | None = None,
        factory=None, log=print) -> dict:
    """Один прогін: навчання з ранньою зупинкою по val.

    `alpha` і `beta` — ваги WMSE. Та сама вага йде і в лосс ранньої
    зупинки: інакше зупинка вибирала б під одну функцію, а вчили б під
    іншу.

    `factory` заміняє пошук у `MODELS` своїм класом моделі: так інше
    дослідження підставляє власну родину, не додаючи її в загальний
    перелік.

    `loss` заміняє WMSE своєю функцією `(pred, true) -> число`
    (`losses.py`); вона має рахуватись і на torch, і на numpy — тим самим
    виразом іде і навчання, і рання зупинка. `point` зводить видачу
    моделі до одного числа на подію, коли виходів кілька (пінбол).
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = device or device_name()
    params = dict(params or {})
    model = (factory or MODELS[name])(**params).to(device)

    tensors = {part: (torch.tensor(data.x, device=device),
                      torch.tensor(data.y, device=device))
               for part, data in parts.items()}
    x_train, y_train = tensors["train"]
    optimiser = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = loss or (lambda pred, true: wmse(pred, true, alpha, beta))
    point_fn = point or (lambda pred: pred)

    best = {"loss": float("inf"), "epoch": 0, "state": None}
    started = time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        order = torch.randperm(len(x_train), device=device)
        for start in range(0, len(order), batch):
            index = order[start:start + batch]
            optimiser.zero_grad()
            loss = loss_fn(model(x_train[index]), y_train[index])
            loss.backward()
            optimiser.step()

        val_pred = predict(model, tensors["val"][0])
        val_loss = float(loss_fn(val_pred, parts["val"].y))
        if val_loss < best["loss"] - 1e-6:
            best = {"loss": val_loss, "epoch": epoch,
                    "state": {k: v.detach().clone()
                              for k, v in model.state_dict().items()}}
        elif epoch - best["epoch"] >= patience:
            break
        if epoch % 10 == 0 or epoch == 1:
            log(f"      {name}: епоха {epoch}, val лосс {val_loss:.5f}")

    model.load_state_dict(best["state"])
    elapsed = time.time() - started
    result = {
        "model": name,
        "parameters": int(sum(p.numel() for p in model.parameters())),
        "hyper": {"epochs": epochs, "batch": batch, "lr": lr,
                  "patience": patience, "seed": seed,
                  "loss": loss_title or loss_name(alpha, beta),
                  "alpha": alpha, "beta": beta,
                  "optimiser": "Adam", **params},
        "best_epoch": best["epoch"],
        "device": device,
        "seconds": round(elapsed, 1),
        # test на кроці підбору не чіпається (rules/03 → Типи мереж)
        "metrics": {part: metrics(parts[part].y,
                                  point_fn(predict(model, tensors[part][0])))
                    for part in ("train", "val")},
    }
    log(f"   {name}: val r {result['metrics']['val']['pearson']}, "
        f"MAE {result['metrics']['val']['mae']}, "
        f"знак {result['metrics']['val']['sign_accuracy']}, "
        f"епоха {best['epoch']}, {result['seconds']} с")
    return result, model


def confusion(true: np.ndarray, pred: np.ndarray) -> dict:
    """Матриця помилок за знаком ноги: низ (<0) проти верху (>0)."""
    positive_true = np.asarray(true) > 0
    positive_pred = np.asarray(pred) > 0
    return {
        "labels": ["низ ноги (−)", "верх ноги (+)"],
        "matrix": [
            [int((~positive_true & ~positive_pred).sum()),
             int((~positive_true & positive_pred).sum())],
            [int((positive_true & ~positive_pred).sum()),
             int((positive_true & positive_pred).sum())],
        ],
    }


def distribution(values: np.ndarray, bins: int = 40,
                 span: tuple[float, float] = (-1.0, 1.0)) -> dict:
    """Гістограма ряду в межах цілі."""
    counts, edges = np.histogram(np.asarray(values, dtype=float), bins=bins,
                                 range=span)
    return {"from": span[0], "to": span[1],
            "counts": [int(v) for v in counts],
            "mean": round(float(np.mean(values)), 4),
            "std": round(float(np.std(values)), 4)}


def sweep(name: str, parts: dict, configs: list[dict], epochs: int,
          seed: int = SEED, log=print) -> list[dict]:
    """Прогін по сітці параметрів; повертає результати, кращий перший."""
    runs = []
    for index, config in enumerate(configs, 1):
        params = {key: value for key, value in config.items() if key != "lr"}
        batch = params.pop("batch", 256)
        log(f"[{index}/{len(configs)}] {name} {config}")
        result, _ = run(name, parts, epochs=epochs, batch=batch,
                        lr=config.get("lr", 1e-3), seed=seed, params=params,
                        log=lambda *_: None)
        result["config"] = config
        runs.append(result)
        log(f"      val r {result['metrics']['val']['pearson']}, "
            f"R2 {result['metrics']['val']['r2']}, "
            f"епоха {result['best_epoch']}, {result['seconds']} с")
    runs.sort(key=lambda item: -abs(item["metrics"]["val"]["pearson"]))
    return runs


def best_config(out: Path, target: str, model: str) -> dict:
    """Конфігурація фінальної моделі: кращий рядок дрібного гріду."""
    name = f"grid_fine_{target.replace('.', '_')}.json"
    path = out / name
    if not path.exists():
        raise SystemExit(f"немає {path}: спершу --grid fine")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("model") != model:
        raise SystemExit(f"грід рахувався для {payload.get('model')}, не {model}")
    return payload["best"]


def final(model_name: str, parts: dict, config: dict, epochs: int, seed: int,
          scaler, report: dict, out: Path, models_dir: Path,
          target: str) -> dict:
    """Крок 6 стандарту: фінальна тестова модель і повна оцінка на test."""
    params = {key: value for key, value in config.items() if key != "lr"}
    batch = params.pop("batch", 256)
    result, model = run(model_name, parts, epochs=epochs, batch=batch,
                        lr=config.get("lr", 1e-3), seed=seed, params=params)
    device = result["device"]
    predictions = {name: predict(model, torch.tensor(part.x, device=device))
                   for name, part in parts.items()}
    result["metrics"] = {name: metrics(part.y, predictions[name])
                         for name, part in parts.items()}

    test = parts["test"]
    version = f"{model_name}_{target.replace('.', '_')}_v1"
    folder = models_dir / version
    folder.mkdir(parents=True, exist_ok=True)
    torch.save({k: v.cpu() for k, v in model.state_dict().items()},
               folder / "model.pt")
    if scaler is not None:
        scaler.save(folder / "scaler.npz")

    payload = {
        **report,
        "step": "фінальна тестова модель",
        "model": model_name,
        "config": config,
        "run": result,
        "model_path": str(folder.relative_to(PROJECT_ROOT)),
        "confusion": confusion(test.y, predictions["test"]),
        "distribution": {
            "pred": distribution(predictions["test"]),
            "true": distribution(test.y),
        },
    }
    out.mkdir(parents=True, exist_ok=True)
    name = f"final_{target.replace('.', '_')}.json"
    (out / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                            encoding="utf-8")
    test_metrics = result["metrics"]["test"]
    print(f"[3/3] test: r {test_metrics['pearson']}, R2 {test_metrics['r2']}, "
          f"знак {test_metrics['sign_accuracy']}, MAE {test_metrics['mae']}")
    print(f"      модель {payload['model_path']}, записано в {out / name}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--model", default="all",
                        choices=("all", *MODELS))
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--grid", default=None, choices=tuple(GRIDS),
                        help="coarse — грід з великим кроком (крок 2), "
                             "fine — грід в околі кращого (крок 5)")
    parser.add_argument("--final", action="store_true",
                        help="крок 6: фінальна тестова модель і оцінка на test")
    parser.add_argument("--scale", default="zscore",
                        choices=("zscore", "none"),
                        help="z-score на train чи фічі як є")
    parser.add_argument("--out", type=Path, default=RESEARCH_DIR / "results")
    args = parser.parse_args()

    parts, scaler, report = load(args.pair, args.target,
                                 scale=args.scale == "zscore")
    print(f"[1/2] ціль: {report['target']} · події "
          f"train {report['events']['train']}, val {report['events']['val']}")

    if args.final:
        model = args.model if args.model != "all" else "mlp"
        chosen = best_config(args.out, args.target, model)
        print(f"[2/3] конфігурація з гріду: {chosen}")
        final(model, parts, chosen, args.epochs, args.seed, scaler, report,
              args.out, RESEARCH_DIR / "models", args.target)
        return

    if args.grid:
        model = args.model if args.model != "all" else "mlp"
        configs = GRIDS[args.grid]
        runs = sweep(model, parts, configs, args.epochs, args.seed)
        payload = {**report, "device": device_name(), "model": model,
                   "grid": args.grid, "configs": len(configs), "runs": runs,
                   "best": runs[0]["config"]}
        args.out.mkdir(parents=True, exist_ok=True)
        name = f"grid_{args.grid}_{args.target.replace('.', '_')}.json"
        (args.out / name).write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        best = runs[0]
        print(f"[2/2] найкращий: {best['config']} · val r "
              f"{best['metrics']['val']['pearson']}, R2 "
              f"{best['metrics']['val']['r2']} · записано в {args.out / name}")
        return

    names = list(MODELS) if args.model == "all" else [args.model]
    runs = []
    for name in names:
        result, _ = run(name, parts, epochs=args.epochs, seed=args.seed)
        runs.append(result)

    runs.sort(key=lambda item: -abs(item["metrics"]["val"]["pearson"]))
    payload = {**report, "device": device_name(), "runs": runs,
               "best": runs[0]["model"]}
    args.out.mkdir(parents=True, exist_ok=True)
    suffix = "" if args.scale == "zscore" else "_noscale"
    name = f"tech_choice_{args.target.replace('.', '_')}{suffix}.json"
    (args.out / name).write_text(json.dumps(payload, ensure_ascii=False,
                                            indent=2), encoding="utf-8")
    print(f"[2/2] найкраща на val: {payload['best']}, записано в {args.out / name}")


if __name__ == "__main__":
    main()
