"""Walk-forward: розбиття по часу замість перемішування подій.

Дослідження: research/12-zigzag-net/ (етап 7)
Правила: rules/03-models.md → Розбиття даних → Розбиття по часу

Етап 6 показав, що при випадковому розбитті подія з test має в train
сусіда за 210 с, і test міряє інтерполяцію, а не прогноз. Тут вибірки
йдуть суцільними відрізками часу з проміжками по півотах
(`rules/scripts/split_time.py`), і таких вікон кілька.

Кожне вікно міряється трьома прогнозами на своєму test:

    модель    — та сама конфігурація, що виграла грід етапу 4
    константа — середнє цілі по train (нічого не вчить)
    сусід     — ціль найближчої за часом події train (діагностика витоку)

Разом із метриками рахується **кількість ніг зігзага** у кожному test —
це і є розмір вибірки в незалежних одиницях.

Вихід: results/walk_forward_0_8.json

Запуск:
    python3 research/12-zigzag-net/scripts/walk_forward.py --target 0.8
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import split_time  # noqa: E402
import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from data import (DATASET, DEFAULT_LEG, KINDS, LEGS, PARTS,  # noqa: E402
                  PICKED, SCALES, Part, Scaler, fit_scaler, target_file,
                  target_period, target_title)
from train import (DEFAULT_ALPHA, DEFAULT_BETA, MODELS,  # noqa: E402
                   confusion, distribution, loss_name, metrics, predict, run)
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MIN_GAP = max(klass.PERIODS)     # глибина фічі: найдовша ЕМА, 130 подій

# Порядок кроків — стандарт rules/03-models.md → Типи мереж → Тестові.
# Підбір робиться **під розбиттям по часу** й тільки по val: конфігурація,
# обрана на перемішаному розбитті, сюди не переноситься.

# Ваги WMSE на кроках 1-3: фіксовані, щоб порівнювались сімейства й ручки,
# а не ваги. Рухати їх починає крок 5 (окіл), де вони стають такими самими
# ручками, як lr (train.py → WMSE).
WMSE_ALPHA = 3.0
WMSE_BETA = 2.0

# Крок 1 стандарту: підбір технології. Однакові дані й бюджет, параметри
# за замовчуванням кожного типу — порівнюються сімейства, не налаштування.
TECH = [
    {"model": "linear", "params": {}, "lr": 1e-3},
    {"model": "mlp", "params": {"hidden": (64, 32), "dropout": 0.1}, "lr": 1e-3},
    {"model": "gru", "params": {"hidden": 32, "layers": 1}, "lr": 1e-3},
    {"model": "cnn", "params": {"channels": 32, "dropout": 0.1}, "lr": 1e-3},
    {"model": "dilated", "params": {"channels": 32, "dropout": 0.1}, "lr": 1e-3},
    {"model": "transformer",
     "params": {"width": 32, "heads": 4, "layers": 2, "dropout": 0.1},
     "lr": 1e-3},
]

# Крок 2 стандарту: невеликий грід з великим кроком. Сітка своя на кожен
# тип — у різних сімейств різні ручки.
COARSE = {
    "linear": [{"model": "linear", "params": {}, "lr": lr}
               for lr in (1e-4, 3e-4, 1e-3, 3e-3)],
    "mlp": [{"model": "mlp",
             "params": {"hidden": hidden, "dropout": dropout}, "lr": lr}
            for hidden in ((16,), (32, 16), (64, 32), (128, 64))
            for dropout in (0.1, 0.3)
            for lr in (3e-4, 1e-3)],
    "gru": [{"model": "gru",
             "params": {"hidden": hidden, "layers": layers}, "lr": lr}
            for hidden in (16, 32, 64)
            for layers in (1, 2)
            for lr in (3e-4, 1e-3)],
    "cnn": [{"model": "cnn",
             "params": {"channels": channels, "dropout": dropout}, "lr": lr}
            for channels in (16, 32, 64)
            for dropout in (0.1, 0.3)
            for lr in (3e-4, 1e-3)],
    "dilated": [{"model": "dilated",
                 "params": {"channels": channels, "dropout": dropout}, "lr": lr}
                for channels in (16, 32, 64)
                for dropout in (0.1, 0.3)
                for lr in (3e-4, 1e-3)],
    "transformer": [{"model": "transformer",
                     "params": {"width": width, "heads": 4, "layers": layers,
                                "dropout": dropout}, "lr": lr}
                    for width in (16, 32, 64)
                    for layers in (1, 2)
                    for dropout in (0.1, 0.3)
                    for lr in (3e-4, 1e-3)],
}

# Крок 3 стандарту: тривалість навчання. Рання зупинка вже стоїть, тому
# міряється саме її терпіння — скільки епох чекати після кращої.
PATIENCE = (3, 10, 30)


def human(value: int) -> str:
    return dt.datetime.fromtimestamp(int(value), dt.timezone.utc).strftime(
        "%Y-%m-%d %H:%M")


def merged(pair: str, threshold: str, period: int,
           root: Path | None = None, kind: str = "ema",
           leg: str = DEFAULT_LEG
           ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Увесь датасет одним рядом за часом: фічі, ціль, час, ціна."""
    in_dir = (root or DATASET) / pair / "class210x4bema10x10x130"
    x, y, stamps, price = [], [], [], []
    for name in PARTS:
        dataset = klass.load(in_dir / f"{name}.npz")
        targets = zigzag_targets.load(in_dir / target_file(name, kind, leg))
        if not np.array_equal(dataset.timestamp, targets.timestamp):
            raise SystemExit(f"{name}: фічі й цілі зібрані на різних подіях")
        x.append(np.asarray(dataset.x, dtype=np.float32))
        y.append(targets.column(period, threshold))
        stamps.append(dataset.timestamp.astype(np.int64))
        price.append(np.asarray(dataset.price_open, dtype=float))
    x = np.concatenate(x)
    y = np.concatenate(y)
    stamps = np.concatenate(stamps)
    price = np.concatenate(price)
    order = np.argsort(stamps, kind="stable")
    return x[order], y[order], stamps[order], price[order]


def pivot_index(price: np.ndarray, period: int, threshold: str,
                kind: str = "ema") -> np.ndarray:
    """Індекси півотів того самого зігзага, з якого зроблена ціль.

    `ema` — зігзаг на ема_p(ціна), `ind` — незалежний зігзаг по самій
    ціні (згладжується вже нормована нога, а не ціна).
    """
    series = price if kind == "ind" else ema(price, period)
    marks = zigzag(series, THRESHOLDS[threshold])
    return np.array([pivot.index for pivot in marks], dtype=int)


def neighbour_guess(train_t: np.ndarray, train_y: np.ndarray,
                    stamps: np.ndarray) -> np.ndarray:
    """Ціль найближчої за часом події train — прогноз без навчання."""
    index = np.searchsorted(train_t, stamps).clip(1, len(train_t) - 1)
    left = np.abs(stamps - train_t[index - 1])
    right = np.abs(train_t[index] - stamps)
    return train_y[np.where(left <= right, index - 1, index)]


def fold_parts(fold, x: np.ndarray, y: np.ndarray,
               scale: str = "zscore") -> tuple[dict, Scaler]:
    """Вибірки вікна зі скейлером, порахованим на його train."""
    parts = {}
    for name, index in (("train", fold.train), ("val", fold.val),
                        ("test", fold.test)):
        good = index[np.isfinite(y[index])
                     & np.isfinite(x[index]).all(axis=(1, 2))]
        parts[name] = Part(x=x[good], y=y[good].astype(np.float32),
                           timestamp=good, price_open=good, price_close=good)
    scaler = fit_scaler(parts["train"].x, scale)
    for part in parts.values():
        part.x = scaler.apply(part.x)
    return parts, scaler


def train_fold(fold, parts: dict, stamps: np.ndarray, pivots: np.ndarray,
               config: dict, epochs: int, patience: int = 10) -> dict:
    """Один прогін на одному вікні: val для вибору, test — тільки міряється."""
    import torch

    run_report, model = run(config["model"], parts, epochs=epochs,
                            lr=config["lr"], params=dict(config["params"]),
                            patience=patience,
                            alpha=config.get("alpha", DEFAULT_ALPHA),
                            beta=config.get("beta", DEFAULT_BETA),
                            log=lambda *args: None)
    test = parts["test"]
    pred = predict(model, torch.tensor(test.x, device=run_report["device"]))
    train_t = stamps[parts["train"].timestamp]
    guess = neighbour_guess(train_t, parts["train"].y, stamps[test.timestamp])
    constant = np.full(len(test.y), float(parts["train"].y.mean()))
    return {
        "fold": fold.index + 1,
        "sizes": fold.sizes(),
        "with_target": {name: len(part) for name, part in parts.items()},
        "dropped": fold.dropped,
        "test_period": {
            "from_utc": human(stamps[fold.test[0]]),
            "to_utc": human(stamps[fold.test[-1]]),
            "days": round(float(stamps[fold.test[-1]]
                                - stamps[fold.test[0]]) / 86400, 1),
        },
        "test_legs": split_time.legs_between(pivots, int(fold.test[0]),
                                             int(fold.test[-1]) + 1),
        "best_epoch": run_report["best_epoch"],
        "seconds": run_report["seconds"],
        "parameters": run_report["parameters"],
        "val": run_report["metrics"]["val"],
        "train": run_report["metrics"]["train"],
        "model": metrics(test.y, pred),
        "constant": metrics(test.y, constant),
        "neighbour": metrics(test.y, guess),
        # WMSE робиться заради амплітуди, тому розкид іде в кожен звіт
        "spread": {"pred": round(float(np.std(pred)), 4),
                   "true": round(float(np.std(test.y)), 4)},
    }


def build(pair: str = "BTC_USDT", threshold: str = "0.8", folds: int = 5,
          first_train: float = 0.5, epochs: int = 400,
          candidates: list[dict] | None = None, patience: tuple = (10,),
          step: str = "grid", root: Path | None = None, kind: str = "ema",
          scale: str = "zscore", leg: str = DEFAULT_LEG, log=print) -> dict:
    """Один крок стандарту: перелік кандидатів на всіх вікнах, вибір по val."""
    period = target_period(threshold, kind)
    x, y, stamps, price = merged(pair, threshold, period, root, kind, leg)
    pivots = pivot_index(price, period, threshold, kind)
    log(f"[1/3] датасет: {len(x)} подій, півотів {len(pivots)}, "
        f"ніг {max(len(pivots) - 1, 0)}")

    windows = split_time.walk_forward(len(x), pivots, folds=folds,
                                      first_train=first_train, min_gap=MIN_GAP)
    prepared = [fold_parts(fold, x, y, scale)[0] for fold in windows]
    log(f"[2/3] вікон: {len(windows)}, проміжок не менший за {MIN_GAP} подій")

    candidates = list(candidates or TECH)
    pairs = [(candidate, wait) for candidate in candidates for wait in patience]
    grid = []
    for number, (candidate, wait) in enumerate(pairs, 1):
        runs = [train_fold(fold, parts, stamps, pivots, candidate, epochs, wait)
                for fold, parts in zip(windows, prepared)]
        grid.append({
            "config": candidate,
            "patience": wait,
            "parameters": runs[0]["parameters"],
            "val": {key: round(float(np.mean([r["val"][key] for r in runs])), 4)
                    for key in ("mae", "pearson", "sign_accuracy")},
            "gap": round(float(np.mean([r["train"]["pearson"] - r["val"]["pearson"]
                                        for r in runs])), 4),
            "spread": round(float(np.mean([r["spread"]["pred"] / r["spread"]["true"]
                                           for r in runs])), 4),
            "best_epoch": [r["best_epoch"] for r in runs],
            "seconds": round(sum(r["seconds"] for r in runs), 1),
            "runs": runs,
        })
        log(f"      {number}/{len(pairs)} {candidate['model']} "
            f"{candidate['params']} lr {candidate['lr']} "
            f"α {candidate.get('alpha', DEFAULT_ALPHA)} "
            f"β {candidate.get('beta', DEFAULT_BETA)} терпіння {wait}: "
            f"val MAE {grid[-1]['val']['mae']}, "
            f"знак {grid[-1]['val']['sign_accuracy']}, "
            f"σ {grid[-1]['spread']} від цілі, {grid[-1]['seconds']} с")

    # Вибір — тільки по val, середнім по вікнах; test у виборі не бере участі
    grid.sort(key=lambda item: item["val"]["mae"])
    best = grid[0]
    config = best["config"]

    report = {
        "step": step,
        "candidates": len(pairs),
        "patience": best["patience"],
        "pair": pair,
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": target_title(threshold, kind, leg),
        "scale": scale,
        "split": "по часу, суцільними відрізками (rules/scripts/split_time.py)",
        "min_gap_events": MIN_GAP,
        "min_gap_rule": "максимум із глибини фічі (ема130) і цілої ноги зігзага",
        "model": config["model"],
        "config": config,
        "loss": loss_name(config.get("alpha", DEFAULT_ALPHA),
                          config.get("beta", DEFAULT_BETA)),
        "grid": [{"config": item["config"], "patience": item["patience"],
                  "parameters": item["parameters"], "val": item["val"],
                  "gap": item["gap"], "spread": item["spread"],
                  "seconds": item["seconds"],
                  "best_epoch": item["best_epoch"]} for item in grid],
        "picked_by": "середній MAE на val по вікнах; test у виборі не бере участі",
        "epochs": epochs,
        "events": int(len(x)),
        "pivots": int(len(pivots)),
        "legs": int(max(len(pivots) - 1, 0)),
        "period": {"from": int(stamps[0]), "to": int(stamps[-1]),
                   "from_utc": human(stamps[0]), "to_utc": human(stamps[-1])},
        "folds": [],
    }

    for item in best["runs"]:
        report["folds"].append(item)
        log(f"      вікно {item['fold']}: test {item['test_period']['from_utc']}"
            f" … {item['test_period']['to_utc']} ({item['test_legs']} ніг), "
            f"модель знак {item['model']['sign_accuracy']}, "
            f"константа {item['constant']['sign_accuracy']}, "
            f"сусід {item['neighbour']['sign_accuracy']}")

    report["summary"] = summarise(report["folds"])
    log(f"[3/3] знак моделі {report['summary']['model']['sign_accuracy']['mean']}"
        f" ± {report['summary']['model']['sign_accuracy']['spread']}, "
        f"вікон краще за константу: {report['summary']['beats_constant']}"
        f"/{len(report['folds'])}")
    return report


def summarise(folds: list[dict]) -> dict:
    """Середнє й розкид по вікнах; одне вікно нічого не доводить."""
    def stat(source: str, key: str) -> dict:
        values = [fold[source][key] for fold in folds
                  if fold[source][key] is not None]
        if not values:
            return {"mean": None, "spread": None, "min": None, "max": None,
                    "values": []}
        return {"mean": round(float(np.mean(values)), 4),
                "spread": round(float(np.std(values)), 4),
                "min": round(float(np.min(values)), 4),
                "max": round(float(np.max(values)), 4),
                "values": [round(float(value), 4) for value in values]}

    legs = int(sum(fold["test_legs"] for fold in folds))
    sign = float(np.mean([fold["model"]["sign_accuracy"] for fold in folds
                          if fold["model"]["sign_accuracy"] is not None]))
    # Розмір вибірки — ноги, а не події: усередині ноги сусідні події
    # майже однакові. Похибка частки рахується з кількості ніг.
    error = 0.5 / np.sqrt(max(legs, 1))
    return {
        "folds": len(folds),
        "test_legs": legs,
        "independence": {
            "unit": "нога зігзага",
            "sign_se": round(float(error), 4),
            "sign_z": round(float((sign - 0.5) / error), 2),
            "note": "різниця менша за 2 se від 50% не відрізняється від монетки",
        },
        "model": {key: stat("model", key)
                  for key in ("mae", "r2", "pearson", "sign_accuracy")},
        "constant": {key: stat("constant", key)
                     for key in ("mae", "sign_accuracy")},
        "neighbour": {key: stat("neighbour", key)
                      for key in ("mae", "sign_accuracy")},
        "beats_constant": int(sum(fold["model"]["mae"] < fold["constant"]["mae"]
                                  for fold in folds)),
        "beats_neighbour": int(sum(fold["model"]["mae"] < fold["neighbour"]["mae"]
                                   for fold in folds)),
    }


def final(pair: str = "BTC_USDT", threshold: str = "0.8",
          test_fraction: float = split_time.TEST_FRACTION,
          epochs: int = 400, config: dict | None = None, patience: int = 10,
          root: Path | None = None, out: Path | None = None,
          kind: str = "ema", scale: str = "zscore", leg: str = DEFAULT_LEG,
          log=print) -> dict:
    """Фінальна модель на одному розбитті по часу: train | val | test підряд.

    Конфігурація береться та, що виграла walk-forward по val. Ваги й
    скейлер зберігаються — далі ними рахується видача на всьому датасеті
    і проміжний тест.
    """
    import torch

    out = out or RESULTS
    period = target_period(threshold, kind)
    x, y, stamps, price = merged(pair, threshold, period, root, kind, leg)
    pivots = pivot_index(price, period, threshold, kind)
    if config is None:
        picked = winner(out, threshold, "fine", kind, leg)
        config, patience = picked["config"], picked["patience"]
    log(f"[1/3] конфігурація: {config['model']} {config['params']} "
        f"lr {config['lr']}, терпіння {patience}")

    fold = split_time.chronological(len(x), pivots, test_fraction=test_fraction,
                                    min_gap=MIN_GAP)
    parts, scaler = fold_parts(fold, x, y, scale)
    log(f"[2/3] розбиття по часу: {fold.sizes()}, викинуто у проміжки "
        f"{fold.dropped}")

    run_report, model = run(config["model"], parts, epochs=epochs,
                            lr=config["lr"], params=dict(config["params"]),
                            patience=patience,
                            alpha=config.get("alpha", DEFAULT_ALPHA),
                            beta=config.get("beta", DEFAULT_BETA),
                            log=lambda *args: None)
    device = run_report["device"]
    pred = {name: predict(model, torch.tensor(part.x, device=device))
            for name, part in parts.items()}
    run_report["metrics"]["test"] = metrics(parts["test"].y, pred["test"])
    constant = np.full(len(parts["test"].y), float(parts["train"].y.mean()))

    folder = (out.parent / "models"
              / f"{config['model']}_{threshold.replace('.', '_')}"
                f"_{prefix(kind, leg, config.get('alpha', DEFAULT_ALPHA))}_v1")
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "model.pt")
    scaler.save(folder / "scaler.npz")

    report = {
        "pair": pair,
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": target_title(threshold, kind, leg),
        "scale": scale,
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "step": "фінальна модель на розбитті по часу",
        "model": config["model"],
        "config": config,
        "loss": loss_name(config.get("alpha", DEFAULT_ALPHA),
                          config.get("beta", DEFAULT_BETA)),
        "patience": patience,
        "events": {name: len(part) for name, part in parts.items()},
        "dropped": fold.dropped,
        "bounds": {name: {"from_utc": human(stamps[index[0]]),
                          "to_utc": human(stamps[index[-1]])}
                   for name, index in (("train", fold.train),
                                       ("val", fold.val), ("test", fold.test))},
        "test_legs": split_time.legs_between(pivots, int(fold.test[0]),
                                             int(fold.test[-1]) + 1),
        "run": run_report,
        "constant": metrics(parts["test"].y, constant),
        "confusion": confusion(parts["test"].y, pred["test"]),
        "distribution": {"pred": distribution(pred["test"]),
                         "true": distribution(parts["test"].y)},
        "model_path": str(folder.relative_to(PROJECT_ROOT)),
    }
    log(f"[3/3] test: знак {run_report['metrics']['test']['sign_accuracy']}, "
        f"MAE {run_report['metrics']['test']['mae']} проти константи "
        f"{report['constant']['mae']}, ніг у test {report['test_legs']}")
    return report


def prefix(kind: str, leg: str = DEFAULT_LEG,
           alpha: float = DEFAULT_ALPHA) -> str:
    """Префікс файлів прогону: ціль, нормалізація ноги і лосс.

    `time` — ЕМА ціни, `ind` — незалежний зігзаг з ногою `minmax`,
    `ind_<leg>` — той самий зігзаг з іншою нормалізацією ноги,
    `..._wmse` — навчання під ваговим MSE. Прогони різних цілей і різних
    лоссів не перезаписують файли один одного.
    """
    if kind == "ema":
        return "time"
    name = kind if leg == DEFAULT_LEG else f"{kind}_{leg}"
    return name if alpha == 0 else f"{name}_wmse"


def winner(out: Path, threshold: str, step: str, kind: str = "ema",
           leg: str = DEFAULT_LEG, alpha: float = DEFAULT_ALPHA) -> dict:
    """Конфігурація, що виграла попередній крок (за val)."""
    path = (out / f"{prefix(kind, leg, alpha)}_{step}"
                  f"_{threshold.replace('.', '_')}.json")
    if not path.exists():
        raise SystemExit(f"немає {path}: спершу пройдіть крок {step}")
    return json.loads(path.read_text(encoding="utf-8"))


def around(config: dict) -> list[dict]:
    """Окіл кращої конфігурації: крок 5 стандарту.

    Кожна ручка рухається на один щабель у обидва боки, решта стоїть —
    правило «один експеримент, одна зміна» (rules/03-models.md).
    """
    name, params, lr = config["model"], dict(config["params"]), config["lr"]
    alpha = config.get("alpha", DEFAULT_ALPHA)
    beta = config.get("beta", DEFAULT_BETA)
    rates = sorted({round(lr / 3, 6), lr, round(lr * 3, 6)})
    base = {"alpha": alpha, "beta": beta}
    out = [{"model": name, "params": dict(params), "lr": rate, **base}
           for rate in rates]
    # ваги WMSE рухаються по одній, решта стоїть — «один експеримент,
    # одна зміна». α = 0 лишається в сітці: це перевірка, чи потрібна вага
    # взагалі.
    for value in sorted({0.0, round(alpha / 3, 4), round(alpha * 3, 4)}):
        if value != alpha:
            out.append({"model": name, "params": dict(params), "lr": lr,
                        "alpha": value, "beta": beta})
    for value in (round(max(beta - 1, 0.5), 2), round(beta + 1, 2)):
        if value != beta and alpha > 0:
            out.append({"model": name, "params": dict(params), "lr": lr,
                        "alpha": alpha, "beta": value})
    steps = {
        "hidden": lambda v: [tuple(int(round(size * k)) for size in v)
                             for k in (0.5, 1.5)],
        "dropout": lambda v: [round(max(v - 0.1, 0.0), 2), round(v + 0.1, 2)],
        "layers": lambda v: [max(v - 1, 1), v + 1],
        "channels": lambda v: [max(v // 2, 4), v * 2],
        "width": lambda v: [max(v // 2, 8), v * 2],
    }
    for key, move in steps.items():
        if key not in params:
            continue
        for value in move(params[key]):
            if value == params[key]:
                continue
            changed = dict(params)
            changed[key] = value
            for rate in rates:
                out.append({"model": name, "params": changed, "lr": rate,
                            **base})
    seen, unique = set(), []
    for item in out:
        mark = (item["model"], str(sorted(item["params"].items())), item["lr"],
                item.get("alpha", DEFAULT_ALPHA), item.get("beta", DEFAULT_BETA))
        if mark not in seen:
            seen.add(mark)
            unique.append(item)
    return unique


STEPS = ("tech", "coarse", "epochs", "fine")


def centre_config(out: Path, threshold: str, kind: str = "ema",
                  leg: str = DEFAULT_LEG,
                  alpha: float = DEFAULT_ALPHA) -> dict:
    """Центр околу кроку 5.

    Окіл рухається: якщо кращим у ньому став край (наприклад найбільший lr),
    оптимум лежить далі, і крок повторюється навколо нового кращого. Тому
    центром береться результат уже пройденого околу, а вперше — кращий
    кроку 4.
    """
    path = (out / f"{prefix(kind, leg, alpha)}_fine"
                  f"_{threshold.replace('.', '_')}.json")
    return winner(out, threshold, "fine" if path.exists() else "epochs",
                  kind, leg, alpha)


def weighted(candidates: list[dict], alpha: float, beta: float) -> list[dict]:
    """Ставить ваги WMSE на кандидатів кроку; свої ваги не перебиває."""
    return [{**item, "alpha": item.get("alpha", alpha),
             "beta": item.get("beta", beta)} for item in candidates]


def candidates_for(step: str, out: Path, threshold: str, kind: str = "ema",
                   leg: str = DEFAULT_LEG, alpha: float = DEFAULT_ALPHA,
                   beta: float = DEFAULT_BETA) -> tuple[list, tuple]:
    """Кандидати кроку: кожен наступний крок стоїть на попередньому."""
    if step == "tech":
        return weighted(TECH, alpha, beta), (10,)
    if step == "coarse":
        best = winner(out, threshold, "tech", kind, leg, alpha)["config"]
        return weighted(COARSE[best["model"]], alpha, beta), (10,)
    if step == "epochs":
        return ([winner(out, threshold, "coarse", kind, leg,
                        alpha)["config"]], PATIENCE)
    best = centre_config(out, threshold, kind, leg, alpha)
    return around(best["config"]), (best["patience"],)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--step", choices=STEPS,
                        help="крок стандарту: технологія, грід, тривалість, окіл")
    parser.add_argument("--folds", type=int, default=split_time.FOLDS)
    parser.add_argument("--first-train", type=float,
                        default=split_time.FIRST_TRAIN)
    parser.add_argument("--epochs", type=int, default=400)
    parser.add_argument("--final", action="store_true",
                        help="фінальна модель на одному розбитті по часу")
    parser.add_argument("--kind", default="ema", choices=KINDS,
                        help="ціль: ema — зігзаг на ЕМА ціни, "
                             "ind — незалежний зігзаг, ЕМА на нозі")
    parser.add_argument("--scale", default="zscore",
                        choices=tuple(s for s in SCALES if s != "none"),
                        help="скейлер фіч на train")
    parser.add_argument("--leg", default=DEFAULT_LEG, choices=LEGS,
                        help="чим нормована нога цілі: minmax — розподіл, "
                             "robust — робаст, quantile — квантиль")
    parser.add_argument("--loss", default="mse", choices=("mse", "wmse"),
                        help="mse або ваговий wmse: w = 1 + α·|y|^β")
    parser.add_argument("--alpha", type=float, default=WMSE_ALPHA,
                        help="α ваги WMSE на кроках 1-3")
    parser.add_argument("--beta", type=float, default=WMSE_BETA,
                        help="β ваги WMSE на кроках 1-3")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    tail = args.target.replace(".", "_")
    alpha = args.alpha if args.loss == "wmse" else DEFAULT_ALPHA
    beta = args.beta if args.loss == "wmse" else DEFAULT_BETA
    if args.final:
        best = winner(args.out, args.target, "fine", args.kind, args.leg,
                      alpha)
        report = final(args.pair, args.target, epochs=args.epochs,
                       config=best["config"], patience=best["patience"],
                       out=args.out, kind=args.kind, scale=args.scale,
                       leg=args.leg)
        path = (args.out
                / f"final_{prefix(args.kind, args.leg, alpha)}_{tail}.json")
        path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                                   allow_nan=False), encoding="utf-8")
        print(f"записано {path.relative_to(PROJECT_ROOT)}")
        return

    if not args.step:
        raise SystemExit(f"вкажіть --step з {STEPS} або --final")
    centre = (centre_config(args.out, args.target, args.kind, args.leg, alpha)
              if args.step == "fine" else None)
    candidates, patience = candidates_for(args.step, args.out, args.target,
                                          args.kind, args.leg, alpha, beta)
    report = build(args.pair, args.target, args.folds, args.first_train,
                   args.epochs, candidates, patience, args.step,
                   kind=args.kind, scale=args.scale, leg=args.leg)
    if centre is not None:
        report["centre"] = centre["config"]
        report["interior"] = report["config"] == centre["config"]
        print("кращий у центрі околу" if report["interior"]
              else "кращий на краю околу — крок fine повторюється")
    path = (args.out
            / f"{prefix(args.kind, args.leg, alpha)}_{args.step}_{tail}.json")
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
