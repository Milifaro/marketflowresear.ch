"""Проміжний тест: свіжий відрізок часу через навчену модель.

Дослідження: research/12-zigzag-net/ (етап 7)

Відрізок береться **поза розбиттям датасету** — сирі CSV нарізаються тим
самим ланцюгом класів, що й датасет навчання, і подаються на збережену
модель `models/mlp_0_8_v1/` тим самим скейлером train:

    CSV -> клас210х8 -> клас210х14х5 -> клас210х14х3
        -> клас210х14х4ц -> клас210х210х4ц -> клас210х4бема10х10х130

Ціль — та сама, якою модель училась (`zigzag_targets`): `ema` — зігзаг
на ема_p(ціна), `ind` — незалежний зігзаг по самій ціні з ЕМА на нозі.

**Розігрів.** ЕМА і зігзаг дивляться назад, тому ланцюг рахується з
`--warmup-from`, а у вихід іде тільки вікно `--from … --to`: перші події
відрізка не мають обірваної історії.

Вихід: results/holdout_0_8.json — для вкладки «Навчання мережі»:
ціна з зігзагом 0.8 поверх неї, ціль і видача моделі.

Запуск:
    python3 research/12-zigzag-net/scripts/holdout.py \
        --from '2026-08-14 14:00' --to '2026-08-25 00:00'
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import torch

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x8  # noqa: E402
import class210x14x3  # noqa: E402
import class210x14x4  # noqa: E402
import class210x14x4c  # noqa: E402
import class210x14x5  # noqa: E402
import class210x210x4c  # noqa: E402
import class210x4bema10x10x130 as klass  # noqa: E402
import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from data_source import SOURCE_ROOT, copy_to_work, load_day, to_array  # noqa: E402
from data import (DEFAULT_LEG, KINDS, LEGS, PICKED,  # noqa: E402
                  target_period)
from train import load_saved, metrics  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
WORK_ROOT = PROJECT_ROOT / "data"
DEFAULT_FROM = "2026-08-14 14:00"
DEFAULT_TO = "2026-08-25 00:00"
DEFAULT_WARMUP = "2026-08-01 00:00"
DEFAULT_FINAL = "final_time"     # модель, навчена на розбитті по часу
COMPARE_FINAL = "final"          # модель етапу 5, на перемішаному розбитті
FINALS = ("final_time", "final", "final_ind")


def stamp(text: str) -> int:
    """'2026-08-14 14:00' у UTC -> секунди епохи (rules: час завжди UTC)."""
    moment = dt.datetime.strptime(text, "%Y-%m-%d %H:%M")
    return int(moment.replace(tzinfo=dt.timezone.utc).timestamp())


def human(value: int) -> str:
    return dt.datetime.fromtimestamp(int(value), dt.timezone.utc).strftime(
        "%Y-%m-%d %H:%M:%S")


def source_files(pair: str, first: int, last: int,
                 root: Path | None = None) -> list[Path]:
    """Добові файли, що перекривають [first, last]. Джерело — тільки читання.

    Дата у назві файлу — місцева, тому межі беруться з запасом у добу
    з кожного боку, а зайве відсіється по timestamp.
    """
    root = Path(root) if root is not None else SOURCE_ROOT
    lo = (dt.datetime.fromtimestamp(first, dt.timezone.utc)
          - dt.timedelta(days=1)).strftime("%Y-%m-%d")
    hi = (dt.datetime.fromtimestamp(last, dt.timezone.utc)
          + dt.timedelta(days=1)).strftime("%Y-%m-%d")
    files = sorted(root.glob(f"*/*/{pair}/1S_*_{pair}.csv"))
    return [f for f in files if lo <= f.name.split("_")[1] <= hi]


def events(files: list[Path], step: int = class210x8.EVENT_LENGTH,
           kind: str = "ema", leg: str = DEFAULT_LEG, log=print
           ) -> tuple[klass.Class210x4bEma, np.ndarray, np.ndarray, list]:
    """Увесь ланцюг класів на робочій копії: фічі (N, 13, 4) і цілі."""
    bases, prices, stamps = [], [], []
    for index, path in enumerate(files, 1):
        frame, _ = load_day(path)
        rows = to_array(frame)
        bases.append(class210x8.build(rows, step=step))
        block, ts = class210x14x4c.from_rows(rows, step)
        if len(ts):
            prices.append(block)
            stamps.append(ts)
        if index % 10 == 0 or index == len(files):
            log(f"      {index}/{len(files)} файлів, "
                f"подій: {sum(len(b) for b in bases)}")

    base = class210x8.concat(bases)
    # Подія з нульовим обʼємом відкидається ще на клас210х14х4, і далі по
    # ланцюгу її немає (rules/01-data-and-db.md) — інакше ЕМА рахувалась би
    # по іншому ряду подій, ніж у датасеті навчання.
    keep, _ = class210x14x4.build(base)
    alive = np.isin(base.timestamp, keep.timestamp)
    base = class210x8.Class210x8(
        x=base.x[alive], timestamp=base.timestamp[alive],
        price_open=base.price_open[alive], price_close=base.price_close[alive])
    log(f"      подій після клас210х14х4: {len(base)} "
        f"(нульовий обʼєм: {int((~alive).sum())})")
    five, _ = class210x14x5.build(base)
    three, _ = class210x14x3.build(five)
    four, _ = class210x14x4c.build(three, np.concatenate(prices),
                                   np.concatenate(stamps))
    mean, _ = class210x210x4c.build(four)
    order = np.argsort(mean.timestamp, kind="stable")
    mean = class210x210x4c.Class210x210x4c(
        x=mean.x[order], timestamp=mean.timestamp[order],
        price_open=mean.price_open[order], price_close=mean.price_close[order])
    dataset, _ = klass.build(mean, klass.PERIODS)
    targets = (zigzag_targets.independent(mean.price_open, mean.timestamp,
                                          scaler=leg)
               if kind == "ind"
               else zigzag_targets.build(mean.price_open, mean.timestamp,
                                         klass.PERIODS))
    return (dataset, targets.y, np.asarray(mean.price_open, dtype=float),
            targets.periods)


def pivots_of(prices: np.ndarray, period: int, threshold: str,
              kind: str = "ema") -> tuple[list, np.ndarray]:
    """Півоти того самого зігзага, на якому будувалась ціль."""
    series = prices if kind == "ind" else ema(prices, period)
    return zigzag(series, THRESHOLDS[threshold]), series


def apply(final: dict, x: np.ndarray, good: np.ndarray) -> np.ndarray:
    """Прогін збереженої моделі на фічах вікна; без цілі — NaN."""
    model, scaler = load_saved(final, PROJECT_ROOT)
    out = np.full(len(x), np.nan, dtype=np.float32)
    with torch.no_grad():
        out[good] = model(torch.tensor(scaler.apply(x[good]))).numpy()
    return out


def build(pair: str = "BTC_USDT", threshold: str = "0.8",
          begin: str = DEFAULT_FROM, end: str = DEFAULT_TO,
          warmup: str = DEFAULT_WARMUP, source_root: Path | None = None,
          work_root: Path | None = None, final_name: str = DEFAULT_FINAL,
          compare_name: str | None = COMPARE_FINAL, kind: str = "ema",
          leg: str = DEFAULT_LEG, log=print) -> dict:
    first, last, warm = stamp(begin), stamp(end), stamp(warmup)
    period = target_period(threshold, kind)

    files = source_files(pair, warm, last, source_root)
    if not files:
        raise SystemExit(f"немає файлів {pair} на {begin} .. {end}")
    copied = copy_to_work(files, root=source_root, work_root=work_root)
    log(f"[1/4] робоча копія: {len(copied)} файлів "
        f"({copied[0].name} .. {copied[-1].name})")

    dataset, y, prices, periods = events(copied, kind=kind, leg=leg, log=log)
    log(f"[2/4] ланцюг класів: {len(dataset)} подій з розігрівом "
        f"({human(dataset.timestamp[0])} .. {human(dataset.timestamp[-1])})")

    marks, smoothed = pivots_of(prices, period, threshold, kind)
    inside = (dataset.timestamp >= first) & (dataset.timestamp < last)
    if not inside.any():
        raise SystemExit(f"у вікні {begin} .. {end} немає подій")

    tail = threshold.replace(".", "_")
    final = json.loads((RESULTS / f"{final_name}_{tail}.json")
                       .read_text(encoding="utf-8"))
    x = np.asarray(dataset.x[inside], dtype=np.float32)
    good = np.isfinite(x).all(axis=(1, 2))
    pred = apply(final, x, good)
    before = None
    if compare_name and (RESULTS / f"{compare_name}_{tail}.json").exists():
        before = json.loads((RESULTS / f"{compare_name}_{tail}.json")
                            .read_text(encoding="utf-8"))
        before_pred = apply(before, x, good)
    log(f"[3/4] прогін моделі: {int(good.sum())} подій з {len(x)}")

    column = periods.index(period)
    row = list(zigzag_targets.THRESHOLDS).index(threshold)
    target = y[inside, column, row]
    stamps = dataset.timestamp[inside]
    known = np.isfinite(target) & np.isfinite(pred)

    tag = kind if leg == DEFAULT_LEG else f"{kind}_{leg}"
    if final_name.endswith("_wmse"):
        tag += "_wmse"
    seen = RESULTS / ("predict_series.json" if kind == "ema"
                      else f"predict_series_{tag}.json")
    seen_to = None
    if seen.exists():
        seen_to = int(json.loads(seen.read_text(encoding="utf-8"))["period"]["to"])
    marks = [pivot for pivot in marks
             if first <= dataset.timestamp[pivot.index] < last]
    payload = {
        "pair": pair,
        "step": "проміжний тест на свіжому відрізку",
        "model": final["model"],
        "model_path": final["model_path"],
        "config": final["config"],
        "split": final.get("split", "перемішане розбиття"),
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": final["target"],
        "scale": final.get("scale", "zscore"),
        "event_seconds": class210x8.EVENT_LENGTH,
        "window": {"from": first, "to": last,
                   "from_utc": human(first), "to_utc": human(last)},
        "warmup": {"from": warm, "from_utc": human(warm),
                   "events": int((~inside).sum())},
        "files": [path.name for path in copied],
        "events": int(inside.sum()),
        "with_target": int(np.isfinite(target).sum()),
        "predicted": int(np.isfinite(pred).sum()),
        "period": {"from": int(stamps.min()), "to": int(stamps.max()),
                   "from_utc": human(stamps.min()), "to_utc": human(stamps.max())},
        "price_range": [round(float(np.nanmin(dataset.price_open[inside])), 2),
                        round(float(np.nanmax(dataset.price_open[inside])), 2)],
        "metrics": metrics(target[known], pred[known]),
        "legs": max(len(marks) - 1, 0),
        "pivots": [{"t": int(dataset.timestamp[pivot.index]),
                    "price": round(float(prices[pivot.index]), 2),
                    "ema": round(float(smoothed[pivot.index]), 2),
                    "kind": pivot.kind} for pivot in marks],
        "t": [int(v) for v in stamps],
        "price": [round(float(v), 2) for v in dataset.price_open[inside]],
        "ema": [round(float(v), 2) for v in smoothed[inside]],
        "y": [None if not np.isfinite(v) else round(float(v), 4) for v in target],
        "p": [None if not np.isfinite(v) else round(float(v), 4) for v in pred],
    }
    if before is not None:
        payload["before"] = {
            "model": before["model"],
            "model_path": before["model_path"],
            "split": before.get("split", "перемішане розбиття"),
            "metrics": metrics(target[known], before_pred[known]),
            "p": [None if not np.isfinite(v) else round(float(v), 4)
                  for v in before_pred],
        }
    if seen_to:
        payload["seen"] = {"to": seen_to, "to_utc": human(seen_to),
                           "events": int((stamps <= seen_to).sum()),
                           "fresh": int((stamps > seen_to).sum())}
    log(f"[4/4] у вікні {payload['events']} подій, з ціллю "
        f"{payload['with_target']}, півотів {len(payload['pivots'])}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--from", dest="begin", default=DEFAULT_FROM)
    parser.add_argument("--to", dest="end", default=DEFAULT_TO)
    parser.add_argument("--warmup-from", dest="warmup", default=DEFAULT_WARMUP)
    parser.add_argument("--final", default=DEFAULT_FINAL,
                        help="файл фінального прогону без розширення, "
                             "наприклад final_ind_quantile")
    parser.add_argument("--leg", default=DEFAULT_LEG, choices=LEGS,
                        help="чим нормована нога цілі")
    parser.add_argument("--compare", default=None,
                        help="друга модель для порівняння; за замовчуванням "
                             "перемішаний прогін тільки для --kind ema")
    parser.add_argument("--kind", default="ema", choices=KINDS,
                        help="ціль: ema — зігзаг на ЕМА ціни, "
                             "ind — незалежний зігзаг, ЕМА на нозі")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    compare = args.compare or (COMPARE_FINAL if args.kind == "ema" else None)
    payload = build(args.pair, args.target, args.begin, args.end, args.warmup,
                    final_name=args.final, compare_name=compare,
                    kind=args.kind, leg=args.leg)
    args.out.mkdir(parents=True, exist_ok=True)
    tail = args.target.replace(".", "_")
    tag = args.kind if args.leg == DEFAULT_LEG else f"{args.kind}_{args.leg}"
    if args.final.endswith("_wmse"):     # прогони під різними лоссами
        tag += "_wmse"                   # не перезаписують ряди один одного
    name = (f"holdout_{tail}.json" if args.kind == "ema"
            else f"holdout_{tag}_{tail}.json")
    path = args.out / name
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(f"MAE {payload['metrics']['mae']}, знак "
          f"{payload['metrics']['sign_accuracy']}, r {payload['metrics']['pearson']}")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
