"""Видача моделі на всьому датасеті: ціна, зігзаг, ціль, прогноз.

Дослідження: research/12-zigzag-net/ (етап 8)

Модель проганяється по **всіх** подіях `клас210х4бема10х10х130` — train,
val і test разом, у порядку часу. Виходить три ряди на спільній осі часу:

    price  — ціна події (price_open), quote (USDT), і півоти зігзага 0.8
    y      — ціль: нормований зігзаг 0.8%, [-1, 1]
    p      — видача моделі на тих самих фічах

Ціль і півоти беруться того самого способу, яким модель училась
(`--kind`): `ema` — зігзаг на ема_p(ціна), `ind` — незалежний зігзаг по
самій ціні з ЕМА на нозі.

За замовчуванням береться модель, навчена на розбитті **по часу**
(`results/final_time_0_8.json`): модель етапу 5 навчалась на
перемішаному розбитті й на суцільному відрізку часу не працює (етап 6).

Скейлер береться **той самий**, що рахувався на train при навчанні,
а не рахується заново.

Вихід: results/predict_series.json — для вкладки «Навчання мережі»

Запуск:
    python3 research/12-zigzag-net/scripts/predict_series.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from data import (DATASET, DEFAULT_LEG, KINDS, LEGS, PARTS,  # noqa: E402
                  PICKED, target_file, target_period)
from train import load_saved  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
DEFAULT_FINAL = "final_time"


def pivots_of(prices: np.ndarray, period: int, threshold: str,
              kind: str = "ema"):
    """Півоти того самого зігзага, з якого зроблена ціль."""
    series = prices if kind == "ind" else ema(prices, period)
    return zigzag(series, THRESHOLDS[threshold]), series


def build(pair: str = "BTC_USDT", threshold: str = "0.8",
          root: Path | None = None, final_name: str = DEFAULT_FINAL,
          kind: str = "ema", leg: str = DEFAULT_LEG) -> dict:
    root = root or DATASET
    in_dir = root / pair / "class210x4bema10x10x130"
    period = target_period(threshold, kind)

    final = json.loads(
        (RESULTS / f"{final_name}_{threshold.replace('.', '_')}.json")
        .read_text(encoding="utf-8"))
    model, scaler = load_saved(final, PROJECT_ROOT)

    rows = []
    for index, name in enumerate(PARTS):
        dataset = klass.load(in_dir / f"{name}.npz")
        targets = zigzag_targets.load(in_dir / target_file(name, kind, leg))
        if not np.array_equal(dataset.timestamp, targets.timestamp):
            raise SystemExit(f"{name}: фічі й цілі зібрані на різних подіях")
        x = np.asarray(dataset.x, dtype=np.float32)
        good = np.isfinite(x).all(axis=(1, 2))
        pred = np.full(len(x), np.nan, dtype=np.float32)
        with torch.no_grad():
            scaled = torch.tensor(scaler.apply(x[good]))
            pred[good] = model(scaled).numpy()
        rows.append({
            "t": dataset.timestamp, "price": dataset.price_open,
            "y": targets.column(period, threshold), "p": pred,
            "part": np.full(len(x), index, dtype=np.int8),
        })

    merged = {key: np.concatenate([row[key] for row in rows]) for key in rows[0]}
    order = np.argsort(merged["t"], kind="stable")
    merged = {key: value[order] for key, value in merged.items()}

    known = np.isfinite(merged["y"]) & np.isfinite(merged["p"])
    marks, smoothed = pivots_of(merged["price"], period, threshold, kind)
    payload = {
        "pair": pair,
        "model": final["model"],
        "split": final.get("split", "перемішане розбиття"),
        "model_path": final["model_path"],
        "config": final["config"],
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": final["target"],
        "scale": final.get("scale", "zscore"),
        "event_seconds": 210,
        "events": int(len(merged["t"])),
        "with_target": int(np.isfinite(merged["y"]).sum()),
        "parts": {name: int((merged["part"] == index).sum())
                  for index, name in enumerate(PARTS)},
        "period": {"from": int(merged["t"].min()), "to": int(merged["t"].max())},
        "price_range": [round(float(merged["price"].min()), 2),
                        round(float(merged["price"].max()), 2)],
        "error": {"mae": round(float(np.abs(merged["p"][known]
                                            - merged["y"][known]).mean()), 4)},
        "t": [int(v) for v in merged["t"]],
        "price": [round(float(v), 2) for v in merged["price"]],
        "y": [None if not np.isfinite(v) else round(float(v), 4)
              for v in merged["y"]],
        "p": [None if not np.isfinite(v) else round(float(v), 4)
              for v in merged["p"]],
        "part": [int(v) for v in merged["part"]],
        "pivots": [{"t": int(merged["t"][pivot.index]),
                    "price": round(float(merged["price"][pivot.index]), 2),
                    "ema": round(float(smoothed[pivot.index]), 2),
                    "kind": pivot.kind} for pivot in marks],
    }
    payload["legs"] = max(len(payload["pivots"]) - 1, 0)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--final", default=DEFAULT_FINAL,
                        help="файл фінального прогону без розширення, "
                             "наприклад final_ind_quantile")
    parser.add_argument("--kind", default="ema", choices=KINDS,
                        help="ціль: ema — зігзаг на ЕМА ціни, "
                             "ind — незалежний зігзаг, ЕМА на нозі")
    parser.add_argument("--leg", default=DEFAULT_LEG, choices=LEGS,
                        help="чим нормована нога цілі")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.target, final_name=args.final,
                    kind=args.kind, leg=args.leg)
    args.out.mkdir(parents=True, exist_ok=True)
    tag = args.kind if args.leg == DEFAULT_LEG else f"{args.kind}_{args.leg}"
    if args.final.endswith("_wmse"):     # прогони під різними лоссами
        tag += "_wmse"                   # не перезаписують ряди один одного
    name = ("predict_series.json" if args.kind == "ema"
            else f"predict_series_{tag}.json")
    path = args.out / name
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(f"подій {payload['events']}, з ціллю {payload['with_target']}, "
          f"MAE {payload['error']['mae']}")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
