"""Три нормалізації ноги зігзага: розподіл, робаст, квантиль.

Дослідження: research/12-zigzag-net/ (етап 2)
Правила: rules/02-markup.md → Нормалізація ноги
         rules/01-data-and-db.md → Скейлери

Питання одне — де подія стоїть у своїй нозі; відповідей три, за
кількістю скейлерів. Кожен рахується **по своїй нозі окремо**, на цінах
самої ноги:

    minmax    2*(price - low)/(high - low) - 1   -1 у дні, +1 у вершині
    robust    (price - медіана)/(q75 - q25)      те саме в одиницях IQR
    quantile  2u - 1, u — місце ціни в CDF ноги  ранг події в нозі

Ряд береться той самий, що йде в навчання: незалежний зігзаг свого
порогу, ЕМА `zigzag_targets.SMOOTH` уже на нормованій нозі.

Вихід: results/zigzag_scalers.json — для вкладки «Навчання мережі»:
гістограма кожного ряду й вікно, де три ряди намальовані під ціною.

Запуск:
    python3 research/12-zigzag-net/scripts/zigzag_scalers.py --target 0.8
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import zigzag_targets  # noqa: E402
from class_card import BINS, CLIP, histogram  # noqa: E402
from data import DATASET, PARTS  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
WINDOW = 900        # подій у вікні, яке малюється під ціною (~2 доби)

# Підписи ті самі, що в колонках розподілу вкладки «Класи датасету»
# (rules/scripts/class_card.py → DISTRIBUTIONS): один словник термінів
# на весь дашборд.
NAMES = {
    "minmax": {"name": "розподіл",
               "formula": "2·(price − low) / (high − low) − 1",
               "note": "−1 у нижньому півоті, +1 у верхньому"},
    "robust": {"name": "робаст",
               "formula": "(price − медіана) / (q75 − q25)",
               "note": "той самий рух в одиницях IQR ноги, без меж"},
    "quantile": {"name": "квантиль",
                 "formula": "2u − 1, u — місце ціни в CDF ноги",
                 "note": "ранг події в нозі: швидкість руху не впливає"},
}


def human(value: int) -> str:
    return dt.datetime.fromtimestamp(int(value), dt.timezone.utc).strftime(
        "%Y-%m-%d %H:%M")


def prices_of(pair: str, root: Path | None = None
              ) -> tuple[np.ndarray, np.ndarray]:
    """Ціни й час усіх подій датасету одним рядом за часом."""
    in_dir = (root or DATASET) / pair / "class210x4bema10x10x130"
    price, stamps = [], []
    for name in PARTS:
        part = klass.load(in_dir / f"{name}.npz")
        price.append(np.asarray(part.price_open, dtype=float))
        stamps.append(np.asarray(part.timestamp, dtype=np.int64))
    price = np.concatenate(price)
    stamps = np.concatenate(stamps)
    order = np.argsort(stamps, kind="stable")
    return price[order], stamps[order]


def row_stats(values: np.ndarray) -> dict:
    """Гістограма й межі одного ряду цілі; події поза зігзагом не рахуються."""
    clean = values[np.isfinite(values)]
    return {
        "events": int(len(clean)),
        "min": round(float(clean.min()), 4),
        "q01": round(float(np.quantile(clean, 0.01)), 4),
        "median": round(float(np.median(clean)), 4),
        "q99": round(float(np.quantile(clean, 0.99)), 4),
        "max": round(float(clean.max()), 4),
        "std": round(float(clean.std()), 4),
        "hist": histogram(clean, BINS, CLIP),
    }


def build(pair: str = "BTC_USDT", threshold: str = "0.8",
          window: int = WINDOW, root: Path | None = None) -> dict:
    price, stamps = prices_of(pair, root)
    pivots = zigzag(price, THRESHOLDS[threshold])
    marks = np.array([pivot.index for pivot in pivots], dtype=int)

    rows, series = [], {}
    for scaler in zigzag_targets.SCALERS:
        targets = zigzag_targets.independent(price, stamps, scaler=scaler)
        values = targets.column(zigzag_targets.SMOOTH, threshold)
        series[scaler] = values
        rows.append({"id": scaler, **NAMES[scaler], **row_stats(values)})

    # вікно під ціною: останні `window` подій — там видно й ноги, й краї
    start = max(len(price) - window, 0)
    inside = [pivot for pivot in pivots if pivot.index >= start]
    return {
        "pair": pair,
        "threshold": threshold,
        "target_kind": "ind",
        "smooth": zigzag_targets.SMOOTH,
        # розділ показує всі три нормалізації, тому підпис без ноги:
        # яку саме взяв прогін, каже вкладка полем `used`
        "target": (f"незалежний зігзаг {threshold}, "
                   f"ема{zigzag_targets.SMOOTH} на нозі"),
        "scaled_by": "нозі: кожен рух між півотами проходить скейлер окремо",
        "events": int(len(price)),
        "pivots": int(len(marks)),
        "legs": int(max(len(marks) - 1, 0)),
        "period": {"from_utc": human(stamps[0]), "to_utc": human(stamps[-1])},
        "bins": BINS,
        "clip": CLIP,
        "rows": rows,
        "window": {
            "events": int(len(price) - start),
            "from_utc": human(stamps[start]),
            "to_utc": human(stamps[-1]),
            "legs": max(len(inside) - 1, 0),
            "t": [int(v) for v in stamps[start:]],
            "price": [round(float(v), 2) for v in price[start:]],
            # `ema` = ціна: незалежний зігзаг стоїть на самій ціні, і
            # вкладка малює півоти тим самим `drawZigzag`, що й решту рядів
            "pivots": [{"t": int(stamps[pivot.index]),
                        "price": round(float(price[pivot.index]), 2),
                        "ema": round(float(price[pivot.index]), 2),
                        "kind": pivot.kind} for pivot in inside],
            **{scaler: [None if not np.isfinite(v) else round(float(v), 4)
                        for v in values[start:]]
               for scaler, values in series.items()},
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(THRESHOLDS))
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.target, args.window)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / "zigzag_scalers.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    for row in payload["rows"]:
        print(f"{row['name']}: {row['events']} подій, "
              f"межі {row['min']} … {row['max']}, σ {row['std']}")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
