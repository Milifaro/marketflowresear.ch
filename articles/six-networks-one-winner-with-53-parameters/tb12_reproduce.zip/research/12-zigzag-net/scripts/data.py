"""Дані для навчання: фічі клас210х4бема10х10х130 і обрана мітка.

Дослідження: research/12-zigzag-net/
Правила: rules/03-models.md → Підбір даних для навчання

Фічі — `(13, 4)` на подію, ціль — один ряд нормованого зігзага. Події без
цілі (поза зігзагом) відкидаються.

**Два способи побудови цілі** (`rules/scripts/zigzag_targets.py`):

| Ключ | Ціль | Файл вибірки |
| ---- | ---- | ------------ |
| `ema` | ема_p(ціна) → зігзаг порогу → нормована нога | `<part>_targets.npz` |
| `ind` | зігзаг порогу по самій ціні → нормована нога → ема10 | `<part>_targets_ind.npz` |

`ind` — **незалежний зігзаг**: він один на весь ряд і від періодів ЕМА
фіч не залежить, згладжується вже нормована нога.

Нога нормується одним із трьох скейлерів (`leg`, `rules/02-markup.md` →
Нормалізація ноги): `minmax` — ряд «розподіл», без суфікса у файлі,
`robust` і `quantile` — свої файли `<part>_targets_ind_<leg>.npz`.

**Два скейлери фіч** (`rules/scripts/scalers.py`), обидва рахуються
**тільки на train** і застосовуються до val/test (rules/01-data-and-db.md
→ Порядок дій і захист від витоку):

| Ключ | Що робить |
| ---- | --------- |
| `zscore` | `(x - середнє) / відхилення` по кожній клітинці `13 × 4` |
| `quantile` | місце значення в CDF train тієї самої клітинки, `[-1, 1]` |
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

import sys

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import scalers  # noqa: E402
import zigzag_targets  # noqa: E402

DATASET = PROJECT_ROOT / "data" / "datasets"
PARTS = ("train", "val", "test")

# Обрані мітки (rules/03-models.md → Підбір даних для навчання)
PICKED = {"0.8": 80, "2.3": 90}
# Незалежний зігзаг: період — це ЕМА нормованої ноги, а не ЕМА ціни
PICKED_IND = {"0.8": zigzag_targets.SMOOTH, "2.3": zigzag_targets.SMOOTH}
KINDS = ("ema", "ind")
LEGS = zigzag_targets.SCALERS          # чим нормована нога цілі
DEFAULT_LEG = "minmax"
SCALES = ("zscore", "quantile", "none")
# Підписи ноги — ті самі, що в колонках розподілу (rules/scripts/class_card.py)
LEG_TITLES = {"minmax": "розподіл", "robust": "робаст", "quantile": "квантиль"}


def target_file(name: str, kind: str = "ema",
                leg: str = DEFAULT_LEG) -> str:
    """Імʼя файлу цілей вибірки: спосіб побудови × нормалізація ноги."""
    if kind == "ema":
        return f"{name}_targets.npz"
    suffix = "" if leg == DEFAULT_LEG else f"_{leg}"
    return f"{name}_targets_ind{suffix}.npz"


def target_period(threshold: str, kind: str = "ema") -> int:
    """Період, яким береться ряд цілі: ЕМА ціни (`ema`) чи ЕМА ноги (`ind`)."""
    return (PICKED if kind == "ema" else PICKED_IND)[threshold]


def target_title(threshold: str, kind: str = "ema",
                 leg: str = DEFAULT_LEG) -> str:
    """Підпис цілі — той самий у звітах і на вкладці."""
    period = target_period(threshold, kind)
    if kind == "ema":
        return f"зігзаг {threshold} нормований, ема{period}"
    return (f"незалежний зігзаг {threshold}, нога {LEG_TITLES[leg]}, "
            f"ема{period} на нозі")


@dataclass
class Part:
    """Одна вибірка: фічі, ціль, час події."""

    x: np.ndarray            # (N, 13, 4)
    y: np.ndarray            # (N,)
    timestamp: np.ndarray    # (N,)
    price_open: np.ndarray   # (N,)
    price_close: np.ndarray  # (N,)

    def __len__(self) -> int:
        return len(self.x)


@dataclass
class Scaler:
    """Скейлер фіч, порахований на train: z-score або квантиль.

    `zscore` тримає середнє й відхилення кожної клітинки `(13, 4)`,
    `quantile` — опорні квантилі train тієї самої клітинки. Обидва
    зберігаються одним `.npz` і застосовуються до будь-якої вибірки.
    """

    kind: str = "zscore"
    mean: np.ndarray | None = None
    std: np.ndarray | None = None
    knots: np.ndarray | None = None    # (K, 13, 4)
    levels: np.ndarray | None = None   # (K,)

    def apply(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=np.float32)
        if self.kind == "zscore":
            return (x - self.mean) / self.std
        out = np.empty_like(x)
        for row in range(x.shape[1]):
            for column in range(x.shape[2]):
                knots = self.knots[:, row, column]
                out[:, row, column] = (
                    0.0 if knots[-1] == knots[0]
                    else 2 * np.interp(x[:, row, column], knots,
                                       self.levels) - 1)
        return out

    def save(self, path) -> None:
        if self.kind == "zscore":
            np.savez(path, kind="zscore", mean=self.mean, std=self.std)
        else:
            np.savez_compressed(path, kind="quantile", knots=self.knots,
                                levels=self.levels)

    @staticmethod
    def load(path) -> "Scaler":
        with np.load(path, allow_pickle=False) as data:
            kind = str(data["kind"]) if "kind" in data else "zscore"
            if kind == "zscore":
                return Scaler(kind="zscore", mean=data["mean"], std=data["std"])
            return Scaler(kind="quantile", knots=data["knots"],
                          levels=data["levels"])


def load_part(in_dir: Path, name: str, threshold: str, period: int,
              kind: str = "ema", leg: str = DEFAULT_LEG) -> Part:
    """Вибірка з міткою; події без цілі відкидаються."""
    dataset = klass.load(in_dir / f"{name}.npz")
    targets = zigzag_targets.load(in_dir / target_file(name, kind, leg))
    if not np.array_equal(dataset.timestamp, targets.timestamp):
        raise SystemExit(f"{name}: фічі й цілі зібрані на різних подіях")
    y = targets.column(period, threshold)
    x = np.asarray(dataset.x, dtype=np.float32)
    good = np.isfinite(y) & np.isfinite(x).all(axis=(1, 2))
    return Part(x=x[good], y=y[good].astype(np.float32),
                timestamp=dataset.timestamp[good],
                price_open=dataset.price_open[good],
                price_close=dataset.price_close[good])


def fit_scaler(x: np.ndarray, kind: str = "zscore") -> Scaler:
    """Скейлер на train. Нульове відхилення лишається одиницею."""
    x = np.asarray(x, dtype=np.float32)
    if kind == "quantile":
        # `scalers.quantile_fit`, але одразу по всіх 52 клітинках
        grid = np.linspace(0.0, 1.0, scalers.QUANTILE_KNOTS)
        levels = (grid * (len(x) - 1) + 0.5) / len(x)
        knots = np.quantile(x, grid, axis=0)
        return Scaler(kind="quantile", knots=knots.astype(np.float32),
                      levels=levels.astype(np.float32))
    mean = x.mean(axis=0)
    std = x.std(axis=0)
    std[std == 0] = 1.0
    return Scaler(kind="zscore", mean=mean.astype(np.float32),
                  std=std.astype(np.float32))


SCALE_TITLES = {"zscore": "z-score на train", "quantile": "квантиль на train",
                "none": "без скейлінгу"}


def load(pair: str = "BTC_USDT", threshold: str = "0.8",
         period: int | None = None, in_dir: Path | None = None,
         scale: bool | str = True, kind: str = "ema",
         leg: str = DEFAULT_LEG) -> tuple[dict, Scaler | None, dict]:
    """Усі три вибірки з обраною міткою плюс скейлер train.

    `scale` — ключ скейлера (`zscore`, `quantile`, `none`). `True`/`False`
    лишаються як старі значення: z-score або без скейлінгу.
    """
    if scale is True:
        scale = "zscore"
    elif scale is False:
        scale = "none"
    if scale not in SCALES:
        raise ValueError(f"скейлер має бути з {SCALES}")
    in_dir = in_dir or DATASET / pair / "class210x4bema10x10x130"
    period = period or target_period(threshold, kind)
    parts = {name: load_part(in_dir, name, threshold, period, kind, leg)
             for name in PARTS}
    scaler = fit_scaler(parts["train"].x, scale) if scale != "none" else None
    if scaler is not None:
        for part in parts.values():
            part.x = scaler.apply(part.x)
    report = {
        "pair": pair,
        "scale": SCALE_TITLES[scale],
        "scale_kind": scale,
        "source": str(in_dir),
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": target_title(threshold, kind, leg),
        "events": {name: len(part) for name, part in parts.items()},
        "target_range": {
            name: [round(float(part.y.min()), 4), round(float(part.y.max()), 4)]
            for name, part in parts.items()},
    }
    return parts, scaler, report
