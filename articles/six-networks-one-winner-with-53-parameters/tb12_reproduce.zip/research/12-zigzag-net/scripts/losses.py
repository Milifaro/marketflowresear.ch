"""Функція втрат: чим саме штрафувати помилку і що це робить з видачею.

Дослідження: research/12-zigzag-net/ (етап 9)
Правила: rules/03-models.md → Лосс: MSE і ваговий MSE

Під MSE вихід моделі стискається до середини ноги: для прогнозу за
найменшими квадратами `σ_прогнозу ≈ |r|·σ_цілі`, і при слабкому сигналі
менша за модулем відповідь просто дешевша. Ваговий MSE згинає цю межу,
але не прибирає — вага краю сатурує. Тут поруч ставляться **пʼять інших
способів** повернути прогнозу розмах, і кожен міряється на тому самому
`test`, тією самою моделлю й тим самим розбиттям, що й основний прогін.

    розмах        WMSE + λ·(σ_цілі − σ_прогнозу)²      прямий важіль на σ
    калібрування  той самий WMSE, вихід розтягнутий    σ рівно як у цілі
    кореляція     1 − Пірсон                            масштаб не штрафується
    пінбол        Σ_q max(q·e, (q−1)·e), 9 квантилів    замість точки — розподіл
    Huber         δ²·(√(1+(e/δ)²) − 1)                  оптимум ближче до медіани

Перший рядок звіту — поточний ваговий MSE прогону: без нього порівнювати
нема з чим.

Усі функції рахуються **однаково на torch і на numpy**: тим самим
виразом іде навчання і рання зупинка по val.

Вихід: results/losses_ind_quantile_0_8.json

Запуск:
    python3 research/12-zigzag-net/scripts/losses.py --target 0.8 \
        --kind ind --leg quantile --scale quantile
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import split_time  # noqa: E402
import walk_forward  # noqa: E402
from data import DEFAULT_LEG, KINDS, LEGS, PICKED, SCALES  # noqa: E402
from train import (DEFAULT_ALPHA, DEFAULT_BETA, SEED, distribution,  # noqa: E402
                   metrics, number, predict, wmse)
from walk_forward import (MIN_GAP, fold_parts, human, merged,  # noqa: E402
                          pivot_index, prefix)

RESULTS = RESEARCH_DIR / "results"

LAMBDA = 1.0          # ціна розмаху: σ коштує стільки ж, скільки помилка
DELTA = 0.5           # злам псевдо-Huber: пів ноги
QUANTILES = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)


def sigma(values):
    """σ ряду одним виразом і для torch, і для numpy (ddof = 0)."""
    centred = values - values.mean()
    return ((centred * centred).mean()) ** 0.5


def spread_loss(pred, true, alpha: float, beta: float,
                lam: float = LAMBDA):
    """WMSE плюс штраф за розмах: `L = WMSE + λ·(σ_цілі − σ_прогнозу)²`.

    Вага краю тягне σ побічно, через ціну помилки. Тут σ стоїть у лоссі
    прямо: модель платить за те, що її розкид не такий, як у цілі.
    Обидва боки штрафуються однаково — надто широка відповідь теж дорога.
    """
    return wmse(pred, true, alpha, beta) + lam * (sigma(true) - sigma(pred)) ** 2


def correlation_loss(pred, true):
    """`L = 1 − Пірсон(p, y)`: форма без масштабу.

    Кореляція не залежить від масштабу відповіді, тому стискати вихід до
    центру немає сенсу — але й самого масштабу лосс не задає. Число з
    такої моделі читається лише після калібрування (`calibration`).
    """
    p = pred - pred.mean()
    t = true - true.mean()
    return 1 - (p * t).mean() / (sigma(pred) * sigma(true) + 1e-8)


def pinball_loss(pred, true, quantiles=QUANTILES):
    """Пінбол по кількох квантилях: `max(q·e, (q−1)·e)`, `e = y − p`.

    `pred` — матриця `(N, len(quantiles))`, по стовпчику на квантиль.
    Кожен стовпчик вчиться на свій квантиль умовного розподілу, тому
    краї беруться з крайніх квантилів, а не з розтягування середини.
    """
    total = 0
    for index, q in enumerate(quantiles):
        error = true - pred[:, index]
        total = total + (q * error.clip(min=0)
                         + (q - 1) * error.clip(max=0)).mean()
    return total / len(quantiles)


def huber_loss(pred, true, delta: float = DELTA):
    """Псевдо-Huber: `δ²·(√(1 + (e/δ)²) − 1)`.

    Гладка версія Huber без гілок, тому рахується однаково на torch і
    numpy. Біля нуля це MSE, далі за `δ` — майже модуль, тобто оптимум
    їде від середнього до медіани й менше стягується до центру.
    """
    error = (pred - true) / delta
    return (delta * delta * ((error * error + 1) ** 0.5 - 1)).mean()


def calibration(pred: np.ndarray, true: np.ndarray) -> dict:
    """Афінне калібрування виходу, пораховане **на train**.

    `p' = shift + scale·p`, `scale = σ_цілі / σ_прогнозу`. Знак і
    Пірсон від цього не міняються взагалі — міняється тільки розмах.
    """
    pred = np.asarray(pred, dtype=float)
    true = np.asarray(true, dtype=float)
    scale = float(sigma(true) / max(float(sigma(pred)), 1e-9))
    return {"scale": round(scale, 4),
            "shift": round(float(true.mean() - scale * pred.mean()), 4)}


def calibrated(pred: np.ndarray, fit: dict) -> np.ndarray:
    return np.asarray(pred, dtype=float) * fit["scale"] + fit["shift"]


@dataclass
class Variant:
    """Один спосіб рахувати штраф."""

    id: str
    name: str
    formula: str
    note: str
    loss: Callable
    outputs: int = 1
    calibrate: bool = False
    point: Callable | None = None
    params: dict = field(default_factory=dict)


def variants(alpha: float = DEFAULT_ALPHA,
             beta: float = DEFAULT_BETA) -> list[Variant]:
    """Перелік способів; ваги WMSE беруться з конфігурації прогону."""
    weighted = lambda pred, true: wmse(pred, true, alpha, beta)  # noqa: E731
    return [
        Variant(
            id="wmse",
            name="ваговий MSE (поточний)",
            formula="Σ w·(p − y)² / Σ w,  w = 1 + α·|y|^β",
            note="вага краю: помилка в півоті дорожча за помилку в "
                 "середині ноги в 1 + α разів",
            loss=weighted,
            params={"alpha": alpha, "beta": beta}),
        Variant(
            id="spread",
            name="штраф за розмах",
            formula="WMSE + λ·(σ_цілі − σ_прогнозу)²",
            note="σ стоїть у лоссі прямо, а не через вагу краю; λ = 1 — "
                 "розмах коштує стільки ж, скільки помилка",
            loss=lambda pred, true: spread_loss(pred, true, alpha, beta),
            params={"alpha": alpha, "beta": beta, "lambda": LAMBDA}),
        Variant(
            id="calibrated",
            name="WMSE + пост-калібрування",
            formula="p' = shift + (σ_цілі / σ_прогнозу)·p",
            note="та сама навчена модель, що в першому рядку; коефіцієнт "
                 "рахується на train, знак і Пірсон не міняються",
            loss=weighted,
            calibrate=True,
            params={"alpha": alpha, "beta": beta}),
        Variant(
            id="corr",
            name="кореляційний лосс",
            formula="1 − Пірсон(p, y), далі калібрування",
            note="масштаб відповіді не штрафується взагалі — модель "
                 "вчить лише форму, розмах ставиться після навчання",
            loss=correlation_loss,
            calibrate=True),
        Variant(
            id="pinball",
            name="пінбол по 9 квантилях",
            formula="Σ_q max(q·e, (q−1)·e) / 9,  e = y − p_q",
            note="дев'ять виходів замість одного: замість точки — "
                 "розподіл; точкова оцінка — середнє по квантилях",
            loss=pinball_loss,
            outputs=len(QUANTILES),
            point=lambda pred: np.asarray(pred, dtype=float).mean(axis=1),
            params={"quantiles": list(QUANTILES)}),
        Variant(
            id="huber",
            name="псевдо-Huber",
            formula="δ²·(√(1 + (e/δ)²) − 1)",
            note="біля нуля MSE, далі за δ майже модуль: оптимум їде від "
                 "середнього до медіани",
            loss=lambda pred, true: huber_loss(pred, true, DELTA),
            params={"delta": DELTA}),
    ]


def build(pair: str = "BTC_USDT", threshold: str = "0.8", epochs: int = 400,
          config: dict | None = None, patience: int | None = None,
          root: Path | None = None, out: Path | None = None,
          kind: str = "ind", scale: str = "quantile",
          leg: str = "quantile", log=print) -> dict:
    """Кожен спосіб — окремий прогін на тому самому розбитті по часу.

    Дані, модель, скейлер, seed і бюджет спільні; міняється рівно одне —
    чим штрафується помилка. Ділянки `train | val | test` ті самі, що у
    фінальної моделі, тому числа порівнюються з етапом 7 напряму.
    """
    import torch

    out = out or RESULTS
    period = walk_forward.target_period(threshold, kind)
    x, y, stamps, price = merged(pair, threshold, period, root, kind, leg)
    pivots = pivot_index(price, period, threshold, kind)
    if config is None:
        picked = walk_forward.winner(out, threshold, "fine", kind, leg, 1.0)
        config, patience = picked["config"], picked["patience"]
    alpha = config.get("alpha", DEFAULT_ALPHA)
    beta = config.get("beta", DEFAULT_BETA)
    log(f"[1/3] конфігурація: {config['model']} {config['params']} "
        f"lr {config['lr']}, α {alpha}, β {beta}, терпіння {patience}")

    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    parts, _ = fold_parts(fold, x, y, scale)
    log(f"[2/3] розбиття по часу: {fold.sizes()}, викинуто у проміжки "
        f"{fold.dropped}")

    tensors = {}
    rows = []
    for number_, variant in enumerate(variants(alpha, beta), 1):
        params = dict(config["params"])
        if variant.outputs > 1:
            params["outputs"] = variant.outputs
        report, model = walk_forward.run(
            config["model"], parts, epochs=epochs, lr=config["lr"],
            params=params, patience=patience, seed=SEED,
            loss=variant.loss, point=variant.point,
            loss_title=variant.name, log=lambda *args: None)
        device = report["device"]
        if not tensors:
            tensors = {name: torch.tensor(part.x, device=device)
                       for name, part in parts.items()}
        point = variant.point or (lambda pred: pred)
        pred = {name: point(predict(model, tensors[name])) for name in parts}
        fit = calibration(pred["train"], parts["train"].y) \
            if variant.calibrate else None
        if fit is not None:
            pred = {name: calibrated(values, fit)
                    for name, values in pred.items()}
        rows.append({
            "id": variant.id,
            "name": variant.name,
            "formula": variant.formula,
            "note": variant.note,
            "params": variant.params,
            "outputs": variant.outputs,
            "calibration": fit,
            "best_epoch": report["best_epoch"],
            "parameters": report["parameters"],
            "seconds": report["seconds"],
            "metrics": {name: metrics(parts[name].y, pred[name])
                        for name in ("train", "val", "test")},
            "spread": {"pred": number(np.std(pred["test"])),
                       "true": number(np.std(parts["test"].y)),
                       "ratio": number(np.std(pred["test"])
                                       / max(float(np.std(parts["test"].y)),
                                             1e-9))},
            "distribution": distribution(pred["test"]),
        })
        test = rows[-1]["metrics"]["test"]
        log(f"      {number_}/6 {variant.name}: test MAE {test['mae']}, "
            f"R² {test['r2']}, Пірсон {test['pearson']}, "
            f"знак {test['sign_accuracy']}, σ {rows[-1]['spread']['ratio']} "
            f"від цілі, {report['seconds']} с")

    constant = np.full(len(parts["test"].y), float(parts["train"].y.mean()))
    report = {
        "pair": pair,
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": walk_forward.target_title(threshold, kind, leg),
        "scale": scale,
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "step": "функція втрат: один спосіб штрафу — один прогін",
        "model": config["model"],
        "config": config,
        "patience": patience,
        "epochs": epochs,
        "seed": SEED,
        "events": {name: len(part) for name, part in parts.items()},
        "bounds": {name: {"from_utc": human(stamps[index[0]]),
                          "to_utc": human(stamps[index[-1]])}
                   for name, index in (("train", fold.train),
                                       ("val", fold.val),
                                       ("test", fold.test))},
        "test_legs": split_time.legs_between(pivots, int(fold.test[0]),
                                             int(fold.test[-1]) + 1),
        "constant": metrics(parts["test"].y, constant),
        "true": distribution(parts["test"].y),
        "rows": rows,
    }
    best = min(rows, key=lambda item: item["metrics"]["test"]["mae"])
    log(f"[3/3] найменший MAE на test: {best['name']} "
        f"({best['metrics']['test']['mae']}), константа "
        f"{report['constant']['mae']}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="0.8", choices=tuple(PICKED))
    parser.add_argument("--epochs", type=int, default=400)
    parser.add_argument("--kind", default="ind", choices=KINDS)
    parser.add_argument("--scale", default="quantile",
                        choices=tuple(s for s in SCALES if s != "none"))
    parser.add_argument("--leg", default="quantile", choices=LEGS)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target, epochs=args.epochs, out=args.out,
                   kind=args.kind, scale=args.scale, leg=args.leg)
    args.out.mkdir(parents=True, exist_ok=True)
    tail = args.target.replace(".", "_")
    path = args.out / f"losses_{prefix(args.kind, args.leg, 0.0)}_{tail}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
