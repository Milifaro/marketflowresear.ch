"""Поєднувач із памʼяттю: GRU на послідовності подій замість MLP на агрегатах.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → навчання моделей

## Чому памʼять

`calls_train.py` ставить MLP на подію, а памʼять підсовує руками: середнє
за 10 і 60 подій та ранг у хвості 600. Форма вікон там **задана**, і
мережа не може ні вибрати інше, ні згадати, що такий самий зубець уже
був на цій нозі. Тим часом канали, які вона поєднує, дивляться вперед на
пару подій кожен: `p10` каже «півот у межах 10 подій», `tooth` — «нога
кінчається». Ланцюжок із таких відповідей — це послідовність, і звʼязати
її може тільки рекурентна мережа.

## Хід

Мережа веде монету подія за подією з початку ряду. Навчання йде шматками
по `BLOCK` подій, перші `WARM` подій шматка памʼять гріє й на них не
вчиться. Замір — один прохід по всьому ряду монети, без нарізки: так
само, як воно працювало б живцем.

## Набори

    сире     тільки миттєві числа — девʼять каналів, ознака «є горизонти»
             і хід ема за 10 подій. Усе довге мережа має дістати з
             памʼяті сама
    разом    ті самі 47 ознак, що в MLP: памʼять **поверх** агрегатів.
             Питання — чи додає вона щось до руками зробленого вікна

Ціль, зона, поріг, чергування, міра і відкладений шматок train — ті самі,
що в `calls_train.py`, тому числа порівнюються напряму. Val у виборі
епохи й порога не бере участі.

Вхід : results/calls_input_<PAIR>.npz, results/calls_train.json
Вихід: results/calls_memory.json, models/calls/memory.pt,
       models/calls/memory_norm.npz

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_memory.py
    python3 research/33-buy-sell-signal/scripts/calls_memory.py --epochs 12
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
SEED = 17
HID = 64          # ширина памʼяті
LAYERS = 1
DROP = 0.1
LR = 0.002
DECAY = 1e-4
EPOCHS = 20
BLOCK = 1024      # довжина шматка, на якому розкручується памʼять
WARM = 200        # перші події шматка гріють памʼять і не вчаться
BATCH = 8         # шматків у пачці
STRIDE = 8192     # довжина кроку при заміру всього ряду
# Набори ознак. «сире» лишає мережі тільки миттєві числа, «разом» дає
# їй ті самі агрегати, що має MLP.
RAW = ("tooth", "line", "p100", "p10", "p40", "p160", "p640", "pivot",
       "correct", "є горизонти", "ціна:хід10")
FEEDS = ("сире", "разом")
SCRIPT = "research/33-buy-sell-signal/scripts/calls_memory.py"


# ------------------------------------------------------------------ мережа

def build(width: int, seed: int = SEED):
    import torch
    from torch import nn

    torch.manual_seed(seed)

    class Memory(nn.Module):
        """GRU уздовж подій; на кожній події — три числа."""

        def __init__(self) -> None:
            super().__init__()
            self.rnn = nn.GRU(width, HID, num_layers=LAYERS, batch_first=True)
            self.drop = nn.Dropout(DROP)
            self.head = nn.Linear(HID, 3)

        def forward(self, steps, state=None):
            out, state = self.rnn(steps, state)
            return self.head(self.drop(out)), state

    return Memory()


def columns_of(names: list, feed: str) -> np.ndarray:
    if feed == "разом":
        return np.arange(len(names))
    return np.asarray([number for number, one in enumerate(names)
                       if one in RAW], dtype=np.int64)


def blocks_of(mask: np.ndarray) -> list:
    """Шматки навчання: де вчитись, і скільки перед ними гріти памʼять."""
    place = np.flatnonzero(mask)
    if not len(place):
        return []
    out = []
    for start in range(int(place[0]), int(place[-1]) + 1, BLOCK):
        stop = min(start + BLOCK, int(place[-1]) + 1)
        if not mask[start:stop].any():
            continue
        out.append((max(0, start - WARM), start, stop))
    return out


def walked(model, x: np.ndarray, good: np.ndarray) -> np.ndarray:
    """Один прохід по всьому ряду монети — так, як було б живцем."""
    import torch

    out = np.full((len(x), 3), np.nan, dtype=np.float32)
    model.eval()          # замір ніколи не глушить нейрони випадково
    state = None
    with torch.no_grad():
        for start in range(0, len(x), STRIDE):
            piece = torch.from_numpy(x[start:start + STRIDE]).unsqueeze(0)
            got, state = model(piece, state)
            out[start:start + STRIDE] = torch.softmax(
                got[0], dim=1).numpy()
    out[~good] = np.nan
    return out


def spread_of(model, coins: dict, pairs: tuple, part: str) -> tuple:
    strength, picked = {}, {}
    for pair in pairs:
        proba = walked(model, coins[pair]["piece"], coins[pair]["good"])
        with np.errstate(all="ignore"):
            strength[pair] = np.nanmax(proba[:, 1:], axis=1)
        picked[pair] = np.where(proba[:, 1] >= proba[:, 2], 1,
                                -1).astype(np.int8)
        coins[pair][f"proba_{part}"] = proba
    return strength, picked


def judged(coins: dict, pairs: tuple, tune: np.ndarray, want: int, train):
    """Оцінка епохи — та сама, що в MLP: влучання ±50 на відкладеному."""
    def judge(model):
        model.eval()
        strength, picked = spread_of(model, coins, pairs, "tune")
        level = train.level_for(
            np.concatenate([strength[one] for one in pairs]),
            np.concatenate([picked[one] for one in pairs]),
            tune, max(want, 1))
        rows = [train.measure(train.fires_of(strength[one], picked[one],
                                             level, coins[one]["tune"]),
                              coins[one]["data"], coins[one]["tune"],
                              train.BEFORE, train.AFTER) for one in pairs]
        got = train.pooled(rows)
        return {"mark": got["caught"]["50"], "level": level, "pooled": got}
    return judge


def fit(coins: dict, pairs: tuple, judge, epochs: int, seed: int,
        log=print, make=None, weight=None) -> dict:
    """Навчання шматками з розкрученою памʼяттю.

    `make(width, seed)` дає мережу: за замовчуванням це GRU цього
    скрипта, а `calls_cells.py` підставляє сюди й LSTM, щоб обидві
    комірки вчились **тим самим** ходом.
    """
    import torch
    from torch import nn

    width = coins[pairs[0]]["piece"].shape[1]
    model = (make or build)(width, seed)
    opt = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=DECAY)
    # Ваги класів: за замовчуванням позитив утричі дорожчий за фон, але
    # інша ціль приносить свої — `legs_train.py` дає їх сюди.
    cost = torch.tensor(weight or [1.0, 3.0, 3.0], dtype=torch.float32)
    loss_fn = nn.CrossEntropyLoss(weight=cost)
    pack = []
    for pair in pairs:
        for warm, start, stop in blocks_of(coins[pair]["keep"]):
            pack.append((pair, warm, start, stop))
    rng = np.random.default_rng(seed)
    best, state, level, curve = None, None, None, []
    for number in range(1, epochs + 1):
        model.train()
        order = rng.permutation(len(pack))
        total, seen = 0.0, 0
        for at in range(0, len(order), BATCH):
            steps, wants, masks = [], [], []
            width_max = 0
            for one in order[at:at + BATCH]:
                pair, warm, start, stop = pack[one]
                steps.append(coins[pair]["piece"][warm:stop])
                wants.append(coins[pair]["want"][warm:stop])
                mask = np.zeros(stop - warm, dtype=bool)
                mask[start - warm:] = coins[pair]["keep"][start:stop]
                masks.append(mask)
                width_max = max(width_max, stop - warm)
            hold = np.zeros((len(steps), width_max, width), dtype=np.float32)
            want = np.zeros((len(steps), width_max), dtype=np.int64)
            keep = np.zeros((len(steps), width_max), dtype=bool)
            for row, (one, two, three) in enumerate(zip(steps, wants, masks)):
                hold[row, :len(one)] = one
                want[row, :len(two)] = two
                keep[row, :len(three)] = three
            opt.zero_grad()
            got, _ = model(torch.from_numpy(hold))
            mask = torch.from_numpy(keep)
            loss = loss_fn(got[mask], torch.from_numpy(want)[mask])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += float(loss.item()) * int(keep.sum())
            seen += int(keep.sum())
        got = judge(model)
        curve.append({"epoch": number, "loss": round(total / max(seen, 1), 4),
                      "mark": got["mark"], "level": round(got["level"], 4)})
        if best is None or got["mark"] > best:
            best, level = got["mark"], got["level"]
            state = {key: value.detach().clone()
                     for key, value in model.state_dict().items()}
            curve[-1]["best"] = True
        log(f"  епоха {number}: втрата {curve[-1]['loss']:.4f} · влучань "
            f"±50 {got['mark']}"
            f"{'  ← краще' if curve[-1].get('best') else ''}")
    model.load_state_dict(state)
    model.eval()
    return {"model": model, "curve": curve, "level": level,
            "epoch": int(max(one["epoch"] for one in curve
                             if one.get("best")))}


def run_feed(feed: str, coins: dict, pairs: tuple, norm: dict, names: list,
             tune: np.ndarray, want: int, epochs: int, seed: int,
             train) -> dict:
    columns = columns_of(names, feed)
    for pair in pairs:
        coins[pair]["piece"] = train.applied(coins[pair]["x"],
                                             norm)[:, columns]
    print(f"\n=== памʼять «{feed}»: ознак {len(columns)}")
    fitted = fit(coins, pairs, judged(coins, pairs, tune, want, train),
                 epochs, seed)
    marks = {}
    for part, title in (("tune", "tune"), ("show", "val")):
        strength, picked = spread_of(fitted["model"], coins, pairs, part)
        rows = {one: train.measure(
            train.fires_of(strength[one], picked[one], fitted["level"],
                           coins[one][part]),
            coins[one]["data"], coins[one][part], train.BEFORE, train.AFTER)
            for one in pairs}
        marks[title] = {"by_pair": rows,
                        "pooled": train.pooled(list(rows.values()))}
        if part == "show":
            hold = {one: strength[one] for one in pairs}
    got = marks["val"]["pooled"]
    print(f"  val: сигналів {got['fires']} на {got['legs']} півотів · "
          f"±15 {got['caught']['15']} · ±50 {got['caught']['50']} · у зоні "
          f"{got['in_zone']} · взято {got['money']['share']} % ходу")
    return {"model": fitted["model"], "feed": feed, "epoch": fitted["epoch"],
            "curve": fitted["curve"], "level": round(float(fitted["level"]), 4),
            "features": int(len(columns)), "columns": columns,
            "marks": marks, "strength": hold}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--feeds", nargs="+", default=list(FEEDS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    got = train.gather(pairs, args.out)
    coins = got["coins"]
    norm = train.norm_of(got["learn"], np.ones(len(got["learn"]), dtype=bool))
    for pair in pairs:
        coins[pair]["want"] = np.where(
            coins[pair]["side"] > 0, 1,
            np.where(coins[pair]["side"] < 0, 2, 0)).astype(np.int64)
    tune = np.concatenate([coins[pair]["tune"] for pair in pairs])
    want = 0
    for pair in pairs:
        piv = coins[pair]["data"]["pivot_at"]
        hold = np.flatnonzero(coins[pair]["tune"])
        want += int(((piv >= hold[0]) & (piv <= hold[-1])).sum())
    print(f"півотів на відкладеному {want} · шматок {BLOCK} подій, грію "
          f"{WARM}")

    runs = {}
    for feed in args.feeds:
        runs[feed] = run_feed(feed, coins, pairs, norm, got["names"],
                              tune, want, args.epochs, args.seed, train)

    best = max(runs.values(), key=lambda one: one["marks"]["tune"]["pooled"]
               ["caught"]["50"])
    keep_dir = MODELS / "calls"
    keep_dir.mkdir(parents=True, exist_ok=True)
    torch.save(best["model"].state_dict(), keep_dir / "memory.pt")
    np.savez_compressed(keep_dir / "memory_norm.npz", mid=norm["mid"],
                        wide=norm["wide"], columns=best["columns"])
    print(f"\nзбережено набір «{best['feed']}»")

    # Чи знає памʼять, **де** був розворот: той самий зсув зігзага назад.
    moved = {}
    rows = {}
    for pair in pairs:
        data, mask = coins[pair]["data"], coins[pair]["show"]
        ema = np.asarray(data["ema"], dtype=float)
        fires = train.zigzag_calls(ema, mask, train.ZIGZAG)
        rows[pair] = train.measure(
            train.shifted(fires, best["strength"][pair], mask, train.BACK),
            data, mask, train.BEFORE, train.AFTER)
    moved["памʼять"] = {"by_pair": rows,
                        "pooled": train.pooled(list(rows.values()))}

    old = json.loads((args.out / "calls_train.json").read_text(
        encoding="utf-8"))
    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "seed": args.seed, "zone": {"before": train.BEFORE,
                                    "after": train.AFTER},
        "shape": {"hid": HID, "layers": LAYERS, "drop": DROP, "lr": LR,
                  "decay": DECAY, "block": BLOCK, "warm": WARM,
                  "batch": BATCH, "epochs": args.epochs},
        "feeds": {"сире": list(RAW), "разом": "усі 47 ознак MLP"},
        "best": best["feed"], "tolerance": list(train.TOLERANCE),
        "runs": {key: {one: value[one] for one in
                       ("feed", "epoch", "curve", "level", "features",
                        "marks")}
                 for key, value in runs.items()},
        "marks": best["marks"], "epoch": best["epoch"],
        "level": best["level"], "curve": best["curve"],
        "moved": moved, "back": train.BACK,
        "mlp": {key: {"level": value["level"], "epoch": value["epoch"],
                      "features": value["features"],
                      "marks": value["marks"]}
                for key, value in old["runs"].items()},
        "others": {key: {"pooled": value["pooled"]}
                   for key, value in old["others"].items()},
        "mlp_moved": {key: {"pooled": value["pooled"]}
                      for key, value in old["moved"].items()},
        "weights": str((keep_dir / "memory.pt").relative_to(PROJECT_ROOT))}
    path = args.out / "calls_memory.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                    encoding="utf-8")

    print("\nval разом:")
    for feed, run in runs.items():
        one = run["marks"]["val"]["pooled"]
        print(f"  памʼять {feed:7s} ±15 {one['caught']['15']} · ±50 "
              f"{one['caught']['50']} · сигналів {one['fires']} · у зоні "
              f"{one['in_zone']} · взято {one['money']['share']} %")
    for feed, run in old["runs"].items():
        one = run["marks"]["val"]["pooled"]
        print(f"  MLP {feed:11s} ±15 {one['caught']['15']} · ±50 "
              f"{one['caught']['50']} · сигналів {one['fires']} · у зоні "
              f"{one['in_zone']} · взято {one['money']['share']} %")
    for key in ("зігзаг", "монетка"):
        two = old["others"][key]["pooled"]
        print(f"  {key:15s} ±15 {two['caught']['15']} · ±50 "
              f"{two['caught']['50']} · сигналів {two['fires']} · у зоні "
              f"{two['in_zone']} · взято {two['money']['share']} %")
    two = moved["памʼять"]["pooled"]
    print(f"\nзсув зігзага в найгучнішу подію памʼяті: ±5 "
          f"{two['caught']['5']} · ±15 {two['caught']['15']} · медіана "
          f"|зсуву| {two['gap_abs']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
