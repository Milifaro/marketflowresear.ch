"""Стан ноги з видачі обраної мережі: розбір без навчання.

Дослідження: research/33-buy-sell-signal/
Правила: rules/05-visualization.md → компоновка

Мережа `LSTM · сире · зона «частка»` навчена казати «зона розвороту».
Тут її видача **не вчиться далі**, а описується: беруться два числа на
подію і дивиться, як вони поводяться вздовж ноги зігзага 2.3 % і
навколо самого розвороту.

## Що рахується

    знак     `продаж − купівля`, згладжений ема`SMOOTH`: додатне —
             «йде нога вгору», відʼємне — «йде нога вниз»
    вздовж   середнє число в бік своєї ноги по десятинах ноги і частка
             подій, де зверху правильний бік
    навколо  те саме по відстані до півота, у клітинках по `STEP` подій,
             плюс найгучніше з двох чисел — впевненість
    перехід  де знак перевертається зі старого боку на новий і як
             далеко це від самого півота
    ціна     скільки ноги лишається, якщо входити через N подій

Усе на **val** усіх монет; train не чіпається взагалі.

Вхід : results/calls_input_<PAIR>.npz, models/calls/cell_<обрана>.pt
Вихід: results/calls_state.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_state.py
    python3 research/33-buy-sell-signal/scripts/calls_state.py --pairs BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
CELL = "lstm"                 # обраний прогін етапу 9
FEED = "сире"
ZONE = "частка"
SEED = 17
SMOOTH = 20                   # згладжування знака, у подіях
# Правило ноги — переможець драбини `calls_rules.py`: знак згладженої
# різниці з гістерезисом, тобто перемикання лише коли різниця відійшла
# від нуля. Стан тримається, поки не прийшло перемикання в інший бік.
RULE = {"win": 10, "level": 0.1}
STEP = 10                     # клітинка профілю навколо півота
REACH = 150                   # наскільки далеко від півота дивимось
DECILES = 10
LAGS = (20, 35, 60)           # через скільки подій після півота заходимо
DIP = (0.35, 0.25)            # рівні просідання впевненості
PARTS = ("val", "all")        # ряд: тільки val або весь датасет монети
SCRIPT = "research/33-buy-sell-signal/scripts/calls_state.py"


def ema(values: np.ndarray, win: int = SMOOTH) -> np.ndarray:
    """Причинне згладжування: дірки тягнуть попереднє значення."""
    out = np.full(len(values), np.nan)
    weight = 2.0 / (win + 1)
    run = None
    for at, one in enumerate(values):
        if np.isfinite(one):
            run = one if run is None else weight * one + (1 - weight) * run
        out[at] = np.nan if run is None else run
    return out


def legs_of(pivots: np.ndarray, ups: np.ndarray, keep: np.ndarray) -> list:
    """Ноги val: відрізок між сусідніми півотами й напрямок кожного."""
    place = np.flatnonzero(keep)
    if not len(place):
        return []
    inside = (pivots >= place[0]) & (pivots <= place[-1])
    piv, up = pivots[inside], ups[inside]
    out = []
    for at in range(len(piv) - 1):
        # `pivot_up` — нижній півот; нога після нього йде вгору
        out.append({"from": int(piv[at]), "to": int(piv[at + 1]),
                    "side": 1 if up[at] else -1,
                    "at": int(piv[at]), "next": int(piv[at + 1]),
                    "prev": int(piv[at - 1]) if at else int(piv[at])})
    return out


def rule_state(data: dict, gap: np.ndarray) -> np.ndarray:
    """Нога за правилом-переможцем драбини `calls_rules.py`."""
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    import calls_rules

    line = calls_rules.ema(gap, RULE["win"])
    flips = np.where(np.isfinite(line) & (line >= RULE["level"]), 1,
                     np.where(np.isfinite(line) & (line <= -RULE["level"]),
                              -1, 0))
    return calls_rules.held(flips)


def marked(total: int, pivots: np.ndarray, ups: np.ndarray) -> np.ndarray:
    """Нога розмітки на кожній події: `1` — вгору, `-1` — вниз, `0` — поза.

    Нижній півот (`pivot_up`) відкриває ногу вгору, верхній — вниз.
    Поза крайніми півотами ноги немає: там її напрямок невідомий.
    """
    out = np.zeros(total, dtype=np.int8)
    for at in range(len(pivots) - 1):
        start, stop = int(pivots[at]), int(pivots[at + 1])
        out[start:stop] = 1 if ups[at] else -1
    return out


def share_of(state: np.ndarray, mine: np.ndarray, side: int):
    """Частка подій ноги цього боку, де стан мережі називає її правильно."""
    mask = (mine == side) & (state != 0)
    if not mask.any():
        return None
    return round(float(np.mean(state[mask] == side)), 4)


def along_legs(legs: list, gap: dict) -> list:
    """Профіль по десятинах ноги, нарізно на ногах вгору й вниз."""
    rows = []
    for step in range(DECILES):
        got = {1: [], -1: []}
        for leg in legs:
            piece = gap[leg["pair"]][leg["from"]:leg["to"]] * leg["side"]
            if len(piece) < DECILES:
                continue
            index = np.linspace(0, DECILES, len(piece),
                                endpoint=False).astype(int)
            mask = np.isfinite(piece) & (index == step)
            if mask.sum():
                got[leg["side"]].append(piece[mask])
        row = {"from": step * 10, "to": step * 10 + 10}
        for side, key in ((1, "up"), (-1, "down")):
            piece = np.concatenate(got[side]) if got[side] else np.array([])
            row[key] = round(float(piece.mean()), 4) if len(piece) else None
            row[f"{key}_share"] = round(float(np.mean(piece > 0)), 4) \
                if len(piece) else None
            row[f"{key}_events"] = int(len(piece))
        rows.append(row)
    return rows


def around_pivot(legs: list, gap: dict, hot: dict) -> list:
    """Профіль навколо розвороту: число нової ноги і впевненість."""
    edges = np.arange(-REACH, REACH + 1, STEP)
    rows = []
    for at in range(len(edges) - 1):
        own, loud = [], []
        for leg in legs[1:]:            # у першої ноги немає попередньої
            start = leg["at"] + int(edges[at])
            stop = leg["at"] + int(edges[at + 1])
            start, stop = max(start, 0), min(stop, len(gap[leg["pair"]]))
            if stop <= start:
                continue
            piece = gap[leg["pair"]][start:stop] * leg["side"]
            piece = piece[np.isfinite(piece)]
            if len(piece):
                own.append(float(piece.mean()))
            piece = hot[leg["pair"]][start:stop]
            piece = piece[np.isfinite(piece)]
            if len(piece):
                loud.append(float(piece.mean()))
        rows.append({"from": int(edges[at]), "to": int(edges[at + 1]),
                     "own": round(float(np.mean(own)), 4) if own else None,
                     "hot": round(float(np.mean(loud)), 4) if loud else None,
                     "pivots": len(own)})
    return rows


def switches_of(legs: list, smooth: dict) -> dict:
    """Де знак перевертається зі старого боку на новий — і як далеко."""
    near, counts, marks = [], [], []
    for leg in legs[1:]:
        own = smooth[leg["pair"]] * leg["side"]
        low, high = leg["prev"] + 1, leg["next"]
        sign = np.sign(own[low:high])
        index = np.arange(low, high)
        flips = index[1:][(sign[:-1] < 0) & (sign[1:] > 0)]
        counts.append(len(flips))
        for one in flips:
            marks.append({"pair": leg["pair"], "at": int(one),
                          "side": int(leg["side"])})
        if len(flips):
            near.append(int(flips[np.argmin(np.abs(flips - leg["at"]))]
                            - leg["at"]))
    near = np.asarray(near, dtype=float)
    return {
        "pivots": len(legs) - 1, "found": int(len(near)),
        "total": int(sum(counts)),
        "per_pivot": round(sum(counts) / max(len(legs) - 1, 1), 2),
        "per_leg_median": float(np.median(counts)) if counts else None,
        "median": round(float(np.median(near)), 1) if len(near) else None,
        "low": round(float(np.percentile(near, 25)), 1) if len(near) else None,
        "high": round(float(np.percentile(near, 75)), 1) if len(near)
        else None,
        "in_15": round(float(np.mean(np.abs(near) <= 15)), 4) if len(near)
        else None,
        "in_50": round(float(np.mean(np.abs(near) <= 50)), 4) if len(near)
        else None,
        "early": round(float(np.mean(near < 0)), 4) if len(near) else None,
        "marks": marks}


def dip_of(legs: list, hot: dict) -> dict:
    """Просідання впевненості після розвороту — і чи воно там лише."""
    was, now, inside, legs_seen = [], [], 0, 0
    for leg in legs[1:]:
        piece = hot[leg["pair"]][max(leg["prev"], leg["at"] - 100):leg["at"]]
        piece = piece[np.isfinite(piece)]
        after = hot[leg["pair"]][leg["at"]:min(leg["at"] + 60, leg["next"])]
        after = after[np.isfinite(after)]
        if len(piece) > 5 and len(after) > 5:
            was.append(float(piece.mean()))
            now.append(float(after.min()))
        body = hot[leg["pair"]][leg["at"] + 60:leg["next"] - 30]
        body = body[np.isfinite(body)]
        if len(body) > 20:
            legs_seen += 1
            inside += int(body.min() < DIP[1])
    now = np.asarray(now)
    return {"before": round(float(np.mean(was)), 4) if was else None,
            "after": round(float(now.mean()), 4) if len(now) else None,
            "pivots": len(now),
            "under": {str(one): round(float(np.mean(now < one)), 4)
                      for one in DIP} if len(now) else {},
            "inside_legs": legs_seen, "inside_hit": inside}


def ranked(values: np.ndarray) -> np.ndarray:
    """Ранги з усередненням однакових: без цього рівні числа дають AUC 0."""
    order = np.argsort(values, kind="mergesort")
    line = values[order]
    out = np.empty(len(values), dtype=float)
    at = 0
    while at < len(line):
        stop = at
        while stop + 1 < len(line) and line[stop + 1] == line[at]:
            stop += 1
        out[order[at:stop + 1]] = (at + stop) / 2 + 1
        at = stop + 1
    return out


def tail_auc(legs: list, gap: dict) -> dict:
    """AUC «остання десятина ноги проти решти» за самим числом."""
    high, rest = [], []
    for leg in legs:
        piece = gap[leg["pair"]][leg["from"]:leg["to"]] * leg["side"]
        piece = piece[np.isfinite(piece)]
        if len(piece) < DECILES:
            continue
        cut = int(len(piece) * 0.9)
        high.append(piece[cut:])
        rest.append(piece[:cut])
    if not high:
        return {"auc": None}
    high, rest = np.concatenate(high), np.concatenate(rest)
    rank = ranked(np.concatenate([high, rest]))
    auc = (rank[:len(high)].sum() - len(high) * (len(high) + 1) / 2) \
        / (len(high) * len(rest))
    return {"auc": round(float(auc), 4), "tail": int(len(high)),
            "body": int(len(rest))}


def left_of(legs: list, price: dict) -> list:
    """Скільки ноги лишається, якщо входити через N подій після півота."""
    rows = []
    for lag in LAGS:
        share = []
        for leg in legs:
            start, stop = leg["from"], leg["to"]
            if stop - start < lag + 5:
                continue
            move = price[leg["pair"]][stop] - price[leg["pair"]][start]
            if not move:
                continue
            took = price[leg["pair"]][stop] - price[leg["pair"]][start + lag]
            share.append(float(took / move))
        rows.append({"lag": lag, "legs": len(share),
                     "share": round(float(np.median(share)), 4)
                     if share else None})
    return rows


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def series_of(pair: str, part: str, data: dict, gap: np.ndarray,
              smooth: np.ndarray, hot: np.ndarray, marks: list,
              proba: np.ndarray | None = None) -> dict:
    """Ряд однієї монети: `val` — після межі розбиття, `all` — увесь."""
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["price"], dtype=float)
    index = np.flatnonzero(stamps >= data["cut"]) if part == "val" \
        else np.arange(len(stamps))
    inside = (data["pivot_at"] >= index[0]) & (data["pivot_at"] <= index[-1])
    mine = marked(len(stamps), data["pivot_at"], data["pivot_up"])
    state = np.asarray(rule_state(data, gap), dtype=np.int8)
    both = (mine != 0) & (state != 0)
    return {
        "script": SCRIPT, "ready": True, "pair": pair, "part": part,
        "state": [int(one) for one in state[index]],
        "markup": [int(one) for one in mine[index]],
        "agree": round(float(np.mean(state[index][both[index]]
                                     == mine[index][both[index]])), 4)
        if both[index].any() else None,
        "agree_up": share_of(state[index], mine[index], 1),
        "agree_down": share_of(state[index], mine[index], -1),
        "in_legs": int(both[index].sum()),
        "cut": int(data["cut"]), "smooth": SMOOTH,
        "events": int(len(index)),
        "from": int(stamps[index[0]]), "to": int(stamps[index[-1]]),
        "t": [int(one) for one in stamps[index]],
        "price": rounded(price[index], 2),
        "ema": rounded(np.asarray(data["ema"], dtype=float)[index], 2),
        "gap": rounded(gap[index]), "smooth": rounded(smooth[index]),
        "hot": rounded(hot[index]),
        "buy": rounded(proba[index, 1]) if proba is not None else None,
        "sell": rounded(proba[index, 2]) if proba is not None else None,
        # `ema` обовʼязкове: зігзаг малюється по ема10, і саме з цього
        # поля полотно бере висоту півота
        "pivots": [{"t": int(stamps[one]),
                    "price": round(float(price[one]), 2),
                    "ema": round(float(np.asarray(data["ema"],
                                                  dtype=float)[one]), 2),
                    "kind": "low" if low else "high"}
                   for one, low in zip(data["pivot_at"][inside],
                                       data["pivot_up"][inside])],
        "switches": [{"t": int(stamps[one["at"]]),
                      "price": round(float(price[one["at"]]), 2),
                      "side": one["side"]}
                     for one in marks if one["pair"] == pair
                     and one["at"] >= index[0] and one["at"] <= index[-1]]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_cells as cells
    import calls_memory as memory
    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    kept = np.load(MODELS / "calls" / "cell_norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    weights = MODELS / "calls" / f"cell_{CELL}_{FEED}_{ZONE}.pt"
    if not weights.exists():
        raise SystemExit(f"немає ваг: {weights} — спершу calls_cells.py")

    gap, smooth, hot, price, legs, kept_data = {}, {}, {}, {}, [], {}
    kept_proba = {}
    for pair in pairs:
        data = train.load(pair, args.out)
        built = train.features_of(data)
        columns = memory.columns_of(built["names"], FEED)
        piece = train.applied(built["x"], norm)[:, columns]
        model = cells.build(piece.shape[1], CELL, SEED)
        model.load_state_dict(torch.load(weights, map_location="cpu"))
        good = np.isfinite(built["x"]).all(axis=1) & data["core"]
        cache = args.out / f"calls_proba_{pair}.npz"
        proba = np.load(cache)["proba"] if cache.exists() \
            else memory.walked(model, piece, good)
        show = good & (np.asarray(data["t"]) >= data["cut"])
        kept_proba[pair] = proba
        gap[pair] = proba[:, 2] - proba[:, 1]
        smooth[pair] = ema(gap[pair])
        hot[pair] = np.nanmax(proba[:, 1:], axis=1)
        price[pair] = np.asarray(data["price"], dtype=float)
        kept_data[pair] = data
        mine = legs_of(data["pivot_at"], data["pivot_up"], show)
        for one in mine:
            one["pair"] = pair
        legs += mine
        print(f"  {pair}: val {int(show.sum())} подій · ніг {len(mine)}")

    lane = {"up": [0, 0], "down": [0, 0]}
    for pair in pairs:
        data = kept_data[pair]
        mine = marked(len(data["t"]), data["pivot_at"], data["pivot_up"])
        keep = np.asarray(data["t"]) >= data["cut"]
        now = np.asarray(rule_state(data, gap[pair]), dtype=np.int8)
        for side, key in ((1, "up"), (-1, "down")):
            mask = keep & (mine == side) & (now != 0)
            lane[key][0] += int((now[mask] == side).sum())
            lane[key][1] += int(mask.sum())
    lane = {key: {"events": value[1],
                  "share": round(value[0] / value[1], 4) if value[1] else None}
            for key, value in lane.items()}

    moves = [abs(price[one["pair"]][one["to"]]
                 / price[one["pair"]][one["from"]] - 1) * 100 for one in legs]
    sizes = [one["to"] - one["from"] for one in legs]
    switch = switches_of(legs, smooth)
    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "weights": str(weights.relative_to(PROJECT_ROOT)), "rule": RULE,
        "cell": CELL, "feed": FEED, "zone": ZONE, "smooth": SMOOTH,
        "step": STEP, "reach": REACH, "dip_levels": list(DIP),
        "legs": {"count": len(legs),
                 "up": sum(1 for one in legs if one["side"] > 0),
                 "down": sum(1 for one in legs if one["side"] < 0),
                 "median_events": int(np.median(sizes)) if sizes else None,
                 "median_move": round(float(np.median(moves)), 2)
                 if moves else None},
        "along": along_legs(legs, gap),
        "around": around_pivot(legs, gap, hot),
        "switch": {key: value for key, value in switch.items()
                   if key != "marks"},
        "dip": dip_of(legs, hot), "tail": tail_auc(legs, gap),
        "lane": lane, 
        "left": left_of(legs, price),
        "by_pair": {one: {"legs": sum(1 for leg in legs
                                      if leg["pair"] == one)}
                    for one in pairs},
        "parts": [{"key": "val", "title": "тільки val"},
                  {"key": "all", "title": "увесь ряд"}],
        "series": {"pairs": list(pairs),
                   "url": "/api/cells/state/<PAIR>/<частина>"}}
    path = args.out / "calls_state.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

    # Ряди — окремими файлами: увесь ряд шести монет в одну відповідь не
    # кладеться, а вкладці за раз потрібен рівно один.
    for pair in pairs:
        for part in PARTS:
            block = series_of(pair, part, kept_data[pair], gap[pair],
                              smooth[pair], hot[pair], switch["marks"],
                              kept_proba[pair])
            spot = args.out / f"calls_state_series_{pair}_{part}.json"
            spot.write_text(json.dumps(block, ensure_ascii=False),
                            encoding="utf-8")
            print(f"  ряд {pair} · {part}: {block['events']} подій → "
                  f"{spot.name}")

    one = report["switch"]
    shape = report["legs"]
    print(f"\nніг {shape['count']} · медіана {shape['median_events']} подій "
          f"і {shape['median_move']} % ходу")
    print(f"AUC «остання десятина проти решти»: {report['tail']['auc']}")
    print(f"перехід знака: медіана {one['median']:+} подій від півота · "
          f"квартилі {one['low']:+} / {one['high']:+} · у ±50 {one['in_50']} "
          f"· раніше за півот {one['early']}")
    print(f"переходів усього {one['total']} на {one['pivots']} розворотів")
    print(f"впевненість: до {report['dip']['before']} · мінімум після "
          f"{report['dip']['after']}")
    for row in report["left"]:
        print(f"вхід через {row['lag']:3d} подій: лишається "
              f"{row['share'] and round(row['share'] * 100, 1)} % ноги")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
