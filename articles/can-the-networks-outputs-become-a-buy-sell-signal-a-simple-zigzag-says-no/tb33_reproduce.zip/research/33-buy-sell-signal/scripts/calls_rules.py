"""Правило ноги: як із видачі моделі дістати ногу зігзага і її розворот.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → відображення результатів

Розбір стану показав: знак `продаж − купівля` веде ноги вниз (69.6 %
подій) і не веде ноги вгору (37.8 %), а перемикання спізнюється на
медіанних 34.5 події. Тут шукається **правило**, яке з тих самих двох
чисел дає ногу ближче до зігзага 2.3 %.

Правило причинне: на кожній події воно бачить тільки минуле й видає
стан `+1` (йде нога вгору, ціль — верхній півот), `-1` (нога вниз) або
`0` (ще не знає). Місця, де стан міняється, — це його розвороти.

## Міра

    нога      частка подій val, де стан збігається з ногою зігзага,
              окремо на ногах вгору й вниз
    розворот  скільки півотів має перемикання в ±15 і ±50 подій,
              медіана |зсуву| і скільки перемикань припадає на розворот
    гроші     скільки ноги лишається, якщо входити на перемиканні
    оцінка    `збіг ноги × узято півотів ±50` — одне число, за яким
              обирається переможець кола

Кола йдуть послідовно: у першому міряються сімейства правил, у другому
переможець першого кола обростає другим механізмом, і так далі. Кожне
коло лежить у видачі цілком, разом із програшними рядками.

Вхід : results/calls_input_<PAIR>.npz, models/calls/cell_<обрана>.pt
Вихід: results/calls_rules.json, results/calls_proba_<PAIR>.npz (кеш)

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_rules.py
    python3 research/33-buy-sell-signal/scripts/calls_rules.py --rounds 1
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
CELL, FEED, ZONE = "lstm", "сире", "частка"
SEED = 17
TOLERANCE = (15, 50)
TUNE = 0.2                    # яка частина train відкладена на вибір правила
LAG = 35                      # з якою затримкою рахуємо залишок ноги
SCRIPT = "research/33-buy-sell-signal/scripts/calls_rules.py"


# ------------------------------------------------------------------ правила

def ema(values: np.ndarray, win: int) -> np.ndarray:
    out = np.full(len(values), np.nan)
    weight = 2.0 / (win + 1)
    run = None
    for at, one in enumerate(values):
        if np.isfinite(one):
            run = one if run is None else weight * one + (1 - weight) * run
        out[at] = np.nan if run is None else run
    return out


def held(flips: np.ndarray) -> np.ndarray:
    """Стан тримається, поки не прийшло нове перемикання."""
    out = np.zeros(len(flips), dtype=np.int8)
    now = 0
    for at, one in enumerate(flips):
        if one:
            now = int(one)
        out[at] = now
    return out


def by_sign(buy, sell, win=20, **_):
    """Знак згладженої різниці — те, що описував розбір стану."""
    return np.where(np.isfinite(ema(sell - buy, win)),
                    np.sign(ema(sell - buy, win)), 0).astype(np.int8)


def by_hyst(buy, sell, win=20, level=0.1, **_):
    """Перемикання лише коли згладжена різниця відійшла від нуля на `level`."""
    line = ema(sell - buy, win)
    flips = np.where(np.isfinite(line) & (line >= level), 1,
                     np.where(np.isfinite(line) & (line <= -level), -1, 0))
    return held(flips)


def by_run(buy, sell, need=15, **_):
    """Знак мусить повторитись `need` подій поспіль."""
    sign = np.where(np.isfinite(sell - buy), np.sign(sell - buy), 0)
    flips = np.zeros(len(sign), dtype=np.int8)
    count, was = 0, 0
    for at, one in enumerate(sign):
        count = count + 1 if one == was and one != 0 else 1
        was = one
        if one != 0 and count >= need:
            flips[at] = one
    return held(flips)


def by_level(buy, sell, level=0.5, **_):
    """Перемикання за самим числом: «продаж» вище `level` — нога вгору."""
    flips = np.zeros(len(buy), dtype=np.int8)
    flips[np.isfinite(sell) & (sell >= level)] = 1
    flips[np.isfinite(buy) & (buy >= level)] = -1
    return held(flips)


def by_hyst_run(buy, sell, win=20, level=0.1, need=10, **_):
    """Гістерезис плюс підтвердження: обидва механізми разом."""
    line = ema(sell - buy, win)
    flips = np.zeros(len(line), dtype=np.int8)
    count, was = 0, 0
    for at, one in enumerate(line):
        side = 0
        if np.isfinite(one) and one >= level:
            side = 1
        elif np.isfinite(one) and one <= -level:
            side = -1
        count = count + 1 if side == was and side != 0 else 1
        was = side
        if side != 0 and count >= need:
            flips[at] = side
    return held(flips)


def by_level_hyst(buy, sell, level=0.5, drop=0.2, **_):
    """Вхід за числом, вихід — коли воно впало нижче `drop`."""
    flips = np.zeros(len(buy), dtype=np.int8)
    now = 0
    for at in range(len(buy)):
        one, two = sell[at], buy[at]
        if np.isfinite(one) and one >= level:
            now = 1
        elif np.isfinite(two) and two >= level:
            now = -1
        elif now == 1 and np.isfinite(one) and one < drop:
            now = 0
        elif now == -1 and np.isfinite(two) and two < drop:
            now = 0
        flips[at] = now
    return flips.astype(np.int8)


def by_split(buy, sell, win=10, up=0.1, down=0.1, **_):
    """Асиметричні пороги: свій на кожен бік — проти перекосу видачі."""
    line = ema(sell - buy, win)
    flips = np.where(np.isfinite(line) & (line >= up), 1,
                     np.where(np.isfinite(line) & (line <= -down), -1, 0))
    return held(flips)


def by_price(buy, sell, price=None, step=0.012, **_):
    """Контроль без моделі: причинний зігзаг на ема ціни."""
    out = np.zeros(len(price), dtype=np.int8)
    side, top, low = 0, price[0], price[0]
    for at, one in enumerate(price):
        if not np.isfinite(one):
            out[at] = side
            continue
        top, low = max(top, one), min(low, one)
        if side >= 0 and one <= top * (1 - step):
            side, low, top = -1, one, one
        elif side <= 0 and one >= low * (1 + step):
            side, low, top = 1, one, one
        out[at] = side
    return out


def by_gate(buy, sell, price=None, win=10, level=0.1, step=0.004, **_):
    """Модель плюс ціна: перемикання, коли **обидва** сказали одне.

    Модель дає бік, ціна підтверджує відходом від крайньої точки на
    `step`. Без згоди стан не міняється.
    """
    line = ema(sell - buy, win)
    out = np.zeros(len(price), dtype=np.int8)
    side, top, low = 0, price[0], price[0]
    for at in range(len(price)):
        one = price[at]
        if np.isfinite(one):
            top, low = max(top, one), min(low, one)
        said = 0
        if np.isfinite(line[at]) and line[at] >= level:
            said = 1
        elif np.isfinite(line[at]) and line[at] <= -level:
            said = -1
        if said == 1 and np.isfinite(one) and one >= low * (1 + step) \
                and side != 1:
            side, low, top = 1, one, one
        elif said == -1 and np.isfinite(one) and one <= top * (1 - step) \
                and side != -1:
            side, low, top = -1, one, one
        out[at] = side
    return out


def by_always(buy, sell, side=1, **_):
    """Контроль: стала відповідь. Ніг вгору в ряді більше, ніж униз."""
    return np.where(np.isfinite(buy), np.int8(side), np.int8(0)).astype(np.int8)


MAKERS = {"знак": by_sign, "гістерезис": by_hyst, "підтвердження": by_run,
          "число": by_level, "гістерезис+підтвердження": by_hyst_run,
          "число з відпусканням": by_level_hyst, "стала": by_always,
          "асиметрія": by_split, "ціна": by_price, "модель+ціна": by_gate}
# Правилам, що дивляться на ціну, потрібна ще й вона
NEEDS_PRICE = ("ціна", "модель+ціна")
SEEDS = 5                     # роздач монетки на правило


# -------------------------------------------------------------------- міра

def marked(total: int, pivots: np.ndarray, ups: np.ndarray) -> np.ndarray:
    out = np.zeros(total, dtype=np.int8)
    for at in range(len(pivots) - 1):
        out[int(pivots[at]):int(pivots[at + 1])] = 1 if ups[at] else -1
    return out


def switches_of(state: np.ndarray, keep: np.ndarray) -> list:
    """Події, де стан змінився на протилежний бік."""
    out, was = [], 0
    for at in np.flatnonzero(keep):
        now = int(state[at])
        if now and now != was:
            if was:
                out.append({"at": int(at), "side": now})
            was = now
    return out


def score_of(rows: list) -> dict:
    """Числа всіх монет разом: події важать подіями, півоти — півотами."""
    legs = {}
    for key in ("up", "down"):
        hit = sum(one["legs"][key]["hit"] for one in rows)
        seen = sum(one["legs"][key]["events"] for one in rows)
        legs[key] = {"events": seen,
                     "share": round(hit / seen, 4) if seen else None}
    hit = sum(one["legs"][key]["hit"] for one in rows for key in ("up", "down"))
    seen = sum(one["legs"][key]["events"] for one in rows
               for key in ("up", "down"))
    legs["all"] = {"events": seen,
                   "share": round(hit / seen, 4) if seen else None}
    pivots = sum(one["pivots"] for one in rows)
    caught = {str(one): round(sum(row["caught"][str(one)] for row in rows)
                              / pivots, 4) if pivots else None
              for one in TOLERANCE}
    pieces = [one["gaps"] for one in rows if len(one["gaps"])]
    gaps = np.concatenate(pieces) if pieces else np.array([])
    switches = sum(one["switches"] for one in rows)
    pieces = [one["left"] for one in rows if len(one["left"])]
    left = np.concatenate(pieces) if pieces else np.array([])
    return {"legs": legs, "pivots": pivots, "switches": switches,
            "per_pivot": round(switches / pivots, 2) if pivots else None,
            "caught": caught,
            "gap_abs": round(float(np.median(np.abs(gaps))), 1) if len(gaps)
            else None,
            "left": round(float(np.median(left)), 4) if len(left) else None,
            "mark": round((legs["all"]["share"] or 0)
                          * (caught[str(TOLERANCE[-1])] or 0), 4)}


def measure(state: np.ndarray, coin: dict, part: str = "keep") -> dict:
    """Одна монета: збіг ноги, влучання в півоти, залишок ноги на вході."""
    keep, mine = coin[part], coin["markup"]
    legs = {}
    for side, key in ((1, "up"), (-1, "down")):
        mask = keep & (mine == side) & (state != 0)
        legs[key] = {"events": int(mask.sum()),
                     "hit": int((state[mask] == side).sum())}
    fires = switches_of(state, keep)
    place = np.asarray([one["at"] for one in fires], dtype=np.int64)
    sides = np.asarray([one["side"] for one in fires], dtype=np.int8)
    piv, ups = coin["pivots"], coin["ups"]
    inside = np.flatnonzero(keep)
    seen = (piv >= inside[0]) & (piv <= inside[-1]) if len(inside) \
        else np.zeros(len(piv), dtype=bool)
    piv, ups = piv[seen], ups[seen]
    gaps, caught, left = [], {str(one): 0 for one in TOLERANCE}, []
    for at, low in zip(piv, ups):
        want = 1 if low else -1               # нижній півот відкриває ногу вгору
        same = place[sides == want] if len(place) else place
        if not len(same):
            continue
        gap = int(same[np.argmin(np.abs(same - at))] - at)
        gaps.append(gap)
        for one in TOLERANCE:
            caught[str(one)] += int(abs(gap) <= one)
    price = coin["price"]
    for at in range(len(piv) - 1):
        start, stop = int(piv[at]), int(piv[at + 1])
        move = price[stop] - price[start]
        after = place[(place >= start) & (place < stop)]
        if not move or not len(after):
            continue
        left.append(float((price[stop] - price[int(after[0])]) / move))
    return {"legs": legs, "pivots": int(len(piv)), "switches": len(fires),
            "caught": caught, "gaps": np.asarray(gaps, dtype=float),
            "left": np.asarray(left, dtype=float)}


def coin_state(coin: dict, switches: int, seed: int,
               part: str = "keep") -> np.ndarray:
    """Монетка тієї самої частоти: стільки ж перемикань, місця випадкові."""
    place = np.flatnonzero(coin[part])
    out = np.zeros(len(coin[part]), dtype=np.int8)
    if not len(place):
        return out
    rng = np.random.default_rng(seed)
    cuts = np.sort(rng.choice(place, size=min(switches, len(place)),
                              replace=False)) if switches else np.array([])
    side = 1 if rng.random() < 0.5 else -1
    was = int(place[0])
    for one in list(cuts) + [int(place[-1]) + 1]:
        out[was:int(one)] = side
        side = -side
        was = int(one)
    return out


def on_part(states: dict, coins: dict, part: str) -> dict:
    """Числа одного шматка разом із монеткою тієї самої частоти."""
    got = score_of([measure(states[pair], one, part)
                    for pair, one in coins.items()])
    flips = {pair: len(switches_of(states[pair], coins[pair][part]))
             for pair in coins}
    draws = [score_of([measure(coin_state(one, flips[pair], seed, part),
                               one, part)
                       for pair, one in coins.items()])
             for seed in range(SEEDS)]
    coin = {"legs": round(float(np.mean([one["legs"]["all"]["share"]
                                         for one in draws])), 4),
            "caught": {str(step): round(float(np.mean(
                [one["caught"][str(step)] for one in draws])), 4)
                for step in TOLERANCE}}
    lift = {str(step): round((got["caught"][str(step)] or 0)
                             / coin["caught"][str(step)], 2)
            if coin["caught"][str(step)] else None for step in TOLERANCE}
    # Оцінка — **надлишок** над монеткою тієї самої частоти, а не
    # відношення: відношення нагороджує рідкі правила (мала підлога),
    # абсолютне влучання — часті (велика підлога). Різниця чесна до обох.
    step = str(TOLERANCE[-1])
    got.update({"coin": coin, "lift": lift,
                "mark": round((got["caught"][step] or 0)
                              - coin["caught"][step], 4)})
    return got


def run_rule(name: str, kind: str, knobs: dict, coins: dict) -> dict:
    """Правило на обох шматках: вибір — за відкладеним, показ — на val."""
    states = {}
    for pair, one in coins.items():
        extra = dict(knobs)
        if kind in NEEDS_PRICE:
            extra["price"] = one["ema"]
        states[pair] = MAKERS[kind](one["buy"], one["sell"], **extra)
    tune = on_part(states, coins, "tune")
    got = on_part(states, coins, "keep")
    got.update({"name": name, "kind": kind, "knobs": knobs, "tune": tune,
                "pick": tune["mark"]})
    return got


def show(got: dict) -> None:
    legs = got["legs"]
    print(f"  {got['name']:34s} відкладене {got['pick']:+.3f} │ val: нога "
          f"{legs['all']['share']:.3f} (вгору {legs['up']['share']:.3f} · "
          f"вниз {legs['down']['share']:.3f}) · ±50 {got['caught']['50']:.3f}"
          f" − монетка {got['coin']['caught']['50']:.3f} = "
          f"{got['mark']:+.3f} (×{got['lift']['50']}) · перемикань "
          f"{got['switches']}")


# -------------------------------------------------------------------- вхід

def coins_of(pairs: tuple, out: Path) -> dict:
    """Видача моделі на кожній монеті; порахована один раз і в кеші."""
    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_cells as cells
    import calls_memory as memory
    import calls_train as train

    kept = np.load(MODELS / "calls" / "cell_norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    weights = MODELS / "calls" / f"cell_{CELL}_{FEED}_{ZONE}.pt"
    coins = {}
    for pair in pairs:
        data = train.load(pair, out)
        cache = out / f"calls_proba_{pair}.npz"
        if cache.exists():
            proba = np.load(cache)["proba"]
        else:
            built = train.features_of(data)
            columns = memory.columns_of(built["names"], FEED)
            piece = train.applied(built["x"], norm)[:, columns]
            model = cells.build(piece.shape[1], CELL, SEED)
            model.load_state_dict(torch.load(weights, map_location="cpu"))
            good = np.isfinite(built["x"]).all(axis=1) & data["core"]
            proba = memory.walked(model, piece, good)
            np.savez_compressed(cache, proba=proba.astype(np.float32))
        stamps = np.asarray(data["t"], dtype=np.int64)
        good = np.isfinite(proba[:, 1])
        learn = np.flatnonzero(good & (stamps < data["cut"]))
        edge = int(learn[int(len(learn) * (1 - TUNE))]) if len(learn) else 0
        place = np.arange(len(stamps))
        coins[pair] = {
            "buy": proba[:, 1].astype(float), "sell": proba[:, 2].astype(float),
            "ema": np.asarray(data["ema"], dtype=float),
            "tune": good & (stamps < data["cut"]) & (place >= edge),
            "keep": stamps >= data["cut"],
            "markup": marked(len(stamps), data["pivot_at"], data["pivot_up"]),
            "pivots": np.asarray(data["pivot_at"]),
            "ups": np.asarray(data["pivot_up"]),
            "price": np.asarray(data["price"], dtype=float)}
        print(f"  {pair}: val {int(coins[pair]['keep'].sum())} подій")
    return coins


def first_round() -> list:
    rows = []
    for win in (5, 20, 60, 150):
        rows.append((f"знак ема{win}", "знак", {"win": win}))
    for level in (0.05, 0.1, 0.2, 0.3):
        rows.append((f"гістерезис {level} на ема20", "гістерезис",
                     {"win": 20, "level": level}))
    for need in (5, 15, 40):
        rows.append((f"підтвердження {need} подій", "підтвердження",
                     {"need": need}))
    for level in (0.3, 0.5, 0.7):
        rows.append((f"число ≥ {level}", "число", {"level": level}))
    for up, down in ((0.05, 0.2), (0.2, 0.05), (0.1, 0.3), (0.3, 0.1)):
        rows.append((f"асиметрія ↑{up} ↓{down}", "асиметрія",
                     {"win": 10, "up": up, "down": down}))
    for step in (0.004, 0.008, 0.012, 0.023):
        rows.append((f"контроль: зігзаг ціни {step * 100:.1f} %", "ціна",
                     {"step": step}))
    for step in (0.002, 0.004, 0.008):
        rows.append((f"модель + ціна {step * 100:.1f} %", "модель+ціна",
                     {"win": 10, "level": 0.1, "step": step}))
    rows.append(("контроль: завжди вгору", "стала", {"side": 1}))
    rows.append(("контроль: завжди вниз", "стала", {"side": -1}))
    return rows


def near_round(best: dict) -> list:
    """Сітка навколо переможця для правил, що дивляться на ціну."""
    rows = []
    knobs = best["knobs"]
    if best["kind"] == "ціна":
        step = float(knobs.get("step", 0.012))
        for one in sorted({round(step * 0.6, 4), step, round(step * 1.6, 4)}):
            rows.append((f"контроль: зігзаг ціни {one * 100:.1f} %", "ціна",
                         {"step": one}))
        return rows
    win = int(knobs.get("win", 10))
    level = float(knobs.get("level", 0.1))
    step = float(knobs.get("step", 0.004))
    for one in sorted({max(win // 2, 3), win, win * 2}):
        for two in sorted({round(level / 2, 3), level, round(level * 2, 3)}):
            for three in sorted({round(step / 2, 4), step,
                                 round(step * 2, 4)}):
                rows.append((f"модель ема{one} ≥{two} + ціна "
                             f"{three * 100:.2f} %", "модель+ціна",
                             {"win": one, "level": two, "step": three}))
    return rows


def next_round(best: dict, number: int) -> list:
    """Наступне коло: сітка навколо переможця, плюс другий механізм.

    Крок сітки звужується з колом: спершу навколо переможця широко,
    далі — дрібніше. Переможець попереднього кола завжди йде в наступне,
    інакше коло могло б «покращити» результат у гірший бік.
    """
    rows = []
    step = 2.0 if number <= 2 else 1.5
    if best["kind"] in ("ціна", "модель+ціна"):
        return near_round(best)
    if best["kind"] == "асиметрія":
        win = int(best["knobs"].get("win", 10))
        up = float(best["knobs"].get("up", 0.1))
        down = float(best["knobs"].get("down", 0.1))
        for one in sorted({max(win // 2, 3), win, win * 2}):
            for two in sorted({round(up / 2, 3), up, round(up * 2, 3)}):
                for three in sorted({round(down / 2, 3), down,
                                     round(down * 2, 3)}):
                    rows.append((f"асиметрія ема{one} ↑{two} ↓{three}",
                                 "асиметрія",
                                 {"win": one, "up": two, "down": three}))
        return rows
    if best["kind"] in ("знак", "гістерезис", "гістерезис+підтвердження"):
        win = int(best["knobs"].get("win", 20))
        level = float(best["knobs"].get("level", 0.1))
        need = int(best["knobs"].get("need", 1))
        wins = sorted({max(int(win / step), 3), win, int(win * step)})
        levels = sorted({round(max(level / step, 0.02), 3), level,
                         round(min(level * step, 0.9), 3)})
        needs = sorted({max(int(need / step), 1), need,
                        max(int(need * step), need + 5)})
        for one in wins:
            for two in levels:
                for three in needs:
                    rows.append((f"ема{one}, поріг {two}, підтвердження "
                                 f"{three}", "гістерезис+підтвердження",
                                 {"win": one, "level": two, "need": three}))
    else:
        level = float(best["knobs"].get("level", 0.5))
        drop = float(best["knobs"].get("drop", 0.15))
        for one in sorted({round(max(level - 0.15, 0.1), 3), level,
                           round(min(level + 0.15, 0.9), 3)}):
            for two in sorted({round(max(drop - 0.1, 0.02), 3), drop,
                               round(min(drop + 0.1, one - 0.05), 3)}):
                rows.append((f"число ≥ {one}, відпускання {two}",
                             "число з відпусканням",
                             {"level": one, "drop": two}))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    coins = coins_of(pairs, args.out)

    rounds, best = [], None
    plan = first_round()
    for number in range(1, args.rounds + 1):
        print(f"\n=== коло {number}: правил {len(plan)}")
        rows = [run_rule(name, kind, knobs, coins) for name, kind, knobs
                in plan]
        for one in sorted(rows, key=lambda x: -x["pick"]):
            show(one)
        now = max(rows, key=lambda one: one["pick"])
        if best is None or now["pick"] > best["pick"]:
            best = now
        rounds.append({"round": number, "rules": rows,
                       "best": now["name"], "mark": now["mark"],
                       "pick": now["pick"]})
        print(f"  → краще на відкладеному: {now['name']} "
              f"(надлишок {now['pick']:+.3f}, на val {now['mark']:+.3f})")
        plan = next_round(best, number + 1)

    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "cell": CELL, "feed": FEED, "zone": ZONE,
        "tolerance": list(TOLERANCE), "lag": LAG,
        "base": next(one for one in rounds[0]["rules"]
                     if one["name"] == "знак ема20"),
        "best": {"name": best["name"], "kind": best["kind"],
                 "knobs": best["knobs"], "mark": best["mark"]},
        "rounds": rounds}
    path = args.out / "calls_rules.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    print(f"\nпереможець: {best['name']} · оцінка {best['mark']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
