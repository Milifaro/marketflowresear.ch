"""Торгівля ногою: одна угода на ногу з видачі двох голів.

Дослідження: research/33-buy-sell-signal/
Правила: rules/04-trading.md → Бектест

Мережа `legs_heads.py` каже на кожній події два числа: `p_side` — бік
ноги, якій подія належить, і `p_zone` — чи це зона розвороту. Правило
торгує **ногою за мережею**, а не розміткою. Бік ноги читається одним
із двох способів, і обидва перебираються нарізно:

    рівень    ема(`p_side`, `ema`) вище `up` — нога вгору, нижче
              `down` — нога вниз, між ними бік не міняється. Рівні
              несиметричні: `p_side` на нозі вгору стоїть близько 0.65,
              на нозі вниз — близько 0.30, тому 0.5 посередині не
              обовʼязково найкраще місце для обох порогів
    перетин   швидка ема `fast` проти повільної `slow` того самого
              `p_side`: вище — нога вгору, нижче — вниз. Рівень тут не
              потрібен узагалі, тому зсув видачі між монетами й
              шматками ряду правило не ламає
    пік       зігзаг на самій ема-лінії: тримається біжучий максимум
              лінії, і коли вона впала від нього на `back`, пік
              **оголошується** — нога вниз; дзеркально для мінімуму.
              Пік у мить піка не видно нікому: ціна цього способу —
              затримка, рівно стільки подій, скільки лінії треба, щоб
              відкотитись на `back`. Ця затримка міряється окремо

Далі — те саме для обох:

    вхід    бік перемкнувся й тримається `hold` подій підряд (а якщо
            `enter_zone` > 0 — ще й зона не нижча за нього):
            бік угору — лонг, бік вниз — шорт
    вихід   зона ≥ `exit_zone` і угода прожила щонайменше `floor`
            подій — або зміна боку, яка відкриває наступну угоду

Одна нога мережі — рівно одна угода: поки бік не перемкнувся, другого
входу немає. Розмітки зігзага в правилі немає **ніде**.

Ручки перебираються колами на **відкладеному шматку train**: оцінка —
середній PnL шести монет із комісією й сліпеджем, але зараховується
лише варіант, який **справді торгує ногами**: угод від `BAND[0]` до
`BAND[1]` кількості ніг зігзага 2.3 % у вікні. Без цієї умови грід
сходиться до «майже не торгувати»: на відкладеному шматку будь-яке
сидіння в кеші вигідніше за торгівлю. Val у виборі не бере участі.

Поруч тим самим механізмом торгує **ема ціни** — класичний перетин
двох ем `ema10` з тим самим гридом: це суперник, який мережі не
бачить, і він показує, що́ видача голови додає понад саму ціну.

Вхід : results/calls_input_<PAIR>.npz, models/legs_heads/model.pt
Вихід: results/legs_calls.json,
       results/legs_calls_series_<PAIR>_<val|all>.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/legs_calls.py
    python3 research/33-buy-sell-signal/scripts/legs_calls.py --rounds 1
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
SEED = 17
BAND = (0.5, 2.0)             # угод на ногу: межі, у яких варіант рахується
NEVER = 1.1                   # поріг виходу вище одиниці — виходу по зоні немає
KNOBS = {"kind": "рівень",    # як читається бік ноги: рівень або перетин
         "ema": 200,          # згладження `p_side` для рівнів
         "up": 0.5,           # вище — нога вгору
         "down": 0.5,         # нижче — нога вниз (між ними бік тримається)
         "fast": 50,          # швидка ема для перетину
         "slow": 400,         # повільна ема для перетину
         "back": 0.05,        # відкат лінії від крайньої точки для «пік був»
         "zone_ema": 1,       # згладження `p_zone`
         "hold": 10,          # скільки подій бік має встояти до входу
         "enter_zone": 0.0,   # зона, потрібна для входу; 0 — не потрібна
         "exit_zone": NEVER,  # зона, на якій угода закривається
         "floor": 0}          # скільки подій угода живе до виходу по зоні
# Кола сімейства «рівень»: спершу згладження, далі кожен поріг окремо.
LEVEL_ROUNDS = (
    {"group": "згладження боку", "key": "ema",
     "values": (40, 100, 200, 400)},
    {"group": "поріг угору", "key": "up",
     "values": (0.45, 0.5, 0.55, 0.6, 0.65, 0.7)},
    {"group": "поріг униз", "key": "down",
     "values": (0.5, 0.45, 0.4, 0.35, 0.3, 0.25)},
    {"group": "згладження боку ще раз", "key": "ema",
     "values": (40, 100, 200, 400)},
)
# Кола сімейства «пік»: згладження лінії й розмір відкату.
PEAK_ROUNDS = (
    {"group": "згладження лінії", "key": "ema",
     "values": (40, 100, 200, 400)},
    {"group": "відкат від піка", "key": "back",
     "values": (0.01, 0.02, 0.05, 0.1, 0.2)},
    {"group": "згладження лінії ще раз", "key": "ema",
     "values": (40, 100, 200, 400)},
)
# Кола сімейства «перетин»: дві ем самої видачі.
CROSS_ROUNDS = (
    {"group": "швидка ема", "key": "fast", "values": (5, 15, 40, 100, 200)},
    {"group": "повільна ема", "key": "slow",
     "values": (100, 200, 400, 800, 1600)},
)
# Спільні кола: від переможця сімейства.
SHARED_ROUNDS = (
    {"group": "підтвердження входу", "key": "hold", "values": (1, 10, 30, 90)},
    {"group": "згладження зони", "key": "zone_ema", "values": (1, 10, 40)},
    {"group": "зона на вході", "key": "enter_zone",
     "values": (0.0, 0.3, 0.5)},
    {"group": "вихід по зоні", "key": "exit_zone",
     "values": (NEVER, 0.5, 0.7, 0.85)},
    {"group": "мінімальна довжина угоди", "key": "floor",
     "values": (0, 50, 150)},
)
FAMILIES = ({"key": "рівень", "rounds": LEVEL_ROUNDS,
             "title": "рівень: ема `p_side` проти двох порогів"},
            {"key": "перетин", "rounds": CROSS_ROUNDS,
             "title": "перетин: швидка ема `p_side` проти повільної"},
            {"key": "пік", "rounds": PEAK_ROUNDS,
             "title": "пік: відкат ема-лінії від її крайньої точки"})
# Суперник без мережі: той самий перетин, але на самій ціні (ема10).
PRICE_ROUNDS = (
    {"group": "швидка ема ціни", "key": "fast",
     "values": (15, 40, 100, 200, 400)},
    {"group": "повільна ема ціни", "key": "slow",
     "values": (200, 400, 800, 1600, 3200)},
)
PARTS = ("val", "all")
SCRIPT = "research/33-buy-sell-signal/scripts/legs_calls.py"


# ------------------------------------------------------------------ правило

def ema_of(values: np.ndarray, span: int) -> np.ndarray:
    """Причинна ема: у події видно тільки її саму й те, що було.

    Пропуск тягне попереднє значення, а до першого числа нічого немає.
    `span = 1` — без згладження.
    """
    line = np.asarray(values, dtype=float)
    if span <= 1:
        return line.copy()
    alpha = 2.0 / (span + 1.0)
    out = np.full(len(line), np.nan)
    was = np.nan
    for at, one in enumerate(line):
        if np.isfinite(one):
            was = one if not np.isfinite(was) else was + alpha * (one - was)
        out[at] = was
    return out


def level_leg(line: np.ndarray, up: float, down: float) -> np.ndarray:
    """Бік за рівнями: вище `up` — вгору, нижче `down` — вниз.

    Між порогами бік **тримається** той, що був: без цього дрібне
    тремтіння навколо середини перевертало б ногу щокілька подій.
    `0` — бік ще невідомий (жодного порога не пройдено).
    """
    out = np.zeros(len(line), dtype=np.int8)
    held = 0
    for at, one in enumerate(line):
        if np.isfinite(one):
            if one >= up:
                held = 1
            elif one <= down:
                held = -1
        out[at] = held
    return out


def cross_leg(fast: np.ndarray, slow: np.ndarray) -> np.ndarray:
    """Бік за перетином: швидка ема вище повільної — нога вгору."""
    good = np.isfinite(fast) & np.isfinite(slow)
    out = np.where(fast > slow, 1, -1).astype(np.int8)
    out[~good] = 0
    return out


def peak_leg(line: np.ndarray, back: float) -> np.ndarray:
    """Пік лінії, оголошений відкатом: зігзаг на самій ема-лінії.

    Тримається біжучий максимум лінії; щойно вона впала від нього на
    `back`, пік вважається пройденим — нога вниз. Дзеркально для
    мінімуму. Майбутнього тут немає, і тому сам пік завжди
    оголошується **пізніше**, ніж він стався: ціна способу — затримка
    рівно на той відкат, якого чекали.
    """
    out = np.zeros(len(line), dtype=np.int8)
    top = bottom = np.nan
    held = 0
    for at, one in enumerate(line):
        if np.isfinite(one):
            top = one if not np.isfinite(top) else max(top, one)
            bottom = one if not np.isfinite(bottom) else min(bottom, one)
            if held <= 0 and one >= bottom + back:
                held, top = 1, one
            elif held >= 0 and one <= top - back:
                held, bottom = -1, one
        out[at] = held
    return out


def peaks_of(line: np.ndarray, leg: np.ndarray) -> list:
    """Де насправді був пік лінії між двома оголошеннями — і як пізно.

    Міра, а не правило: справжній пік видно лише заднім числом, і саме
    тому він рахується тут, а не всередині `peak_leg`.
    """
    out = []
    ходи = np.flatnonzero(np.diff(leg.astype(int)) != 0) + 1
    was = 0
    for at in ходи:
        at = int(at)
        if not leg[at] or leg[at] == was:
            was = int(leg[at])
            continue
        start = out[-1]["at"] if out else 0
        piece = line[start:at + 1]
        good = np.flatnonzero(np.isfinite(piece))
        if len(good):
            pick = good[np.argmax(piece[good])] if leg[at] < 0 \
                else good[np.argmin(piece[good])]
            out.append({"at": at, "peak": int(start + pick),
                        "late": int(at - start - pick), "side": int(leg[at])})
        was = int(leg[at])
    return out


def leg_of(line: np.ndarray, knobs: dict) -> np.ndarray:
    """Бік ноги з видачі голови — тим способом, який названо в ручках."""
    if knobs["kind"] == "перетин":
        return cross_leg(ema_of(line, int(knobs["fast"])),
                         ema_of(line, int(knobs["slow"])))
    if knobs["kind"] == "пік":
        return peak_leg(ema_of(line, int(knobs["ema"])), float(knobs["back"]))
    return level_leg(ema_of(line, int(knobs["ema"])),
                     float(knobs["up"]), float(knobs["down"]))


def trades_of(leg: np.ndarray, zone: np.ndarray, mask: np.ndarray,
              knobs: dict | None = None) -> list:
    """Угоди: вхід на зміні боку, вихід на зоні кінця ноги.

    Одна нога — рівно одна угода: поки бік не перемкнувся, другого
    входу немає. Майбутнього правило не бачить — кожна подія читається
    на своєму місці.
    """
    knobs = dict(KNOBS, **(knobs or {}))
    hold = int(knobs["hold"])
    door, exit_at = float(knobs["enter_zone"]), float(knobs["exit_zone"])
    floor = int(knobs["floor"])
    out = []
    held, since = 0, None          # бік відкритої угоди й подія входу
    was, run = 0, 0                # бік ноги й скільки подій він тримається
    done = 0                       # на якій нозі вже була угода
    for place in np.flatnonzero(mask):
        at = int(place)
        side, two = int(leg[at]), zone[at]
        if not side or not np.isfinite(two):
            continue
        if side != was:
            was, run = side, 1     # нога перемкнулась — лічильник з нуля
        else:
            run += 1
        if held and (was != held
                     or (two >= exit_at and at - since >= floor)):
            out.append({"in": int(since), "out": at, "side": held})
            held, since = 0, None
        if not held and was != done and run >= hold and two >= door:
            held, since, done = was, at, was
    if held:
        last = int(np.flatnonzero(mask)[-1])
        out.append({"in": int(since), "out": last, "side": held})
    return out


def fires_of(trades: list) -> list:
    """Угоди як сигнали для симуляції: вхід боком, вихід у кеш."""
    out = []
    for one in trades:
        out.append({"at": int(one["in"]), "side": int(one["side"]),
                    "kind": "in"})
        out.append({"at": int(one["out"]), "side": 0, "kind": "out"})
    return out


# -------------------------------------------------------------------- гроші

def walked(trades: list, price: np.ndarray, mask: np.ndarray,
           stamps: np.ndarray, cash) -> dict:
    """Симуляція `calls_money.py` на сигналах правила, без змін умов."""
    return cash.run(fires_of(trades), price, mask, stamps,
                    cash.FEE + cash.SLIP, cash.START)


def scored(legs: dict, zones: dict, coins: dict, pairs: tuple, part: str,
           knobs: dict, cash) -> dict:
    """Правило на одному шматку: гроші кожної монети й середнє по них."""
    rows, made = {}, {}
    for pair in pairs:
        one = coins[pair]
        trades = trades_of(legs[pair], zones[pair], one[part], knobs)
        made[pair] = trades
        rows[pair] = walked(trades, one["price"], one[part], one["stamps"],
                            cash)
        rows[pair]["legs"] = int(one["legs"][part])
    told = [rows[pair]["pnl_share"] for pair in pairs]
    deals = [rows[pair]["trades"] for pair in pairs]
    drops = [rows[pair]["drawdown"] for pair in pairs]
    legs_seen = int(np.sum([rows[pair]["legs"] for pair in pairs]))
    steps = [one["out"] - one["in"] for pair in pairs for one in made[pair]]
    return {"by_pair": rows, "trades": int(np.sum(deals)), "legs": legs_seen,
            "pnl_share": round(float(np.mean(told)), 2),
            "drawdown": round(float(np.mean(drops)), 2),
            "per_leg": round(float(np.sum(deals)) / legs_seen, 2)
            if legs_seen else None,
            "events": int(np.median(steps)) if steps else 0,
            "trades_by_pair": made}


def fits_band(block: dict) -> bool:
    """Чи торгує варіант саме ногами — угод у межах `BAND` на ногу."""
    return bool(block["legs"]) and (
        BAND[0] * block["legs"] <= block["trades"] <= BAND[1] * block["legs"])


def sane(knobs: dict) -> bool:
    """Набір, який узагалі має сенс: швидка ема мусить бути швидшою."""
    if knobs["kind"] == "перетин" and int(knobs["fast"]) >= int(knobs["slow"]):
        return False
    return float(knobs["up"]) >= float(knobs["down"])


def rounds_of(rounds: tuple, knobs: dict, judge, log=print) -> tuple:
    """Кола перебору: коло бере переможця попереднього і міняє свою ручку.

    Переможець шукається **тільки серед тих, хто торгує ногами**, і вже
    серед них — за PnL. Якщо в колі не торгує ногами жоден варіант,
    береться найближчий до однієї угоди на ногу: інакше коло виграє
    вироджене «одна угода на весь ряд», у якої PnL завжди рівний.
    """
    knobs, made = dict(knobs), []
    for one in rounds:
        rows, best = [], None
        for value in one["values"]:
            said = dict(knobs, **{one["key"]: value})
            if not sane(said):
                continue
            block = judge(said)
            row = {"name": f"{one['key']} {value}", "value": value,
                   "trades": block["trades"], "legs": block["legs"],
                   "per_leg": block["per_leg"], "events": block["events"],
                   "fits": fits_band(block),
                   "pnl_share": block["pnl_share"],
                   "drawdown": block["drawdown"]}
            rows.append(row)
            log(f"  {one['group']:24s} {one['key']} {value}: угод "
                f"{row['trades']:4d} на {row['legs']:3d} ніг "
                f"({row['per_leg']} на ногу, медіана {row['events']} подій)"
                f" · PnL {row['pnl_share']:+7.2f} % · просадка "
                f"{row['drawdown']:5.2f} %"
                f"{'' if row['fits'] else '  ← не торгує ногами'}")
        if not rows:
            continue
        fitted = [row for row in rows if row["fits"]]
        best = max(fitted, key=lambda row: row["pnl_share"]) if fitted \
            else min(rows, key=lambda row: abs((row["per_leg"] or 0) - 1))
        knobs[one["key"]] = best["value"]
        made.append({"group": one["group"], "key": one["key"], "rows": rows,
                     "best": best["name"], "fitted": bool(fitted)})
        log(f"коло «{one['group']}»: {best['name']}\n")
    return knobs, made


# -------------------------------------------------------------------- вихід

def series_of(pair: str, part: str, data: dict, trades: list,
              proba: np.ndarray, knobs: dict) -> dict:
    """Угоди ряду: вхід і вихід окремими мітками з числами мережі."""
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["price"], dtype=float)
    index = np.flatnonzero(stamps >= data["cut"]) if part == "val" \
        else np.arange(len(stamps))
    low, high = int(index[0]), int(index[-1])
    out, deals = [], []
    for one in trades:
        if int(one["in"]) < low or int(one["in"]) > high:
            continue
        got = []
        for key, kind, side in (("in", "in", one["side"]), ("out", "out", 0)):
            at = int(one[key])
            got.append({"t": int(stamps[at]), "side": int(side), "kind": kind,
                        "price": round(float(price[at]), 2),
                        "p_side": round(float(proba[at, 0]), 4),
                        "p_zone": round(float(proba[at, 1]), 4)})
        out.extend(got)
        deals.append({"from": got[0]["t"], "to": got[1]["t"],
                      "side": int(one["side"]),
                      "got": round(float((price[int(one["out"])]
                                          / price[int(one["in"])] - 1)
                                         * one["side"] * 100), 3)})
    return {"script": SCRIPT, "ready": True, "pair": pair, "part": part,
            "knobs": knobs, "fires": out, "deals": deals,
            "from": int(stamps[low]), "to": int(stamps[high])}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--families", nargs="+", default=None)
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_memory as memory       # noqa: F401  (потрібен legs_heads)
    import calls_money as cash
    import calls_train as train
    import legs_heads as heads

    pairs = tuple(args.pairs or train.PAIRS)
    got = train.gather(pairs, args.out)
    coins = got["coins"]
    kept = np.load(MODELS / "legs_heads" / "norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    columns = kept["columns"].astype(int)
    report = json.loads((args.out / "legs_heads.json").read_text(
        encoding="utf-8"))
    model = heads.build(len(columns), report["seed"], report["knobs"])
    model.load_state_dict(torch.load(MODELS / "legs_heads" / "model.pt",
                                     map_location="cpu"))
    model.eval()

    proba = {}
    for pair in pairs:
        one = coins[pair]
        data = one["data"]
        piece = train.applied(one["x"], norm)[:, columns]
        side, _ = heads.target_of(len(data["t"]), data["pivot_at"],
                                  data["pivot_up"])
        for key in ("keep", "tune", "show"):
            one[key] = one[key] & (side >= 0)
        one["price"] = np.asarray(data["price"], dtype=float)
        one["ema"] = np.asarray(data["ema"], dtype=float)
        one["stamps"] = np.asarray(data["t"], dtype=np.int64)
        # Ноги зігзага 2.3 % у вікні — тільки щоб було видно, скільки
        # угод припадає на ногу. У правилі їх немає.
        one["legs"] = {}
        for key in ("tune", "show"):
            place = np.flatnonzero(one[key])
            inside = (data["pivot_at"] >= place[0]) \
                & (data["pivot_at"] <= place[-1])
            one["legs"][key] = int(max(inside.sum() - 1, 0))
        proba[pair] = heads.walked(model, piece, one["good"])

    def judged(part: str, line):
        """Оцінка набору ручок: бік із `line`, зона — завжди з мережі."""
        def judge(knobs: dict) -> dict:
            legs = {pair: leg_of(line(pair), knobs) for pair in pairs}
            zones = {pair: ema_of(proba[pair][:, 1], int(knobs["zone_ema"]))
                     for pair in pairs}
            return scored(legs, zones, coins, pairs, part, knobs, cash)
        return judge

    said = judged("tune", lambda pair: proba[pair][:, 0])
    print(f"кола ручок на відкладеному шматку train, {len(pairs)} монет "
          f"(оцінка — середній PnL серед тих, хто торгує ногами: "
          f"{BAND[0]}–{BAND[1]} угоди на ногу):")

    families, best = [], None
    for one in FAMILIES:
        if args.families and one["key"] not in args.families:
            continue
        print(f"— сімейство «{one['key']}»")
        knobs, rounds = rounds_of(one["rounds"],
                                  dict(KNOBS, **{"kind": one["key"]}), said)
        knobs, shared = rounds_of(SHARED_ROUNDS, knobs, said)
        block = said(knobs)
        family = {"key": one["key"], "title": one["title"], "knobs": knobs,
                  "grid": rounds + shared, "fits": fits_band(block),
                  "trades": block["trades"], "legs": block["legs"],
                  "per_leg": block["per_leg"], "events": block["events"],
                  "pnl_share": block["pnl_share"],
                  "drawdown": block["drawdown"]}
        families.append(family)
        if best is None or (family["fits"], family["pnl_share"]) \
                > (best["fits"], best["pnl_share"]):
            best = family
        print(f"сімейство «{one['key']}»: PnL {family['pnl_share']:+.2f} % · "
              f"{family['per_leg']} угоди на ногу\n")

    knobs = best["knobs"]
    tune = said(knobs)
    tune.pop("trades_by_pair")
    show = judged("show", lambda pair: proba[pair][:, 0])(knobs)
    trades = show.pop("trades_by_pair")

    # Скільки коштує «пік»: на скільки подій оголошення відстає від
    # самої крайньої точки лінії і від півота зігзага. Обидва числа
    # рахуються заднім числом — це міра, а не частина правила.
    lag = {"by_pair": {}}
    lates, gaps = [], []
    for pair in pairs:
        one = coins[pair]
        line = ema_of(proba[pair][:, 0], int(knobs["ema"]))
        legs = leg_of(proba[pair][:, 0], knobs)
        place = np.flatnonzero(one["show"])
        told = [got for got in peaks_of(line, legs)
                if place[0] <= got["at"] <= place[-1]]
        near = []
        for got in told:
            if len(one["data"]["pivot_at"]):
                near.append(int(np.min(np.abs(one["data"]["pivot_at"]
                                              - got["at"]))))
        row = {"switches": len(told),
               "late": int(np.median([got["late"] for got in told]))
               if told else None,
               "to_pivot": int(np.median(near)) if near else None}
        lag["by_pair"][pair] = row
        lates += [got["late"] for got in told]
        gaps += near
    lag["late"] = int(np.median(lates)) if lates else None
    lag["to_pivot"] = int(np.median(gaps)) if gaps else None

    # Суперник без мережі: той самий перетин, але на ема10 самої ціни.
    print("— суперник «ема ціни» (мережі не бачить)")
    price_knobs = dict(KNOBS, **{"kind": "перетин", "hold": 1,
                                 "exit_zone": NEVER, "enter_zone": 0.0})
    price_line = judged("tune", lambda pair: coins[pair]["ema"])
    price_knobs, price_grid = rounds_of(PRICE_ROUNDS, price_knobs, price_line)
    price_show = judged("show", lambda pair: coins[pair]["ema"])(price_knobs)
    price_show.pop("trades_by_pair")

    # Решта контролів — у тих самих умовах на тому самому шматку val.
    rivals = {"ема ціни": dict(price_show, knobs=price_knobs,
                               grid=price_grid)}
    for name in ("купив і тримав", f"зігзаг {train.ZIGZAG * 100:.1f} %",
                 "монетка"):
        rows = {}
        for pair in pairs:
            one = coins[pair]
            if name == "купив і тримав":
                got_one = cash.hold(one["price"], one["show"], one["stamps"],
                                    cash.FEE + cash.SLIP)
            else:
                fires = train.zigzag_calls(one["ema"], one["show"],
                                           train.ZIGZAG) \
                    if name.startswith("зігзаг") \
                    else train.coin_calls(one["show"],
                                          show["by_pair"][pair]["trades"],
                                          args.seed)
                got_one = cash.run(fires, one["price"], one["show"],
                                   one["stamps"], cash.FEE + cash.SLIP)
            got_one["legs"] = int(one["legs"]["show"])
            rows[pair] = got_one
        deals = int(np.sum([rows[pair]["trades"] for pair in pairs]))
        rivals[name] = {
            "by_pair": rows, "trades": deals, "legs": show["legs"],
            "pnl_share": round(float(np.mean([rows[pair]["pnl_share"]
                                              for pair in pairs])), 2),
            "drawdown": round(float(np.mean([rows[pair]["drawdown"]
                                             for pair in pairs])), 2),
            "per_leg": round(deals / show["legs"], 2) if show["legs"]
            else None}

    block = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "seed": args.seed, "never": NEVER, "band": list(BAND),
        "weights": report["weights"], "edge": report["edge"],
        "knobs": knobs, "defaults": KNOBS, "family": best["key"],
        "families": families, "grid": best["grid"],
        "money": {"start": float(cash.START), "fee": float(cash.FEE),
                  "slip": float(cash.SLIP)},
        "tune": tune, "val": show, "rivals": rivals, "lag": lag,
        "parts": [{"key": "val", "title": "тільки val"},
                  {"key": "all", "title": "увесь ряд"}]}
    path = args.out / "legs_calls.json"
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")

    for pair in pairs:
        legs = leg_of(proba[pair][:, 0], knobs)
        zone = ema_of(proba[pair][:, 1], int(knobs["zone_ema"]))
        whole = trades_of(legs, zone, coins[pair]["good"], knobs)
        for part in PARTS:
            one = series_of(pair, part, coins[pair]["data"],
                            trades[pair] if part == "val" else whole,
                            proba[pair], knobs)
            (args.out / f"legs_calls_series_{pair}_{part}.json").write_text(
                json.dumps(one, ensure_ascii=False), encoding="utf-8")

    print(f"\nсімейство: {best['key']} · ручки: "
          + " · ".join(f"{key} {value}" for key, value in knobs.items()))
    print(f"val, ${float(cash.START):.0f} на монету, комісія "
          f"{float(cash.FEE) * 100:.3f} % + сліпедж "
          f"{float(cash.SLIP) * 100:.2f} % за бік:")
    for pair in pairs:
        one = show["by_pair"][pair]
        print(f"  {pair:10s} угод {one['trades']:3d} на {one['legs']:3d} ніг "
              f"· кінець ${one['end']:8.2f} · {one['pnl_share']:+7.2f} % · "
              f"виграшних {one['wins']} % · просадка {one['drawdown']} %")
    print(f"  {'середнє':22s} PnL {show['pnl_share']:+7.2f} % · просадка "
          f"{show['drawdown']} % · угод {show['trades']} "
          f"({show['per_leg']} на ногу)")
    print(f"  затримка: оголошення піка відстає від самої крайньої точки "
          f"лінії на {lag['late']} подій, від півота зігзага — на "
          f"{lag['to_pivot']}")
    for name, one in rivals.items():
        print(f"  {name:22s} PnL {one['pnl_share']:+7.2f} % · просадка "
              f"{one['drawdown']} % · угод {one['trades']} "
              f"({one['per_leg']} на ногу)")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
