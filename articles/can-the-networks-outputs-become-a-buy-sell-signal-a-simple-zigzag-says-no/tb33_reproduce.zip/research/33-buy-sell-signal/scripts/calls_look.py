"""Що кожна видача каже про розворот: розбір входу перед поєднанням.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → відображення результатів

Поєднувати видачі, не подивившись на них, немає сенсу: може статись, що
вони кажуть одне й те саме, або що жодна не тримає напрямку. Тут кожен
канал міряється **однією лінійкою** на train і на val окремо:

1. **Чи бачить канал зону розвороту.** AUC «подія в зоні проти решти»
   і поруч підлога — те саме AUC на **перемішаних** мітках. Зона
   несиметрична: `BEFORE` подій до півота і `AFTER` після (дослідження
   32 міряло її на фічах класу — 50 подій до і 15 після).
2. **Де канал піднімається.** Профіль середнього по відстані до
   найближчого півота, від `−REACH` до `+REACH` подій, і місце піка.
   Пік ліворуч від нуля — канал попереджає, праворуч — спізнюється.
3. **Скільки правди в його верхівці.** Частка подій зони серед
   найгучніших `TOP` % канала, поруч покриття (частка зони в ряді) і
   підйом = частка / покриття.
4. **Чи знає канал напрямок.** AUC «зона верхнього півота проти зони
   нижнього» на самих подіях зони. Близько 0.5 — напрямку в каналі
   немає, і його доведеться брати з ціни.
5. **Чи не кажуть канали одне й те саме.** Спірмен кожного з кожним на
   подіях, де є всі канали.

Числа рахуються на кожній монеті окремо й зводяться середнім: монет
порівну, і одна монета з довшим рядом не має важити більше.

Вхід : results/calls_input_<PAIR>.npz
Вихід: results/calls_look.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_look.py
    python3 research/33-buy-sell-signal/scripts/calls_look.py --pairs BTC_USDT
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
SEED = 17
BEFORE = 50                   # зона розвороту: подій до півота
AFTER = 15                    # і подій після
REACH = 300                   # профіль: наскільки далеко дивимось
STEPS = 20                    # ширина клітинки профілю в подіях
TOP = 5.0                     # верхівка каналу у відсотках
SCRIPT = "research/33-buy-sell-signal/scripts/calls_look.py"


def load(pair: str = PAIR, out: Path = RESULTS) -> dict:
    """Вхід однієї монети: канали на її осі подій і її ж півоти."""
    path = out / f"calls_input_{pair}.npz"
    if not path.exists():
        raise SystemExit(f"немає входу: {path} — спершу calls_data.py")
    got = np.load(path)
    report = json.loads((out / "calls_input.json").read_text(
        encoding="utf-8"))
    coin = report["coins"][pair]
    return {"pair": pair, "t": got["t"], "price": got["price"],
            "ema": got["ema"], "table": got["table"], "full": got["full"],
            "core": got["core"], "pivot_at": got["pivot_at"],
            "pivot_up": got["pivot_up"], "channels": report["channels"],
            "have": coin["have"], "cut": coin["cut"]}


# ------------------------------------------------------------------ мітки

SHARE = 0.10                  # хвіст зони як частка ноги, що в півот упирається
FLOOR = 5                     # але не коротше за це, інакше мітки просто немає


def tails_of(pivots: np.ndarray, share: float = SHARE,
             floor: int = FLOOR) -> np.ndarray:
    """Хвіст зони кожного півота — частка **його власної** ноги.

    Дослідження 32 (етап 9) міряло згасання зони нарізно на коротких,
    середніх і довгих ногах: 30 / 50 / 100 подій, тобто 10.0 / 9.5 /
    9.2 % довжини. У подіях розмах 3.3×, у частках — 1.09×, отже зона
    стоїть у **частці ноги**, а не в сталій кількості подій. Нога
    півота — відрізок від попереднього півота до нього; у першого
    півота ряду попереднього немає, тому береться видима частина.
    """
    piv = np.asarray(pivots, dtype=np.int64)
    if not len(piv):
        return np.zeros(0, dtype=np.int64)
    past = np.concatenate([[0], piv[:-1]])
    return np.maximum(np.rint((piv - past) * share), floor).astype(np.int64)


def backs_of(before, count: int) -> np.ndarray:
    """Хвіст на кожен півот: або стале число, або вже готовий масив."""
    if np.ndim(before) == 0:
        return np.full(count, int(before), dtype=np.int64)
    got = np.asarray(before, dtype=np.int64)
    if len(got) != count:
        raise ValueError(f"хвостів {len(got)}, а півотів {count}")
    return got


def zone_of(total: int, pivots: np.ndarray, before=BEFORE,
            after: int = AFTER) -> np.ndarray:
    """Маска зони розвороту: `before` подій до півота і `after` після.

    `before` — або стале число подій, або свій хвіст на кожен півот
    (`tails_of`).
    """
    out = np.zeros(total, dtype=bool)
    backs = backs_of(before, len(pivots))
    for one, back in zip(pivots, backs):
        out[max(0, one - int(back)):min(total, one + after + 1)] = True
    return out


def side_of(total: int, pivots: np.ndarray, up: np.ndarray,
            before=BEFORE, after: int = AFTER) -> np.ndarray:
    """`1` — зона нижнього півота (купівля), `-1` — верхнього, `0` — ні."""
    out = np.zeros(total, dtype=np.int8)
    backs = backs_of(before, len(pivots))
    for one, low, back in zip(pivots, up, backs):
        out[max(0, one - int(back)):min(total, one + after + 1)] = 1 if low \
            else -1
    return out


def steps_to(total: int, pivots: np.ndarray) -> np.ndarray:
    """Відстань до найближчого півота зі знаком: `<0` — півот попереду."""
    if not len(pivots):
        return np.full(total, np.nan)
    place = np.arange(total)
    near = np.searchsorted(pivots, place)
    left = pivots[np.clip(near - 1, 0, len(pivots) - 1)]
    right = pivots[np.clip(near, 0, len(pivots) - 1)]
    pick = np.where(np.abs(place - left) <= np.abs(place - right),
                    left, right)
    return (place - pick).astype(float)


# ------------------------------------------------------------------ лінійка

def auc_of(score: np.ndarray, label: np.ndarray) -> float:
    """AUC через ранги; без сторонніх бібліотек."""
    good = np.isfinite(score)
    score, label = score[good], label[good].astype(bool)
    if not label.any() or label.all():
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    rank = np.empty(len(score), dtype=float)
    rank[order] = np.arange(1, len(score) + 1)
    # однакові числа отримують середній ранг — інакше AUC залежить від
    # порядку рядків, а не від самого каналу
    values = score[order]
    start = 0
    for stop in range(1, len(values) + 1):
        if stop == len(values) or values[stop] != values[start]:
            rank[order[start:stop]] = (start + stop + 1) / 2.0
            start = stop
    hit, miss = int(label.sum()), int((~label).sum())
    return float((rank[label].sum() - hit * (hit + 1) / 2) / (hit * miss))


def floor_of(score: np.ndarray, label: np.ndarray, seed: int = SEED,
             times: int = 5) -> float:
    """Підлога: те саме AUC на перемішаних мітках."""
    rng = np.random.default_rng(seed)
    got = []
    for _ in range(times):
        got.append(auc_of(score, rng.permutation(label)))
    return float(np.nanmean(got))


def profile_of(score: np.ndarray, gap: np.ndarray, reach: int = REACH,
               steps: int = STEPS) -> dict:
    """Середнє каналу по відстані до півота, клітинками по `steps` подій."""
    rows, edges = [], np.arange(-reach, reach + steps, steps)
    for start, stop in zip(edges[:-1], edges[1:]):
        keep = (gap >= start) & (gap < stop) & np.isfinite(score)
        rows.append({"from": int(start), "to": int(stop),
                     "events": int(keep.sum()),
                     "mean": round(float(np.mean(score[keep])), 4)
                     if keep.any() else None})
    told = [one for one in rows if one["mean"] is not None]
    peak = max(told, key=lambda one: one["mean"]) if told else None
    return {"rows": rows,
            "peak": None if peak is None
            else {"from": peak["from"], "to": peak["to"],
                  "mean": peak["mean"]}}


def top_of(score: np.ndarray, zone: np.ndarray, top: float = TOP) -> dict:
    """Скільки правди у верхівці каналу проти покриття зони."""
    good = np.isfinite(score)
    if not good.any():
        return {"share": None, "cover": None, "lift": None}
    level = float(np.nanpercentile(score[good], 100.0 - top))
    loud = good & (score >= level)
    cover = float(zone[good].mean())
    share = float(zone[loud].mean()) if loud.any() else float("nan")
    return {"level": round(level, 4), "events": int(loud.sum()),
            "share": round(share, 4), "cover": round(cover, 4),
            "lift": round(share / cover, 3) if cover else None}


def spearman(one: np.ndarray, two: np.ndarray) -> float:
    good = np.isfinite(one) & np.isfinite(two)
    if good.sum() < 10:
        return float("nan")
    first = np.argsort(np.argsort(one[good])).astype(float)
    second = np.argsort(np.argsort(two[good])).astype(float)
    first -= first.mean()
    second -= second.mean()
    below = float(np.sqrt((first ** 2).sum() * (second ** 2).sum()))
    return float((first * second).sum() / below) if below else float("nan")


# ------------------------------------------------------------------- замір

def look(data: dict, before: int = BEFORE, after: int = AFTER) -> dict:
    total = len(data["t"])
    train = data["t"] < data["cut"]
    zone = zone_of(total, data["pivot_at"], before, after)
    side = side_of(total, data["pivot_at"], data["pivot_up"], before, after)
    gap = steps_to(total, data["pivot_at"])
    out = {}
    for key in data["have"]:
        column = data["channels"].index(key)
        score = data["table"][:, column].astype(float)
        block = {}
        for part, keep in (("train", train), ("val", ~train)):
            piece, label = score[keep], zone[keep]
            block[part] = {
                "events": int(np.isfinite(piece).sum()),
                "auc": round(auc_of(piece, label), 4),
                "floor": round(floor_of(piece, label), 4),
                "top": top_of(piece, label),
                "profile": profile_of(piece, gap[keep], REACH, STEPS)}
            inside = keep & (side != 0)
            block[part]["side_auc"] = round(
                auc_of(score[inside], side[inside] > 0), 4)
        out[key] = block
    pairs = {}
    both = data["full"]
    for first in data["have"]:
        for second in data["have"]:
            if first >= second:
                continue
            one = data["table"][both, data["channels"].index(first)]
            two = data["table"][both, data["channels"].index(second)]
            pairs[f"{first}|{second}"] = round(spearman(one.astype(float),
                                                        two.astype(float)), 3)
    return {"pair": data["pair"], "channels": out, "pairs": pairs,
            "zone": {"before": before, "after": after,
                     "events": int(zone.sum()),
                     "share": round(float(zone.mean()), 4)},
            "pivots": {"all": int(len(data["pivot_at"])),
                       "train": int((data["t"][data["pivot_at"]]
                                     < data["cut"]).sum()),
                       "val": int((data["t"][data["pivot_at"]]
                                   >= data["cut"]).sum()),
                       "up": int(data["pivot_up"].sum())}}


def joined(rows: list) -> dict:
    """Пул монет: AUC і підйом важать однаково, бо монет порівну."""
    out = {}
    for key in rows[0]["channels"]:
        block = {}
        for part in ("train", "val"):
            said = [one["channels"][key][part] for one in rows]
            block[part] = {
                "auc": round(float(np.mean([two["auc"] for two in said])), 4),
                "floor": round(float(np.mean([two["floor"]
                                              for two in said])), 4),
                "side_auc": round(float(np.mean([two["side_auc"]
                                                 for two in said])), 4),
                "top": {"lift": round(float(np.mean(
                    [two["top"]["lift"] for two in said
                     if two["top"]["lift"] is not None])), 3)},
                "profile": {"peak": said[0]["profile"]["peak"]}}
        out[key] = block
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--before", type=int, default=BEFORE)
    parser.add_argument("--after", type=int, default=AFTER)
    args = parser.parse_args()

    rows, by_pair = [], {}
    for pair in args.pairs:
        got = look(load(pair, args.out), args.before, args.after)
        rows.append(got)
        by_pair[pair] = got
        print(f"{pair}: зона {got['zone']['share'] * 100:.1f} % ряду · "
              f"півотів {got['pivots']['all']} "
              f"({got['pivots']['val']} val)")
        for key, block in got["channels"].items():
            one, two = block["train"], block["val"]
            print(f"  {key:8s} AUC train {one['auc']:.4f} (підлога "
                  f"{one['floor']:.4f}) · val {two['auc']:.4f} · верхівка "
                  f"{two['top']['lift']} · напрямок {two['side_auc']:.4f}")
    report = {"script": SCRIPT, "ready": True, "pairs": list(args.pairs),
              "top": TOP, "reach": REACH, "steps": STEPS, "seed": SEED,
              "zone": rows[0]["zone"],
              "pivots": {"all": int(sum(one["pivots"]["all"]
                                        for one in rows)),
                         "train": int(sum(one["pivots"]["train"]
                                          for one in rows)),
                         "val": int(sum(one["pivots"]["val"]
                                        for one in rows))},
              "channels": joined(rows),
              "pairs_spearman": rows[0]["pairs"],
              "by_pair": by_pair}
    path = args.out / "calls_look.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                    encoding="utf-8")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
