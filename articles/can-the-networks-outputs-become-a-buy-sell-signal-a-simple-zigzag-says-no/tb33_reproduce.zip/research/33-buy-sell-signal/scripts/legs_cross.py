"""Перетини голови «бік ноги» з її ема — і перевірка їх моделями межі.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md, rules/05-visualization.md

Голова «бік ноги» дає число 0…1 на кожній події. Її власна ема
`SPAN` подій — повільна лінія того самого числа. Правило тут одне і
причинне:

    видача вище `EDGE` перетинає свою ему **зверху вниз** -> продаж
    видача нижче `EDGE` перетинає свою ему **знизу вгору** -> купівля

Два відбори гасять шум першої ланки, і обидва причинні:

    рівень  голова має ще стояти на боці ноги, що кінчається: падіння
            крізь ему з-під 0.5 нічого не каже про кінець ноги вгору
    тиша    перетин ближчий за `QUIET` подій до попереднього взятого
            не береться — моделі відповідають вікном ±`NEAR`, тож два
            таких перетини питають про ті самі події

На val BTC вони рубають 127 перетинів до 61, не втрачаючи жодного
знайденого розвороту й жодної закритої межі.

Це кандидати в точки розвороту, і нічого більше вони не знають. Далі
кожного кандидата питають **дві моделі етапу 7 дослідження 34** — ті
самі, що на вкладці `/border`, навчені на подіях краю всіх шести монет
до `VAL_FROM`:

    бік межі      P(подія належить нозі, що почалась)
                  до межі має бути низько, після — високо
    бік розвороту P(межа поруч — вершина)

Моделі межі працюють **не завжди**: у ряді вони пускаються рівно там,
де стався перетин, і тільки в його зоні. Поза зонами їхніх ліній
немає — вони вчились на подіях краю і поза краєм відповідають завжди
й гучно.

Перетин не називає подію розвороту — він каже **зону**: «нога, схоже,
кінчилась десь тут». Тому питання ставиться зоною ±`SEARCH` подій:
сходинка «боку межі» шукається по всіх положеннях межі в зоні, кожне
з них міряється своїм вікном ±`NEAR` (тим, на якому модель вчилась), і
модель сама називає ту подію, де сходинка сходиться найкраще.

Кандидат **підтверджений**, якщо обидві відповіді сходяться: сходинка
в зоні є, і «бік розвороту» називає той бік, якого чекає сигнал
(продаж — вершина, купівля — дно). Робота моделей тут — не сказати
«так», а **вказати подію** і відкинути зону, де розвороту немає.

Правда береться окремо: **межа** — це справжня точка розвороту ноги з
розмітки проєкту (зігзаг 2.3 % на ема10, півот перенесений на
екстремум `price_close` у вікні ±25 подій). Ні перетин, ні моделі її
не бачать — вона тільки для перевірки.

Розворот вважається **знайденим**, якщо така межа того самого боку
стоїть не далі ніж `MISS` подій від події, яку **назвала модель**, —
а не від самого перетину. Інакше вказівка за дві події від межі йшла б
у промах тільки тому, що перетин стоїть трохи далі за край зони.
Окремо лишається `hit` — чи була межа в зоні перетину взагалі: це
питання до першої ланки, а не до моделей.

Вхід : results/legs_heads_series_<PAIR>_val.json,
       data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Знайдений розворот **помічається**: подія, яку назвала модель, лягає
в ряд окремим списком `turns` і на графіку стоїть точкою на ціні.

Вихід: results/legs_cross.json,
       results/legs_cross_series_<PAIR>.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/legs_cross.py
    python3 research/33-buy-sell-signal/scripts/legs_cross.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
BORDER_SCRIPTS = PROJECT_ROOT / "research" / "34-pivot-signature" / "scripts"
sys.path.insert(0, str(BORDER_SCRIPTS))

SCRIPT = "research/33-buy-sell-signal/scripts/legs_cross.py"
PART = "val"
SPAN = 200          # ема видачі голови, подій
EDGE = 0.5          # рівень, що ділить «нога вгору» від «нога вниз»
NEAR = 10           # вікно однієї відповіді: стільки подій краю в моделі
SEARCH = 25         # зона пошуку навколо перетину — як `SNAP_SPAN` розмітки
MISS = 10           # наскільки точно має вказати модель, щоб це влучання
SHARE = 0.5         # рівно стільки дає рівна лінія: вище — вже сходинка
QUIET = 2 * NEAR    # два перетини ближче цього питають про ті самі події
LADDER = (10, 25, 50, 100, 200)   # драбина розмірів зони, у подіях
CONTROL = 400       # скільки випадкових подій береться на підлогу
SEED = 17           # зерно вибірки контрольних подій
KINDS = {"sell": {"title": "продаж", "top": True, "line": "belong_up",
                  "border": "вершина"},
         "buy": {"title": "купівля", "top": False, "line": "belong_down",
                 "border": "дно"}}


def ema_line(values: list, span: int) -> list:
    """Та сама ема, що малює вкладка: `alpha = 2/(span+1)`, причинно."""
    alpha = 2 / (span + 1)
    out: list = []
    was = None
    for value in values:
        if value is None or not np.isfinite(value):
            out.append(was)
            continue
        was = value if was is None else was + alpha * (value - was)
        out.append(was)
    return out


def crossings(side: list, line: list, span: int = SPAN,
              edge: float = EDGE, quiet: int = QUIET) -> list:
    """Перетини видачі з її емою — після прогріву ема в `span` подій.

    Беруться не всі перетини, а ті, що проходять два відбори:

    **рівень** — падіння крізь ему рахується продажем, поки голова ще
    вище `edge`, підйом — купівлею, поки вона ще нижче. Голова, що
    вже перейшла на інший бік, кінець старої ноги не оголошує: там
    сама ема просто доганяє нове положення.

    **тиша** — перетин ближчий за `quiet` подій до попереднього
    взятого відкидається. Вікно однієї відповіді моделі — ±`NEAR`
    подій, тож два перетини на такій відстані питають про ті самі
    події, і другий не додає нічого, крім зайвого рядка.

    Голова відповідає не на кожній події, тому попереднє значення
    береться з останньої події, **де воно є**, а не з сусідньої: дірка
    в ряді не має ковтати перетин.
    """
    found: list = []
    was = None
    last = None
    for at in range(len(side)):
        two, now = side[at], line[at]
        if two is None or now is None:
            continue
        if was is not None and at >= span:      # прогрів гасить сигнал,
            one, before = was                   # але не памʼять
            kind = None
            if one >= before and two < now and two > edge:
                kind = "sell"
            elif one <= before and two > now and two < edge:
                kind = "buy"
            if kind and (last is None or at - last >= quiet):
                found.append({"index": at, "kind": kind})
                last = at
        was = (two, now)
    return found


def step(line: list, at: int, near: int, edge: float):
    """Сходинка «бік межі», якщо межа стоїть рівно на події `at`.

    Мітка моделі: подія зсуву −9 … 0 належить нозі, що кінчається,
    подія +1 … +10 — тій, що почалась. Згода околу збалансована:
    половина її — частка подій **до** межі, названих старою ногою,
    половина — частка подій **після**, названих новою. Рівна лінія,
    хоч висока, хоч низька, дає рівно 0.5, тому поріг стоїть саме там.
    """
    before = [one for one in line[max(0, at - near):at + 1]
              if one is not None]
    after = [one for one in line[at + 1:at + 1 + near] if one is not None]
    if not before or not after:
        return None
    old = float(np.mean([one < edge for one in before]))
    new = float(np.mean([one > edge for one in after]))
    return ((old + new) / 2, float(np.mean(before)), float(np.mean(after)))


def ask(lines: dict, at: int, kind: str, near: int = NEAR,
        search: int = SEARCH, edge: float = EDGE) -> dict:
    """Що кажуть дві моделі про зону кандидата.

    Перетин дає **зону**, а не подію, тому сходинка шукається по всіх
    положеннях межі в зоні ±`search`. Кожне положення міряється своїм
    вікном ±`near` — тим, на якому модель вчилась. Модель називає ту
    подію, де сходинка сходиться найкраще; числа на самому перетині
    лишаються поруч, щоб було видно, наскільки вона її посунула.

    «Бік межі» читається в рамці тієї ноги, яка мала б кінчатись:
    продаж — нога вгору, купівля — нога вниз.
    """
    want = KINDS[kind]
    belong = lines[want["line"]]
    updown = lines["updown"]
    here = step(belong, at, near, edge)
    best, place = None, at
    for one in range(max(0, at - search), at + search + 1):
        got = step(belong, one, near, edge)
        if got is not None and (best is None or got[0] > best[0]):
            best, place = got, one
    if best is None:
        best, place = (float("nan"),) * 3, at
    around = [one for one in updown[max(0, place - near):place + near + 1]
              if one is not None]
    top = float(np.mean(around)) if around else float("nan")
    said_top = top > edge
    return {"agree": best[0], "place": int(place), "shift": int(place - at),
            "here": here[0] if here else float("nan"),
            "before": best[1], "after": best[2],
            "step": best[2] - best[1], "top": top,
            "said_border": bool(best[0] > SHARE),
            "said_side": "вершина" if said_top else "дно",
            "side_ok": bool(said_top == want["top"])}


def truth(borders: list, at: int, kind: str, span: int = SEARCH) -> dict:
    """Найближча справжня межа: як далеко, якого боку і чи є вона в зоні."""
    want = KINDS[kind]["border"]
    mine = [one for one in borders if one["kind"] == want]
    out = {"distance": None, "border": None, "own_distance": None,
           "own_index": None, "hit": False}
    if borders:
        near = min(borders, key=lambda one: abs(one["index"] - at))
        out["distance"] = int(near["index"] - at)
        out["border"] = near["kind"]
    if mine:
        own = min(mine, key=lambda one: abs(one["index"] - at))
        out["own_distance"] = int(own["index"] - at)
        out["own_index"] = int(own["index"])
        out["hit"] = bool(abs(out["own_distance"]) <= span)
    return out


def look(lines: dict, borders: list, found: list, near: int = NEAR,
         search: int = SEARCH, tol: int = MISS) -> list:
    """Судимо кожен перетин зоною заданого розміру.

    Влучання рахується **від події, яку назвала модель**, а не від
    перетину: робота ланцюжка — знайти розворот, а перетин лише каже,
    де шукати. Інакше вказівка за дві події від справжньої межі йшла б
    у промах тільки тому, що сам перетин стоїть на дві події далі за
    край зони.
    """
    calls = []
    for one in found:
        at = one["index"]
        said = ask(lines, at, one["kind"], near, search)
        real = truth(borders, at, one["kind"], search)
        put = truth(borders, said["place"], one["kind"], tol)
        sure = bool(said["said_border"] and said["side_ok"])
        calls.append(dict(one, **said, **real, confirmed=sure,
                          miss=(-put["own_distance"]
                                if put["own_distance"] is not None else None),
                          found=bool(sure and put["hit"]),
                          verdict=verdict(sure, put["hit"])))
    return calls


def ladder(lines: dict, borders: list, found: list, near: int = NEAR,
           spans=LADDER, tol: int = MISS) -> list:
    """Драбина зон: як розмір зони міняє і влучність, і покриття."""
    rows = []
    for span in spans:
        calls = look(lines, borders, found, near, span, tol)
        covered, caught = 0, 0
        for border in borders:
            kind = "sell" if border["kind"] == "вершина" else "buy"
            close = [one for one in calls if one["kind"] == kind
                     and abs(one["index"] - border["index"]) <= span]
            covered += int(bool(close))
            caught += int(any(one["found"] for one in close))
        misses = [abs(one["miss"]) for one in calls if one["found"]]
        right = sum(one["found"] for one in calls)
        said = sum(one["confirmed"] for one in calls)
        rows.append({"span": span, "calls": len(calls),
                     "hit": sum(one["hit"] for one in calls),
                     "said": said, "right": right,
                     "precision": round(right / said, 4) if said else None,
                     "covered": covered, "caught": caught,
                     "borders": len(borders),
                     "miss": int(np.median(misses)) if misses else None})
    return rows


def floor(lines: dict, side: list, borders: list, reach: dict,
          near: int = NEAR, search: int = SEARCH, count: int = CONTROL,
          seed: int = SEED) -> dict:
    """Підлога: та сама перевірка на випадкових подіях, а не на перетинах.

    Сходинка шукається по всій зоні, тому «підтверджено» дається
    задешево. Скільки саме задешево — видно тільки тут: бік береться
    так само, як у правила (видача вище 0.5 — продаж, нижче — купівля).
    """
    low = (reach["from"] or 0) + search
    high = (reach["to"] or 0) - search
    if high <= low:
        return {"events": 0, "confirmed": None, "hit": None, "right": None}
    dice = np.random.default_rng(seed)
    said, real, both, taken = 0, 0, 0, 0
    for at in dice.integers(low, high, size=count * 3):
        if side[at] is None:
            continue
        kind = "sell" if side[at] > EDGE else "buy"
        got = ask(lines, int(at), kind, near, search)
        if not np.isfinite(got["agree"]):
            continue
        taken += 1
        sure = bool(got["said_border"] and got["side_ok"])
        near_border = truth(borders, int(at), kind, search)["hit"]
        put = truth(borders, got["place"], kind, MISS)["hit"]
        said += int(sure)
        real += int(near_border)
        both += int(sure and put)
        if taken >= count:
            break
    return {"events": taken,
            "confirmed": round(said / taken, 4) if taken else None,
            "hit": round(real / taken, 4) if taken else None,
            "right": round(both / taken, 4) if taken else None}


def verdict(said: bool, hit: bool) -> str:
    """Вирок: `hit` тут — чи влучила **названа подія**, а не перетин."""
    if said and hit:
        return "знайдено"
    if said and not hit:
        return "хиба"
    if hit:
        return "пропуск"
    return "відхилено"


def zoned(lines: dict, found: list, near: int = NEAR,
          search: int = SEARCH, count: int = 0) -> dict:
    """Видачі моделей **тільки в зонах перетинів**, поза ними — порожньо.

    Моделі етапу 7 вчились на подіях краю і поза краєм відповідають
    завжди й гучно. Тому в ряді вони пускаються не всюди, а рівно
    там, де їх питали: зона ±`search` навколо перетину плюс вікно
    ±`near`, яке потрібне самій відповіді на краях зони.
    """
    span = search + near
    keep = np.zeros(count, dtype=bool)
    for one in found:
        low = max(0, one["index"] - span)
        keep[low:one["index"] + span + 1] = True
    return {name: [value if keep[at] else None
                   for at, value in enumerate(values)]
            for name, values in lines.items()}


def agree_line(lines: dict, found: list, near: int = NEAR,
               search: int = SEARCH, edge: float = EDGE,
               count: int = 0) -> list:
    """Збалансована згода в кожній точці зони — те, з чого йде вирок.

    Сирі лінії моделей дивитись марно: «бік межі» перескакує через
    `edge` раз на пʼять подій, «бік розвороту» в 87 % подій стоїть
    на рейках 0 або 1. Рішення ухвалюється не з них, а зі **згоди**:
    «якщо межа стоїть тут, наскільки окіл із цим згоден». Її й треба
    показувати — у неї є пік, а в сирої лінії його немає.

    Рахується в рамці **свого** перетину: продаж читає `belong_up`,
    купівля — `belong_down`. Поза зонами числа немає.
    """
    out: list = [None] * count
    for one in found:
        line = lines[KINDS[one["kind"]]["line"]]
        low = max(0, one["index"] - search)
        for at in range(low, min(count, one["index"] + search + 1)):
            got = step(line, at, near, edge)
            if got is not None:
                out[at] = round(got[0], 4)
    return out


def bands(found: list, near: int = NEAR, search: int = SEARCH,
          count: int = 0) -> list:
    """Самі зони — щоб на графіку було видно, де моделі взагалі питали."""
    span = search + near
    out: list = []
    for one in sorted(found, key=lambda x: x["index"]):
        low = max(0, one["index"] - span)
        high = min(count - 1, one["index"] + span)
        if out and low <= out[-1]["to"] + 1:      # зони злились
            out[-1]["to"] = max(out[-1]["to"], high)
            continue
        out.append({"from": int(low), "to": int(high)})
    return out


def clean(values: np.ndarray, digits: int = 4) -> list:
    return [None if one is None or not np.isfinite(one)
            else round(float(one), digits) for one in values]


def border_lines(pair: str, pairs: list, marks: int, window: int) -> dict:
    """Дві моделі етапу 7 дослідження 34 на всьому ряді монети."""
    import border_series
    from mirror import series

    rows = [series(one) for one in pairs]
    models = {task: border_series.trained(rows, task, marks, window)
              for task in border_series.TASKS}
    row = next(one for one in rows if one["pair"] == pair)
    lines = border_series.paint(row, {task: models[task][0] for task in models},
                                window)
    return {"row": row, "lines": lines,
            "about": {task: models[task][1] for task in models},
            "marks": border_series.marks_of(row)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--pairs", nargs="*", default=None,
                        help="на яких монетах учаться моделі межі")
    parser.add_argument("--span", type=int, default=SPAN)
    parser.add_argument("--near", type=int, default=NEAR)
    parser.add_argument("--search", type=int, default=SEARCH)
    parser.add_argument("--marks", type=int, default=10)
    parser.add_argument("--window", type=int, default=39)
    args = parser.parse_args()

    from mirror import PAIRS
    pairs = args.pairs or list(PAIRS)

    path = RESULTS / f"legs_heads_series_{args.pair}_{PART}.json"
    if not path.exists():
        raise SystemExit(f"немає ряду голів: {path} — запустіть legs_heads.py")
    heads = json.loads(path.read_text())

    got = border_lines(args.pair, pairs, args.marks, args.window)
    row, marks = got["row"], got["marks"]
    place = {int(one): at for at, one in enumerate(row["t"])}

    # Ряд голів і ряд моделей межі стоять на одній сітці подій, але
    # звіряються за часом, а не за номером: пропуск в одному з них не
    # має зсувати інший.
    keep = [place.get(int(one)) for one in heads["t"]]
    lines = {name: [None if at is None else
                    (None if not np.isfinite(values[at]) else
                     round(float(values[at]), 4))
                    for at in keep]
             for name, values in got["lines"].items()
             if name in ("belong_up", "belong_down", "updown")}

    seen = {at: number for number, at in enumerate(heads["t"])}
    borders = [{"index": seen[int(row["t"][one["index"]])],
                "kind": one["kind"], "price": one["price"]}
               for one in marks["borders"]
               if int(row["t"][one["index"]]) in seen]

    side = heads["p_side"]
    line = ema_line(side, args.span)
    found = crossings(side, line, args.span)
    # Голова відповідає не на кожній події ряду: там, де входу немає,
    # числа немає теж. Межі поза цим відрізком питати нема в кого, тому
    # в знаменнику драбини стоять тільки ті, що в нього потрапили.
    spoken = [at for at, one in enumerate(side) if one is not None]
    reach = {"from": spoken[0] if spoken else None,
             "to": spoken[-1] if spoken else None,
             "events": len(spoken)}
    inside = [one for one in borders
              if spoken and reach["from"] <= one["index"] <= reach["to"]]
    reach["borders"] = len(inside)
    calls = [dict(one, t=heads["t"][one["index"]],
                  price=heads["price"][one["index"]],
                  title=KINDS[one["kind"]]["title"],
                  p_side=side[one["index"]],
                  ema=round(line[one["index"]], 4))
             for one in look(lines, borders, found, args.near, args.search)]
    for one in calls:                    # NaN у JSON не лізе
        for key, value in one.items():
            if isinstance(value, float) and not np.isfinite(value):
                one[key] = None
            elif isinstance(value, float):
                one[key] = round(value, 4)

    counts: dict = {}
    for one in calls:
        counts[one["verdict"]] = counts.get(one["verdict"], 0) + 1
    by_kind = {}
    for key in KINDS:
        part = [one for one in calls if one["kind"] == key]
        by_kind[key] = {
            "title": KINDS[key]["title"], "calls": len(part),
            "confirmed": sum(one["confirmed"] for one in part),
            "hit": sum(one["hit"] for one in part),
            "right": sum(one["found"] for one in part)}

    result = {
        "script": SCRIPT, "ready": True, "pair": args.pair, "part": PART,
        "events": len(heads["t"]), "edge": EDGE,
        "knobs": {"span": args.span, "near": args.near,
                  "search": args.search, "miss": MISS,
                  "share": SHARE, "edge": EDGE, "quiet": QUIET,
                  "marks": args.marks, "window": args.window},
        "models": {"source": "research/34-pivot-signature/scripts/"
                             "border_series.py",
                   "trained_on": pairs, "about": got["about"]},
        "borders": borders, "counts": counts, "by_kind": by_kind,
        "asked": sum(one["to"] - one["from"] + 1
                     for one in bands(found, args.near, args.search,
                                      len(heads["t"]))),
        "ladder": ladder(lines, inside, found, args.near), "reach": reach,
        "floor": floor(lines, side, borders, reach, args.near, args.search),
        "calls": calls,
        "totals": {"calls": len(calls),
                   "confirmed": sum(one["confirmed"] for one in calls),
                   "hit": sum(one["hit"] for one in calls),
                   "right": sum(one["found"] for one in calls)}}
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "legs_cross.json").write_text(
        json.dumps(result, ensure_ascii=False))

    # Знайдені розвороти: подія, яку назвала модель, і її ціна. Це
    # головна видача ряду — те, що ланцюжок **помітив**.
    turns = [{"index": one["place"], "t": heads["t"][one["place"]],
              "found": one["found"],
              "price": heads["price"][one["place"]],
              "kind": one["kind"], "from": one["index"],
              "shift": one["shift"], "agree": one["agree"],
              "top": one["top"], "hit": one["hit"], "miss": one["miss"]}
             for one in calls if one["confirmed"]]

    row_out = dict(result)
    row_out.pop("calls")
    row_out["marks"] = calls
    row_out["turns"] = turns
    row_out.update({
        "t": heads["t"], "price": heads["price"], "ema": heads["ema"],
        "pivots": heads["pivots"], "p_side": side,
        "side_ema": clean(np.array([np.nan if one is None else one
                                    for one in line])),
        "bands": bands(found, args.near, args.search, len(heads["t"])),
        "lines": zoned(lines, found, args.near, args.search,
                       len(heads["t"])),
        "agree_line": agree_line(lines, found, args.near, args.search,
                                 EDGE, len(heads["t"]))})
    (RESULTS / f"legs_cross_series_{args.pair}.json").write_text(
        json.dumps(row_out, ensure_ascii=False))

    print(f"{args.pair}: {len(heads['t'])} подій val, "
          f"{len(borders)} справжніх меж, {len(calls)} перетинів "
          f"(ема {args.span})")
    print(f"  голова говорить на {reach['events']} подіях "
          f"({reach['from']}…{reach['to']}), меж у цьому відрізку "
          f"{reach['borders']}")
    print(f"  моделі межі питали на {result['asked']} подіях "
          f"({result['asked'] / len(heads['t']) * 100:.1f} % ряду), "
          f"позначено розворотів {sum(one['confirmed'] for one in calls)}")
    for key, one in by_kind.items():
        print(f"  {one['title']:9s} {one['calls']:4d} · підтверджено "
              f"{one['confirmed']:4d} · межа в зоні {one['hit']:3d} · "
              f"знайдено {one['right']:3d}")
    for name in ("знайдено", "хиба", "пропуск", "відхилено"):
        print(f"  {name:14s} {counts.get(name, 0)}")
    put = [abs(one["miss"]) for one in calls if one["found"]]
    if put:
        print(f"  похибка вказівки на знайдених: медіана "
              f"{int(np.median(put))} подій, найкраща {min(put)}")
    said = result["floor"]
    print(f"  підлога: на {said['events']} випадкових подіях "
          f"підтверджено {said['confirmed']}, справді межа {said['hit']}, "
          f"і те й те {said['right']}")
    print("  зона  сказали  влучні  точність  покрито  зловлено  похибка")
    for one in result["ladder"]:
        print(f"  ±{one['span']:<4d} {one['said']:6d} {one['right']:7d} "
              f"{str(one['precision']):>10s}   {one['covered']} з "
              f"{one['borders']}      {one['caught']}       {one['miss']}")


if __name__ == "__main__":
    main()
