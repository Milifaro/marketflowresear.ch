"""Сигнал купівлі й продажу з видач мереж: навчання на train, замір на val.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → навчання моделей

Жодна з мереж проєкту не каже «купуй» чи «продавай». Вони кажуть інше:
«нога кінчається», «ми на 80 % ноги», «це зона розвороту». Тут з їхніх
видач збирається **одне рішення** — і воно міряється тим, чого від нього
хочуть: наскільки близько до півота воно стало.

## Вхід

Девʼять каналів `calls_data.py`. З кожного беруться чотири числа: саме
значення, середнє за `SHORT` і `LONG` подій і **місце в хвості** —
причинний ранг значення серед останніх `TRAIL` подій.

Ранг тут не прикраса. Замір `calls_look.py` показав, що рівень каналів
їде: на val у зоні розвороту `zone` тримає медіану 0.16 при максимумі
0.27, а поза зоною доходить до 0.31 — сталий поріг, поставлений на
train, вибирає на val зовсім не ті події, хоча **порядок** усередині
каналу лишається правильним (AUC 0.68). Ранг у хвості й лікує саме це:
він каже «зараз гучніше, ніж було останні дві години», а не «більше
за 0.27».

Напрямку в каналах немає: мережі кажуть «кінець ноги», а не «кінець ноги
вгору» (AUC напрямку 0.51–0.56 на самих подіях зони). Тому поруч ідуть
причинні числа самої ціни — хід ема10 за `MOVES` подій і відкат від
крайньої точки вікон `BACKS` — те саме число, на якому стоїть
зігзаг-суперник. Розмітки серед входів немає **жодної**.

Горизонти `hazard` живуть на коротшому ряді, ніж решта. Там, де їх
немає, стоїть середнє, а окрема ознака `є горизонти` каже мережі, що
це саме пропуск.

## Ціль

Три класи на подію: `купівля` — подія в зоні нижнього півота, `продаж` —
верхнього, `нічого` — решта. Зона несиметрична, `BEFORE` подій до півота
і `AFTER` після: ранній сигнал ще можна виконати, пізній — ні.

## Вибір епохи й порога

Останні `TUNE` частки подій train відрізаються і не вчаться — по них
вибирається епоха і поріг. Val у виборі не бере участі взагалі.

Поріг ставиться так, щоб сигналів вийшло приблизно стільки ж, скільки
півотів на відкладеному шматку: **один сигнал на ногу**, а не потік.
Далі працює чергування — після купівлі береться тільки продаж, і
навпаки: двічі підряд в один бік позиції не відкривають.

## З чим порівнюється

    канал     той самий поріг і те саме чергування, але на одному
              каналі, а бік береться з ходу ціни
    зігзаг    причинний зігзаг `ZIGZAG` %: сигнал у мить, коли ціна
              відійшла від крайньої точки на цей відсоток. Розмітки не
              бачить, майбутнього теж — чесний суперник
    монетка   випадкові сигнали тієї самої частоти

Вхід : results/calls_input_<PAIR>.npz
Вихід: results/calls_train.json, models/calls/model.pt, models/calls/norm.npz

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_train.py
    python3 research/33-buy-sell-signal/scripts/calls_train.py --epochs 40
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
SEED = 17
BEFORE = 50                   # зона: подій до півота
AFTER = 15                    # і після
SHORT = 10                    # коротке згладжування каналу
LONG = 60                     # довге згладжування
TRAIL = 600                   # хвіст, у якому шукається місце значення
MOVES = (10, 30, 100, 300)    # на скільки подій назад дивиться ціна
BACKS = (300, 900)            # вікна, від крайньої точки яких міряється відкат
TUNE = 0.2                    # яка частина train відкладена на вибір
HIDDEN = (64, 32)
DROP = 0.1
LR = 0.002
DECAY = 1e-4                  # вага вниз: без неї мережа вчить сам шматок
EPOCHS = 30
BATCH = 512
WEIGHT = 3.0                  # у скільки разів позитив дорожчий за фон
ZIGZAG = 0.012                # причинний зігзаг-суперник, частка ціни
BACK = 150                    # на скільки подій назад дозволено посунути сигнал
TOLERANCE = (5, 15, 50, 100)  # у скільки подій рахуємо влучання
# Три набори ознак: самі видачі мереж, сама ціна і все разом. Питання
# ставиться так, щоб відповідь «мережі нічого не додають» теж було видно.
FEEDS = {"мережі": ("мережі",), "ціна": ("ціна",),
         "разом": ("мережі", "ціна")}
SCRIPT = "research/33-buy-sell-signal/scripts/calls_train.py"


# -------------------------------------------------------------------- вхід

def load(pair: str, out: Path = RESULTS) -> dict:
    path = out / f"calls_input_{pair}.npz"
    if not path.exists():
        raise SystemExit(f"немає входу: {path} — спершу calls_data.py")
    got = np.load(path)
    report = json.loads((out / "calls_input.json").read_text(
        encoding="utf-8"))
    coin = report["coins"][pair]
    return {"pair": pair, "t": got["t"], "price": got["price"],
            "ema": got["ema"], "table": got["table"], "full": got["full"],
            "core": got["core"], "pivot_at": got["pivot_at"],
            "pivot_up": got["pivot_up"], "channels": report["channels"],
            "have": coin["have"], "cut": coin["cut"]}


def look_module():
    """`calls_look.py` поруч: зона розвороту описана там, не тут."""
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    import calls_look

    return calls_look


def rolling_mean(values: np.ndarray, win: int) -> np.ndarray:
    """Причинне середнє: у події видно тільки її саму й те, що було."""
    good = np.isfinite(values)
    filled = np.where(good, values, 0.0)
    total = np.concatenate([[0.0], np.cumsum(filled)])
    count = np.concatenate([[0], np.cumsum(good.astype(np.int64))])
    place = np.arange(len(values))
    start = np.maximum(0, place - win + 1)
    seen = count[place + 1] - count[start]
    got = np.where(seen > 0, (total[place + 1] - total[start])
                   / np.maximum(seen, 1), np.nan)
    return got


def trail_rank(values: np.ndarray, win: int = TRAIL,
               chunk: int = 4000) -> np.ndarray:
    """Місце значення серед останніх `win` подій, 0…1.

    Рівень каналу їде між монетами й між частинами ряду, а порядок —
    ні. Ранг у хвості лишає тільки порядок.
    """
    total = len(values)
    out = np.full(total, np.nan)
    padded = np.concatenate([np.full(win - 1, np.nan), values])
    for start in range(0, total, chunk):
        stop = min(start + chunk, total)
        view = np.lib.stride_tricks.sliding_window_view(
            padded[start:stop + win - 1], win)
        now = values[start:stop][:, None]
        good = np.isfinite(view)
        below = np.where(good & (view < now), 1.0, 0.0).sum(axis=1)
        same = np.where(good & (view == now), 1.0, 0.0).sum(axis=1)
        seen = good.sum(axis=1)
        out[start:stop] = np.where(seen > 0,
                                   (below + same / 2.0)
                                   / np.maximum(seen, 1), np.nan)
    return np.where(np.isfinite(values), out, np.nan)


def features_of(data: dict) -> dict:
    """Числа на подію: канали в чотирьох виглядах і хід самої ціни.

    Ознаки поділені на дві групи, `мережі` й `ціна`, щоб можна було
    спитати окремо: що дають видачі мереж понад те, що видно в ціні.
    """
    ema = np.asarray(data["ema"], dtype=float)
    columns, names, group = [], [], []
    for key in data["channels"]:
        if key not in data["have"]:
            continue
        value = data["table"][:, data["channels"].index(key)].astype(float)
        for one, title in ((value, key),
                           (rolling_mean(value, SHORT), f"{key}:сер{SHORT}"),
                           (rolling_mean(value, LONG), f"{key}:сер{LONG}"),
                           (trail_rank(value, TRAIL), f"{key}:ранг{TRAIL}")):
            columns.append(one)
            names.append(title)
            group.append("мережі")
    columns.append(np.isfinite(data["table"][:, data["channels"].index("p100")]
                               ).astype(float))
    names.append("є горизонти")
    group.append("мережі")
    for step in MOVES:
        past = np.concatenate([np.full(step, np.nan), ema[:-step]])
        columns.append((ema - past) / np.maximum(past, 1e-9) * 100.0)
        names.append(f"ціна:хід{step}")
        group.append("ціна")
    # Відкат від крайньої точки вікна — те саме число, на якому стоїть
    # зігзаг-суперник. Без нього порівняння було б нечесним: мережі
    # питали б про розворот, а ціна — ні.
    for step in BACKS:
        low = -rolling_max(-ema, step)
        high = rolling_max(ema, step)
        columns.append((ema - low) / np.maximum(low, 1e-9) * 100.0)
        names.append(f"ціна:відкат вгору{step}")
        group.append("ціна")
        columns.append((high - ema) / np.maximum(high, 1e-9) * 100.0)
        names.append(f"ціна:відкат вниз{step}")
        group.append("ціна")
        columns.append((ema - low) / np.maximum(high - low, 1e-9))
        names.append(f"ціна:місце{step}")
        group.append("ціна")
    return {"x": np.stack(columns, axis=1).astype(np.float32), "names": names,
            "group": group}


def rolling_max(values: np.ndarray, win: int) -> np.ndarray:
    """Причинний максимум у вікні; порожнє вікно — `NaN`."""
    total = len(values)
    out = np.full(total, np.nan)
    padded = np.concatenate([np.full(win - 1, np.nan), values])
    for start in range(0, total, 4000):
        stop = min(start + 4000, total)
        view = np.lib.stride_tricks.sliding_window_view(
            padded[start:stop + win - 1], win)
        with np.errstate(all="ignore"):
            out[start:stop] = np.nanmax(
                np.where(np.isfinite(view), view, -np.inf), axis=1)
    return np.where(np.isfinite(out) & (out > -np.inf), out, np.nan)


def norm_of(x: np.ndarray, keep: np.ndarray) -> dict:
    """Середнє й розкид рахуються **тільки на навчальних подіях**."""
    piece = x[keep]
    with np.errstate(all="ignore"):
        mid = np.nanmean(piece, axis=0)
        wide = np.nanstd(piece, axis=0)
    return {"mid": np.where(np.isfinite(mid), mid, 0.0).astype(np.float32),
            "wide": np.where(np.isfinite(wide) & (wide > 1e-6), wide,
                             1.0).astype(np.float32)}


def applied(x: np.ndarray, norm: dict) -> np.ndarray:
    """Нормування, а вже потім заміна пропуску середнім — тобто нулем."""
    out = (x - norm["mid"]) / norm["wide"]
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0
                         ).astype(np.float32)


# ------------------------------------------------------------------ мережа

def build(width: int, seed: int = SEED):
    import torch
    from torch import nn

    torch.manual_seed(seed)
    layers, was = [], width
    for size in HIDDEN:
        layers += [nn.Linear(was, size), nn.ReLU(), nn.Dropout(DROP)]
        was = size
    layers.append(nn.Linear(was, 3))
    return nn.Sequential(*layers)


def fit(x: np.ndarray, y: np.ndarray, keep: np.ndarray, tune: np.ndarray,
        judge, epochs: int = EPOCHS, seed: int = SEED, log=print) -> dict:
    """Навчання на train без відкладеного шматка.

    Епоха вибирається **не втратою**, а тим самим числом, заради якого
    все робиться: скільки розворотів відкладеного шматка взято з
    точністю ±50 подій. Втрата й влучність розходяться — падіння втрати
    на третій епосі вже йшло разом із падінням влучності.
    """
    import torch
    from torch import nn

    model = build(x.shape[1], seed)
    opt = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=DECAY)
    weight = torch.tensor([1.0, WEIGHT, WEIGHT], dtype=torch.float32)
    loss_fn = nn.CrossEntropyLoss(weight=weight)
    learn = np.flatnonzero(keep)
    check = np.flatnonzero(tune)
    steps = torch.from_numpy(x[learn])
    want = torch.from_numpy(y[learn].astype(np.int64))
    hold = torch.from_numpy(x[check])
    held = torch.from_numpy(y[check].astype(np.int64))
    rng = np.random.default_rng(seed)
    best, state, level, curve = None, None, None, []
    for number in range(1, epochs + 1):
        model.train()
        order = rng.permutation(len(learn))
        total = 0.0
        for start in range(0, len(order), BATCH):
            piece = torch.from_numpy(order[start:start + BATCH])
            opt.zero_grad()
            loss = loss_fn(model(steps[piece]), want[piece])
            loss.backward()
            opt.step()
            total += float(loss.item()) * len(piece)
        model.eval()
        with torch.no_grad():
            hurt = float(loss_fn(model(hold), held).item())
        got = judge(model)
        curve.append({"epoch": number, "loss": round(total / len(order), 4),
                      "tune": round(hurt, 4), "mark": got["mark"],
                      "level": round(got["level"], 4)})
        if best is None or got["mark"] > best:
            best, level = got["mark"], got["level"]
            state = {key: value.detach().clone()
                     for key, value in model.state_dict().items()}
            curve[-1]["best"] = True
        log(f"  епоха {number}: втрата {curve[-1]['loss']:.4f} · "
            f"відкладене {hurt:.4f} · влучань ±50 {got['mark']}"
            f"{'  ← краще' if curve[-1].get('best') else ''}")
    model.load_state_dict(state)
    model.eval()
    return {"model": model, "curve": curve, "level": level,
            "epoch": int(max(one["epoch"] for one in curve
                             if one.get("best")))}


def probable(model, x: np.ndarray, good: np.ndarray) -> np.ndarray:
    """Три числа на подію; там, де входу немає, — `NaN`."""
    import torch

    out = np.full((len(x), 3), np.nan, dtype=np.float32)
    place = np.flatnonzero(good)
    if not len(place):
        return out
    with torch.no_grad():
        got = torch.softmax(model(torch.from_numpy(x[place])), dim=1)
    out[place] = got.numpy()
    return out


# ------------------------------------------------------------------ сигнал

def fires_of(strength: np.ndarray, side: np.ndarray, level: float,
             good: np.ndarray) -> list:
    """Сигнали з чергуванням: після купівлі береться тільки продаж."""
    out, last = [], 0
    for place in np.flatnonzero(good & np.isfinite(strength)
                                & (strength >= level)):
        now = int(side[place])
        if now == 0 or now == last:
            continue
        out.append({"at": int(place), "side": now})
        last = now
    return out


def level_for(strength: np.ndarray, side: np.ndarray, good: np.ndarray,
              want: int, steps: int = 200) -> float:
    """Поріг, за якого сигналів виходить приблизно `want`."""
    piece = strength[good & np.isfinite(strength)]
    if not len(piece):
        return 1.0
    grid = np.unique(np.quantile(piece, np.linspace(0.5, 0.9995, steps)))
    best, level = None, float(grid[-1])
    for one in grid[::-1]:
        count = len(fires_of(strength, side, float(one), good))
        gap = abs(count - want)
        if best is None or gap < best:
            best, level = gap, float(one)
        if count > want * 3:
            break
    return level


# -------------------------------------------------------------------- міра

def measure(fires: list, data: dict, keep: np.ndarray,
            before=BEFORE, after: int = AFTER) -> dict:
    """Наскільки близько сигнали стали до півотів — і що з цього вийшло.

    `before` — хвіст зони: стале число подій або свій хвіст на кожен
    півот (`calls_look.tails_of`). Впливає тільки на `in_zone`;
    влучання ±N рахуються від самого півота і від зони не залежать.
    """
    place = np.asarray([one["at"] for one in fires], dtype=np.int64)
    sides = np.asarray([one["side"] for one in fires], dtype=np.int8)
    pivots, ups = data["pivot_at"], data["pivot_up"]
    backs = look_module().backs_of(before, len(pivots))
    mine = np.flatnonzero(keep)
    first, last = (int(mine[0]), int(mine[-1])) if len(mine) else (0, -1)
    inside = (pivots >= first) & (pivots <= last)
    pivots, ups, backs = pivots[inside], ups[inside], backs[inside]

    gaps, caught = [], {one: 0 for one in TOLERANCE}
    for one, low in zip(pivots, ups):
        same = place[sides == (1 if low else -1)] if len(place) else place
        if not len(same):
            continue
        gap = int(same[np.argmin(np.abs(same - one))] - one)
        gaps.append(gap)
        for tolerance in TOLERANCE:
            caught[tolerance] += int(abs(gap) <= tolerance)
    near = []
    for one, side in zip(place, sides):
        pick = np.flatnonzero(ups == (side > 0))
        if len(pick):
            at = int(pick[np.argmin(np.abs(pivots[pick] - one))])
            near.append((int(one - pivots[at]), int(backs[at])))
    zone = [gap for gap, back in near if -back <= gap <= after]
    return {
        "fires": len(fires),
        "per_1000": round(len(fires) / max(int(keep.sum()), 1) * 1000, 2),
        "legs": int(len(pivots)),
        "caught": {str(one): round(caught[one] / len(pivots), 4)
                   for one in TOLERANCE} if len(pivots) else {},
        "gap_median": round(float(np.median(gaps)), 1) if gaps else None,
        "gap_abs": round(float(np.median(np.abs(gaps))), 1) if gaps else None,
        "in_zone": round(len(zone) / len(near), 4) if near else None,
        "money": money_of(fires, np.asarray(data["price"], dtype=float),
                          keep)}


def money_of(fires: list, price: np.ndarray, keep: np.ndarray) -> dict:
    """Скільки ходу взято: позиція перевертається на кожному сигналі.

    Міра груба навмисне — без комісій, плеча й розміру позиції. Питання
    одне: яку частку ходу, що був у ряді, цей набір сигналів узяв.
    """
    mine = np.flatnonzero(keep)
    if len(fires) < 2 or not len(mine):
        return {"taken": None, "moves": 0}
    took = 0.0
    for one, two in zip(fires[:-1], fires[1:]):
        took += (price[two["at"]] - price[one["at"]]) \
            / price[one["at"]] * one["side"]
    walk = float(np.abs(np.diff(price[mine])).sum() / price[mine[0]])
    return {"taken": round(took * 100, 3), "moves": len(fires) - 1,
            "walk": round(walk * 100, 1),
            "share": round(took / walk * 100, 2) if walk else None}


def pooled(rows: list) -> dict:
    """Числа по всіх монетах разом: влучання й гроші важать за ногами."""
    legs = sum(one["legs"] for one in rows)
    fires = sum(one["fires"] for one in rows)
    got = {"fires": fires, "legs": legs,
           "per_1000": round(float(np.mean([one["per_1000"]
                                            for one in rows])), 2)}
    for tolerance in TOLERANCE:
        key = str(tolerance)
        hit = sum(one["caught"].get(key, 0) * one["legs"] for one in rows)
        got.setdefault("caught", {})[key] = round(hit / legs, 4) if legs \
            else None
    told = [one["gap_abs"] for one in rows if one["gap_abs"] is not None]
    got["gap_abs"] = round(float(np.median(told)), 1) if told else None
    inside = [one["in_zone"] for one in rows if one["in_zone"] is not None]
    got["in_zone"] = round(float(np.mean(inside)), 4) if inside else None
    shares = [one["money"]["share"] for one in rows
              if one["money"].get("share") is not None]
    got["money"] = {"share": round(float(np.mean(shares)), 2) if shares
                    else None,
                    "taken": round(float(np.sum(
                        [one["money"].get("taken") or 0.0 for one in rows])),
                        2)}
    return got


# --------------------------------------------------------------- суперники

def zigzag_calls(ema: np.ndarray, good: np.ndarray,
                 threshold: float = ZIGZAG) -> list:
    """Причинний зігзаг: сигнал у мить відходу від крайньої точки."""
    out = []
    place = np.flatnonzero(good)
    if not len(place):
        return out
    top = bottom = float(ema[place[0]])
    side = 0
    for one in place:
        value = float(ema[one])
        top, bottom = max(top, value), min(bottom, value)
        if side <= 0 and value >= bottom * (1 + threshold):
            out.append({"at": int(one), "side": 1})
            side, top = 1, value
        elif side >= 0 and value <= top * (1 - threshold):
            out.append({"at": int(one), "side": -1})
            side, bottom = -1, value
    return out


def shifted(fires: list, strength: np.ndarray, good: np.ndarray,
            back: int = BACK) -> list:
    """Сигнал зігзага, посунутий назад у найгучнішу подію каналу.

    Зігзаг спізнюється за будовою: він чекає, поки ціна відійде від
    крайньої точки. Питання цього заміру одне — чи знає котрийсь із
    каналів, **де саме** в останніх `back` подіях була крайня точка.
    Якщо знає, сигнал стане ближче до розвороту; якщо ні, поправка
    зробить гірше, і це теж відповідь.
    """
    out, last = [], 0
    for one in fires:
        start = max(0, one["at"] - back)
        piece = np.arange(start, one["at"] + 1)
        keep = piece[good[piece] & np.isfinite(strength[piece])]
        at = int(keep[np.argmax(strength[keep])]) if len(keep) else one["at"]
        if out and at <= out[-1]["at"]:
            at = one["at"]
        if one["side"] == last:
            continue
        out.append({"at": at, "side": one["side"]})
        last = one["side"]
    return out


def price_side(ema: np.ndarray, step: int = 100) -> np.ndarray:
    """Бік з самої ціни: ряд падав — розворот буде вгору, і навпаки."""
    past = np.concatenate([np.full(step, np.nan), ema[:-step]])
    move = ema - past
    return np.where(np.isfinite(move), np.where(move < 0, 1, -1),
                    0).astype(np.int8)


def coin_calls(good: np.ndarray, count: int, seed: int = SEED) -> list:
    """Монетка: стільки ж сигналів, поставлених навмання з чергуванням."""
    rng = np.random.default_rng(seed)
    place = np.flatnonzero(good)
    if not len(place) or count <= 0:
        return []
    picked = np.sort(rng.choice(place, size=min(count, len(place)),
                                replace=False))
    return [{"at": int(one), "side": 1 if number % 2 == 0 else -1}
            for number, one in enumerate(picked)]


# --------------------------------------------------------------------- хід

def gather(pairs: tuple, out: Path) -> dict:
    """Монети підряд: ознаки й мітки рахуються **всередині** кожної."""
    sys.path.insert(0, str(SCRIPTS))
    import calls_look as look

    coins, blocks, labels, parts = {}, [], [], []
    for pair in pairs:
        data = load(pair, out)
        built = features_of(data)
        total = len(data["t"])
        side = look.side_of(total, data["pivot_at"], data["pivot_up"],
                            BEFORE, AFTER)
        good = np.isfinite(built["x"]).all(axis=1) & data["core"]
        train = data["t"] < data["cut"]
        edge = np.flatnonzero(train & good)
        if not len(edge):
            raise SystemExit(f"{pair}: навчальних подій немає")
        cut = int(edge[int(len(edge) * (1 - TUNE))])
        place = np.arange(total)
        coins[pair] = {
            "data": data, "x": built["x"], "names": built["names"],
            "group": built["group"],
            "side": side, "good": good,
            "keep": good & train & (place < cut),
            "tune": good & train & (place >= cut),
            "show": good & ~train}
        blocks.append(built["x"][coins[pair]["keep"]])
        labels.append(side[coins[pair]["keep"]])
        parts.append(pair)
        print(f"  {pair}: подій {total} · з входом {int(good.sum())} · "
              f"навчання {int(coins[pair]['keep'].sum())} · відкладено "
              f"{int(coins[pair]['tune'].sum())} · val "
              f"{int(coins[pair]['show'].sum())}")
    return {"coins": coins, "names": coins[parts[0]]["names"],
            "group": coins[parts[0]]["group"],
            "learn": np.concatenate(blocks),
            "labels": np.concatenate(labels)}


def spread_of(model, x: np.ndarray, coins: dict, pairs: tuple,
              edges: dict, part: str) -> tuple:
    """Сила й бік сигналу на всіх монетах разом, довжиною в увесь ряд."""
    strength, picked = {}, {}
    for pair in pairs:
        start, stop = edges[pair]
        proba = probable(model, x[start:stop], coins[pair][part])
        with np.errstate(all="ignore"):
            strength[pair] = np.nanmax(proba[:, 1:], axis=1)
        picked[pair] = np.where(proba[:, 1] >= proba[:, 2], 1,
                                -1).astype(np.int8)
        coins[pair][f"proba_{part}"] = proba
    return strength, picked


def judged(coins: dict, pairs: tuple, x: np.ndarray, edges: dict,
           tune: np.ndarray, want: int):
    """Оцінка епохи: влучання ±50 на відкладеному шматку train."""
    def judge(model):
        strength, picked = spread_of(model, x, coins, pairs, edges, "tune")
        level = level_for(np.concatenate([strength[one] for one in pairs]),
                          np.concatenate([picked[one] for one in pairs]),
                          tune, max(want, 1))
        rows = [measure(fires_of(strength[one], picked[one], level,
                                 coins[one]["tune"]),
                        coins[one]["data"], coins[one]["tune"], BEFORE, AFTER)
                for one in pairs]
        got = pooled(rows)
        return {"mark": got["caught"]["50"], "level": level, "pooled": got}
    return judge


def run_feed(feed: str, coins: dict, pairs: tuple, x: np.ndarray,
             y: np.ndarray, edges: dict, keep: np.ndarray, tune: np.ndarray,
             columns: np.ndarray, want: int, epochs: int, seed: int) -> dict:
    """Один набір ознак: навчання, поріг і числа на val."""
    piece = x[:, columns]
    print(f"\n=== {feed}: ознак {piece.shape[1]}")
    fitted = fit(piece, y, keep, tune, judged(coins, pairs, piece, edges,
                                              tune, want), epochs, seed)
    model, level = fitted["model"], fitted["level"]
    marks = {}
    for part, title in (("tune", "tune"), ("show", "val")):
        strength, picked = spread_of(model, piece, coins, pairs, edges, part)
        rows = {one: measure(fires_of(strength[one], picked[one], level,
                                      coins[one][part]),
                             coins[one]["data"], coins[one][part],
                             BEFORE, AFTER) for one in pairs}
        marks[title] = {"by_pair": rows, "pooled": pooled(list(rows.values()))}
    got = marks["val"]["pooled"]
    print(f"  val: сигналів {got['fires']} на {got['legs']} півотів · "
          f"±15 {got['caught']['15']} · ±50 {got['caught']['50']} · у зоні "
          f"{got['in_zone']} · взято {got['money']['share']} % ходу")
    return {"model": model, "feed": feed, "epoch": fitted["epoch"],
            "curve": fitted["curve"], "level": round(float(level), 4),
            "features": int(piece.shape[1]), "marks": marks}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--feeds", nargs="+", default=list(FEEDS))
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()

    import torch

    pairs = tuple(args.pairs)
    got = gather(pairs, args.out)
    coins = got["coins"]
    norm = norm_of(got["learn"], np.ones(len(got["learn"]), dtype=bool))

    x = np.concatenate([applied(coins[pair]["x"], norm) for pair in pairs])
    y = np.concatenate([np.where(coins[pair]["side"] > 0, 1,
                                 np.where(coins[pair]["side"] < 0, 2, 0))
                        for pair in pairs]).astype(np.int64)
    edges, at = {}, 0
    for pair in pairs:
        edges[pair] = (at, at + len(coins[pair]["x"]))
        at = edges[pair][1]
    keep = np.concatenate([coins[pair]["keep"] for pair in pairs])
    tune = np.concatenate([coins[pair]["tune"] for pair in pairs])
    group = np.asarray(got["group"])
    want = 0
    for pair in pairs:
        piv = coins[pair]["data"]["pivot_at"]
        hold = np.flatnonzero(coins[pair]["tune"])
        want += int(((piv >= hold[0]) & (piv <= hold[-1])).sum())
    print(f"ознак {x.shape[1]} · навчання {int(keep.sum())} · відкладено "
          f"{int(tune.sum())} подій · півотів на відкладеному {want}")

    runs = {}
    for feed in args.feeds:
        columns = np.flatnonzero(np.isin(group, FEEDS[feed]))
        runs[feed] = run_feed(feed, coins, pairs, x, y, edges, keep, tune,
                              columns, want, args.epochs, args.seed)

    best = max(runs.values(), key=lambda one: one["marks"]["tune"]["pooled"]
               ["caught"]["50"])
    keep_dir = MODELS / "calls"
    keep_dir.mkdir(parents=True, exist_ok=True)
    torch.save(best["model"].state_dict(), keep_dir / "model.pt")
    np.savez_compressed(
        keep_dir / "norm.npz", mid=norm["mid"], wide=norm["wide"],
        columns=np.flatnonzero(np.isin(group, FEEDS[best["feed"]])))
    print(f"\nзбережено набір «{best['feed']}» — його вибрав відкладений "
          f"шматок")

    have = coins[pairs[0]]["data"]["have"]
    others = {}
    for key in list(have) + ["зігзаг", "монетка"]:
        rows = {}
        for pair in pairs:
            data, mask = coins[pair]["data"], coins[pair]["show"]
            ema = np.asarray(data["ema"], dtype=float)
            if key == "зігзаг":
                fires = zigzag_calls(ema, mask, ZIGZAG)
            elif key == "монетка":
                fires = coin_calls(mask, best["marks"]["val"]["by_pair"][pair]
                                   ["fires"], args.seed)
            else:
                value = data["table"][:, data["channels"].index(key)
                                      ].astype(float)
                naive = price_side(ema)
                one = level_for(value, naive, coins[pair]["tune"],
                                max(best["marks"]["tune"]["by_pair"][pair]
                                    ["legs"], 1))
                fires = fires_of(value, naive, one, mask)
            rows[pair] = measure(fires, data, mask, BEFORE, AFTER)
        others[key] = {"by_pair": rows, "pooled": pooled(list(rows.values()))}

    # Чи можуть мережі підтягнути зігзаг ближче до розвороту.
    moved = {}
    best_side = {}
    for pair in pairs:
        piece = x[:, np.flatnonzero(np.isin(group, FEEDS[best["feed"]]))]
        start, stop = edges[pair]
        proba = probable(best["model"], piece[start:stop],
                         coins[pair]["good"])
        with np.errstate(all="ignore"):
            best_side[pair] = (np.nanmax(proba[:, 1:], axis=1),
                               np.where(proba[:, 1] >= proba[:, 2], 1,
                                        -1).astype(np.int8))
    for key in ["поєднувач"] + list(have):
        rows = {}
        for pair in pairs:
            data, mask = coins[pair]["data"], coins[pair]["show"]
            ema = np.asarray(data["ema"], dtype=float)
            fires = zigzag_calls(ema, mask, ZIGZAG)
            value = best_side[pair][0] if key == "поєднувач" else \
                data["table"][:, data["channels"].index(key)].astype(float)
            rows[pair] = measure(shifted(fires, value, mask, BACK), data,
                                 mask, BEFORE, AFTER)
        moved[key] = {"by_pair": rows, "pooled": pooled(list(rows.values()))}

    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "seed": args.seed, "zone": {"before": BEFORE, "after": AFTER},
        "shape": {"hidden": list(HIDDEN), "drop": DROP, "lr": LR,
                  "decay": DECAY, "batch": BATCH, "weight": WEIGHT,
                  "epochs": args.epochs, "short": SHORT, "long": LONG,
                  "trail": TRAIL, "moves": list(MOVES), "backs": list(BACKS),
                  "tune": TUNE, "zigzag": ZIGZAG},
        "features": got["names"], "groups": list(group),
        "feeds": {key: list(value) for key, value in FEEDS.items()},
        "channels": list(have),
        "events": {"learn": int(keep.sum()), "tune": int(tune.sum()),
                   "val": int(sum(coins[pair]["show"].sum()
                                  for pair in pairs))},
        "best": best["feed"], "tolerance": list(TOLERANCE),
        "runs": {key: {one: value[one] for one in
                       ("feed", "epoch", "curve", "level", "features",
                        "marks")}
                 for key, value in runs.items()},
        "marks": best["marks"], "epoch": best["epoch"],
        "level": best["level"], "curve": best["curve"],
        "others": others, "moved": moved, "back": BACK,
        "weights": str((keep_dir / "model.pt").relative_to(PROJECT_ROOT))}
    path = args.out / "calls_train.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                    encoding="utf-8")

    print("\nval разом:")
    for feed, run in runs.items():
        one = run["marks"]["val"]["pooled"]
        print(f"  {feed:10s} ±15 {one['caught']['15']} · ±50 "
              f"{one['caught']['50']} · сигналів {one['fires']} · у зоні "
              f"{one['in_zone']} · взято {one['money']['share']} %")
    for key, block in others.items():
        two = block["pooled"]
        print(f"  {key:10s} ±15 {two['caught']['15']} · ±50 "
              f"{two['caught']['50']} · сигналів {two['fires']} · у зоні "
              f"{two['in_zone']} · взято {two['money']['share']} %")
    print(f"\nзігзаг, посунутий назад у найгучнішу подію каналу "
          f"(до {BACK} подій):")
    for key, block in moved.items():
        two = block["pooled"]
        print(f"  {key:10s} ±15 {two['caught']['15']} · ±50 "
              f"{two['caught']['50']} · медіана |зсуву| {two['gap_abs']} · "
              f"взято {two['money']['share']} %")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
