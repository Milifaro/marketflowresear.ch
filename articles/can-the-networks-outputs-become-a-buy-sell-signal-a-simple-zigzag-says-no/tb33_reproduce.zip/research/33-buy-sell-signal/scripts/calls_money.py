"""Симуляція торгівлі на val: $1000, перевертання позиції на сигналі.

Дослідження: research/33-buy-sell-signal/
Правила: rules/04-trading.md → Бектест

## Умови

    капітал     START, повністю в кожній позиції, без плеча
    вхід        **наступною подією** після сигналу, не тією самою
    комісія     FEE за бік (taker) + SLIP сліпеджу за бік
    позиція     два режими: `обидва` — завжди в ринку, сигнал купівлі
                перевертає в лонг, продажу — у шорт; `лонг` — сигнал
                продажу просто виводить у кеш
    складний    так: наступна угода йде на весь поточний капітал
    гроші       `Decimal`, ціни округлені до копійки

Look-ahead немає: сигнал рахується на події `i`, ціна входу береться з
події `i + 1`. Просадка міряється переоцінкою позиції на **кожній**
події, а не тільки на закритті угоди.

## Чого тут немає

Стоп-лосу. `rules/04-trading.md` вимагає не відкривати позицію без
стопа — тому це **замір сигналу**, а не готова стратегія: питання
одне, скільки дав би сам сигнал, якщо ходити за ним механічно.

Вхід : results/calls_input_<PAIR>.npz, models/calls/*
Вихід: results/calls_money.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_money.py
    python3 research/33-buy-sell-signal/scripts/calls_money.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal, getcontext
from pathlib import Path

import numpy as np

getcontext().prec = 28

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
PAIR = "BTC_USDT"
START = Decimal("1000")
FEE = Decimal("0.0005")     # taker за бік
SLIP = Decimal("0.0002")    # сліпедж за бік
COSTS = ("0", "0.0002", "0.0005", "0.001")   # драбина чутливості, за бік
ZIGZAGS = (0.004, 0.008, 0.012, 0.023)
YEAR = Decimal("365") * 24 * 3600
SCRIPT = "research/33-buy-sell-signal/scripts/calls_money.py"


def money(value: float) -> Decimal:
    """Ціна в грошах: копійки, без float-хвостів."""
    return Decimal(str(round(float(value), 2)))


def run(fires: list, price: np.ndarray, keep: np.ndarray, stamps: np.ndarray,
        cost: Decimal = FEE + SLIP, start: Decimal = START,
        mode: str = "обидва") -> dict:
    """Проходить сигнали по порядку й веде капітал.

    Позиція відкривається наступною подією після сигналу і тримається
    до наступного сигналу. Комісія й сліпедж беруться з обох боків
    угоди.
    """
    place = np.flatnonzero(keep)
    if len(place) < 2:
        return {"trades": 0, "end": float(start)}
    last = int(place[-1])
    steps = []
    for one in fires:
        at = int(one["at"])
        after = place[place > at]
        if not len(after):
            continue
        steps.append({"at": int(after[0]), "side": int(one["side"])})
    equity, curve, deals = start, [], []
    top, drop = start, Decimal("0")
    held, entry, since = 0, None, None
    for number, at in enumerate(place):
        at = int(at)
        now = [one for one in steps if one["at"] == at]
        if now:
            side = now[-1]["side"]
            if mode == "лонг" and side < 0:
                side = 0
            if held and entry is not None:
                got = (money(price[at]) / entry - 1) * held
                equity = equity * (1 + got) * (1 - cost) ** 2
                deals.append({"from": int(since), "to": at,
                              "side": held, "got": float(got),
                              "equity": float(equity)})
            if side != held:
                held, entry, since = side, money(price[at]), at
                if not held:
                    entry, since = None, None
            elif held:
                entry, since = money(price[at]), at
        mark = equity
        if held and entry is not None:
            mark = equity * (1 + (money(price[at]) / entry - 1) * held) \
                * (1 - cost) ** 2
        top = max(top, mark)
        drop = max(drop, (top - mark) / top)
        curve.append(mark)
    if held and entry is not None:
        got = (money(price[last]) / entry - 1) * held
        equity = equity * (1 + got) * (1 - cost) ** 2
        deals.append({"from": int(since), "to": last, "side": held,
                      "got": float(got), "equity": float(equity)})
    wins = [one for one in deals if one["got"] > 0]
    told = np.asarray([one["got"] for one in deals], dtype=float)
    span = Decimal(int(stamps[last]) - int(stamps[place[0]]))
    ticks = np.diff(np.asarray([float(one) for one in curve]))
    base = np.asarray([float(one) for one in curve[:-1]])
    step = ticks / np.maximum(base, 1e-9)
    sharpe = None
    if len(step) > 2 and step.std() > 0:
        beat = float(span / max(len(step), 1))
        sharpe = float(step.mean() / step.std()
                       * np.sqrt(float(YEAR) / max(beat, 1)))
    return {
        "mode": mode, "trades": len(deals), "signals": len(steps),
        "end": round(float(equity), 2),
        "pnl": round(float(equity - start), 2),
        "pnl_share": round(float((equity / start - 1) * 100), 2),
        "wins": round(len(wins) / len(deals) * 100, 1) if deals else None,
        "mean_deal": round(float(told.mean() * 100), 3) if len(told) else None,
        "best": round(float(told.max() * 100), 2) if len(told) else None,
        "worst": round(float(told.min() * 100), 2) if len(told) else None,
        "drawdown": round(float(drop * 100), 2),
        "sharpe": round(sharpe, 2) if sharpe is not None else None,
        "days": round(float(span) / 86400, 1),
        "fees": round(float(start * ((1 - (1 - (FEE + SLIP)) ** 2)
                                     * len(deals))), 2)}


def hold(price: np.ndarray, keep: np.ndarray, stamps: np.ndarray,
         cost: Decimal = FEE + SLIP, start: Decimal = START) -> dict:
    """Купив на початку val і тримав — база для порівняння."""
    place = np.flatnonzero(keep)
    one = [{"at": int(place[0]), "side": 1}]
    return run(one, price, keep, stamps, cost, start)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--start", type=Decimal, default=START)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_train as train

    data = train.load(args.pair, args.out)
    built = train.features_of(data)
    good = np.isfinite(built["x"]).all(axis=1) & data["core"]
    show = good & (data["t"] >= data["cut"])
    price = np.asarray(data["price"], dtype=float)
    ema = np.asarray(data["ema"], dtype=float)
    stamps = np.asarray(data["t"], dtype=np.int64)

    sets = {}
    for step in ZIGZAGS:
        sets[f"зігзаг {step * 100:.1f} %"] = train.zigzag_calls(ema, show,
                                                                step)

    kept = np.load(MODELS / "calls" / "norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    piece = train.applied(built["x"], norm)[:, kept["columns"].astype(int)]
    report = json.loads((args.out / "calls_train.json").read_text(
        encoding="utf-8"))
    model = train.build(piece.shape[1], report["seed"])
    model.load_state_dict(torch.load(MODELS / "calls" / "model.pt",
                                     map_location="cpu"))
    model.eval()
    proba = train.probable(model, piece, good)
    with np.errstate(all="ignore"):
        strength = np.nanmax(proba[:, 1:], axis=1)
    side = np.where(proba[:, 1] >= proba[:, 2], 1, -1).astype(np.int8)
    sets["поєднувач MLP"] = train.fires_of(strength, side,
                                          float(report["level"]), show)

    import calls_memory as memory

    told = json.loads((args.out / "calls_memory.json").read_text(
        encoding="utf-8"))
    kept = np.load(MODELS / "calls" / "memory_norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    piece = train.applied(built["x"], norm)[:, kept["columns"].astype(int)]
    net = memory.build(piece.shape[1], told["seed"])
    net.load_state_dict(torch.load(MODELS / "calls" / "memory.pt",
                                   map_location="cpu"))
    got = memory.walked(net, piece, good)
    with np.errstate(all="ignore"):
        loud = np.nanmax(got[:, 1:], axis=1)
    sets["поєднувач із памʼяттю"] = train.fires_of(
        loud, np.where(got[:, 1] >= got[:, 2], 1, -1).astype(np.int8),
        float(told["level"]), show)
    sets["монетка"] = train.coin_calls(
        show, len(sets["зігзаг 1.2 %"]), report["seed"])

    rows = {key: run(value, price, show, stamps, FEE + SLIP, args.start)
            for key, value in sets.items()}
    rows["купив і тримав"] = hold(price, show, stamps, FEE + SLIP,
                                  args.start)
    # Val BTC — це тренд угору, тому перевертання в шорт карається саме
    # трендом. Той самий сигнал без шортів: продаж виводить у кеш.
    longs = {key: run(value, price, show, stamps, FEE + SLIP, args.start,
                      "лонг") for key, value in sets.items()}
    # Драбина чутливості до витрат — на найкращому сигналі й на монетці.
    steps = {}
    for one in COSTS:
        cost = Decimal(one)
        steps[one] = {key: run(sets[key], price, show, stamps, cost,
                               args.start)["end"]
                      for key in ("зігзаг 1.2 %", "поєднувач MLP",
                                  "поєднувач із памʼяттю", "монетка")}

    place = np.flatnonzero(show)
    block = {
        "script": SCRIPT, "ready": True, "pair": args.pair,
        "start": float(args.start), "fee": float(FEE), "slip": float(SLIP),
        "events": int(show.sum()),
        "from": int(stamps[place[0]]), "to": int(stamps[place[-1]]),
        "days": rows["купив і тримав"]["days"],
        "price": {"from": round(float(price[place[0]]), 2),
                  "to": round(float(price[place[-1]]), 2)},
        "walk": round(float(np.abs(np.diff(price[place])).sum()
                            / price[place[0]] * 100), 1),
        "rows": rows, "longs": longs, "costs": steps}
    path = args.out / "calls_money.json"
    path.write_text(json.dumps(block, ensure_ascii=False, indent=2),
                    encoding="utf-8")

    print(f"{args.pair} val: {block['events']} подій · {block['days']} днів "
          f"· ціна {block['price']['from']} → {block['price']['to']} · хід "
          f"ряду {block['walk']} %")
    print(f"старт ${float(args.start):.0f} · комісія {float(FEE) * 100:.3f} % "
          f"+ сліпедж {float(SLIP) * 100:.2f} % за бік\n")
    for key, one in rows.items():
        print(f"  {key:22s} угод {one['trades']:3d} · кінець "
              f"${one['end']:8.2f} · {one['pnl_share']:+7.2f} % · виграшних "
              f"{one['wins']} % · просадка {one['drawdown']} % · шарп "
              f"{one['sharpe']}")
    print("\nтільки лонг (сигнал продажу виводить у кеш):")
    for key, one in longs.items():
        print(f"  {key:22s} угод {one['trades']:3d} · кінець "
              f"${one['end']:8.2f} · {one['pnl_share']:+7.2f} % · виграшних "
              f"{one['wins']} % · просадка {one['drawdown']} % · шарп "
              f"{one['sharpe']}")
    print("\nчутливість до витрат (кінцевий капітал, $):")
    for one, block_one in steps.items():
        print(f"  {float(one) * 100:.2f} % за бік: "
              + " · ".join(f"{key} {value:.2f}"
                           for key, value in block_one.items()))
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
