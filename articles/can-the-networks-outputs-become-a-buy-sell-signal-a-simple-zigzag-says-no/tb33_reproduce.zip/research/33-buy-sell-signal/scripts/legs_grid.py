"""Грід ручок двоголової мережі й драбина функцій втрат по епохах.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → навчання моделей

Дві фази, одна за одною.

## Фаза 1: грід

Ручки перебираються **колами по одній групі**: коло бере переможця
попереднього і міняє тільки свою ручку. Це дешевше за повний перебір і
не гірше на такій сітці, бо ручки тут майже незалежні.

    ширина      скільки нейронів памʼяті
    крок        швидкість навчання
    глушіння    `Dropout`
    ціна зони   у скільки разів позитив зони дорожчий
    різкість    безплатний крок числа, ціна стрибка й ціна прокола

Оцінка — **середня збалансована точність двох голів на відкладеному
шматку train**. Val у виборі не бере участі й тільки показується.

## Фаза 2: драбина втрат

Від ваг переможця гріду щабель за щаблем донавчаємо по `LADDER_EPOCHS`
епох, щоразу міняючи функцію втрат. Щабель лишається, якщо оцінка на
відкладеному шматку виросла, інакше ваги відкочуються — так само, як у
драбині дослідження 32.

Вхід : results/calls_input_<PAIR>.npz
Вихід: results/legs_grid.json, models/legs_heads/grid.pt

Запуск:
    python3 research/33-buy-sell-signal/scripts/legs_grid.py
    python3 research/33-buy-sell-signal/scripts/legs_grid.py --epochs 8
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
SEED = 17
EPOCHS = 12                   # епох на прогін гріду
LADDER_EPOCHS = 3             # епох на щабель драбини
SCRIPT = "research/33-buy-sell-signal/scripts/legs_grid.py"


def rounds_of() -> list:
    """Кола гріду: назва групи й варіанти ручок у ній."""
    return [
        ("ширина", [{"hid": 32}, {"hid": 64}, {"hid": 128}]),
        ("крок", [{"lr": 0.001}, {"lr": 0.002}, {"lr": 0.004}]),
        ("глушіння", [{"drop": 0.05}, {"drop": 0.1}, {"drop": 0.2}]),
        ("ціна зони", [{"zone": 2.0}, {"zone": 3.0}, {"zone": 5.0}]),
        ("різкість", [{"jump": 0.0, "spike": 0.0},
                      {"jump": 1.0, "spike": 1.0, "step": 0.2},
                      {"jump": 3.0, "spike": 3.0, "step": 0.2},
                      {"jump": 3.0, "spike": 1.0, "step": 0.1},
                      {"jump": 1.0, "spike": 3.0, "step": 0.3}]),
    ]


def ladder_of() -> list:
    """Щаблі драбини: що саме міняється у функції втрат."""
    return [
        ("той самий штраф", {}),
        ("стрибок удвічі дорожчий", {"jump": None, "times": 2.0}),
        ("прокол удвічі дорожчий", {"spike": None, "times": 2.0}),
        ("безплатний крок 0.1", {"step": 0.1}),
        ("зона вдвічі дорожча", {"zone": None, "times": 2.0}),
        ("фокальна втрата γ=2", {"focal": 2.0}),
        ("бік важить удвічі", {"side": 2.0}),
    ]


def stepped(knobs: dict, change: dict) -> dict:
    """Щабель поверх поточних ручок: `times` множить, решта — ставить."""
    out = dict(knobs)
    times = change.get("times")
    for key, value in change.items():
        if key == "times":
            continue
        out[key] = round(float(out[key]) * times, 4) if value is None \
            else value
    return out


def sharpness(proba: dict, coins: dict, pairs: tuple) -> dict:
    """Наскільки різко мережа рухає числа — те, за що штрафуємо."""
    steps, turns = [], []
    for pair in pairs:
        keep = coins[pair]["show"]
        for at in range(2):
            line = proba[pair][:, at]
            move = np.diff(line)
            both = keep[1:] & keep[:-1] & np.isfinite(move)
            if both.any():
                steps.append(np.abs(move[both]))
            if len(move) > 1:
                three = both[1:] & both[:-1]
                if three.any():
                    turns.append(np.maximum(-(move[1:] * move[:-1]), 0)[three])
    steps = np.concatenate(steps) if steps else np.array([0.0])
    turns = np.concatenate(turns) if turns else np.array([0.0])
    return {"step_median": round(float(np.median(steps)), 5),
            "step_high": round(float(np.quantile(steps, 0.99)), 5),
            "over_02": round(float(np.mean(steps > 0.2)), 5),
            "spike": round(float(turns.mean()), 6)}


def run_one(name: str, knobs: dict, coins: dict, pairs: tuple, epochs: int,
            seed: int, heads, start=None) -> dict:
    began = time.monotonic()
    fitted = heads.fit(coins, pairs, heads.judged(coins, pairs), epochs, seed,
                       log=lambda *_: None, knobs=knobs, start=start)
    proba = {pair: heads.walked(fitted["model"], coins[pair]["piece"],
                                coins[pair]["good"]) for pair in pairs}
    tune = heads.marks_of(proba, coins, pairs, "tune")
    val = heads.marks_of(proba, coins, pairs, "show")
    pick = float(np.mean([tune[one["key"]]["balanced"] for one in heads.HEADS]))
    mark = float(np.mean([val[one["key"]]["balanced"] for one in heads.HEADS]))
    got = {"name": name, "knobs": dict(knobs), "epoch": fitted["epoch"],
           "pick": round(pick, 4), "mark": round(mark, 4),
           "tune": {one["key"]: tune[one["key"]] for one in heads.HEADS},
           "val": {one["key"]: val[one["key"]] for one in heads.HEADS},
           "sharp": sharpness(proba, coins, pairs),
           "minutes": round((time.monotonic() - began) / 60, 1)}
    print(f"  {name:34s} відкладене {got['pick']:.4f} │ val {got['mark']:.4f}"
          f" · бік AUC {val['side']['auc']} · зона AUC {val['zone']['auc']}"
          f" · кроків >0.2 {got['sharp']['over_02']:.4f} · "
          f"{got['minutes']} хв")
    return got, fitted["model"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--ladder-epochs", type=int, default=LADDER_EPOCHS)
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_memory as memory
    import calls_train as train
    import legs_heads as heads

    pairs = tuple(args.pairs or train.PAIRS)
    got = train.gather(pairs, args.out)
    coins = got["coins"]
    norm = train.norm_of(got["learn"], np.ones(len(got["learn"]), dtype=bool))
    columns = memory.columns_of(got["names"], heads.FEED)
    for pair in pairs:
        one = coins[pair]
        data = one["data"]
        one["piece"] = train.applied(one["x"], norm)[:, columns]
        side, zone = heads.target_of(len(data["t"]), data["pivot_at"],
                                     data["pivot_up"])
        one["side"], one["zone"] = side.astype(np.int64), zone.astype(np.int64)
        for part in ("keep", "tune", "show"):
            one[part] = one[part] & (side >= 0)

    best, best_model, grid = None, None, []
    knobs = dict(heads.KNOBS)
    for title, plan in rounds_of():
        print(f"\n=== коло «{title}»: варіантів {len(plan)}")
        rows = []
        for change in plan:
            now = dict(knobs, **change)
            name = " · ".join(f"{key} {value}" for key, value
                              in change.items())
            one, model = run_one(name, now, coins, pairs, args.epochs,
                                 args.seed, heads)
            one["group"] = title
            rows.append(one)
            if best is None or one["pick"] > best["pick"]:
                best, best_model = one, model
        pick = max(rows, key=lambda one: one["pick"])
        knobs = dict(knobs, **pick["knobs"])
        grid.append({"group": title, "rows": rows, "best": pick["name"],
                     "pick": pick["pick"]})
        print(f"  → краще: {pick['name']} (відкладене {pick['pick']})")

    print(f"\nгрід обрав: {best['name']} · ручки "
          + " · ".join(f"{key} {value}" for key, value in best["knobs"].items()
                       if key in ("hid", "lr", "drop", "zone", "step", "jump",
                                  "spike")))

    # --- фаза 2: драбина функцій втрат від ваг переможця
    print(f"\n=== драбина втрат: щаблів {len(ladder_of())}, по "
          f"{args.ladder_epochs} епох")
    state = {key: value.detach().clone()
             for key, value in best_model.state_dict().items()}
    now, ladder, stood = dict(best["knobs"]), [], best
    for name, change in ladder_of():
        step = stepped(now, change)
        one, model = run_one(name, step, coins, pairs, args.ladder_epochs,
                             args.seed, heads, start=state)
        kept = one["pick"] > stood["pick"]
        one.update({"knobs_step": step, "kept": kept,
                    "was": stood["pick"]})
        ladder.append(one)
        print(f"     {'ЛИШАЮ' if kept else 'вертаю'} "
              f"({one['pick']:.4f} проти {stood['pick']:.4f})")
        if kept:
            stood, now = one, step
            state = {key: value.detach().clone()
                     for key, value in model.state_dict().items()}
            best_model = model

    keep_dir = MODELS / "legs_heads"
    keep_dir.mkdir(parents=True, exist_ok=True)
    torch.save(best_model.state_dict(), keep_dir / "grid.pt")
    np.savez_compressed(keep_dir / "grid_norm.npz", mid=norm["mid"],
                        wide=norm["wide"], columns=columns)

    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "seed": args.seed, "epochs": args.epochs,
        "ladder_epochs": args.ladder_epochs,
        "heads": list(heads.HEADS), "base": dict(heads.KNOBS),
        "grid": grid, "ladder": ladder,
        "best": {"name": best["name"], "knobs": best["knobs"],
                 "pick": best["pick"], "mark": best["mark"]},
        "final": {"name": stood["name"], "knobs": stood["knobs"],
                  "pick": stood["pick"], "mark": stood["mark"],
                  "val": stood["val"], "sharp": stood["sharp"]},
        "weights": str((keep_dir / "grid.pt").relative_to(PROJECT_ROOT))}
    path = args.out / "legs_grid.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    print(f"\nпісля драбини: {stood['name']} · відкладене {stood['pick']} · "
          f"val {stood['mark']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
