"""Видачі моделей на одній осі: вхід для сигналу купівлі й продажу.

Дослідження: research/33-buy-sell-signal/
Правила: rules/01-data-and-db.md → Класи (події)

Вкладка «Драбина втрат» показує пʼять мереж рядом під ціною, але кожну
**окремо** і тільки на val. Щоб з їхніх видач зробити один сигнал, треба
дві речі: усі видачі на **спільній осі подій** і на **train теж** —
інакше нема на чому вчити поєднання.

## Які мережі беруться

    tooth   `legtooth` — зубець кінця ноги, сира видача (дослідження 32)
    line    `legline`  — частка пройденої ноги, 0…1 (дослідження 32)
    p100    `hazard100` — «півот у наступні 100 подій» (дослідження 20)
    p10…p640 `hazard4`  — чотири горизонти тієї самої мережі
    pivot   `zone` — «це зона розвороту» (дослідження 31)
    correct `zone` — «це зона корекції всередині ноги»

Замість `legleft` і `legtip` драбини стоять наші `legtooth` і `legline`
з тією самою роботою — «де кінець ноги» і «де ми в нозі». Причина не
смакова: `legleft` іде за **фальшивим** півотом, підставленим у канали
розмітки (міра 0.776 → 5.79, `results/fake_pivot_BTC_USDT.json`
дослідження 32), тобто тримається на розмітці, якої в торгівлі немає.
`legtooth` і `legline` розмітки не бачать: у їхній рамці всі чотири
канали розмітки погашені, а «своя нога» дорівнює одиниці скрізь.

## Спільна вісь

Вісь — події `клас210х10-1х7д/д` **своєї монети**, ті самі, що в
дослідженнях 30–32; межа train|val береться з самого датасету. Мережі
живуть на різних розмітках, але всі на сітці 210 с, тому видача
кладеться на вісь за часом події, і тільки якщо найближча подія осі
ближча за пів кроку (105 с). Чого немає — `NaN`, а не нуль.

Подія рахується, коли є **основні** чотири канали (`tooth`, `line`,
`pivot`, `correct`); горизонти `hazard` живуть на коротшому ряді, і
їхня відсутність — окрема ознака, а не привід викинути подію.

## Чому на процесорі

Та сама причина, що в `val_series.py` дослідження 32: прохід LSTM на
`mps` дає різну видачу залежно від того, чи був у процесі зворотний
прохід. Тут потрібні саме ті числа, що й у заміру, тому `--device cpu`.

Вхід : ваги моделей досліджень 20, 31 і 32
Вихід: results/calls_<модель>_<PAIR>.npz — видача однієї мережі
       results/calls_input_<PAIR>.npz    — зшитий вхід на осі монети
       results/calls_input.json          — покриття кожного каналу

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_data.py            усе
    python3 research/33-buy-sell-signal/scripts/calls_data.py --model zone
    python3 research/33-buy-sell-signal/scripts/calls_data.py --join
    python3 research/33-buy-sell-signal/scripts/calls_data.py --pairs BTC_USDT
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
LADDER = PROJECT_ROOT / "research" / "32-loss-ladder"
RESULTS = RESEARCH_DIR / "results"
PAIR = "BTC_USDT"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
SEED = 17
DEVICE = "cpu"
HALF = 105                    # пів події сітки 210 с: далі це вже сусід
MODELS = ("split", "hazard100", "hazard4", "zone")
JOINED = "calls_input_{pair}.npz"
REPORT = "calls_input.json"
SCRIPT = "research/33-buy-sell-signal/scripts/calls_data.py"

# Канали входу в тому порядку, в якому вони лягають у матрицю.
CHANNELS = ("tooth", "line", "p100", "p10", "p40", "p160", "p640",
            "pivot", "correct")
# Без цих чотирьох подія не рахується взагалі; горизонти `hazard` живуть
# на своєму, коротшому ряді, і їхня відсутність — окрема ознака входу.
CORE = ("tooth", "line", "pivot", "correct")


def sibling(name: str, where: Path = LADDER / "scripts"):
    """Скрипт сусіднього дослідження — за шляхом файлу, а не за іменем.

    У проєкті два `pivot_zone.py` і два `zone_train.py`; імпорт за
    іменем підняв би той, що трапиться першим у `sys.path`.
    """
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        f"calls33_{name}", where / f"{name}.py")
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    return one


def lift(model, path: Path) -> None:
    import torch

    if not path.exists():
        raise SystemExit(f"немає ваг: {path}")
    model.load_state_dict(torch.load(path, map_location="cpu"))


def save(name: str, blocks: dict, out: Path) -> list:
    """Видача однієї мережі: окремий файл на монету."""
    out.mkdir(parents=True, exist_ok=True)
    done = []
    for pair, block in blocks.items():
        path = out / f"calls_{name}_{pair}.npz"
        np.savez_compressed(path, t=np.asarray(block["t"], dtype=np.int64),
                            **{key: np.asarray(value, dtype=np.float32)
                               for key, value in block["values"].items()})
        print(f"записано: {path} — {len(block['t'])} подій, "
              f"канали {sorted(block['values'])}")
        done.append(path)
    return done


# ------------------------------------------------------------------ мережі

def series_split(pairs: tuple = PAIRS) -> dict:
    """Зубці й лінія поділу на всіх ногах монети — і train, і val."""
    sys.path.insert(0, str(LADDER / "scripts"))
    import ad_legleft as ad
    import share_train as share

    tooth = sibling("tooth_train")
    line = sibling("line_train")

    ctx = ad.prepare(force=True)
    ctx["device"] = DEVICE
    rows, built = ctx["rows"], ctx["built"]
    total = built["x"].shape[0]
    got = json.loads((LADDER / "results" / "line_train.json")
                     .read_text(encoding="utf-8"))
    win, warm = int(got.get("win", share.WIN)), int(got.get("warm",
                                                           share.WARM))
    level = float(got.get("level", 0.5))
    fade = float(got.get("fade", line.FADE))
    first, last = share.edges_of(rows, list(range(len(rows))), total)
    truth = share.truth_of(first, last)

    teeth = tooth.build_of(ctx, ad, SEED)
    lift(teeth, LADDER / "models" / "legtooth" / "model.pt")
    teeth.eval()
    drawn = tooth.build_of(ctx, ad, SEED)
    lift(drawn, LADDER / "models" / "legline" / "model.pt")

    out = {}
    for pair in pairs:
        picked = [one for one, row in enumerate(rows) if row["pair"] == pair]
        if not picked:
            print(f"{pair}: ніг немає")
            continue
        boxes = share.windows(share.spans_of(rows, picked), win, warm)
        seen = np.zeros(total, dtype=bool)
        for one in boxes:
            seen[one["first"]:one["last"] + 1] = True
        score = tooth.score_on(teeth, built, boxes, DEVICE, total)
        press = line.pressed(score, level)
        now = line.measure(drawn, built, rows, picked, boxes, press, truth,
                           seen, DEVICE, total, fade)
        index = np.flatnonzero(seen)
        print(f"  {pair}: ніг {len(picked)} · вікон {len(boxes)} · подій "
              f"{len(index)}")
        out[pair] = {"t": built["t"][index],
                     "values": {"tooth": score[index],
                                "line": now["said"][index]}}
    return out


def series_hazard(name: str, pairs: tuple = PAIRS) -> dict:
    """Горизонти «нога скінчиться в наступні N подій» на потоці монети."""
    sys.path.insert(0, str(LADDER / "scripts"))
    import hazard_common
    import hazard_net as hazard
    import torch

    ad = __import__("ad_hazard" if name == "hazard100" else "ad_hazard4")
    ctx = ad.prepare(force=True)
    model, _ = ad.build(ctx, SEED)
    lift(model, LADDER / "models" / name / "model.pt")
    model.eval()
    step = {"wmul": 1.0, "gamma": 0.0, "near": (0, 1.0), "window": 75,
            "lift": hazard_common.LIFT}
    out = {}
    for pair in pairs:
        stamps, values = [], {}
        for part in ("train", "val"):
            stream = next((one for one in ctx[part]
                           if one["pair"].startswith(pair)), None)
            if stream is None:
                continue
            with torch.no_grad():
                walked = hazard_common.walk(model, stream, ctx["knobs"],
                                            ctx["weights"], step)
            known = stream["known"]
            stamps.append(np.asarray(stream["t"], dtype=np.int64))
            for place, horizon in enumerate(hazard.HORIZONS):
                curve = np.where(known, walked["curve"][:, place], np.nan)
                values.setdefault(f"p{horizon}", []).append(curve)
        if not stamps:
            print(f"{pair}: потоку немає")
            continue
        out[pair] = {"t": np.concatenate(stamps),
                     "values": {key: np.concatenate(parts)
                                for key, parts in values.items()}}
        print(f"  {pair}: подій {len(out[pair]['t'])}")
    return out


def series_zone(name: str = "zone", pairs: tuple = PAIRS) -> dict:
    """Зона півота і зона корекції: два канали з трьох на кожній події."""
    sys.path.insert(0, str(LADDER / "scripts"))
    import ad_zone as ad
    from zones import MARKS

    model, one, head, weight = None, None, None, None
    out = {}
    for pair in pairs:
        coin = ad.base.coin_data(pair, ad.CLASS, ad.REDUCE, "all", None, None)
        for part in ("train", "val"):
            coin[f"blocks_{part}"] = ad.base.blocks_of(
                coin["where"], coin["legs"], coin["t"], coin["cut"], ad.STEP,
                part, "events")
        ctx = {"coins": [coin], "device": DEVICE,
               "labels": coin["labels"][np.concatenate(coin["blocks_train"])],
               "channels": int(coin["levels"].shape[1])}
        if model is None:
            model, _ = ad.build(ctx, SEED)
            lift(model, LADDER / "models" / name / "model.pt")
            one = ad.rungs()[0]["step"]
            head = "softmax" if one["loss"] == "softmax" else one["loss"]
            weight = ad.weight_of(ctx, one["cap"], head)
        stamps, values = [], {}
        for part in ("train", "val"):
            got = ad.base.run_blocks(model, ctx["coins"], part, ad.STEP,
                                     DEVICE, ad.CHUNK, False, None,
                                     weight=weight, head=head,
                                     confuse=one["confuse"],
                                     gamma=one["gamma"])
            index = got["index"].astype(int)
            stamps.append(np.asarray(coin["t"][index], dtype=np.int64))
            for key, channel in (("pivot", "pivot"),
                                 ("correct", "correction")):
                values.setdefault(key, []).append(
                    got["proba"][:, MARKS.index(channel)])
        out[pair] = {"t": np.concatenate(stamps),
                     "values": {key: np.concatenate(parts)
                                for key, parts in values.items()}}
        print(f"  {pair}: подій {len(out[pair]['t'])}")
    return out


MAKERS = {"split": series_split, "hazard100": series_hazard,
          "hazard4": series_hazard, "zone": series_zone}


# ------------------------------------------------------------------ кістяк

def skeleton(pair: str = PAIR, root: Path | None = None) -> dict:
    """Час, ціна, ема10 і півоти зігзага 2.3 % — усе на подіях монети."""
    sys.path.insert(0, str(PROJECT_ROOT / "research" / "30-inleg-events"
                           / "scripts"))
    sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
    import inleg_profile as inleg
    from class210ema4 import ema
    from zigzag import zigzag

    data = inleg.load(pair, inleg.CLASS, root)
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["open"], dtype=float)
    smooth = ema(price, inleg.PERIOD)
    pivots = [{"at": int(one.index), "t": int(stamps[one.index]),
               "ema": float(smooth[one.index]), "kind": one.kind}
              for one in zigzag(smooth, inleg.THRESHOLD)]
    return {"t": stamps, "price": price, "ema": smooth, "pivots": pivots,
            "cut": int(data["cut"]), "class": inleg.CLASS,
            "threshold": inleg.THRESHOLD, "period": inleg.PERIOD}


def nearest(axis: np.ndarray, stamps, gap: int = HALF) -> np.ndarray:
    """Куди лягає подія моделі на осі ряду; `-1` — нікуди."""
    stamps = np.asarray(stamps, dtype=np.int64)
    if not len(axis) or not len(stamps):
        return np.full(len(stamps), -1, dtype=np.int64)
    place = np.searchsorted(axis, stamps)
    left = np.clip(place - 1, 0, len(axis) - 1)
    right = np.clip(place, 0, len(axis) - 1)
    pick = np.where(np.abs(axis[left] - stamps)
                    <= np.abs(axis[right] - stamps), left, right)
    return np.where(np.abs(axis[pick] - stamps) <= gap, pick, -1)


def join(out: Path, pairs: tuple = PAIRS) -> dict:
    """Усі видачі на одну вісь монети: матриця каналів і покриття."""
    coins, missing = {}, set()
    for pair in pairs:
        bones = skeleton(pair)
        axis = bones["t"]
        total = len(axis)
        table = np.full((total, len(CHANNELS)), np.nan, dtype=np.float32)
        cover = {}
        for name in MODELS:
            path = out / f"calls_{name}_{pair}.npz"
            if not path.exists():
                missing.add(f"{name}/{pair}")
                continue
            got = np.load(path)
            place = nearest(axis, got["t"])
            good = place >= 0
            for key in got.files:
                if key == "t" or key not in CHANNELS:
                    continue
                column = CHANNELS.index(key)
                value = np.asarray(got[key], dtype=np.float32)
                table[place[good], column] = value[good]
                known = np.isfinite(table[:, column])
                cover[key] = {
                    "model": name,
                    "events": int(known.sum()),
                    "train": int((known & (axis < bones["cut"])).sum()),
                    "val": int((known & (axis >= bones["cut"])).sum())}
        ready = [key for key in CHANNELS if key in cover]
        columns = [CHANNELS.index(key) for key in ready]
        both = np.isfinite(table[:, columns]).all(axis=1) if ready \
            else np.zeros(total, dtype=bool)
        core = np.isfinite(table[:, [CHANNELS.index(key) for key in CORE
                                     if key in cover]]).all(axis=1) \
            if all(key in cover for key in CORE) else np.zeros(total,
                                                               dtype=bool)
        path = out / JOINED.format(pair=pair)
        np.savez_compressed(
            path, t=axis, price=bones["price"], ema=bones["ema"],
            table=table, full=both, core=core,
            pivot_at=np.array([one["at"] for one in bones["pivots"]],
                              dtype=np.int64),
            pivot_up=np.array([one["kind"] == "low"
                               for one in bones["pivots"]], dtype=bool))
        coins[pair] = {
            "events": total, "cut": bones["cut"],
            "train": int((axis < bones["cut"]).sum()),
            "val": int((axis >= bones["cut"]).sum()),
            "have": ready, "cover": cover,
            "full": {"events": int(both.sum()),
                     "train": int((both & (axis < bones["cut"])).sum()),
                     "val": int((both & (axis >= bones["cut"])).sum())},
            "core": {"events": int(core.sum()),
                     "train": int((core & (axis < bones["cut"])).sum()),
                     "val": int((core & (axis >= bones["cut"])).sum())},
            "pivots": {"all": len(bones["pivots"]),
                       "train": int(sum(one["t"] < bones["cut"]
                                        for one in bones["pivots"])),
                       "val": int(sum(one["t"] >= bones["cut"]
                                      for one in bones["pivots"]))},
            "class": bones["class"], "threshold": bones["threshold"],
            "period": bones["period"],
            "file": str(path.relative_to(PROJECT_ROOT))}
        print(f"{pair}: {total} подій · усі канали на "
              f"{coins[pair]['full']['events']} · основні на "
              f"{coins[pair]['core']['events']} · півотів "
              f"{coins[pair]['pivots']['all']} "
              f"({coins[pair]['pivots']['val']} val)")
    if missing:
        print(f"немає видачі: {', '.join(sorted(missing))}")
    report = {"script": SCRIPT, "ready": bool(coins), "pairs": list(coins),
              "channels": list(CHANNELS), "core": list(CORE),
              "coins": coins,
              "pivots": {"val": int(sum(one["pivots"]["val"]
                                        for one in coins.values())),
                         "train": int(sum(one["pivots"]["train"]
                                          for one in coins.values()))}}
    (out / REPORT).write_text(json.dumps(report, ensure_ascii=False,
                                         indent=2), encoding="utf-8")
    print(f"записано: {out / REPORT}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--model", choices=MODELS)
    parser.add_argument("--join", action="store_true")
    parser.add_argument("--pairs", nargs="+", default=list(PAIRS))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    pairs = tuple(args.pairs)
    if args.model:
        maker = MAKERS[args.model]
        blocks = maker(args.model, pairs) if args.model.startswith("hazard") \
            else maker(pairs=pairs)
        save(args.model, blocks, args.out)
        return
    if args.join:
        join(args.out, pairs)
        return
    for name in MODELS:
        print(f"\n=== {name}")
        done = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                               "--model", name, "--out", str(args.out),
                               "--pairs", *pairs])
        if done.returncode:
            raise SystemExit(f"{name}: прогін упав")
    join(args.out, pairs)


if __name__ == "__main__":
    main()
