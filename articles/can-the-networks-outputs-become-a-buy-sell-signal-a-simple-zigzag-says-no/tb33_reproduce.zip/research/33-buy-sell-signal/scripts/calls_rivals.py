"""Драбина порогів суперника: на якому відході від крайньої точки міряти.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → базові рівні

Розмітка проєкту — зігзаг **2.3 %** на ема10: саме його півоти є ціллю.
Суперник же — інше: причинне правило «ема відійшла від крайньої точки
на `X` %», яке нічого не знає про розмітку і спрацьовує тоді, коли це
видно в ряді. Порогу `X` розмітка не задає, і в першому заміру він був
узятий зі стелі — 1.2 %, «приблизно пів ноги».

Тут він міряється драбиною: від 0.4 % до 3.0 %. Нічого не вчиться,
модель не потрібна — правило рахується просто по ема, тією самою мірою
і на тому самому val, що і все інше в дослідженні.

Поруч із кожним щаблем іде **монетка тієї самої частоти**. Без неї
драбина обманює: нижчий поріг дає більше сигналів, а чим їх більше, тим
легше котромусь опинитися біля півота випадково. Питання щабля — не
«скільки влучив», а «наскільки більше за монетку з такою самою
кількістю сигналів».

Вхід : results/calls_input_<PAIR>.npz
Вихід: results/calls_rivals.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_rivals.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
RESULTS = RESEARCH_DIR / "results"
STEPS = (0.004, 0.006, 0.008, 0.012, 0.016, 0.023, 0.030)
# Крива випадковості: скільки розворотів бере монетка, якщо їй дати
# стільки ж сигналів. Кожна точка — середнє по `SEEDS` роздачах.
CHANCE = (40, 60, 90, 120, 150, 200, 300, 420)
SEEDS = 20
SCRIPT = "research/33-buy-sell-signal/scripts/calls_rivals.py"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--steps", nargs="+", type=float, default=list(STEPS))
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    coins = {}
    for pair in pairs:
        data = train.load(pair, args.out)
        built = train.features_of(data)
        good = np.isfinite(built["x"]).all(axis=1) & data["core"]
        coins[pair] = {"data": data, "show": good & (data["t"] >= data["cut"])}

    rungs = {}
    for step in args.steps:
        rows = {}
        for pair in pairs:
            data, mask = coins[pair]["data"], coins[pair]["show"]
            fires = train.zigzag_calls(np.asarray(data["ema"], dtype=float),
                                       mask, step)
            rows[pair] = train.measure(fires, data, mask, train.BEFORE,
                                       train.AFTER)
        coins_row = {}
        for pair in pairs:
            data, mask = coins[pair]["data"], coins[pair]["show"]
            coins_row[pair] = train.measure(
                train.coin_calls(mask, rows[pair]["fires"], train.SEED),
                data, mask, train.BEFORE, train.AFTER)
        got = train.pooled(list(rows.values()))
        flip = train.pooled(list(coins_row.values()))
        rungs[f"{step * 100:.1f}"] = {
            "threshold": step, "by_pair": rows, "pooled": got,
            "coin": {"by_pair": coins_row, "pooled": flip},
            "lift": {key: round(got["caught"][key] / flip["caught"][key], 2)
                     if flip["caught"][key] else None
                     for key in got["caught"]}}

    # Щабель вибирається не самим влучанням, а перевагою над монеткою
    # тієї самої частоти: інакше виграє просто найчастіший сигнал.
    # Крива випадковості по частоті: сигнали розкидані по монетах у
    # тій пропорції, у якій між ними поділені події.
    weights = {pair: int(coins[pair]["show"].sum()) for pair in pairs}
    whole = max(sum(weights.values()), 1)
    chance = {}
    for count in CHANCE:
        rows = []
        for seed in range(SEEDS):
            one = {}
            for pair in pairs:
                data, mask = coins[pair]["data"], coins[pair]["show"]
                share = max(int(round(count * weights[pair] / whole)), 1)
                one[pair] = train.measure(
                    train.coin_calls(mask, share, seed * 101 + 7),
                    data, mask, train.BEFORE, train.AFTER)
            rows.append(train.pooled(list(one.values())))
        chance[str(count)] = {
            "fires": int(round(float(np.mean([one["fires"]
                                              for one in rows])))),
            "caught": {key: round(float(np.mean([one["caught"][key]
                                                 for one in rows])), 4)
                       for key in rows[0]["caught"]},
            "gap_abs": round(float(np.mean([one["gap_abs"] for one in rows
                                            if one["gap_abs"] is not None])),
                             1),
            "seeds": SEEDS}

    best = max(rungs.items(),
               key=lambda one: one[1]["lift"]["15"] or 0.0)
    report = {"script": SCRIPT, "ready": True, "pairs": list(pairs),
              "markup": 0.023, "zone": {"before": train.BEFORE,
                                        "after": train.AFTER},
              "tolerance": list(train.TOLERANCE),
              "steps": [float(one) for one in args.steps],
              "rungs": rungs, "best": best[0], "chance": chance,
              "seeds": SEEDS}
    path = args.out / "calls_rivals.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2),
                    encoding="utf-8")

    print("причинний зігзаг на val, шість монет:")
    for key, block in rungs.items():
        one = block["pooled"]
        two = block["coin"]["pooled"]
        print(f"  {key:>4s} % · сигналів {one['fires']:4d} · ±15 "
              f"{one['caught']['15']} (монетка {two['caught']['15']}, "
              f"×{block['lift']['15']}) · ±50 {one['caught']['50']} "
              f"(монетка {two['caught']['50']}, ×{block['lift']['50']}) · "
              f"медіана |зсуву| {one['gap_abs']} · взято "
              f"{one['money']['share']} % ходу")
    print(f"найкращий щабель за перевагою над монеткою ±15: {best[0]} %")
    print(f"\nкрива випадковості ({SEEDS} роздач на точку):")
    for key, one in chance.items():
        print(f"  {one['fires']:4d} сигналів · ±5 {one['caught']['5']} · ±15 "
              f"{one['caught']['15']} · ±50 {one['caught']['50']} · ±100 "
              f"{one['caught']['100']} · медіана |зсуву| {one['gap_abs']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
