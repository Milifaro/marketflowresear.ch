"""Ряд val: ціна, сигнали купівлі й продажу і видачі, з яких вони зібрані.

Дослідження: research/33-buy-sell-signal/
Правила: rules/05-visualization.md → компоновка

Числа `calls_train.py` кажуть, скільки розворотів узято і з яким зсувом.
Тут те саме видно очима на одній монеті: ціна з зігзагом 2.3 % зверху,
під нею — де стали сигнали, ще нижче — два числа поєднувача, і в
підвалі — самі канали, з яких воно зроблено.

Замір іде на процесорі й **не вчить нічого**: ваги піднімаються з
`models/calls/model.pt`, нормування — з `models/calls/norm.npz`. Поріг
береться з `results/calls_train.json`, тобто той самий, що поставлений
на відкладеному шматку train.

Вхід : results/calls_input_<PAIR>.npz, models/calls/*
Вихід: results/calls_series_<PAIR>.json

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_series.py
    python3 research/33-buy-sell-signal/scripts/calls_series.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
PAIR = "BTC_USDT"
SHOWN = ("tooth", "line", "p100", "pivot", "correct")
TITLES = {"buy": "купівля", "sell": "продаж", "tooth": "зубець кінця ноги",
          "line": "частка ноги", "p100": "півот у 100 подій",
          "pivot": "зона розвороту", "correct": "зона корекції"}
SCRIPT = "research/33-buy-sell-signal/scripts/calls_series.py"


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def build(pair: str, out: Path) -> dict:
    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_look as look
    import calls_train as train

    data = train.load(pair, out)
    report = json.loads((out / "calls_train.json").read_text(
        encoding="utf-8"))
    built = train.features_of(data)
    good = np.isfinite(built["x"]).all(axis=1) & data["core"]
    show = good & (data["t"] >= data["cut"])
    kept = np.load(MODELS / "calls" / "norm.npz")
    norm = {"mid": kept["mid"], "wide": kept["wide"]}
    # Ваги збережені для того набору ознак, який виграв на відкладеному
    # шматку, — його колонки лежать поруч із нормуванням
    columns = kept["columns"].astype(int)
    piece = train.applied(built["x"], norm)[:, columns]
    model = train.build(piece.shape[1], report["seed"])
    model.load_state_dict(torch.load(MODELS / "calls" / "model.pt",
                                     map_location="cpu"))
    model.eval()
    proba = train.probable(model, piece, good)
    strength = np.nanmax(proba[:, 1:], axis=1)
    side = np.where(proba[:, 1] >= proba[:, 2], 1, -1).astype(np.int8)
    level = float(report["level"])
    fires = train.fires_of(strength, side, level, show)
    marks = train.measure(fires, data, show, train.BEFORE, train.AFTER)
    ema = np.asarray(data["ema"], dtype=float)
    zigzag = train.zigzag_calls(ema, show, train.ZIGZAG)
    moved = train.shifted(zigzag, strength, show, train.BACK)

    index = np.flatnonzero(data["t"] >= data["cut"])
    price = np.asarray(data["price"], dtype=float)
    stamps = np.asarray(data["t"], dtype=np.int64)
    inside = (data["pivot_at"] >= index[0]) & (data["pivot_at"] <= index[-1])
    zone = look.zone_of(len(stamps), data["pivot_at"], train.BEFORE,
                        train.AFTER)
    block = {
        "script": SCRIPT, "ready": True, "pair": pair,
        "device": "cpu", "level": round(level, 4),
        "zone": {"before": train.BEFORE, "after": train.AFTER},
        "events": int(len(index)),
        "from": int(stamps[index[0]]), "to": int(stamps[index[-1]]),
        "t": [int(one) for one in stamps[index]],
        "price": rounded(price[index], 2),
        "ema": rounded(np.asarray(data["ema"], dtype=float)[index], 2),
        "in_zone": [int(one) for one in zone[index]],
        # `ema` обовʼязкове: зігзаг малюється по ема10, і саме з цього
        # поля полотно бере висоту півота
        "pivots": [{"t": int(stamps[one]),
                    "price": round(float(price[one]), 2),
                    "ema": round(float(np.asarray(data["ema"],
                                                  dtype=float)[one]), 2),
                    "kind": "low" if low else "high"}
                   for one, low in zip(data["pivot_at"][inside],
                                       data["pivot_up"][inside])],
        "buy": rounded(proba[index, 1]),
        "sell": rounded(proba[index, 2]),
        "fires": [{"t": int(stamps[one["at"]]),
                   "price": round(float(price[one["at"]]), 2),
                   "side": int(one["side"])} for one in fires],
        "zigzag": [{"t": int(stamps[one["at"]]),
                    "price": round(float(price[one["at"]]), 2),
                    "side": int(one["side"])} for one in zigzag],
        "moved": [{"t": int(stamps[one["at"]]),
                   "price": round(float(price[one["at"]]), 2),
                   "side": int(one["side"])} for one in moved],
        "back": train.BACK,
        "zigzag_marks": train.measure(zigzag, data, show, train.BEFORE,
                                      train.AFTER),
        "moved_marks": train.measure(moved, data, show, train.BEFORE,
                                     train.AFTER),
        "lines": [{"key": key, "title": TITLES.get(key, key)}
                  for key in SHOWN if key in data["have"]],
        "marks": marks,
        "others": {key: value["by_pair"].get(pair)
                   for key, value in report["others"].items()},
        "moved_by": {key: value["by_pair"].get(pair)
                     for key, value in report.get("moved", {}).items()},
        "weights": report["weights"]}
    for key in SHOWN:
        if key in data["have"]:
            column = data["channels"].index(key)
            block[key] = rounded(data["table"][index, column])
    return block


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pair", default=PAIR)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    block = build(args.pair, args.out)
    path = args.out / f"calls_series_{args.pair}.json"
    path.write_text(json.dumps(block, ensure_ascii=False), encoding="utf-8")
    one = block["marks"]
    print(f"{args.pair}: {block['events']} подій · сигналів "
          f"{one['fires']} на {one['legs']} півотів · влучань ±50 "
          f"{one['caught'].get('50')} · у зоні {one['in_zone']} · взято "
          f"{one['money'].get('share')} % ходу")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
