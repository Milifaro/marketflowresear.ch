"""Мережа ноги на дві голови: бік ноги і зона розвороту окремо.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → навчання моделей

`legs_train.py` ставив одну голову на три класи, і зона розвороту
воювала там із боком ноги: подія в зоні втрачала напрямок. Тут те саме
розділено на **дві незалежні відповіді** на кожній події:

    бік     0 — нога вниз, 1 — нога вгору (нога, якій подія належить)
    зона    1 — це зона розвороту, 0 — тіло ноги

Тепер подія в зоні розвороту **зберігає** свій бік, а мережа може
сказати «нога вгору і ми в зоні її кінця» — чого три класи виразити не
могли.

Мережа й вхід ті самі, що в `LSTM · сире`: 11 миттєвих чисел, 64
нейрони, один шар, шматки по 1024 події з прогрівом 200, `Adam` 0.002,
20 епох, `seed 17`. Голова одна замість трьох чисел дає два логіти,
втрата — сума двох `BCEWithLogits`, у зони позитив дорожчий у
`ZONE_COST` разів (її подій приблизно ушестеро менше).

Епоха обирається середнім **збалансованої точності** двох голів на
відкладеному шматку train — інакше кожна голова візьме свою більшість.

Вхід : results/calls_input_<PAIR>.npz
Вихід: results/legs_heads.json,
       results/legs_heads_series_<PAIR>_<val|all>.json,
       models/legs_heads/model.pt, models/legs_heads/norm.npz

Запуск:
    python3 research/33-buy-sell-signal/scripts/legs_heads.py
    python3 research/33-buy-sell-signal/scripts/legs_heads.py --epochs 5
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
SEED = 17
FEED = "сире"
SHARE = 0.10                  # хвіст зони — частка своєї ноги
FLOOR = 5
AFTER = 15                    # голова зони, у подіях
EDGE = 0.5                    # поріг обох голів
# Ручки навчання в одному місці: `legs_grid.py` перебирає саме їх, і
# нижче стоїть **переможець** того гріду (коло за колом на відкладеному
# шматку train).
KNOBS = {"hid": 128, "layers": 1, "drop": 0.1, "lr": 0.001, "decay": 1e-4,
         "zone": 3.0,          # у скільки разів позитив зони дорожчий
         "step": 0.2,          # безплатний крок числа між сусідніми подіями
         "jump": 1.0,          # ціна кроку понад `step`
         "spike": 1.0,         # ціна розвороту руху — прокол і повернення
         "focal": 0.0,         # степінь фокусування втрати на важких подіях
         "side": 1.0}          # вага голови боку в сумі втрат
PARTS = ("val", "all")
HEADS = ({"key": "side", "title": "бік ноги",
          "names": ["нога вниз", "нога вгору"]},
         {"key": "zone", "title": "зона розвороту",
          "names": ["тіло ноги", "зона розвороту"]})
SCRIPT = "research/33-buy-sell-signal/scripts/legs_heads.py"


def build(width: int, seed: int = SEED, knobs: dict | None = None):
    """Та сама LSTM, але на виході два числа замість трьох."""
    import torch
    from torch import nn

    knobs = dict(KNOBS, **(knobs or {}))
    torch.manual_seed(seed)

    class Heads(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.rnn = nn.LSTM(width, int(knobs["hid"]),
                               num_layers=int(knobs["layers"]),
                               batch_first=True)
            self.drop = nn.Dropout(knobs["drop"])
            self.head = nn.Linear(int(knobs["hid"]), 2)

        def forward(self, steps, state=None):
            out, state = self.rnn(steps, state)
            return self.head(self.drop(out)), state

    return Heads()


def target_of(total: int, pivots: np.ndarray, ups: np.ndarray) -> tuple:
    """Дві мітки на подію: бік ноги і чи це зона розвороту.

    `-1` у боці — мітки немає (подія поза крайніми півотами ряду).
    """
    import calls_look as look

    side = np.full(total, -1, dtype=np.int8)
    zone = np.zeros(total, dtype=np.int8)
    for at in range(len(pivots) - 1):
        start, stop = int(pivots[at]), int(pivots[at + 1])
        side[start:stop] = 1 if ups[at] else 0
    for one, tail in zip(pivots, look.tails_of(pivots, SHARE, FLOOR)):
        low = max(int(one) - int(tail), 0)
        high = min(int(one) + AFTER + 1, total)
        zone[low:high] = 1
    zone[side < 0] = 0
    return side, zone


def walked(model, x: np.ndarray, good: np.ndarray) -> np.ndarray:
    """Два числа на подію одним проходом по ряду монети."""
    import torch

    sys.path.insert(0, str(SCRIPTS))
    import calls_memory as memory

    out = np.full((len(x), 2), np.nan, dtype=np.float32)
    model.eval()
    state = None
    with torch.no_grad():
        for start in range(0, len(x), memory.STRIDE):
            piece = torch.from_numpy(x[start:start + memory.STRIDE]
                                     ).unsqueeze(0)
            got, state = model(piece, state)
            out[start:start + memory.STRIDE] = torch.sigmoid(got[0]).numpy()
    out[~good] = np.nan
    return out


def scored(said: np.ndarray, want: np.ndarray, keep: np.ndarray) -> dict:
    """Дві на дві: влучання, повнота, точність і збалансована точність."""
    mask = keep & (want >= 0) & np.isfinite(said.astype(float))
    grid = [[int(((want == one) & (said == two) & mask).sum())
             for two in range(2)] for one in range(2)]
    recall, precision = [], []
    for one in range(2):
        seen = sum(grid[one])
        recall.append(round(grid[one][one] / seen, 4) if seen else None)
        told = sum(grid[two][one] for two in range(2))
        precision.append(round(grid[one][one] / told, 4) if told else None)
    total = int(mask.sum())
    right = grid[0][0] + grid[1][1]
    known = [one for one in recall if one is not None]
    return {"grid": grid, "recall": recall, "precision": precision,
            "events": total,
            "accuracy": round(right / total, 4) if total else None,
            "balanced": round(float(np.mean(known)), 4) if known else None,
            "share": round(sum(grid[1]) / total, 4) if total else None}


def ranked(values: np.ndarray) -> np.ndarray:
    """Ранги з усередненням однакових: без цього рівні числа дають AUC 0."""
    order = np.argsort(values, kind="mergesort")
    line = values[order]
    out = np.empty(len(values), dtype=float)
    at = 0
    while at < len(line):
        stop = at
        while stop + 1 < len(line) and line[stop + 1] == line[at]:
            stop += 1
        out[order[at:stop + 1]] = (at + stop) / 2 + 1
        at = stop + 1
    return out


def auc_of(value: np.ndarray, want: np.ndarray, keep: np.ndarray):
    mask = keep & (want >= 0) & np.isfinite(value)
    pos, neg = value[mask & (want == 1)], value[mask & (want == 0)]
    if not len(pos) or not len(neg):
        return None
    rank = ranked(np.concatenate([pos, neg]))
    return round(float((rank[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2)
                       / (len(pos) * len(neg))), 4)


def marks_of(proba: dict, coins: dict, pairs: tuple, part: str) -> dict:
    """Числа обох голів на одному шматку, разом по монетах."""
    out = {}
    for at, head in enumerate(HEADS):
        said = np.concatenate([(proba[pair][:, at] >= EDGE).astype(np.int8)
                               for pair in pairs])
        value = np.concatenate([proba[pair][:, at] for pair in pairs])
        want = np.concatenate([coins[pair][head["key"]] for pair in pairs])
        keep = np.concatenate([coins[pair][part] for pair in pairs])
        if head["key"] == "zone":            # зона є лише там, де є бік
            want = np.where(np.concatenate(
                [coins[pair]["side"] for pair in pairs]) < 0, -1, want)
        got = scored(said, want, keep)
        got["auc"] = auc_of(value, want, keep)
        out[head["key"]] = got
    return out


def judged(coins: dict, pairs: tuple):
    def judge(model):
        proba = {pair: walked(model, coins[pair]["piece"],
                              coins[pair]["good"]) for pair in pairs}
        got = marks_of(proba, coins, pairs, "tune")
        marks = [got[one["key"]]["balanced"] for one in HEADS
                 if got[one["key"]]["balanced"] is not None]
        return {"mark": round(float(np.mean(marks)), 4) if marks else 0.0,
                "level": 0.0}
    return judge


def steady(said, keep, knobs: dict):
    """Штраф за різкість: великий крок і прокол із поверненням.

    `said` — логіти шматка, `keep` — де подія вчиться. Беруться самі
    числа після сигмоїди: крок понад `step` коштує квадратично (щоб
    мережа казала три кроки по 0.2 замість одного на 0.6), а прокол —
    це рух, який одразу розвертається, і його ціна дорівнює добутку
    двох сусідніх рухів.
    """
    import torch

    if not knobs["jump"] and not knobs["spike"]:
        return said.sum() * 0.0
    value = torch.sigmoid(said)
    move = value[:, 1:] - value[:, :-1]
    both = keep[:, 1:] & keep[:, :-1]
    if not bool(both.any()):
        return said.sum() * 0.0
    jump = torch.relu(move.abs()[both] - knobs["step"]).pow(2).mean()
    spike = said.sum() * 0.0
    if move.shape[1] > 1:
        turn = torch.relu(-(move[:, 1:] * move[:, :-1]))
        three = both[:, 1:] & both[:, :-1]
        if bool(three.any()):
            spike = turn[three].mean()
    return knobs["jump"] * jump + knobs["spike"] * spike


def binary(said, want, weight=None, gamma: float = 0.0):
    """`BCE`, а за `gamma > 0` — фокальна: легкі події дешевшають."""
    import torch
    from torch import nn

    loss = nn.functional.binary_cross_entropy_with_logits(
        said, want, pos_weight=weight, reduction="none")
    if gamma:
        value = torch.sigmoid(said)
        near = want * value + (1 - want) * (1 - value)
        loss = loss * (1 - near).pow(gamma)
    return loss.mean()


def fit(coins: dict, pairs: tuple, judge, epochs: int, seed: int,
        log=print, knobs: dict | None = None, start=None) -> dict:
    """Той самий хід шматками, але втрата — сума двох голів і різкості."""
    import torch
    from torch import nn

    sys.path.insert(0, str(SCRIPTS))
    import calls_memory as memory

    knobs = dict(KNOBS, **(knobs or {}))
    width = coins[pairs[0]]["piece"].shape[1]
    model = build(width, seed, knobs)
    if start is not None:                 # донавчання йде з готових ваг
        model.load_state_dict(start)
    opt = torch.optim.Adam(model.parameters(), lr=knobs["lr"],
                           weight_decay=knobs["decay"])
    cost = torch.tensor(knobs["zone"], dtype=torch.float32)
    pack = []
    for pair in pairs:
        for warm, start, stop in memory.blocks_of(coins[pair]["keep"]):
            pack.append((pair, warm, start, stop))
    rng = np.random.default_rng(seed)
    best, state, curve = None, None, []
    for number in range(1, epochs + 1):
        model.train()
        order = rng.permutation(len(pack))
        total, seen = 0.0, 0
        for at in range(0, len(order), memory.BATCH):
            rows = [pack[one] for one in order[at:at + memory.BATCH]]
            span = max(stop - warm for _, warm, _, stop in rows)
            hold = np.zeros((len(rows), span, width), dtype=np.float32)
            want = np.zeros((len(rows), span, 2), dtype=np.float32)
            keep = np.zeros((len(rows), span), dtype=bool)
            for row, (pair, warm, start, stop) in enumerate(rows):
                piece = coins[pair]["piece"][warm:stop]
                hold[row, :len(piece)] = piece
                want[row, :len(piece), 0] = coins[pair]["side"][warm:stop]
                want[row, :len(piece), 1] = coins[pair]["zone"][warm:stop]
                mask = np.zeros(stop - warm, dtype=bool)
                mask[start - warm:] = coins[pair]["keep"][start:stop]
                keep[row, :len(mask)] = mask
            opt.zero_grad()
            got, _ = model(torch.from_numpy(hold))
            mask = torch.from_numpy(keep)
            truth = torch.from_numpy(want)[mask]
            said = got[mask]
            loss = knobs["side"] * binary(said[:, 0], truth[:, 0],
                                          gamma=knobs["focal"]) \
                + binary(said[:, 1], truth[:, 1], cost, knobs["focal"]) \
                + steady(got, mask, knobs)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += float(loss.item()) * int(keep.sum())
            seen += int(keep.sum())
        got = judge(model)
        curve.append({"epoch": number, "loss": round(total / max(seen, 1), 4),
                      "mark": got["mark"]})
        if best is None or got["mark"] > best:
            best = got["mark"]
            state = {key: value.detach().clone()
                     for key, value in model.state_dict().items()}
            curve[-1]["best"] = True
        log(f"  епоха {number}: втрата {curve[-1]['loss']:.4f} · "
            f"збалансована точність {got['mark']:.4f}"
            f"{'  ← краще' if curve[-1].get('best') else ''}")
    model.load_state_dict(state)
    model.eval()
    return {"model": model, "curve": curve, "knobs": knobs,
            "epoch": int(max(one["epoch"] for one in curve
                             if one.get("best")))}


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def series_of(pair: str, part: str, data: dict, proba: np.ndarray,
              side: np.ndarray, zone: np.ndarray) -> dict:
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["price"], dtype=float)
    ema = np.asarray(data["ema"], dtype=float)
    index = np.flatnonzero(stamps >= data["cut"]) if part == "val" \
        else np.arange(len(stamps))
    inside = (data["pivot_at"] >= index[0]) & (data["pivot_at"] <= index[-1])
    said = np.where(np.isfinite(proba[:, 0]), (proba[:, 0] >= EDGE).astype(int),
                    -1)
    told = np.where(np.isfinite(proba[:, 1]), (proba[:, 1] >= EDGE).astype(int),
                    -1)
    return {
        "script": SCRIPT, "ready": True, "pair": pair, "part": part,
        "events": int(len(index)), "edge": EDGE,
        "from": int(stamps[index[0]]), "to": int(stamps[index[-1]]),
        "t": [int(one) for one in stamps[index]],
        "price": rounded(price[index], 2), "ema": rounded(ema[index], 2),
        "p_side": rounded(proba[index, 0]), "p_zone": rounded(proba[index, 1]),
        "said_side": [int(one) for one in said[index]],
        "said_zone": [int(one) for one in told[index]],
        "want_side": [int(one) for one in side[index]],
        "want_zone": [int(one) for one in zone[index]],
        "pivots": [{"t": int(stamps[one]), "price": round(float(price[one]), 2),
                    "ema": round(float(ema[one]), 2),
                    "kind": "low" if low else "high"}
                   for one, low in zip(data["pivot_at"][inside],
                                       data["pivot_up"][inside])]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_memory as memory
    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    epochs = args.epochs or memory.EPOCHS
    seed = args.seed or SEED
    got = train.gather(pairs, args.out)
    coins = got["coins"]
    norm = train.norm_of(got["learn"], np.ones(len(got["learn"]), dtype=bool))
    columns = memory.columns_of(got["names"], FEED)
    for pair in pairs:
        one = coins[pair]
        data = one["data"]
        one["piece"] = train.applied(one["x"], norm)[:, columns]
        side, zone = target_of(len(data["t"]), data["pivot_at"],
                               data["pivot_up"])
        one["side"], one["zone"] = side.astype(np.int64), zone.astype(np.int64)
        one["keep"] = one["keep"] & (side >= 0)
        one["tune"] = one["tune"] & (side >= 0)
        one["show"] = one["show"] & (side >= 0)

    fitted = fit(coins, pairs, judged(coins, pairs), epochs, seed)
    model = fitted["model"]
    keep_dir = MODELS / "legs_heads"
    keep_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), keep_dir / "model.pt")
    np.savez_compressed(keep_dir / "norm.npz", mid=norm["mid"],
                        wide=norm["wide"], columns=columns)

    proba = {pair: walked(model, coins[pair]["piece"], coins[pair]["good"])
             for pair in pairs}
    marks = {"val": marks_of(proba, coins, pairs, "show"),
             "tune": marks_of(proba, coins, pairs, "tune")}
    by_pair = {pair: marks_of({pair: proba[pair]}, coins, (pair,), "show")
               for pair in pairs}

    # Контролі на кожну голову: стала більшість і монетка за часткою
    controls, rng = {}, np.random.default_rng(seed)
    for at, head in enumerate(HEADS):
        want = np.concatenate([coins[pair][head["key"]] for pair in pairs])
        keep = np.concatenate([coins[pair]["show"] for pair in pairs])
        if head["key"] == "zone":
            want = np.where(np.concatenate(
                [coins[pair]["side"] for pair in pairs]) < 0, -1, want)
        share = float(np.mean(want[keep & (want >= 0)] == 1))
        big = int(share >= 0.5)
        controls[head["key"]] = {
            "стала": {"class": head["names"][big],
                      **scored(np.full(len(want), big, dtype=np.int64), want,
                               keep)},
            "монетка за часткою": scored(
                (rng.random(len(want)) < share).astype(np.int64), want, keep)}

    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs), "seed": seed,
        "feed": FEED, "features": int(len(columns)), "heads": list(HEADS),
        "edge": EDGE, "zone": {"share": SHARE, "floor": FLOOR,
                               "after": AFTER,
                               "cost": fitted["knobs"]["zone"]},
        "knobs": fitted["knobs"],
        "shape": {"hid": fitted["knobs"]["hid"],
                  "layers": fitted["knobs"]["layers"],
                  "drop": fitted["knobs"]["drop"],
                  "lr": fitted["knobs"]["lr"], "block": memory.BLOCK,
                  "warm": memory.WARM, "batch": memory.BATCH,
                  "epochs": epochs},
        "epoch": fitted["epoch"], "curve": fitted["curve"],
        "marks": marks, "by_pair": by_pair, "controls": controls,
        "parts": [{"key": "val", "title": "тільки val"},
                  {"key": "all", "title": "увесь ряд"}],
        "weights": str((keep_dir / "model.pt").relative_to(PROJECT_ROOT))}
    path = args.out / "legs_heads.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

    for pair in pairs:
        for part in PARTS:
            block = series_of(pair, part, coins[pair]["data"], proba[pair],
                              coins[pair]["side"], coins[pair]["zone"])
            spot = args.out / f"legs_heads_series_{pair}_{part}.json"
            spot.write_text(json.dumps(block, ensure_ascii=False),
                            encoding="utf-8")

    print(f"\nепоха {fitted['epoch']}")
    for head in HEADS:
        one = marks["val"][head["key"]]
        two = controls[head["key"]]
        print(f"  {head['title']:16s} точність {one['accuracy']} · "
              f"збалансована {one['balanced']} · AUC {one['auc']} · "
              f"повнота {one['recall']} │ стала {two['стала']['accuracy']} · "
              f"монетка {two['монетка за часткою']['accuracy']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
