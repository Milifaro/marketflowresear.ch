"""Комірка памʼяті: LSTM проти GRU на тому самому вході.

Дослідження: research/33-buy-sell-signal/
Правила: rules/03-models.md → навчання моделей

## Питання

`calls_memory.py` поставив на послідовність подій GRU — і це був вибір
без заміру. Тут обидві комірки вчаться **тим самим** ходом: однакові
ширина памʼяті, шматки, розігрів, крок навчання, seed, ціль, поріг і
міра. Різниця лише в комірці:

    GRU    двоє воріт, один вектор стану `h`
    LSTM   троє воріт, два вектори стану `h` і `c` — і на чверть
           більше ваг на ту саму ширину

## Дані

Ті самі, що в усьому дослідженні 33 (`calls_data.py`): шість монет на
осі подій `class210x10m1x7dd`, канали — видачі раніше навчених мереж
проєкту.

    навчання    події з `t < cut`, крім останніх 20 % ряду train
    відкладене  ті останні 20 % train — на ньому обирається епоха
                й ставиться поріг; жодна видача val сюди не входить
    val         події з `t >= cut`

`cut` — межа розбиття за датою з `calls_input.json`, однакова на всі
монети. Числа кожного шматка й дати лежать у видачі (`data`).

## Що міряється

Поріг ставиться один раз на відкладеному шматку (стільки сигналів,
скільки там півотів), а далі тим самим порогом міряються **всі три**
шматки — навчання, відкладене й val. Тому видно і те, скільки мережа
взяла на своєму ж матеріалі, і скільки лишилось поза ним.

Вхід : results/calls_input_<PAIR>.npz, results/calls_train.json
Вихід: results/calls_cells.json, models/calls/cell_<комірка>_<подача>.pt

Запуск:
    python3 research/33-buy-sell-signal/scripts/calls_cells.py
    python3 research/33-buy-sell-signal/scripts/calls_cells.py \
        --cells gru lstm --feeds сире --epochs 12
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parent
RESEARCH_DIR = SCRIPTS.parent
PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESULTS = RESEARCH_DIR / "results"
MODELS = RESEARCH_DIR / "models"
CELLS = ("gru", "lstm")
# Дві зони розвороту: стала в подіях (як було в етапах 3–8) і частка
# ноги — те, що виміряне в дослідженні 32 (етап 9).
ZONES = ("події", "частка")
TITLES = {"gru": "GRU", "lstm": "LSTM"}
PARTS = (("keep", "навчання"), ("tune", "відкладене"), ("show", "val"))
SERIES_PAIR = "BTC_USDT"
SCRIPT = "research/33-buy-sell-signal/scripts/calls_cells.py"


# ------------------------------------------------------------------ мережа

def memory_module():
    """`calls_memory.py` поруч: ручки памʼяті беруться звідти, не тут."""
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    import calls_memory

    return calls_memory


def build(width: int, cell: str, seed: int):
    """Та сама обгортка, що в `calls_memory.py`, з вибором комірки."""
    import torch
    from torch import nn

    memory = memory_module()

    if cell not in CELLS:
        raise SystemExit(f"невідома комірка: {cell}")
    torch.manual_seed(seed)

    class Memory(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            maker = nn.GRU if cell == "gru" else nn.LSTM
            self.rnn = maker(width, memory.HID, num_layers=memory.LAYERS,
                             batch_first=True)
            self.drop = nn.Dropout(memory.DROP)
            self.head = nn.Linear(memory.HID, 3)

        def forward(self, steps, state=None):
            out, state = self.rnn(steps, state)
            return self.head(self.drop(out)), state

    return Memory()


def params_of(model) -> int:
    return int(sum(one.numel() for one in model.parameters()))


# -------------------------------------------------------------------- дані

def stamped(one: int) -> str:
    return datetime.fromtimestamp(int(one), timezone.utc).strftime(
        "%Y-%m-%d %H:%M")


def legs_in(data: dict, mask: np.ndarray) -> int:
    """Скільки півотів зігзага 2.3 % припало на цей шматок."""
    place = np.flatnonzero(mask)
    if not len(place):
        return 0
    piv = np.asarray(data["pivot_at"])
    return int(((piv >= place[0]) & (piv <= place[-1])).sum())


def split_of(coins: dict, pairs: tuple) -> dict:
    """Опис датасету: скільки подій і півотів у кожному шматку."""
    rows, totals = {}, {"events": 0, "keep": 0, "tune": 0, "show": 0,
                        "legs_keep": 0, "legs_tune": 0, "legs_show": 0}
    for pair in pairs:
        one = coins[pair]
        data = one["data"]
        stamps = np.asarray(data["t"], dtype=np.int64)
        row = {"events": int(len(stamps)),
               "with_input": int(one["good"].sum()),
               "from": stamped(stamps[0]), "to": stamped(stamps[-1]),
               "cut": stamped(data["cut"])}
        for key, title in PARTS:
            place = np.flatnonzero(one[key])
            row[key] = int(one[key].sum())
            row[f"legs_{key}"] = legs_in(data, one[key])
            row[f"{key}_from"] = stamped(stamps[place[0]]) if len(place) \
                else None
            row[f"{key}_to"] = stamped(stamps[place[-1]]) if len(place) \
                else None
            totals[key] += row[key]
            totals[f"legs_{key}"] += row[f"legs_{key}"]
        totals["events"] += row["events"]
        rows[pair] = row
    return {"by_pair": rows, "totals": totals,
            "parts": [{"key": key, "title": title} for key, title in PARTS]}


# ------------------------------------------------------------------ прогін

def labelled(coins: dict, pairs: tuple, zone: str, train, look) -> dict:
    """Мітка під обрану зону; повертає хвіст зони кожної монети.

    `події` — сталий хвіст `BEFORE` на кожен півот. `частка` — хвіст
    кожного півота як частка **його** ноги (`calls_look.tails_of`):
    так виміряно в дослідженні 32, де ті самі 50 подій виявились 17 %
    короткої ноги і 3.7 % довгої.
    """
    backs = {}
    for pair in pairs:
        data = coins[pair]["data"]
        pivots = data["pivot_at"]
        back = look.tails_of(pivots) if zone == "частка" else train.BEFORE
        side = look.side_of(len(data["t"]), pivots, data["pivot_up"], back,
                            train.AFTER)
        coins[pair]["side"] = side
        coins[pair]["want"] = np.where(
            side > 0, 1, np.where(side < 0, 2, 0)).astype(np.int64)
        backs[pair] = back
    return backs


def judged(coins: dict, pairs: tuple, tune: np.ndarray, want: int,
           backs: dict, train, memory):
    """Оцінка епохи: влучання ±50 на відкладеному шматку, зона — своя."""
    def judge(model):
        model.eval()
        strength, picked = memory.spread_of(model, coins, pairs, "tune")
        level = train.level_for(
            np.concatenate([strength[one] for one in pairs]),
            np.concatenate([picked[one] for one in pairs]),
            tune, max(want, 1))
        rows = [train.measure(train.fires_of(strength[one], picked[one],
                                             level, coins[one]["tune"]),
                              coins[one]["data"], coins[one]["tune"],
                              backs[one], train.AFTER) for one in pairs]
        got = train.pooled(rows)
        return {"mark": got["caught"]["50"], "level": level, "pooled": got}
    return judge


def run_one(cell: str, feed: str, coins: dict, pairs: tuple, norm: dict,
            names: list, tune: np.ndarray, want: int, epochs: int, seed: int,
            train, memory, zone: str = ZONES[0],
            backs: dict | None = None) -> dict:
    """Одна комірка на одній подачі й одній зоні: навчання, поріг, заміри."""
    columns = memory.columns_of(names, feed)
    for pair in pairs:
        coins[pair]["piece"] = train.applied(coins[pair]["x"],
                                             norm)[:, columns]
    backs = backs or {one: train.BEFORE for one in pairs}
    print(f"\n=== {TITLES[cell]} «{feed}» · зона «{zone}»: ознак "
          f"{len(columns)}")
    began = time.monotonic()
    fitted = memory.fit(coins, pairs,
                        judged(coins, pairs, tune, want, backs, train,
                               memory),
                        epochs, seed,
                        make=lambda width, one: build(width, cell, one))
    spent = time.monotonic() - began
    model, level = fitted["model"], fitted["level"]
    # Видача рахується **один раз** на весь ряд монети: шматки — це
    # тільки маски по тій самій видачі, тому міра трьох шматків завжди
    # знята з одного й того самого проходу.
    strength, picked = memory.spread_of(model, coins, pairs, "show")
    marks = {}
    for key, title in PARTS:
        rows = {one: train.measure(
            train.fires_of(strength[one], picked[one], level,
                           coins[one][key]),
            coins[one]["data"], coins[one][key], backs[one], train.AFTER)
            for one in pairs}
        marks[title] = {"by_pair": rows,
                        "pooled": train.pooled(list(rows.values()))}
    shown = marks["val"]["pooled"]
    learnt = marks["навчання"]["pooled"]
    print(f"  навчання: ±50 {learnt['caught']['50']} · val: сигналів "
          f"{shown['fires']} · ±15 {shown['caught']['15']} · ±50 "
          f"{shown['caught']['50']} · {spent / 60:.1f} хв")
    return {"model": model, "cell": cell, "feed": feed, "zone": zone,
            "title": f"{TITLES[cell]} · {feed} · зона «{zone}»",
            "epoch": fitted["epoch"],
            "curve": fitted["curve"], "level": round(float(level), 4),
            "features": int(len(columns)), "columns": columns,
            "params": params_of(model), "minutes": round(spent / 60, 1),
            "marks": marks, "strength": strength,
            "proba": {one: coins[one]["proba_show"] for one in pairs}}


def rounded(values, digits: int = 4) -> list:
    out = []
    for one in np.asarray(values, dtype=float):
        out.append(None if not np.isfinite(one) else round(float(one), digits))
    return out


def series_of(runs: dict, coins: dict, pair: str, train) -> dict:
    """Ряд val однієї монети: ціна, півоти і видачі всіх прогонів."""
    data = coins[pair]["data"]
    stamps = np.asarray(data["t"], dtype=np.int64)
    price = np.asarray(data["price"], dtype=float)
    index = np.flatnonzero(stamps >= data["cut"])
    inside = (data["pivot_at"] >= index[0]) & (data["pivot_at"] <= index[-1])
    out = {"pair": pair, "events": int(len(index)),
           "from": int(stamps[index[0]]), "to": int(stamps[index[-1]]),
           "t": [int(one) for one in stamps[index]],
           "price": rounded(price[index], 2),
           "ema": rounded(np.asarray(data["ema"], dtype=float)[index], 2),
           "pivots": [{"t": int(stamps[one]),
                       "price": round(float(price[one]), 2),
                       "kind": "low" if low else "high"}
                      for one, low in zip(data["pivot_at"][inside],
                                          data["pivot_up"][inside])],
           "lines": {}}
    for key, run in runs.items():
        proba = run["proba"][pair]
        picked = np.where(proba[:, 1] >= proba[:, 2], 1, -1).astype(np.int8)
        fires = train.fires_of(run["strength"][pair], picked, run["level"],
                               coins[pair]["show"])
        out["lines"][key] = {
            "title": run["title"], "level": run["level"],
            "buy": rounded(proba[index, 1]), "sell": rounded(proba[index, 2]),
            "fires": [{"t": int(stamps[one["at"]]),
                       "price": round(float(price[one["at"]]), 2),
                       "side": int(one["side"])} for one in fires]}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", type=Path, default=RESULTS)
    parser.add_argument("--pairs", nargs="+", default=None)
    parser.add_argument("--cells", nargs="+", default=list(CELLS))
    parser.add_argument("--feeds", nargs="+", default=None)
    parser.add_argument("--zones", nargs="+", default=list(ZONES))
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    sys.path.insert(0, str(SCRIPTS))
    import torch

    import calls_look as look
    import calls_memory as memory
    import calls_train as train

    pairs = tuple(args.pairs or train.PAIRS)
    feeds = tuple(args.feeds or memory.FEEDS)
    epochs = args.epochs or memory.EPOCHS
    seed = args.seed or memory.SEED
    got = train.gather(pairs, args.out)
    coins = got["coins"]
    norm = train.norm_of(got["learn"], np.ones(len(got["learn"]), dtype=bool))
    tune = np.concatenate([coins[pair]["tune"] for pair in pairs])
    want = sum(legs_in(coins[pair]["data"], coins[pair]["tune"])
               for pair in pairs)
    data = split_of(coins, pairs)
    print(f"півотів на відкладеному {want} · шматок {memory.BLOCK} подій, "
          f"грію {memory.WARM}")

    runs = {}
    for zone in args.zones:
        backs = labelled(coins, pairs, zone, train, look)
        tails = np.concatenate([np.atleast_1d(backs[one]) for one in pairs])
        print(f"\nзона «{zone}»: хвіст {int(np.min(tails))}…"
              f"{int(np.max(tails))} подій, медіана "
              f"{int(np.median(tails))} · голова {train.AFTER}")
        for cell in args.cells:
            for feed in feeds:
                runs[f"{cell}|{feed}|{zone}"] = run_one(
                    cell, feed, coins, pairs, norm, got["names"], tune, want,
                    epochs, seed, train, memory, zone, backs)

    keep_dir = MODELS / "calls"
    keep_dir.mkdir(parents=True, exist_ok=True)
    for key, run in runs.items():
        torch.save(run["model"].state_dict(),
                   keep_dir / f"cell_{run['cell']}_{run['feed']}_"
                              f"{run['zone']}.pt")
    np.savez_compressed(keep_dir / "cell_norm.npz", mid=norm["mid"],
                        wide=norm["wide"])
    best = max(runs.values(), key=lambda one: one["marks"]["відкладене"]
               ["pooled"]["caught"]["50"])
    print(f"\nкраще на відкладеному: {best['title']}")

    series = series_of(runs, coins, SERIES_PAIR, train)
    report = {
        "script": SCRIPT, "ready": True, "pairs": list(pairs),
        "seed": seed, "cells": [{"key": one, "title": TITLES[one]}
                                for one in args.cells],
        "feeds": {"сире": list(memory.RAW), "разом": "усі 47 ознак MLP"},
        "zone": {"before": train.BEFORE, "after": train.AFTER},
        "shape": {"hid": memory.HID, "layers": memory.LAYERS,
                  "drop": memory.DROP, "lr": memory.LR,
                  "decay": memory.DECAY, "block": memory.BLOCK,
                  "warm": memory.WARM, "batch": memory.BATCH,
                  "epochs": epochs},
        "tolerance": list(train.TOLERANCE), "data": data,
        "best": f"{best['cell']}|{best['feed']}|{best['zone']}",
        "zones": {"події": {"tail": train.BEFORE, "head": train.AFTER},
                  "частка": {"share": look.SHARE, "floor": look.FLOOR,
                             "head": train.AFTER}},
        "runs": {key: {one: run[one] for one in
                       ("cell", "feed", "zone", "title", "epoch", "curve",
                        "level", "features", "params", "minutes", "marks")}
                 for key, run in runs.items()},
        "series": series,
        "weights": {key: str((keep_dir / f"cell_{run['cell']}_"
                              f"{run['feed']}_{run['zone']}.pt"
                              ).relative_to(PROJECT_ROOT))
                    for key, run in runs.items()}}
    path = args.out / "calls_cells.json"
    path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

    print("\nразом:")
    for key, run in runs.items():
        for title in ("навчання", "val"):
            one = run["marks"][title]["pooled"]
            print(f"  {run['title']:34s} {title:9s} сигналів {one['fires']:4d}"
                  f" · ±15 {one['caught']['15']} · ±50 {one['caught']['50']}"
                  f" · у зоні {one['in_zone']}")
    print(f"записано: {path}")


if __name__ == "__main__":
    main()
