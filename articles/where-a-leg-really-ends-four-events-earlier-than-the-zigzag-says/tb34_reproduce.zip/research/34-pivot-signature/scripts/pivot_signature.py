"""Етапи 1-2: дзеркальність класу і хід підпису навколо півота.

Етап 1. Клас має пари «покупці / продавці». Якщо ряд дзеркальний, то
величина `X` на вершині дорівнює величині `дзеркало(X)` на дні. Це й
перевіряється — по кожній фічі, з обох боків півота.

Етап 2. Той самий підпис, але вздовж зсуву від точки розвороту: власний
бік ноги, що закінчується, проти зустрічного, −40 … +40 подій.

Запуск:
    python3 research/34-pivot-signature/scripts/pivot_signature.py
    python3 research/34-pivot-signature/scripts/pivot_signature.py --anchor close

Вихід: results/pivot_signature_<якір>.json
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from mirror import (FEATURES, MIRROR, PAIRS, RESULTS, SIDES, WINDOW, anchor,
                    series, sided)


def mirror_test(rows: list, window: int = 20) -> list:
    """`X` на вершині проти `дзеркало(X)` на дні, з обох боків розвороту."""
    pool: dict = {}
    for row in rows:
        for index, kind in row["anchored"].items():
            side_kind = "high" if kind > 0 else "low"
            for name in FEATURES:
                value = row["rank"][(name, "mean", "rank")]
                before = np.nanmean(value[max(0, index - window):index + 1])
                after = np.nanmean(value[index:index + window + 1])
                for side, level in (("before", before), ("after", after)):
                    if np.isfinite(level):
                        pool.setdefault((name, side, side_kind), []).append(level)
    out = []
    for name in FEATURES:
        for side in ("before", "after"):
            top = np.array(pool[(name, side, "high")])
            bottom = np.array(pool[(MIRROR[name], side, "low")])
            if name == "d_price_avg":
                bottom = 1 - bottom       # ціна при дзеркалі міняє знак
            diff = top.mean() - bottom.mean()
            error = np.sqrt(top.var(ddof=1) / len(top)
                            + bottom.var(ddof=1) / len(bottom))
            out.append({"feature": name, "side": side,
                        "top": float(top.mean()),
                        "bottom_mirrored": float(bottom.mean()),
                        "diff": float(diff), "t": float(diff / error),
                        "n_top": len(top), "n_bottom": len(bottom)})
    return out


def offsets(rows: list) -> dict:
    """Хід величин по зсуву від точки розвороту, нарізно вгору й вниз."""
    pool: dict = {}
    price: dict = {}
    for row in rows:
        count = row["count"]
        for index, kind in row["anchored"].items():
            if index - WINDOW < 0 or index + WINDOW >= count:
                continue
            leg = "up" if kind > 0 else "down"
            for side in ("own", "cnt"):
                for part in SIDES["up"]:
                    value = sided(row, leg, side, part)
                    pool.setdefault((side, part, leg), []).append(
                        value[index - WINDOW:index + WINDOW + 1])
            pool.setdefault(("price", "amp", leg), []).append(
                row["rank"][("d_price_avg", "mean", "amp")]
                [index - WINDOW:index + WINDOW + 1])
            pool.setdefault(("signature", "all", leg), []).append(
                row["signature"][index - WINDOW:index + WINDOW + 1])
            price.setdefault(leg, []).append(
                np.log(row["open"][index - WINDOW:index + WINDOW + 1]
                       / row["open"][index]) * kind)
    curves = {}
    for key, stack in pool.items():
        mean = np.nanmean(np.array(stack), axis=0)
        curves["·".join(key)] = {"mean": [float(v) for v in mean],
                                 "n": len(stack)}
    for leg, stack in price.items():
        curves[f"ціна·{leg}"] = {
            "mean": [float(v) for v in np.nanmedian(np.array(stack), axis=0)],
            "n": len(stack)}
    for leg in ("up", "down"):        # перекид: зустрічний бік мінус власний
        own = np.array(curves[f"own·vol·{leg}"]["mean"])
        cnt = np.array(curves[f"cnt·vol·{leg}"]["mean"])
        curves[f"перекид·{leg}"] = {"mean": [float(v) for v in cnt - own],
                                    "n": curves[f"own·vol·{leg}"]["n"]}
    curves["offsets"] = list(range(-WINDOW, WINDOW + 1))
    return curves


CROSS_FROM = -10        # звідки шукається перекид, щоб не ловити шум далеко


def crossing(curves: dict, leg: str) -> int | None:
    """Зсув, на якому зустрічний бік переганяє власний і лишається вище."""
    line = np.array(curves[f"перекид·{leg}"]["mean"])
    offsets = np.array(curves["offsets"])
    for position in range(int(np.where(offsets == CROSS_FROM)[0][0]),
                          len(line) - 3):
        if line[position] > 0 and (line[position:position + 3] > 0).all():
            return int(offsets[position])
    return None


def report(rows: list, by: str) -> dict:
    mirror = mirror_test(rows)
    curves = offsets(rows)
    off = np.array(curves["offsets"])
    peaks = {}
    for leg in ("up", "down"):
        for side in ("own", "cnt"):
            line = np.array(curves[f"{side}·vol·{leg}"]["mean"])
            peaks[f"{side}·vol·{leg}"] = int(off[np.nanargmax(line)])
    peaks.update({f"перекид·{leg}": crossing(curves, leg)
                  for leg in ("up", "down")})
    return {"anchor": by, "pairs": list(PAIRS),
            "pivots": sum(len(row["anchored"]) for row in rows),
            "legs": sum(len(row["legs"]) for row in rows),
            "mirror": mirror, "curves": curves, "peaks": peaks}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--anchor", default="none",
                        choices=("none", "open", "close"))
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    args = parser.parse_args()

    rows = []
    for pair in args.pairs:
        row = series(pair)
        row["anchored"] = {anchor(row, index, kind, args.anchor): kind
                           for index, kind in row["pivots"].items()}
        rows.append(row)
        print(f"{pair}: ніг {len(row['legs'])}, півотів {len(row['pivots'])}",
              flush=True)

    result = report(rows, args.anchor)
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / f"pivot_signature_{args.anchor}.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))
    print(f"\n{path}")

    print("\nдзеркальність (крива rank, вікно 20 подій):")
    print(f"{'фіча':22s} {'бік':7s} {'вершина':>8s} {'дно':>8s} {'різниця':>8s} {'t':>6s}")
    for line in result["mirror"]:
        print(f"{line['feature']:22s} {line['side']:7s} {line['top']:8.3f} "
              f"{line['bottom_mirrored']:8.3f} {line['diff']:+8.3f} {line['t']:+6.1f}")

    off = result["curves"]["offsets"]
    show = [off.index(o) for o in (-30, -20, -10, -5, -2, 0, 2, 5, 10, 20, 30)]
    print("\nхід по зсувах (amp·mean):")
    print(f"{'крива':18s} " + " ".join(f"{o:+6d}" for o in
                                       (-30, -20, -10, -5, -2, 0, 2, 5, 10, 20, 30)))
    for key in sorted(k for k in result["curves"] if k != "offsets"):
        line = result["curves"][key]["mean"]
        print(f"{key:18s} " + " ".join(f"{line[i]:6.3f}" for i in show))
    print("\nпіки:", result["peaks"])


if __name__ == "__main__":
    main()
