"""Ряд val однієї монети під її ціною: видачі етапів 7 і 8 поруч.

Дослідження: research/34-pivot-signature/

Моделі етапу 7 вчаться на подіях **краю** — по 10 з кожного боку межі.
Тут вони пускаються по **всьому** ряду val, подія за подією, разом із
ціною і зігзагом. Це навмисне питання не за призначенням: видно, як
часто видача гучна там, де жодної межі немає.

    бік межі      P(подія належить новій нозі)
                  рамка дзеркальна, тому ліній дві: «якщо нога вгору»
                  і «якщо нога вниз». Жодна з них не знає, яка нога
                  йде насправді, — це видно з їхнього розходження
    бік розвороту P(межа поруч — вершина), рамка звичайна
    B             амплітуда(d_down) − амплітуда(d_up), етап 4, без навчання
    B|рух         той самий B після регресії на ранг руху ціни

Поруч — ті самі дві моделі **етапу 8**, у яких є третя відповідь «не
край». Вони вчились на всьому тілі ноги, тому вміють мовчати, і в ряді
це головне, що треба побачити:

    край (межа)      1 − P(не край) у дзеркальній рамці, дві лінії
    край (розворот)  1 − P(не край) у звичайній рамці
    бік межі 8       P(голова нової) серед самої маси краю
    бік розвороту 8  P(вершина) серед самої маси краю

Перші три числа — те, чого в етапі 7 не було зовсім: там модель
відповідала на кожній події й однаково гучно. Останні два показують,
що перша робота нікуди не зникла: бік читається там само, але тільки
там, де модель сказала «край є».

Навчання — події краю всіх шести монет **до** 2026-08-14; видача — ряд
val обраної монети. Точка розвороту скрізь за стандартом (`close` ±25).

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/border_series_<PAIR>.json

Запуск:
    python3 research/34-pivot-signature/scripts/border_series.py
    python3 research/34-pivot-signature/scripts/border_series.py --pair ETH_USDT
"""

from __future__ import annotations

import argparse
import json

import numpy as np

import border_edge
import pivot_side
from border_side import (TASKS, VAL_FROM, class_columns, collect, label_of,
                         mirrored_price, price_window)
from mirror import PAIRS, RESULTS, SEED, anchor, series

ANCHOR = "close"
KIT = "разом"
# Верхівка ряду, на якій міряється точність етапу 8: поріг «це край»
# береться з самого ряду val, а не з навчання — так само, як у
# `border_edge.py` рахується колонка «точність верхівки 2 %».
TOP = 0.02
# Ручки моделі стоять тут, а не тільки в коді бустинга: rules/03-models.md
# → «Що логувати для кожного прогону». Вони ті самі, що в дослідженні 28,
# етап 5 (`event_edges.py` → `sides`), щоб числа читались поруч.
KNOBS = {"model": "HistGradientBoostingClassifier", "trees": 300,
         "leaves": 31, "learning_rate": 0.05, "min_samples_leaf": 50,
         "l2": 1.0, "seed": SEED, "outputs": 1}


def whole_row(row: dict, seen: int, window: int) -> np.ndarray:
    """Усі події ряду в заданій рамці: клас поруч із вікном ціни."""
    block, _ = class_columns(row, seen)
    price, names = price_window(row, window)
    return np.hstack([block, mirrored_price(price, names, seen)])


def trained(rows: list, task: str, marks: int, window: int):
    """Модель задачі, навчена на подіях краю **до** межі val."""
    bag = collect(rows, ANCHOR, marks, window, TASKS[task]["frame"])
    label = label_of(bag, task)
    train = bag["t"] < VAL_FROM
    from sklearn.ensemble import HistGradientBoostingClassifier
    model = HistGradientBoostingClassifier(
        max_iter=KNOBS["trees"], learning_rate=KNOBS["learning_rate"],
        max_leaf_nodes=KNOBS["leaves"],
        min_samples_leaf=KNOBS["min_samples_leaf"],
        l2_regularization=KNOBS["l2"], random_state=KNOBS["seed"])
    model.fit(bag[KIT][train], label[train])
    return model, {"events": int(train.sum()),
                   "base": float(label[train].mean()),
                   "frame": TASKS[task]["frame"],
                   "title": TASKS[task]["title"],
                   "columns": {kit: len(bag["names"][kit])
                               for kit in ("клас", "ціна", KIT)}}


def trained_edge(rows: list, marks: int, window: int):
    """Моделі етапу 8 — ті самі дві, але з третьою відповіддю «не край».

    Вчаться на **всьому тілі ноги** шести монет до межі val, тому
    вміють мовчати. Ручки ті самі, що в етапі 7: різниця лише в
    навчальній вибірці й у кількості відповідей.
    """
    bag = border_edge.collect(rows, ANCHOR, marks, window)
    train = bag["t"] < VAL_FROM
    from sklearn.ensemble import HistGradientBoostingClassifier
    out, about = {}, {}
    for task in border_edge.TASKS:
        frame = border_edge.TASKS[task]["frame"]
        model = HistGradientBoostingClassifier(
            max_iter=KNOBS["trees"], learning_rate=KNOBS["learning_rate"],
            max_leaf_nodes=KNOBS["leaves"],
            min_samples_leaf=KNOBS["min_samples_leaf"],
            l2_regularization=KNOBS["l2"], random_state=KNOBS["seed"])
        label = bag[task]
        model.fit(border_edge.kit_of(bag, KIT, frame)[train], label[train])
        out[task] = model
        real = label != border_edge.NONE
        about[task] = {
            "events": int(train.sum()),
            "edge": int((real & train).sum()),
            "body": int((~real & train).sum()),
            "base": float(real[train].mean()),
            "frame": frame,
            "title": border_edge.TASKS[task]["title"],
            "answers": list(border_edge.TASKS[task]["names"]) + ["не край"]}
    return out, about


def edge_row(row: dict, seen: int, window: int) -> np.ndarray:
    """Усі події ряду в рамці етапу 8: клас поруч із вікном ціни.

    Вікно ціни тут **не дзеркалиться**: етап 8 збирає його як є, і
    рамка міняє тільки клас. Інакше ряд читався б не тією лінійкою,
    якою модель навчена.
    """
    block, _ = class_columns(row, seen)
    price, _ = price_window(row, window)
    return np.hstack([block, price])


def paint_edge(row: dict, models: dict, window: int) -> dict:
    """Видачі етапу 8: скільки «це край» і який бік усередині цієї маси.

    Бік береться **умовно** — частка від самої маси краю, а не від
    одиниці. Інакше низьке «це край» тягнуло б бік до нуля, і лінія
    казала б не «дно», а «нічого тут немає», що вже сказано сусідньою.
    """
    lines: dict = {}
    none = border_edge.NONE
    for name, task, seen in (("edge_up", "belong", 1),
                             ("edge_down", "belong", -1),
                             ("edge_turn", "updown", 1)):
        got = models[task].predict_proba(edge_row(row, seen, window))
        full = np.zeros((len(got), 3))
        full[:, models[task].classes_] = got
        mass = full[:, 0] + full[:, 1]
        lines[name] = 1.0 - full[:, none]
        with np.errstate(invalid="ignore", divide="ignore"):
            side = np.where(mass > 0, full[:, 1] / np.maximum(mass, 1e-12),
                            np.nan)
        lines[name.replace("edge_", "side_")] = side
    return lines


def paint(row: dict, models: dict, window: int) -> dict:
    """Видачі на кожній події ряду, кожна у своїй рамці."""
    belong, updown = models["belong"], models["updown"]
    lines = {}
    for name, seen in (("belong_up", 1), ("belong_down", -1)):
        lines[name] = belong.predict_proba(whole_row(row, seen, window))[:, 1]
    lines["updown"] = updown.predict_proba(whole_row(row, 1, window))[:, 1]
    kit = pivot_side.prepare(row, ANCHOR)
    lines["B"] = kit["B"]
    lines["B|рух"] = kit["B|рух"]
    return lines


def marks_of(row: dict) -> dict:
    """Ноги й перенесені межі ряду — щоб було з чим порівнювати видачу."""
    legs, borders = [], []
    for number, leg in enumerate(row["legs"]):
        legs.append({"leg": number, "kind": leg["kind"],
                     "first": int(leg["first"]), "last": int(leg["last"]),
                     "move": float(leg["move"])})
    for old, new in zip(row["legs"], row["legs"][1:]):
        if new["first"] != old["last"] + 1:
            continue
        sign = 1 if old["kind"] == "up" else -1
        place = int(anchor(row, old["last"], sign, ANCHOR))
        borders.append({"index": place, "pivot": int(old["last"]),
                        "kind": "вершина" if sign > 0 else "дно",
                        "price": round(float(row["close"][place]), 2)})
    return {"legs": legs, "borders": borders}


def clean(values: np.ndarray, digits: int = 4) -> list:
    """Числа для вкладки: NaN не лізе в JSON, точність обрізана."""
    return [None if not np.isfinite(one) else round(float(one), digits)
            for one in values]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS),
                        help="на яких монетах учаться моделі")
    parser.add_argument("--marks", type=int, default=10)
    parser.add_argument("--window", type=int, default=39)
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    models, about = {}, {}
    for task in TASKS:
        models[task], about[task] = trained(rows, task, args.marks,
                                            args.window)
    edges, edge_about = trained_edge(rows, args.marks, args.window)

    row = next(one for one in rows if one["pair"] == args.pair)
    lines = paint(row, models, args.window)
    lines.update(paint_edge(row, edges, args.window))
    val = row["t"] >= VAL_FROM
    start = int(np.argmax(val))
    picked = marks_of(row)
    shift = {"legs": [one for one in picked["legs"] if one["last"] >= start],
             "borders": [one for one in picked["borders"]
                         if one["index"] >= start]}

    result = {"pair": args.pair, "anchor": ANCHOR, "kit": KIT,
              "marks": args.marks, "window": args.window,
              "trained_on": args.pairs, "train": about, "knobs": KNOBS,
              "edge_train": edge_about, "top": TOP,
              "val_from": VAL_FROM, "first": start,
              "t": [int(one) for one in row["t"][val]],
              "price": clean(row["open"][val], 2),
              "lines": {name: clean(values[val])
                        for name, values in lines.items()},
              "legs": [dict(one, first=one["first"] - start,
                            last=one["last"] - start) for one in shift["legs"]],
              "borders": [dict(one, index=one["index"] - start,
                               pivot=one["pivot"] - start)
                          for one in shift["borders"]]}
    # Поріг верхівки 2 % і те, що він ловить: скільки меж закрито й
    # скільки суцільних плям видачі. Це те саме число, що в таблиці
    # етапу 8, але пораховане на одному ряді — щоб графік і таблиця
    # читались разом.
    result["gates"] = {}
    for name in ("edge_up", "edge_down", "edge_turn"):
        line = np.array([one if one is not None else np.nan
                         for one in result["lines"][name]], dtype=float)
        good = np.isfinite(line)
        if not good.any():
            continue
        take = max(1, int(round(TOP * int(good.sum()))))
        gate = float(np.sort(line[good])[-take])
        above = good & (line >= gate)
        spots = int(np.sum(above[1:] & ~above[:-1])) + int(above[0])
        near = {one["index"] for one in result["borders"]}
        caught = sum(1 for one in result["borders"]
                     if above[max(0, one["index"] - args.marks):
                              one["index"] + args.marks + 1].any())
        result["gates"][name] = {
            "gate": round(gate, 4), "events": int(above.sum()),
            "share": round(float(above.sum() / good.sum()), 4),
            "spots": spots, "caught": caught, "borders": len(near)}

    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / f"border_series_{args.pair}.json"
    path.write_text(json.dumps(result, ensure_ascii=False))

    print(f"{args.pair}: {len(result['t'])} подій val, "
          f"{len(result['borders'])} меж, {len(result['legs'])} ніг")
    for task in TASKS:
        print(f"  етап 7 · {TASKS[task]['title']:14s} навчено на "
              f"{about[task]['events']} подіях краю, база "
              f"{about[task]['base']:.3f}")
    for task in edge_about:
        one = edge_about[task]
        print(f"  етап 8 · {one['title']:14s} навчено на {one['events']} "
              f"подіях ноги ({one['edge']} краю + {one['body']} тіла), "
              f"база {one['base']:.4f}")
    for name, one in result["gates"].items():
        print(f"  верхівка {TOP * 100:.0f} % · {name:10s} поріг "
              f"{one['gate']:.3f}, {one['events']} подій у "
              f"{one['spots']} плямах, меж закрито {one['caught']} "
              f"з {one['borders']}")
    for name, values in result["lines"].items():
        line = np.array([one for one in values if one is not None])
        print(f"  {name:12s} медіана {np.median(line):.3f}, "
              f"понад 0.5 на {(line > 0.5).mean() * 100:.1f} % подій")


if __name__ == "__main__":
    main()
