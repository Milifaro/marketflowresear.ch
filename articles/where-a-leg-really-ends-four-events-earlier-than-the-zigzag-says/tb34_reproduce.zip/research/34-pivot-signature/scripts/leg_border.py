"""Етап 3: куди ставити межу ноги.

Півот зігзага стоїть на ема10, а ема відстає. Тут міряється, наскільки
підпис класу вищий, якщо межу ноги перенести на **справжній екстремум
ціни** поруч, і наскільки профіль підпису стає симетричним.

Чотири якорі:

| якір | точка розвороту |
| ---- | --------------- |
| `none` | півот зігзага 2.3 % на ема10, як є |
| `open` | найвища (найнижча) `price_open` у вікні ±25 подій |
| `close` | те саме по `price_close` — ціні в кінці події |
| `oracle` | подія з найбільшим підписом у тому самому вікні — стеля |

Запуск:
    python3 research/34-pivot-signature/scripts/leg_border.py

Вихід: results/leg_border.json
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from mirror import PAIRS, RESULTS, SEARCH, WINDOW, anchor, series

ANCHORS = ("none", "open", "close", "oracle")


def place(row: dict, index: int, kind: int, by: str) -> int:
    if by != "oracle":
        return anchor(row, index, kind, by)
    low, high = max(0, index - SEARCH), min(row["count"], index + SEARCH + 1)
    piece = row["signature"][low:high]
    if not np.isfinite(piece).any():
        return index
    return low + int(np.nanargmax(piece))


def extreme(row: dict, moved: int, kind: int, index: int) -> float:
    """Наскільки нова межа піднімає край ноги: ціна події — крайня з двох."""
    def edge(i: int) -> float:
        pair = (row["open"][i], row["close"][i])
        return max(pair) if kind > 0 else min(pair)
    return float(np.log(edge(moved) / edge(index)) * kind)


def profile(rows: list, by: str) -> dict:
    """Рівень підпису в точці, хід навколо неї, зсув і приріст розмаху."""
    levels, shifts, gains, stack = [], [], [], []
    per_pair: dict = {}
    for row in rows:
        for index, kind in row["pivots"].items():
            moved = place(row, index, kind, by)
            value = row["signature"][moved]
            if np.isfinite(value):
                levels.append(value)
                per_pair.setdefault(row["pair"], []).append(value)
            shifts.append(moved - index)
            gains.append(extreme(row, moved, kind, index))
            if moved - WINDOW >= 0 and moved + WINDOW < row["count"]:
                stack.append(row["signature"][moved - WINDOW:moved + WINDOW + 1])
    curve = np.nanmean(np.array(stack), axis=0)
    offsets = np.arange(-WINDOW, WINDOW + 1)
    base = float(np.nanmean(np.r_[curve[:10], curve[-10:]]))
    bump = np.clip(curve - base, 0, None)
    smooth = np.convolve(curve, np.ones(5) / 5, mode="same")
    shifts = np.array(shifts, dtype=float)
    gains = np.array(gains, dtype=float)
    return {
        "anchor": by,
        "pivots": len(shifts),
        "level": float(np.mean(levels)),
        "level_by_pair": {pair: float(np.mean(v)) for pair, v in per_pair.items()},
        "peak_offset": int(offsets[np.nanargmax(smooth[5:-5]) + 5]),
        "centroid": float((offsets * bump).sum() / bump.sum()),
        "left_to_right": float(bump[offsets < 0].sum() / bump[offsets > 0].sum()),
        "shift_median": float(np.median(shifts)),
        "shift_mean": float(shifts.mean()),
        "shift_q1": float(np.percentile(shifts, 25)),
        "shift_q3": float(np.percentile(shifts, 75)),
        "share_left": float((shifts < 0).mean()),
        "share_same": float((shifts == 0).mean()),
        "gain_median": float(np.median(gains)),
        "gain_mean": float(gains.mean()),
        "curve": [float(v) for v in curve],
        "offsets": offsets.tolist(),
    }


def inside_leg(rows: list, by: str) -> dict:
    """Місце межі серед подій **своєї** ноги: чи це пік у кожній нозі.

    Для кожної ноги береться її кінцева межа і рахується, яку частку
    подій ноги вона перевищує за підписом. 1.0 — найгучніша подія ноги.
    """
    quantiles = []
    for row in rows:
        for leg in row["legs"]:
            index = leg["last"]
            if index not in row["pivots"]:
                continue
            moved = place(row, index, row["pivots"][index], by)
            piece = row["signature"][leg["first"]:leg["last"] + 1]
            piece = piece[np.isfinite(piece)]
            value = row["signature"][moved]
            if not np.isfinite(value) or not len(piece):
                continue
            quantiles.append(float((piece < value).mean()))
    quantiles = np.array(quantiles)
    return {"legs": len(quantiles), "median": float(np.median(quantiles)),
            "mean": float(quantiles.mean()),
            "above_90": float((quantiles >= 0.90).mean()),
            "above_75": float((quantiles >= 0.75).mean()),
            "below_50": float((quantiles < 0.50).mean())}


def by_pair_shift(rows: list, by: str) -> dict:
    out = {}
    for row in rows:
        shifts = [place(row, i, k, by) - i for i, k in row["pivots"].items()]
        out[row["pair"]] = {"median": float(np.median(shifts)),
                            "mean": float(np.mean(shifts)), "n": len(shifts)}
    return out


def by_kind_shift(rows: list, by: str) -> dict:
    out = {}
    for name, want in (("вершина", 1), ("дно", -1)):
        shifts = [place(row, i, k, by) - i
                  for row in rows for i, k in row["pivots"].items() if k == want]
        out[name] = {"median": float(np.median(shifts)),
                     "mean": float(np.mean(shifts)), "n": len(shifts)}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    result = {"pairs": args.pairs, "search": SEARCH,
              "legs": sum(len(row["legs"]) for row in rows),
              "anchors": {by: profile(rows, by) for by in ANCHORS},
              "inside_leg": {by: inside_leg(rows, by) for by in ANCHORS},
              "shift_by_pair": by_pair_shift(rows, "close"),
              "shift_by_kind": by_kind_shift(rows, "close")}
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / "leg_border.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    print(f"ніг {result['legs']}, півотів {result['anchors']['none']['pivots']}\n")
    print(f"{'якір':8s} {'підпис':>7s} {'пік':>4s} {'центр':>6s} {'ліво/право':>10s} "
          f"{'зсув мед':>8s} {'ліворуч':>8s} {'розмах':>8s}")
    for by in ANCHORS:
        a = result["anchors"][by]
        print(f"{by:8s} {a['level']:7.3f} {a['peak_offset']:+4d} {a['centroid']:+6.1f} "
              f"{a['left_to_right']:10.2f} {a['shift_median']:+8.1f} "
              f"{100*a['share_left']:7.0f}% {100*a['gain_median']:+8.3f}%")
    print(f"\n{'якір':8s} {'місце межі в нозі':>18s} {'у топ-10 % ноги':>16s} "
          f"{'у топ-25 %':>11s} {'нижче середини':>15s}")
    for by in ANCHORS:
        a = result["inside_leg"][by]
        print(f"{by:8s} {a['median']:18.3f} {100*a['above_90']:15.0f}% "
              f"{100*a['above_75']:10.0f}% {100*a['below_50']:14.0f}%")
    print("\nзсув до екстремуму price_close по монетах:")
    for pair, v in result["shift_by_pair"].items():
        print(f"  {pair:10s} медіана {v['median']:+5.1f}  середнє {v['mean']:+5.1f}  n {v['n']}")
    for kind, v in result["shift_by_kind"].items():
        print(f"  {kind:10s} медіана {v['median']:+5.1f}  середнє {v['mean']:+5.1f}  n {v['n']}")
    print(f"\n{path}")


if __name__ == "__main__":
    main()
