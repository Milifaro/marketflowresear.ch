"""Етап 8: навчити обидві моделі казати «ні» — третя відповідь «не край».

Дослідження: research/34-pivot-signature/
Правила: rules/01-data-and-db.md, rules/02-markup.md → Точка кінця ноги

Етап 7 поставив дві моделі на **подіях краю** і сам назвав свій замір
умовним: «модель питають тільки на подіях краю, а в живому ряді край
ще треба знайти». Наслідок видно на вкладці дослідження 33: обидві
кажуть «межа ось тут» у 80 % зон, тоді як межа трапляється в зоні ±25
з шансом 4.3 %. Це не помилка прогону — у їхній навчальній вибірці
**9 300 подій, і всі 9 300 — краї**. Класу «тут нічого немає» в них
не існує, тому «ні» сказати нічим.

Тут цілі обох моделей лишаються ті самі, а відповідей стає три:

    бік межі      0 хвіст ноги, що кінчається (зсув −9 … 0)
                  1 голова ноги, що почалась  (зсув +1 … +10)
                  2 **не край** — подія тіла ноги

    бік розвороту 0 межа поруч — дно
                  1 межа поруч — вершина
                  2 **не край**

Позитив той самий, що в етапі 7 (9 300 подій краю 465 стиків), негатив
новий — близько 299 тисяч подій тіла ноги, яких модель етапу 7 не
бачила жодної. Частка краю падає з 1.000 до ~0.032, тому міра тут
інша: не сама AUC, а **точність на верхівці** — скільки з найгучніших
подій справді край і скільки меж вони закривають.

Три питання етапу:

1. Наскільки точне «ні»: точність і покриття меж на верхівці ряду.
2. Чи не зламалась перша робота: серед подій, які модель таки назвала
   краєм, чи так само правильно названий бік.
3. Корекції. Поворот усередині ноги (вкладений зігзаг `INNER`, не
   ближче `CLEAR` подій до країв) межею не є, і саме там «ні» потрібне
   найбільше. Етап 6 показав, що клас розрізняє їх слабко.

Рамка «боку межі» — рамка **ноги, в якій подія стоїть**: для події
краю це нога, що кінчається (так само, як в етапі 7), для події тіла —
її власна нога. У живому ряді бік невідомий, тому там модель питають
в обох рамках — так само, як це вже робить `border_series.py`.
«Бік розвороту» дзеркала не має: воно і є відповіддю.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/border_edge.json

Запуск:
    python3 research/34-pivot-signature/scripts/border_edge.py
    python3 research/34-pivot-signature/scripts/border_edge.py --coins
    python3 research/34-pivot-signature/scripts/border_edge.py --anchor none
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from border_side import (MARKS, NO_EMA, TREES, WINDOW, class_columns,
                         junctions, price_window)
from leg_start import VAL_FROM
from mirror import PAIRS, RESULTS, SEED, anchor, auc, corrections, series

SCRIPT = "research/34-pivot-signature/scripts/border_edge.py"
SETS = ("клас", "ціна", "ціна−ема", "разом")
TASKS = {"belong": {"title": "бік межі", "frame": "mirror",
                    "names": ("хвіст старої ноги", "голова нової ноги")},
         "updown": {"title": "бік розвороту", "frame": "plain",
                    "names": ("дно", "вершина")}}
NONE = 2            # третя відповідь: подія краєм не є
TOPS = (0.005, 0.01, 0.02, 0.05, 0.10)   # верхівка ряду, частка подій
GATES = (0.5, 0.7, 0.9)                  # пороги самої видачі «це край»
GAP = 210 * 3       # розрив у часі, після якого це вже інша межа
SHUFFLES = 3        # підлога: вибірка велика, трьох перемішувань вистачає


def collect(rows: list, by: str = "close", marks: int = MARKS,
            window: int = WINDOW) -> dict:
    """Усі події ніг шести монет: ознаки обох рамок, мітки обох задач.

    Зсув від межі береться той самий, що в етапі 7: подія межі й девʼять
    перед нею — хвіст, десять після — голова. Решта подій ноги — «не
    край». Рамка дзеркала для події тіла — її власна нога.
    """
    bags: dict = {"mirror": [], "plain": [], "ціна": [], "belong": [],
                  "updown": [], "away": [], "pair": [], "t": [], "inner": [],
                  "tag": []}
    names: dict = {}
    tag = 0
    for row in rows:
        price, price_names = price_window(row, window)
        frames = {sign: class_columns(row, sign)[0] for sign in (1, -1)}
        names = {"клас": class_columns(row, 1)[1], "ціна": price_names}

        sign_of = np.zeros(row["count"], dtype=int)
        for leg in row["legs"]:
            sign_of[leg["first"]:leg["last"] + 1] = (
                1 if leg["kind"] == "up" else -1)

        belong = np.full(row["count"], NONE, dtype=int)
        updown = np.full(row["count"], NONE, dtype=int)
        away = np.full(row["count"], -1, dtype=np.int64)
        mark = np.full(row["count"], -1, dtype=np.int64)
        for one in junctions(row):
            sign = one["sign"]
            border = anchor(row, one["index"], sign, by)
            tag += 1
            for offset in range(-marks + 1, marks + 1):
                at = border + offset
                if not one["from"] <= at <= one["to"]:
                    continue
                if not row["inleg"][at]:
                    continue
                belong[at] = int(offset > 0)
                updown[at] = int(sign > 0)
                away[at] = abs(offset)
                mark[at] = tag
                # подія після межі читається рамкою ноги, що кінчилась
                sign_of[at] = sign

        inner = corrections(row)
        keep = np.flatnonzero(row["inleg"])
        if not len(keep):
            continue
        own = np.where(sign_of[keep] > 0, 1, -1)
        bags["mirror"].append(
            np.where((own > 0)[:, None], frames[1][keep], frames[-1][keep]))
        bags["plain"].append(frames[1][keep])
        bags["ціна"].append(price[keep])
        bags["belong"].append(belong[keep])
        bags["updown"].append(updown[keep])
        bags["away"].append(away[keep])
        bags["tag"].append(mark[keep])
        bags["pair"].append(np.full(len(keep), row["pair"]))
        bags["t"].append(row["t"][keep])
        bags["inner"].append(np.isin(keep, list(inner)))

    out = {name: np.concatenate(bags[name]) for name in bags}
    out["names"] = names
    drop = names["ціна"].index("ema_slope")
    cols = [i for i in range(len(names["ціна"])) if i != drop]
    out["names"][NO_EMA] = [names["ціна"][i] for i in cols]
    out["names"]["разом"] = names["клас"] + names["ціна"]
    out["price_keep"] = cols
    return out


def kit_of(bag: dict, kit: str, frame: str) -> np.ndarray:
    """Стовпці набору в потрібній рамці — збираються на льоту, не в памʼять."""
    block = bag[frame]
    if kit == "клас":
        return block
    if kit == "ціна":
        return bag["ціна"]
    if kit == NO_EMA:
        return bag["ціна"][:, bag["price_keep"]]
    return np.hstack([block, bag["ціна"]])


def fit3(x: np.ndarray, y: np.ndarray, train: np.ndarray,
         seed: int = SEED) -> np.ndarray:
    """Та сама модель, що в етапі 7, але з трьома відповідями."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=seed)
    model.fit(x[train], y[train])
    out = np.zeros((len(y), 3))
    out[:, model.classes_] = model.predict_proba(x)
    return out


def top_ladder(edge: np.ndarray, bag: dict, mark: np.ndarray, task: str,
               guess: np.ndarray, tops: tuple = TOPS) -> list:
    """Верхівка ряду: точність «це край», покриття меж і чи правильний бік.

    Верхівка — це те, як модель працює в живому ряді: беруться
    найгучніші `share` подій, і питається, скільки з них справді край.
    Покриття міряється **межами**, а не подіями: межа закрита, якщо
    бодай одна її подія потрапила у верхівку. Остання колонка —
    друге питання етапу: серед узятих подій краю бік усе ще правильний?
    """
    line, truth = edge[mark], bag[task][mark]
    tags = bag["tag"][mark]
    total = len(set(tags[tags > 0].tolist()))
    side = guess[mark][:, 0] < guess[mark][:, 1]
    order = np.argsort(-line, kind="stable")   # рівні числа — за порядком ряду
    out = []
    for share in tops:
        take = max(1, int(round(share * len(line))))
        chosen = order[:take]
        got = truth[chosen] != NONE
        right = side[chosen][got] == (truth[chosen][got] == 1)
        out.append({"share": share, "events": int(take),
                    "gate": float(line[chosen[-1]]),
                    "right": int(got.sum()),
                    "precision": float(got.mean()),
                    "recall": float(got.sum()
                                    / max(int((truth != NONE).sum()), 1)),
                    "covered": len(set(tags[chosen][got].tolist())),
                    "borders": total,
                    "side_ok": float(right.mean()) if got.any() else 0.0})
    return out


def gate_ladder(edge: np.ndarray, bag: dict, mark: np.ndarray,
                task: str, gates: tuple = GATES) -> list:
    """Те саме за самим порогом видачі: чи вміє модель мовчати."""
    line, truth = edge[mark], bag[task][mark]
    out = []
    for gate in gates:
        said = line > gate
        real = truth != NONE
        out.append({"gate": gate, "events": int(said.sum()),
                    "share": float(said.mean()),
                    "precision": float(real[said].mean())
                    if said.any() else 0.0,
                    "recall": float((said & real).sum()
                                    / max(int(real.sum()), 1))})
    return out


def hard(edge: np.ndarray, bag: dict, mark: np.ndarray, task: str,
         share: float = 0.02) -> dict:
    """Тверді негативи: корекції всередині ноги проти решти тіла.

    Корекція — поворот, який межею не є. Якщо модель бачить у ній край,
    її «ні» коштує менше: саме тут воно потрібне найбільше.
    """
    line = edge[mark]
    take = max(1, int(round(share * len(line))))
    gate = float(np.sort(line)[-take])
    body = mark & (bag[task] == NONE)
    inner = body & bag["inner"]
    plain = body & ~bag["inner"]
    return {"share": share, "gate": gate,
            "inner_events": int(inner.sum()),
            "inner_above": float((edge[inner] >= gate).mean())
            if inner.any() else 0.0,
            "plain_events": int(plain.sum()),
            "plain_above": float((edge[plain] >= gate).mean())
            if plain.any() else 0.0,
            "edge_above": float((edge[mark & (bag[task] != NONE)]
                                 >= gate).mean())}


def by_distance(edge: np.ndarray, bag: dict, mark: np.ndarray,
                share: float = 0.02) -> list:
    """Хід видачі «це край» за відстанню до межі: де саме модель гучна."""
    line = edge[mark]
    take = max(1, int(round(share * len(line))))
    gate = float(np.sort(line)[-take])
    out = []
    for step in range(0, MARKS + 1):
        spot = mark & (bag["away"] == step)
        if not spot.any():
            continue
        out.append({"away": step, "events": int(spot.sum()),
                    "mean": float(edge[spot].mean()),
                    "above": float((edge[spot] >= gate).mean())})
    far = mark & (bag["away"] < 0)
    out.append({"away": None, "events": int(far.sum()),
                "mean": float(edge[far].mean()),
                "above": float((edge[far] >= gate).mean())})
    return out


def score(bag: dict, task: str, kit: str, train: np.ndarray,
          val: np.ndarray, seed: int = SEED) -> dict:
    """Навчити на `train`, поміряти на `val` — усе, що важить для точності."""
    x = kit_of(bag, kit, TASKS[task]["frame"])
    y = bag[task]
    guess = fit3(x, y, train, seed)
    edge = 1.0 - guess[:, NONE]
    real = y != NONE
    # умовна міра етапу 7 на тій самій вибірці: бік серед подій краю
    side = val & real
    conditional = auc(guess[side & (y == 1)][:, 1],
                      guess[side & (y == 0)][:, 1]) if side.any() else 0.5
    return {"auc": auc(edge[val & real], edge[val & ~real]),
            "base": float(real[val].mean()),
            "n_train": int(train.sum()), "n_val": int(val.sum()),
            "side_auc": conditional,
            "side_accuracy": float(((guess[side][:, 1] > guess[side][:, 0])
                                    == (y[side] == 1)).mean())
            if side.any() else 0.0,
            "top": top_ladder(edge, bag, val, task, guess),
            "gates": gate_ladder(edge, bag, val, task),
            "hard": hard(edge, bag, val, task),
            "by_distance": by_distance(edge, bag, val)}


def by_date(bag: dict, task: str, sets: tuple = SETS) -> dict:
    """Розбиття за датою: навчання до 2026-08-14, замір після."""
    train, val = bag["t"] < VAL_FROM, bag["t"] >= VAL_FROM
    return {kit: score(bag, task, kit, train, val) for kit in sets}


def by_coin(bag: dict, task: str, sets: tuple = SETS) -> dict:
    """Відкладена монета: шість прогонів, у кожному одна монета не вчиться."""
    out = {}
    for kit in sets:
        per_pair, values, tops = {}, [], []
        for pair in sorted(set(bag["pair"].tolist())):
            val = bag["pair"] == pair
            one = score(bag, task, kit, ~val, val)
            best = one["top"][2]             # верхівка 2 %
            per_pair[pair] = {"auc": one["auc"], "events": one["n_val"],
                              "precision": best["precision"],
                              "covered": best["covered"],
                              "borders": best["borders"],
                              "side_ok": best["side_ok"]}
            values.append(one["auc"])
            tops.append(best["precision"])
        out[kit] = {"auc_mean": float(np.mean(values)),
                    "auc_min": float(np.min(values)),
                    "auc_max": float(np.max(values)),
                    "precision_mean": float(np.mean(tops)),
                    "by_pair": per_pair}
    return out


def floor(bag: dict, task: str, shuffles: int = SHUFFLES,
          seed: int = SEED) -> dict:
    """Підлога: та сама модель на перемішаній мітці. Має дати базу."""
    train, val = bag["t"] < VAL_FROM, bag["t"] >= VAL_FROM
    rng = np.random.default_rng(seed)
    mixed = dict(bag)
    aucs, tops = [], []
    for _ in range(shuffles):
        mixed[task] = rng.permutation(bag[task])
        one = score(mixed, task, "разом", train, val)
        aucs.append(one["auc"])
        tops.append(one["top"][2]["precision"])
    return {"auc_median": float(np.median(aucs)),
            "auc_max": float(np.max(aucs)),
            "precision_median": float(np.median(tops)),
            "shuffles": shuffles}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    parser.add_argument("--anchor", default="close", choices=("close", "none"))
    parser.add_argument("--marks", type=int, default=MARKS)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--sets", nargs="*", default=list(SETS))
    parser.add_argument("--tasks", nargs="*", default=list(TASKS))
    parser.add_argument("--coins", action="store_true",
                        help="ще й відкладена монета: шість прогонів на набір")
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    bag = collect(rows, args.anchor, args.marks, args.window)
    sets = tuple(one for one in args.sets if one in SETS)
    tasks = tuple(one for one in args.tasks if one in TASKS)

    result = {"script": SCRIPT, "ready": True, "pairs": args.pairs,
              "anchor": args.anchor, "marks": args.marks,
              "window": args.window, "trees": TREES, "seed": SEED,
              "sets": list(sets), "val_from": VAL_FROM,
              "events": int(len(bag["t"])),
              "edge": int((bag["belong"] != NONE).sum()),
              "body": int((bag["belong"] == NONE).sum()),
              "inner": int(bag["inner"].sum()),
              "base": float((bag["belong"] != NONE).mean()),
              "tasks": {}}
    print(f"подій у ногах {result['events']}, з них край {result['edge']} "
          f"({result['base'] * 100:.2f} %), корекцій {result['inner']}")

    for task in tasks:
        one = {"title": TASKS[task]["title"], "frame": TASKS[task]["frame"],
               "names": list(TASKS[task]["names"]),
               "date": by_date(bag, task, sets),
               "floor": floor(bag, task)}
        if args.coins:
            one["coin"] = by_coin(bag, task, sets)
        result["tasks"][task] = one

        print(f"\n{TASKS[task]['title']} · підлога AUC "
              f"{one['floor']['auc_median']:.3f}, точність верхівки 2 % "
              f"{one['floor']['precision_median']:.4f}")
        print(f"  {'набір':10s} {'AUC':>6s} {'верх 2 %':>9s} {'меж':>9s} "
              f"{'бік':>6s} {'корекції':>9s} {'тіло':>7s}")
        for kit in sets:
            got = one["date"][kit]
            best = got["top"][2]
            print(f"  {kit:10s} {got['auc']:6.3f} {best['precision']:9.3f} "
                  f"{best['covered']:4d} з {best['borders']:<3d} "
                  f"{best['side_ok']:6.3f} "
                  f"{got['hard']['inner_above']:9.3f} "
                  f"{got['hard']['plain_above']:7.3f}")
        if args.coins:
            for kit in sets:
                got = one["coin"][kit]
                print(f"    відкладена монета {kit:10s} AUC "
                      f"{got['auc_mean']:.3f} ({got['auc_min']:.3f}…"
                      f"{got['auc_max']:.3f}), точність "
                      f"{got['precision_mean']:.3f}")

    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "border_edge.json").write_text(
        json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
