"""Дзеркальна рамка ноги: спільний хід для всіх етапів дослідження 34.

Дослідження: research/34-pivot-signature/
Правила: rules/01-data-and-db.md → клас210х10-1х7д/д, rules/02-markup.md

Хід той самий, що в дослідженнях 28-31:

    ряд подій монети -> ема10(price_open) -> півоти зігзага 2.3 %
    -> ноги -> величини події -> ранги в межах монети

Додано дві речі, яких у попередніх дослідженнях не було:

1. **Дзеркало.** Фічі класу стоять парами «покупці проти продавців»:
   `d_up`/`d_down`, `d_resist_buy`/`d_support_sell`,
   `d_bal_resist_buy`/`d_bal_support_sell`. Відображення ціни міняє пару
   місцями, а `d_price_avg` — знак. Нога вгору й нога вниз лягають одна
   на одну, якщо в нозі вгору **власним** боком назвати покупців, а в
   нозі вниз — продавців.
2. **Якір межі.** Точку розвороту можна ставити не там, де стоїть півот
   ема10: `anchor` переносить її на справжній екстремум ціни у вікні
   ±`SEARCH` подій.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
"""

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "28-leg-edge-profile" / "scripts"))

from class210ema4 import ema  # noqa: E402
from edge_profile import HOLE, PERIOD, THRESHOLD, legs_of, load  # noqa: E402
from zigzag import zigzag  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
PAIRS = ("BTC_USDT", "ETH_USDT", "SOL_USDT", "XRP_USDT", "BNB_USDT",
         "DOGE_USDT")
PARAMS = ("mean", "first", "last", "peak", "spread", "slope")
FEATURES = ("d_up", "d_down", "d_resist_buy", "d_bal_resist_buy",
            "d_support_sell", "d_bal_support_sell", "d_price_avg")

MIN_LEG = 60        # нога коротша в заміри не йде
WINDOW = 40         # скільки подій з кожного боку півота показує профіль
SEARCH = 25         # у якому вікні шукається справжній екстремум ціни
INNER = 0.005       # поріг вкладеного зігзага: що вважаємо корекцією
CLEAR = 40          # корекція не ближче за стільки подій до країв ноги
SEED = 17
SHUFFLES = 500

# пара фічі при відображенні ціни; `d_price_avg` міняє знак, а не пару
MIRROR = {"d_up": "d_down", "d_down": "d_up",
          "d_resist_buy": "d_support_sell", "d_support_sell": "d_resist_buy",
          "d_bal_resist_buy": "d_bal_support_sell",
          "d_bal_support_sell": "d_bal_resist_buy",
          "d_price_avg": "d_price_avg"}

# бік ноги: чий обʼєм веде рух
SIDES = {"up": {"vol": "d_up", "lvl": "d_resist_buy",
                "bal": "d_bal_resist_buy"},
         "down": {"vol": "d_down", "lvl": "d_support_sell",
                  "bal": "d_bal_support_sell"}}

# підпис місця: обʼємні відношення мінус рівневі (дослідження 31, етап 4)
SIGNATURE_UP = ("d_up", "d_down")
SIGNATURE_DOWN = ("d_resist_buy", "d_support_sell", "d_bal_resist_buy",
                  "d_bal_support_sell")


def reduce_blocks(column: np.ndarray, how: str) -> np.ndarray:
    """Згортка фічі по девʼяти блоках події — шість параметрів."""
    if how == "mean":
        return column.mean(axis=1)
    if how == "first":
        return column[:, 0]
    if how == "last":
        return column[:, -1]
    if how == "peak":
        index = np.argmax(np.abs(column), axis=1)
        return column[np.arange(len(column)), index]
    if how == "spread":
        return column.std(axis=1)
    if how == "slope":
        j = np.arange(column.shape[1], dtype=float)
        j -= j.mean()
        return (column * j).sum(axis=1) / (j * j).sum()
    raise ValueError(f"невідомий параметр події: {how}")


def ranks(values: np.ndarray) -> np.ndarray:
    """Ранги 0…1 без звʼязків: порядок значення серед поданих."""
    order = np.argsort(np.argsort(values, kind="stable"), kind="stable")
    return (order + 0.5) / len(values)


def average_ranks(values: np.ndarray) -> np.ndarray:
    """Ранги 1…n, де однакові значення дістають середній ранг."""
    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    ranked = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        stop = start
        while (stop + 1 < len(values)
               and sorted_values[stop + 1] == sorted_values[start]):
            stop += 1
        ranked[order[start:stop + 1]] = (start + stop) / 2 + 1
        start = stop + 1
    return ranked


def auc(positive: np.ndarray, negative: np.ndarray) -> float:
    """Площа під ROC: імовірність, що позитив вищий за негатив.

    Однакові значення дають половину — інакше два однакові набори дали б
    не 0.5.
    """
    joined = np.concatenate([positive, negative])
    rank = average_ranks(joined)
    n1, n0 = len(positive), len(negative)
    return float((rank[:n1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def series(pair: str) -> dict:
    """Ряд монети: ноги, ранги 42 величин події, підпис місця, півоти."""
    data = load(pair, CLASS)
    place, legs = legs_of(data)
    legs = [leg for leg in legs
            if leg["hole_hours"] < HOLE / 3600 and leg["events"] >= MIN_LEG]
    count = len(data["t"])
    inleg = np.zeros(count, dtype=bool)
    for leg in legs:
        inleg[leg["first"]:leg["last"] + 1] = True

    rank: dict[tuple, np.ndarray] = {}
    for name in FEATURES:
        column = data["x"][..., data["features"].index(name)]
        for param in PARAMS:
            value = reduce_blocks(column, param)
            inside = value[inleg]
            good = np.isfinite(inside)
            for curve, source in (("rank", inside), ("amp", np.abs(inside))):
                filled = np.full(len(inside), np.nan)
                filled[good] = ranks(source[good])
                whole = np.full(count, np.nan)
                whole[inleg] = filled
                rank[(name, param, curve)] = whole

    with warnings.catch_warnings():        # поза ногами всі ранги — NaN
        warnings.simplefilter("ignore", RuntimeWarning)
        signature = (np.nanmean([rank[(f, "mean", "amp")]
                                 for f in SIGNATURE_UP], axis=0)
                     - np.nanmean([rank[(f, "mean", "amp")]
                                   for f in SIGNATURE_DOWN], axis=0))

    pivots = {}
    for old, new in zip(legs, legs[1:]):
        if new["first"] == old["last"] + 1:      # стик суцільний
            pivots[old["last"]] = 1 if old["kind"] == "up" else -1

    return {"pair": pair, "t": data["t"], "open": data["open"],
            "close": data["close"], "legs": legs, "place": place,
            "inleg": inleg, "rank": rank, "signature": signature,
            "pivots": pivots, "count": count}


def anchor(row: dict, index: int, kind: int, by: str = "close",
           span: int = SEARCH) -> int:
    """Перенести точку розвороту на справжній екстремум ціни поруч.

    `by` — на якій ціні шукати: `open` (ціна на початку події),
    `close` (ціна в кінці), `none` — лишити як є.
    """
    if by == "none":
        return index
    price = row[by]
    low, high = max(0, index - span), min(len(price), index + span + 1)
    piece = price[low:high]
    return low + int(np.argmax(piece) if kind > 0 else np.argmin(piece))


def corrections(row: dict, threshold: float = INNER,
                clear: int = CLEAR) -> dict:
    """Корекції: півоти вкладеного зігзага всередині ноги, далеко від країв."""
    smooth = ema(row["open"], PERIOD)
    found = {}
    for pivot in zigzag(smooth, threshold):
        index = pivot.index
        if not row["inleg"][index]:
            continue
        if min((abs(index - p) for p in row["pivots"]), default=10 ** 9) < clear:
            continue
        found[index] = 1 if pivot.kind == "high" else -1
    return found


def sided(row: dict, kind: str, side: str, part: str, param: str = "mean",
          curve: str = "amp") -> np.ndarray:
    """Ранг фічі **власного** або **зустрічного** боку ноги напрямку `kind`."""
    other = "down" if kind == "up" else "up"
    table = SIDES[kind] if side == "own" else SIDES[other]
    return row["rank"][(table[part], param, curve)]


def shuffled_max(values: np.ndarray, labels: np.ndarray, shuffles: int,
                 seed: int = SEED) -> tuple[float, float]:
    """Шум перебору: медіана і 95 % найбільшого |z| на перемішаній мітці."""
    rng = np.random.default_rng(seed)
    scores = []
    for _ in range(shuffles):
        mixed = rng.permutation(labels)
        pos, neg = values[mixed == 1], values[mixed == 0]
        a = auc(pos, neg)
        n1, n0 = len(pos), len(neg)
        sigma = np.sqrt((n1 + n0 + 1) / (12.0 * n1 * n0))
        scores.append(abs(a - 0.5) / sigma)
    return float(np.median(scores)), float(np.percentile(scores, 95))


def z_of_auc(value: float, n1: int, n0: int) -> float:
    """z для AUC проти 0.5 (наближення Манна-Вітні)."""
    sigma = np.sqrt((n1 + n0 + 1) / (12.0 * n1 * n0))
    return float((value - 0.5) / sigma)
