"""Етап 6: чим корекція всередині ноги відрізняється від межі ноги.

Етап 5 показав, що підпис `S` стоїть і на корекції, тільки слабший
(0.353 проти 0.589). Тут розбирається, **чим саме** відрізняються ці
два місця: рівнем якої фічі, формою профілю навколо точки — чи самим
лише розміром повороту.

Обидва місця ставляться одним якорем (`close`) і міряються в одній
дзеркальній рамці: **власний** бік — той, чий обʼєм вів рух до точки
(покупці на вершині, продавці на дні), **зустрічний** — протилежний.

Чотири питання:

1. Пофічно: рівень кожної з семи фіч на межі, на корекції й у тілі,
   та `AUC` межі проти корекції по кожній окремо.
2. Форма: хід власного й зустрічного боку по зсувах навколо обох точок,
   зсув перекиду і симетрія горба.
3. Розмір: чи лишається різниця, коли повороти зрівняти за розміром —
   парування за найближчим розміром і залишок регресії `S` на розмір.
4. Тривалість: скільки подій після точки зустрічний бік тримається
   зверху.

Запуск:
    python3 research/34-pivot-signature/scripts/inner_turn.py

Вихід: results/inner_turn.json
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from mirror import (CLEAR, INNER, PAIRS, PERIOD, RESULTS, SHUFFLES, anchor,
                    auc, corrections, ema, series, shuffled_max, z_of_auc,
                    zigzag)

ANCHOR = "close"
NEAR = 2                  # скільки подій навколо точки не йдуть у тіло
OFFSETS = tuple(range(-10, 11))
CROSS_FROM = -10          # звідки шукається перекид
HOLD = 20                 # на скількох подіях після точки міряється тривалість
CALIPER = 0.10            # наскільки близькі розміри приймаються за пару
# хвости ноги: від якого й до якого зсуву міряється околиця без точки
TAILS = ((3, 10), (3, 20), (3, 40), (11, 20), (21, 40))
PARTS = (("own", "vol"), ("cnt", "vol"), ("own", "lvl"), ("cnt", "lvl"),
         ("own", "bal"), ("cnt", "bal"))
NAMES = {("own", "vol"): "власний обʼєм", ("cnt", "vol"): "зустрічний обʼєм",
         ("own", "lvl"): "власний рівень", ("cnt", "lvl"): "зустрічний рівень",
         ("own", "bal"): "власний баланс", ("cnt", "bal"): "зустрічний баланс",
         ("", "price"): "ціна", ("", "S"): "підпис S"}


def kind_of(sign: int) -> str:
    """Напрямок руху, що привів у точку: вершина — вгору, дно — вниз."""
    return "up" if sign > 0 else "down"


def curve(row: dict, side: str, part: str, sign: int) -> np.ndarray:
    """Ранг фічі власного або зустрічного боку для повороту знака `sign`."""
    from mirror import sided
    return sided(row, kind_of(sign), "own" if side == "own" else "cnt", part)


def value(row: dict, side: str, part: str, sign: int, index: int) -> float:
    if part == "S":
        return float(row["signature"][index])
    if part == "price":
        return float(row["rank"][("d_price_avg", "mean", "amp")][index])
    return float(curve(row, side, part, sign)[index])


def points(row: dict) -> tuple[dict, dict]:
    """Межі й корекції ряду, обидві перенесені тим самим якорем."""
    pivots = {anchor(row, i, k, ANCHOR): k for i, k in row["pivots"].items()}
    inner = {anchor(row, i, k, ANCHOR): k for i, k in corrections(row).items()}
    inner = {i: k for i, k in inner.items()
             if min((abs(i - p) for p in pivots), default=10 ** 9) >= CLEAR}
    return pivots, inner


def features(rows: list) -> dict:
    """Рівень кожної величини на межі, на корекції й у тілі."""
    keys = list(PARTS) + [("", "price"), ("", "S")]
    border = {key: [] for key in keys}
    inner = {key: [] for key in keys}
    body = {key: [] for key in keys}
    for row in rows:
        pivots, corr = points(row)
        mask = row["inleg"].copy()
        for index in list(pivots) + list(corr):
            mask[max(0, index - NEAR - 1):index + NEAR + 2] = False
        spots = np.where(mask)[0]
        for key in keys:
            side, part = key
            for table, into in ((pivots, border), (corr, inner)):
                for index, sign in table.items():
                    got = value(row, side, part, sign, index)
                    if np.isfinite(got):
                        into[key].append(got)
            # тіло: знак повороту невідомий, беремо обидва боки порівну
            for sign in (1, -1):
                got = np.array([value(row, side, part, sign, int(i))
                                for i in spots[::2 if sign > 0 else -2]])
                body[key] += list(got[np.isfinite(got)])
    out = {}
    for key in keys:
        high = np.array(border[key])
        low = np.array(inner[key])
        rest = np.array(body[key])
        labels = np.r_[np.ones(len(high)), np.zeros(len(low))]
        noise = shuffled_max(np.r_[high, low], labels, SHUFFLES)
        name = f"{key[0]}_{key[1]}" if key[0] else key[1]
        out[name] = {"title": NAMES[key],
                     "border": float(high.mean()),
                     "correction": float(low.mean()),
                     "body": float(rest.mean()),
                     "auc_border_correction": auc(high, low),
                     "auc_correction_body": auc(low, rest),
                     "z": z_of_auc(auc(high, low), len(high), len(low)),
                     "noise_95": noise[1],
                     "n_border": len(high), "n_correction": len(low)}
    return out


def shape(rows: list) -> dict:
    """Хід величин по зсувах навколо межі й навколо корекції."""
    keys = list(PARTS) + [("", "price"), ("", "S")]
    out = {}
    for label in ("border", "correction"):
        table = {f"{k[0]}_{k[1]}" if k[0] else k[1]: [] for k in keys}
        for row in rows:
            pivots, corr = points(row)
            chosen = pivots if label == "border" else corr
            for index, sign in chosen.items():
                for key in keys:
                    side, part = key
                    name = f"{side}_{part}" if side else part
                    line = [value(row, side, part, sign, index + o)
                            if 0 <= index + o < row["count"] else np.nan
                            for o in OFFSETS]
                    table[name].append(line)
        out[label] = {name: [float(np.nanmean(np.array(lines)[:, j]))
                             for j in range(len(OFFSETS))]
                      for name, lines in table.items()}
        own = np.array(out[label]["own_vol"])
        cnt = np.array(out[label]["cnt_vol"])
        cross = None
        for j, off in enumerate(OFFSETS):
            if off < CROSS_FROM:
                continue
            if all(cnt[k] > own[k] for k in range(j, len(OFFSETS))):
                cross = off
                break
        line = np.array(out[label]["S"])
        middle = OFFSETS.index(0)
        base = float(np.nanmin(line))
        weight = line - base
        left = float(weight[:middle].sum())
        right = float(weight[middle + 1:].sum())
        out[label]["cross"] = cross
        out[label]["peak_offset"] = int(OFFSETS[int(np.nanargmax(line))])
        out[label]["left_right"] = left / right if right else None
        out[label]["contrast"] = float(line[middle] - line[0])
        wide = [j for j, off in enumerate(OFFSETS) if abs(off) >= 3]
        out[label]["pedestal"] = float(np.nanmean(line[wide]))
        out[label]["spike"] = float(line[middle] - np.nanmean(line[wide]))
    out["offsets"] = list(OFFSETS)
    return out


def pedestal(rows: list) -> dict:
    """Рівень `S` навколо точки без самої точки — проти рівня в точці."""
    wide = [o for o in OFFSETS if 3 <= abs(o) <= 10]
    out = {"window": [min(abs(o) for o in wide), max(abs(o) for o in wide)]}
    got = {}
    for label in ("border", "correction"):
        spot, ring = [], []
        for row in rows:
            pivots, corr = points(row)
            S = row["signature"]
            for index in (pivots if label == "border" else corr):
                near = [S[index + o] for o in wide
                        if 0 <= index + o < row["count"]]
                near = [v for v in near if np.isfinite(v)]
                if not near or not np.isfinite(S[index]):
                    continue
                spot.append(float(S[index]))
                ring.append(float(np.mean(near)))
        got[label] = (np.array(spot), np.array(ring))
        out[label] = {"spot": float(np.mean(spot)), "ring": float(np.mean(ring)),
                      "spike": float(np.mean(spot) - np.mean(ring)),
                      "n": len(spot)}
    high, low = got["border"], got["correction"]
    out["auc_spot"] = auc(high[0], low[0])
    out["auc_ring"] = auc(high[1], low[1])
    out["auc_spike"] = auc(high[0] - high[1], low[0] - low[1])
    out["z_ring"] = z_of_auc(out["auc_ring"], len(high[1]), len(low[1]))
    return out


def leg_bounds(row: dict) -> tuple[np.ndarray, np.ndarray]:
    """Для кожної події — перша й остання подія її ноги."""
    first = np.full(row["count"], -1, dtype=int)
    last = np.full(row["count"], -1, dtype=int)
    for leg in row["legs"]:
        first[leg["first"]:leg["last"] + 1] = leg["first"]
        last[leg["first"]:leg["last"] + 1] = leg["last"]
    return first, last


def before(rows: list) -> dict:
    """Околиця **до** точки: хвіст ноги, що закінчується, без самої точки.

    Права половина околиці належить уже наступній нозі, тому для
    розмітки годиться лише ліва. Міряються чотири вікна різної довжини
    і, для порівняння, дзеркальні праві.
    """
    out = {"windows": [list(w) for w in TAILS]}
    kept = {}
    for label in ("border", "correction"):
        rows_left = {w: [] for w in TAILS}
        rows_right = {w: [] for w in TAILS}
        spot = []
        for row in rows:
            pivots, corr = points(row)
            first, last = leg_bounds(row)
            S = row["signature"]
            for index in (pivots if label == "border" else corr):
                if not (0 <= index < row["count"]) or first[index] < 0:
                    continue
                spot.append(float(S[index]))
                for near, far in TAILS:
                    left = [S[index - o] for o in range(near, far + 1)
                            if index - o >= first[index]]
                    right = [S[index + o] for o in range(near, far + 1)
                             if index + o < row["count"]]
                    left = [v for v in left if np.isfinite(v)]
                    right = [v for v in right if np.isfinite(v)]
                    rows_left[(near, far)].append(
                        float(np.mean(left)) if len(left) >= far - near else np.nan)
                    rows_right[(near, far)].append(
                        float(np.mean(right)) if len(right) >= far - near else np.nan)
        kept[label] = (rows_left, rows_right, np.array(spot))
    for near, far in TAILS:
        name = f"{near}-{far}"
        pair = {}
        for side, which in (("before", 0), ("after", 1)):
            high = np.array(kept["border"][which][(near, far)])
            low = np.array(kept["correction"][which][(near, far)])
            high, low = high[np.isfinite(high)], low[np.isfinite(low)]
            pair[side] = {"border": float(high.mean()),
                          "correction": float(low.mean()),
                          "auc": auc(high, low),
                          "z": z_of_auc(auc(high, low), len(high), len(low)),
                          "n_border": len(high), "n_correction": len(low)}
        high = np.array(kept["border"][0][(near, far)])
        low = np.array(kept["correction"][0][(near, far)])
        both = {}
        for label, which in (("border", high), ("correction", low)):
            spot = kept[label][2]
            good = np.isfinite(which) & np.isfinite(spot)
            both[label] = (spot[good] + which[good]) / 2
        pair["with_point"] = {
            "border": float(both["border"].mean()),
            "correction": float(both["correction"].mean()),
            "auc": auc(both["border"], both["correction"]),
            "z": z_of_auc(auc(both["border"], both["correction"]),
                          len(both["border"]), len(both["correction"])),
            "n_border": len(both["border"]),
            "n_correction": len(both["correction"])}
        out[name] = pair
    return out


def turn_size(row: dict) -> tuple[dict, dict]:
    """Розмір повороту: менший із двох сусідніх рухів, у частках ціни."""
    smooth = ema(row["open"], PERIOD)
    sizes = {}
    pivots = zigzag(smooth, INNER)
    for before, middle, after in zip(pivots, pivots[1:], pivots[2:]):
        left = abs(np.log(smooth[middle.index] / smooth[before.index]))
        right = abs(np.log(smooth[after.index] / smooth[middle.index]))
        sizes[middle.index] = float(min(left, right))
    legs = row["legs"]
    border = {}
    for old, new in zip(legs, legs[1:]):
        if new["first"] == old["last"] + 1:
            border[old["last"]] = float(min(abs(old["move"]), abs(new["move"])))
    return border, sizes


def by_size(rows: list) -> dict:
    """Чи лишається різниця, коли повороти зрівняти за розміром."""
    high, low = [], []
    for row in rows:
        border_size, inner_size = turn_size(row)
        pivots, corr = points(row)
        raw_border = {anchor(row, i, k, ANCHOR): i for i, k in row["pivots"].items()}
        raw_inner = {anchor(row, i, k, ANCHOR): i
                     for i, k in corrections(row).items()}
        S = row["signature"]
        for index in pivots:
            source = raw_border.get(index)
            if source is None or source not in border_size:
                continue
            if np.isfinite(S[index]):
                high.append((border_size[source], float(S[index])))
        for index in corr:
            source = raw_inner.get(index)
            if source is None or source not in inner_size:
                continue
            if np.isfinite(S[index]):
                low.append((inner_size[source], float(S[index])))
    high = np.array(high)
    low = np.array(low)
    band = (float(max(high[:, 0].min(), low[:, 0].min())),
            float(min(high[:, 0].max(), low[:, 0].max())))
    inside_high = high[(high[:, 0] >= band[0]) & (high[:, 0] <= band[1])]
    inside_low = low[(low[:, 0] >= band[0]) & (low[:, 0] <= band[1])]

    # залишок: крива `S` від розміру вчиться на корекціях, межа міряється нею
    fit = np.polyfit(np.log(low[:, 0]), low[:, 1], 2)
    predicted = np.polyval(fit, np.log(high[:, 0]))
    residual = high[:, 1] - predicted
    own = low[:, 1] - np.polyval(fit, np.log(low[:, 0]))

    # парування: кожній межі — корекція найближчого розміру, без повторів
    order = np.argsort(low[:, 0])
    pool = low[order]
    used = np.zeros(len(pool), dtype=bool)
    pairs, missed = [], 0
    for size, score in sorted(high.tolist(), key=lambda one: -one[0]):
        free = np.where(~used)[0]
        if not len(free):
            missed += 1
            continue
        pick = free[int(np.argmin(np.abs(np.log(pool[free, 0]) - np.log(size))))]
        if abs(np.log(pool[pick, 0]) - np.log(size)) > CALIPER:
            missed += 1
            continue
        used[pick] = True
        pairs.append((size, score, float(pool[pick, 0]), float(pool[pick, 1])))
    pairs = np.array(pairs)
    return {
        "border": {"n": len(high), "size_median": float(np.median(high[:, 0])),
                   "size_min": float(high[:, 0].min()),
                   "size_max": float(high[:, 0].max()),
                   "signature": float(high[:, 1].mean())},
        "correction": {"n": len(low), "size_median": float(np.median(low[:, 0])),
                       "size_min": float(low[:, 0].min()),
                       "size_max": float(low[:, 0].max()),
                       "signature": float(low[:, 1].mean())},
        "overlap": {"from": band[0], "to": band[1],
                    "n_border": len(inside_high), "n_correction": len(inside_low),
                    "share_border": len(inside_high) / len(high),
                    "share_correction": len(inside_low) / len(low),
                    "border_signature": float(inside_high[:, 1].mean())
                    if len(inside_high) else None,
                    "correction_signature": float(inside_low[:, 1].mean())
                    if len(inside_low) else None,
                    "auc": auc(inside_high[:, 1], inside_low[:, 1])
                    if len(inside_high) and len(inside_low) else None},
        "residual": {"border": float(residual.mean()),
                     "correction": float(own.mean()),
                     "auc": auc(residual, own),
                     "z": z_of_auc(auc(residual, own), len(residual), len(own))},
        "matched": {"n": len(pairs), "missed": missed, "caliper": CALIPER,
                    "border_size": float(pairs[:, 0].mean()),
                    "correction_size": float(pairs[:, 2].mean()),
                    "border": float(pairs[:, 1].mean()),
                    "correction": float(pairs[:, 3].mean()),
                    "gap": float((pairs[:, 1] - pairs[:, 3]).mean()),
                    "t": float((pairs[:, 1] - pairs[:, 3]).mean()
                               / ((pairs[:, 1] - pairs[:, 3]).std(ddof=1)
                                  / np.sqrt(len(pairs))))}}


def persist(rows: list) -> dict:
    """Скільки подій після точки зустрічний бік тримається зверху."""
    out = {}
    for label in ("border", "correction"):
        held, first_back = [], []
        for row in rows:
            pivots, corr = points(row)
            for index, sign in (pivots if label == "border" else corr).items():
                own = curve(row, "own", "vol", sign)
                cnt = curve(row, "cnt", "vol", sign)
                line = []
                for step in range(1, HOLD + 1):
                    j = index + step
                    if j >= row["count"] or not np.isfinite(own[j]):
                        break
                    line.append(cnt[j] > own[j])
                if not line:
                    continue
                held.append(float(np.mean(line)))
                back = next((k + 1 for k, flag in enumerate(line) if not flag),
                            len(line) + 1)
                first_back.append(back)
        out[label] = {"share_counter_on_top": float(np.mean(held)),
                      "events_until_own_returns": float(np.median(first_back)),
                      "n": len(held)}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    result = {"pairs": args.pairs, "anchor": ANCHOR, "near": NEAR,
              "inner": INNER, "hold": HOLD,
              "features": features(rows), "shape": shape(rows),
              "pedestal": pedestal(rows), "before": before(rows),
              "size": by_size(rows), "persist": persist(rows)}
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / "inner_turn.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    print(f"{'величина':20s} {'межа':>6s} {'корекція':>9s} {'тіло':>7s} "
          f"{'межа/кор.':>10s} {'кор./тіло':>10s} {'z':>6s} {'шум':>5s}")
    for name, row in result["features"].items():
        print(f"{row['title']:20s} {row['border']:6.3f} {row['correction']:9.3f} "
              f"{row['body']:7.3f} {row['auc_border_correction']:10.3f} "
              f"{row['auc_correction_body']:10.3f} {row['z']:6.1f} "
              f"{row['noise_95']:5.1f}")
    print("\nформа:")
    for label in ("border", "correction"):
        one = result["shape"][label]
        print(f"  {label:11s} перекид {one['cross']}, пік S {one['peak_offset']}, "
              f"ліво/право {one['left_right']:.2f}, "
              f"контраст {one['contrast']:+.3f}")
    size = result["size"]
    print(f"\nрозмір повороту: межа {100*size['border']['size_median']:.2f} % "
          f"({100*size['border']['size_min']:.2f}–{100*size['border']['size_max']:.2f}), "
          f"корекція {100*size['correction']['size_median']:.2f} % "
          f"({100*size['correction']['size_min']:.2f}–{100*size['correction']['size_max']:.2f})")
    over = size["overlap"]
    print(f"  спільна смуга {100*over['from']:.2f}–{100*over['to']:.2f} %: "
          f"меж {over['n_border']} ({100*over['share_border']:.0f} %), "
          f"корекцій {over['n_correction']} ({100*over['share_correction']:.0f} %), "
          f"S {over['border_signature']:.3f} проти {over['correction_signature']:.3f}, "
          f"AUC {over['auc']:.3f}")
    res = size["residual"]
    print(f"  залишок кривої розміру: межа {res['border']:+.3f}, "
          f"корекція {res['correction']:+.3f}, AUC {res['auc']:.3f} (z {res['z']:.1f})")
    match = size["matched"]
    print(f"  парування за розміром: {match['n']} пар, "
          f"{100*match['border_size']:.2f} % проти {100*match['correction_size']:.2f} %, "
          f"S {match['border']:.3f} проти {match['correction']:.3f} "
          f"({match['gap']:+.3f}, t {match['t']:+.1f}), "
          f"без пари лишилось {match['missed']}")
    ring = result["pedestal"]
    print(f"\nпідмурівок (|зсув| {ring['window'][0]}…{ring['window'][1]}): "
          f"межа {ring['border']['ring']:.3f} проти корекції "
          f"{ring['correction']['ring']:.3f}, AUC {ring['auc_ring']:.3f} "
          f"(z {ring['z_ring']:.1f}); сплеск над ним "
          f"{ring['border']['spike']:+.3f} проти {ring['correction']['spike']:+.3f}, "
          f"AUC {ring['auc_spike']:.3f}; сама точка AUC {ring['auc_spot']:.3f}")
    print("\nоколиця до точки (хвіст своєї ноги) проти околиці після неї:")
    print(f"  {'вікно':>8s} {'до: межа':>9s} {'корекція':>9s} {'AUC':>6s} "
          f"{'z':>6s} | {'після: межа':>12s} {'корекція':>9s} {'AUC':>6s}")
    for near, far in TAILS:
        one = result["before"][f"{near}-{far}"]
        left, right = one["before"], one["after"]
        print(f"  −{far}…−{near:<4d} {left['border']:9.3f} "
              f"{left['correction']:9.3f} {left['auc']:6.3f} {left['z']:6.1f} | "
              f"{right['border']:12.3f} {right['correction']:9.3f} "
              f"{right['auc']:6.3f} | разом із точкою "
              f"{one['with_point']['auc']:.3f}")
    print("\nтривалість переваги зустрічного боку:")
    for label, one in result["persist"].items():
        print(f"  {label:11s} зверху на {100*one['share_counter_on_top']:.0f} % "
              f"з {HOLD} подій, власний повертається через "
              f"{one['events_until_own_returns']:.0f}")
    print(f"\n{path}")


if __name__ == "__main__":
    main()
