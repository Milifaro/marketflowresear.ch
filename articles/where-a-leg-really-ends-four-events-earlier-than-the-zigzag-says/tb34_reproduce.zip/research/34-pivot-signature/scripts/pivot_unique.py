"""Етап 5: чи є в підпису щось, що буває **тільки** на межі ноги.

Підпис місця `S` (обʼємні відношення мінус рівневі) міряється в трьох
місцях ряду: на межі ноги, на корекції всередині ноги (вкладений зігзаг
0.5 %) і в тілі ноги. Усі три точки ставляться **одним правилом** —
переносяться на справжній екстремум ціни, інакше порівнюються не місця,
а точність розмітки.

Три питання:

1. `AUC` межі проти тіла і межі проти корекції — на трьох якорях.
2. Точність верхівки: скільки справжніх меж серед `N` найгучніших подій
   ряду, де `N` — скільки меж у цьому ряді. Контроль — частка подій
   межі в ряді.
3. Чи знає підпис **розмір** розвороту: усі повороти зігзагів шести
   порогів, від 0.3 % до 2.3 %, проти рівня `S` у своїй точці.

Запуск:
    python3 research/34-pivot-signature/scripts/pivot_unique.py

Вихід: results/pivot_unique.json
"""

from __future__ import annotations

import argparse
import json
import sys

import numpy as np

from mirror import (CLEAR, INNER, PAIRS, PERIOD, RESULTS, SHUFFLES, anchor,
                    auc, corrections, ema, series, shuffled_max, z_of_auc,
                    zigzag)

ANCHORS = ("none", "open", "close")
NEAR = 2                 # скільки подій навколо межі вважаються межею
SIZES = (0.003, 0.005, 0.008, 0.012, 0.018, 0.023)


def points(row: dict, by: str) -> tuple[dict, dict]:
    pivots = {anchor(row, i, k, by): k for i, k in row["pivots"].items()}
    inner = {anchor(row, i, k, by): k for i, k in corrections(row).items()}
    inner = {i: k for i, k in inner.items()
             if min((abs(i - p) for p in pivots), default=10 ** 9) >= CLEAR}
    return pivots, inner


def levels(rows: list, by: str) -> dict:
    border, inner, body, per_pair = [], [], [], {}
    for row in rows:
        pivots, corr = points(row, by)
        S = row["signature"]
        mask = row["inleg"] & np.isfinite(S)
        for index in list(pivots) + list(corr):
            mask[max(0, index - NEAR - 1):index + NEAR + 2] = False
        take = lambda table: np.array([S[i] for i in table if np.isfinite(S[i])])
        border_pair, inner_pair = take(pivots), take(corr)
        border += list(border_pair)
        inner += list(inner_pair)
        body += list(S[mask])
        per_pair[row["pair"]] = {
            "border": float(border_pair.mean()),
            "correction": float(inner_pair.mean()),
            "body": float(S[mask].mean()),
            "auc_border_body": auc(border_pair, S[mask]),
            "auc_border_correction": auc(border_pair, inner_pair)}
    border, inner, body = np.array(border), np.array(inner), np.array(body)
    labels = np.r_[np.ones(len(border)), np.zeros(len(inner))]
    noise = shuffled_max(np.r_[border, inner], labels, SHUFFLES)
    return {"anchor": by,
            "border": float(border.mean()), "n_border": len(border),
            "correction": float(inner.mean()), "n_correction": len(inner),
            "body": float(body.mean()), "n_body": len(body),
            "auc_border_body": auc(border, body),
            "auc_correction_body": auc(inner, body),
            "auc_border_correction": auc(border, inner),
            "z_border_correction": z_of_auc(auc(border, inner), len(border),
                                            len(inner)),
            "z_border_body": z_of_auc(auc(border, body), len(border),
                                      len(body)),
            "noise_median": noise[0], "noise_95": noise[1],
            "by_pair": per_pair}


def top(rows: list, by: str) -> dict:
    out = {}
    for row in rows:
        pivots, _ = points(row, by)
        S = row["signature"]
        index = np.where(row["inleg"] & np.isfinite(S))[0]
        count = len(pivots)
        chosen = index[np.argsort(-S[index])[:count]]
        hit = sum(1 for i in chosen
                  if any(abs(i - p) <= NEAR for p in pivots))
        base = sum(1 for i in index
                   if any(abs(i - p) <= NEAR for p in pivots)) / len(index)
        out[row["pair"]] = {"borders": count, "hit": hit,
                            "precision": hit / count, "base": base,
                            "lift": (hit / count) / base if base else 0.0}
    return out


def by_size(rows: list, by: str) -> dict:
    sizes, values = [], []
    for row in rows:
        smooth = ema(row["open"], PERIOD)
        best: dict = {}
        for threshold in SIZES:
            found = zigzag(smooth, threshold)
            for left, middle, right in zip(found, found[1:], found[2:]):
                index = middle.index
                if not row["inleg"][index]:
                    continue
                size = min(abs(np.log(smooth[middle.index] / smooth[left.index])),
                           abs(np.log(smooth[right.index] / smooth[middle.index])))
                if best.get(index, (0.0, 0))[0] < size:
                    best[index] = (size, 1 if middle.kind == "high" else -1)
        for index, (size, kind) in best.items():
            moved = anchor(row, index, kind, by)
            value = row["signature"][moved]
            if np.isfinite(value):
                sizes.append(size)
                values.append(value)
    sizes, values = np.array(sizes), np.array(values)
    order = np.argsort(sizes)
    rank_size = np.empty(len(sizes)); rank_size[order] = np.arange(len(sizes))
    order = np.argsort(values)
    rank_value = np.empty(len(values)); rank_value[order] = np.arange(len(values))
    rho = float(np.corrcoef(rank_size, rank_value)[0, 1])
    bounds = np.percentile(sizes, [0, 20, 40, 60, 80, 100])
    groups = []
    for low, high in zip(bounds, bounds[1:]):
        mask = (sizes >= low) & (sizes <= high)
        groups.append({"from": float(low), "to": float(high),
                       "signature": float(values[mask].mean()),
                       "n": int(mask.sum())})
    return {"spearman": rho, "turns": len(sizes), "groups": groups}


def anchored_noise(rows: list, by: str, times: int = 5) -> dict:
    """Контроль самого якоря: випадкова точка тіла, перенесена тим правилом.

    Якір шукає екстремум ціни, а гучні події й так стоять біля
    екстремумів. Тому те саме правило застосовується до випадкових точок
    ноги — і рівень підпису порівнюється з рівнем на справжній межі.
    """
    rng = np.random.default_rng(17)
    border, fake, plain = [], [], []
    for row in rows:
        pivots, _ = points(row, by)
        S = row["signature"]
        index = np.where(row["inleg"] & np.isfinite(S))[0]
        border += [S[i] for i in pivots if np.isfinite(S[i])]
        far = np.array([i for i in index
                        if min((abs(i - p) for p in pivots),
                               default=10 ** 9) > 60])
        picks = rng.choice(far, size=min(len(far), len(pivots) * times),
                           replace=False)
        for point in picks:
            moved = anchor(row, int(point), int(rng.choice([1, -1])), by)
            if np.isfinite(S[moved]):
                fake.append(S[moved])
            if np.isfinite(S[point]):
                plain.append(S[point])
    border, fake, plain = np.array(border), np.array(fake), np.array(plain)
    return {"border": float(border.mean()), "anchored": float(fake.mean()),
            "plain": float(plain.mean()), "n": len(fake),
            "auc": auc(border, fake),
            "z": z_of_auc(auc(border, fake), len(border), len(fake))}


def top_noise(rows: list, by: str, shuffles: int = 200) -> dict:
    """Скільки збирає верхівка, якщо межі розкидати по ряду навмання."""
    rng = np.random.default_rng(17)
    out = {}
    for row in rows:
        pivots, _ = points(row, by)
        S = row["signature"]
        index = np.where(row["inleg"] & np.isfinite(S))[0]
        count = len(pivots)
        chosen = set(index[np.argsort(-S[index])[:count]])
        hits = []
        for _ in range(shuffles):
            fake = rng.choice(index, size=count, replace=False)
            hits.append(sum(1 for i in chosen
                            if any(abs(i - p) <= NEAR for p in fake)))
        out[row["pair"]] = {"median": float(np.median(hits)),
                            "p95": float(np.percentile(hits, 95))}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    result = {"pairs": args.pairs, "near": NEAR, "inner": INNER,
              "levels": {by: levels(rows, by) for by in ANCHORS},
              "top": {by: top(rows, by) for by in ANCHORS},
              "size": by_size(rows, "close"),
              "top_noise": top_noise(rows, "close"),
              "anchored_noise": anchored_noise(rows, "close")}
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / "pivot_unique.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    print(f"{'якір':8s} {'межа':>6s} {'корекція':>9s} {'тіло':>7s} "
          f"{'межа/тіло':>10s} {'кор./тіло':>10s} {'межа/кор.':>10s} {'z':>5s} {'шум 95 %':>9s}")
    for by in ANCHORS:
        row = result["levels"][by]
        print(f"{by:8s} {row['border']:6.3f} {row['correction']:9.3f} {row['body']:7.3f} "
              f"{row['auc_border_body']:10.3f} {row['auc_correction_body']:10.3f} "
              f"{row['auc_border_correction']:10.3f} "
              f"{row['z_border_correction']:5.1f} {row['noise_95']:9.1f}")
    print("\nточність верхівки підпису (якір close):")
    for pair, row in result["top"]["close"].items():
        print(f"  {pair:10s} меж {row['borders']:3d}, у верхівці {row['hit']:3d} "
              f"({100*row['precision']:5.1f} %), база {100*row['base']:.1f} %, "
              f"×{row['lift']:.1f}, шум {result['top_noise'][pair]['median']:.0f}"
              f"/{result['top_noise'][pair]['p95']:.0f}")
    control = result["anchored_noise"]
    print(f"\nконтроль якоря: межа {control['border']:.3f}, випадкова точка тим "
          f"самим правилом {control['anchored']:.3f}, без правила {control['plain']:.3f}, "
          f"AUC {control['auc']:.3f} (z {control['z']:.1f}, n {control['n']})")
    print(f"\nрозмір розвороту проти підпису: {result['size']['turns']} поворотів, "
          f"Спірмен {result['size']['spearman']:+.3f}")
    for group in result["size"]["groups"]:
        print(f"  {100*group['from']:5.2f}–{100*group['to']:5.2f} %: "
              f"S {group['signature']:+.3f}, n {group['n']}")
    print(f"\n{path}")


if __name__ == "__main__":
    main()
