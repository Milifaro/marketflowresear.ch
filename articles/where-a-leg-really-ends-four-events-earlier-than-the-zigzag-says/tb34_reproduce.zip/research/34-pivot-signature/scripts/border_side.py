"""Етап 7: бік межі — подія належить нозі, що кінчається, чи тій, що почалась.

Дослідження: research/34-pivot-signature/
Правила: rules/01-data-and-db.md, rules/02-markup.md → Точка кінця ноги

Етапи 1-6 питали, **де** межа і чим вона відрізняється від корекції. Тут
питаються дві інші речі, і обидві — на тій самій вибірці подій краю,
тією самою моделлю й тією самою мірою.

    бік межі      мітка 0 -> подія хвоста ноги, що кінчається (зсув -9 ... 0)
                  мітка 1 -> подія голови ноги, що почалась   (зсув +1 ... +10)

    бік розвороту мітка 0 -> межа поруч є дном
                  мітка 1 -> межа поруч є вершиною

Рамки в них різні, і інакше бути не може. «Бік межі» читається
**дзеркалом**: власний бік ноги, що кінчається, проти зустрічного, і
нога вниз лягає на ногу вгору. «Бік розвороту» дзеркала не має — саме
воно і є відповіддю, — тому там величини беруться як є.

Дослідження 28 (етап 5) питало те саме на голих півотах ема10 і дало
AUC 0.877. Тут три відмінності, і кожна — предмет цього дослідження:

1. **Точна межа.** Точка розвороту береться за стандартом розмітки —
   екстремум `price_close` у вікні ±25 подій (`--anchor close`). Якір
   `none` лишає голий півот ема10: різниця між ними і є ціна стандарту.
2. **Дзеркало.** Ноги вгору й ноги вниз зводяться в одну задачу:
   власний бік ноги, що кінчається, проти зустрічного. Модель одна на
   всі 465 стиків, а не дві.
3. **Три набори входів.** Клас проти причинного вікна ціни і разом —
   щоб знати, чи каже клас щось понад те, що вже видно з ходу ціни.

Замір умовний за побудовою: модель питають тільки на подіях краю, а в
живому ряді край ще треба знайти. Це друга ланка ланцюжка, не перша.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/border_side.json

Запуск:
    python3 research/34-pivot-signature/scripts/border_side.py
    python3 research/34-pivot-signature/scripts/border_side.py --marks 5
"""

from __future__ import annotations

import argparse
import json
import sys

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

from mirror import (PAIRS, PARAMS, RESULTS, SEED, anchor, auc, series)

sys.path.insert(0, str(RESULTS.parents[2] / "28-leg-edge-profile" / "scripts"))

from class210ema4 import ema      # noqa: E402
from edge_profile import PERIOD   # noqa: E402
from leg_start import VAL_FROM    # noqa: E402

MARKS = 10          # скільки подій з кожного боку межі вважати краєм
WINDOW = 39         # причинне вікно ціни: стільки попередніх подій
TREES = 300         # дерев у бустингу — як у дослідженні 28
SHUFFLES = 3        # скільки разів перемішується мітка для підлоги
ANCHORS = ("close", "none")
# дві задачі на одній вибірці: рамка ознак і мітка в них різні
TASKS = {"belong": {"title": "бік межі", "frame": "mirror"},
         "updown": {"title": "бік розвороту", "frame": "plain"}}
SETS = ("клас", "ціна", "ціна−ема", "разом")
# `ema_slope` — нахил ема10 у вікні. Півот зігзага стоїть на екстремумі
# ема10, тому при якорі `none` ця величина **визначає** мітку, а не
# передбачає її. Набір без неї показує, скільки лишається без тавтології.
NO_EMA = "ціна−ема"

# частини класу в дзеркальній рамці: чий обʼєм, чиї рівні, чий баланс
PARTS = (("own", "vol"), ("cnt", "vol"), ("own", "lvl"), ("cnt", "lvl"),
         ("own", "bal"), ("cnt", "bal"))
CURVES = ("rank", "amp")


def slopes(block: np.ndarray) -> np.ndarray:
    """Нахил прямої в кожному вікні: скалярний добуток зі сталою вагою."""
    steps = np.arange(block.shape[-1], dtype=float)
    weight = (steps - steps.mean()) / ((steps - steps.mean()) ** 2).sum()
    return block @ weight


def price_window(row: dict, window: int = WINDOW) -> tuple[np.ndarray, list]:
    """Ознаки ходу ціни з вікна **попередніх** подій. Майбутнього немає.

    Рядок `i` описує вікно, що закінчується подією `i`; перші `window-1`
    подій ряду вікна не мають і йдуть `NaN` — бустинг читає їх як пропуск.
    """
    v = np.log(row["close"] / row["open"])
    view = sliding_window_view(v, window)
    cum = np.cumsum(view, axis=1)
    smooth = sliding_window_view(ema(row["open"], PERIOD), window)
    columns = {
        "v_sum": view.sum(axis=1), "v_mean": view.mean(axis=1),
        "v_std": view.std(axis=1), "v_max": view.max(axis=1),
        "v_min": view.min(axis=1), "v_abs": np.abs(view).mean(axis=1),
        "v_last": view[:, -1], "up_share": (view > 0).mean(axis=1),
        "path": np.abs(view).sum(axis=1),
        "run_up": cum.max(axis=1), "draw_down": cum.min(axis=1),
        "v_slope": slopes(view), "ema_slope": slopes(smooth),
    }
    columns["straight"] = np.divide(columns["v_sum"], columns["path"],
                                    out=np.zeros_like(columns["v_sum"]),
                                    where=columns["path"] != 0)
    names = sorted(columns)
    matrix = np.full((row["count"], len(names)), np.nan)
    matrix[window - 1:] = np.column_stack([columns[name] for name in names])
    return matrix, names


def mirrored_price(matrix: np.ndarray, names: list,
                   sign: int) -> np.ndarray:
    """Те саме вікно очима ноги, що кінчається: вниз читається як вгору.

    Нога вниз — це відображена нога вгору, тому знакові величини міняють
    знак, підйом міняється місцями з просадкою, а частка подій угору
    стає часткою подій униз.
    """
    if sign > 0:
        return matrix
    out = matrix.copy()
    place = {name: index for index, name in enumerate(names)}
    for name in ("v_sum", "v_mean", "v_last", "v_slope", "ema_slope",
                 "straight"):
        out[:, place[name]] = -matrix[:, place[name]]
    out[:, place["v_max"]] = -matrix[:, place["v_min"]]
    out[:, place["v_min"]] = -matrix[:, place["v_max"]]
    out[:, place["run_up"]] = -matrix[:, place["draw_down"]]
    out[:, place["draw_down"]] = -matrix[:, place["run_up"]]
    out[:, place["up_share"]] = 1.0 - matrix[:, place["up_share"]]
    return out


def class_columns(row: dict, sign: int) -> tuple[np.ndarray, list]:
    """42 величини події в дзеркальній рамці ноги, що кінчається.

    Ранг — величина зі знаком, тому при дзеркалі він стає `1 − ранг`;
    розмах знака не має і лишається як є.
    """
    from mirror import sided
    kind = "up" if sign > 0 else "down"
    columns, names = [], []
    for side, part in PARTS:
        for param in PARAMS:
            for curve in CURVES:
                columns.append(sided(row, kind, side, part, param, curve))
                names.append(f"{side}_{part}·{param}·{curve}")
    for param in PARAMS:
        for curve in CURVES:
            line = row["rank"][("d_price_avg", param, curve)]
            columns.append(line if (sign > 0 or curve == "amp") else 1.0 - line)
            names.append(f"price·{param}·{curve}")
    return np.column_stack(columns), names


def junctions(row: dict) -> list:
    """Стики двох сусідніх ніг: межа, знак ноги, що кінчається, і краї."""
    found = []
    for old, new in zip(row["legs"], row["legs"][1:]):
        if new["first"] != old["last"] + 1:
            continue
        found.append({"index": old["last"],
                      "sign": 1 if old["kind"] == "up" else -1,
                      "from": old["first"], "to": new["last"]})
    return found


def collect(rows: list, by: str = "close", marks: int = MARKS,
            window: int = WINDOW, frame: str = "mirror") -> dict:
    """Події краю всіх монет: ознаки, зсув від межі, знак межі, монета, час.

    `frame` — у чиїй рамці читаються величини: `mirror` зводить ногу вниз
    на ногу вгору (тоді бік ноги з ознак зникає), `plain` лишає як є.
    """
    bags: dict = {"клас": [], "ціна": [], "kind": [], "offset": [], "pair": [],
                  "t": []}
    names: dict = {}
    for row in rows:
        pair = row["pair"]
        price, price_names = price_window(row, window)
        for stick in junctions(row):
            sign = stick["sign"]
            border = anchor(row, stick["index"], sign, by)
            seen = sign if frame == "mirror" else 1
            block, class_names = class_columns(row, seen)
            mirror_price = mirrored_price(price, price_names, seen)
            names = {"клас": class_names, "ціна": price_names,
                     "разом": class_names + price_names}
            for offset in range(-marks + 1, marks + 1):
                event = border + offset
                if not stick["from"] <= event <= stick["to"]:
                    continue
                if not row["inleg"][event]:
                    continue
                bags["клас"].append(block[event])
                bags["ціна"].append(mirror_price[event])
                bags["kind"].append(sign)
                bags["offset"].append(offset)
                bags["pair"].append(pair)
                bags["t"].append(row["t"][event])
    out = {"клас": np.array(bags["клас"]), "ціна": np.array(bags["ціна"]),
           "kind": np.array(bags["kind"]), "offset": np.array(bags["offset"]),
           "pair": np.array(bags["pair"]), "t": np.array(bags["t"]),
           "names": names}
    drop = out["names"]["ціна"].index("ema_slope")
    keep = [i for i in range(len(out["names"]["ціна"])) if i != drop]
    out[NO_EMA] = out["ціна"][:, keep]
    out["names"][NO_EMA] = [out["names"]["ціна"][i] for i in keep]
    out["разом"] = np.hstack([out["клас"], out["ціна"]])
    out["names"]["разом"] = out["names"]["клас"] + out["names"]["ціна"]
    return out


def label_of(bag: dict, task: str) -> np.ndarray:
    """Мітка задачі на тій самій вибірці подій краю."""
    if task == "belong":
        return (bag["offset"] > 0).astype(int)
    if task == "updown":
        return (bag["kind"] > 0).astype(int)
    raise ValueError(f"невідома задача: {task}")


def fit(x: np.ndarray, y: np.ndarray, train: np.ndarray,
        seed: int = SEED) -> np.ndarray:
    from sklearn.ensemble import HistGradientBoostingClassifier
    model = HistGradientBoostingClassifier(
        max_iter=TREES, learning_rate=0.05, max_leaf_nodes=31,
        min_samples_leaf=50, l2_regularization=1.0, random_state=seed)
    model.fit(x[train], y[train])
    return model.predict_proba(x)[:, 1]


def score(bag: dict, kit: str, train: np.ndarray, val: np.ndarray,
          seed: int = SEED) -> dict:
    """Навчити на `train`, поміряти на `val`: AUC, точність, хід за зсувом.

    Хід за зсувом рахується так само, як у дослідженні 28: подія межі —
    це перша подія **до** півота, подія `+1` — перша **після** нього.
    """
    x, y = bag[kit], bag["y"]
    guess = fit(x, y, train, seed)
    hit = (guess[val] > 0.5) == (y[val] > 0)
    walk = []
    for offset in sorted(set(bag["offset"][val].tolist())):
        mark = val & (bag["offset"] == offset)
        walk.append({"offset": int(offset),
                     "side": "після" if offset > 0 else "до",
                     "distance": int(offset if offset > 0 else 1 - offset),
                     "events": int(mark.sum()),
                     "accuracy": float(((guess[mark] > 0.5)
                                        == (y[mark] > 0)).mean())})
    by_pair = {}
    for pair in sorted(set(bag["pair"][val].tolist())):
        mark = val & (bag["pair"] == pair)
        if len(set(y[mark].tolist())) < 2:
            continue
        by_pair[pair] = {
            "auc": auc(guess[mark & (y == 1)], guess[mark & (y == 0)]),
            "accuracy": float(((guess[mark] > 0.5) == (y[mark] > 0)).mean()),
            "events": int(mark.sum())}
    return {"auc": auc(guess[val & (y == 1)], guess[val & (y == 0)]),
            "accuracy": float(hit.mean()),
            "base": float(y[val].mean()),
            "n_train": int(train.sum()), "n_val": int(val.sum()),
            "by_offset": walk, "by_pair": by_pair}


def by_date(bag: dict) -> dict:
    """Розбиття за датою: навчання до 2026-08-14, замір після."""
    train, val = bag["t"] < VAL_FROM, bag["t"] >= VAL_FROM
    return {kit: score(bag, kit, train, val) for kit in SETS}


def by_coin(bag: dict) -> dict:
    """Відкладена монета: шість прогонів, у кожному одна монета не вчиться."""
    out = {}
    for kit in SETS:
        per_pair, values = {}, []
        for pair in sorted(set(bag["pair"].tolist())):
            val = bag["pair"] == pair
            one = score(bag, kit, ~val, val)
            per_pair[pair] = {"auc": one["auc"], "accuracy": one["accuracy"],
                              "events": one["n_val"]}
            values.append(one["auc"])
        out[kit] = {"auc_mean": float(np.mean(values)),
                    "auc_min": float(np.min(values)),
                    "auc_max": float(np.max(values)), "by_pair": per_pair}
    return out


def floor(bag: dict, shuffles: int = SHUFFLES, seed: int = SEED) -> dict:
    """Підлога: та сама модель на перемішаній мітці. Має дати 0.5."""
    train, val = bag["t"] < VAL_FROM, bag["t"] >= VAL_FROM
    rng = np.random.default_rng(seed)
    mixed = dict(bag)
    values = []
    for _ in range(shuffles):
        mixed["y"] = rng.permutation(bag["y"])
        values.append(score(mixed, "разом", train, val)["auc"])
    return {"auc_median": float(np.median(values)),
            "auc_max": float(np.max(values)), "shuffles": shuffles}


def singles(bag: dict) -> list:
    """Кожна величина сама по собі: AUC на val, усі — від сильних до слабких.

    Список повний навмисне: він малий, а питання «скільки дає саме ця
    величина» виникає після прогону, і переміряти заради нього весь етап
    було б марною роботою.
    """
    val = bag["t"] >= VAL_FROM
    y = bag["y"][val]
    found = []
    for index, name in enumerate(bag["names"]["разом"]):
        line = bag["разом"][val, index]
        good = np.isfinite(line)
        if good.sum() < 100 or len(set(y[good].tolist())) < 2:
            continue
        value = auc(line[good & (y == 1)], line[good & (y == 0)])
        found.append({"name": name, "auc": value, "gap": abs(value - 0.5)})
    found.sort(key=lambda one: -one["gap"])
    return found


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    parser.add_argument("--marks", type=int, default=MARKS)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--tasks", nargs="*", default=list(TASKS))
    args = parser.parse_args()

    result = {"pairs": args.pairs, "marks": args.marks, "window": args.window,
              "trees": TREES, "seed": SEED, "sets": list(SETS),
              "val_from": VAL_FROM,
              "tasks": {name: dict(TASKS[name], anchors={})
                        for name in args.tasks}}
    rows = [series(pair) for pair in args.pairs]
    for name in args.tasks:
        frame = TASKS[name]["frame"]
        for by in ANCHORS:
            bag = collect(rows, by, args.marks, args.window, frame)
            bag["y"] = label_of(bag, name)
            node = {"events": int(len(bag["y"])),
                    "base": float(bag["y"].mean()),
                    "columns": {kit: len(bag["names"][kit]) for kit in SETS},
                    "date": by_date(bag), "coin": by_coin(bag),
                    "singles": singles(bag)}
            if by == "close":
                node["floor"] = floor(bag)
            result["tasks"][name]["anchors"][by] = node

    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / "border_side.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    for name in args.tasks:
        task = result["tasks"][name]
        print(f"\n=== {task['title']} (рамка {task['frame']}) ===")
        for by in ANCHORS:
            node = task["anchors"][by]
            print(f"\nякір {by}: {node['events']} подій краю, "
                  f"база {node['base']:.3f}")
            print(f"  {'набір':8s} {'стовпців':>9s} {'AUC дата':>9s} "
                  f"{'точність':>9s} {'AUC монета':>11s}")
            for kit in SETS:
                one, two = node["date"][kit], node["coin"][kit]
                print(f"  {kit:8s} {node['columns'][kit]:9d} "
                      f"{one['auc']:9.3f} {one['accuracy']:9.3f} "
                      f"{two['auc_mean']:11.3f}")
        close = task["anchors"]["close"]
        print(f"  підлога на перемішаній мітці "
              f"{close['floor']['auc_median']:.3f}")
        walk = close["date"]["разом"]["by_offset"]
        for side in ("після", "до"):
            line = sorted((one for one in walk if one["side"] == side),
                          key=lambda one: one["distance"])
            cells = " ".join(f"{one['accuracy']:.3f}" for one in line)
            print(f"  подія {side:6s} півота: {cells}")


if __name__ == "__main__":
    main()
