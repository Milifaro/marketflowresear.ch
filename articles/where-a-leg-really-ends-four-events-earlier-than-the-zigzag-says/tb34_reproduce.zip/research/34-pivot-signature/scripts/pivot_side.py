"""Етап 4: чи каже клас, у який бік розворот.

`B = amp(d_down) − amp(d_up)` — перекид обʼємних відношень із боку
покупців на бік продавців. При дзеркалі `B` міняє знак, тому на вершині
він має бути додатний, на дні — відʼємний.

Суперник обовʼязковий: подія півота сама по собі має великий рух ціни в
бік розвороту, і цей рух лежить у тому самому класі (`d_price_avg`).
Тому міряються три величини:

| величина | що це |
| -------- | ----- |
| `B` | перекид обʼємних відношень |
| `−рух` | мінус власний рух ціни події, `−ln(close/open)` |
| `B\\|рух` | залишок `B` після регресії на ранг руху (і його квадрат) |

Запуск:
    python3 research/34-pivot-signature/scripts/pivot_side.py --anchor close

Вихід: results/pivot_side_<якір>.json
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from mirror import (PAIRS, RESULTS, SHUFFLES, anchor, auc, ranks, series,
                    shuffled_max, z_of_auc)

WINDOWS = (0, 1, 2, 3, 5, 8)


def prepare(row: dict, by: str) -> dict:
    B = (row["rank"][("d_down", "mean", "amp")]
         - row["rank"][("d_up", "mean", "amp")])
    move = np.log(row["close"] / row["open"])
    good = row["inleg"] & np.isfinite(B) & np.isfinite(move)
    rank_move = np.full(row["count"], np.nan)
    rank_move[good] = ranks(move[good])
    design = np.c_[np.ones(good.sum()), rank_move[good], rank_move[good] ** 2]
    beta = np.linalg.lstsq(design, B[good], rcond=None)[0]
    residual = np.full(row["count"], np.nan)
    residual[good] = B[good] - design @ beta
    return {"B": B, "−рух": -move, "B|рух": residual,
            "pivots": {anchor(row, i, k, by): k
                       for i, k in row["pivots"].items()}}


def measure(rows: list, by: str) -> dict:
    prepared = [(row, prepare(row, by)) for row in rows]
    table: dict = {}
    for window in WINDOWS:
        for name in ("B", "−рух", "B|рух"):
            top, bottom, per_pair = [], [], {}
            for row, kit in prepared:
                hi, lo = [], []
                for index, kind in kit["pivots"].items():
                    piece = kit[name][max(0, index - window):index + window + 1]
                    level = np.nanmean(piece) if np.isfinite(piece).any() else np.nan
                    if not np.isfinite(level):
                        continue
                    (hi if kind > 0 else lo).append(level)
                per_pair[row["pair"]] = auc(np.array(hi), np.array(lo))
                top += hi
                bottom += lo
            top, bottom = np.array(top), np.array(bottom)
            value = auc(top, bottom)
            labels = np.r_[np.ones(len(top)), np.zeros(len(bottom))]
            noise = shuffled_max(np.r_[top, bottom], labels, SHUFFLES)
            table[f"{name}·{window}"] = {
                "value": name, "window": window, "auc": value,
                "z": z_of_auc(value, len(top), len(bottom)),
                "noise_median": noise[0], "noise_95": noise[1],
                "n_top": len(top), "n_bottom": len(bottom),
                "by_pair": per_pair}
    return table


def matched(rows: list, by: str, neighbours: int = 20) -> dict:
    """Чесніший контроль за регресію: подія того самого **знакового** руху.

    Для кожного розвороту беруться `neighbours` подій тіла ноги з
    найближчим рангом руху ціни, і `B` півота (приведений до боку
    розвороту) порівнюється з їхнім `B`, приведеним так само.
    """
    diffs, pairs = [], {}
    for row in rows:
        kit = prepare(row, by)
        B = kit["B"]
        move = np.log(row["close"] / row["open"])
        good = row["inleg"] & np.isfinite(B) & np.isfinite(move)
        rank_move = np.full(row["count"], np.nan)
        rank_move[good] = ranks(move[good])
        body = good.copy()
        for index in kit["pivots"]:
            body[max(0, index - 5):index + 6] = False
        pool = np.where(body)[0]
        local = []
        for index, kind in kit["pivots"].items():
            if not np.isfinite(rank_move[index]):
                continue
            near = pool[np.argsort(np.abs(rank_move[pool]
                                          - rank_move[index]))[:neighbours]]
            local.append(B[index] * kind - np.nanmean(B[near]) * kind)
        pairs[row["pair"]] = float(np.mean(local))
        diffs += local
    diffs = np.array(diffs)
    return {"diff": float(diffs.mean()),
            "t": float(diffs.mean() / (diffs.std(ddof=1) / np.sqrt(len(diffs)))),
            "n": len(diffs), "by_pair": pairs,
            "share_positive": float((diffs > 0).mean())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--anchor", default="close",
                        choices=("none", "open", "close"))
    parser.add_argument("--pairs", nargs="*", default=list(PAIRS))
    args = parser.parse_args()

    rows = [series(pair) for pair in args.pairs]
    table = measure(rows, args.anchor)
    control = matched(rows, args.anchor)
    result = {"anchor": args.anchor, "pairs": args.pairs, "table": table,
              "matched": control}
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / f"pivot_side_{args.anchor}.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1))

    print(f"AUC «вершина проти дна», якір {args.anchor}")
    print(f"{'вікно':>6s} " + "".join(f"{n:>12s}" for n in ("B", "−рух", "B|рух"))
          + f"{'|z| B|рух':>11s}{'шум 95 %':>10s}")
    for window in WINDOWS:
        cells = [table[f"{n}·{window}"]["auc"] for n in ("B", "−рух", "B|рух")]
        row = table[f"B|рух·{window}"]
        print(f"{window:6d} " + "".join(f"{v:12.3f}" for v in cells)
              + f"{abs(row['z']):11.1f}{row['noise_95']:10.1f}")
    print("\nпо монетах, вікно 2:")
    for pair in args.pairs:
        print(f"  {pair:10s} B {table['B·2']['by_pair'][pair]:.3f}   "
              f"−рух {table['−рух·2']['by_pair'][pair]:.3f}   "
              f"B|рух {table['B|рух·2']['by_pair'][pair]:.3f}")
    print("\nпо монетах, вікно 0 (сама точка межі):")
    for pair in args.pairs:
        print(f"  {pair:10s} B {table['B·0']['by_pair'][pair]:.3f}   "
              f"−рух {table['−рух·0']['by_pair'][pair]:.3f}   "
              f"B|рух {table['B|рух·0']['by_pair'][pair]:.3f}")
    print(f"\nконтроль подією того самого руху: різниця B {control['diff']:+.3f}, "
          f"t {control['t']:+.1f}, вище в {100*control['share_positive']:.0f} % розворотів, "
          f"n {control['n']}")
    for pair, value in control["by_pair"].items():
        print(f"  {pair:10s} {value:+.3f}")
    print(f"\n{path}")


if __name__ == "__main__":
    main()
