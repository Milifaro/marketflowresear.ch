"""Мережа розділу 5: трансформер по осі подій із виходом у клітинки.

Дослідження: research/18-smooth-zigzag-x4c/ (розділи 4 і 5)
Правила: rules/03-models.md → Типи мереж

Крок послідовності — **одна подія** класу `клас210х210х4ц`, тобто чотири
числа. Середніх у події немає, тому контекст збирає сама увага: на вхід
іде вікно з K подій поспіль, `(K, 4)`, ціль — ціль **останньої** події
вікна.

Відмінність від `nets.WindowTransformer` дослідження 17 — дві:

    17   крок = подія (13 ЕМА × 4 = 52 числа), зчитування mean, вихід 1
    тут  крок = подія (4 числа),               зчитування flat, вихід 28

## Правило невтрачання даних

Жоден шар не може бути вужчим за те, що в нього заходить, і перевіряє це
**конструктор**, а не коментар:

- `width` менша за подію (4 числа) — помилка;
- зчитування `mean` тисне вікно з `K × width` до `width` — при K = 128 це
  у 128 разів. Воно береться лише явним `readout="mean"`, за
  замовчуванням стоїть `flat`.

Єдине допустиме стиснення — остання голова: відповідь скінченна,
`outputs` клітинок.

Ваги мають збігатись із формулами розділу 5
([`net_spec.py`](net_spec.py) → `steps_of`); це перевіряється тестом.
"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parent))

import net_spec  # noqa: E402

READOUTS = ("flat", "mean", "last")
SQUEEZING = ("mean", "last")     # зчитування, які втрачають вікно


class BinTransformer(nn.Module):
    """Увага по осі подій, вікно `(K, 4)`, вихід — `outputs` логітів."""

    def __init__(self, k: int, width: int = net_spec.WIDTH,
                 heads: int = net_spec.HEADS, layers: int = net_spec.LAYERS,
                 dropout: float = net_spec.DROPOUT,
                 outputs: int = net_spec.KNOWN,
                 features: int = net_spec.FEATURES, readout: str = "flat"):
        super().__init__()
        if k < 1:
            raise ValueError("K має бути >= 1")
        if width % heads:
            raise ValueError("width має ділитись на heads")
        if width < features:
            raise ValueError(f"width {width} вужчий за подію "
                             f"({features} числа): частина даних не дійшла б "
                             "до мережі")
        if readout not in READOUTS:
            raise ValueError(f"невідоме зчитування: {readout}")
        if readout in SQUEEZING and k > 1:
            raise ValueError(f"зчитування {readout} тисне вікно з {k * width} "
                             f"чисел до {width}: дані втрачаються "
                             "(розділ 5 → правило невтрачання даних)")
        self.k = k
        self.features = features
        self.readout = readout
        self.into = nn.Linear(features, width)
        self.place = nn.Parameter(torch.zeros(1, k, width))
        layer = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=width * 4,
            dropout=dropout, batch_first=True, norm_first=True)
        self.net = nn.TransformerEncoder(layer, num_layers=layers,
                                         enable_nested_tensor=False)
        self.head = nn.Linear(width if readout in SQUEEZING else k * width,
                              outputs)

    def forward(self, x):
        out = self.net(self.into(x.reshape(x.shape[0], self.k, self.features))
                       + self.place)                     # (N, K, width)
        if self.readout == "mean":
            return self.head(out.mean(dim=1))
        if self.readout == "last":
            return self.head(out[:, -1])
        return self.head(out.reshape(out.shape[0], -1))   # flat: усі кроки


def factory(k: int, readout: str = "flat"):
    """Фабрика під одне K: решта ручок приходить конфігурацією прогону."""
    def make(**params):
        return BinTransformer(k=k, readout=readout, **params)
    return make


def parameters_of(model: nn.Module) -> int:
    return int(sum(p.numel() for p in model.parameters()))
