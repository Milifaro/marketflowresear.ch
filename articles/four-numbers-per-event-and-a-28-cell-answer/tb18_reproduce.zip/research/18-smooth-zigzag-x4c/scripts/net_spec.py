"""Параметри трансформера: вхід, шари, ваги, правило невтрачання даних.

Дослідження: research/18-smooth-zigzag-x4c/ (розділ 5)

Мережа читає **вікно з K подій** класу `клас210х210х4ц` — по чотири
числа на подію. Крок послідовності тут одна **подія**, а не період ЕМА:
подія цього класу і є чотири числа, середніх у ній немає, тому контекст
збирає сама увага, а не порахований наперед набір ЕМА.

Ваги рахуються формулами, а не збиранням моделі: розділ описує мережу,
яку ще треба побудувати, і числа мають бути перевіряні на папері.

## Ваги шару уваги

`nn.TransformerEncoderLayer(d_model=w, nhead=h, dim_feedforward=f)`:

    увага      4w² + 4w      (in_proj 3w x w + 3w, out_proj w x w + w)
    linear1    fw + f
    linear2    wf + w
    norm1/2    4w
    ---------------------------
    разом      4w² + 2wf + f + 9w

## Правило невтрачання даних

Жоден шар не може бути вужчим за те, що в нього заходить. Перевіряється
по кроках і потрапляє у звіт полем `keeps`: `False` там, де чисел на
виході менше, ніж на вході. Єдине допустиме стиснення — остання голова,
бо відповідь скінченна.

Вихід: results/net_2_3.json

Запуск:
    python3 research/18-smooth-zigzag-x4c/scripts/net_spec.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x210x4c as klass  # noqa: E402
import correlate  # noqa: E402

PAIRS = ("BTC_USDT_fill", "ETH_USDT_fill", "SOL_USDT_fill",
         "XRP_USDT_fill", "BNB_USDT_fill", "DOGE_USDT_fill")

RESULTS = RESEARCH_DIR / "results"
FEATURES = len(klass.FEATURES)   # 4: подія класу і є ці чотири числа
WIDTH, HEADS, LAYERS = 64, 4, 2
DROPOUT = 0.1
FEED = WIDTH * 4                 # dim_feedforward
SIZES = (128, 256, 512, 1024)
KNOWN = 28                       # клітинок виходу (розділ 4)
SOURCE = "research/17-zigzag23-transformer/results/picked_2_3.json"


def layer_weights(width: int = WIDTH, feed: int = FEED) -> int:
    """Ваги одного шару енкодера: увага + два лінійних + дві норми."""
    return 4 * width ** 2 + 2 * width * feed + feed + 9 * width


def steps_of(k: int, width: int = WIDTH, layers: int = LAYERS,
             outputs: int = KNOWN, features: int = FEATURES,
             feed: int = FEED) -> list:
    """Шар за шаром: що заходить, що виходить, скільки ваг."""
    rows = [
        {"step": "вхід: вікно з K подій",
         "shape": f"({k}, {features})", "into": k * features,
         "out": k * features, "weights": 0},
        {"step": f"Linear({features} → {width}) на кожну подію окремо",
         "shape": f"({k}, {width})", "into": k * features,
         "out": k * width, "weights": features * width + width},
        {"step": "позиція події у вікні: вчений параметр",
         "shape": f"({k}, {width})", "into": k * width,
         "out": k * width, "weights": k * width},
    ]
    for index in range(layers):
        rows.append({
            "step": f"шар уваги {index + 1} з {layers}: "
                    f"{HEADS} голови, матриця {k} × {k}",
            "shape": f"({k}, {width})", "into": k * width,
            "out": k * width, "weights": layer_weights(width, feed)})
    rows.append({"step": "зчитування flat: усі кроки як є",
                 "shape": f"({k * width},)", "into": k * width,
                 "out": k * width, "weights": 0})
    rows.append({"step": f"голова Linear({k * width} → {outputs})",
                 "shape": f"({outputs},)", "into": k * width,
                 "out": outputs, "weights": k * width * outputs + outputs})
    for row in rows:
        row["keeps"] = row["out"] >= row["into"]
    return rows


def sizes_of(sizes=SIZES, width: int = WIDTH, layers: int = LAYERS,
             outputs: int = KNOWN, seconds: int = klass.EVENT_LENGTH) -> list:
    """Одна довжина вікна — один рядок: ваги, увага, зчитування."""
    rows = []
    for k in sizes:
        steps = steps_of(k, width, layers, outputs)
        rows.append({
            "k": k,
            "minutes": round(k * seconds / 60, 1),
            "numbers": k * FEATURES,
            "attention": k * k,
            "readout": k * width,
            "squeeze_mean": round(k * width / width, 1),
            "parameters": sum(row["weights"] for row in steps),
        })
    return rows


def build(width: int = WIDTH, heads: int = HEADS, layers: int = LAYERS,
          outputs: int = KNOWN, sizes=SIZES, log=print) -> dict:
    """Опис мережі: вхід, шари, ваги, ручки навчання."""
    if width % heads:
        raise SystemExit("width має ділитись на heads")
    if width < FEATURES:
        raise SystemExit(f"width {width} вужчий за подію ({FEATURES} числа)")
    steps = steps_of(sizes[-1], width, layers, outputs)
    rows = sizes_of(sizes, width, layers, outputs)
    log(f"[1/1] {FEATURES} фічі на подію, ширина {width}, {layers} шари, "
        f"{heads} голови, вихід {outputs} · ваг від "
        f"{rows[0]['parameters']:,} (K={rows[0]['k']}) до "
        f"{rows[-1]['parameters']:,} (K={rows[-1]['k']})".replace(",", " "))

    return {
        "step": "параметри трансформера по осі подій",
        "class": "клас210х210х4ц",
        "features": list(klass.FEATURES),
        "feature_count": FEATURES,
        "event_seconds": klass.EVENT_LENGTH,
        "input": (f"вікно (K, {FEATURES}): K подій поспіль по {FEATURES} "
                  "фічі, ціль — ціль останньої події вікна"),
        "why": ("подія класу і є чотири числа, середніх у ній немає — "
                "контекст збирає увага, а не порахований наперед набір ЕМА"),
        "width": width,
        "heads": heads,
        "layers": layers,
        "feed": width * 4,
        "dropout": DROPOUT,
        "outputs": outputs,
        "readout": "flat",
        "pairs": [pair.replace("_fill", "") for pair in PAIRS],
        "sizes": list(sizes),
        "steps": steps,
        "steps_k": sizes[-1],
        "rows": rows,
        "knobs": [
            {"knob": "ширина", "value": str(width), "from": SOURCE},
            {"knob": "голови", "value": str(heads), "from": SOURCE},
            {"knob": "шари", "value": str(layers), "from": SOURCE},
            {"knob": "dim_feedforward", "value": f"{width * 4} (ширина × 4)",
             "from": "усталене для енкодера"},
            {"knob": "dropout", "value": str(DROPOUT), "from": SOURCE},
            {"knob": "norm_first", "value": "True",
             "from": "усталене для енкодера"},
            {"knob": "lr", "value": "3e-4", "from": SOURCE},
            {"knob": "оптимізатор", "value": "Adam", "from": SOURCE},
            {"knob": "батч", "value": "до 256, менший на довшому вікні",
             "from": "памʼять уваги: batch × heads × K²"},
            {"knob": "seed", "value": "0", "from": "train.SEED"},
            {"knob": "бюджет", "value": "60 епох по 20 000 вікон або 40 хв",
             "from": "train_all.EPOCHS, WINDOWS, MINUTES"},
            {"knob": "рання зупинка", "value": "немає: валідації немає",
             "from": "розбиття train | test за датою"},
            {"knob": "скейлер", "value": "немає: фічі вже безрозмірні [−1, 1]",
             "from": "правило невтрачання даних"},
            {"knob": "K", "value": ", ".join(str(k) for k in sizes),
             "from": "перебір"},
            {"knob": "вибір K", "value": "збіги на краях на test",
             "from": "валідації немає"},
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--width", type=int, default=WIDTH)
    parser.add_argument("--heads", type=int, default=HEADS)
    parser.add_argument("--layers", type=int, default=LAYERS)
    parser.add_argument("--outputs", type=int, default=KNOWN)
    parser.add_argument("--target", default="2.3")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.width, args.heads, args.layers, args.outputs)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"net_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
