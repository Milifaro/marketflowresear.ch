"""Клітинки виходу: `[-1, 1]` на 28 клітинок під перехресну ентропію.

Дослідження: research/18-smooth-zigzag-x4c/ (розділ 4)

Вихід у одне число під MSE завжди сповзає в **умовне середнє**: сказати
край і промазати дорожче, ніж промовчати. Розділи 1-3 показують, що звʼязку у
чотирьох фічах небагато, а прогони моделі під MSE давали «сказала: 0».
Тому питання міняється з «яке
число» на «в якій клітинці», і крайня клітинка дістає власну
ймовірність, на яку вже можна ставити поріг.

## Межі

Дві крайні клітинки закріплені межею зони (`band = 0.20`), тому крайня
клітинка **дослівно дорівнює зоні півота за значенням**. Решта 26 ріжуться
по квантилю цілі — приблизно по 3.5 % подій на клітинку.

Рівні клітинки по 0.2 давали перекіс 6 : 1 (22 % подій у середині проти
3.6 % на краю) — перехресна ентропія вчилась би переважно казати
«середина». Квантиль лишає перекіс 1.5 : 1.

Межі **рахуються з цілі train** — з усіх шести монет, з подій до межі
розбиття (`train_all.CUT`), — а не зашиваються числами: на іншому наборі
монет чи іншому згладжуванні вони інші.

## Мʼяка мітка

Клітинки різної ширини, тому гаус по **значенню** розмазав би подію на
сім вузьких клітинок у середині й не вилазив би за одну широку на краю.
Розмазування йде по **номерах**: своя клітинка `OWN`, сусідні по `SIDE`.
Вага сусіда, якого немає (край ряду), віддається своїй клітинці.

Вихід: results/bins_2_3.json

Запуск:
    python3 research/18-smooth-zigzag-x4c/scripts/bins.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import correlate  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MIDDLE = 26                      # клітинок між закріпленими краями
OWN, SIDE = 0.70, 0.15           # мʼяка мітка: своя клітинка і сусідні
DIGITS = 3


def edges_of(y: np.ndarray, band: float = correlate.MODEL_BAND,
             middle: int = MIDDLE) -> np.ndarray:
    """Межі клітинок: краї по зоні, середина по квантилю цілі."""
    edge = 1.0 - band
    inside = y[np.isfinite(y) & (np.abs(y) < edge)]
    steps = np.quantile(inside, np.linspace(0.0, 1.0, middle + 1))
    steps[0], steps[-1] = -edge, edge
    return np.concatenate(([-1.0], np.round(steps, DIGITS), [1.0]))


def cells_of(y: np.ndarray, edges: np.ndarray) -> list:
    """Опис кожної клітинки: межі, ширина, центр, скільки подій усередині."""
    good = y[np.isfinite(y)]
    rows = []
    for index in range(len(edges) - 1):
        low, high = float(edges[index]), float(edges[index + 1])
        last = index == len(edges) - 2
        inside = (good >= low) & (good <= high if last else good < high)
        rows.append({
            "cell": index + 1,
            "from": round(low, DIGITS),
            "to": round(high, DIGITS),
            "width": round(high - low, DIGITS),
            "centre": round((low + high) / 2, DIGITS),
            "events": int(inside.sum()),
            "share": round(float(inside.mean()), 5),
            "zone": index == 0 or last,
        })
    return rows


def label(cell: int, count: int, own: float = OWN,
          side: float = SIDE) -> list:
    """Мʼяка мітка по номерах клітинок; вага краю вертається своїй."""
    out = np.zeros(count)
    out[cell] = own
    for step in (-1, 1):
        near = cell + step
        if 0 <= near < count:
            out[near] = side
        else:
            out[cell] += side
    return [round(float(value), 4) for value in out]


def build(pairs=None, threshold: str = "2.3",
          way: str = correlate.WAY, middle: int = MIDDLE,
          band: float = correlate.MODEL_BAND, window: int | None = None,
          cut: str | None = None, root: Path | None = None,
          log=print) -> dict:
    """Клітинки виходу на цілі train: усі монети, події до межі розбиття."""
    import train_all                      # пізній імпорт: train_all бере bins

    window = correlate.MODEL_WINDOW if window is None else window
    pairs = train_all.PAIRS if pairs is None else tuple(pairs)
    cut = train_all.CUT if cut is None else cut
    data = train_all.pool(pairs, threshold, way, root, lambda *args: None)
    y = data["y"][train_all.split_of(data["stamps"],
                                     train_all.cut_stamp(cut)) == 0]
    edges = edges_of(y, band, middle)
    cells = cells_of(y, edges)
    count = len(cells)
    shares = [item["share"] for item in cells]
    log(f"[1/1] {len(pairs)} монети до {cut}: "
        f"{int(np.isfinite(y).sum())} подій з ціллю, "
        f"{count} клітинок, від {min(shares):.2%} до {max(shares):.2%} "
        f"подій на клітинку, перекіс {max(shares) / min(shares):.2f} : 1")

    return {
        "pairs": [item.replace("_fill", "") for item in pairs],
        "cut": cut,
        "threshold": threshold,
        "step": "клітинки виходу: [-1, 1] під перехресну ентропію",
        "way": way,
        "target": (f"зігзаг {threshold} нормований, ема{data['period']}, "
                   f"нога розподіл, згладжено {way}"),
        "on": "ціль train: усі монети, події до межі розбиття",
        "zone": {"band": band, "window": window},
        "cells": count,
        "middle": middle,
        "edges": [round(float(value), DIGITS) for value in edges],
        "rows": cells,
        "events": int(len(y)),
        "with_target": int(np.isfinite(y).sum()),
        "share_min": min(shares),
        "share_max": max(shares),
        "skew": round(max(shares) / max(min(shares), 1e-9), 2),
        "soft": {"own": OWN, "side": SIDE,
                 "note": ("розмазування по номерах клітинок; вага сусіда, "
                          "якого немає, вертається своїй клітинці"),
                 "example": {"y": -0.93, "cell": 1,
                             "label": label(0, count)}},
        "loss": {"name": "перехресна ентропія по клітинках",
                 "formula": "L = − Σ qᵢ · log softmax(z)ᵢ",
                 "note": ("ваги класів не додаються: клітинки вже майже "
                          "рівні за наповненням. Розділ 6 додає до неї "
                          "ціну помилки в клітинках і штраф за розмах")},
        "read": [
            {"what": "зона нижнього півота", "how": "p₁ ≥ поріг"},
            {"what": "зона верхнього півота", "how": f"p{count} ≥ поріг"},
            {"what": "підходимо до низу / верху",
             "how": f"p₁ + p₂ / p{count - 1} + p{count}"},
            {"what": "число ноги назад у [−1, 1]",
             "how": "ŷ = Σ pᵢ · центрᵢ"},
            {"what": "впевненість",
             "how": f"1 − ентропія(p) / log {count}"},
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", default=None)
    parser.add_argument("--target", default="2.3")
    parser.add_argument("--way", default=correlate.WAY)
    parser.add_argument("--middle", type=int, default=MIDDLE)
    parser.add_argument("--cut", default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    pairs = (tuple(item.strip() for item in args.pairs.split(","))
             if args.pairs else None)
    report = build(pairs, args.target, args.way, args.middle,
                   cut=args.cut)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"bins_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
