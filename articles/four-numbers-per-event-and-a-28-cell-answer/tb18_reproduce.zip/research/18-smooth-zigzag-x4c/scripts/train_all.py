"""Навчання на всіх монетах: вихід у 28 клітинок, вікно з K подій.

Дослідження: research/18-smooth-zigzag-x4c/ (розділ 6)
Правила: rules/03-models.md → Розбиття даних, Правила навчання

Мережа — розділ 5 ([`net.py`](net.py)): трансформер по осі подій, вхід
`(K, 4)`, зчитування `flat`, голова `Linear(K · 64 → 28)`.

## Дані

**Усі шість пар** (`PAIRS`), клас `клас210х210х4ц`, ціль — згладжений
`сернога` зігзаг 2.3 % на ема90. Пари зшиваються в один ряд подія за
подією; кожна подія памʼятає свою монету, і вікно ніколи не переходить
з монети на монету.

**Пропуски не викидаються.** Подія, у якій фіча не порахувалась (ділення
на нуль), заходить у мережу нулем: нуль тут і є «немає перекосу». Раніше
одна така подія викидала все вікно й рвала видачу на клапті.

**Розриви в часі не викидаються.** Вікно — це K подій **поспіль за
номером**, а не за часом: збір даних зупинявся, і вимога рівних 210 с
лишала найдовший суцільний відрізок у 411 подій, тобто вікна 512 і 1024
не існували б взагалі.

## Розбиття

    події < 10.08  ->  train        події >= 10.08  ->  test

Одна дата на всі монети, вікно цілком лежить по один її бік. Валідації
немає: навчання йде фіксований бюджет, і на test модель не
підглядає — там міряється вже навчена.

## Штраф

Перехресна ентропія по клітинках (розділ 4) плюс ціна помилки, плюс
штраф за розмах дослідження 12:

    L = CE + очікувана ціна + WMSE + λ·(σ_цілі − σ_прогнозу)²

Ціна помилки — матриця `C[справжня, сказана]` (`cost_matrix`): своя
клітинка 0, звичайна помилка 1, **прогавлений край** `MISS`, **хибний
край** `FALSE`, **протилежний край** `WRONG`.

## Метрики

Тільки сигнали країв — клітинка 1 (низ) і клітинка 28 (верх):
скільки сигналів у цілі, скільки сказала модель, скільки збіглось і
на скільки подій у середньому вона промахнулась.

Вихід: results/train_all_2_3.json

Запуск:
    python3 research/18-smooth-zigzag-x4c/scripts/train_all.py
    python3 research/18-smooth-zigzag-x4c/scripts/train_all.py --sizes 128
    python3 research/18-smooth-zigzag-x4c/scripts/train_all.py --add --sizes 1024
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "16-zigzag23-wattn" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import bins  # noqa: E402
import correlate  # noqa: E402
import net as net_module  # noqa: E402
import net_spec  # noqa: E402
from class210ema4 import ema  # noqa: E402
from train import SEED, device_name, number, weights  # noqa: E402
from walk_forward import human  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

PAIRS = ("BTC_USDT_fill", "ETH_USDT_fill", "SOL_USDT_fill",
         "XRP_USDT_fill", "BNB_USDT_fill", "DOGE_USDT_fill")
CUT = "2026-08-10"               # межа train | test, UTC
SIZES = (128, 256, 512, 1024)    # довжини вікна цього розділу

# Ціна помилки в клітинках: своя 0, звичайна 1.
MISS = 3.0                       # ціль на краю, сказала середину
FALSE = 6.0                      # ціль у середині, сказала край
WRONG = 12.0                     # сказала протилежний край

ALPHA, BETA = 3.0, 2.0           # ваговий MSE, ручки дослідження 16
LAMBDA = 1.0                     # ціна розмаху (losses.LAMBDA)

LR = 3e-4
BATCH = 256                      # стеля батча; довше вікно бере менший
MIN_BATCH = 16
# Памʼять уваги росте як batch × heads × K². Бюджет на матрицю уваги
# заміряний на цій машині: більший батч на K = 1024 уже не влазить.
ATTENTION_BUDGET = 256 * 256 * 128
READ_BATCH = 512                 # батч для читання видачі (без градієнтів)
WINDOWS = 20_000                 # вікон train на епоху, однаково для всіх K
EPOCHS = 60                      # стеля епох
MINUTES = 40.0                   # стеля часу на одне K
DIGITS = 4


# ---------- дані ----------

def cut_stamp(day: str = CUT) -> int:
    """Межа розбиття як timestamp UTC: `2026-08-10` -> секунди."""
    when = dt.datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
    return int(when.timestamp())


def pool(pairs=PAIRS, threshold: str = "2.3", way: str = correlate.WAY,
         root: Path | None = None, log=print) -> dict:
    """Усі монети одним рядом: фічі, ціль, час, ціна, півоти, зони.

    Пропуск у фічі стає нулем (`nan_to_num`). Кожна подія памʼятає номер
    своєї монети, тому вікно з неї не вийде.
    """
    correlate.widen()
    band, window = correlate.MODEL_BAND, correlate.MODEL_WINDOW
    coins, x, y, stamps, price, price_ema, coin = [], [], [], [], [], [], []
    marks, zones, start, holes = [], [], 0, 0
    for index, pair in enumerate(pairs):
        data = correlate.data_of(pair, threshold, way, root, band, window)
        raw = np.asarray(data["x"], dtype=np.float32)
        holes += int((~np.isfinite(raw)).any(axis=1).sum())
        smooth_price = ema(data["price"], data["period"])
        pivots = zigzag(smooth_price, THRESHOLDS[threshold])
        count = len(data["x"])
        coins.append({
            "coin": index, "pair": pair, "events": count,
            "from": start, "to": start + count,
            "from_utc": human(int(data["stamps"][0])),
            "to_utc": human(int(data["stamps"][-1])),
            "period": data["period"], "legs": data["legs"],
            "zones": len(data["zones"]),
            "zone_events": data["zone_events"],
            "pivots": [int(item.index) + start for item in pivots],
        })
        x.append(np.nan_to_num(raw, nan=0.0))
        y.append(np.asarray(data["y"], dtype=np.float64))
        stamps.append(np.asarray(data["stamps"], dtype=np.int64))
        price.append(np.asarray(data["price"], dtype=np.float64))
        price_ema.append(np.asarray(smooth_price, dtype=np.float64))
        coin.append(np.full(count, index, dtype=np.int16))
        marks.append(pivots)
        zones.append(data["zones"])
        start += count
        log(f"      {pair}: {count} подій, {len(pivots)} півотів, "
            f"зона {data['zone_events']}")
    return {"x": np.concatenate(x), "y": np.concatenate(y),
            "stamps": np.concatenate(stamps), "price": np.concatenate(price),
            "ema": np.concatenate(price_ema), "coin": np.concatenate(coin),
            "coins": coins, "marks": marks, "zones": zones,
            "band": band, "window": window, "holes": holes,
            "period": coins[0]["period"], "way": way}


def split_of(stamps: np.ndarray, cut: int) -> np.ndarray:
    """0 — подія train (до межі), 1 — подія test (від межі)."""
    return (np.asarray(stamps) >= cut).astype(np.int8)


def window_ends(coin: np.ndarray, side: np.ndarray, y: np.ndarray,
                k: int) -> tuple[np.ndarray, np.ndarray]:
    """Кінці вікон з K подій поспіль: train і test.

    Вікно цілком в одній монеті і цілком по один бік межі; у події
    вікна має бути ціль. Розриви в часі всередині вікна не заважають —
    події беруться підряд за номером.
    """
    n = len(coin)
    ends = np.arange(k - 1, n)
    starts = ends - (k - 1)
    ends = ends[(coin[ends] == coin[starts]) & (side[ends] == side[starts])]
    ends = ends[np.isfinite(y[ends])]
    return ends[side[ends] == 0], ends[side[ends] == 1]


def stack(x: np.ndarray, ends: np.ndarray, k: int) -> np.ndarray:
    """Вікна `(N, K, 4)`: K подій поспіль, остання — подія вікна.

    Події беруться як є: жодного обрізання, усереднення чи зміни
    значень — рівно ті самі рядки датасету у тому самому порядку.
    """
    offsets = np.arange(-(k - 1), 1)
    return x[ends[:, None] + offsets[None, :]]


# ---------- клітинки ----------

def cell_index(y: np.ndarray, edges: np.ndarray) -> np.ndarray:
    """Номер клітинки кожної події, 0-базований; NaN дає 0."""
    values = np.clip(np.nan_to_num(y, nan=0.0), -1.0, 1.0)
    return np.searchsorted(np.asarray(edges)[1:-1], values, side="right")


def soft_matrix(count: int, own: float = bins.OWN,
                side: float = bins.SIDE) -> np.ndarray:
    """Мʼяка мітка на кожну клітинку: рядок `i` — мітка клітинки `i`."""
    return np.array([bins.label(cell, count, own, side)
                     for cell in range(count)], dtype=np.float32)


def centres_of(rows: list) -> np.ndarray:
    return np.array([row["centre"] for row in rows], dtype=np.float32)


def cost_matrix(count: int, miss: float = MISS, false: float = FALSE,
                wrong: float = WRONG) -> np.ndarray:
    """Ціна помилки `C[справжня, сказана]`.

    Своя клітинка нічого не коштує, звичайна помилка коштує 1,
    прогавлений край — `miss`, хибний край — `false`, протилежний
    край — `wrong`. Порядок цін і є постановка: сказати край дарма
    дорожче, ніж його прогавити.
    """
    edge = (0, count - 1)
    cost = np.ones((count, count), dtype=np.float32)
    np.fill_diagonal(cost, 0.0)
    for true in range(count):
        for said in range(count):
            if true == said:
                continue
            if true in edge and said in edge:
                cost[true, said] = wrong
            elif true in edge:
                cost[true, said] = miss
            elif said in edge:
                cost[true, said] = false
    return cost


# ---------- штраф ----------

def loss_of(logits, labels, true, centres, cost_rows, lam: float = LAMBDA,
            alpha: float = ALPHA, beta: float = BETA):
    """`L = CE + очікувана ціна + WMSE + λ·(σ_цілі − σ_прогнозу)²`.

    `cost_rows` — рядки матриці цін під справжні клітинки батча, тому
    очікувана ціна це просто `Σ p · C[справжня]`.
    """
    import torch

    log_p = torch.log_softmax(logits, 1)
    probs = log_p.exp()
    ce = -(labels * log_p).sum(1).mean()
    price = (probs * cost_rows).sum(1).mean()
    pred = probs @ centres
    w = weights(true, alpha, beta)
    wmse = (w * (pred - true) ** 2).sum() / w.sum()
    spread = (true.std(unbiased=False) - pred.std(unbiased=False)) ** 2
    return ce + price + wmse + lam * spread, ce


def batch_for(k: int, batch: int = BATCH) -> int:
    """Батч під довжину вікна: памʼять уваги росте як batch × K²."""
    return int(max(MIN_BATCH, min(batch, ATTENTION_BUDGET // max(k * k, 1))))


# ---------- навчання ----------

def fit(k: int, x: np.ndarray, labels: np.ndarray, y: np.ndarray,
        centres: np.ndarray, cost: np.ndarray, cells: np.ndarray,
        ends: np.ndarray, params: dict, epochs: int, lr: float, batch: int,
        seed: int, minutes: float, per_epoch: int, log=print):
    """Один прогін: фіксований бюджет епох і часу, валідації немає.

    Вікна не матеріалізуються: на пристрої лежить сам ряд подій, а батч
    збирається індексами. Інакше `(N, 1024, 4)` не влізло б у памʼять.
    """
    import torch

    device = device_name()
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = net_module.BinTransformer(k=k, outputs=len(centres),
                                      **params).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    flat = torch.tensor(x, device=device)
    soft = torch.tensor(labels, device=device)
    truth = torch.tensor(y.astype(np.float32), device=device)
    price = torch.tensor(cost, device=device)
    middles = torch.tensor(centres, device=device)
    where = torch.tensor(cells.astype(np.int64), device=device)
    offsets = torch.arange(-(k - 1), 1, device=device)
    pool_ends = torch.tensor(ends.astype(np.int64), device=device)

    started, curve, epoch = time.time(), [], 0
    for epoch in range(1, epochs + 1):
        model.train()
        picked = pool_ends[torch.randperm(len(pool_ends),
                                          device=device)[:per_epoch]]
        total, seen, entropy = 0.0, 0, 0.0
        for step in range(0, len(picked), batch):
            index = picked[step:step + batch]
            window = flat[index[:, None] + offsets[None, :]]
            loss, ce = loss_of(model(window), soft[where[index]],
                               truth[index], middles, price[where[index]])
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += float(loss.detach()) * len(index)
            entropy += float(ce.detach()) * len(index)
            seen += len(index)
        curve.append({"epoch": epoch, "loss": round(total / max(seen, 1), 5),
                      "entropy": round(entropy / max(seen, 1), 5),
                      "seconds": round(time.time() - started, 1)})
        if epoch % 5 == 0 or epoch == 1:
            log(f"        K={k}: епоха {epoch}, штраф {curve[-1]['loss']:.5f}, "
                f"ентропія {curve[-1]['entropy']:.5f}, "
                f"{curve[-1]['seconds']:.0f} с")
        if (time.time() - started) / 60 >= minutes:
            log(f"        K={k}: стеля часу {minutes} хв на епосі {epoch}")
            break
    return model, device, curve, round(time.time() - started, 1), epoch


def logits_of(model, x: np.ndarray, ends: np.ndarray, k: int, device,
              batch: int = READ_BATCH) -> np.ndarray:
    """Логіти на заданих кінцях вікон, батчами і без градієнтів."""
    import torch

    model.eval()
    flat = torch.tensor(x, device=device)
    offsets = torch.arange(-(k - 1), 1, device=device)
    out = []
    with torch.no_grad():
        for step in range(0, len(ends), batch):
            index = torch.tensor(ends[step:step + batch].astype(np.int64),
                                 device=device)
            window = flat[index[:, None] + offsets[None, :]]
            out.append(model(window).cpu().numpy())
    if not out:
        return np.empty((0, model.head.out_features), dtype=np.float32)
    return np.concatenate(out)


def probs_of(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


# ---------- метрики: тільки сигнали країв ----------

def gap_to(said: np.ndarray, real: np.ndarray, coin: np.ndarray) -> float | None:
    """Середня відстань промаху в подіях до найближчого справжнього сигналу.

    Береться по кожній монеті окремо: сусідня монета не рахується
    сусідньою подією. Сигнал моделі, у монеті якого справжніх сигналів
    немає взагалі, у середнє не входить.
    """
    gaps = []
    for number_ in np.unique(coin[said]) if len(said) else []:
        here = np.sort(real[coin[real] == number_])
        mine = said[coin[said] == number_]
        if not len(here) or not len(mine):
            continue
        place = np.searchsorted(here, mine)
        left = here[np.clip(place - 1, 0, len(here) - 1)]
        right = here[np.clip(place, 0, len(here) - 1)]
        gaps.append(np.minimum(np.abs(mine - left), np.abs(mine - right)))
    if not gaps:
        return None
    return round(float(np.concatenate(gaps).mean()), 1)


def signals(ends: np.ndarray, true_cells: np.ndarray, said_cells: np.ndarray,
            coin: np.ndarray, count: int) -> list:
    """Сигнали країв: скільки в цілі, скільки сказала, скільки збіглось."""
    rows = []
    for cell, title in ((0, "1 · низ"), (count - 1, f"{count} · верх")):
        real = ends[true_cells == cell]
        said = ends[said_cells == cell]
        hit = ends[(true_cells == cell) & (said_cells == cell)]
        wrong = said[~np.isin(said, hit)]
        rows.append({
            "cell": cell + 1,
            "title": title,
            "real": int(len(real)),
            "said": int(len(said)),
            "hits": int(len(hit)),
            "gap": gap_to(wrong, real, coin),
        })
    return rows


# ---------- звіт ----------

def coin_series(data: dict, side: np.ndarray) -> list:
    """Відрізок test кожної монети рядами: час, ціна, ціль, півоти, зони."""
    stamps, price, y = data["stamps"], data["price"], data["y"]
    out = []
    for item, marks, zones in zip(data["coins"], data["marks"], data["zones"]):
        piece = np.arange(item["from"], item["to"])
        piece = piece[side[piece] == 1]
        low, high = int(stamps[piece[0]]), int(stamps[piece[-1]])
        out.append({
            "coin": item["coin"],
            "pair": item["pair"].replace("_fill", ""),
            "events": int(len(piece)),
            "from": int(piece[0]),
            "to": int(piece[-1]) + 1,
            "from_utc": human(low),
            "to_utc": human(high),
            "t": [int(value) for value in stamps[piece]],
            "price": [round(float(value), 2) for value in price[piece]],
            "y": [None if not np.isfinite(value) else round(float(value), DIGITS)
                  for value in y[piece]],
            "pivots": [{"t": int(stamps[mark.index + item["from"]]),
                        "ema": round(float(data["ema"][mark.index
                                                       + item["from"]]), 2),
                        "kind": mark.kind}
                       for mark in marks
                       if low <= int(stamps[mark.index + item["from"]]) <= high],
            "zones": [zone for zone in zones
                      if zone["to"] >= low and zone["from"] <= high],
        })
    return out


def series_of(chunks: list, ends: np.ndarray, pred: np.ndarray,
              said: np.ndarray, probs: np.ndarray) -> list:
    """Видача моделі по монетах: місце події, число і ймовірності країв.

    `low` і `high` — ймовірності клітинок 1 і 28, тобто зон нижнього й
    верхнього півота. Це і є те, з чого береться сигнал.
    """
    out = []
    for chunk in chunks:
        inside = (ends >= chunk["from"]) & (ends < chunk["to"])
        at = ends[inside] - chunk["from"]
        out.append({
            "coin": chunk["coin"],
            "at": [int(value) for value in at],
            "pred": [round(float(value), DIGITS) for value in pred[inside]],
            "said": [int(value) + 1 for value in said[inside]],
            "low": [round(float(value), DIGITS)
                    for value in probs[inside, 0]],
            "high": [round(float(value), DIGITS)
                     for value in probs[inside, -1]],
        })
    return out


def save(path: Path | None, report: dict) -> None:
    """Звіт на диск після кожного K: вкладка показує те, що вже готове."""
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")


def build(pairs=PAIRS, threshold: str = "2.3", way: str = correlate.WAY,
          sizes=SIZES, day: str = CUT, epochs: int = EPOCHS, lr: float = LR,
          batch: int = BATCH, seed: int = SEED, minutes: float = MINUTES,
          per_epoch: int = WINDOWS, miss: float = MISS, false: float = FALSE,
          wrong: float = WRONG, root: Path | None = None, log=print,
          path: Path | None = None, add: dict | None = None) -> dict:
    """Один прогін на кожне K: дані, клітинки й seed спільні."""
    log(f"[1/3] монети: {len(pairs)}")
    data = pool(pairs, threshold, way, root, log)
    x, y, stamps, coin = data["x"], data["y"], data["stamps"], data["coin"]
    cut = cut_stamp(day)
    side = split_of(stamps, cut)
    edges = bins.edges_of(y[side == 0], data["band"], bins.MIDDLE)
    cell_rows = bins.cells_of(y, edges)
    count = len(cell_rows)
    centres = centres_of(cell_rows)
    cells = cell_index(y, edges)
    labels = soft_matrix(count)
    cost = cost_matrix(count, miss, false, wrong)
    chunks = coin_series(data, side)
    log(f"      разом {len(x)} подій, train {int((side == 0).sum())}, "
        f"test {int((side == 1).sum())}, межа {day} · {count} клітинок")
    params = {"width": net_spec.WIDTH, "heads": net_spec.HEADS,
              "layers": net_spec.LAYERS, "dropout": net_spec.DROPOUT}
    log(f"[2/3] {params} lr {lr}, батч до {batch}, {per_epoch} вікон на "
        f"епоху, бюджет {epochs} епох і {minutes} хв, "
        f"ціни {miss}/{false}/{wrong}, K: "
        f"{', '.join(str(k) for k in sizes)}")

    rows = list(add["rows"]) if add else []
    known = {row["k"] for row in rows}
    if add:
        log(f"      дописується до готових {len(rows)}: "
            f"{', '.join(str(k) for k in sizes if k not in known)}")

    def rank(row: dict) -> tuple:
        """Краще K: більше збігів на краях, далі менший промах."""
        hits = sum(item["hits"] for item in row["signals"])
        gaps = [item["gap"] for item in row["signals"] if item["gap"] is not None]
        return (hits, -(sum(gaps) / len(gaps) if gaps else float("inf")))

    def report_of() -> dict:
        ready = sorted(rows, key=lambda item: item["k"])
        best = max(ready, key=rank)["k"] if ready else None
        return {
            "step": "навчання на всіх монетах: вихід у 28 клітинок",
            "pairs": [pair.replace("_fill", "") for pair in pairs],
            "source": list(pairs),
            "threshold": threshold,
            "way": way,
            "class": "клас210х210х4ц",
            "features": list(correlate.klass.FEATURES),
            "event_seconds": correlate.klass.EVENT_LENGTH,
            "target": (f"зігзаг {threshold} нормований, ема{data['period']}, "
                       f"нога розподіл, згладжено {way}"),
            "target_period": data["period"],
            "events": int(len(x)),
            "with_target": int(np.isfinite(y).sum()),
            "holes": data["holes"],
            "zone": {"band": data["band"], "window": data["window"]},
            "cut": day,
            "cut_stamp": cut,
            "split": {"train": int((side == 0).sum()),
                      "test": int((side == 1).sum())},
            "coins": [{**{key: item[key] for key in
                          ("coin", "pair", "events", "from_utc", "to_utc",
                           "legs", "zones", "zone_events")},
                       "pair": item["pair"].replace("_fill", ""),
                       "train": int((side[item["from"]:item["to"]] == 0).sum()),
                       "test": int((side[item["from"]:item["to"]] == 1).sum())}
                      for item in data["coins"]],
            "cells": count,
            "cell_rows": cell_rows,
            "edges": [round(float(value), bins.DIGITS) for value in edges],
            "centres": [round(float(value), bins.DIGITS) for value in centres],
            "soft": {"own": bins.OWN, "side": bins.SIDE},
            "cost": {"miss": miss, "false": false, "wrong": wrong,
                     "same": 0.0, "other": 1.0},
            "loss_name": ("перехресна ентропія + очікувана ціна + "
                          "WMSE + λ·(σ_цілі − σ_прогнозу)²"),
            "loss_formula": "L = CE + Σ p·C[ціль] + WMSE + λ·(σ_y − σ_ŷ)²",
            "hyper": {**params, "readout": "flat", "lr": lr, "batch": batch,
                      "epochs": epochs, "minutes": minutes,
                      "windows": per_epoch, "seed": seed,
                      "alpha": ALPHA, "beta": BETA, "lambda": LAMBDA,
                      "device": device_name()},
            "sizes": list(sizes),
            "done": len(ready),
            "left": [k for k in sizes if k not in {row["k"] for row in ready}],
            "best": best,
            "chunks": chunks,
            "rows": ready,
        }

    for k in sizes:
        if k in known:
            continue
        train_ends, test_ends = window_ends(coin, side, y, k)
        size = batch_for(k, batch)
        log(f"      K={k}: вікон train {len(train_ends)}, test "
            f"{len(test_ends)}, батч {size}")
        model, device, curve, seconds, epoch = fit(
            k, x, labels, y, centres, cost, cells, train_ends, params,
            epochs, lr, size, seed, minutes, per_epoch, log)
        probs = probs_of(logits_of(model, x, test_ends, k, device,
                                   batch_for(k, READ_BATCH)))
        pred = probs @ centres
        said = probs.argmax(axis=1)
        true_cells = cells[test_ends]
        marks = signals(test_ends, true_cells, said, coin, count)
        row = {
            "k": k,
            "minutes": round(k * correlate.klass.EVENT_LENGTH / 60, 1),
            "windows": {"train": int(len(train_ends)),
                        "test": int(len(test_ends))},
            "batch": size,
            "parameters": net_module.parameters_of(model),
            "epochs": epoch,
            "seconds": seconds,
            "loss": curve[-1]["loss"],
            "entropy": curve[-1]["entropy"],
            "curve": curve,
            "signals": marks,
            "series": series_of(chunks, test_ends, pred, said, probs),
        }
        rows.append(row)
        log(f"      K={k} ({row['minutes']} хв, {row['parameters']} ваг): "
            + " · ".join(f"клітинка {item['cell']}: у цілі {item['real']}, "
                         f"сказала {item['said']}, збіглось {item['hits']}, "
                         f"промах {item['gap']}" for item in marks)
            + f" · {seconds} с")
        save(path, report_of())

    report = report_of()
    save(path, report)
    log(f"[3/3] краще K={report['best']} за збігами на краях")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", default=",".join(PAIRS))
    parser.add_argument("--target", default="2.3")
    parser.add_argument("--way", default=correlate.WAY)
    parser.add_argument("--sizes", default=",".join(str(k) for k in SIZES))
    parser.add_argument("--cut", default=CUT)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--minutes", type=float, default=MINUTES)
    parser.add_argument("--windows", type=int, default=WINDOWS)
    parser.add_argument("--lr", type=float, default=LR)
    parser.add_argument("--batch", type=int, default=BATCH)
    parser.add_argument("--miss", type=float, default=MISS)
    parser.add_argument("--false", dest="false", type=float, default=FALSE)
    parser.add_argument("--wrong", type=float, default=WRONG)
    parser.add_argument("--add", action="store_true",
                        help="дописати нові K до готового звіту")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    pairs = tuple(item.strip() for item in args.pairs.split(",") if item.strip())
    sizes = tuple(int(item) for item in args.sizes.split(",") if item.strip())
    path = args.out / f"train_all_{args.target.replace('.', '_')}.json"
    done = None
    if args.add and path.exists():
        done = json.loads(path.read_text(encoding="utf-8"))
        sizes = tuple(sorted(set(sizes) | {row["k"] for row in done["rows"]}))
    build(pairs, args.target, args.way, sizes, args.cut, args.epochs, args.lr,
          args.batch, SEED, args.minutes, args.windows, args.miss, args.false,
          args.wrong, path=path, add=done)
    print(f"записано {path}")


if __name__ == "__main__":
    main()
