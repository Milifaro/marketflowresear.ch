"""Кореляція фіч `клас210х210х4ц` зі згладженим зігзагом 2.3%.

Дослідження: research/18-smooth-zigzag-x4c/
Правила: rules/01-data-and-db.md → клас210х210х4ц
         rules/02-markup.md → Нормований зігзаг

Подія тут — **чотири числа**: `клас210х210х4ц` це `клас210х14х4ц`,
усереднений по всій події, без розкладки по ЕМА. Питання одне: чи
тримається звʼязок цих чотирьох фіч із ціллю, коли ціль **згладжена**.

Ціль будується тим самим ланцюгом, що в дослідженнях 16 і 17:

    ема90(ціна) -> півоти зігзага 2.3% -> нормована нога (розподіл)
                -> згладжування `сернога` між зонами півотів (вікно = довжина ноги)

Згладжування береться готовим кроком дослідження 16
([`smooth.py`](../../16-zigzag23-wattn/scripts/smooth.py) → `apply_way`),
а не переписується: зони півотів лишаються недоторканими, згладжується
тільки те, що між ними, кожна нога окремо. Період задається іменем
(`--way`), формула — та сама.

Спосіб згладжування тут **центрований** (`сер` — середнє по вікну
`[i − N/2, i + N/2]`), тому фазового зсуву немає. Причинна ЕМА його дає:
`(N−1)/2` подій. Центроване вікно заглядає вперед — для **цілі** це
припустимо, вона й так розмічається заднім числом (півот відомий лише
постфактум), для фічі так робити не можна.

Кореляція рахується двома мірками (Пірсон і Спірмен) на двох відрізках:
**train** розбиття по часу — той самий, на якому вчились моделі 16 і 17,
— і **всі події** датасету. Поруч із згладженою ціллю стоїть сира: без
неї не видно, що дало саме згладжування.

Вихід: results/correlation_2_3.json — числа і ряди для вкладки.

Запуск:
    python3 research/18-smooth-zigzag-x4c/scripts/correlate.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "research" / "16-zigzag23-wattn" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

import class210x210x4c as klass  # noqa: E402
import smooth  # noqa: E402
import split_time  # noqa: E402
import vertex  # noqa: E402
from class210ema4 import ema  # noqa: E402
from correlation import both  # noqa: E402
from data import DATASET, PARTS, PICKED  # noqa: E402
from train import distribution  # noqa: E402
from walk_forward import MIN_GAP, human, merged, pivot_index  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
WAY = "сернога"                 # згладжування цілі цього дослідження
CLASS = "class210x210x4c"
# Іменовані способи дослідження 16 (`smooth.WAYS`) — це його перелік для
# перебору, а не межа можливого. Тут спосіб задається іменем виду
# `ема60`, `сер21`, `мед41`: вид береться з префікса, період — з числа,
# а сама формула лишається тією самою (`smooth.smooth_leg`).
KINDS = {"ема": "ema", "сер": "mean", "мед": "median"}
# Замість числа можна написати `нога` — тоді вікно кожної ноги дорівнює
# **її власній довжині**: `сернога`, `меднога`. У звіті це `way_size` 0.
LEG_SIZE = "нога"


def apply_way(values: np.ndarray, pivots: np.ndarray, zone: np.ndarray,
              kind: str, size: int) -> tuple[np.ndarray, list]:
    """Згладжування по ногах із вікном **не довшим за саму ногу**.

    `smooth.apply_way` дослідження 16 бере вікно як є: на нозі, коротшій
    за вікно, центроване середнє тягне майже всю ногу в кожну точку, і
    нога стає пласкою. Тут вікно кожної ноги обрізається до її довжини —
    коротка нога згладжується своїм розміром, довга — заданим.

    `size <= 0` — вікно **кожної** ноги дорівнює її власній довжині
    (`сернога`): довгі ноги згладжуються так само сильно, як короткі, і
    жодна не отримує вікна, більшого за себе.

    Решта правил ті самі, що в дослідженні 16: зони півотів недоторкані,
    нога в ногу не перетікає, ряд лишається в `[-1, 1]`.

    Повертає ряд і вікно, з яким пішла кожна нога.
    """
    out = values.copy()
    widths = []
    edges = list(pivots)
    for index, (start, stop) in enumerate(zip(edges, edges[1:])):
        piece = slice(start, stop + 1)
        length = stop - start + 1
        good = np.isfinite(values[piece])
        if good.sum() < 3:
            continue
        width = length if size <= 0 else min(size, length)
        widths.append({"leg": index, "events": int(length),
                       "width": int(width)})
        out[piece] = smooth.smooth_leg(values[piece], zone[piece] | ~good,
                                       kind, width)
    return np.clip(out, -1.0, 1.0), widths


def way_of(name: str) -> tuple[str, int]:
    """Спосіб згладжування за іменем: `ема60` -> ("ema", 60).

    Спершу питається перелік дослідження 16 — щоб його способи давали
    рівно ті самі числа, — а вже потім імʼя розбирається на префікс і
    період.
    """
    known = {item for item, _, _ in smooth.WAYS}
    if name in known:
        return smooth.way_of(name)
    for prefix, kind in KINDS.items():
        tail = name[len(prefix):]
        if not name.startswith(prefix) or not tail:
            continue
        if tail == LEG_SIZE:                   # вікно = довжина своєї ноги
            return kind, 0
        if tail.isdigit():
            size = int(tail)
            if size < 2:
                raise SystemExit(f"період згладжування замалий: {name}")
            return kind, size
    raise SystemExit(f"невідомий спосіб згладжування: {name}")


def events(pair: str = "BTC_USDT", root: Path | None = None):
    """Усі події `клас210х210х4ц` одним рядом за часом.

    Власний поділ датасету перемішаний, тому вибірки зшиваються і
    сортуються за `timestamp` — так само, як це робить `merged`.
    """
    folder = (root or DATASET) / pair / CLASS
    x, stamps = [], []
    for part in PARTS:
        with np.load(folder / f"{part}.npz", allow_pickle=False) as data:
            x.append(np.asarray(data["x"], dtype=float))
            stamps.append(np.asarray(data["timestamp"], dtype=np.int64))
    x = np.concatenate(x)
    stamps = np.concatenate(stamps)
    order = np.argsort(stamps, kind="stable")
    return x[order], stamps[order]


def aligned(pair: str, threshold: str, root: Path | None = None):
    """Фічі класу і ціль на спільній осі подій.

    Ціль і ціна беруться тим самим `merged`, що в дослідженнях 16 і 17
    (клас навчання), фічі — з `клас210х210х4ц`. Обидва набори — той самий
    відбір подій, тому зіставляються за `timestamp` подія в подію.
    """
    period = PICKED[threshold]
    _, y, stamps, price = merged(pair, threshold, period, root, "ema", "minmax")
    x, own = events(pair, root)
    if len(own) != len(stamps) or not np.array_equal(own, stamps):
        raise SystemExit("події класу і цілі не збігаються за timestamp")
    return x, y, stamps, price, period


# Ширша зона півота, на якій вчаться моделі цієї вкладки: |y| >= 0.80 і
# ±50 подій. Пара перевірена дослідженням 16 (`pivot_band.py`): усередину
# не потрапляє жоден чужий півот вкладеного зігзага 0.8 %, на кожен півот
# припадає рівно одне суцільне вікно, покриті всі півоти, а саме вікно
# коротше за відстань до найближчого чужого півота (52 події).
MODEL_BAND, MODEL_WINDOW = 0.20, 50


def widen(band: float = MODEL_BAND, window: int = MODEL_WINDOW) -> None:
    """Зона півота на весь прогін: межі, вікно і окіл вершини.

    `vertex.vertices` бере межі з модульної константи **у тілі**, тому їх
    треба саме перевизначити. А от вікно і перелік околів стоять
    значеннями за замовчуванням — вони прив'язуються при імпорті, і їх
    доводиться передавати кожному виклику явно.
    """
    vertex.BAND, vertex.WINDOW = band, window
    vertex.BANDS, vertex.MAIN = (band,), band


def zone_mask(y: np.ndarray, stamps: np.ndarray, pivots: np.ndarray,
              kinds: list, band: float | None = None,
              window: int | None = None) -> tuple[np.ndarray, list]:
    """Маска зон півотів: усередині них ціль не згладжується.

    Межі й вікно передаються **явно**: у `vertex.zone_spans` вони стоять
    значеннями за замовчуванням, а ті прив'язуються при імпорті, тому
    ширшу зону так не поставити.
    """
    spans = vertex.zone_spans(y, stamps, pivots, kinds,
                              vertex.BAND if band is None else band,
                              vertex.WINDOW if window is None else window)
    place = {int(value): index for index, value in enumerate(stamps)}
    mask = np.zeros(len(y), dtype=bool)
    for span in spans:
        mask[place[span["from"]]:place[span["to"]] + 1] = True
    return mask, spans


# Датасет із заповненими пропусками часу: у сирому ряду довгі відрізки
# без розривів рідкісні (`rules/01-data-and-db.md` -> Пропуски часу).
FILL_PAIR = "BTC_USDT_fill"


def data_of(pair: str = FILL_PAIR, threshold: str = "2.3", way: str = WAY,
            root: Path | None = None, band: float | None = None,
            window: int | None = None) -> dict:
    """Події класу, згладжена ціль, півоти й зони — на спільній осі подій."""
    band = MODEL_BAND if band is None else band
    window = MODEL_WINDOW if window is None else window
    x, y, stamps, price, period = aligned(pair, threshold, root)
    pivots = pivot_index(price, period, threshold, "ema")
    marks = zigzag(ema(price, period), THRESHOLDS[threshold])
    mask, spans = zone_mask(y, stamps, pivots, [item.kind for item in marks],
                            band, window)
    kind, size = way_of(way)
    smoothed, widths = apply_way(y, pivots, mask, kind, size)
    return {"x": np.asarray(x, dtype=np.float32), "raw": y, "y": smoothed,
            "stamps": stamps, "price": price, "pivots": pivots,
            "period": period, "zones": spans, "zone_events": int(mask.sum()),
            "leg_windows": widths, "way_kind": kind, "way_size": size,
            "legs": max(len(marks) - 1, 0)}


def dists_of(x: np.ndarray, targets: dict, index: np.ndarray,
             features: list) -> dict:
    """Гістограми: кожна фіча і кожна ціль на тих самих подіях.

    Межі скрізь `[-1, 1]` — і фічі класу, і нормована нога живуть у них,
    тому гістограми читаються на одній шкалі.
    """
    out = {"bins": 40, "from": -1.0, "to": 1.0, "events": int(len(index)),
           "features": {}, "targets": {}}
    for column, name in enumerate(features):
        values = x[index, column]
        good = values[np.isfinite(values)]
        out["features"][name] = {**distribution(good),
                                 "events": int(len(good)),
                                 "nan": int(len(values) - len(good))}
    for title, values in targets.items():
        good = values[index]
        good = good[np.isfinite(good)]
        out["targets"][title] = {**distribution(good),
                                 "events": int(len(good))}
    return out


def rows_for(x: np.ndarray, targets: dict, index: np.ndarray,
             features: list) -> list:
    """Кореляція кожної фічі з кожною ціллю на заданих подіях."""
    rows = []
    for column, name in enumerate(features):
        row = {"feature": name}
        for title, values in targets.items():
            row[title] = both(x[index, column], values[index])
        rows.append(row)
    return rows


def build(pair: str = "BTC_USDT", threshold: str = "2.3", way: str = WAY,
          root: Path | None = None, log=print) -> dict:
    """Кореляція фіч класу з сирою і згладженою ціллю."""
    x, y, stamps, price, period = aligned(pair, threshold, root)
    smoothed_price = ema(price, period)
    pivots = pivot_index(price, period, threshold, "ema")
    marks = zigzag(smoothed_price, THRESHOLDS[threshold])
    kinds = [item.kind for item in marks]
    mask, spans = zone_mask(y, stamps, pivots, kinds)
    wide, wide_spans = zone_mask(y, stamps, pivots, kinds,
                                 MODEL_BAND, MODEL_WINDOW)
    kind, size = way_of(way)
    smoothed, widths = apply_way(y, pivots, mask, kind, size)
    log(f"[1/2] {pair}: {len(x)} подій, {len(marks)} півотів, "
        f"{len(spans)} зон ({int(mask.sum())} подій), "
        f"ширших {len(wide_spans)} ({int(wide.sum())}), згладжування {way}"
        + (f", вікно = довжина ноги ({len(widths)} ніг)" if size <= 0
           else f", вікно обрізано на "
                f"{sum(1 for item in widths if item['width'] < size)} ногах "
                f"із {len(widths)}"))

    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    known = np.isfinite(y) & np.isfinite(smoothed)
    where = {"train": np.flatnonzero(known & np.isin(np.arange(len(x)),
                                                    fold.train)),
             "усі події": np.flatnonzero(known)}
    targets = {"сирий": y, way: smoothed}
    marks_by = {name: rows_for(x, targets, index, klass.FEATURES)
                for name, index in where.items()}
    dists = {name: dists_of(x, targets, index, klass.FEATURES)
             for name, index in where.items()}
    for name, rows in marks_by.items():
        best = max(rows, key=lambda row: abs(row[way]["pearson"] or 0))
        log(f"[2/2] {name}: найсильніша {best['feature']} — Пірсон "
            f"{best[way]['pearson']} (сира ціль {best['сирий']['pearson']})")

    return {
        "pair": pair,
        "threshold": threshold,
        "class": "клас210х210х4ц",
        "features": list(klass.FEATURES),
        "way": way,
        "way_kind": kind,
        "way_size": size,
        "way_note": ("вікно кожної ноги дорівнює її довжині" if size <= 0
                     else "вікно кожної ноги не довше за саму ногу"),
        "leg_windows": widths,
        "legs_capped": sum(1 for item in widths
                           if size > 0 and item["width"] < size),
        "target": f"зігзаг {threshold} нормований, ема{period}, нога розподіл",
        "target_period": period,
        "step": "кореляція фіч класу з сирою і згладженою ціллю",
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "events": int(len(x)),
        "with_target": int(known.sum()),
        "parts": {name: int(len(index)) for name, index in where.items()},
        "bounds": {"train": {"from_utc": human(stamps[fold.train[0]]),
                             "to_utc": human(stamps[fold.train[-1]])},
                   "усі події": {"from_utc": human(stamps[0]),
                                 "to_utc": human(stamps[-1])}},
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW},
        "zones": spans,
        "zone_events": int(mask.sum()),
        "model_zone": {"band": MODEL_BAND, "window": MODEL_WINDOW},
        "model_zones": wide_spans,
        "model_zone_events": int(wide.sum()),
        "legs": max(len(marks) - 1, 0),
        "pivots": [{"t": int(stamps[item.index]),
                    "price": round(float(price[item.index]), 2),
                    "ema": round(float(smoothed_price[item.index]), 2),
                    "kind": item.kind} for item in marks],
        "rows": marks_by,
        "dists": dists,
        "event_seconds": klass.EVENT_LENGTH,
        "price_range": [round(float(price.min()), 2),
                        round(float(price.max()), 2)],
        "t": [int(value) for value in stamps],
        "price": [round(float(value), 2) for value in price],
        "ema": [round(float(value), 2) for value in smoothed_price],
        "y": [None if not np.isfinite(v) else round(float(v), 4) for v in y],
        "p": [None if not np.isfinite(v) else round(float(v), 4)
              for v in smoothed],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--way", default=WAY,
                        help="спосіб згладжування: сернога, сер500, сер210, сер120, ема20")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target, args.way)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"correlation_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
