"""Перевірка моделей дослідження 23 поза їхнім часом: train -> val.

Дослідження: research/24-val-check/
Правила: rules/03-models.md → Навчання моделей

Дослідження 23 міряло все на **train** з перевіркою відкладеною монетою:
модель не бачила монету, але бачила той самий час. Тут перевірка інша й
чесніша — **відкладений час**: навчання на всьому train (до `CUT`),
видача на `val` (від `CUT` до `END`), усі шість монет з обох боків.

## Питання

1. До якого числа падає точність поза часом навчання.
2. На скількох подіях це виміряно — скільки в `val` пачок і скільки
   розворотів.

## Приклад і мітка

Та сама драбина, що в дослідженні 23, етап 6. Пачка з десяти подій
закінчується на події `e`, мітка на затримці `N`:

    y[e] = 1, якщо півот стоїть на події e − N

Приклад іде в train або val **цілком**: і пачка кандидата, і подія
«зараз» лежать по один бік `CUT`. Інших умов немає — питання ставиться
на кожній події й про кожен півот.

## Набори входів

| Набір | Що подається |
| ----- | ------------ |
| `клас` | 62 ознаки пачки кандидата |
| `контекст` | пʼять причинних чисел зараз, вікно 400 подій |
| `вікна` | ті самі пʼять на чотирьох вікнах: 200, 400, 800, 1600 |
| `вікна+клас` | чотири вікна разом з ознаками кандидата |

## Як міряється

Поріг **береться з train** — на заданій повноті — і застосовується до
val як є. Це і є видача моделі в роботі: у момент рішення розподілу val
ніхто не знає.

Оцінки train, за якими стоїть поріг, беруться **з відкладеної монети**:
модель, що цю монету не бачила. Інакше поріг стояв би на числах, які
модель просто запамʼятала, і на val він виявився б надто високим.
Видача на val рахується моделлю, навченою на **всьому** train.

| Число | Що означає |
| ----- | ---------- |
| `train` | точність на навчанні, при повноті `RECALL` |
| `val` | точність на val **тим самим порогом** |
| `recall` | яку частку розворотів val той поріг спіймав |
| `auc`, `ap` | видача на val, незалежно від порога |
| `per_day` | скільки сигналів на монету за добу дає поріг на val |

## Плашка монети

Крім чисел, кожна монета віддає свій **ряд val**: ема ціни, зігзаг і
**сирий сигнал моделі на кожній події ряду** — до порога, як є. Разом із
сигналом іде `kind`: чим ця подія є (`1` — півот на `e − N`, `2` — не
півот, але ціна в його рівні, `0` — ні те, ні те, `-1` — приклад є, але в
рахунок не йде, бо пачка лежить через межу навчання).

Мітки — влучив, у рівні півота, хибний, проґавлений — з цих двох рядів
рахуються **порогом**, і поріг у плашці рухають рукою: файл несе те, з
чого вони виходять, а не готові смуги. `edge` — поріг за замовчуванням, з
чесних оцінок train на повноті `SERIES_RECALL`; `counts` — мітки на ньому.
Окремо йдуть лише півоти, відповідь про які ще попереду: від порога вони
не залежать.

Сигнал іде для **всіх чотирьох** наборів, і плашка їх перемикає.
Фіксувати один набір не можна: поріг із train на val зриває то в одного
набору, то в іншого, і плашка виявлялась би порожньою без пояснення.
`SERIES_SET` лишається тільки як набір за замовчуванням.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/val_check.json      — числа драбини
       results/val_<PAIR>.json     — ряд val однієї монети

Запуск:
    python3 research/24-val-check/scripts/val_check.py
    python3 research/24-val-check/scripts/val_check.py --lags 3 43
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
SIGNAL_SCRIPTS = PROJECT_ROOT / "research" / "23-reversal-signal" / "scripts"
sys.path.insert(0, str(SIGNAL_SCRIPTS))

import signal_data as legs  # noqa: E402
import leg_context  # noqa: E402
import pivot_delay  # noqa: E402
from signal_data import CUT, END, PAIRS, stamp  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LAGS = (3, 23, 43, 103)
SERIES_SET = "вікна+клас"   # яким набором малюються плашки монет
SERIES_RECALL = 0.3         # на якій повноті стоїть поріг у плашках
RECALL = (0.2, 0.3)
SETS = pivot_delay.SETS
SEED = legs.SEED
MARKS = ("hit", "near", "false", "miss", "blind")


def span_part(coin: dict, ends: np.ndarray, lag: int) -> np.ndarray:
    """train / val / поза — приклад цілком по один бік межі.

    Приклад тягнеться від першої події пачки кандидата (`e − lag −
    LEAD + 1`) до події «зараз» (`e`).
    """
    edge, right = stamp(CUT), stamp(END)
    first = coin["t"][np.maximum(ends - lag - legs.LEAD + 1, 0)]
    last = coin["t"][ends]
    return np.where(last < edge, "train",
                    np.where(first >= edge,
                             np.where(last < right, "val", "поза"), "поза"))


def one_lag(coins: list, boards: list, lag: int, sets=SETS,
            recall=RECALL, seed: int = SEED, log=print) -> dict:
    """Один щабель: навчання на train, видача на val."""
    rows, parts = [], []
    for coin, board in zip(coins, boards):
        found = pivot_delay.lag_rows(board, lag)
        rows.append(found)
        parts.append(span_part(coin, found["ends"], lag))
    packs = {"coin": np.concatenate(
                 [np.full(len(one["y"]), number, dtype=np.int16)
                  for number, one in enumerate(rows)]),
             "marks": np.vstack([one["marks"] for one in rows]),
             "context": {look: np.vstack([one["context"][look]
                                          for one in rows])
                         for look in rows[0]["context"]},
             "y": np.concatenate([one["y"] for one in rows]),
             "part": np.concatenate(parts)}
    train = packs["part"] == "train"
    val = packs["part"] == "val"
    body = {"lag": lag, "minutes": round(lag * legs.EVENT_LENGTH / 60, 1),
            "train": {"packs": int(train.sum()),
                      "reversal": int(packs["y"][train].sum())},
            "val": {"packs": int(val.sum()),
                    "reversal": int(packs["y"][val].sum()),
                    "days": legs.cell(int(val.sum()) * legs.EVENT_LENGTH
                                      / 86400)},
            "sets": []}
    log(f"      N {lag:>3}: train пачок {body['train']['packs']}, "
        f"розворотів {body['train']['reversal']}; val пачок "
        f"{body['val']['packs']}, розворотів {body['val']['reversal']}, "
        f"{body['val']['days']} монетодіб")
    if body["val"]["reversal"] < 2 or body["train"]["reversal"] < 2:
        log(f"      N {lag:>3}: розворотів у val {body['val']['reversal']}"
            " — пропуск")
        return body

    near = near_mask(coins, rows, lag)
    for name, wide, looks in sets:
        started = time.time()
        columns = [packs["context"][look] for look in looks]
        if wide:
            columns.insert(0, packs["marks"])
        x = np.nan_to_num(np.hstack(columns), nan=0.0, posinf=0.0, neginf=0.0)
        model = fit(x[train], packs["y"][train], seed)
        score = model.predict_proba(x)[:, 1]
        honest = np.full(len(score), np.nan)
        honest[train] = leg_context.out_of_coin(
            x[train], packs["y"][train], packs["coin"][train], seed)
        found = {"set": name, "columns": int(x.shape[1]),
                 "looks": list(looks),
                 "train": leg_context.measure(packs["y"][train],
                                              honest[train]),
                 "val": leg_context.measure(packs["y"][val], score[val]),
                 "steps": carry(packs["y"], score, honest, train, val,
                                body["val"]["days"], recall, near),
                 "seconds": round(time.time() - started, 1)}
        body["sets"].append(found)
        found["marks"], found["raw"] = fired_by_coin(
            coins, rows, packs, score, honest, train, val, near, lag)
        step = found["steps"][-1]
        log(f"      N {lag:>3} {name:<14}: train {step['train']} -> val "
            f"{step['val']} (спіймано {step['taken']} з "
            f"{body['val']['reversal']}, хибних {step['false']}), val AUC "
            f"{found['val'].get('auc')} — {found['seconds']} с")
    return body


def near_mask(coins: list, rows: list, lag: int,
              near: float = legs.NEAR) -> np.ndarray:
    """Чи показує приклад на подію в ціновому околі справжнього півота."""
    out = []
    for coin, one in zip(coins, rows):
        places = np.clip(one["ends"] - lag, 0, len(coin["ema"]) - 1)
        gap = legs.pivot_gap(coin["ema"], coin["pivots"], places)
        out.append(gap <= near)
    return np.concatenate(out) if out else np.empty(0, dtype=bool)


def blind_pivots(coin: dict, ends: np.ndarray, label: np.ndarray,
                 lag: int) -> list:
    """Півоти val, відповідь про які ще попереду.

    Питання ставиться на кожній події, але про півот `p` його ставлять
    на події `p + N` — і для останніх `N` подій ряду цієї події ще
    немає. Без цієї мітки такий півот мовчки зникав би з плашки.
    """
    inside = np.flatnonzero(coin["part"] == "val")
    if not len(inside):
        return []
    low, high = int(inside[0]), int(inside[-1])
    asked = set((ends[label] - lag).tolist())
    out = []
    for point in coin["pivots"]:
        if not low <= point.index <= high or point.index in asked:
            continue
        out.append(int(min(point.index + lag, high)))
    return out


def fired_by_coin(coins: list, rows: list, packs: dict, score: np.ndarray,
                  honest: np.ndarray, train: np.ndarray, val: np.ndarray,
                  near: np.ndarray, lag: int,
                  want: float = SERIES_RECALL) -> tuple:
    """Сирий сигнал моделі на val — по кожній монеті окремо.

    Повертає поріг із чесних оцінок train і, на кожну монету, сигнал
    **на кожній події** її ряду val разом з тим, чим ця подія є:

    | `kind` | Подія |
    | ------ | ----- |
    | `-1` | приклад є, у рахунок не йде: пачка лежить через межу навчання |
    | `0` | питання поставлене, півота на події `e − N` немає |
    | `1` | півот там є |
    | `2` | півота там немає, але ціна тієї події в його рівні |

    Мітки — влучив, у рівні, хибний, проґавив — з цих двох рядів
    рахуються порогом, і поріг у плашці рухають рукою. Окремо йдуть лише
    півоти, відповідь про які ще попереду (`blind`): від порога вони не
    залежать.
    """
    edge = float(np.quantile(honest[train & (packs["y"] == 1)], 1.0 - want))
    out, raw = {}, {}
    place = 0
    for coin, one in zip(coins, rows):
        count = len(one["y"])
        block = slice(place, place + count)
        place += count
        here = val[block]
        values = score[block]
        label = (packs["y"][block] == 1) & here
        close = near[block] & here & ~label
        ends = one["ends"]
        kind = np.where(label, legs.PIVOT,
                        np.where(close, legs.LEVEL, legs.PLAIN))
        kind = np.where(here, kind, legs.NO_COUNT).astype(np.int8)
        inside = np.flatnonzero(coin["part"] == "val")
        low = int(inside[0]) if len(inside) else 0
        high = int(inside[-1]) if len(inside) else -1
        shown = (ends >= low) & (ends <= high)
        out[coin["pair"]] = {"blind": blind_pivots(coin, ends, label, lag)}
        raw[coin["pair"]] = {"ends": ends[shown].tolist(),
                             "kind": kind[shown].tolist(),
                             "value": [round(float(value), 4)
                                       for value in values[shown]]}
    return ({"edge": legs.cell(edge), "want": legs.cell(want),
             "set": SERIES_SET, "near": legs.cell(legs.NEAR),
             "by_coin": out}, raw)


def coin_series(coin: dict, rows: list, lags: list) -> dict:
    """Ряд val однієї монети: ема, зігзаг і сигнал моделі по щаблях."""
    part = coin["part"]
    inside = np.flatnonzero(part == "val")
    if not len(inside):
        return {"pair": coin["pair"], "events": 0, "ready": False}
    low, high = int(inside[0]), int(inside[-1])
    index = np.arange(low, high + 1)
    place = {value: number for number, value in enumerate(index)}
    body = {"pair": coin["pair"], "ready": True,
            "events": int(len(index)),
            "from_utc": legs.leg_deciles.utc(coin["t"][low]),
            "to_utc": legs.leg_deciles.utc(coin["t"][high]),
            "t": coin["t"][index].astype(int).tolist(),
            "price": [round(float(one), 6) for one in coin["ema"][index]],
            "period": legs.PERIOD, "threshold": legs.THRESHOLD,
            "event_seconds": legs.EVENT_LENGTH,
            "pivots": [{"t": int(coin["t"][point.index]),
                        "ema": round(float(coin["ema"][point.index]), 6),
                        "kind": point.kind}
                       for point in coin["pivots"]
                       if low <= point.index <= high],
            "lags": {}}
    for row, lag in zip(rows, lags):
        sets = {}
        for one in row.get("sets", []):
            raw = (one.get("raw") or {}).get(coin["pair"])
            if not raw:
                continue
            found = (one.get("marks") or {}).get("by_coin", {}).get(
                coin["pair"], {})
            sets[one["set"]] = legs.step_lines(
                raw, found.get("blind", ()), place, len(index),
                one["marks"].get("edge"), one["marks"].get("near"))
        if sets:
            body["lags"][str(lag)] = sets
    return body


def fit(x: np.ndarray, y: np.ndarray, seed: int = SEED):
    from sklearn.ensemble import HistGradientBoostingClassifier

    model = HistGradientBoostingClassifier(
        max_iter=leg_context.MAX_ITER, learning_rate=leg_context.RATE,
        max_leaf_nodes=leg_context.LEAVES, class_weight="balanced",
        random_state=seed)
    model.fit(x, y)
    return model


def carry(y: np.ndarray, score: np.ndarray, honest: np.ndarray,
          train: np.ndarray, val: np.ndarray, days: float,
          recall=RECALL, near: np.ndarray | None = None) -> list:
    """Поріг із чесних оцінок train, застосований до val як є.

    `honest` — оцінки train від моделі, що цієї монети не бачила;
    `score` — оцінки повної моделі, ними міряється val. `near` —
    приклади, що показують на подію в ціновому околі півота: строга
    точність їх не зараховує, точність з допуском зараховує.
    """
    out = []
    if near is None:
        near = np.zeros(len(y), dtype=bool)
    close = near & (y == 0)
    for want in recall:
        edge = float(np.quantile(honest[train & (y == 1)], 1.0 - want))
        rows = {}
        for name, mask in (("train", train), ("val", val)):
            values = honest if name == "train" else score
            shot = (values >= edge) & mask
            taken = int((shot & (y == 1)).sum())
            spare = int((shot & close).sum())
            false = int((shot & (y == 0) & ~close).sum())
            hit = int((mask & (y == 1)).sum())
            rows[name] = {"precision": legs.cell(taken
                                                 / max(taken + spare + false,
                                                       1)),
                          "near": legs.cell((taken + spare)
                                            / max(taken + spare + false, 1)),
                          "taken": taken, "spare": spare, "false": false,
                          "recall": legs.cell(taken / max(hit, 1))}
        out.append({"want": legs.cell(want), "edge": legs.cell(edge),
                    "train": rows["train"]["precision"],
                    "val": rows["val"]["precision"],
                    "near_val": rows["val"]["near"],
                    "recall": rows["val"]["recall"],
                    "taken": rows["val"]["taken"],
                    "spare": rows["val"]["spare"],
                    "false": rows["val"]["false"],
                    "per_day": legs.cell((rows["val"]["taken"]
                                          + rows["val"]["spare"]
                                          + rows["val"]["false"])
                                         / max(days, legs.EPS))})
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lags", type=int, nargs="+", default=list(LAGS))
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    boards = [pivot_delay.coin_board(coin, part="all") for coin in coins]
    print("[щаблі]")
    rows = [one_lag(coins, boards, lag, seed=args.seed) for lag in args.lags]

    args.out.mkdir(parents=True, exist_ok=True)
    print("[плашки монет]")
    for coin in coins:
        body = coin_series(coin, rows, list(args.lags))
        body.update({"script": "research/24-val-check/scripts/val_check.py",
                     "cut_utc": f"{CUT} 00:00:00",
                     "end_utc": f"{END} 00:00:00",
                     "series_set": SERIES_SET,
                     "series_recall": SERIES_RECALL,
                     "near": legs.NEAR, "marks": list(MARKS),
                     "lag_list": list(args.lags)})
        (args.out / f"val_{coin['pair']}.json").write_text(
            json.dumps(body, ensure_ascii=False), encoding="utf-8")
        first = body.get("lags", {}).get(str(args.lags[0]), {})
        first = first.get(SERIES_SET) or next(iter(first.values()), {})
        print(f"      {coin['pair']}: подій {body['events']}, півотів "
              f"{len(body.get('pivots', []))}, на щаблі {args.lags[0]} — "
              f"{first.get('counts', {})}")
    for row in rows:                 # мітки й сигнал живуть у плашках монет
        for one in row.get("sets", []):
            one.pop("raw", None)
            one.pop("marks", None)

    (args.out / "val_check.json").write_text(json.dumps({
        "script": "research/24-val-check/scripts/val_check.py",
        "command": "python3 research/24-val-check/scripts/val_check.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "lags": list(args.lags),
        "recall_grid": list(RECALL),
        "sets": [name for name, _, _ in SETS], "looks": list(pivot_delay.LOOKS),
        "size": legs.SIZE, "lead": legs.LEAD, "tail": legs.TAIL,
        "look": legs.LOOK, "seed": args.seed,
        "max_iter": leg_context.MAX_ITER, "leaves": leg_context.LEAVES,
        "rate": leg_context.RATE,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "series_set": SERIES_SET, "series_recall": SERIES_RECALL,
        "near": legs.NEAR, "marks": list(MARKS),
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/val_check.json")


if __name__ == "__main__":
    main()
