"""Зона півота в розподілі: де ціль гарантовано означає півот.

Дослідження: research/16-zigzag23-wattn/ (розділ 1)
Правила: rules/02-markup.md → Нормований зігзаг, Нормалізація ноги

У нозі, нормованій **розподілом**, півот має значення рівно `−1` або
`+1` — це контролюється тут же. Але саме по собі `|y|` близьке до
одиниці півота не гарантує: у довгій нозі ціна може відкотитись майже до
її початку, і `|y|` знову підійде до одиниці за сотні подій від будь-якого
півота.

Тому зона задається **двома** показниками:

    вліво-вправо   подія не далі за K_ліво … K_право подій від півота
    межі           |y| >= 1 - band  (діапазон розподілу навколо вершини)

Зона перевіряється чотирма умовами:

1. **чисто** — всередину не потрапляє жоден локальний екстремум усередині
   руху. Такі екстремуми беруться не на око: це півоти **вкладеного
   зігзага 0.8%** на тому самому ряду, які не є півотами 2.3%;
2. **однозначно** — рівно одне суцільне вікно на кожен півот
   (`clusters == pivots`): зона не розсипається на шматки й не зливає два
   півоти в один;
3. **повно** — покриті всі півоти ряду;
4. **із запасом** — вікно коротше за відстань до найближчого чужого
   півота. Тоді чужий півот не може потрапити в зону **за побудовою**, а
   не тому, що цього разу не потрапив.

Серед зон, що пройшли всі чотири, береться найбільша за кількістю подій:
менша зона нічого не додає, а тільки звужує навчальну вибірку.

Вихід: results/pivot_band_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/pivot_band.py --target 2.3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from data import PICKED  # noqa: E402
from legs import LEG_USED, prices_of  # noqa: E402
from train import number  # noqa: E402
from zigzag import INNER_THRESHOLD, zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
# Сітка перебору: межі розподілу і скільки подій навколо півота.
BANDS = (0.02, 0.05, 0.08, 0.1, 0.15, 0.2, 0.3)
STEPS = (10, 20, 30, 40, 50, 60, 80, 120)


def edges(values: np.ndarray, pivots: np.ndarray, inside: np.ndarray
          ) -> tuple[np.ndarray, np.ndarray]:
    """Довжина суцільної смуги `inside` ліворуч і праворуч від кожного півота."""
    left, right = [], []
    for pivot in pivots:
        step = pivot - 1
        count = 0
        while step >= 0 and inside[step]:
            count += 1
            step -= 1
        left.append(count)
        step = pivot + 1
        count = 0
        while step < len(values) and inside[step]:
            count += 1
            step += 1
        right.append(count)
    return np.array(left), np.array(right)


def zone(values, pivots, distance, band, left, right, side):
    """Маска зони: межі розподілу плюс вікно вліво-вправо від півота."""
    near = (distance >= -left) & (distance <= right)
    return np.isfinite(values) & (np.abs(values) >= 1 - band) & near & side


def moves(series: np.ndarray, owner_price: np.ndarray, mask: np.ndarray) -> dict:
    """Відхилення ціни події від ціни її півота, % і одиниці котирування."""
    if not mask.any():
        return {"min": None, "mean": None, "median": None, "max": None,
                "min_abs": None, "mean_abs": None, "max_abs": None}
    gap = np.abs(series[mask] - owner_price[mask])
    percent = 100 * gap / owner_price[mask]
    return {
        "min": number(percent.min(), 4),
        "mean": number(percent.mean(), 4),
        "median": number(np.median(percent), 4),
        "max": number(percent.max(), 4),
        "min_abs": number(gap.min(), 2),
        "mean_abs": number(gap.mean(), 2),
        "max_abs": number(gap.max(), 2),
    }


def measure(values, pivots, inner, distance, side, band, left, right,
            smoothed=None, price=None, owner=None) -> dict:
    """Скільки подій у зоні, чи вона суцільна, чи чиста і як далеко ціна."""
    mask = zone(values, pivots, distance, band, left, right, side)
    where = np.flatnonzero(mask)
    clusters = 1 + int((np.diff(where) > 1).sum()) if len(where) else 0
    inside = mask[pivots]
    prices = {}
    if smoothed is not None and owner is not None:
        at_pivot = pivots[owner]
        prices = {"ema": moves(smoothed, smoothed[at_pivot], mask),
                  "price": moves(price, price[at_pivot], mask)}
    return {
        "band": band,
        "left": int(left),
        "right": int(right),
        "events": int(mask.sum()),
        "share": number(mask.mean()),
        "clusters": clusters,
        "pivots": int(inside.sum()),
        "inner_pivots": int(mask[inner].sum()) if len(inner) else 0,
        "min_abs": number(np.abs(values[mask]).min()) if mask.any() else None,
        **prices,
    }


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          root: Path | None = None, leg: str = LEG_USED,
          bands=BANDS, steps=STEPS) -> dict:
    period = PICKED[threshold]
    price, stamps = prices_of(pair, root)
    smoothed = ema(price, period)
    outer = zigzag(smoothed, THRESHOLDS[threshold])
    inner_all = zigzag(smoothed, INNER_THRESHOLD)
    pivots = np.array([item.index for item in outer], dtype=int)
    kinds = np.array([item.kind for item in outer])
    inner = np.setdiff1d(np.array([item.index for item in inner_all], dtype=int),
                         pivots)
    values = zigzag_targets.build(price, stamps, periods=[period],
                                  scaler=leg).column(period, threshold)

    order = np.arange(len(values))
    gap = order[:, None] - pivots[None, :]          # + праворуч, − ліворуч
    owner = np.abs(gap).argmin(axis=1)
    distance = gap[order, owner]
    # знак зони той самий, що в її півота: верхня вершина — верхній півот
    want = np.where(kinds[owner] == "high", 1.0, -1.0)
    side = np.sign(values) == want

    at_pivots = values[pivots]
    control = {
        "pivots": int(len(pivots)),
        "high": {"events": int((kinds == "high").sum()),
                 "min": number(at_pivots[kinds == "high"].min()),
                 "max": number(at_pivots[kinds == "high"].max())},
        "low": {"events": int((kinds == "low").sum()),
                "min": number(at_pivots[kinds == "low"].min()),
                "max": number(at_pivots[kinds == "low"].max())},
        "exact": bool(np.all(np.abs(np.abs(at_pivots) - 1) < 1e-9)),
    }

    runs = []
    for band in bands:
        inside = np.isfinite(values) & (np.abs(values) >= 1 - band) & side
        left, right = edges(values, pivots, inside)
        runs.append({"band": band,
                     "left": {"median": number(np.median(left)),
                              "p90": number(np.quantile(left, 0.9)),
                              "max": int(left.max())},
                     "right": {"median": number(np.median(right)),
                               "p90": number(np.quantile(right, 0.9)),
                               "max": int(right.max())}})

    grid = [measure(values, pivots, inner, distance, side, band, step, step,
                    smoothed, price, owner)
            for band in bands for step in steps]
    nearest = int(np.abs(distance[inner]).min()) if len(inner) else None
    clean = [item for item in grid
             if item["inner_pivots"] == 0 and item["clusters"] == len(pivots)
             and item["pivots"] == len(pivots)
             and (nearest is None
                  or max(item["left"], item["right"]) < nearest)]
    best = max(clean, key=lambda item: item["events"]) if clean else None

    return {
        "pair": pair,
        "threshold": threshold,
        "target_period": period,
        "leg": leg,
        "target": f"зігзаг {threshold} нормований, ема{period}",
        "events": int(len(values)),
        "with_target": int(np.isfinite(values).sum()),
        "inner_threshold": INNER_THRESHOLD,
        "inner_pivots": int(len(inner)),
        "inner_nearest": nearest,
        "inner_max_abs": number(np.nanmax(np.abs(values[inner])))
        if len(inner) else None,
        "control": control,
        "runs": runs,
        "grid": grid,
        "clean": clean,
        "picked": best,
        "rule": ("чисто (жодного півота вкладеного зігзага), однозначно "
                 "(одне вікно на півот), повно (усі півоти), із запасом "
                 "(вікно коротше за відстань до найближчого чужого півота) "
                 "— і найбільша з таких"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"pivot_band_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")

    control = report["control"]
    print(f"{report['pair']} · ціль {report['target']} · {report['events']} подій")
    print(f"півоти в розподілі: верхні {control['high']['min']} … "
          f"{control['high']['max']} ({control['high']['events']} шт), нижні "
          f"{control['low']['min']} … {control['low']['max']} "
          f"({control['low']['events']} шт) · рівно ±1: {control['exact']}")
    print(f"чужі півоти (вкладений зігзаг {report['inner_threshold']}): "
          f"{report['inner_pivots']} шт, найближчий за {report['inner_nearest']} "
          f"подій, макс |y| {report['inner_max_abs']}")
    print("\nсуцільна смуга навколо півота, подій:")
    for row in report["runs"]:
        print(f"  межі |y| >= {1 - row['band']:.2f}: вліво "
              f"{row['left']['median']:.0f}/{row['left']['p90']:.0f}/"
              f"{row['left']['max']}, вправо {row['right']['median']:.0f}/"
              f"{row['right']['p90']:.0f}/{row['right']['max']} "
              f"(медіана/90 %/макс)")
    print("\nзони, що пройшли всі умови:")
    for item in sorted(report["clean"], key=lambda row: -row["events"])[:8]:
        print(f"  |y| >= {1 - item['band']:.2f}, ±{item['left']} подій: "
              f"{item['events']} подій ({item['share'] * 100:.2f} % ряду)")
    print("\nвідхилення ціни від ціни півота в зоні, %:")
    print(f"{'зона':>22} | {'ема90: мін/сер/макс':>26} | "
          f"{'ціна події: мін/сер/макс':>28}")
    for item in sorted(report["clean"], key=lambda row: -row["events"]):
        name = f"|y| >= {1 - item['band']:.2f}, ±{item['left']}"
        e, q = item["ema"], item["price"]
        print(f"{name:>22} | {e['min']:>7.3f}/{e['mean']:>7.3f}/{e['max']:>7.3f} "
              f"    | {q['min']:>8.3f}/{q['mean']:>8.3f}/{q['max']:>8.3f}")
    if report["picked"]:
        best = report["picked"]
        print(f"\nобрано: |y| >= {1 - best['band']:.2f} і ±{best['left']} "
              f"подій від півота — {best['events']} подій "
              f"({best['share'] * 100:.2f} % ряду)")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
