"""Яку ногу брати в навчання: розподіл чи квантиль.

Дослідження: research/16-zigzag23-wattn/ (розділ 1)
Правила: rules/02-markup.md → Нормалізація ноги
         rules/01-data-and-db.md → Порядок дій і захист від витоку

Обидва ряди відповідають на одне питання — де подія стоїть у своїй нозі,
але по-різному: `minmax` — **частка пройденого шляху** ноги, `quantile` —
**ранг** події всередині ноги. Порівнюються двома мірками:

1. **Звʼязок з фічами** — той самий критерій, яким обиралась мітка на
   етапі 1: кореляція всіх 52 фіч класу з рядом, Пірсоном і Спірменом,
   **тільки на train**.
2. **Розподіл біля вершин** — скільки подій потрапляє в окіл `−1` і `+1`
   і як далеко в цьому околі стоїть сама ціль (`vertex.py`): цим
   дослідження міряє видачу, тому ряд не має ні згущувати вершини, ні
   робити їх порожніми.

Цілі будуються на **всьому** ряду подій і лише потім ріжуться по train —
рівно так, як вони лежать у датасеті (контроль: колонка `minmax` має
збігтись із `train_targets.npz`).

Вихід: results/leg_pick_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/leg_pick.py --target 2.3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import vertex  # noqa: E402
import zigzag_targets  # noqa: E402
from correlation import pearson, ranks  # noqa: E402
from data import DATASET, PICKED  # noqa: E402
from legs import prices_of  # noqa: E402
from train import number  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
PART = "train"          # вибір ноги — агрегат по датасету, тому тільки train
# Кандидати порівняння. У навчання йде переможець (`legs.SCALERS`), але
# порівняння лишається тут: без нього вибір нічим не підтверджений.
CANDIDATES = ("minmax", "quantile")


def rows_of(dataset) -> list[tuple[str, np.ndarray]]:
    """52 фічі події одним переліком: `<фіча> ема<період>`."""
    return [(f"{name} ема{period}", dataset.x[:, i, j])
            for i, period in enumerate(dataset.periods)
            for j, name in enumerate(dataset.features)]


def link(rows, ranked, values: np.ndarray) -> dict:
    """Звʼязок ряду з фічами: макс і середня |r| Пірсона й Спірмена."""
    good = np.isfinite(values)
    target_ranks = ranks(np.where(good, values, np.nan))
    pear = {label: abs(pearson(series, values)) for label, series in rows}
    spear = {label: abs(pearson(ranked[label], target_ranks))
             for label, _ in rows}
    best = max(pear, key=pear.get)
    return {
        "events": int(good.sum()),
        "std": number(np.nanstd(values)),
        "max_abs": number(max(pear.values())),
        "mean_abs": number(float(np.mean(list(pear.values())))),
        "max_abs_spearman": number(max(spear.values())),
        "mean_abs_spearman": number(float(np.mean(list(spear.values())))),
        "best_feature": best,
    }


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          root: Path | None = None, part: str = PART) -> dict:
    period = PICKED[threshold]
    in_dir = (root or DATASET) / pair / "class210x4bema10x10x130"
    dataset = klass.load(in_dir / f"{part}.npz")
    price, stamps = prices_of(pair, root)
    place = {int(value): index for index, value in enumerate(stamps)}
    index = np.array([place[int(value)] for value in dataset.timestamp])

    rows = rows_of(dataset)
    ranked = {label: ranks(series) for label, series in rows}
    # контроль сходиться лише там, де цілі вже збережені поруч із фічами
    targets = in_dir / f"{part}_targets.npz"
    saved = (zigzag_targets.load(targets).column(period, threshold)
             if targets.exists() else None)

    report = {"pair": pair, "threshold": threshold, "part": part,
              "target_period": period,
              "target": f"зігзаг {threshold} нормований, ема{period}",
              "features": len(rows), "events": int(len(dataset)),
              "bands": list(vertex.BANDS), "rows": []}
    for leg in CANDIDATES:
        values = zigzag_targets.build(price, stamps, periods=[period],
                                      scaler=leg).column(period, threshold)[index]
        clean = values[np.isfinite(values)]
        spread = vertex.vertices(clean, clean)
        report["rows"].append({
            "id": leg,
            "name": {"minmax": "розподіл", "quantile": "квантиль"}.get(leg, leg),
            **link(rows, ranked, values),
            # контроль: ряд датасету зібраний саме цим скейлером
            "matches_dataset": (None if saved is None else
                                bool(np.allclose(values, saved,
                                                 equal_nan=True))),
            "vertices": [{"band": item["band"],
                          "share": item["both"]["share"],
                          "gap_true": item["both"]["gap_true"]}
                         for item in spread["rows"]],
        })
    best = max(report["rows"], key=lambda item: item["max_abs"])
    report["picked"] = best["id"]
    report["reason"] = (f"найбільший звʼязок з фічами на {part}: "
                        f"макс |r| {best['max_abs']}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3",
                        choices=tuple(zigzag_targets.THRESHOLDS))
    parser.add_argument("--part", default=PART,
                        choices=("train", "val", "test"))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target, part=args.part)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"leg_pick_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"{report['pair']} · {report['part']} · {report['events']} подій · "
          f"{report['features']} фіч · ціль {report['target']}")
    for row in report["rows"]:
        print(f"  {row['name']:>9}: σ {row['std']} · макс |r| {row['max_abs']} "
              f"(сер {row['mean_abs']}) · макс |ро| {row['max_abs_spearman']} "
              f"(сер {row['mean_abs_spearman']}) · {row['best_feature']}"
              + ("  ← ряд датасету" if row["matches_dataset"] else ""))
        print("             околи: " + ", ".join(
            f"{item['band']}: {item['share'] * 100:.1f}% / {item['gap_true']}"
            for item in row["vertices"]))
    print(f"обрано: {report['picked']} — {report['reason']}")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
