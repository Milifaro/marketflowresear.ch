"""Відстань до вершин цілі: наскільки видача не доходить до −1 і +1.

Дослідження: research/16-zigzag23-wattn/
Правила: rules/03-models.md → Метрики

Ціль — нормована нога зігзага: `−1` у нижньому півоті, `+1` у верхньому,
між ними пропорційно. Загальний MAE рахується по всіх подіях, а більшість
із них сидить у середині ноги, де відповідь «близько нуля» і дешева, і
правильна. Питання дослідження інше — **де вершина**, тому міряється
відстань саме до неї.

Вершина береться не однією точкою, а **околом**: подія вважається
верхньою, поки ціль не впала нижче за `1 − band`, і нижньою, поки не
піднялась вище за `−1 + band`. На кожен окіл рахується:

    events / share    скільки подій потрапило в окіл вершини
    gap_pred          середнє |вершина − прогноз| — відстань видачі до вершини
    gap_true          те саме для самої цілі: наскільки вершина «розмита»
                      всередині околу (лінія відліку, менше не буде)
    mae               середнє |прогноз − ціль| на цих подіях
    reach             середній прогноз: доходить він до вершини чи ні

`BANDS` — окіл звіту, він же `MAIN`: `|y| >= 0.90`.

## Зона півота

Самих меж `|y|` мало: у довгій нозі ціна відкочується майже до її
початку, і `|y|` знову підходить до одиниці за сотні подій від будь-якого
півота (`pivot_band.py`). Тому **робоча зона** дослідження задана двома
показниками:

    |y| >= 1 - BAND      межі розподілу навколо вершини   (BAND = 0.1)
    |i - півот| <= WINDOW   вікно вліво-вправо, подій      (WINDOW = 40)

Обидва числа взяті з `pivot_band.py`: у такій зоні 2 624 події (6.5 %
ряду), рівно одне суцільне вікно на кожен півот, жодного півота
вкладеного зігзага 0.8 %, а вікно вдвічі коротше за відстань до
найближчого з них. Зона рахується там, де відома **відстань до півота**
(`distance` у виклику); без неї у звіті лишаються самі околи.

Ціль дослідження — **попадати в цю зону**, тому поруч рахуються влучання:

    у зоні        подія, де ціль справді в зоні півота
    сказала       подія, де |прогноз| >= 1 - BAND: модель каже «вершина»
    влучань       обидва разом і того самого знака
    to_edge       скільки прогнозу бракує до межі зони: max(0, 0.9 − |p|)
    to_vertex     скільки бракує до самої вершини: |вершина − p|
    to_pivot      відстань у **подіях** до найближчого півота там, де
                  модель сказала «вершина» — влучає вона біля півотів
                  чи будь-де
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))

from train import number  # noqa: E402

# Окіл вершини, який іде у звіт (частка ноги від самої вершини). Він
# один — той, на якому стоїть робоча зона; ширші околи нічого не
# вирішують, бо «вершиною» там зветься півноги.
BANDS = (0.1,)
MAIN = 0.1
# Робоча зона: межі розподілу і вікно вліво-вправо від півота, подій.
BAND, WINDOW = 0.1, 40
TOP, BOTTOM = 1.0, -1.0


def side(true: np.ndarray, pred: np.ndarray, mask: np.ndarray,
         vertex: float) -> dict:
    """Одна вершина в одному околі: скільки подій і як далеко від неї видача."""
    if not mask.any():
        return {"events": 0, "share": 0.0, "gap_pred": None, "gap_true": None,
                "mae": None, "reach": None}
    y, p = true[mask], pred[mask]
    return {
        "events": int(mask.sum()),
        "share": number(mask.mean()),
        "gap_pred": number(np.abs(vertex - p).mean()),
        "gap_true": number(np.abs(vertex - y).mean()),
        "mae": number(np.abs(p - y).mean()),
        "reach": number(p.mean()),
    }


def band_row(true, pred, up, down, band=None, extra=None) -> dict:
    """Один рядок звіту: верхня вершина, нижня і обидві разом."""
    both = up | down
    gaps = np.where(up, np.abs(TOP - pred), np.abs(BOTTOM - pred))
    truth = np.where(up, np.abs(TOP - true), np.abs(BOTTOM - true))
    row = {"band": band, "up": side(true, pred, up, TOP),
           "down": side(true, pred, down, BOTTOM),
           "both": {
               "events": int(both.sum()),
               "share": number(both.mean()),
               "gap_pred": number(gaps[both].mean()) if both.any() else None,
               "gap_true": number(truth[both].mean()) if both.any() else None,
               "mae": number(np.abs(pred[both] - true[both]).mean())
               if both.any() else None,
               "reach": None,
           }}
    row.update(extra or {})
    return row


def zone_row(true, pred, distance, band: float = BAND,
             window: int = WINDOW) -> dict:
    """Робоча зона: межі розподілу плюс вікно вліво-вправо від півота."""
    near = np.asarray(distance) <= window
    up = (true >= TOP - band) & near
    down = (true <= BOTTOM + band) & near
    return band_row(true, pred, up, down, band, {"window": int(window)})


def hits(true, pred, distance, band: float = BAND,
         window: int = WINDOW) -> dict:
    """Влучання в зону: скільки разів модель сказала вершину там, де вона є."""
    near = np.asarray(distance) <= window
    inside = (np.abs(true) >= 1 - band) & near
    said = np.abs(pred) >= 1 - band
    same = np.sign(pred) == np.sign(true)
    hit = inside & said & same
    edge = np.clip((1 - band) - np.abs(pred), 0, None)
    vertex = np.abs(np.sign(true) - pred)
    steps = np.asarray(distance)[said]
    return {
        "band": band,
        "window": int(window),
        "inside": int(inside.sum()),
        "said": int(said.sum()),
        "hits": int(hit.sum()),
        "missed": int((inside & ~(said & same)).sum()),
        "false": int((said & ~(inside & same)).sum()),
        "recall": number(hit.sum() / inside.sum()) if inside.any() else None,
        "precision": number(hit.sum() / said.sum()) if said.any() else None,
        "to_edge": number(edge[inside].mean()) if inside.any() else None,
        "to_vertex": number(vertex[inside].mean()) if inside.any() else None,
        "to_pivot": {
            "mean": number(steps.mean()) if said.any() else None,
            "median": number(np.median(steps)) if said.any() else None,
            "max": int(steps.max()) if said.any() else None,
            "inside_window": number((steps <= window).mean())
            if said.any() else None,
        },
    }


def vertices(true, pred, bands=BANDS, main: float = MAIN,
             distance=None, window: int = WINDOW) -> dict:
    """Відстань до вершин `−1` і `+1` в околах і в робочій зоні."""
    true = np.asarray(true, dtype=float)
    pred = np.asarray(pred, dtype=float)
    rows = []
    for band in bands:
        up = true >= TOP - band
        down = true <= BOTTOM + band
        both = up | down
        gaps = np.where(up, np.abs(TOP - pred), np.abs(BOTTOM - pred))
        rows.append({
            "band": band,
            "up": side(true, pred, up, TOP),
            "down": side(true, pred, down, BOTTOM),
            "both": {
                "events": int(both.sum()),
                "share": number(both.mean()),
                "gap_pred": number(gaps[both].mean()) if both.any() else None,
                "gap_true": number(
                    np.where(up, np.abs(TOP - true),
                             np.abs(BOTTOM - true))[both].mean())
                if both.any() else None,
                "mae": number(np.abs(pred[both] - true[both]).mean())
                if both.any() else None,
                "reach": None,
            },
        })
    report = {"vertices": [BOTTOM, TOP], "bands": list(bands), "main": main,
              "rows": rows}
    if distance is not None:
        report["zone"] = zone_row(true, pred, distance, BAND, window)
        report["hits"] = hits(true, pred, distance, BAND, window)
    return report


def zone_spans(values, stamps, pivots, kinds, band: float = BAND,
               window: int = WINDOW) -> list[dict]:
    """Зона кожного півота як відрізок часу — для графіків.

    Береться **суцільна смуга навколо самого півота**: від нього вліво і
    вправо, поки ціль тримається в межах зони і не далі за вікно.
    """
    values = np.asarray(values, dtype=float)
    stamps = np.asarray(stamps)
    spans = []
    for pivot, kind in zip(np.asarray(pivots, dtype=int), kinds):
        want = 1.0 if kind == "high" else -1.0
        def inside(i):
            return (0 <= i < len(values) and np.isfinite(values[i])
                    and abs(values[i]) >= 1 - band
                    and np.sign(values[i]) == want)
        left = pivot
        while left - 1 >= pivot - window and inside(left - 1):
            left -= 1
        right = pivot
        while right + 1 <= pivot + window and inside(right + 1):
            right += 1
        spans.append({"pivot": int(stamps[pivot]), "kind": kind,
                      "from": int(stamps[left]), "to": int(stamps[right]),
                      "events": int(right - left + 1)})
    return spans


def main_row(report: dict) -> dict:
    """Рядок робочого околу зі звіту — те, що читає вкладка."""
    for row in report["rows"]:
        if row["band"] == report["main"]:
            return row
    return report["rows"][0]
