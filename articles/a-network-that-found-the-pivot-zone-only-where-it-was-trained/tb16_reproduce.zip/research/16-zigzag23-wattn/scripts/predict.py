"""Видача моделі на всьому датасеті: ціна, зігзаг, ціль, прогноз, зони.

Дослідження: research/16-zigzag23-wattn/ (розділ 2)

Модель проганяється по **всіх** подіях `клас210х4бема10х10х130` — train,
val і test разом, у порядку часу. Виходить чотири ряди на спільній осі:

    price  — ціна події (price_open), USDT, і півоти зігзага 2.3 на ема90
    ema    — ема90 ціни: сам ряд, на якому стоїть зігзаг
    y      — ціль: нормований зігзаг 2.3%, нога розподіл, [-1, 1]
    p      — видача моделі на тих самих фічах

Разом з рядами йдуть **зони півотів** (`vertex.zone_spans`) — відрізки
часу, у які модель має влучати, і метрики влучання (`vertex.hits`).

Метрики рахуються по **вікнах розбиття прогону** (`train | val | test`
підряд за часом), а не по вибірках датасету: власний поділ датасету
перемішаний, усі три його частини лежать на всьому періоді, і модель,
навчена на суцільному відрізку часу, на них не міряється.

Модель і скейлер беруться збережені прогоном `wattn_losses.py`: скейлер
той самий, що рахувався на train при навчанні, а не рахується заново.

Вихід: results/predict_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/predict.py --target 2.3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import split_time  # noqa: E402
import vertex  # noqa: E402
from class210ema4 import ema  # noqa: E402
from data import PICKED  # noqa: E402
from saved import load_model  # noqa: E402
from train import metrics, model_params  # noqa: E402
from walk_forward import MIN_GAP, merged, pivot_index  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
DEFAULT_RUN = "losses_wattn"


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          root: Path | None = None, run: str = DEFAULT_RUN,
          out: Path | None = None, leg: str = "minmax",
          scale: str = "quantile") -> dict:
    out = out or RESULTS
    tail = threshold.replace(".", "_")
    report = json.loads((out / f"{run}_{tail}.json").read_text(encoding="utf-8"))
    model, scaler = load_model(report, PROJECT_ROOT)
    period = PICKED[threshold]

    x, y, stamps, price = merged(pair, threshold, period, root, "ema", leg)
    smoothed = ema(price, period)
    pivots = pivot_index(price, period, threshold, "ema")
    marks = zigzag(smoothed, THRESHOLDS[threshold])
    kinds = [item.kind for item in marks]

    good = np.isfinite(x).all(axis=(1, 2))
    pred = np.full(len(x), np.nan, dtype=np.float32)
    with torch.no_grad():
        pred[good] = model(torch.tensor(scaler.apply(x[good]))).numpy()

    distance = np.abs(np.arange(len(x))[:, None] - pivots[None, :]).min(axis=1)
    spans = vertex.zone_spans(y, stamps, pivots, kinds)

    # ті самі вікна, на яких модель училась: власний поділ датасету
    # перемішаний і для суцільного відрізку часу не годиться
    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    windows = {"train": fold.train, "val": fold.val, "test": fold.test}
    part = np.full(len(x), -1, dtype=np.int8)
    for index, (name, where) in enumerate(windows.items()):
        part[where] = index

    known = np.isfinite(y) & np.isfinite(pred)

    def score(mask):
        mask = mask & known
        return {**metrics(y[mask], pred[mask]),
                "events": int(mask.sum()),
                "vertex": vertex.vertices(y[mask], pred[mask],
                                          distance=distance[mask])}

    payload = {
        "pair": pair,
        "step": "видача моделі на всьому датасеті",
        "model": report["model"],
        "model_path": report["model_path"],
        "config": report["config"],
        "loss": report["rows"][0]["name"],
        "split": report["split"],
        "threshold": threshold,
        "target_kind": "ema",
        "target_leg": leg,
        "target_period": period,
        "target": report["target"],
        "scale": scale,
        "event_seconds": 210,
        "events": int(len(stamps)),
        "with_target": int(np.isfinite(y).sum()),
        "parts": {name: int(len(where)) for name, where in windows.items()},
        "bounds": report["bounds"],
        "period": {"from": int(stamps.min()), "to": int(stamps.max())},
        "price_range": [round(float(price.min()), 2),
                        round(float(price.max()), 2)],
        "zone": report["zone"],
        "zones": spans,
        "zone_events": int(sum(span["events"] for span in spans)),
        "metrics": {name: score(np.isin(np.arange(len(x)), where))
                    for name, where in windows.items()},
        "all": score(np.ones(len(x), dtype=bool)),
        "legs": max(len(marks) - 1, 0),
        "pivots": [{"t": int(stamps[item.index]),
                    "price": round(float(price[item.index]), 2),
                    "ema": round(float(smoothed[item.index]), 2),
                    "kind": item.kind} for item in marks],
        "t": [int(v) for v in stamps],
        "price": [round(float(v), 2) for v in price],
        "ema": [round(float(v), 2) for v in smoothed],
        "y": [None if not np.isfinite(v) else round(float(v), 4) for v in y],
        "p": [None if not np.isfinite(v) else round(float(v), 4) for v in pred],
        "part": [int(v) for v in part],
    }
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--run", default=DEFAULT_RUN,
                        help="звіт прогону, з якого береться модель")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.target, run=args.run, out=args.out)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"predict_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    name, _ = model_params(payload["config"])
    print(f"{payload['pair']} · {name} · {payload['events']} подій · "
          f"{payload['legs']} ніг · зон {len(payload['zones'])} "
          f"({payload['zone_events']} подій)")
    for part, item in {**payload["metrics"], "усе": payload["all"]}.items():
        hit = item["vertex"]["hits"]
        print(f"  {part:>5}: подій {item['events']} · MAE {item['mae']} · "
              f"знак {item['sign_accuracy']} · у зоні {hit['inside']}, "
              f"сказала {hit['said']}, влучань {hit['hits']} "
              f"({hit['recall']} з зони, точність {hit['precision']}) · "
              f"до межі {hit['to_edge']} · до вершини {hit['to_vertex']}")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
