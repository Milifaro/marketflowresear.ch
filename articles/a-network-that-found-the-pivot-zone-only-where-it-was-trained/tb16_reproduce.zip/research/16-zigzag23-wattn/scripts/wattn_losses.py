"""Розділ 2 вкладки: одна мережа `wattn` під штрафом за розмах.

Дослідження: research/16-zigzag23-wattn/ (розділ 2)
Правила: rules/03-models.md → Лосс: MSE і ваговий MSE

Модель тут одна — `wattn` (`nets.py`), і гріду немає: ручки стоять на
типових значеннях родини. Функція втрат теж одна, береться з переліку
вкладки «Навчання мережі» (`research/12-zigzag-net/scripts/losses.py`
→ `variants`):

    розмах        WMSE + λ·(σ_цілі − σ_прогнозу)²
    калібрування  WMSE, вихід розтягнутий коефіцієнтами train
    кореляція     1 − Пірсон, далі калібрування

Перелік `losses.variants` ширший: голий ваговий MSE, пінбол і
псевдо-Huber у цьому дослідженні не рахуються (`LOSSES`). Усі три, що
лишились, **ставлять розмах видачі** — прямо в лоссі, калібруванням або
відмовою штрафувати масштаб; саме це й міряє відстань до вершин.

Дані, розбиття по часу, скейлер фіч, seed і бюджет спільні для всіх
шести прогонів, тому рядки порівнюються між собою напряму.

До звичайних метрик у кожному рядку йде **відстань до вершин цілі**
(`vertex.py`): наскільки видача не доходить до −1 і +1 в околі вершини і
окремо — у **робочій зоні півота** (`|y| ≥ 0.90` і ±40 подій від півота,
`pivot_band.py`). Відстань кожної події до найближчого півота рахується
тут же, по тих самих індексах, що й вибірки.

Ваги моделі й скейлер її train зберігаються у
`models/wattn_2_3_spread_v1/` — ними далі рахується видача на всьому
датасеті (`predict.py`) і на невідомому відрізку (`fresh.py`).

Вихід: results/losses_wattn_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/wattn_losses.py --target 2.3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import nets  # noqa: E402  (родина `wattn`, іде окремим factory)
import split_time  # noqa: E402
import vertex  # noqa: E402
import walk_forward  # noqa: E402
from data import KINDS, LEGS, PICKED, SCALES  # noqa: E402
from losses import calibrated, calibration, variants  # noqa: E402
from train import SEED, distribution, metrics, number, predict  # noqa: E402
from walk_forward import MIN_GAP, fold_parts, human, merged, pivot_index  # noqa: E402

RESULTS = RESEARCH_DIR / "results"

# Спосіб штрафу цього дослідження — один: розмах стоїть у самому лоссі.
# Решта переліку `losses.variants` (голий WMSE, пост-калібрування,
# кореляційний, пінбол, псевдо-Huber) сюди не входить.
LOSSES = ("spread",)


def to_pivot(index: np.ndarray, pivots: np.ndarray) -> np.ndarray:
    """Відстань кожної події вибірки до найближчого півота, в подіях."""
    return np.abs(np.asarray(index)[:, None] - pivots[None, :]).min(axis=1)


def report_metrics(true, pred, distance=None) -> dict:
    """Метрики рядка: стандартні плюс відстань до вершин цілі."""
    return {**metrics(true, pred),
            "vertex": vertex.vertices(true, pred, distance=distance)}


def build(pair: str = "BTC_USDT", threshold: str = "2.3", epochs: int | None = None,
          config: dict | None = None, patience: int | None = None,
          root: Path | None = None, kind: str = "ema", scale: str = "quantile",
          leg: str = "minmax", log=print) -> dict:
    """Шість прогонів `wattn` на одному розбитті: різниця лише в лоссі."""
    import torch

    config = dict(config or nets.CONFIG)
    patience = nets.PATIENCE if patience is None else patience
    epochs = nets.EPOCHS if epochs is None else epochs
    period = walk_forward.target_period(threshold, kind)
    x, y, stamps, price = merged(pair, threshold, period, root, kind, leg)
    pivots = pivot_index(price, period, threshold, kind)
    alpha = config.get("alpha", 0.0)
    beta = config.get("beta", 1.0)
    log(f"[1/3] {config['model']} {config['params']} lr {config['lr']}, "
        f"α {alpha}, β {beta}, терпіння {patience}, епох {epochs}")

    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    parts, scaler = fold_parts(fold, x, y, scale)
    # `timestamp` вибірки — це індекси подій у спільному ряду, тому
    # відстань до півота рахується по них напряму
    gaps = {name: to_pivot(part.timestamp, pivots)
            for name, part in parts.items()}
    log(f"[2/3] розбиття по часу: {fold.sizes()}, викинуто у проміжки "
        f"{fold.dropped}")

    tensors, rows = {}, []
    kinds = [item for item in variants(alpha, beta) if item.id in LOSSES]
    for index, variant in enumerate(kinds, 1):
        params = dict(config["params"])
        if variant.outputs > 1:
            params["outputs"] = variant.outputs
        run_report, model = walk_forward.run(
            config["model"], parts, epochs=epochs, lr=config["lr"],
            params=params, patience=patience, seed=SEED,
            loss=variant.loss, point=variant.point, factory=nets.FACTORY,
            loss_title=variant.name, log=lambda *args: None)
        device = run_report["device"]
        if not tensors:
            tensors = {name: torch.tensor(part.x, device=device)
                       for name, part in parts.items()}
        point = variant.point or (lambda pred: pred)
        pred = {name: point(predict(model, tensors[name])) for name in parts}
        fit = calibration(pred["train"], parts["train"].y) \
            if variant.calibrate else None
        if fit is not None:
            pred = {name: calibrated(values, fit)
                    for name, values in pred.items()}
        folder = (RESEARCH_DIR / "models"
                  / f"{config['model']}_{threshold.replace('.', '_')}"
                    f"_{variant.id}_v1")
        folder.mkdir(parents=True, exist_ok=True)
        torch.save(model.state_dict(), folder / "model.pt")
        scaler.save(folder / "scaler.npz")
        rows.append({
            "id": variant.id,
            "model_path": str(folder.relative_to(PROJECT_ROOT)),
            "name": variant.name,
            "formula": variant.formula,
            "note": variant.note,
            "params": variant.params,
            "outputs": variant.outputs,
            "calibration": fit,
            "best_epoch": run_report["best_epoch"],
            "parameters": run_report["parameters"],
            "seconds": run_report["seconds"],
            "metrics": {name: report_metrics(parts[name].y, pred[name],
                                             gaps[name])
                        for name in ("train", "val", "test")},
            "spread": {"pred": number(np.std(pred["test"])),
                       "true": number(np.std(parts["test"].y)),
                       "ratio": number(np.std(pred["test"])
                                       / max(float(np.std(parts["test"].y)),
                                             1e-9))},
            "distribution": distribution(pred["test"]),
        })
        test = rows[-1]["metrics"]["test"]
        top = vertex.main_row(test["vertex"])["both"]
        band = test["vertex"]["zone"]["both"]
        log(f"      {index}/{len(kinds)} {variant.name}: test MAE "
            f"{test['mae']}, R² {test['r2']}, Пірсон {test['pearson']}, "
            f"знак {test['sign_accuracy']}, до вершин {top['gap_pred']}, "
            f"у зоні {band['gap_pred']} ({band['events']} подій), "
            f"σ {rows[-1]['spread']['ratio']} від цілі, "
            f"{run_report['seconds']} с")

    constant = np.full(len(parts["test"].y), float(parts["train"].y.mean()))
    report = {
        "pair": pair,
        "threshold": threshold,
        "target_kind": kind,
        "target_leg": leg,
        "target_period": period,
        "target": walk_forward.target_title(threshold, kind, leg),
        "scale": scale,
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "step": "функція втрат: один спосіб штрафу — один прогін",
        "model": config["model"],
        "config": config,
        "patience": patience,
        "epochs": epochs,
        "seed": SEED,
        "events": {name: len(part) for name, part in parts.items()},
        "bounds": {name: {"from_utc": human(stamps[idx[0]]),
                          "to_utc": human(stamps[idx[-1]])}
                   for name, idx in (("train", fold.train), ("val", fold.val),
                                     ("test", fold.test))},
        "test_legs": split_time.legs_between(pivots, int(fold.test[0]),
                                             int(fold.test[-1]) + 1),
        "constant": report_metrics(parts["test"].y, constant, gaps["test"]),
        "true": distribution(parts["test"].y),
        "vertex_bands": list(vertex.BANDS),
        "vertex_main": vertex.MAIN,
        "model_path": None,      # заповнюється нижче: модель у прогону одна
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW,
                 "note": ("робоча зона півота: |y| >= "
                          f"{1 - vertex.BAND:.2f} і ±{vertex.WINDOW} подій "
                          "від півота (pivot_band.py)")},
        "rows": rows,
    }
    report["model_path"] = rows[0]["model_path"] if len(rows) == 1 else None
    best = min(rows, key=lambda item: item["metrics"]["test"]["mae"])
    closest = min(rows, key=lambda item: vertex.main_row(
        item["metrics"]["test"]["vertex"])["both"]["gap_pred"])
    log(f"[3/3] найменший MAE: {best['name']} "
        f"({best['metrics']['test']['mae']}), найближче до вершин: "
        f"{closest['name']} ("
        f"{vertex.main_row(closest['metrics']['test']['vertex'])['both']['gap_pred']}"
        f"), константа {report['constant']['mae']}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(PICKED))
    parser.add_argument("--epochs", type=int, default=nets.EPOCHS)
    parser.add_argument("--kind", default="ema", choices=KINDS)
    parser.add_argument("--scale", default="quantile",
                        choices=tuple(s for s in SCALES if s != "none"))
    parser.add_argument("--leg", default="minmax", choices=LEGS)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target, epochs=args.epochs,
                   kind=args.kind, scale=args.scale, leg=args.leg)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"losses_{report['model']}_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
