"""Невідомий відрізок: модель на даних, яких не бачив ніхто.

Дослідження: research/16-zigzag23-wattn/ (розділ 2)

Датасет навчання закінчується **2026-08-16 19:51 UTC**. Тут береться те,
що після нього: сирі CSV нарізаються тим самим ланцюгом класів, що й
датасет, і подаються на збережену модель тим самим скейлером train
(`holdout.py` дослідження 12 — той самий ланцюг):

    CSV -> клас210х8 -> клас210х14х5 -> клас210х14х3
        -> клас210х14х4ц -> клас210х210х4ц -> клас210х4бема10х10х130

Ціль будується так само, як у навчанні: `ема90(ціна) -> півоти зігзага
2.3% -> нормована нога` (розподіл). Якщо модель училась на **згладженій**
цілі (`--run final_...`, поле `way`), тут вона згладжується тим самим
способом і з тими самими зонами (`smooth.apply_way`).

Вхід теж береться зі звіту: одна подія або **вікно з K подій** — тоді
вікна будуються тими самими правилами, що в розділі 3 (тільки події
підряд).

**Розігрів.** ЕМА і зігзаг дивляться назад, тому ланцюг рахується
з `--warmup-from`, а у вихід іде тільки вікно `--from … --to`.

**Заповнення пропусків.** Модель, навчена на датасеті `*_fill`, і тут
дивиться на заповнений ряд: секунди без угод відновлюються тим самим
`fill_gaps` і тим самим `MAX_GAP`, що й у датасеті (`rules/01-data-and-db.md`
→ Пропуски часу). Без цього довге вікно майже не збирається: при K = 45
на сирому відрізку виходить 79 вікон замість двох з половиною тисяч.

Разом з рядами йдуть **зони півотів** цього відрізка і метрики влучання
в них (`vertex.py`).

Вихід: results/fresh_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/fresh.py \\
        --from '2026-08-16 20:00' --to '2026-08-27 00:00'
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x14x3  # noqa: E402
import class210x14x4  # noqa: E402
import class210x14x4c  # noqa: E402
import class210x14x5  # noqa: E402
import class210x210x4c  # noqa: E402
import class210x4bema10x10x130 as klass  # noqa: E402
import class210x8  # noqa: E402
import fill_gaps  # noqa: E402
import smooth  # noqa: E402
import vertex  # noqa: E402
import windows as window_step  # noqa: E402
import zigzag_targets  # noqa: E402
from data import PICKED  # noqa: E402
from data_source import copy_to_work, load_day, to_array  # noqa: E402
from holdout import events, human, pivots_of, source_files, stamp  # noqa: E402
import nets  # noqa: E402
from saved import load_model  # noqa: E402
from train import metrics  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
WORK_ROOT = PROJECT_ROOT / "data"
DEFAULT_RUN = "losses_wattn"
# Датасет навчання закінчується 2026-08-16 19:51 UTC — беремо все після.
DEFAULT_FROM = "2026-08-16 20:00"
DEFAULT_TO = "2026-08-27 00:00"
DEFAULT_WARMUP = "2026-08-01 00:00"


def events_filled(files, step: int = class210x8.EVENT_LENGTH,
                  max_gap: int = fill_gaps.MAX_GAP, log=print):
    """Той самий ланцюг класів, що в `holdout.events`, але з заповненням.

    Пропуски секунд заповнюються **у кожному добовому файлі окремо** —
    рівно так, як їх заповнює `build_class210x14x5.py` при побудові
    датасету `*_fill`.
    """
    bases, prices, stamps, holes = [], [], [], 0
    for index, path in enumerate(files, 1):
        frame, _ = load_day(path)
        rows, report = fill_gaps.fill(to_array(frame), max_gap)
        holes += report.seconds_filled
        bases.append(class210x8.build(rows, step=step))
        block, ts = class210x14x4c.from_rows(rows, step)
        if len(ts):
            prices.append(block)
            stamps.append(ts)
        if index % 10 == 0 or index == len(files):
            log(f"      {index}/{len(files)} файлів, "
                f"подій: {sum(len(b) for b in bases)}, "
                f"заповнено секунд: {holes}")

    base = class210x8.concat(bases)
    keep, _ = class210x14x4.build(base)
    alive = np.isin(base.timestamp, keep.timestamp)
    base = class210x8.Class210x8(
        x=base.x[alive], timestamp=base.timestamp[alive],
        price_open=base.price_open[alive], price_close=base.price_close[alive])
    five, _ = class210x14x5.build(base)
    three, _ = class210x14x3.build(five)
    four, _ = class210x14x4c.build(three, np.concatenate(prices),
                                   np.concatenate(stamps))
    mean, _ = class210x210x4c.build(four)
    order = np.argsort(mean.timestamp, kind="stable")
    mean = class210x210x4c.Class210x210x4c(
        x=mean.x[order], timestamp=mean.timestamp[order],
        price_open=mean.price_open[order], price_close=mean.price_close[order])
    dataset, _ = klass.build(mean, klass.PERIODS)
    targets = zigzag_targets.build(mean.price_open, mean.timestamp,
                                   klass.PERIODS)
    return (dataset, targets.y, np.asarray(mean.price_open, dtype=float),
            targets.periods, holes)


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          begin: str = DEFAULT_FROM, end: str = DEFAULT_TO,
          warmup: str = DEFAULT_WARMUP, source_root: Path | None = None,
          work_root: Path | None = None, run: str = DEFAULT_RUN,
          out: Path | None = None, fill: bool | None = None,
          log=print) -> dict:
    out = out or RESULTS
    first, last, warm = stamp(begin), stamp(end), stamp(warmup)
    period = PICKED[threshold]
    tail = threshold.replace(".", "_")
    report = json.loads((out / f"{run}_{tail}.json").read_text(encoding="utf-8"))

    files = source_files(pair, warm, last, source_root)
    if not files:
        raise SystemExit(f"немає файлів {pair} на {begin} .. {end}")
    copied = copy_to_work(files, root=source_root, work_root=work_root)
    log(f"[1/4] робоча копія: {len(copied)} файлів "
        f"({copied[0].name} .. {copied[-1].name})")

    # модель, навчена на *_fill, і тут дивиться на заповнений ряд
    if fill is None:
        fill = str(report.get("pair", "")).endswith("_fill")
    if fill:
        dataset, y_all, prices, periods, holes = events_filled(copied, log=log)
    else:
        dataset, y_all, prices, periods = events(copied, kind="ema", log=log)
        holes = 0
    log(f"[2/4] ланцюг класів: {len(dataset)} подій з розігрівом "
        f"({human(dataset.timestamp[0])} .. {human(dataset.timestamp[-1])})"
        + (f", заповнено секунд {holes}" if fill else ""))

    marks, smoothed = pivots_of(prices, period, threshold, "ema")
    inside = (dataset.timestamp >= first) & (dataset.timestamp < last)
    if not inside.any():
        raise SystemExit(f"у вікні {begin} .. {end} немає подій")

    k = int(report.get("k") or 1)
    model, scaler = load_model(report, PROJECT_ROOT,
                               factory=nets.window_factory(k) if k > 1
                               else None)
    x = np.asarray(dataset.x[inside], dtype=np.float32)

    column = periods.index(period)
    row = list(THRESHOLDS).index(threshold)
    target = y_all[inside, column, row]
    stamps = dataset.timestamp[inside]

    # зони й відстані рахуються по півотах усередині вікна
    window_pivots = [pivot for pivot in marks
                     if first <= dataset.timestamp[pivot.index] < last]
    place = {int(value): index for index, value in enumerate(stamps)}
    pivots = np.array([place[int(dataset.timestamp[pivot.index])]
                       for pivot in window_pivots], dtype=int)
    kinds = [pivot.kind for pivot in window_pivots]
    if len(pivots):
        distance = np.abs(np.arange(len(stamps))[:, None]
                          - pivots[None, :]).min(axis=1)
        spans = vertex.zone_spans(target, stamps, pivots, kinds)
    else:
        distance, spans = np.full(len(stamps), 10 ** 9), []

    # ціль згладжується так само, як у навчанні
    way = report.get("way")
    if way:
        kind, size = smooth.way_of(way)
        zone = np.zeros(len(target), dtype=bool)
        for span in spans:
            zone[place[span["from"]]:place[span["to"]] + 1] = True
        if len(pivots) > 1:
            target = smooth.apply_way(target, pivots, zone, kind, size)

    pred = np.full(len(x), np.nan, dtype=np.float32)
    if k > 1:
        ends = window_step.window_ends(stamps, k)
        block = window_step.stack(x, ends, k)
        alive = np.isfinite(block).all(axis=(1, 2, 3))
        ends, block = ends[alive], block[alive]
        with torch.no_grad():
            shape = block.shape
            scaled = scaler.apply(block.reshape(-1, *x.shape[1:]))
            pred[ends] = model(torch.tensor(
                scaled.reshape(shape))).numpy()
        log(f"[3/4] прогін моделі: вікон K={k} — {len(ends)} з {len(x)} подій")
    else:
        good = np.isfinite(x).all(axis=(1, 2))
        with torch.no_grad():
            pred[good] = model(torch.tensor(scaler.apply(x[good]))).numpy()
        log(f"[3/4] прогін моделі: {int(good.sum())} подій з {len(x)}")

    known = np.isfinite(target) & np.isfinite(pred)
    payload = {
        "pair": pair,
        "step": "невідомий відрізок: дані після кінця датасету",
        "model": report["model"],
        "model_path": report["model_path"],
        "config": report["config"],
        "k": k,
        "way": way,
        "run": run,
        "filled": bool(fill),
        "filled_seconds": int(holes),
        "loss": report.get("loss") or report["rows"][0]["name"],
        "split": report["split"],
        "threshold": threshold,
        "target_kind": "ema",
        "target_leg": report["target_leg"],
        "target_period": period,
        "target": report["target"],
        "scale": report["scale"],
        "event_seconds": class210x8.EVENT_LENGTH,
        "window": {"from": first, "to": last,
                   "from_utc": human(first), "to_utc": human(last)},
        "warmup": {"from": warm, "from_utc": human(warm),
                   "events": int((~inside).sum())},
        # кінець того, що модель бачила: test, а де його немає — val
        "seen": {"to_utc": (report["bounds"].get("test")
                            or report["bounds"]["val"])["to_utc"],
                 "note": "модель не бачила жодної події цього вікна"},
        "files": [path.name for path in copied],
        "events": int(inside.sum()),
        "with_target": int(np.isfinite(target).sum()),
        "predicted": int(np.isfinite(pred).sum()),
        "period": {"from": int(stamps.min()), "to": int(stamps.max()),
                   "from_utc": human(stamps.min()),
                   "to_utc": human(stamps.max())},
        "price_range": [round(float(np.nanmin(dataset.price_open[inside])), 2),
                        round(float(np.nanmax(dataset.price_open[inside])), 2)],
        "zone": report["zone"],
        "zones": spans,
        "zone_events": int(sum(span["events"] for span in spans)),
        "metrics": {**metrics(target[known], pred[known]),
                    "events": int(known.sum()),
                    "vertex": vertex.vertices(target[known], pred[known],
                                              distance=distance[known])},
        "legs": max(len(window_pivots) - 1, 0),
        "pivots": [{"t": int(dataset.timestamp[pivot.index]),
                    "price": round(float(prices[pivot.index]), 2),
                    "ema": round(float(smoothed[pivot.index]), 2),
                    "kind": pivot.kind} for pivot in window_pivots],
        "t": [int(v) for v in stamps],
        "price": [round(float(v), 2) for v in dataset.price_open[inside]],
        "ema": [round(float(v), 2) for v in smoothed[inside]],
        "y": [None if not np.isfinite(v) else round(float(v), 4)
              for v in target],
        "p": [None if not np.isfinite(v) else round(float(v), 4) for v in pred],
    }
    hit = payload["metrics"]["vertex"]["hits"]
    log(f"[4/4] у вікні {payload['events']} подій, з ціллю "
        f"{payload['with_target']}, півотів {len(payload['pivots'])}, зон "
        f"{len(spans)} ({payload['zone_events']} подій); влучань "
        f"{hit['hits']} з {hit['inside']}, сказала {hit['said']}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--from", dest="begin", default=DEFAULT_FROM)
    parser.add_argument("--to", dest="end", default=DEFAULT_TO)
    parser.add_argument("--warmup-from", dest="warmup", default=DEFAULT_WARMUP)
    parser.add_argument("--run", default=DEFAULT_RUN)
    parser.add_argument("--fill", dest="fill", action="store_true",
                        default=None, help="заповнювати пропуски секунд")
    parser.add_argument("--no-fill", dest="fill", action="store_false",
                        help="брати відрізок як є")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.target, args.begin, args.end, args.warmup,
                    run=args.run, out=args.out, fill=args.fill)
    args.out.mkdir(parents=True, exist_ok=True)
    tag = "" if args.run == DEFAULT_RUN else f"_{args.run}"
    path = args.out / f"fresh{tag}_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    item = payload["metrics"]
    print(f"{payload['window']['from_utc']} … {payload['window']['to_utc']}: "
          f"MAE {item['mae']} · знак {item['sign_accuracy']} · "
          f"Пірсон {item['pearson']}")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
