"""Згладжування цілі між зонами півотів.

Дослідження: research/16-zigzag23-wattn/ (розділ 1)
Правила: rules/02-markup.md → Нормований зігзаг

Усередині зони півота ціль має лишитись такою, як є: саме там `−1` і
`+1`, і саме туди модель має влучати. А от **між зонами** — на середині
ноги — ціль смикається слідом за кожним відкотом ціни, і ці коливання
модель вчить нарівні з рухом. Тут вони гасяться.

Правила згладжування:

1. **зони недоторкані** — події з `|y| >= 0.90` і не далі за ±40 подій
   від півота (`vertex.BAND`, `vertex.WINDOW`) лишаються без змін;
2. **нога не перетікає в ногу** — кожен рух між сусідніми півотами
   згладжується окремо, тому вершина не розмивається;
3. **межі лишаються** — ряд не виходить за `[-1, 1]`, події поза
   зігзагом лишаються `NaN`.

Способи (`WAYS`):

    сер<w>   ковзне середнє вікна w, центроване
    мед<w>   ковзна медіана вікна w, центрована
    ема<p>   ЕМА періоду p по нозі, причинна
    пряма    лінійна вставка між краями зон: коливань немає взагалі

Коливання міряються **між зонами**, і саме коливання, а не рух: крок
`|Δy|` майже весь складається з ходу ноги, тому головна мірка тут —
**шорсткість**, друга різниця ряду:

    rough  середнє |y[i−1] − 2·y[i] + y[i+1]| — зигзагоподібність
    back   середній крок **проти** напрямку ноги: відкоти
    turns  частка розворотів: скільки разів Δy міняє знак
    step   середнє |y[i] − y[i−1]| — для повноти, він майже не падає

Разом з ними — звʼязок з фічами (макс і середня |r| на train): гасити
коливання має сенс, поки ціль не втрачає звʼязок із входом.

Вихід: results/smooth_2_3.json (і smooth_fill_2_3.json для датасету із
заповненими пропусками); поруч .npz з самими рядами

Запуск:
    python3 research/16-zigzag23-wattn/scripts/smooth.py --target 2.3
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

import class210x4bema10x10x130 as klass  # noqa: E402
import vertex  # noqa: E402
import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from correlation import pearson  # noqa: E402
from data import DATASET, PICKED  # noqa: E402
from legs import LEG_USED, prices_of  # noqa: E402
from leg_pick import PART, rows_of  # noqa: E402
from train import number  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
# Способи згладжування: ім'я -> (вид, параметр)
WAYS = (("сер9", "mean", 9), ("сер21", "mean", 21), ("сер41", "mean", 41),
        ("мед9", "median", 9), ("мед21", "median", 21), ("мед41", "median", 41),
        ("ема10", "ema", 10), ("ема20", "ema", 20), ("ема40", "ema", 40),
        ("пряма", "line", 0))
# Наскільки коливання мають впасти, щоб спосіб узагалі розглядався.
NEEDED = 2.0


def way_of(name: str) -> tuple[str, int]:
    """Спосіб згладжування за іменем: `ема20` -> ("ema", 20)."""
    for item, kind, size in WAYS:
        if item == name:
            return kind, size
    raise SystemExit(f"невідомий спосіб згладжування: {name}")


def centred(values: np.ndarray, width: int, kind: str) -> np.ndarray:
    """Центроване вікно: середнє або медіана, краї рахуються по обрізаному."""
    out = np.empty(len(values))
    half = width // 2
    for index in range(len(values)):
        lo = max(index - half, 0)
        hi = min(index + half + 1, len(values))
        piece = values[lo:hi]
        out[index] = piece.mean() if kind == "mean" else np.median(piece)
    return out


def smooth_leg(values: np.ndarray, keep: np.ndarray, kind: str,
               size: int) -> np.ndarray:
    """Одна нога: згладжується тільки те, що поза зонами (`keep` — зона)."""
    out = values.copy()
    if kind == "line":
        free = np.flatnonzero(~keep)
        if not len(free):
            return out
        first, last = free[0], free[-1]
        left = values[first - 1] if first > 0 else values[first]
        right = values[last + 1] if last + 1 < len(values) else values[last]
        out[first:last + 1] = np.linspace(left, right, last - first + 1)
        return out
    if kind == "ema":
        smoothed = ema(values, size)
    else:
        smoothed = centred(values, size, kind)
    out[~keep] = smoothed[~keep]
    return out


def apply_way(values: np.ndarray, pivots: np.ndarray, zone: np.ndarray,
              kind: str, size: int) -> np.ndarray:
    """Згладжування по ногах: між сусідніми півотами, зони недоторкані."""
    out = values.copy()
    edges = list(pivots)
    for start, stop in zip(edges, edges[1:]):
        piece = slice(start, stop + 1)
        good = np.isfinite(values[piece])
        if good.sum() < 3:
            continue
        out[piece] = smooth_leg(values[piece], zone[piece] | ~good, kind, size)
    return np.clip(out, -1.0, 1.0)


EMPTY = {"step": None, "rough": None, "back": None, "turns": None}


def wiggle(values: np.ndarray, free: np.ndarray) -> dict:
    """Коливання ряду між зонами: шорсткість, відкоти, розвороти, крок."""
    where = np.flatnonzero(free)
    if len(where) < 3:
        return {"events": int(len(where)), **EMPTY}
    steps, rough, back, turns, count = [], [], [], 0, 0
    runs = np.split(where, np.flatnonzero(np.diff(where) > 1) + 1)
    for run in runs:
        piece = values[run]
        piece = piece[np.isfinite(piece)]
        if len(piece) < 3:
            continue
        delta = np.diff(piece)
        steps.append(np.abs(delta))
        rough.append(np.abs(piece[:-2] - 2 * piece[1:-1] + piece[2:]))
        way = np.sign(piece[-1] - piece[0]) or 1.0
        back.append(np.abs(delta[np.sign(delta) == -way]))
        sign = np.sign(delta)
        turns += int((sign[1:] * sign[:-1] < 0).sum())
        count += len(delta) - 1
    if not steps:
        return {"events": int(len(where)), **EMPTY}
    back = np.concatenate(back) if any(len(item) for item in back) \
        else np.zeros(1)
    return {
        "events": int(len(where)),
        "step": number(np.concatenate(steps).mean(), 5),
        "rough": number(np.concatenate(rough).mean(), 6),
        "back": number(back.mean(), 5),
        "turns": number(turns / max(count, 1), 4),
    }


def link(values: np.ndarray, index: np.ndarray, rows) -> dict:
    """Звʼязок цілі з 52 фічами класу на train: макс і середня |r|."""
    picked = values[index]
    scores = [abs(pearson(series, picked)) for _, series in rows]
    best = max(range(len(rows)), key=lambda i: scores[i])
    return {"max_abs": number(max(scores)),
            "mean_abs": number(float(np.mean(scores))),
            "best_feature": rows[best][0]}


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          root: Path | None = None, leg: str = LEG_USED,
          ways=WAYS, part: str = PART, needed: float = NEEDED) -> dict:
    period = PICKED[threshold]
    price, stamps = prices_of(pair, root)
    smoothed_price = ema(price, period)
    marks = zigzag(smoothed_price, THRESHOLDS[threshold])
    pivots = np.array([item.index for item in marks], dtype=int)
    kinds = [item.kind for item in marks]
    values = zigzag_targets.build(price, stamps, periods=[period],
                                  scaler=leg).column(period, threshold)

    # зона півота — та сама, що в метриці
    spans = vertex.zone_spans(values, stamps, pivots, kinds)
    place = {int(value): index for index, value in enumerate(stamps)}
    zone = np.zeros(len(values), dtype=bool)
    for span in spans:
        zone[place[span["from"]]:place[span["to"]] + 1] = True
    inside_legs = np.zeros(len(values), dtype=bool)
    inside_legs[pivots[0]:pivots[-1] + 1] = True
    free = inside_legs & ~zone & np.isfinite(values)

    dataset = klass.load((root or DATASET) / pair
                         / "class210x4bema10x10x130" / f"{part}.npz")
    index = np.array([place[int(value)] for value in dataset.timestamp])
    rows = rows_of(dataset)

    base_wiggle = wiggle(values, free)
    base_link = link(values, index, rows)
    report = {
        "pair": pair,
        "threshold": threshold,
        "target_period": period,
        "leg": leg,
        "target": f"зігзаг {threshold} нормований, ема{period}",
        "part": part,
        "events": int(len(values)),
        "with_target": int(np.isfinite(values).sum()),
        "pivots": int(len(pivots)),
        "legs": int(max(len(pivots) - 1, 0)),
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW},
        "zone_events": int(zone.sum()),
        "free_events": int(free.sum()),
        "needed": needed,
        "raw": {"id": "сирий", "kind": "none", "size": 0,
                "wiggle": base_wiggle, "link": base_link,
                "rough_ratio": 1.0, "back_ratio": 1.0, "turns_ratio": 1.0},
        "rows": [],
        "series": {},
    }
    for name, kind, size in ways:
        out = apply_way(values, pivots, zone, kind, size)
        assert np.allclose(out[zone], values[zone], equal_nan=True)
        item = wiggle(out, free)
        ratio = lambda key: (  # noqa: E731
            number(base_wiggle[key] / item[key], 3) if item[key] else None)
        report["rows"].append({
            "id": name, "kind": kind, "size": size,
            "wiggle": item,
            "link": link(out, index, rows),
            "rough_ratio": ratio("rough"),
            "back_ratio": ratio("back"),
            "turns_ratio": ratio("turns"),
            "step_ratio": ratio("step"),
            "zone_kept": True,
        })
        report["series"][name] = out

    good = [row for row in report["rows"]
            if (row["rough_ratio"] or 0) >= needed]
    order = sorted(good, key=lambda row: -row["link"]["max_abs"])
    report["picked"] = [row["id"] for row in order[:2]]
    report["picked_by"] = (f"коливання впали щонайменше в {needed} рази, "
                           "далі — найбільший звʼязок з фічами на train")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    report = build(args.pair, args.target)
    series = report.pop("series")
    args.out.mkdir(parents=True, exist_ok=True)
    tag = "_fill" if args.pair.endswith("_fill") else ""
    path = args.out / f"smooth{tag}_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    np.savez_compressed(path.with_suffix(".npz"),
                        **{name: values.astype(np.float32)
                           for name, values in series.items()})

    base = report["raw"]
    print(f"{report['pair']} · {report['target']} · між зонами "
          f"{report['free_events']} подій із {report['events']}")
    цифра = lambda value, form: (  # noqa: E731
        "—".rjust(int(form.split(".")[0])) if value is None
        else format(value, form))
    print(f"{'спосіб':>8} | {'шорсткість':>10} | {'падіння':>7} | "
          f"{'відкоти':>8} | {'падіння':>7} | {'розвороти':>9} | "
          f"{'падіння':>7} | {'макс |r|':>8} | {'сер |r|':>7}")
    for row in (base, *report["rows"]):
        mark = " ←" if row["id"] in report["picked"] else ""
        item = row["wiggle"]
        print(f"{row['id']:>8} | {цифра(item['rough'], '10.6f')} | "
              f"{цифра(row['rough_ratio'], '7.2f')} | "
              f"{цифра(item['back'], '8.5f')} | "
              f"{цифра(row['back_ratio'], '7.2f')} | "
              f"{цифра(item['turns'], '9.4f')} | "
              f"{цифра(row['turns_ratio'], '7.2f')} | "
              f"{row['link']['max_abs']:>8.4f} | "
              f"{row['link']['mean_abs']:>7.4f}{mark}")
    print(f"обрано: {', '.join(report['picked'])} — {report['picked_by']}")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
