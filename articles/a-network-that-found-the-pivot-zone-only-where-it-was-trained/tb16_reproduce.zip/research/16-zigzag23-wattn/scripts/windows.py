"""Пачка подій на вхід: вікно з K подій поспіль, K = 5 … 50.

Дослідження: research/16-zigzag23-wattn/ (розділ 3)
Правила: rules/03-models.md → Розбиття даних → Розбиття по часу

Досі модель бачила **одну** подію: `(13, 4)`. Тут на вхід іде вікно з K
подій поспіль — `(K, 13, 4)` — а ціль лишається ціллю **останньої**
події вікна. Модель та сама, `wattn`, але увага тепер по осі подій
(`nets.WindowAttn`), і штраф той самий — за розмах.

## Витік даних

Вікно тягне за собою минуле, тому воно небезпечніше за одну подію.
Захист тут потрійний:

1. **вікно не перестрибує розриви** — усі K подій мають іти рівно через
   `STEP` секунд одна за одною, інакше вікно не будується;
2. **вікно цілком лежить в одній вибірці** — якщо хоч одна його подія
   з train, вікно не може потрапити ні у val, ні в test. Вікна, що
   перетинають межу, викидаються, і скільки саме — у звіті
   (`crossing`);
3. **проміжок між вибірками ріжеться по півотах** (`split_time`,
   `MIN_GAP = 130` подій) — він утричі довший за найдовше вікно (50),
   тому навіть у межах проміжку вікно не дотягується до сусідньої
   вибірки.

Скейлер фіч рахується **тільки на подіях train** і застосовується до
всіх вікон — так само, як в одноподієвому прогоні.

У сирому датасеті довгі відрізки без розривів рідкісні, тому той самий
перебір робиться ще й на датасеті **із заповненими пропусками часу**
(`BTC_USDT_fill`, `rules/01-data-and-db.md` → Пропуски часу): там вікно
з 50 подій мають 77 % подій проти 2 % у сирому.

Вихід: results/windows_2_3.json (сирий датасет) і
results/windows_fill_2_3.json (із заповненими пропусками).

Запуск:
    python3 research/16-zigzag23-wattn/scripts/windows.py --target 2.3
    python3 research/16-zigzag23-wattn/scripts/windows.py --target 2.3 \
        --pair BTC_USDT_fill
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import nets  # noqa: E402
import split_time  # noqa: E402
import vertex  # noqa: E402
import walk_forward  # noqa: E402
from data import Part, fit_scaler  # noqa: E402
from losses import calibrated, calibration, variants  # noqa: E402
from train import SEED, distribution, metrics, number, predict  # noqa: E402
from walk_forward import MIN_GAP, human, merged, pivot_index  # noqa: E402
from wattn_losses import LOSSES, to_pivot  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
STEP = 210                      # секунд між сусідніми подіями
SIZES = (5, 10, 15, 20, 25, 30, 35, 40, 45, 50)


def runs_of(stamps: np.ndarray, step: int = STEP) -> np.ndarray:
    """Скільки подій поспіль (без розривів) закінчується кожною подією."""
    run = np.ones(len(stamps), dtype=np.int32)
    for index in range(1, len(stamps)):
        if stamps[index] - stamps[index - 1] == step:
            run[index] = run[index - 1] + 1
    return run


def window_ends(stamps: np.ndarray, k: int, step: int = STEP) -> np.ndarray:
    """Індекси подій, якими закінчується повне вікно з K подій поспіль."""
    return np.flatnonzero(runs_of(stamps, step) >= k)


def parts_of(fold, ends: np.ndarray, k: int) -> tuple[dict, dict]:
    """Розкладка вікон по вибірках: вікно цілком лежить в одній із них.

    Повертає індекси кінців вікон по вибірках і скільки вікон викинуто
    через те, що вони перетинали межу вибірки.
    """
    picked, crossing = {}, {}
    for name, index in (("train", fold.train), ("val", fold.val),
                        ("test", fold.test)):
        lo, hi = int(index[0]), int(index[-1])
        inside = ends[(ends >= lo) & (ends <= hi)]
        whole = inside[inside - (k - 1) >= lo]
        picked[name] = whole
        crossing[name] = int(len(inside) - len(whole))
    return picked, crossing


def stack(x: np.ndarray, ends: np.ndarray, k: int) -> np.ndarray:
    """Вікна `(N, K, 13, 4)`: по K подій поспіль, остання — подія вікна."""
    offsets = np.arange(-(k - 1), 1)
    return x[ends[:, None] + offsets[None, :]]


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          sizes=SIZES, epochs: int | None = None, patience: int | None = None,
          root: Path | None = None, scale: str = "quantile",
          leg: str = "minmax", config: dict | None = None,
          log=print) -> dict:
    """Один прогін на кожне K: дані, штраф і seed спільні, різне лише вікно."""
    import torch

    config = dict(config or nets.CONFIG)
    patience = nets.PATIENCE if patience is None else patience
    epochs = nets.EPOCHS if epochs is None else epochs
    period = walk_forward.target_period(threshold, "ema")
    x, y, stamps, price = merged(pair, threshold, period, root, "ema", leg)
    pivots = pivot_index(price, period, threshold, "ema")
    fold = split_time.chronological(len(x), pivots, min_gap=MIN_GAP)
    alpha = config.get("alpha", 0.0)
    beta = config.get("beta", 1.0)
    variant = next(item for item in variants(alpha, beta)
                   if item.id == LOSSES[0])
    log(f"[1/2] {config['params']} lr {config['lr']}, штраф {variant.name}, "
        f"розбиття {fold.sizes()}, проміжки {fold.dropped}")

    rows = []
    for k in sizes:
        ends = window_ends(stamps, k)
        picked, crossing = parts_of(fold, ends, k)
        parts = {}
        for name, where in picked.items():
            good = where[np.isfinite(y[where])
                         & np.isfinite(stack(x, where, k)).all(axis=(1, 2, 3))]
            parts[name] = Part(x=stack(x, good, k),
                               y=y[good].astype(np.float32),
                               timestamp=good, price_open=good,
                               price_close=good)
        scaler = fit_scaler(parts["train"].x.reshape(-1, *x.shape[1:]), scale)
        for part in parts.values():
            shape = part.x.shape
            part.x = scaler.apply(part.x.reshape(-1, *x.shape[1:])).reshape(shape)

        run_report, model = walk_forward.run(
            config["model"], parts, epochs=epochs, lr=config["lr"],
            params=dict(config["params"]), patience=patience, seed=SEED,
            loss=variant.loss, point=variant.point,
            factory=nets.window_factory(k), loss_title=variant.name,
            log=lambda *args: None)
        device = run_report["device"]
        pred = {name: predict(model, torch.tensor(part.x, device=device))
                for name, part in parts.items()}
        fit = calibration(pred["train"], parts["train"].y) \
            if variant.calibrate else None
        if fit is not None:
            pred = {name: calibrated(values, fit)
                    for name, values in pred.items()}
        gaps = {name: to_pivot(part.timestamp, pivots)
                for name, part in parts.items()}
        row = {
            "k": k,
            "minutes": round(k * STEP / 60, 1),
            "windows": {name: len(part) for name, part in parts.items()},
            "crossing": crossing,
            "of_events": number(len(parts["train"]) / len(fold.train)),
            "parameters": run_report["parameters"],
            "best_epoch": run_report["best_epoch"],
            "seconds": run_report["seconds"],
            "calibration": fit,
            "metrics": {name: {**metrics(parts[name].y, pred[name]),
                               "vertex": vertex.vertices(parts[name].y,
                                                         pred[name],
                                                         distance=gaps[name])}
                        for name in ("train", "val", "test")},
            "spread": {"pred": number(np.std(pred["test"])),
                       "true": number(np.std(parts["test"].y)),
                       "ratio": number(np.std(pred["test"])
                                       / max(float(np.std(parts["test"].y)),
                                             1e-9))},
            "distribution": distribution(pred["test"]),
        }
        rows.append(row)
        test = row["metrics"]["test"]
        hit = test["vertex"]["hits"]
        log(f"      K={k:>2} ({row['minutes']} хв): вікон "
            f"{row['windows']['train']}/{row['windows']['val']}/"
            f"{row['windows']['test']}, викинуто на межах "
            f"{sum(crossing.values())} · test MAE {test['mae']}, знак "
            f"{test['sign_accuracy']}, у зоні {hit['inside']}, влучань "
            f"{hit['hits']} ({hit['recall']}), до вершини {hit['to_vertex']} · "
            f"{row['seconds']} с")

    best = max(rows, key=lambda item: item["metrics"]["test"]["vertex"]["hits"]
               ["recall"] or 0)
    report = {
        "pair": pair,
        "threshold": threshold,
        "target_kind": "ema",
        "target_leg": leg,
        "target_period": period,
        "target": walk_forward.target_title(threshold, "ema", leg),
        "scale": scale,
        "split": "по часу: train | val | test підряд, проміжки по півотах",
        "min_gap_events": MIN_GAP,
        "step": "пачка подій: вікно з K подій поспіль, ціль — остання подія",
        "model": config["model"],
        "family": nets.WINDOW_NAME,
        "config": config,
        "loss": variant.name,
        "patience": patience,
        "epochs": epochs,
        "seed": SEED,
        "event_seconds": STEP,
        "sizes": list(sizes),
        "events": fold.sizes(),
        "dropped": fold.dropped,
        "bounds": {name: {"from_utc": human(stamps[index[0]]),
                          "to_utc": human(stamps[index[-1]])}
                   for name, index in (("train", fold.train),
                                       ("val", fold.val),
                                       ("test", fold.test))},
        "leak": {"same_part": True, "step_seconds": STEP,
                 "note": ("вікно будується тільки з подій підряд і цілком "
                          "лежить в одній вибірці; проміжок між вибірками "
                          f"({MIN_GAP} подій) довший за найбільше вікно")},
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW},
        "picked_by": "влучання в зону на test (recall)",
        "picked": best["k"],
        "rows": rows,
    }
    log(f"[2/2] найбільше влучань у зону на test: K={best['k']} — "
        f"{best['metrics']['test']['vertex']['hits']['recall']}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--sizes", default=",".join(str(k) for k in SIZES),
                        help="перелік K через кому")
    parser.add_argument("--epochs", type=int, default=nets.EPOCHS)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    sizes = tuple(int(item) for item in args.sizes.split(","))
    report = build(args.pair, args.target, sizes=sizes, epochs=args.epochs)
    args.out.mkdir(parents=True, exist_ok=True)
    # заповнений датасет пишеться окремим файлом: вкладка показує обидва
    tag = "_fill" if args.pair.endswith("_fill") else ""
    path = args.out / f"windows{tag}_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
