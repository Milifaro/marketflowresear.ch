"""Розділ 1 вкладки: три нормалізації ноги зігзага 2.3% на ЕМА90.

Дослідження: research/16-zigzag23-wattn/ (розділ 1)
Правила: rules/02-markup.md → Нормалізація ноги
         rules/01-data-and-db.md → Скейлери

Ціль дослідження — нормований зігзаг **2.3% на ЕМА90 ціни** (мітка етапу
1). Порядок побудови той самий, що в `zigzag_targets.build`:

    ема90(ціна) -> півоти зігзага 2.3% -> нормована нога

Нога нормується **розподілом** — часткою пройденого шляху, рахованою по
своїй нозі окремо:

    minmax    2*(price - low)/(high - low) - 1   -1 у дні, +1 у вершині

Це єдиний ряд дослідження. Робаст меж не має (нога в одиницях IQR),
квантиль ставить ранг події, а не пройдений шлях — обидва зміщують
вершину, до якої тут міряється відстань. Числа, якими зроблено цей
вибір, — `leg_pick.py`.

Поруч іде **той самий ряд, згладжений між зонами півотів** (`smooth.py`,
за замовчуванням `ема20`): у зонах усе лишається як було, а коливання
на середині ноги падають у 4.8 раза. Саме на ньому вчаться моделі
розділу 4.

Вихід: results/legs_2_3.json — гістограма кожного ряду і графік, де три
ряди намальовані під ЕМА90 з півотами її зігзага. Графік іде на **весь
датасет**: нога зігзага 2.3% довга (близько 900 подій), тому в короткому
вікні ніг не видно взагалі. Поруч
results/legs_2_3.meta.json — короткий звіт для картки дослідження:
те саме, але без гістограм і без самого вікна.

Запуск:
    python3 research/16-zigzag23-wattn/scripts/legs.py --target 2.3
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import vertex  # noqa: E402
import zigzag_targets  # noqa: E402
from class210ema4 import ema  # noqa: E402
from class_card import BINS, CLIP, histogram  # noqa: E402
from data import PICKED  # noqa: E402
from zigzag import zigzag  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402
from zigzag_scalers import NAMES, prices_of, row_stats  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
# Нормалізація ноги дослідження — одна. Робаст і квантиль
# (`zigzag_targets.SCALERS`) не беруться: у першого немає фіксованих меж,
# другий міряє ранг, а не шлях — вершини зміщені в обох (`leg_pick.py`).
SCALERS = ("minmax",)
# Подій у вікні під графіком. 0 — увесь датасет: середня нога зігзага 2.3%
# близько 900 подій, і коротке вікно частіше за все не містить жодної.
WINDOW = 0
LEG_USED = "minmax"  # нога прогону: розділ 2 стоїть на цьому ряду
SMOOTH = "ема20"     # згладжування між зонами (smooth.py), None — без нього


def human(value: int) -> str:
    return dt.datetime.fromtimestamp(int(value), dt.timezone.utc).strftime(
        "%Y-%m-%d %H:%M")


def build(pair: str = "BTC_USDT", threshold: str = "2.3",
          window: int = WINDOW, root: Path | None = None,
          used: str = LEG_USED, smooth_way: str | None = SMOOTH) -> dict:
    price, stamps = prices_of(pair, root)
    period = PICKED[threshold]
    smoothed = ema(price, period)
    pivots = zigzag(smoothed, THRESHOLDS[threshold])

    rows, series = [], {}
    for scaler in SCALERS:
        targets = zigzag_targets.build(price, stamps, periods=[period],
                                       scaler=scaler)
        values = targets.column(period, threshold)
        series[scaler] = values
        rows.append({"id": scaler, **NAMES[scaler], **row_stats(values)})

    start = max(len(price) - window, 0) if window else 0
    inside = [pivot for pivot in pivots if pivot.index >= start]
    # зони півотів — ті самі, що в метриці (vertex.BAND, vertex.WINDOW)
    marks = [pivot.index for pivot in pivots]
    kinds = [pivot.kind for pivot in pivots]
    spans = vertex.zone_spans(series[used], stamps, marks, kinds)
    first = int(stamps[start])

    # той самий ряд, згладжений між зонами: зони недоторкані
    if smooth_way:
        import smooth as smooth_step
        kind, size = smooth_step.way_of(smooth_way)
        zone = np.zeros(len(price), dtype=bool)
        place = {int(value): index for index, value in enumerate(stamps)}
        for span in spans:
            zone[place[span["from"]]:place[span["to"]] + 1] = True
        series["smooth"] = smooth_step.apply_way(
            series[used], np.array(marks, dtype=int), zone, kind, size)
        rows.append({"id": "smooth",
                     "name": f"розподіл згладжений ({smooth_way})",
                     "formula": f"{smooth_way} між зонами, у зонах — як є",
                     "note": ("коливання на середині ноги погашені, "
                              "вершини й зони не змінені"),
                     **row_stats(series["smooth"])})
    return {
        "pair": pair,
        "threshold": threshold,
        "target_kind": "ema",
        "smooth": period,
        "used": used,
        # ряд, на якому стоїть зігзаг: його ж малює перший графік вікна
        "chart": "ema",
        "chart_title": (f"ема{period} ціни BTC_USDT, USDT · "
                        f"зігзаг {threshold}"),
        "target": f"зігзаг {threshold} нормований, ема{period}",
        "scaled_by": "нозі: кожен рух між півотами проходить скейлер окремо",
        "events": int(len(price)),
        "pivots": int(len(pivots)),
        "legs": int(max(len(pivots) - 1, 0)),
        "period": {"from_utc": human(stamps[0]), "to_utc": human(stamps[-1])},
        "scalers": list(SCALERS),
        "smooth_way": smooth_way,
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW,
                 "leg": used, "rows": [used] + (["smooth"] if smooth_way
                                                else []),
                 "note": (f"зона півота: |y| >= {1 - vertex.BAND:.2f} і "
                          f"±{vertex.WINDOW} подій від півота")},
        "bins": BINS,
        "clip": CLIP,
        "rows": rows,
        "window": {
            "events": int(len(price) - start),
            "from_utc": human(stamps[start]),
            "to_utc": human(stamps[-1]),
            "legs": max(len(inside) - 1, 0),
            "t": [int(v) for v in stamps[start:]],
            "price": [round(float(v), 2) for v in price[start:]],
            "ema": [round(float(v), 2) for v in smoothed[start:]],
            "zones": [span for span in spans if span["to"] >= first],
            "pivots": [{"t": int(stamps[pivot.index]),
                        "price": round(float(price[pivot.index]), 2),
                        "ema": round(float(smoothed[pivot.index]), 2),
                        "kind": pivot.kind} for pivot in inside],
            **{scaler: [None if not np.isfinite(v) else round(float(v), 4)
                        for v in values[start:]]
               for scaler, values in series.items()},
        },
    }


def meta(payload: dict) -> dict:
    """Короткий звіт для картки дослідження: без гістограм і вікна."""
    return {**{key: value for key, value in payload.items()
               if key not in ("rows", "window", "bins", "clip")},
            "script": "research/16-zigzag23-wattn/scripts/legs.py",
            "command": ("python3 research/16-zigzag23-wattn/scripts/legs.py "
                        f"--target {payload['threshold']}"),
            "rows": [{key: value for key, value in row.items()
                      if key != "hist"} for row in payload["rows"]]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--leg", default=LEG_USED, choices=SCALERS)
    parser.add_argument("--smooth", default=SMOOTH,
                        help="спосіб згладжування між зонами; none — без нього")
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    payload = build(args.pair, args.target, args.window, used=args.leg,
                    smooth_way=None if args.smooth == "none" else args.smooth)
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"legs_{args.target.replace('.', '_')}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False),
                    encoding="utf-8")
    path.with_suffix(".meta.json").write_text(
        json.dumps(meta(payload), ensure_ascii=False, indent=2,
                   allow_nan=False), encoding="utf-8")
    for row in payload["rows"]:
        print(f"{row['name']}: {row['events']} подій, "
              f"межі {row['min']} … {row['max']}, σ {row['std']}")
    print(f"ніг {payload['legs']}, півотів {payload['pivots']}")
    print(f"записано {path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
