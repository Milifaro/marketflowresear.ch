"""Збережена модель прогону: ваги `wattn` і скейлер її train.

Дослідження: research/16-zigzag23-wattn/

`train.load_saved` шукає родину в загальному переліку `train.MODELS`, а
`wattn` туди навмисно не додається (`nets.py`): переліки дослідження 12
мають лишитись такими, як були. Тому завантаження тут своє — воно бере
клас родини напряму.

Скейлер читається тим самим `data.Scaler`, що й писався: і z-score, і
квантиль лежать в одному форматі.
"""

from __future__ import annotations

import sys
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))

import nets  # noqa: E402
from data import Scaler  # noqa: E402
from train import model_params  # noqa: E402


def load_model(report: dict, root: Path = PROJECT_ROOT, factory=None):
    """Модель і скейлер зі звіту прогону: `model_path` + `config`.

    `factory` підставляє іншу форму родини — наприклад вікно з K подій
    (`nets.window_factory`); без нього береться одноподієва `wattn`.
    """
    folder = Path(root) / report["model_path"]
    name, params = model_params(report["config"])
    if name != nets.NAME:
        raise SystemExit(f"звіт не про {nets.NAME}, а про {name}")
    model = (factory or nets.FACTORY)(**params)
    model.load_state_dict(torch.load(folder / "model.pt", map_location="cpu"))
    model.eval()
    return model, Scaler.load(folder / "scaler.npz")
