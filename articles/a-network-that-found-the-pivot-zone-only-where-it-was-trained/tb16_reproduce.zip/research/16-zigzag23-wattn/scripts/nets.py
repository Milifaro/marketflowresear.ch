"""Мережа `wattn`: увага по осі ЕМА-періодів зі зваженим зчитуванням.

Дослідження: research/16-zigzag23-wattn/
Правила: rules/03-models.md → Типи мереж

Подія — `(13, 4)`: 13 періодів ЕМА × 4 фічі. Крок послідовності тут один
період ЕМА (10 … 130), тому увага дивиться, які масштаби згладжування
важливі саме для цієї події. Позиція періоду вчиться окремим параметром:
порядок періодів має значення.

У дослідженні дві форми однієї родини: `WAttn` — увага по осі періодів
ЕМА однієї події, `WindowAttn` — та сама увага по осі **подій**, коли на
вхід іде вікно з K подій поспіль (`windows.py`).

Відмінність від `transformer` дослідження 12 — **зчитування**. Там
кроки усереднюються (`mean`), тут за них відповідає навчений запит:

    ваги = softmax(q · h_крок / √width)      Σ ваг = 1
    вихід = Σ ваг · h_крок  ->  голова

Тобто мережа сама вирішує, з яких періодів ЕМА брати відповідь, а не
розмазує їх рівно. `width` має ділитись на `heads`.

Модель **не додається** в загальний перелік `train.MODELS`: вона йде в
прогін окремим `factory`, тому переліки дослідження 12 (підбір
технології, гріди) лишаються такими, як були. Решта пайплайну —
навчання з ранньою зупинкою, метрики, калібрування — працює над нею
без правок.
"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch import nn

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))

from train import FEATURES, PERIODS, flat  # noqa: E402

NAME = "wattn"


class WAttn(nn.Module):
    """Енкодер уваги по 13 періодах ЕМА + зважене зчитування навченим запитом."""

    def __init__(self, width=32, heads=4, layers=2, dropout=0.1, outputs=1):
        super().__init__()
        if width % heads:
            raise ValueError("width має ділитись на heads")
        self.outputs = outputs
        self.width = width
        self.into = nn.Linear(FEATURES, width)
        self.place = nn.Parameter(torch.zeros(1, PERIODS, width))
        self.query = nn.Parameter(torch.zeros(1, 1, width))
        nn.init.normal_(self.query, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=width * 4,
            dropout=dropout, batch_first=True, norm_first=True)
        self.net = nn.TransformerEncoder(layer, num_layers=layers,
                                         enable_nested_tensor=False)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(width, outputs)

    def attention(self, x):
        """Ваги зчитування: скільки кожен період важить у відповіді."""
        out = self.net(self.into(x) + self.place)          # (N, 13, width)
        score = (out * self.query).sum(-1) / self.width ** 0.5
        return out, torch.softmax(score, dim=1)            # (N, 13)

    def forward(self, x):
        out, weight = self.attention(x)
        pooled = (out * weight.unsqueeze(-1)).sum(dim=1)
        return flat(self.head(self.drop(pooled)), self.outputs)


class WindowAttn(nn.Module):
    """Та сама увага, але по осі **подій**: вікно з K подій поспіль.

    Крок послідовності — ціла подія, розгорнута в 52 значення
    (13 періодів ЕМА × 4 фічі). Позиція кроку вчиться, зчитування —
    той самий навчений запит, що і в `WAttn`. Ціль вікна — ціль його
    **останньої** події.

    K не ручка навчання, а параметр досліду: він перебирається зовні
    (`windows.py`), і кожне K — свій прогін.
    """

    def __init__(self, k: int, width=32, heads=4, layers=2, dropout=0.1,
                 outputs=1):
        super().__init__()
        if width % heads:
            raise ValueError("width має ділитись на heads")
        self.k = k
        self.outputs = outputs
        self.width = width
        self.into = nn.Linear(PERIODS * FEATURES, width)
        self.place = nn.Parameter(torch.zeros(1, k, width))
        self.query = nn.Parameter(torch.zeros(1, 1, width))
        nn.init.normal_(self.query, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=width, nhead=heads, dim_feedforward=width * 4,
            dropout=dropout, batch_first=True, norm_first=True)
        self.net = nn.TransformerEncoder(layer, num_layers=layers,
                                         enable_nested_tensor=False)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(width, outputs)

    def attention(self, x):
        """Ваги зчитування: скільки кожна подія вікна важить у відповіді."""
        flat_x = x.reshape(x.shape[0], self.k, PERIODS * FEATURES)
        out = self.net(self.into(flat_x) + self.place)      # (N, K, width)
        score = (out * self.query).sum(-1) / self.width ** 0.5
        return out, torch.softmax(score, dim=1)             # (N, K)

    def forward(self, x):
        out, weight = self.attention(x)
        pooled = (out * weight.unsqueeze(-1)).sum(dim=1)
        return flat(self.head(self.drop(pooled)), self.outputs)


# Родина підставляється в прогін замість пошуку в `train.MODELS`
# (`train.run(..., factory=nets.FACTORY)`).
FACTORY = WAttn
WINDOW_NAME = "wattn-вікно"


def window_factory(k: int):
    """Фабрика вікна: K фіксується дослідом, решта ручок — як у `wattn`."""
    def make(**params):
        return WindowAttn(k=k, **params)
    return make

# Конфігурація прогону: гріду в цьому дослідженні немає, тому ручки стоять
# на типових значеннях родини (ті самі, що в кроці «підбір технології»
# дослідження 12), а не підбираються.
CONFIG = {"model": NAME,
          "params": {"width": 32, "heads": 4, "layers": 2, "dropout": 0.1},
          "lr": 1e-3, "alpha": 3.0, "beta": 2.0}
PATIENCE = 30
EPOCHS = 400
