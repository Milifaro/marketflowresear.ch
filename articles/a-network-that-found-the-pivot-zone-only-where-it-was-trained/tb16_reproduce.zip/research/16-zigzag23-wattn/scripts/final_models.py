"""Моделі на згладженій цілі: увесь датасет, грід і видалення фіч.

Дослідження: research/16-zigzag23-wattn/ (розділ 4)
Правила: rules/03-models.md → Типи мереж → Тестові, Продакшен

Ціль тут — **згладжена** між зонами півотів (`smooth.py`): у зонах
лишилось як було, між ними коливання погашені. Спосіб згладжування
задається `--way` і береться з `results/smooth_2_3.npz`.

Вхід — **вікно з K подій** (`--k`, `nets.WindowAttn`, розділ 3) або одна
подія (`--k 1`, `nets.WAttn`). Вікна будуються тими самими правилами, що
в розділі 3: тільки події підряд, вікно цілком в одній вибірці.

## Розбиття

Модель вчиться на **всьому датасеті, крім невідомого відрізка**: датасет
ділиться тільки на `train | val`, а роль test грає те, що після його
кінця (`fresh.py`, 2026-08-16 20:00 і далі). Межа `train | val` ріжеться
по півоту з проміжком не меншим за глибину фічі (`MIN_GAP` = 130 подій),
щоб дві вибірки не поділили одну ногу.

## Кроки

    --step grid       грід по ручках родини, вибір по val
    --step final      навчання кращої конфігурації і збереження ваг
    --step ablation   викидання фіч по одній, від найслабшої за |r|

Викидання фіч робиться **маскою**: клітинка `(період, фіча)` після
скейлера зануляється, форма входу не міняється, архітектура лишається
тією самою. Порядок викидання — за |r| фічі з ціллю **на train**.

Вибір скрізь іде по `val` і по одній мірці — **влучання в зону півота**
(`vertex.hits.recall`), бо в цьому й завдання; за рівних — менший MAE.

Вихід: results/grid_<спосіб>_2_3.json, results/final_<спосіб>_2_3.json,
results/ablation_<спосіб>_2_3.json

Запуск:
    python3 research/16-zigzag23-wattn/scripts/final_models.py \\
        --way ема10 --step grid
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "research" / "12-zigzag-net" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

import nets  # noqa: E402
import split_time  # noqa: E402
import windows as window_step  # noqa: E402
import vertex  # noqa: E402
import walk_forward  # noqa: E402
from correlation import pearson  # noqa: E402
from data import Part, PICKED, fit_scaler  # noqa: E402
from losses import variants  # noqa: E402
from train import SEED, metrics, number, predict  # noqa: E402
from walk_forward import MIN_GAP, human, merged, pivot_index  # noqa: E402
from wattn_losses import LOSSES, to_pivot  # noqa: E402
from zigzag_targets import THRESHOLDS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
VAL_FRACTION = 0.2          # доля val у датасеті; test тут немає
GRID_EPOCHS, GRID_PATIENCE = 200, 20
# Грід по ручках родини `wattn`. Батч фіксований — міняється по одному
# сімейству параметрів за раз (rules/03-models.md → Типи мереж).
GRID = [{"model": nets.NAME,
         "params": {"width": width, "heads": 4, "layers": layers,
                    "dropout": dropout},
         "lr": lr, "alpha": nets.CONFIG["alpha"], "beta": nets.CONFIG["beta"]}
        for width in (16, 32, 64)
        for layers in (1, 2)
        for dropout in (0.1, 0.3)
        for lr in (3e-4, 1e-3)]
ABLATION_STEPS = 12         # скільки фіч викинути по одній


def smoothed_target(way: str, out: Path = RESULTS, threshold: str = "2.3",
                    pair: str = "BTC_USDT") -> np.ndarray:
    """Згладжений ряд цілі зі звіту `smooth.py` тієї самої пари."""
    tag = "_fill" if pair.endswith("_fill") else ""
    path = out / f"smooth{tag}_{threshold.replace('.', '_')}.npz"
    with np.load(path, allow_pickle=False) as data:
        if way not in data:
            raise SystemExit(f"немає способу {way} у {path.name}")
        return data[way].astype(float)


def split(n: int, pivots: np.ndarray,
          val_fraction: float = VAL_FRACTION) -> tuple[np.ndarray, np.ndarray]:
    """`train | val` по часу: межа по півоту, проміжок не менший за MIN_GAP."""
    val_from = int(round(n * (1 - val_fraction)))
    cut = split_time.cut_before(pivots, val_from, MIN_GAP)
    if not cut:
        raise SystemExit("півотів не вистачає на проміжок між train і val")
    return np.arange(0, cut), np.arange(val_from, n)


def parts_of(x, y, index, scale: str = "quantile", mask=None,
             k: int = 1, stamps=None):
    """Вибірки зі скейлером train; `mask` зануляє викинуті клітинки.

    `k > 1` — вхід стає вікном з K подій поспіль (розділ 3): вікно
    будується тільки з подій підряд і цілком лежить в одній вибірці.
    """
    parts, crossing = {}, {}
    for name, where in index.items():
        if k > 1:
            ends = window_step.window_ends(stamps, k)
            low, high = int(where[0]), int(where[-1])
            inside = ends[(ends >= low) & (ends <= high)]
            whole = inside[inside - (k - 1) >= low]
            crossing[name] = int(len(inside) - len(whole))
            block = window_step.stack(x, whole, k)
            good = whole[np.isfinite(y[whole])
                         & np.isfinite(block).all(axis=(1, 2, 3))]
            values = window_step.stack(x, good, k)
        else:
            good = where[np.isfinite(y[where])
                         & np.isfinite(x[where]).all(axis=(1, 2))]
            values = x[good]
        parts[name] = Part(x=np.asarray(values, dtype=np.float32),
                           y=y[good].astype(np.float32), timestamp=good,
                           price_open=good, price_close=good)
    flat = parts["train"].x.reshape(-1, *x.shape[1:])
    scaler = fit_scaler(flat, scale)
    for part in parts.values():
        shape = part.x.shape
        part.x = scaler.apply(part.x.reshape(-1, *x.shape[1:])).reshape(shape)
        if mask is not None:
            part.x = part.x * mask
    return parts, scaler, crossing


def score(parts: dict, pred: dict, gaps: dict) -> dict:
    """Метрики по вибірках: звичайні плюс вершини й влучання в зону."""
    return {name: {**metrics(parts[name].y, pred[name]),
                   "events": len(parts[name]),
                   "vertex": vertex.vertices(parts[name].y, pred[name],
                                             distance=gaps[name])}
            for name in parts}


def recall_of(item: dict) -> float:
    return item["vertex"]["hits"]["recall"] or 0.0


def factory_for(k: int):
    """Родина під вхід: вікно з K подій або одна подія."""
    return nets.window_factory(k) if k > 1 else nets.FACTORY


def run_config(config: dict, parts: dict, gaps: dict, variant, epochs: int,
               patience: int, factory=None) -> tuple[dict, object, dict]:
    """Один прогін: навчання, прогноз на всіх вибірках, метрики."""
    import torch

    report, model = walk_forward.run(
        config["model"], parts, epochs=epochs, lr=config["lr"],
        params=dict(config["params"]), patience=patience, seed=SEED,
        loss=variant.loss, point=variant.point,
        factory=factory or nets.FACTORY, loss_title=variant.name,
        log=lambda *args: None)
    device = report["device"]
    pred = {name: predict(model, torch.tensor(part.x, device=device))
            for name, part in parts.items()}
    return report, model, score(parts, pred, gaps)


def prepare(pair: str, threshold: str, way: str, root: Path | None,
            out: Path, leg: str = "minmax", scale: str = "quantile",
            k: int = 1):
    """Спільна підготовка: фічі, згладжена ціль, розбиття, відстані."""
    period = PICKED[threshold]
    x, raw, stamps, price = merged(pair, threshold, period, root, "ema", leg)
    y = smoothed_target(way, out, threshold, pair)
    if len(y) != len(x):
        raise SystemExit("згладжений ряд і фічі різної довжини")
    pivots = pivot_index(price, period, threshold, "ema")
    train, val = split(len(x), pivots)
    parts, scaler, crossing = parts_of(x, y, {"train": train, "val": val},
                                       scale, k=k, stamps=stamps)
    gaps = {name: to_pivot(part.timestamp, pivots)
            for name, part in parts.items()}
    bounds = {name: {"from_utc": human(stamps[part.timestamp[0]]),
                     "to_utc": human(stamps[part.timestamp[-1]])}
              for name, part in parts.items()}
    return {"x": x, "y": y, "raw": raw, "stamps": stamps, "price": price,
            "pivots": pivots, "index": {"train": train, "val": val},
            "parts": parts, "scaler": scaler, "gaps": gaps, "bounds": bounds,
            "period": period, "scale": scale, "leg": leg, "k": k,
            "crossing": crossing}


def head(pair: str, threshold: str, way: str, data: dict, step: str) -> dict:
    """Спільна шапка звіту."""
    return {
        "pair": pair,
        "threshold": threshold,
        "way": way,
        "step": step,
        "run": None,
        "target": (f"зігзаг {threshold} нормований, ема{data['period']}, "
                   f"згладжено між зонами ({way})"),
        "target_kind": "ema",
        "target_leg": data["leg"],
        "target_period": data["period"],
        "scale": data["scale"],
        "split": "по часу: train | val; test — невідомий відрізок після датасету",
        "min_gap_events": MIN_GAP,
        "k": data["k"],
        "family": nets.WINDOW_NAME if data["k"] > 1 else nets.NAME,
        "crossing": data["crossing"],
        "events": {name: len(part) for name, part in data["parts"].items()},
        "bounds": data["bounds"],
        "zone": {"band": vertex.BAND, "window": vertex.WINDOW},
        "seed": SEED,
        "picked_by": "влучання в зону на val (recall), за рівних — MAE",
    }


def grid(pair: str = "BTC_USDT", threshold: str = "2.3", way: str = "ема10",
         root: Path | None = None, out: Path = RESULTS,
         configs=None, epochs: int = GRID_EPOCHS,
         patience: int = GRID_PATIENCE, k: int = 1, log=print) -> dict:
    """Грід по ручках родини: усі конфігурації на одному розбитті."""
    data = prepare(pair, threshold, way, root, out, k=k)
    variant = next(item for item in variants(nets.CONFIG["alpha"],
                                             nets.CONFIG["beta"])
                   if item.id == LOSSES[0])
    configs = list(configs or GRID)
    log(f"[1/2] {way}, K={k}: train {len(data['parts']['train'])} / val "
        f"{len(data['parts']['val'])} · {len(configs)} конфігурацій")

    rows = []
    for index, config in enumerate(configs, 1):
        report, _, marks = run_config(config, data["parts"], data["gaps"],
                                      variant, epochs, patience,
                                      factory_for(k))
        val = marks["val"]
        rows.append({"config": config, "parameters": report["parameters"],
                     "best_epoch": report["best_epoch"],
                     "seconds": report["seconds"], "metrics": marks})
        log(f"      {index}/{len(configs)} {config['params']} lr "
            f"{config['lr']}: val MAE {val['mae']}, знак "
            f"{val['sign_accuracy']}, влучань "
            f"{val['vertex']['hits']['hits']} з "
            f"{val['vertex']['hits']['inside']} ({recall_of(val)}), "
            f"{report['seconds']} с")
    rows.sort(key=lambda row: (-recall_of(row["metrics"]["val"]),
                               row["metrics"]["val"]["mae"]))
    best = rows[0]
    log(f"[2/2] краща: {best['config']['params']} lr {best['config']['lr']} — "
        f"влучань {recall_of(best['metrics']['val'])}")
    return {**head(pair, threshold, way, data, "грід по ручках родини"),
            "loss": variant.name, "epochs": epochs, "patience": patience,
            "configs": len(configs), "rows": rows, "picked": best["config"]}


def final(pair: str = "BTC_USDT", threshold: str = "2.3", way: str = "ема10",
          root: Path | None = None, out: Path = RESULTS,
          config: dict | None = None, epochs: int | None = None,
          patience: int | None = None, k: int = 1, log=print) -> dict:
    """Фінальна модель способу: навчання кращої конфігурації і збереження."""
    import torch

    data = prepare(pair, threshold, way, root, out, k=k)
    variant = next(item for item in variants(nets.CONFIG["alpha"],
                                             nets.CONFIG["beta"])
                   if item.id == LOSSES[0])
    tail = threshold.replace(".", "_")
    if config is None:
        picked = json.loads((out / f"grid_{name_of(way, k, pair)}_{tail}.json")
                            .read_text(encoding="utf-8"))
        config = picked["picked"]
    epochs = nets.EPOCHS if epochs is None else epochs
    patience = nets.PATIENCE if patience is None else patience
    log(f"[1/2] {way}: {config['params']} lr {config['lr']}")

    report, model, marks = run_config(config, data["parts"], data["gaps"],
                                      variant, epochs, patience,
                                      factory_for(k))
    folder = (RESEARCH_DIR / "models"
              / f"{nets.NAME}_{name_of(way, k, pair)}_{tail}_v1")
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "model.pt")
    data["scaler"].save(folder / "scaler.npz")
    val = marks["val"]
    log(f"[2/2] val: MAE {val['mae']}, знак {val['sign_accuracy']}, влучань "
        f"{val['vertex']['hits']['hits']} з {val['vertex']['hits']['inside']}")
    return {**head(pair, threshold, way, data, "фінальна модель способу"),
            "loss": variant.name, "model": config["model"], "config": config,
            "epochs": epochs, "patience": patience,
            "parameters": report["parameters"],
            "best_epoch": report["best_epoch"], "seconds": report["seconds"],
            "metrics": marks,
            "model_path": str(folder.relative_to(PROJECT_ROOT)),
            "rows": [{"id": way, "name": variant.name,
                      "model_path": str(folder.relative_to(PROJECT_ROOT))}]}


def order_features(x: np.ndarray, y: np.ndarray, index: np.ndarray,
                   periods, features) -> list[dict]:
    """Фічі за |r| з ціллю на train, від найслабшої."""
    rows = []
    for i, period in enumerate(periods):
        for j, name in enumerate(features):
            value = abs(pearson(x[index, i, j], y[index]))
            rows.append({"period": int(period), "feature": name,
                         "cell": [i, j], "abs_r": number(value)})
    rows.sort(key=lambda row: row["abs_r"])
    return rows


def ablation(pair: str = "BTC_USDT", threshold: str = "2.3",
             way: str = "ема10", root: Path | None = None,
             out: Path = RESULTS, steps: int = ABLATION_STEPS,
             config: dict | None = None, epochs: int | None = None,
             patience: int | None = None, k: int = 1, log=print) -> dict:
    """Викидання фіч по одній: від найслабшої за |r|, щоразу нове навчання."""
    import class210x4bema10x10x130 as klass

    data = prepare(pair, threshold, way, root, out, k=k)
    variant = next(item for item in variants(nets.CONFIG["alpha"],
                                             nets.CONFIG["beta"])
                   if item.id == LOSSES[0])
    tail = threshold.replace(".", "_")
    if config is None:
        config = json.loads((out / f"grid_{name_of(way, k, pair)}_{tail}.json")
                            .read_text(encoding="utf-8"))["picked"]
    epochs = nets.EPOCHS if epochs is None else epochs
    patience = nets.PATIENCE if patience is None else patience

    train = data["index"]["train"]
    features = klass.FEATURES if hasattr(klass, "FEATURES") else \
        ["balance", "d_balance", "vol_balance", "price_balance"]
    weakest = order_features(data["x"], data["y"], train, klass.PERIODS,
                             features)
    log(f"[1/2] {way}: найслабша фіча {weakest[0]['feature']} "
        f"ема{weakest[0]['period']} (|r| {weakest[0]['abs_r']}), "
        f"викидаємо {steps} по одній")

    mask = np.ones((len(klass.PERIODS), len(features)), dtype=np.float32)
    rows, dropped = [], []
    for step in range(steps + 1):
        parts, _, _ = parts_of(data["x"], data["y"], data["index"],
                               data["scale"], mask, k=k,
                               stamps=data["stamps"])
        gaps = {name: to_pivot(part.timestamp, data["pivots"])
                for name, part in parts.items()}
        report, _, marks = run_config(config, parts, gaps, variant, epochs,
                                      patience, factory_for(k))
        val = marks["val"]
        rows.append({"dropped": len(dropped),
                     "last": dropped[-1] if dropped else None,
                     "kept": int(mask.sum()),
                     "best_epoch": report["best_epoch"],
                     "seconds": report["seconds"], "metrics": marks})
        log(f"      викинуто {len(dropped):>2} (лишилось {int(mask.sum())}): "
            f"val MAE {val['mae']}, знак {val['sign_accuracy']}, влучань "
            f"{val['vertex']['hits']['hits']} з "
            f"{val['vertex']['hits']['inside']} ({recall_of(val)})")
        if step == steps:
            break
        item = weakest[step]
        mask[item["cell"][0], item["cell"][1]] = 0.0
        dropped.append({"feature": item["feature"], "period": item["period"],
                        "abs_r": item["abs_r"]})
    best = max(rows, key=lambda row: (recall_of(row["metrics"]["val"]),
                                      -row["metrics"]["val"]["mae"]))
    log(f"[2/2] найкраще після {best['dropped']} викинутих: влучань "
        f"{recall_of(best['metrics']['val'])}")
    return {**head(pair, threshold, way, data, "викидання фіч по одній"),
            "loss": variant.name, "config": config, "epochs": epochs,
            "patience": patience, "steps": steps,
            "order": weakest[:steps], "rows": rows,
            "picked": best["dropped"]}


def name_of(way: str, k: int, pair: str = "BTC_USDT") -> str:
    """Імʼя прогону у файлах: пара, спосіб згладжування і розмір вікна."""
    tag = "fill_" if pair.endswith("_fill") else ""
    return f"{tag}{way}_k{k}"


STEPS = {"grid": grid, "final": final, "ablation": ablation}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", default="BTC_USDT")
    parser.add_argument("--target", default="2.3", choices=tuple(THRESHOLDS))
    parser.add_argument("--way", default="ема10")
    parser.add_argument("--step", default="grid", choices=tuple(STEPS))
    parser.add_argument("--steps", type=int, default=ABLATION_STEPS)
    parser.add_argument("--k", type=int, default=1,
                        help="подій у вікні; 1 — одна подія")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    extra = {"steps": args.steps} if args.step == "ablation" else {}
    if args.epochs is not None:
        extra["epochs"] = args.epochs
    report = STEPS[args.step](args.pair, args.target, args.way,
                              out=args.out, k=args.k, **extra)
    args.out.mkdir(parents=True, exist_ok=True)
    tail = args.target.replace(".", "_")
    path = (args.out
            / f"{args.step}_{name_of(args.way, args.k, args.pair)}_{tail}.json")
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False,
                               allow_nan=False), encoding="utf-8")
    print(f"записано {path}")


if __name__ == "__main__":
    main()
