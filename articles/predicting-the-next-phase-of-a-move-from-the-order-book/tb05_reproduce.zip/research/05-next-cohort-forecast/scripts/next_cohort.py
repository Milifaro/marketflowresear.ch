"""Дослідження 05: прогноз когорти наступної події за пачкою клас210х14х2.

Дослідження: research/05-next-cohort-forecast/
Правила: rules/01-data-and-db.md (класи, витік), rules/03-models.md (метрики),
         rules/05-visualization.md (компоновка графіків).

Задача: по пачці з N підряд подій `клас210х14х2` сказати, у якій з чотирьох
когорт лежатиме **наступна** подія:

    up        — зростання (відрізок за трендом 2.3 вгору)
    up_pull   — протирух у зростанні
    down      — падіння
    down_pull — протирух у падінні

Когорти й розмітка — дослідження 04, етап 6 (`class_schema.phases`).

Метод математичний, без ітеративного навчання: класи описуються нормальним
розподілом зі спільною коваріацією, рішення — за формулою Байєса (лінійний
дискримінант). Усі величини рахуються в закритій формі з сум, середніх
і коваріації.

Пачка росте з кроку 2 на +1 подію, поки не виконається критерій, і далі до
стелі — кількості подій у 4 рухах зігзагу 2.3.

Уся вибірка — тільки `train`: і пачка, і ціль лежать у train.

Вхід : data/datasets/BTC_USDT/class210x14x2/train.npz
Вихід: results/forecast.json      — сходинки, метрики, матриці помилок (дашборд)
       results/forecast.meta.json — те саме без сходинок, для картки

Запуск:
    python3 research/05-next-cohort-forecast/scripts/next_cohort.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import class210x14x2  # noqa: E402
import zigzag  # noqa: E402
from class_schema import CLASSES, PHASES, phases  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
DATASET = PROJECT_ROOT / "data" / "datasets" / "BTC_USDT" / "class210x14x2"
DEFAULT_INPUT = DATASET / "train.npz"

FOLDS = 5           # блокових частин train для чесної оцінки
COND_LIMIT = 1e12   # гірша обумовленість коваріації — рахувати не можна
MOVES_IN_CAP = 4    # стеля пачки — стільки рухів зігзагу 2.3
SIGMA = 2.0         # скільки стандартних похибок треба перевищити

VARIANTS = ("freq", "equal")   # апріорні ймовірності: частоти класів / рівні


# ---------------------------------------------------------------- дані

def load_sample(path: Path) -> dict:
    """Вибірка в хронологічному порядку: точки подій, ціни, когорти.

    Точка події — середнє по її 15 блоках, окремо по кожній величині
    (дослідження 04: усереднення по події працює краще за окремі блоки).
    """
    data = class210x14x2.load(path)
    order = np.argsort(data.timestamp)
    x = data.x[order].astype(float)
    return {
        "points": np.nanmean(x, axis=1),                  # (N, 2)
        "blocks": x.reshape(len(x), -1),                  # (N, 30)
        "timestamp": data.timestamp[order].astype(np.int64),
        "price": data.price_open[order].astype(float),
        "events": len(x),
    }


def cohorts(prices: np.ndarray, outer: float, inner: float) -> dict:
    """Когорта кожної події числом: 0..3 за PHASES, -1 — поза зігзагом."""
    marks = phases(prices, outer, inner)
    index = {name: number for number, name in enumerate(PHASES)}
    return {"y": np.array([index.get(value, -1) for value in marks["phase"]]),
            "pivots": marks["pivots"]}


def packet_cap(prices: np.ndarray, outer: float, moves: int = MOVES_IN_CAP
               ) -> dict:
    """Стеля розміру пачки: скільки подій у `moves` рухах зігзагу `outer`."""
    pivots = zigzag.zigzag(prices, outer)
    lengths = np.array([move.end - move.start
                        for move in zigzag.moves(pivots)], dtype=float)
    mean = float(lengths.mean()) if len(lengths) else 0.0
    return {"moves": int(len(lengths)), "mean_events_per_move": mean,
            "cap": int(round(moves * mean))}


def packet_rows(y: np.ndarray, points: np.ndarray, n_max: int) -> np.ndarray:
    """Індекси цільових подій, для яких пачка з n_max подій уся в вибірці.

    Ціль має бути розміченою (когорта відома), пачка — без NaN. Набір рядків
    один для всіх N, щоб сходинки порівнювались на однакових подіях.
    """
    clean = ~np.isnan(points).any(axis=1)
    ok = np.concatenate([[0], np.cumsum(clean)])       # ok[i] — чистих до i
    rows = np.arange(n_max, len(y))
    whole = (ok[rows] - ok[rows - n_max]) == n_max     # уся пачка чиста
    return rows[(y[rows] >= 0) & whole]


def design(points: np.ndarray, rows: np.ndarray, n_max: int) -> np.ndarray:
    """Матриця пачок (R, 2·n_max), колонки за лагом: [лаг1, лаг2, ... ].

    Порядок колонок за лагом дає пачку розміру N як префікс перших 2N колонок.
    Лаг 1 — подія перед ціллю; сама ціль у пачку не входить.
    """
    lags = np.arange(1, n_max + 1)
    return points[rows[:, None] - lags[None, :]].reshape(len(rows), -1)


# ------------------------------------------------- лінійний дискримінант

def moments(F: np.ndarray, y: np.ndarray, classes: int = len(PHASES)) -> dict:
    """Суми, потрібні для дискримінанта: G = FᵀF, суми по класах, розміри."""
    return {
        "gram": F.T @ F,
        "sums": np.array([F[y == c].sum(axis=0) for c in range(classes)]),
        "counts": np.array([int((y == c).sum()) for c in range(classes)]),
    }


def subtract(total: dict, part: dict) -> dict:
    """Моменти навчальної частини = усе мінус вилучена смуга."""
    return {"gram": total["gram"] - part["gram"],
            "sums": total["sums"] - part["sums"],
            "counts": total["counts"] - part["counts"]}


def discriminant(moment: dict, width: int) -> dict:
    """Лінійний дискримінант із моментів, у закритій формі.

    Спільна коваріація: W = Σ_c (X_c − μ_c)ᵀ(X_c − μ_c) = G − Σ_c n_c μ_c μ_cᵀ.
    Повертає ваги `w` і зсуви `b` для score = x·w + b.

    Коваріація обертається як є: подій на порядок більше за колонки,
    і `float64` це тримає. Обумовленість перевіряється явно — гірша за
    `COND_LIMIT` дає помилку, а не тихо зіпсований результат (оцінка —
    з діагоналі розкладу Холецького, повний SVD для цього не потрібен).

    Дискримінант інваріантний до лінійного перетворення фіч: масштаб на
    результат не впливає, скейлер не потрібен.
    """
    counts = moment["counts"].astype(float)
    means = moment["sums"][:, :width] / counts[:, None]
    scatter = moment["gram"][:width, :width] - (means * counts[:, None]).T @ means
    cov = scatter / (counts.sum() - len(counts))
    try:                       # не додатно визначена — Холецький впаде
        factor = np.diagonal(np.linalg.cholesky(cov))
    except np.linalg.LinAlgError as error:
        raise ValueError("коваріація вироджена") from error
    conditioning = float((factor.max() / factor.min()) ** 2)
    if conditioning > COND_LIMIT:
        raise ValueError("коваріація вироджена (оцінка обумовленості "
                         f"{conditioning:.1e} > {COND_LIMIT:.0e})")
    solved = np.linalg.solve(cov, means.T)               # Σ⁻¹ μ_c по колонках
    penalty = 0.5 * np.einsum("cd,dc->c", means, solved)
    priors = {"freq": counts / counts.sum(),
              "equal": np.full(len(counts), 1.0 / len(counts))}
    return {"w": solved,
            "b": {name: -penalty + np.log(value)
                  for name, value in priors.items()}}


# ----------------------------------------------------------- перевірка

def blocked_folds(size: int, folds: int = FOLDS) -> list[np.ndarray]:
    """Блокові частини: підряд у часі, а не рендомно — сусідні пачки схожі."""
    return np.array_split(np.arange(size), folds)


def band(size: int, block: np.ndarray, purge: int) -> np.ndarray:
    """Смуга, вилучена з навчання: сама частина плюс покриття пачок навколо."""
    mask = np.zeros(size, dtype=bool)
    mask[max(0, block[0] - purge):block[-1] + 1 + purge] = True
    return mask


def metrics(pred: np.ndarray, true: np.ndarray,
            classes: int = len(PHASES)) -> dict:
    """Метрики класифікації (rules/03-models.md): accuracy, precision, recall,
    f1, матриця помилок, розподіл по класах."""
    size = classes
    matrix = np.zeros((size, size), dtype=int)
    for t, p in zip(true, pred):
        matrix[t, p] += 1
    support = matrix.sum(axis=1)
    predicted = matrix.sum(axis=0)
    hit = np.diag(matrix)
    with np.errstate(invalid="ignore", divide="ignore"):
        recall = np.where(support > 0, hit / np.maximum(support, 1), 0.0)
        precision = np.where(predicted > 0, hit / np.maximum(predicted, 1), 0.0)
        f1 = np.where(precision + recall > 0,
                      2 * precision * recall / np.maximum(precision + recall, 1e-12),
                      0.0)
    balanced = float(recall.mean())
    # похибка збалансованої точності: середнє по класах, кожен — біноміальний
    se_balanced = float(np.sqrt(
        (recall * (1 - recall) / np.maximum(support, 1)).sum()) / size)
    return {
        "accuracy": float(hit.sum() / max(len(true), 1)),
        "balanced": balanced,
        "balanced_se": se_balanced,
        "macro_f1": float(f1.mean()),
        "precision": [float(v) for v in precision],
        "recall": [float(v) for v in recall],
        "f1": [float(v) for v in f1],
        "support": [int(v) for v in support],
        "predicted": [int(v) for v in predicted],
        "confusion": matrix.tolist(),
    }


def evaluate(F: np.ndarray, y: np.ndarray, total: dict, bands: list[dict],
             blocks: list[np.ndarray], width: int,
             classes: int = len(PHASES)) -> dict:
    """Прогноз поза своєю частиною (out-of-fold) для пачки шириною `width`."""
    pred = {name: np.full(len(y), -1) for name in VARIANTS}
    for block, part in zip(blocks, bands):
        model = discriminant(subtract(total, part), width)
        score = F[block, :width] @ model["w"]
        for name in VARIANTS:
            pred[name][block] = (score + model["b"][name]).argmax(axis=1)
    return {name: metrics(pred[name], y, classes) for name in VARIANTS}


def baseline(y: np.ndarray, names: tuple = PHASES) -> dict:
    """База порівняння: завжди найчастіший клас."""
    counts = np.bincount(y, minlength=len(names))
    top = int(counts.argmax())
    share = float(counts[top] / counts.sum())
    return {
        "class": names[top],
        "accuracy": share,
        "accuracy_se": float(np.sqrt(share * (1 - share) / len(y))),
        "balanced": 1.0 / len(names),
        "macro_f1": float(2 * share / (1 + share) / len(names)),
        "counts": {name: int(counts[i]) for i, name in enumerate(names)},
    }


def persistence(y: np.ndarray, rows: np.ndarray) -> dict:
    """Оракул: когорта цілі = когорта попередньої події.

    Мітки минулих подій у реальному часі невідомі (зігзаг підтверджується
    майбутнім), тому це не модель, а верхня межа: скільки структури взагалі
    є в задачі.
    """
    previous = y[rows - 1]
    known = previous >= 0
    return {"accuracy": float((previous[known] == y[rows][known]).mean()),
            "coverage": float(known.mean())}


def verdict(step: dict, base: dict, sigma: float = SIGMA) -> dict:
    """Чи є результат на цій сходинці.

    A — напрямок: точність вище за базу більш ніж на `sigma` похибок.
    B — усі чотири когорти: збалансована точність (рівні апріорні) вище
        за випадкову 0.25 більш ніж на `sigma` похибок.
    """
    freq, equal = step["freq"], step["equal"]
    gain = freq["accuracy"] - base["accuracy"]
    lift = equal["balanced"] - base["balanced"]
    return {
        "a": bool(gain > sigma * base["accuracy_se"]),
        "a_sigma": float(gain / base["accuracy_se"]) if base["accuracy_se"] else 0.0,
        "a_gain": float(gain),
        "b": bool(lift > sigma * equal["balanced_se"]),
        "b_sigma": float(lift / equal["balanced_se"]) if equal["balanced_se"] else 0.0,
        "b_gain": float(lift),
    }


# -------------------------------------------------------------- сходинки

def ladder(sample: dict, y: np.ndarray, n_max: int, folds: int = FOLDS,
           sigma: float = SIGMA, step: int = 1, log=print) -> dict:
    """Пачка від 2 подій із кроком +1 до стелі `n_max`.

    Набір цільових подій і смуги вилучення однакові для всіх N (беруться по
    стелі), тому сходинки порівнюються між собою напряму.
    """
    rows = packet_rows(y, sample["points"], n_max)
    if len(rows) < folds * (2 * n_max + len(PHASES)):
        raise ValueError("замало подій для такої стелі пачки")
    F = design(sample["points"], rows, n_max)
    target = y[rows]
    blocks = blocked_folds(len(rows), folds)
    total = moments(F, target)
    bands = [moments(F[band(len(rows), block, n_max)],
                     target[band(len(rows), block, n_max)]) for block in blocks]
    base = baseline(target)

    steps, found = [], {"a": None, "b": None}
    for width in range(2, n_max + 1, step):
        started = time.time()
        result = evaluate(F, target, total, bands, blocks, 2 * width)
        mark = verdict(result, base, sigma)
        steps.append({"n": width, "seconds": round(time.time() - started, 3),
                      **result, "verdict": mark})
        for key in ("a", "b"):
            if mark[key] and found[key] is None:
                found[key] = width
        log(f"  N={width:4d} acc={result['freq']['accuracy']:.4f} "
            f"({mark['a_sigma']:+5.1f} SE)  bal={result['equal']['balanced']:.4f} "
            f"({mark['b_sigma']:+5.1f} SE)  {steps[-1]['seconds']:5.2f}s")
    best = max(steps, key=lambda item: item["freq"]["accuracy"])
    return {
        "rows": rows,
        "packets": int(len(rows)),
        "baseline": base,
        "oracle": {"persistence": persistence(y, rows)},
        "steps": steps,
        "found": found,
        "best": {"n": best["n"], "accuracy": best["freq"]["accuracy"],
                 "balanced": best["equal"]["balanced"]},
    }


# ---------------------------------------------------------------- вивід

def payload(run: dict, sample: dict, cap: dict, args) -> dict:
    """Дані для файлу дослідження й вкладки дашборду."""
    counts = run["baseline"]["counts"]
    return {
        "pair": "BTC_USDT",
        "class": "клас210х14х2",
        "sample": args.sample,
        "source": f"data/datasets/BTC_USDT/class210x14x2/{args.sample}.npz",
        "script": "research/05-next-cohort-forecast/scripts/next_cohort.py",
        "command": ("python3 research/05-next-cohort-forecast/scripts/"
                    f"next_cohort.py --outer {args.outer} --inner {args.inner} "
                    f"--folds {args.folds} --sigma {args.sigma} "
                    f"--step {args.step}"),
        "method": [
            "1. Вибірка train читається як є, події сортуються за timestamp.",
            "2. Точка події — середнє по її 15 блоках: 2 числа на подію.",
            f"3. Когорта події — розмітка дослідження 04: зігзаг {args.outer:.1%} "
            f"× вкладений {args.inner:.1%}.",
            "4. Пачка — N подій підряд перед ціллю; сама ціль у пачку не "
            "входить, її фічі не використовуються.",
            "5. Класи описуються нормальним розподілом зі спільною "
            "коваріацією; рішення — лінійний дискримінант за формулою Байєса. "
            "Ітеративного навчання немає: середні, коваріація й апріорні — "
            "закрита форма.",
            f"6. Оцінка — {args.folds} блокових частин train; навчальна частина "
            "не містить пачок, що перетинають перевірочну (вилучення смуги "
            f"± {cap['cap']} подій).",
            "7. Апріорні беруться у двох варіантах: частоти когорт (метрика — "
            "точність) і рівні (метрика — збалансована точність).",
            f"8. Пачка росте з 2 подій кроком +{args.step} до стелі "
            f"{cap['cap']} подій = {MOVES_IN_CAP} рухи зігзагу "
            f"{args.outer:.1%}.",
        ],
        "params": {
            "outer": args.outer, "inner": args.inner, "folds": args.folds,
            "sigma": args.sigma, "step": args.step,
            "purge": cap["cap"], "features_per_event": 2,
            "feature": "точка події: середнє balance і d_balance по 15 блоках",
        },
        "cap": {**cap, "moves_used": MOVES_IN_CAP},
        "events": sample["events"],
        "packets": run["packets"],
        "cohorts": [{**item, "count": counts[item["id"]]} for item in CLASSES],
        "phases": list(PHASES),
        "baseline": run["baseline"],
        "oracle": run["oracle"],
        "found": run["found"],
        "best": run["best"],
        "ladder": [{k: v for k, v in step.items() if k != "seconds"}
                   for step in run["steps"]],
        "note": ("Мітки когорт будуються по ряду цін усієї вибірки train, "
                 "тому вони відомі лише заднім числом. Фічі пачки — тільки "
                 "минулі події, ціль у пачку не входить."),
    }


def _short(path: Path) -> str:
    """Шлях відносно кореня проєкту, якщо він там лежить."""
    try:
        return str(path.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def _fmt(value: float) -> str:
    return f"{value:.4f}"


def build(args) -> dict:
    sample = load_sample(Path(args.input))
    marks = cohorts(sample["price"], args.outer, args.inner)
    cap = packet_cap(sample["price"], args.outer)
    n_max = args.max or cap["cap"]
    cap = {**cap, "cap": n_max}
    print(f"подій {sample['events']}, півоти {marks['pivots']}, "
          f"стеля пачки {n_max} подій")
    run = ladder(sample, marks["y"], n_max, args.folds, args.sigma, args.step)
    data = payload(run, sample, cap, args)
    data["pivots"] = marks["pivots"]

    results = Path(args.out) if args.out else RESULTS
    results.mkdir(parents=True, exist_ok=True)
    path = results / "forecast.json"
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    print(f"      {_short(path)}")

    # коротка мітка прогону — для картки дослідження, без сходинок
    meta = results / "forecast.meta.json"
    meta.write_text(json.dumps(
        {k: v for k, v in data.items() if k != "ladder"},
        ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"      {_short(meta)}")
    print(f"база {_fmt(run['baseline']['accuracy'])} "
          f"({run['baseline']['class']}), критерій A з N={run['found']['a']}, "
          f"критерій B з N={run['found']['b']}, краще "
          f"{_fmt(run['best']['accuracy'])} на N={run['best']['n']}")
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=str(DEFAULT_INPUT))
    parser.add_argument("--sample", default="train")
    parser.add_argument("--outer", type=float, default=zigzag.OUTER_THRESHOLD)
    parser.add_argument("--inner", type=float, default=zigzag.INNER_THRESHOLD)
    parser.add_argument("--folds", type=int, default=FOLDS)
    parser.add_argument("--sigma", type=float, default=SIGMA)
    parser.add_argument("--step", type=int, default=1)
    parser.add_argument("--max", type=int, default=0,
                        help="стеля пачки; 0 — 4 рухи зігзагу 2.3")
    parser.add_argument("--out", default="", help="куди писати; типово results/")
    build(parser.parse_args())


if __name__ == "__main__":
    main()
