"""Дослідження 05, етап 1: когорти подій + кількості по вибірках.

Когорта події — дві мітки разом: напрямок великого руху 2.3 і напрямок
власного відрізка 0.8 (ділянки між сусідніми півотами обʼєднаного ряду
півотів). Це розмітка, на якій далі вчиться прогноз когорти наступної події.

Схема — ідеалізований зігзаг: один рух 2.3 вгору з корекціями, один вниз
з корекціями і один рух без жодної корекції. Форма схематична, **кількості
справжні** — рахуються по вибірках train / val / test.

Запуск:
    python3 research/05-next-cohort-forecast/scripts/class_schema.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))

import class210x14x2  # noqa: E402
import zigzag  # noqa: E402


def merge_pivots(outer: list, inner: list) -> list:
    """Півоти 2.3 і вкладені 0.8 в один ряд за порядком індексів."""
    return sorted(outer + inner, key=lambda p: p.index)


DATASET = (PROJECT_ROOT / "data" / "datasets" / "BTC_USDT" / "class210x14x2")
PHASES = ("up", "up_pull", "down", "down_pull")
RESULTS = RESEARCH_DIR / "results"
SAMPLES = ("train", "val", "test")
# Серединні відрізки розділені: за трендом 2.3 і проти нього — це різні класи
KINDS = ("2.3-0.8", "0.8-0.8", "0.8-0.8 проти", "0.8-2.3", "2.3-2.3")
COUNTER = "0.8-0.8 проти"

# Колір — за напрямком самого відрізка; насиченість — чи йде він за трендом 2.3
CLASSES = [
    {"id": "up", "title": "зростання", "big": "up", "segment": "up",
     "color": "#46c882"},
    {"id": "up_pull", "title": "протирух у зростанні", "big": "up",
     "segment": "down", "color": "#f0a0a0"},
    {"id": "down", "title": "падіння", "big": "down", "segment": "down",
     "color": "#eb5a5a"},
    {"id": "down_pull", "title": "протирух у падінні", "big": "down",
     "segment": "up", "color": "#8ecfae"},
]

# Схематичний зігзаг: (x, y, розмір півота). Форма умовна, не з даних.
PIVOTS = [
    (0, 0, "2.3"), (2, 4, "0.8"), (3, 3, "0.8"), (5, 7, "0.8"), (6, 6, "0.8"),
    (9, 11, "2.3"), (11, 7, "0.8"), (12, 8, "0.8"), (14, 4, "0.8"),
    (15, 5, "0.8"), (18, 1, "2.3"), (24, 9, "2.3"),
]


def phases(prices: np.ndarray, outer: float, inner: float) -> dict:
    """Клас кожної події: напрямок руху 2.3 × напрямок її відрізка 0.8.

    Півоти зігзагу `outer` і вкладеного `inner` зливаються в один ряд за
    індексом. Ділянка між двома сусідніми півотами — відрізок; півот належить
    наступному руху, тому подія `i` лежить у відрізку `left.index <= i <
    right.index`. Останній півот ряду наступного руху не має, тому лишається
    у своєму відрізку. Події поза зігзагом (до першого півота й після
    останнього) дістають `none` і не входять у жоден клас.

    Повертає:
        phase  — (N,) `up` / `up_pull` / `down` / `down_pull` / `none`
        kind   — (N,) тип відрізка `<розмір лівого>-<розмір правого>`
        pivots — скільки півотів у кожному зігзагу
    """
    prices = np.asarray(prices, dtype=float)
    outer_pivots = zigzag.zigzag(prices, outer)
    inner_pivots = zigzag.nested_zigzag(prices, outer_pivots, inner)
    sizes = {id(p): "2.3" for p in outer_pivots}
    merged = merge_pivots(outer_pivots, inner_pivots)

    phase = np.full(len(prices), "none", dtype="<U9")
    kind = np.full(len(prices), "none", dtype="<U16")
    last = merged[-1].index if merged else -1
    for move in zigzag.moves(outer_pivots):
        big = move.direction
        inside = [p for p in merged if move.start <= p.index <= move.end]
        for left, right in zip(inside, inside[1:]):
            segment = "up" if left.kind == "low" else "down"
            value = big if segment == big else f"{big}_pull"
            stop = right.index + 1 if right.index == last else right.index
            phase[left.index:stop] = value
            kind[left.index:stop] = (
                f"{sizes.get(id(left), '0.8')}-{sizes.get(id(right), '0.8')}")
    return {"phase": phase, "kind": kind,
            "pivots": {"outer": len(outer_pivots), "inner": len(inner_pivots)}}


def schema() -> dict:
    """Ідеалізований зігзаг: півоти й відрізки з типом і класом."""
    pivots = [{"x": x, "y": y, "size": size,
               "kind": "low" if index == 0 or PIVOTS[index - 1][1] > y else "high"}
              for index, (x, y, size) in enumerate(PIVOTS)]
    big = ["up"] * 5 + ["down"] * 5 + ["up"]      # рух 2.3, у який вкладено відрізок
    segments = []
    for index, (left, right) in enumerate(zip(PIVOTS, PIVOTS[1:])):
        segment = "up" if right[1] > left[1] else "down"
        phase = next(item["id"] for item in CLASSES
                     if item["big"] == big[index] and item["segment"] == segment)
        kind = f"{left[2]}-{right[2]}"
        if segment != big[index]:
            kind = COUNTER
        segments.append({"from": index, "to": index + 1,
                         "kind": kind, "phase": phase})
    return {"pivots": pivots, "segments": segments}


def counts(outer: float, inner: float) -> dict:
    """Справжні кількості подій по класах і типах відрізків."""
    out = {}
    for name in SAMPLES:
        data = class210x14x2.load(DATASET / f"{name}.npz")
        order = np.argsort(data.timestamp)
        marks = phases(data.price_open[order].astype(float), outer, inner)
        phase, kind = marks["phase"], marks["kind"].astype("<U16")
        kind[np.char.endswith(phase.astype(str), "_pull")] = COUNTER
        out[name] = {
            "events": int(len(phase)),
            "outside": int((phase == "none").sum()),
            "pivots": marks["pivots"],
            "classes": {value: int((phase == value).sum()) for value in PHASES},
            "by_kind": {k: {value: int(((kind == k) & (phase == value)).sum())
                            for value in PHASES} for k in KINDS},
        }
    return out


def build(outer: float, inner: float) -> dict:
    payload = {
        "pair": "BTC_USDT",
        "class": "клас210х14х2",
        "source": "data/datasets/BTC_USDT/class210x14x2/",
        "script": "research/05-next-cohort-forecast/scripts/class_schema.py",
        "command": (f"python3 research/05-next-cohort-forecast/scripts/"
                    f"class_schema.py --outer {outer} --inner {inner}"),
        "method": [
            "1. Вибірка читається як є, події сортуються за timestamp.",
            f"2. По ряду price_open будується зігзаг {outer:.1%} і вкладений "
            f"{inner:.1%}; півоти обох зливаються в один ряд за індексом.",
            "3. Ділянка між сусідніми півотами — відрізок; його тип задають "
            "розміри півотів на кінцях; півот належить наступному руху.",
            "4. Відрізок, що йде проти великого руху 2.3, виноситься в "
            f"окремий тип «{COUNTER}».",
            "5. Клас події = напрямок руху 2.3 × напрямок її відрізка.",
            "6. Кількості рахуються окремо по train / val / test.",
        ],
        "thresholds": {"outer": outer, "inner": inner},
        "classes": CLASSES,
        "kinds": list(KINDS),
        "schema": schema(),
        "counts": counts(outer, inner),
        "note": ("Форма зігзагу на схемі умовна. Кількості — справжні: "
                 "зігзаг рахується по ряду price_open кожної вибірки."),
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    path = RESULTS / "classes.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding="utf-8")
    for name in SAMPLES:
        part = payload["counts"][name]
        print(f"{name:5s} {part['events']:6d} подій, поза зігзагом "
              f"{part['outside']:4d}, {part['classes']}")
    print(f"записано {path}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outer", type=float, default=zigzag.OUTER_THRESHOLD)
    parser.add_argument("--inner", type=float, default=zigzag.INNER_THRESHOLD)
    args = parser.parse_args()
    build(args.outer, args.inner)


if __name__ == "__main__":
    main()
