Reproduction kit — The ±0.15% Pivot Zone — Seventeen Ways to Describe an Event, One Honest Ceiling of 0.70
https://marketflowresear.ch/articles/the-pivot-zone-plus-minus-015-percent-seventeen-ways-to-describe-an-event/

research/27-pivot-zone-015/27-pivot-zone-015.md
    The research log (Ukrainian). Goal, data, plan, the exact scripts and command lines,
    every confirmed stage with its tables, and the conclusion. It is written so that the
    study can be rerun from scratch and give the same numbers.
research/27-pivot-zone-015/scripts/
    Scripts of this study, as referenced from the log.
rules/
    Project rules the log relies on: data and classes (01), labeling and zigzag legs (02),
    models and storage (03), trading (04), charts (05); rules/scripts holds the base
    scripts that build every class and dataset.
scripts/
    Shared helper scripts of the project.

Not included: the raw data. Every study reads second-by-second Binance order-book snapshots
(8 features + price, 6 coins, Feb 2026 onward) laid out as
DATA/<year>/<month>/<PAIR>/1S_<YYYY-MM-DD>_<PAIR>.csv — see rules/01-data-and-db.md for the
schema. Paths inside the scripts point to the original machine; change them to your copy.
Research, not financial advice.
