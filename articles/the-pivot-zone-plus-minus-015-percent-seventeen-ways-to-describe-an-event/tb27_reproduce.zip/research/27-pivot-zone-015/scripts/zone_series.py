"""Видача моделі на val рядом: ціна, зона і сирий сигнал на кожній події.

Дослідження: research/27-pivot-zone-015/
Правила: rules/05-visualization.md → Обовʼязкова компоновка
         rules/03-models.md → Навчання моделей

Таблиці етапу 2 кажуть, **скільки** модель влучає. Тут те саме показано
**де**: ряд валідації кожної монети з ціною, зігзагом, зоною ±0.15 % і
сирим сигналом моделі на кожній події — до порога, як є.

Беруться класи, у яких найкраща довжина пачки дала на val
**AUC вище `--auc`** (типово 0.68): решта від монетки не відрізняється,
і дивитись у них нема на що.

## Що в ряді

| Ряд | Що це |
| --- | ----- |
| `price` | ема10 ціни події |
| `pivots` | півоти зігзага 2.3 % у межах val |
| `zone` | 1 — пачка події лежить у зоні півота, 0 — ні |
| `score` | сира видача моделі на цій події, `null` — пачки немає |

## Поріг за замовчуванням

Поріг береться з **тесту** на повноті `RECALL`. Оцінки тесту — від
моделі, яка цієї монети не бачила (`відкладена монета`), інакше поріг
стояв би на числах, які модель запамʼятала. Клас, побудований на одній
монеті, відкласти нема чого: там поріг стоїть на оцінках у межах
навчання, і це записано в `edge_kind`.

Поріг у плашці рухають рукою — файл несе сирий сигнал, а не готові смуги.

Вхід : results/zone_classes.json — які класи брати і з яким `K`
       data/datasets/<PAIR>/<клас>/{train,val,test}.npz
Вихід: results/zone_series.json           — перелік класів і монет
       results/series_<клас>_<PAIR>.json  — ряд однієї монети

Запуск:
    python3 research/27-pivot-zone-015/scripts/zone_series.py
    python3 research/27-pivot-zone-015/scripts/zone_series.py --auc 0.6
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import zone_packs as zone  # noqa: E402
from zone_packs import CUT, END  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
AUC = 0.68                 # нижче цього класи в ряд не виводяться
RECALL = 0.2               # на якій повноті тесту стоїть поріг
DIGITS = 6


def picked_classes(data: dict, edge: float = AUC) -> list:
    """Класи заміру, у яких найкраще `K` дало AUC вище `edge`."""
    out = []
    for one in data.get("classes", ()):
        best = zone.best_row(one.get("rows", ()))
        if best and (best["val"]["auc"] or 0.0) > edge:
            out.append({"class": one["class"],
                        "class_title": one["class_title"],
                        "k": best["k"], "auc": best["val"]["auc"],
                        "ap": best["val"]["ap"],
                        "pairs": list(one["pairs"]),
                        "shape": list(one["shape"])})
    return sorted(out, key=lambda one: -one["auc"])


def coin_rows(coin: dict, k: int, step: int) -> dict:
    """Пачки однієї монети: числа, мітка, розбиття й місце в ряді."""
    ends, label = zone.label_of(coin, k)
    part = zone.part_of(coin, ends, k)
    return {"ends": ends, "y": label, "part": part,
            "test": zone.taken_test(label, part, step),
            "val": part == "val"}


def honest_test(coins: list, rows: list, k: int, seed: int) -> list:
    """Оцінки тесту від моделі, що цієї монети не бачила."""
    out = []
    for number, coin in enumerate(coins):
        others = [(one, row) for index, (one, row) in
                  enumerate(zip(coins, rows)) if index != number]
        if not others:
            out.append(None)
            continue
        x = np.vstack([zone.rows_of(one, row["ends"][row["test"]], k)
                       for one, row in others])
        y = np.concatenate([row["y"][row["test"]] for _, row in others])
        if y.sum() < 2 or y.sum() == len(y):
            out.append(None)
            continue
        model = zone.fit(x, y, seed)
        here = rows[number]
        out.append(model.predict_proba(
            zone.rows_of(coin, here["ends"][here["test"]], k))[:, 1])
    return out


def edge_of(rows: list, honest: list, inside: list,
            want: float = RECALL) -> tuple:
    """Поріг тесту на заданій повноті і чим його рахували."""
    values, kind = [], "відкладена монета"
    for number, row in enumerate(rows):
        score = honest[number]
        if score is None:
            score = inside[number]
            kind = "у межах навчання"
        values.append(score[row["y"][row["test"]] == 1])
    values = np.concatenate([one for one in values if len(one)])
    if not len(values):
        return None, kind
    return float(np.quantile(values, 1.0 - want)), kind


def one_class(item: dict, root: Path | None = None, width: float = zone.WIDTH,
              step: int = zone.NEG_STEP, seed: int = zone.SEED,
              want: float = RECALL, log=print) -> tuple:
    """Модель класу на його найкращій довжині пачки і ряди монет."""
    k = item["k"]
    coins = zone.collect(root, item["pairs"], width, item["class"], log)
    rows = [coin_rows(coin, k, step) for coin in coins]
    x = np.vstack([zone.rows_of(coin, row["ends"][row["test"]], k)
                   for coin, row in zip(coins, rows)])
    y = np.concatenate([row["y"][row["test"]] for row in rows])
    model = zone.fit(x, y, seed)
    place, inside = 0, []
    test_score = model.predict_proba(x)[:, 1]
    for row in rows:
        count = int(row["test"].sum())
        inside.append(test_score[place:place + count])
        place += count
    honest = honest_test(coins, rows, k, seed)
    edge, kind = edge_of(rows, honest, inside, want)
    log(f"      поріг тесту на повноті {want}: {edge:.4f} ({kind})")
    out = []
    for coin, row in zip(coins, rows):
        out.append(coin_series(coin, row, model, k, edge, kind, item))
        log(f"      {coin['pair']}: подій val {out[-1]['events']}, у зоні "
            f"{out[-1]['in_zone']}, півотів {len(out[-1]['pivots'])}")
    return edge, kind, out


def coin_series(coin: dict, row: dict, model, k: int, edge, kind: str,
                item: dict) -> dict:
    """Ряд val однієї монети: ціна, зігзаг, зона і сирий сигнал."""
    inside = np.flatnonzero(row["val"])
    body = {"pair": coin["pair"], "class": item["class"],
            "class_title": item["class_title"], "k": k,
            "auc": item["auc"], "edge": zone.cell(edge), "edge_kind": kind,
            "recall": RECALL, "period": zone.PERIOD,
            "threshold": zone.THRESHOLD,
            "event_seconds": zone.EVENT_LENGTH,
            "width": zone.WIDTH, "ready": False, "events": 0}
    if not len(inside):
        return body
    ends = row["ends"][row["val"]]
    low, high = int(ends[0]), int(ends[-1])
    index = np.arange(low, high + 1)
    score = model.predict_proba(zone.rows_of(coin, ends, k))[:, 1]
    line = [None] * len(index)
    zone_line = [0] * len(index)
    label = row["y"][row["val"]]
    for place, value, mark in zip(ends, score, label):
        line[int(place) - low] = round(float(value), 4)
        zone_line[int(place) - low] = int(mark)
    body.update({
        "ready": True, "events": int(len(index)),
        "from_utc": zone.leg_deciles.utc(coin["t"][low]),
        "to_utc": zone.leg_deciles.utc(coin["t"][high]),
        "t": coin["t"][index].astype(int).tolist(),
        "price": [round(float(one), DIGITS) for one in coin["ema"][index]],
        "pivots": [{"t": int(coin["t"][point.index]),
                    "ema": round(float(coin["ema"][point.index]), DIGITS),
                    "kind": point.kind}
                   for point in coin["pivots"]
                   if low <= point.index <= high],
        "zone": zone_line, "score": line,
        "in_zone": int(sum(zone_line)),
        "packs": int(len(ends))})
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--auc", type=float, default=AUC)
    parser.add_argument("--recall", type=float, default=RECALL)
    parser.add_argument("--width", type=float, default=zone.WIDTH)
    parser.add_argument("--step", type=int, default=zone.NEG_STEP)
    parser.add_argument("--seed", type=int, default=zone.SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    source = args.out / "zone_classes.json"
    if not source.exists():
        raise SystemExit("немає zone_classes.json: спершу zone_classes.py")
    data = json.loads(source.read_text(encoding="utf-8"))
    picked = picked_classes(data, args.auc)
    if not picked:
        raise SystemExit(f"немає класів з AUC вище {args.auc}")

    args.out.mkdir(parents=True, exist_ok=True)
    listed = []
    for item in picked:
        print(f"[{item['class_title']}] K {item['k']}, AUC {item['auc']}, "
              f"монет {len(item['pairs'])}")
        edge, kind, series = one_class(item, args.data, args.width,
                                       args.step, args.seed, args.recall)
        for body in series:
            (args.out / f"series_{item['class']}_{body['pair']}.json"
             ).write_text(json.dumps(body, ensure_ascii=False),
                          encoding="utf-8")
        listed.append(dict(item, edge=zone.cell(edge), edge_kind=kind,
                           coins=[{"pair": body["pair"],
                                   "events": body["events"],
                                   "in_zone": body["in_zone"],
                                   "pivots": len(body.get("pivots", ()))}
                                  for body in series]))

    (args.out / "zone_series.json").write_text(json.dumps({
        "script": "research/27-pivot-zone-015/scripts/zone_series.py",
        "command": "python3 research/27-pivot-zone-015/scripts/"
                   "zone_series.py",
        "auc_edge": args.auc, "recall": args.recall,
        "width": args.width, "threshold": zone.THRESHOLD,
        "period": zone.PERIOD, "event_seconds": zone.EVENT_LENGTH,
        "neg_step": args.step, "max_iter": zone.MAX_ITER,
        "leaves": zone.LEAVES, "rate": zone.RATE, "seed": args.seed,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "classes": listed, "ready": True}, ensure_ascii=False),
        encoding="utf-8")
    print(f"записано {args.out}/zone_series.json")


if __name__ == "__main__":
    main()
