"""Цінова зона розвороту ±0.15 % на ема10 і градієнтний бустинг на ній.

Дослідження: research/27-pivot-zone-015/
Правила: rules/02-markup.md → зігзаг
         rules/03-models.md → Навчання моделей

Зігзаг 2.3 % стоїть на `ема10` ціни події — той самий, що в дослідженнях
21–26. Біля кожного півота ціна деякий час тримається його рівня, і саме
цей відрізок тут і є **зоною**:

    зона півота p = суцільний відрізок подій навколо p,
                    де |ема / ема[p] − 1| ≤ 0.0015

Ліва межа — перша подія ліворуч, де ема відійшла більше ніж на 0.15 %,
права — так само праворуч. Зони сусідніх півотів не перетинаються: між
двома півотами ціна проходить щонайменше 2.3 %.

## Питання

Одне: **чи є ця зона зоною розвороту** — чи відрізняє градієнтний бустинг
події зони від усіх інших подій ряду, маючи тільки числа класу.

## Приклад і мітка

Пачка з `K` подій підряд закінчується на події `e`. Питання ставиться на
**кожній події** ряду — усіх монет класу, без відбору:

    y[e] = 1, якщо всі K подій пачки лежать в одній зоні

Вхід моделі — сирі числа класу цих `K` подій, без жодної згортки.

## Довжина пачки

`K` росте `1, 2, 3, 4 …` — рівно доти, доки пачка ще вміщається в зону.
Стеля — **медіана довжини зон** по всіх монетах: на ній пачка вміщається
щонайменше в половину зон, далі позитивних прикладів лишається надто
мало. Скільки зон вміщає кожне `K`, лежить у `fits`.

## Клас

Замір не привʼязаний до одного класу: `--class` бере будь-який клас
проєкту зі свого датасету. Ема й півоти рахуються з **власної** ціни
класу (`price_open`), тому кожен клас міряється на своїй сітці подій.
Усі класи разом — [`zone_classes.py`](zone_classes.py).

## Розбиття й навчання

Свіже вікно `CUT … END` — **валідація**, усе інше — **тест**:

    подія скінчилась до CUT               -> тест
    подія з CUT і до END                  -> валідація

Приклад іде в одну частину **цілком**: і перша подія пачки, і остання
лежать по один бік межі. Модель — `HistGradientBoosting`, навчання на
тесті, видача на **всіх** подіях валідації.

Зона займає близько 2 % ряду, тому в тесті негативні приклади беруться
кожен `NEG_STEP`-й, позитивні — всі: це прибирає з навчання чотири пʼятих
рядків, які нічого не додають, і лишає замір на валідації недоторканим.

Вхід : data/datasets/<PAIR>/<клас>/{train,val,test}.npz
Вихід: results/zone_packs.json

Запуск:
    python3 research/27-pivot-zone-015/scripts/zone_packs.py
    python3 research/27-pivot-zone-015/scripts/zone_packs.py --max-k 4
    python3 research/27-pivot-zone-015/scripts/zone_packs.py \
        --class class210x10x9
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
X7DD_SCRIPTS = PROJECT_ROOT / "research" / "22-leg-edge-spread" / "scripts"
SIGNAL_SCRIPTS = PROJECT_ROOT / "research" / "23-reversal-signal" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))
sys.path.insert(0, str(X7DD_SCRIPTS))
sys.path.insert(0, str(SIGNAL_SCRIPTS))

import class_card  # noqa: E402
import leg_context  # noqa: E402
import leg_deciles  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, PARTS, stamp  # noqa: E402
from class210ema4 import ema  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402
from zigzag import zigzag  # noqa: E402

DATASETS = PROJECT_ROOT / "data" / "datasets"
RESULTS = RESEARCH_DIR / "results"
CLASS = "class210x10m1x7dd"
WIDTH = 0.0015             # ±0.15 % від ціни півота на ема
THRESHOLD = leg_deciles.THRESHOLD
PERIOD = leg_deciles.PERIOD
ALL_PARTS = PARTS + ("test",)   # у старих класів є ще й test
NEG_STEP = 4               # кожен який негативний приклад іде в навчання
MAX_ITER = leg_context.MAX_ITER
LEAVES = leg_context.LEAVES
RATE = leg_context.RATE
CURVE = (0.05, 0.1, 0.2, 0.3, 0.5)
SEED = 0
EPS = 1e-12
DIGITS = 4


def cell(value):
    value = float(value)
    if not np.isfinite(value):
        return None
    return round(value, DIGITS) if abs(value) < 1e6 else round(value, 1)


def card_of(name: str) -> dict:
    """Картка класу з rules/scripts/class_card.py."""
    for card in class_card.CLASSES:
        if card["id"] == name:
            return card
    raise SystemExit(f"невідомий клас: {name}")


def classes(root: Path | None = None, pairs=PAIRS) -> list:
    """Класи проєкту, у яких є побудований датасет хоч однієї монети."""
    out = []
    for card in class_card.CLASSES:
        folder = card.get("dataset")
        if not folder:
            continue
        coins = pairs_of(card["id"], root, pairs)
        if coins:
            out.append(card["id"])
    return out


def parts_of(folder: Path) -> list:
    """Вибірки класу, які лежать на диску: `train`, `val`, `test`."""
    return [part for part in ALL_PARTS if (folder / f"{part}.npz").exists()]


def pairs_of(name: str, root: Path | None = None, pairs=PAIRS) -> list:
    """Монети, для яких клас побудований."""
    folder = card_of(name).get("dataset")
    if not folder:
        return []
    base = root or DATASETS
    return [pair for pair in pairs
            if all((base / pair / folder / f"{part}.npz").exists()
                   for part in PARTS)]


def series(pair: str, name: str = CLASS, root: Path | None = None) -> dict:
    """Події класу одним рядом за часом: усі вибірки разом.

    Беруться **всі** файли, які клас має: `train`, `val` і `test`.
    Розбиття класу тут ні до чого — воно в кожної сімʼї своє (у старих
    класів випадкове, перемішане в часі), а замір ділить ряд заново за
    датою. Пропустити `test` означало б викинути частину ряду.

    Час події — `t_start`, якщо клас його має, інакше `timestamp`. Ціна —
    власна `price_open` класу: кожен клас міряється на своїй сітці подій.
    """
    card = card_of(name)
    module = importlib.import_module(name)
    folder = (root or DATASETS) / pair / card["dataset"]
    x, t, price = [], [], []
    for part in parts_of(folder):
        dataset = module.load(folder / f"{part}.npz")
        x.append(np.asarray(dataset.x, dtype=np.float32))
        t.append(np.asarray(getattr(dataset, "t_start", dataset.timestamp)))
        price.append(np.asarray(dataset.price_open, dtype=float))
    x = np.concatenate(x)
    t = np.concatenate(t)
    price = np.concatenate(price)
    order = np.argsort(t, kind="stable")
    return {"x": x[order], "t": t[order].astype(np.int64),
            "price": price[order], "features": list(module.FEATURES)}


def zones_of(ema_row: np.ndarray, pivots: list, width: float = WIDTH) -> tuple:
    """Зона кожного півота: `-1` поза зонами, інакше номер зони.

    Зона росте від півота в обидва боки, поки ема тримається його рівня
    з точністю `width`. Клітинка, вже зайнята сусідньою зоною, не
    перезаписується — так номер зони лишається однозначним.
    """
    zone = np.full(len(ema_row), -1, dtype=np.int32)
    spans = []
    for number, point in enumerate(pivots):
        place = int(point.index)
        if place >= len(ema_row):
            break
        level = float(ema_row[place])
        if not np.isfinite(level) or abs(level) < EPS:
            continue
        first = place
        while first > 0 and abs(ema_row[first - 1] / level - 1.0) <= width:
            first -= 1
        last = place
        edge = len(ema_row) - 1
        while last < edge and abs(ema_row[last + 1] / level - 1.0) <= width:
            last += 1
        free = zone[first:last + 1] < 0
        zone[first:last + 1] = np.where(free, number, zone[first:last + 1])
        spans.append({"zone": number, "pivot": place, "kind": point.kind,
                      "first": first, "last": last,
                      "events": int(free.sum())})
    return zone, spans


def one_coin(pair: str, root: Path | None = None, period: int = PERIOD,
             threshold: float = THRESHOLD, width: float = WIDTH,
             name: str = CLASS) -> dict:
    """Ряд однієї монети: клас, ема, півоти й зони ±width."""
    data = series(pair, name, root)
    smooth = ema(data["price"], period)
    pivots = zigzag(smooth, threshold)
    zone, spans = zones_of(smooth, pivots, width)
    return {"pair": pair, "x": data["x"], "t": data["t"],
            "features": data["features"], "ema": smooth, "pivots": pivots,
            "zone": zone, "spans": spans}


def collect(root: Path | None = None, pairs=PAIRS, width: float = WIDTH,
            name: str = CLASS, log=print) -> list:
    coins = []
    for pair in pairs:
        coin = one_coin(pair, root, width=width, name=name)
        coins.append(coin)
        inside = int((coin["zone"] >= 0).sum())
        log(f"      {pair}: подій {len(coin['t'])}, півотів "
            f"{len(coin['pivots'])}, зон {len(coin['spans'])}, у зонах "
            f"{inside} подій ({inside / max(len(coin['t']), 1) * 100:.1f} %)")
    return coins


def zone_lengths(coins: list) -> np.ndarray:
    return np.array([one["events"] for coin in coins for one in coin["spans"]],
                    dtype=np.int64)


def zone_report(coin: dict) -> dict:
    lengths = np.array([one["events"] for one in coin["spans"]],
                       dtype=np.int64)
    inside = int((coin["zone"] >= 0).sum())
    events = int(len(coin["t"]))
    return {"pair": coin["pair"], "events": events,
            "pivots": len(coin["pivots"]), "zones": int(len(lengths)),
            "in_zone": inside, "share": cell(inside / max(events, 1)),
            "median": cell(np.median(lengths)) if len(lengths) else None,
            "low": cell(np.quantile(lengths, 0.25)) if len(lengths) else None,
            "high": cell(np.quantile(lengths, 0.75)) if len(lengths) else None,
            "shortest": int(lengths.min()) if len(lengths) else 0,
            "longest": int(lengths.max()) if len(lengths) else 0}


def fits_report(lengths: np.ndarray, grid) -> list:
    """Скільки зон вміщає пачку кожної довжини."""
    return [{"k": int(k), "zones": int((lengths >= k).sum()),
             "share": cell((lengths >= k).mean() if len(lengths) else 0.0)}
            for k in grid]


def label_of(coin: dict, k: int) -> tuple:
    """Мітка на кожній події, де пачка з `k` подій вміщається в ряд."""
    ends = np.arange(k - 1, len(coin["zone"]), dtype=np.int64)
    zone = coin["zone"]
    label = ((zone[ends] >= 0) & (zone[ends] == zone[ends - k + 1]))
    return ends, label.astype(np.int8)


def part_of(coin: dict, ends: np.ndarray, k: int) -> np.ndarray:
    """тест / валідація / поза: пачка цілком по один бік межі.

    Валідація — свіже вікно `CUT … END`, тест — усе інше.
    """
    edge, right = stamp(CUT), stamp(END)
    first = coin["t"][ends - k + 1]
    last = coin["t"][ends]
    return np.where(last < edge, "test",
                    np.where((first >= edge) & (last < right), "val", "поза"))


def broken(coin: dict, ends: np.ndarray, k: int) -> np.ndarray:
    """Пачки, всередині яких є пропуск часу."""
    if k == 1:
        return np.zeros(len(ends), dtype=bool)
    span = coin["t"][ends] - coin["t"][ends - k + 1]
    return span != EVENT_LENGTH * (k - 1)


def rows_of(coin: dict, ends: np.ndarray, k: int) -> np.ndarray:
    """Сирі числа класу `k` подій пачки одним рядком на пачку."""
    flat = coin["x"].reshape(len(coin["x"]), -1).astype(np.float32)
    view = np.lib.stride_tricks.sliding_window_view(flat, (k, flat.shape[1]))
    picked = view[ends - k + 1, 0]
    out = picked.reshape(len(ends), -1)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)


def taken_test(label: np.ndarray, part: np.ndarray,
               step: int = NEG_STEP) -> np.ndarray:
    """Приклади тесту: усі позитивні і кожен `step`-й негативний."""
    test = part == "test"
    place = np.arange(len(label))
    return test & ((label == 1) | (place % max(step, 1) == 0))


def one_k(coins: list, k: int, step: int = NEG_STEP, seed: int = SEED,
          log=print) -> dict:
    """Одна довжина пачки: навчання на тесті, видача на всій валідації."""
    started = time.time()
    test_x, test_y, val_x, val_y, val_coin = [], [], [], [], []
    body = {"k": int(k), "columns": 0,
            "test": {"packs": 0, "zone": 0, "taken": 0},
            "val": {"packs": 0, "zone": 0}, "gaps": 0}
    for number, coin in enumerate(coins):
        ends, label = label_of(coin, k)
        part = part_of(coin, ends, k)
        body["gaps"] += int(broken(coin, ends, k).sum())
        pick = taken_test(label, part, step)
        val = part == "val"
        body["test"]["packs"] += int((part == "test").sum())
        body["test"]["zone"] += int(label[part == "test"].sum())
        body["test"]["taken"] += int(pick.sum())
        body["val"]["packs"] += int(val.sum())
        body["val"]["zone"] += int(label[val].sum())
        test_x.append(rows_of(coin, ends[pick], k))
        test_y.append(label[pick])
        val_x.append(rows_of(coin, ends[val], k))
        val_y.append(label[val])
        val_coin.append(np.full(int(val.sum()), number, dtype=np.int16))
    x = np.vstack(test_x)
    y = np.concatenate(test_y)
    body["columns"] = int(x.shape[1])
    body["val"]["days"] = cell(body["val"]["packs"] * EVENT_LENGTH / 86400)
    vy = np.concatenate(val_y)
    if body["val"]["zone"] < 2 or int(y.sum()) < 2 or vy.sum() == len(vy):
        log(f"      K {k:>2}: зон у валідації {body['val']['zone']}"
            " — пропуск")
        body["ready"] = False
        return body
    model = fit(x, y, seed)
    score_test = model.predict_proba(x)[:, 1]
    del x
    vx = np.vstack(val_x)
    vcoin = np.concatenate(val_coin)
    score = model.predict_proba(vx)[:, 1]
    del vx
    body["ready"] = True
    body["test"]["inside"] = leg_context.measure(y, score_test)
    body["val"].update(leg_context.measure(vy, score))
    body["curve"] = leg_context.curve_of(vy, score, body["val"]["days"], CURVE)
    body["by_coin"] = by_coin(vy, score, vcoin, coins)
    body["seconds"] = round(time.time() - started, 1)
    best = body["curve"][2]
    log(f"      K {k:>2} ({body['columns']:>3} чисел): пачок "
        f"{body['val']['packs']}, у зоні {body['val']['zone']}, AUC "
        f"{body['val']['auc']}, AP {body['val']['ap']}, при повноті "
        f"{best['recall']} точність {best['precision']} (×{best['lift']} "
        f"до бази) — {body['seconds']} с")
    return body


def by_coin(y: np.ndarray, score: np.ndarray, coin: np.ndarray,
            coins: list) -> list:
    """Видача на val окремо по кожній монеті."""
    from sklearn.metrics import roc_auc_score

    out = []
    for number, one in enumerate(coins):
        mask = coin == number
        if not mask.any():
            continue
        here, values = y[mask], score[mask]
        auc = (cell(roc_auc_score(here, values))
               if 0 < here.sum() < len(here) else None)
        out.append({"pair": one["pair"], "packs": int(mask.sum()),
                    "zone": int(here.sum()), "base": cell(here.mean()),
                    "auc": auc})
    return out


def fit(x: np.ndarray, y: np.ndarray, seed: int = SEED):
    from sklearn.ensemble import HistGradientBoostingClassifier

    model = HistGradientBoostingClassifier(
        max_iter=MAX_ITER, learning_rate=RATE, max_leaf_nodes=LEAVES,
        class_weight="balanced", random_state=seed)
    model.fit(x, y)
    return model


def grid_of(lengths: np.ndarray, top: int | None = None) -> list:
    """Довжини пачки: 1 … медіана довжини зон."""
    if top is None:
        top = int(np.median(lengths)) if len(lengths) else 1
    return list(range(1, max(int(top), 1) + 1))


def best_row(rows: list) -> dict | None:
    """Найкраща довжина пачки за AUC на val."""
    ready = [one for one in rows if one.get("ready")]
    if not ready:
        return None
    return max(ready, key=lambda one: one["val"]["auc"] or 0.0)


def run_class(name: str = CLASS, pairs=None, root: Path | None = None,
              max_k: int | None = None, width: float = WIDTH,
              step: int = NEG_STEP, seed: int = SEED, log=print) -> dict:
    """Увесь замір одного класу: зони, грід довжин пачки і моделі."""
    card = card_of(name)
    coins = collect(root, pairs or pairs_of(name, root), width, name, log)
    if not coins:
        return {"class": name, "class_title": card["name"], "ready": False,
                "pairs": [], "reason": "немає датасету"}
    lengths = zone_lengths(coins)
    if not len(lengths):
        return {"class": name, "class_title": card["name"], "ready": False,
                "pairs": [coin["pair"] for coin in coins],
                "reason": "немає зон"}
    grid = grid_of(lengths, max_k)
    log(f"      зон {len(lengths)}, подій у зоні: медіана "
        f"{np.median(lengths):.0f}, чверть {np.quantile(lengths, 0.25):.0f}, "
        f"три чверті {np.quantile(lengths, 0.75):.0f}, "
        f"найдовша {lengths.max()}")
    log(f"      довжини пачки: {grid[0]} … {grid[-1]}")
    log("[пачки]")
    rows = [one_k(coins, k, step, seed, log) for k in grid]
    picked = best_row(rows)
    return {"class": name, "class_title": card["name"],
            "features": coins[0]["features"],
            "shape": list(np.asarray(coins[0]["x"]).shape[1:]),
            "width": width, "threshold": THRESHOLD, "period": PERIOD,
            "event_seconds": EVENT_LENGTH, "neg_step": step,
            "max_iter": MAX_ITER, "leaves": LEAVES, "rate": RATE,
            "seed": seed, "curve_grid": list(CURVE),
            "grid": grid, "fits": fits_report(lengths, grid),
            "zones": {"total": int(len(lengths)),
                      "median": cell(np.median(lengths)),
                      "low": cell(np.quantile(lengths, 0.25)),
                      "high": cell(np.quantile(lengths, 0.75)),
                      "shortest": int(lengths.min()),
                      "longest": int(lengths.max()),
                      "pairs": [zone_report(coin) for coin in coins]},
            "from_utc": leg_deciles.utc(min(coin["t"][0] for coin in coins)),
            "to_utc": leg_deciles.utc(max(coin["t"][-1] for coin in coins)),
            "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
            "pairs": [coin["pair"] for coin in coins],
            "best": picked["k"] if picked else None,
            "rows": rows, "ready": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--class", dest="name", default=CLASS,
                        help="клас проєкту; типово class210x10m1x7dd")
    parser.add_argument("--max-k", type=int, default=None,
                        help="стеля довжини пачки; типово медіана зон")
    parser.add_argument("--width", type=float, default=WIDTH)
    parser.add_argument("--step", type=int, default=NEG_STEP)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--pair", action="append", default=None)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    body = run_class(args.name, args.pair, args.data, args.max_k,
                     args.width, args.step, args.seed)
    if not body["ready"]:
        raise SystemExit(f"{args.name}: {body.get('reason')}")

    args.out.mkdir(parents=True, exist_ok=True)
    body.update({
        "script": "research/27-pivot-zone-015/scripts/zone_packs.py",
        "command": "python3 research/27-pivot-zone-015/scripts/zone_packs.py"})
    (args.out / "zone_packs.json").write_text(
        json.dumps(body, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/zone_packs.json")


if __name__ == "__main__":
    main()
