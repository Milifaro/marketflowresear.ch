"""Той самий замір зони ±0.15 % на **всіх класах проєкту**.

Дослідження: research/27-pivot-zone-015/
Правила: rules/01-data-and-db.md → класи
         rules/03-models.md → Навчання моделей

Питання те саме, що в [`zone_packs.py`](zone_packs.py): чи є зона біля
півота зігзага 2.3 % зоною розвороту — і чи залежить відповідь від того,
**яким класом** описана подія.

Клас береться зі свого датасету, ема й півоти рахуються з його **власної**
ціни (`price_open`), тому кожен клас міряється на своїй сітці подій і зі
своїми зонами. Решта — мітка, розбиття, грід довжин пачки, модель і
ручки — та сама, що в основному замірі.

Клас, у якого немає побудованого датасету жодної з шести монет,
пропускається і потрапляє у `skipped` зі своєю причиною.

## Що з чим порівнюється

| Число | Що означає |
| ----- | ---------- |
| `монет` | скільки монет має цей клас побудованим |
| `зон` | скільки зон ±0.15 % на його сітці подій |
| `K` | найкраща довжина пачки за AUC на val |
| `AUC`, `AP` | видача на val на цій довжині |
| `до бази` | у скільки разів точність вища за частку зони |

Вхід : data/datasets/<PAIR>/<клас>/{train,val}.npz
Вихід: results/zone_classes.json

Запуск:
    python3 research/27-pivot-zone-015/scripts/zone_classes.py
    python3 research/27-pivot-zone-015/scripts/zone_classes.py \
        --class class210x10x9 --class class210x14x4
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import zone_packs as zone  # noqa: E402
from zone_packs import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"


def run_all(names=None, root: Path | None = None, max_k: int | None = None,
            width: float = zone.WIDTH, step: int = zone.NEG_STEP,
            seed: int = zone.SEED, log=print) -> dict:
    """Замір кожного класу підряд. Клас без датасету йде в `skipped`."""
    wanted = list(names or [card["id"] for card in zone.class_card.CLASSES])
    rows, skipped = [], []
    for name in wanted:
        card = zone.card_of(name)
        pairs = zone.pairs_of(name, root)
        if not pairs:
            log(f"[{card['name']}] немає датасету — пропуск")
            skipped.append({"class": name, "class_title": card["name"],
                            "reason": "немає датасету"})
            continue
        log(f"[{card['name']}] монет {len(pairs)}")
        started = time.time()
        body = zone.run_class(name, pairs, root, max_k, width, step, seed,
                              log)
        if not body["ready"]:
            skipped.append({"class": name, "class_title": card["name"],
                            "reason": body.get("reason", "немає заміру")})
            continue
        body["seconds"] = round(time.time() - started, 1)
        rows.append(body)
        picked = zone.best_row(body["rows"])
        if picked:
            log(f"      краще K {picked['k']}: AUC {picked['val']['auc']}, "
                f"AP {picked['val']['ap']} — {body['seconds']} с")
    return {"classes": rows, "skipped": skipped}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--class", dest="names", action="append",
                        default=None, help="лише ці класи")
    parser.add_argument("--max-k", type=int, default=None)
    parser.add_argument("--width", type=float, default=zone.WIDTH)
    parser.add_argument("--step", type=int, default=zone.NEG_STEP)
    parser.add_argument("--seed", type=int, default=zone.SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    found = run_all(args.names, args.data, args.max_k, args.width,
                    args.step, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "zone_classes.json").write_text(json.dumps({
        "script": "research/27-pivot-zone-015/scripts/zone_classes.py",
        "command": "python3 research/27-pivot-zone-015/scripts/"
                   "zone_classes.py",
        "width": args.width, "threshold": zone.THRESHOLD,
        "period": zone.PERIOD, "event_seconds": zone.EVENT_LENGTH,
        "neg_step": args.step, "max_iter": zone.MAX_ITER,
        "leaves": zone.LEAVES, "rate": zone.RATE, "seed": args.seed,
        "curve_grid": list(zone.CURVE), "main_class": zone.CLASS,
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), **found, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/zone_classes.json")


if __name__ == "__main__":
    main()
