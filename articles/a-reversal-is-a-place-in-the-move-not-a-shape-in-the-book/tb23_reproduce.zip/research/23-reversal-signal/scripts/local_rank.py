"""Етап 1: локальний ранг замість пульної бази.

Дослідження: research/23-reversal-signal/
Правила: rules/01-data-and-db.md → Скейлери

Дослідження 22 порівнювало силу пачки з медіаною **всієї монети**.
Волатильність гуляє годинами, тому «сильна» пачка в тиху добу і в бурю —
різні речі, і пульна база їх змішує.

Тут сила події береться **рангом серед попередніх `look` подій**:

    rank[подія, фіча] = частка попередніх `look` подій, у яких сила менша

Ранг причинний — дивиться тільки назад і не бере саму подію. `look = 0`
означає стару пульну базу: з нею рядок таблиці збігається з дослідженням
22 і служить точкою відліку.

## Ознаки пачки

На кожному `look` пачка з десяти подій дає десять чисел:

| Ознака | Що це |
| ------ | ----- |
| `<фіча>` | медіана рангу цієї фічі по десяти подіях |
| `direct` | середнє рангів прямих фіч: `d_up`, `d_down`, `d_price_avg` |
| `inverse` | середнє рангів чотирьох зворотних відношень |
| `ratio` | `direct` мінус `inverse` |

## Що міряється

| Число | Що означає |
| ----- | ---------- |
| `auc` | поділ пачок розвороту й решти |
| `lift` | у скільки разів більше розворотів у відібраному, ніж у датасеті |
| `precision` | точність при повноті 10 % |
| `alone` | скільки розворотів вийшли за край усієї решти |

Порівнюються ті самі набори, що в дослідженні 22, етап 5: пачки
розвороту проти всіх десяток train із кроком в одну подію.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/local_rank.json

Запуск:
    python3 research/23-reversal-signal/scripts/local_rank.py
    python3 research/23-reversal-signal/scripts/local_rank.py --looks 0 300
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
import pack_unique  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LOOKS = (0, 100, 300, 500, 1000)   # подій у локальному вікні; 0 — пул
CHUNK = 2000                       # рядків за раз у рахунку рангу
RECALL = 0.10                      # повнота, на якій міряється точність
DIGITS = legs.DIGITS


def local_rank(values: np.ndarray, look: int,
               chunk: int = CHUNK) -> np.ndarray:
    """(N, F) ранг кожної події серед попередніх `look` подій.

    Дивиться тільки назад і саму подію не рахує. Перші події ряду мають
    неповне вікно, тому ранг у них рахується по тому, що є, а в найпершої
    події історії немає зовсім — там `NaN`. Пачка з таким рангом далі
    відкидається сама, як пачка з `NaN` у класі.
    """
    if look <= 0:
        return np.asarray(values, dtype=float)
    count, width = values.shape
    padded = np.vstack([np.full((look, width), np.nan), values])
    view = np.lib.stride_tricks.sliding_window_view(padded, look, axis=0)
    out = np.empty((count, width), dtype=float)
    for start in range(0, count, chunk):
        stop = min(start + chunk, count)
        block = view[start:stop]
        here = values[start:stop, :, None]
        with np.errstate(invalid="ignore"):
            less = np.nansum(block < here, axis=2)
        seen = np.isfinite(block).sum(axis=2)
        out[start:stop] = np.where(seen > 0, less / np.maximum(seen, 1),
                                   np.nan)
    return out


def pack_names(features: list) -> list:
    return list(features) + ["direct", "inverse", "ratio"]


def pack_marks(rank: np.ndarray, starts: np.ndarray, features: list,
               size: int = legs.SIZE) -> np.ndarray:
    """(P, F + 3) медіани рангів пачки і три спільні числа."""
    if not len(starts):
        return np.empty((0, len(features) + 3), dtype=np.float32)
    window = pack_unique.windows_of(rank, starts, size)
    median = np.median(window, axis=2)
    direct = [index for index, name in enumerate(features)
              if name in legs.DIRECT]
    other = [index for index in range(len(features)) if index not in direct]
    straight = median[:, direct].mean(axis=1)
    inverse = median[:, other].mean(axis=1)
    return np.column_stack([median, straight, inverse,
                            straight - inverse]).astype(np.float32)


def coin_packs(coin: dict, look: int, part: str = "train") -> dict:
    """Пачки однієї монети на заданому вікні нормування."""
    rank = local_rank(coin["mag"], look)
    hit = legs.reversal_starts(coin, part=part)
    rest = legs.other_starts(coin, part=part)
    features = coin["features"]
    return {"x": np.vstack([pack_marks(rank, hit, features),
                            pack_marks(rank, rest, features)]),
            "y": np.concatenate([np.ones(len(hit), dtype=np.int8),
                                 np.zeros(len(rest), dtype=np.int8)])}


def gather(coins: list, look: int, part: str = "train") -> dict:
    """Пачки всіх монет одним набором."""
    body = [coin_packs(coin, look, part) for coin in coins]
    return {"x": np.vstack([one["x"] for one in body]),
            "y": np.concatenate([one["y"] for one in body]),
            "names": pack_names(coins[0]["features"])}


def at_recall(hit: np.ndarray, rest: np.ndarray, sign: int,
              recall: float = RECALL) -> dict:
    """Точність і підйом над базою при заданій повноті."""
    edge = float(np.quantile(sign * hit, 1.0 - recall))
    taken = int((sign * hit >= edge).sum())
    false = int((sign * rest >= edge).sum())
    base = len(hit) / max(len(hit) + len(rest), 1)
    precision = taken / max(taken + false, 1)
    return {"recall": legs.cell(recall), "taken": taken, "false": false,
            "precision": legs.cell(precision),
            "lift": legs.cell(precision / max(base, legs.EPS))}


def score(packs: dict, look: int) -> dict:
    """Таблиця ознак одного вікна і найкраща з них."""
    hit = packs["y"] == 1
    table = []
    for index, name in enumerate(packs["names"]):
        column = packs["x"][:, index]
        found = pack_unique.score_one(column[hit], column[~hit], name)
        if "auc" not in found:
            continue
        sign = 1 if found["direction"] == "вище" else -1
        found.update(at_recall(column[hit], column[~hit], sign))
        table.append(found)
    table.sort(key=lambda one: -one["auc"])
    return {"look": look, "packs": int(len(packs["y"])),
            "reversal": int(hit.sum()), "table": table,
            "best": table[0] if table else {}}


def run(coins: list, looks=LOOKS, log=print) -> list:
    out = []
    for look in looks:
        started = time.time()
        body = score(gather(coins, look), look)
        body["seconds"] = round(time.time() - started, 1)
        out.append(body)
        best = body["best"]
        log(f"      вікно {look or 'пул':>4}: краща `{best['mark']}` "
            f"AUC {best['auc']}, точність {best['precision']}, "
            f"×{best['lift']} до бази, сама {best['alone']}"
            f" — {body['seconds']} с")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--looks", type=int, nargs="+", default=list(LOOKS))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[вікна]")
    rows = run(coins, args.looks)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "local_rank.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/local_rank.py",
        "command": "python3 research/23-reversal-signal/scripts/local_rank.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "marks": pack_names(
            coins[0]["features"]),
        "lead": legs.LEAD, "tail": legs.TAIL, "size": legs.SIZE,
        "part": "train", "cut_utc": f"{CUT} 00:00:00",
        "end_utc": f"{END} 00:00:00", "pairs": list(PAIRS),
        "threshold": legs.THRESHOLD, "period": legs.PERIOD,
        "event_seconds": legs.EVENT_LENGTH, "recall": RECALL,
        "looks": list(args.looks), "rows": rows, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/local_rank.json")


if __name__ == "__main__":
    main()
