"""Спільний збір для дослідження 23: клас, ноги, ціна й контекст події.

Дослідження: research/23-reversal-signal/
Правила: rules/01-data-and-db.md → клас210х10-1х7д/д
         rules/02-markup.md → зігзаг

Усі пʼять етапів беруть один і той самий вхід, тому він зібраний тут:

| Що | Звідки |
| -- | ------ |
| значення класу `(N, 9, 7)` | `data/datasets/<PAIR>/class210x10m1x7dd/` |
| ема10 і ціна події | `leg_deciles.build_pair` |
| півоти зігзага 2.3 % | там само |
| ноги: межі, напрямок, довжина | там само |

## Сила події

`mag[подія, фіча]` — модуль по девʼяти плашках, поділений на медіану цієї
ж фічі по подіях **звичайних десяток** монети (та сама база, що в
`pivot_zone.py`). `sign` — знакове середнє на тій самій базі.

## Контекст ноги

Контекст рахується **причинно**: тільки з того, що видно на момент
події. Ковзний екстремум ема за `LOOK` подій назад:

| Число | Що це |
| ----- | ----- |
| `run` | хід від ковзного мінімуму вгору, у частках порогу 2.3 % |
| `draw` | хід від ковзного максимуму вниз, у тих самих частках |
| `since_top` | подій від ковзного максимуму |
| `since_low` | подій від ковзного мінімуму |
| `since_pivot` | подій від останнього півота — **з підказкою** |

`since_pivot` стоїть окремо: зігзаг ставить півот заднім числом, тому
онлайн цього числа немає. Воно рахується, щоб показати різницю між
причинним контекстом і контекстом з підказкою.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[3]
X7DC_SCRIPTS = PROJECT_ROOT / "research" / "21-class210x10x7dc" / "scripts"
X7DD_SCRIPTS = PROJECT_ROOT / "research" / "22-leg-edge-spread" / "scripts"
sys.path.insert(0, str(PROJECT_ROOT / "rules" / "scripts"))
sys.path.insert(0, str(X7DC_SCRIPTS))
sys.path.insert(0, str(X7DD_SCRIPTS))

import class210x10m1x7dd  # noqa: E402
import leg_deciles  # noqa: E402
import pivot_compare as pivot  # noqa: E402
import pivot_zone  # noqa: E402
from build_class210x10x7dc import CUT, END, PAIRS, stamp  # noqa: E402
from class210x10x9 import EVENT_LENGTH  # noqa: E402

CLASS = "class210x10m1x7dd"
MODULE = class210x10m1x7dd
FEATURES = list(MODULE.FEATURES)
DIRECT = pivot_zone.DIRECT
LEAD, TAIL = pivot_zone.LEAD, pivot_zone.TAIL
SIZE = LEAD + TAIL
THRESHOLD = leg_deciles.THRESHOLD
PERIOD = leg_deciles.PERIOD
LOOK = 400                 # подій у ковзному екстремумі контексту
SEED = 0
EPS = 1e-12
NEAR = 0.001               # ціновий окіл півота: сигнал у ньому не хибний
DIGITS = 4
CONTEXT = ("run", "draw", "since_top", "since_low")
HINTED = ("since_pivot",)


def cell(value):
    value = float(value)
    if not np.isfinite(value):
        return None
    return round(value, DIGITS) if abs(value) < 1e6 else round(value, 1)


def running(values: np.ndarray, look: int, how: str) -> np.ndarray:
    """Ковзний екстремум за `look` подій назад разом із поточною.

    На початку ряду повного вікна ще немає, тому екстремум береться по
    тому, що є. Якщо ряд коротший за `look`, вікно звужується до його
    довжини — інакше рахувати нічого.
    """
    values = np.asarray(values, dtype=float)
    out = np.empty(len(values), dtype=float)
    pick = np.maximum if how == "max" else np.minimum
    width = min(max(look, 1), len(values))
    for index in range(width - 1):
        out[index] = pick.reduce(values[:index + 1])
    view = np.lib.stride_tricks.sliding_window_view(values, width)
    out[width - 1:] = pick.reduce(view, axis=1)
    return out


def context_of(ema: np.ndarray, pivots: list, look: int = LOOK,
               threshold: float = THRESHOLD) -> dict:
    """Причинний контекст ноги плюс одне число з підказкою."""
    count = len(ema)
    top = running(ema, look, "max")
    low = running(ema, look, "min")
    since_top = np.zeros(count, dtype=float)
    since_low = np.zeros(count, dtype=float)
    last_top = last_low = 0
    for index in range(count):
        if ema[index] >= top[index]:
            last_top = index
        if ema[index] <= low[index]:
            last_low = index
        since_top[index] = index - last_top
        since_low[index] = index - last_low
    since_pivot = np.zeros(count, dtype=float)
    place = 0
    for point in pivots:
        if point.index >= count:
            break
        since_pivot[place:point.index + 1] = \
            np.arange(place, point.index + 1) - place
        place = point.index + 1
    since_pivot[place:] = np.arange(place, count) - place
    return {"run": (ema / np.where(low > 0, low, 1.0) - 1.0) / threshold,
            "draw": (1.0 - ema / np.where(top > 0, top, 1.0)) / threshold,
            "since_top": since_top, "since_low": since_low,
            "since_pivot": since_pivot}


def pivot_gap(ema: np.ndarray, pivots: list,
              places: np.ndarray) -> np.ndarray:
    """Відносна відстань за ціною до найближчого **в часі** півота.

    Модель відповідає «півот був N подій тому» і тим самим показує на
    подію. Якщо ціна тієї події збігається з ціною справжнього півота з
    точністю до `NEAR`, відповідь промазала в подіях, але не в рівні:
    входити довелося б там само. Такий сигнал рахується окремо від
    хибного.

    Півот шукається найближчий за часом, а не за ціною: ціна вертається
    на той самий рівень і за сотні подій, і збіг рівнів сам по собі
    нічого не значить.
    """
    places = np.asarray(places, dtype=np.int64)
    spots = np.array([point.index for point in pivots], dtype=np.int64)
    if not len(spots) or not len(places):
        return np.full(len(places), np.inf)
    order = np.searchsorted(spots, places)
    left = np.clip(order - 1, 0, len(spots) - 1)
    right = np.clip(order, 0, len(spots) - 1)
    near = np.where(np.abs(spots[left] - places)
                    <= np.abs(spots[right] - places), left, right)
    mark = spots[near]
    return np.abs(ema[places] - ema[mark]) / np.maximum(np.abs(ema[mark]), EPS)


# Мітки плашки монети: чим є подія і що з неї зробив поріг.
#   -1 — приклад є, але в рахунок не йде: пачка лежить через межу навчання
#    0 — питання поставлене, півота на події `e − N` немає
#    1 — півот там є
#    2 — півота там немає, але ціна тієї події в його рівні (`NEAR`)
NO_COUNT, PLAIN, PIVOT, LEVEL = -1, 0, 1, 2


def mark_counts(kind, score, edge: float, blind: int = 0) -> dict:
    """Скільки чого дає поріг `edge` на сирому сигналі.

    Та сама арифметика, що в плашці дашборду: поріг там рухають рукою, і
    мітки перераховуються з `kind` і `score` на льоту. Тут вона потрібна,
    щоб числа за замовчуванням у файлі збігалися з намальованими.
    """
    out = {name: 0 for name in ("hit", "near", "false", "miss")}
    for one, value in zip(kind, score):
        if one is None or one == NO_COUNT:
            continue
        fired = value is not None and value >= edge
        if one == PIVOT:
            out["hit" if fired else "miss"] += 1
        elif fired:
            out["near" if one == LEVEL else "false"] += 1
    out["blind"] = blind
    return out


def step_lines(raw: dict, blind, place: dict, events: int,
               edge: float, near: float) -> dict:
    """Сигнал, вид події й проґавлені півоти — рядами вздовж ряду монети.

    Мітки в плашці рахуються з `score` і `kind` порогом, який рухають
    рукою, тому рядів міток тут немає: є те, з чого вони виходять.
    `counts` — ті самі числа на порозі за замовчуванням.
    """
    score = [None] * events
    kind = [NO_COUNT] * events
    for spot, value, mark in zip(raw.get("ends", ()), raw.get("value", ()),
                                 raw.get("kind", ())):
        if spot in place:
            score[place[spot]] = value
            kind[place[spot]] = mark
    line = np.zeros(events, dtype=int)
    for spot in blind:
        if spot in place:
            line[place[spot]] = 1
    return {"score": score, "kind": kind, "blind": line.tolist(),
            "edge": edge, "near": near,
            "counts": mark_counts(kind, score, edge, int(line.sum()))}


def usual_index(x: np.ndarray, t: np.ndarray, pivots: list,
                lead: int = LEAD, tail: int = TAIL) -> np.ndarray:
    """Події звичайних десяток: вони дають базу нормування."""
    size = lead + tail
    zone = pivot_zone.zone_index(len(t), pivots, lead, tail)
    step = np.arange(0, len(t) - size + 1, size)
    plain = np.array([one for one in step if not zone[one:one + size].any()],
                     dtype=np.int64)
    plain = pivot_zone.clean_starts(x, t, plain, size)
    if not len(plain):
        return np.empty(0, dtype=np.int64)
    return np.concatenate([np.arange(one, one + size) for one in plain])


def one_coin(pair: str, root: Path | None = None, look: int = LOOK) -> dict:
    """Ряд однієї монети: клас, сила події, ноги й контекст."""
    data = pivot.series(pair, root, MODULE, CLASS)
    marks = leg_deciles.build_pair(pair, root, PERIOD, THRESHOLD)
    if len(marks["group"]) != len(data["t"]):
        raise SystemExit(f"{pair}: ряди різної довжини")
    x, t = data["x"], data["t"]
    mag, base = pivot_zone.event_scale(x, usual_index(x, t, marks["pivots"]))
    return {"pair": pair, "x": x, "t": t, "features": list(data["features"]),
            "mag": mag, "sign": x.mean(axis=1) / base, "base": base,
            "price": marks["data"]["price"], "ema": marks["ema"],
            "pivots": marks["pivots"], "legs": marks["legs"],
            "group": marks["group"], "part": parts_of(t),
            "context": context_of(marks["ema"], marks["pivots"], look)}


def parts_of(t: np.ndarray) -> np.ndarray:
    """train / val / поза межами — за датою події."""
    edge, right = stamp(CUT), stamp(END)
    return np.where(t < edge, "train", np.where(t < right, "val", "поза"))


def collect(root: Path | None = None, pairs=PAIRS, look: int = LOOK,
            log=print) -> list:
    """Ряди всіх монет одним списком."""
    coins = []
    for pair in pairs:
        coin = one_coin(pair, root, look)
        coins.append(coin)
        log(f"      {pair}: подій {len(coin['t'])}, ніг {len(coin['legs'])}, "
            f"півотів {len(coin['pivots'])}")
    return coins


def reversal_starts(coin: dict, lead: int = LEAD, tail: int = TAIL,
                    part: str = "train") -> np.ndarray:
    """Пачки розвороту: `lead` подій до півота з ним і `tail` після."""
    size = lead + tail
    starts = pivot_zone.zone_windows(len(coin["t"]), coin["pivots"], lead, tail)
    starts = pivot_zone.clean_starts(coin["x"], coin["t"], starts, size)
    return starts[whole_part(coin, starts, size, part)] if len(starts) \
        else starts


def other_starts(coin: dict, lead: int = LEAD, tail: int = TAIL,
                 part: str = "train", step: int = 1) -> np.ndarray:
    """Усі десятки, що не торкаються зони розвороту, з кроком `step`."""
    size = lead + tail
    count = len(coin["t"])
    zone = pivot_zone.zone_index(count, coin["pivots"], lead, tail)
    ready = pivot_zone.linked(coin["t"], size)[size - 1:]
    finite = np.lib.stride_tricks.sliding_window_view(
        np.isfinite(coin["x"]).all(axis=(1, 2)), size, axis=0).all(axis=1)
    touched = np.lib.stride_tricks.sliding_window_view(
        zone, size, axis=0).any(axis=1)
    starts = np.flatnonzero(ready & finite & ~touched)
    starts = starts[starts % step == 0] if step > 1 else starts
    return starts[whole_part(coin, starts, size, part)]


def whole_part(coin: dict, starts: np.ndarray, size: int,
               part: str) -> np.ndarray:
    """Маска: пачка цілком лежить по один бік межі train | val."""
    if part == "all" or not len(starts):
        return np.ones(len(starts), dtype=bool)
    inside = np.lib.stride_tricks.sliding_window_view(
        coin["part"] == part, size, axis=0).all(axis=1)
    return inside[starts]
