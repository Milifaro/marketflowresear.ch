"""Етап 2: край ноги проти середини **тієї самої** ноги.

Дослідження: research/23-reversal-signal/
Правила: rules/02-markup.md → зігзаг

Пульне порівняння змішує ноги різної волатильності, монети й час доби.
Парне порівняння цього не робить: у кожній нозі край міряється проти
середини **цієї ж** ноги, тому все, що спільне для ноги, скорочується.

## Пара

| Частина ноги | Які події |
| ------------ | --------- |
| `початок` | перші `edge` подій ноги |
| `кінець` | останні `edge` подій ноги |
| `середина` | центральна половина ноги — від 25 % до 75 % її довжини |
| `контроль` | `edge` подій, узятих випадково всередині центральної половини |

Нога бере участь, якщо в ній є і край, і середина: довжина не менша за
`MIN_EVENTS`, а середина не коротша за `edge`.

## Число ноги

    відношення = медіана сили краю / медіана сили середини

Сила — та сама відносна `mag` з `legs.py`. Відношення більше за одиницю
означає «на краю фіча активніша».

## Перевірка

Знак рахується по кожній нозі окремо, далі — **біноміальний тест**:
скільки ніг із загальної кількості дали відношення більше за одиницю.
`0.5` — це монетка, тобто різниці немає. Контроль показує, що сам спосіб
рахунку монетку і дає.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/leg_pair.json

Запуск:
    python3 research/23-reversal-signal/scripts/leg_pair.py
    python3 research/23-reversal-signal/scripts/leg_pair.py --edges 5 10
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
EDGES = (3, 5, 10, 20)     # подій у краю
MIDDLE = (0.25, 0.75)      # межі середини ноги
MIN_EVENTS = 20            # найкоротша нога, яку беремо
PARTS = ("початок", "кінець", "край", "контроль")
SEED = legs.SEED


def middle_range(leg: dict, bounds=MIDDLE) -> tuple:
    """Індекси центральної половини ноги."""
    length = leg["to"] - leg["from"] + 1
    low = leg["from"] + int(round(length * bounds[0]))
    high = leg["from"] + int(round(length * bounds[1]))
    return low, max(high, low + 1)


def leg_rows(coin: dict, edge: int, part: str = "train",
             least: int = MIN_EVENTS, seed: int = SEED) -> dict:
    """Відношення край / середина по кожній нозі монети."""
    rng = np.random.default_rng(seed)
    mag, train = coin["mag"], coin["part"] == part
    rows = {name: [] for name in PARTS}
    used = 0
    for leg in coin["legs"]:
        length = leg["to"] - leg["from"] + 1
        low, high = middle_range(leg)
        if length < least or high - low < edge or length < 2 * edge + edge:
            continue
        if part != "all" and not train[leg["from"]:leg["to"] + 1].all():
            continue
        centre = mag[low:high]
        if not np.isfinite(centre).any():
            continue
        base = np.nanmedian(centre, axis=0)
        if not np.isfinite(base).all() or (base <= 0).any():
            continue
        picked = rng.choice(high - low, edge, replace=False) + low
        places = {"початок": np.arange(leg["from"], leg["from"] + edge),
                  "кінець": np.arange(leg["to"] - edge + 1, leg["to"] + 1),
                  "край": np.concatenate([
                      np.arange(leg["from"], leg["from"] + edge),
                      np.arange(leg["to"] - edge + 1, leg["to"] + 1)]),
                  "контроль": picked}
        for name, index in places.items():
            with np.errstate(invalid="ignore"):
                value = np.nanmedian(mag[index], axis=0) / base
            rows[name].append(value)
        used += 1
    return {"rows": {name: np.array(value) for name, value in rows.items()},
            "legs": used}


def sign_test(values: np.ndarray) -> dict:
    """Скільки значень більші за одиницю і наскільки це не монетка."""
    from scipy.stats import binomtest

    values = values[np.isfinite(values)]
    if not len(values):
        return {}
    above = int((values > 1.0).sum())
    result = binomtest(above, len(values), 0.5)
    return {"legs": int(len(values)), "above": above,
            "share": legs.cell(above / len(values)),
            "p": legs.cell(float(result.pvalue)),
            "median": legs.cell(float(np.median(values)))}


def one_edge(coins: list, edge: int, features: list, log=print) -> dict:
    """Один розмір краю: зведення по фічах і по монетах."""
    gathered = [leg_rows(coin, edge) for coin in coins]
    body = {"edge": edge, "legs": sum(one["legs"] for one in gathered),
            "by_part": {}, "by_coin": []}
    for name in PARTS:
        stack = np.vstack([one["rows"][name] for one in gathered
                           if len(one["rows"][name])])
        body["by_part"][name] = [
            dict(sign_test(stack[:, index]), feature=feature)
            for index, feature in enumerate(features)]
    for coin, one in zip(coins, gathered):
        stack = one["rows"]["край"]
        body["by_coin"].append({
            "pair": coin["pair"], "legs": one["legs"],
            "features": [dict(sign_test(stack[:, index]), feature=feature)
                         for index, feature in enumerate(features)]
            if len(stack) else []})
    best = max(body["by_part"]["край"],
               key=lambda one: abs(one.get("share", 0.5) - 0.5))
    log(f"      край {edge:>2}: ніг {body['legs']}, найсильніша "
        f"`{best['feature']}` {best['share']} ніг, p {best['p']}")
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--edges", type=int, nargs="+", default=list(EDGES))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    features = coins[0]["features"]
    print("[пари]")
    rows = [one_edge(coins, edge, features) for edge in args.edges]

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_pair.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/leg_pair.py",
        "command": "python3 research/23-reversal-signal/scripts/leg_pair.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": features, "parts": list(PARTS), "middle": list(MIDDLE),
        "min_events": MIN_EVENTS, "edges": list(args.edges), "part": "train",
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "seed": SEED, "rows": rows, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/leg_pair.json")


if __name__ == "__main__":
    main()
