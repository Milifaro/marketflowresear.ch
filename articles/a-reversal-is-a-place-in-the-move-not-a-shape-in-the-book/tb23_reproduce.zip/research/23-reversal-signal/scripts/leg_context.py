"""Етап 5: контекст ноги поруч із числами класу.

Дослідження: research/23-reversal-signal/
Правила: rules/03-models.md → Навчання моделей

Клас — це відношення похідних обʼємів і рівнів усередині 210 секунд.
Півот же визначений **ціною** і **розмахом від попереднього
екстремуму**, а цих чисел у пачці немає взагалі. Тут вони додаються.

## Набори входів

| Набір | Що подається |
| ----- | ------------ |
| `клас` | 62 ознаки пачки з дослідження 22, етап 5 |
| `контекст` | тільки причинний контекст: `move`, `run`, `draw`, `since_top`, `since_low` |
| `клас+контекст` | обидва разом |
| `клас+підказка` | плюс `since_pivot` — число, якого онлайн немає |

`клас+підказка` показаний як межа зверху. Зігзаг ставить півот заднім
числом, тому в пачці з півотом `since_pivot` дорівнює `tail`: це та сама
відповідь, подана на вхід.

## Задача

Пачка з десяти подій підряд, крок в одну подію, мітка `1`, якщо півот
стоїть на `LEAD`-й події пачки. Беруться **всі** пачки train, а не
тільки ті, що не торкаються зони: детектор має працювати скрізь.

Модель — `HistGradientBoosting`, перевірка **відкладеною монетою**:
навчання на пʼятьох монетах, оцінка на шостій, і так шість разів.

| Число | Що означає |
| ----- | ---------- |
| `auc` | поділ на відкладених монетах |
| `ap` | площа під precision-recall |
| `lift` | у скільки разів більше розворотів у відібраному при повноті 10 % |

## Крива повноти

Одна точка нічого не каже про робочу точку, тому кожен набір міряється на
`CURVE`: поріг ставиться так, щоб зловити задану частку розворотів, і
рахується, скільки при цьому чужих пачок пройшло. Поруч — скільки це
сигналів на монету за добу: пачка починається на кожній події, подія —
`EVENT_LENGTH` секунд.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/leg_context.json

Запуск:
    python3 research/23-reversal-signal/scripts/leg_context.py
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
import leg_progress  # noqa: E402
import local_rank  # noqa: E402
import pack_unique  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
CONTEXT = ("move",) + legs.CONTEXT
HINTED = legs.HINTED
SETS = (("клас", True, False, False),
        ("контекст", False, True, False),
        ("клас+контекст", True, True, False),
        ("клас+підказка", True, True, True))
CURVE = (0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9)   # повноти в кривій
MAX_ITER = 200
LEAVES = 31
RATE = 0.1
SEED = legs.SEED
RECALL = local_rank.RECALL


def coin_rows(coin: dict, part: str = "train") -> dict:
    """Пачки монети: 62 ознаки класу, контекст і мітка."""
    size = legs.SIZE
    ready = pack_unique.pivot_zone.linked(coin["t"], size)[size - 1:]
    finite = np.lib.stride_tricks.sliding_window_view(
        np.isfinite(coin["x"]).all(axis=(1, 2)), size, axis=0).all(axis=1)
    starts = np.flatnonzero(ready & finite)
    starts = starts[legs.whole_part(coin, starts, size, part)]
    base = coin["base"]
    first = np.abs(coin["x"][:, 0]) / base
    last = np.abs(coin["x"][:, -1]) / base
    marks = pack_unique.pack_marks(
        pack_unique.windows_of(coin["mag"], starts, size),
        pack_unique.windows_of(coin["sign"], starts, size),
        pack_unique.windows_of(first, starts, size),
        pack_unique.windows_of(last, starts, size), list(coin["features"]))
    tail = starts + size - 1
    context = dict(coin["context"])
    context["move"] = np.maximum(context["run"], context["draw"])
    side = np.column_stack([context[name][tail]
                            for name in CONTEXT + HINTED])
    return {"class": marks.astype(np.float32),
            "context": side.astype(np.float32),
            "y": leg_progress.label_of(coin, starts)}


def gather(coins: list, part: str = "train", log=print) -> dict:
    body = []
    for coin in coins:
        one = coin_rows(coin, part)
        body.append(one)
        log(f"      {coin['pair']}: пачок {len(one['y'])}, розворотів "
            f"{int(one['y'].sum())}")
    return {"class": np.vstack([one["class"] for one in body]),
            "context": np.vstack([one["context"] for one in body]),
            "y": np.concatenate([one["y"] for one in body]),
            "coin": np.concatenate([np.full(len(one["y"]), index, np.int16)
                                    for index, one in enumerate(body)]),
            "days": sum(len(one["y"]) for one in body)
            * legs.EVENT_LENGTH / 86400,
            "class_names": pack_unique.names_of(list(coins[0]["features"])),
            "context_names": list(CONTEXT + HINTED)}


def inputs(packs: dict, wide: bool, side: bool, hint: bool) -> np.ndarray:
    """Матриця входів одного набору."""
    parts = []
    if wide:
        parts.append(packs["class"])
    if side:
        columns = len(CONTEXT) + (len(HINTED) if hint else 0)
        parts.append(packs["context"][:, :columns])
    x = np.hstack(parts)
    return np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)


def out_of_coin(x: np.ndarray, y: np.ndarray, coin: np.ndarray,
                seed: int = SEED) -> np.ndarray:
    """Оцінка кожної пачки моделлю, що її монети не бачила."""
    from sklearn.ensemble import HistGradientBoostingClassifier

    score = np.full(len(y), np.nan)
    for number in np.unique(coin):
        out = coin == number
        model = HistGradientBoostingClassifier(
            max_iter=MAX_ITER, learning_rate=RATE, max_leaf_nodes=LEAVES,
            class_weight="balanced", random_state=seed)
        model.fit(x[~out], y[~out])
        score[out] = model.predict_proba(x[out])[:, 1]
    return score


def measure(y: np.ndarray, score: np.ndarray) -> dict:
    from sklearn.metrics import average_precision_score, roc_auc_score

    hit = y == 1
    body = {"auc": legs.cell(roc_auc_score(y, score)),
            "ap": legs.cell(average_precision_score(y, score)),
            "base": legs.cell(y.mean()), "packs": int(len(y)),
            "reversal": int(hit.sum())}
    body.update(local_rank.at_recall(score[hit], score[~hit], 1))
    return body


def curve_of(y: np.ndarray, score: np.ndarray, days: float,
             grid=CURVE) -> list:
    """Точність на кожній повноті і скільки це сигналів за добу."""
    hit, rest = score[y == 1], score[y == 0]
    base = float(y.mean())
    out = []
    for recall in grid:
        edge = float(np.quantile(hit, 1.0 - recall))
        taken = int((hit >= edge).sum())
        false = int((rest >= edge).sum())
        precision = taken / max(taken + false, 1)
        out.append({"recall": legs.cell(recall), "taken": taken,
                    "false": false, "precision": legs.cell(precision),
                    "lift": legs.cell(precision / max(base, legs.EPS)),
                    "per_day": legs.cell((taken + false) / max(days, legs.EPS))})
    return out


def coin_days(packs: dict) -> list:
    """Скільки діб ряду за кожною монетою: пачка на кожній події."""
    out = []
    for number, pair in enumerate(PAIRS):
        mask = packs["coin"] == number
        if not mask.any():
            continue
        count = int(mask.sum())
        out.append({"pair": pair, "packs": count,
                    "reversal": int(packs["y"][mask].sum()),
                    "days": legs.cell(count * legs.EVENT_LENGTH / 86400)})
    return out


def run(packs: dict, sets=SETS, seed: int = SEED, log=print) -> list:
    out = []
    for name, wide, side, hint in sets:
        started = time.time()
        x = inputs(packs, wide, side, hint)
        score = out_of_coin(x, packs["y"], packs["coin"], seed)
        body = {"set": name, "columns": int(x.shape[1]), "hinted": hint}
        body.update(measure(packs["y"], score))
        body["curve"] = curve_of(packs["y"], score, packs["days"])
        body["seconds"] = round(time.time() - started, 1)
        out.append(body)
        line = "  ".join(f"{one['recall']}->{one['precision']}"
                         for one in body["curve"])
        log(f"      {name:<14} входів {body['columns']:>3}: AUC {body['auc']},"
            f" AP {body['ap']}, ×{body['lift']} до бази — {body['seconds']} с")
        log(f"          крива {line}")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[пачки]")
    packs = gather(coins)
    by_coin = coin_days(packs)
    print(f"      монетодіб {packs['days']:.0f}")
    print("[набори]")
    rows = run(packs, seed=args.seed)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_context.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/leg_context.py",
        "command": "python3 research/23-reversal-signal/scripts/"
                   "leg_context.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"],
        "class_names": packs["class_names"],
        "context_names": packs["context_names"], "hinted": list(HINTED),
        "lead": legs.LEAD, "tail": legs.TAIL, "size": legs.SIZE,
        "look": legs.LOOK, "recall": RECALL, "part": "train",
        "max_iter": MAX_ITER, "leaves": LEAVES, "rate": RATE,
        "seed": args.seed, "curve_grid": list(CURVE),
        "by_coin": by_coin, "days": legs.cell(packs["days"]),
        "packs": int(len(packs["y"])),
        "reversal": int(packs["y"].sum()), "cut_utc": f"{CUT} 00:00:00",
        "end_utc": f"{END} 00:00:00", "pairs": list(PAIRS),
        "threshold": legs.THRESHOLD, "period": legs.PERIOD,
        "event_seconds": legs.EVENT_LENGTH, "rows": rows, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/leg_context.json")


if __name__ == "__main__":
    main()
