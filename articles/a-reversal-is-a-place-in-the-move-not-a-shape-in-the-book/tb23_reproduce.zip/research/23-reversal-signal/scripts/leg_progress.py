"""Етап 4: база розвороту як функція від прогресу ноги.

Дослідження: research/23-reversal-signal/
Правила: rules/02-markup.md → зігзаг

Питання «чи ця десятка — розворот», задане без контексту, має базу
0.2 %: розворотів у датасеті мало. Але ми знаємо, **скільки рух уже
пройшов**. Зігзаг ставить півот після руху на 2.3 %, тому чим далі
зайшов хід від протилежного екстремуму, тим ближче розворот.

Тут база рахується не по всьому датасету, а **всередині кожної
клітинки контексту**, і поруч — той самий поділ ознакою класу.

## Контекст пачки

Береться на **останній події** пачки, причинно (`legs.py` → Контекст
ноги):

| Число | Клітинки |
| ----- | -------- |
| `move` | `max(run, draw)` — хід від ковзного екстремуму в частках 2.3 % |
| `run` | хід угору від ковзного мінімуму |
| `draw` | хід униз від ковзного максимуму |
| `since_top` | подій від ковзного максимуму |
| `since_low` | подій від ковзного мінімуму |
| `since_pivot` | подій від останнього півота — **з підказкою** |

`since_pivot` показаний окремо і в роботу не йде: зігзаг ставить півот
заднім числом, тому в пачці, що містить півот, це число дорівнює `tail`
— тобто відповіді. Він стоїть у таблиці як межа зверху: стільки дає
контекст, у якому відповідь уже є.

## Що в клітинці

| Число | Що означає |
| ----- | ---------- |
| `packs` | скільки пачок потрапило в клітинку |
| `base` | частка розворотів у клітинці |
| `lift` | у скільки разів ця частка більша за загальну |
| `auc` | поділ найкращою ознакою класу **всередині** клітинки |
| `precision` | точність цієї ознаки при повноті 10 % у клітинці |

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/leg_progress.json

Запуск:
    python3 research/23-reversal-signal/scripts/leg_progress.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
import local_rank  # noqa: E402
import pack_unique  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
MOVE_EDGES = (0.0, 0.25, 0.5, 0.75, 1.0, np.inf)
STEP_EDGES = (0.0, 3.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0,
              np.inf)
BUCKETS = (("move", MOVE_EDGES), ("run", MOVE_EDGES), ("draw", MOVE_EDGES),
           ("since_top", STEP_EDGES), ("since_low", STEP_EDGES),
           ("since_pivot", STEP_EDGES))
MIN_PACKS = 200            # менші клітинки не міряються
MARK = "ratio"             # ознака класу, якою міряється поділ у клітинці
RECALL = local_rank.RECALL


def label_of(coin: dict, starts: np.ndarray, lead: int = legs.LEAD) -> np.ndarray:
    """1, якщо півот стоїть у пачці на своєму місці — `lead`-та подія."""
    place = np.zeros(len(coin["t"]), dtype=bool)
    for point in coin["pivots"]:
        if 0 <= point.index < len(place):
            place[point.index] = True
    return place[starts + lead - 1].astype(np.int8)


def coin_rows(coin: dict, part: str = "train") -> dict:
    """Усі пачки монети: ознака класу, контекст і мітка."""
    size = legs.SIZE
    count = len(coin["t"])
    ready = pack_unique.pivot_zone.linked(coin["t"], size)[size - 1:]
    finite = np.lib.stride_tricks.sliding_window_view(
        np.isfinite(coin["x"]).all(axis=(1, 2)), size, axis=0).all(axis=1)
    starts = np.flatnonzero(ready & finite)
    starts = starts[legs.whole_part(coin, starts, size, part)]
    marks = local_rank.pack_marks(coin["mag"], starts, coin["features"], size)
    names = local_rank.pack_names(coin["features"])
    last = starts + size - 1
    context = {name: values[last]
               for name, values in coin["context"].items()}
    context["move"] = np.maximum(context["run"], context["draw"])
    return {"score": marks[:, names.index(MARK)], "context": context,
            "y": label_of(coin, starts), "starts": starts}


def gather(coins: list, part: str = "train") -> dict:
    body = [coin_rows(coin, part) for coin in coins]
    names = list(body[0]["context"])
    return {"score": np.concatenate([one["score"] for one in body]),
            "y": np.concatenate([one["y"] for one in body]),
            "context": {name: np.concatenate([one["context"][name]
                                              for one in body])
                        for name in names}}


def cells(packs: dict, name: str, edges, least: int = MIN_PACKS) -> list:
    """Клітинки одного контексту: база, підйом і поділ усередині."""
    values = packs["context"][name]
    base = float(packs["y"].mean())
    out = []
    for low, high in zip(edges, edges[1:]):
        mask = (values >= low) & (values < high)
        hit = packs["y"][mask] == 1
        body = {"from": legs.cell(low),
                "to": None if not np.isfinite(high) else legs.cell(high),
                "packs": int(mask.sum()), "reversal": int(hit.sum()),
                "base": legs.cell(hit.mean()) if mask.sum() else None,
                "lift": legs.cell(hit.mean() / max(base, legs.EPS))
                if mask.sum() else None}
        if mask.sum() >= least and 0 < hit.sum() < mask.sum():
            column = packs["score"][mask]
            found = pack_unique.score_one(column[hit], column[~hit], MARK)
            sign = 1 if found["direction"] == "вище" else -1
            found.update(local_rank.at_recall(column[hit], column[~hit], sign))
            body.update({"auc": found["auc"], "precision": found["precision"],
                         "inner_lift": found["lift"]})
        out.append(body)
    return out


def run(packs: dict, buckets=BUCKETS, log=print) -> list:
    out = []
    for name, edges in buckets:
        rows = cells(packs, name, edges)
        out.append({"context": name, "hinted": name in legs.HINTED,
                    "cells": rows})
        top = max((one for one in rows if one["base"] is not None),
                  key=lambda one: one["base"])
        log(f"      {name:<12} найгустіша клітинка {top['from']}…"
            f"{top['to']}: база {top['base']}, ×{top['lift']} до загальної")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[пачки]")
    packs = gather(coins)
    base = float(packs["y"].mean())
    print(f"      усього {len(packs['y'])}, розворотів "
          f"{int(packs['y'].sum())}, база {base:.5f}")
    print("[контекст]")
    rows = run(packs)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "leg_progress.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/leg_progress.py",
        "command": "python3 research/23-reversal-signal/scripts/"
                   "leg_progress.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "mark": MARK, "recall": RECALL,
        "lead": legs.LEAD, "tail": legs.TAIL, "size": legs.SIZE,
        "look": legs.LOOK, "min_packs": MIN_PACKS, "part": "train",
        "packs": int(len(packs["y"])), "reversal": int(packs["y"].sum()),
        "base": legs.cell(base), "cut_utc": f"{CUT} 00:00:00",
        "end_utc": f"{END} 00:00:00", "pairs": list(PAIRS),
        "threshold": legs.THRESHOLD, "period": legs.PERIOD,
        "event_seconds": legs.EVENT_LENGTH, "hinted": list(legs.HINTED),
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/leg_progress.json")


if __name__ == "__main__":
    main()
