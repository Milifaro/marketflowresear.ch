"""Етап 3: чи росте сигнал з довжиною пачки.

Дослідження: research/23-reversal-signal/
Правила: rules/03-models.md → Навчання моделей

Медіана по десяти подіях має великий розкид. Якщо різниця між
розворотом і рештою — це **зсув середнього**, то з довжиною пачки шум
має падати, а поділ рости приблизно як корінь із кількості подій. Якщо
не росте — зсуву в середньому немає, і довша пачка не допоможе.

## Пачка довжини `W`

Пропорція та сама, що в дослідженні 22: сім десятих до півота, три
після.

    lead = round(0.7 · W)      tail = W − lead

Пачка розвороту — одна на півот, решта — усі пачки тієї ж довжини з
кроком в одну подію, що не торкаються зони розвороту. Пачка бере участь,
тільки якщо всі `W` подій ідуть підряд і без `NaN`, тому з ростом `W`
пачок стає менше.

## Що міряється

Ті самі десять чисел, що в етапі 1 на пульній базі: медіана сили кожної
фічі по пачці, `direct`, `inverse`, `ratio`. Для кожного `W` береться
найкраща ознака за `AUC`.

| Число | Що означає |
| ----- | ---------- |
| `auc` | поділ на цій довжині |
| `lift` | у скільки разів більше розворотів у відібраному |
| `gain` | підйом `AUC` над 0.5 відносно того, що дала довжина 10 |
| `root` | скільки цей підйом мав би бути за коренем: `sqrt(W / 10)` |

`gain` проти `root` і є відповідь: збіг означає зсув середнього, відрив
униз — що різниця сидить у хвості, а не в середньому.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/pack_length.json

Запуск:
    python3 research/23-reversal-signal/scripts/pack_length.py
    python3 research/23-reversal-signal/scripts/pack_length.py --sizes 10 40
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
import local_rank  # noqa: E402
import pack_unique  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
SIZES = (10, 20, 40, 60, 100)
SHARE = 0.7                # частка пачки до півота
RECALL = local_rank.RECALL


def split(size: int, share: float = SHARE) -> tuple:
    """Скільки подій пачки лежить до півота і скільки після."""
    lead = int(round(size * share))
    lead = min(max(lead, 1), size - 1)
    return lead, size - lead


def coin_packs(coin: dict, size: int, part: str = "train") -> dict:
    """Пачки однієї монети заданої довжини на пульній базі."""
    lead, tail = split(size)
    hit = legs.reversal_starts(coin, lead, tail, part)
    rest = legs.other_starts(coin, lead, tail, part)
    features = coin["features"]
    marks = [local_rank.pack_marks(coin["mag"], starts, features, size)
             for starts in (hit, rest)]
    return {"x": np.vstack(marks),
            "y": np.concatenate([np.ones(len(hit), dtype=np.int8),
                                 np.zeros(len(rest), dtype=np.int8)])}


def gather(coins: list, size: int, part: str = "train") -> dict:
    body = [coin_packs(coin, size, part) for coin in coins]
    return {"x": np.vstack([one["x"] for one in body]),
            "y": np.concatenate([one["y"] for one in body]),
            "names": local_rank.pack_names(coins[0]["features"])}


def one_size(coins: list, size: int, log=print) -> dict:
    """Один розмір пачки: таблиця ознак і найкраща з них."""
    started = time.time()
    packs = gather(coins, size)
    hit = packs["y"] == 1
    table = []
    for index, name in enumerate(packs["names"]):
        column = packs["x"][:, index]
        found = pack_unique.score_one(column[hit], column[~hit], name)
        if "auc" not in found:
            continue
        sign = 1 if found["direction"] == "вище" else -1
        found.update(local_rank.at_recall(column[hit], column[~hit], sign))
        table.append(found)
    table.sort(key=lambda one: -one["auc"])
    lead, tail = split(size)
    body = {"size": size, "lead": lead, "tail": tail,
            "packs": int(len(packs["y"])), "reversal": int(hit.sum()),
            "table": table, "best": table[0] if table else {},
            "seconds": round(time.time() - started, 1)}
    best = body["best"]
    log(f"      W {size:>3}: пачок {body['packs']}, розворотів "
        f"{body['reversal']}, краща `{best['mark']}` AUC {best['auc']}, "
        f"×{best['lift']} до бази — {body['seconds']} с")
    return body


def with_root(rows: list, sizes: list) -> list:
    """Підйом AUC над монеткою проти кореневого очікування."""
    if not rows:
        return rows
    first = rows[0]["best"].get("auc")
    for row in rows:
        auc = row["best"].get("auc")
        row["gain"] = legs.cell((auc - 0.5) / max(first - 0.5, legs.EPS)) \
            if auc and first else None
        row["root"] = legs.cell(float(np.sqrt(row["size"] / sizes[0])))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=list(SIZES))
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    print("[довжини]")
    rows = with_root([one_size(coins, size) for size in args.sizes],
                     args.sizes)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "pack_length.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/pack_length.py",
        "command": "python3 research/23-reversal-signal/scripts/"
                   "pack_length.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"],
        "marks": local_rank.pack_names(coins[0]["features"]),
        "share": SHARE, "sizes": list(args.sizes), "recall": RECALL,
        "part": "train", "cut_utc": f"{CUT} 00:00:00",
        "end_utc": f"{END} 00:00:00", "pairs": list(PAIRS),
        "threshold": legs.THRESHOLD, "period": legs.PERIOD,
        "event_seconds": legs.EVENT_LENGTH, "rows": rows, "ready": True},
        ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/pack_length.json")


if __name__ == "__main__":
    main()
