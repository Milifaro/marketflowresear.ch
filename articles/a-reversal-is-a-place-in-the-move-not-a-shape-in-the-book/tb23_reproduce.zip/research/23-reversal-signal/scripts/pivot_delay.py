"""Етап 6: драбина підтверджень — «чи був півот `N` подій тому».

Дослідження: research/23-reversal-signal/
Правила: rules/03-models.md → Навчання моделей

Етап 5 питав одне: «півот був три події тому» — і відповідав з точністю
25 %. Три події це 10.5 хвилини, і за такий час підтвердити розворот
нічим: зігзаг ставить півот, коли ціна пройшла 2.3 % назад, а вона за
десять хвилин стільки не проходить.

Тут те саме питання ставиться **знову і знову, з дедалі більшою
затримкою**: `N` = 3, 13, 23, … подій тому. Чим більше `N`, тим більше
ціна встигла показати, тому відповідь має гострішати. Питання етапу —
**через скільки подій відповідь стає надійною** і якою вона стає.

## Приклад і мітка

Пачка з десяти подій закінчується на події `e` — це «зараз». Мітка на
затримці `N`:

    y[e] = 1, якщо півот стоїть на події e − N

При `N = 3` це рівно мітка етапу 5, тому перший щабель драбини з ним
збігається.

Питання ставиться на **кожній події** ряду, і про **кожен** півот — на
кожному щаблі. Ніяких умов на довжину ноги, на суцільність пачки чи на
`NaN` у фічах немає: там, де пачки немає, ознаки кандидата йдуть нулями
(`nan_to_num`), а контекст ціни визначений завжди.

Це навмисно. Будь-який відбір прикладів прибирає з заміру саме ті місця,
де даних бракує, — а в роботі модель питатимуть і там теж.

## Що подається

| Набір | Що подається |
| ----- | ------------ |
| `контекст` | пʼять причинних чисел **зараз**, на події `e`, вікно `LOOK` |
| `клас+контекст` | плюс 62 ознаки пачки **кандидата** — тієї, що закінчилась на `e − N + 3` |
| `вікна` | ті самі пʼять чисел на **чотирьох** вікнах `LOOKS`: 200, 400, 800, 1600 подій |
| `вікна+клас` | чотири вікна разом з ознаками кандидата |

Чотири вікна тут не для повноти: півот зігзага — це екстремум **усієї
ноги**, а нога має медіану 423 події. Одне вікно на 400 подій не
відрізняє «максимум ноги» від «максимуму останніх чотирьох годин», і
довші вікна перевіряють, чи в цьому річ.

Клас береться біля кандидата, а не «зараз»: на події `e` пачка кандидата
вже в минулому, тож дивитись на неї можна. Контекст навпаки береться
зараз — саме в ньому лежить те, що сталося після кандидата.

## Що міряється

Ті самі числа, що в етапі 5, на кожному щаблі: `AUC`, `AP`, точність при
повноті `RECALL` і скільки це сигналів на монету за добу. Перевірка —
**відкладеною монетою**.

Вхід : data/datasets/<PAIR>/class210x10m1x7dd/{train,val}.npz
Вихід: results/pivot_delay.json

Запуск:
    python3 research/23-reversal-signal/scripts/pivot_delay.py
    python3 research/23-reversal-signal/scripts/pivot_delay.py --lags 3 43
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

RESEARCH_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_data as legs  # noqa: E402
import leg_context  # noqa: E402
import local_rank  # noqa: E402
import pack_unique  # noqa: E402
from signal_data import CUT, END, PAIRS  # noqa: E402

RESULTS = RESEARCH_DIR / "results"
LAGS = tuple(range(3, 204, 10))    # 3, 13, 23, … 203 подій тому
LOOKS = (200, 400, 800, 1600)      # вікна ковзного екстремуму
SETS = (("контекст", False, (legs.LOOK,)),
        ("клас+контекст", True, (legs.LOOK,)),
        ("вікна", False, LOOKS),
        ("вікна+клас", True, LOOKS))
RECALL = (0.2, 0.3)
SEED = legs.SEED


def coin_board(coin: dict, part: str = "train") -> dict:
    """Усе, що потрібно драбині, порахованим один раз на монету.

    `marks` — ознаки пачки за індексом її **останньої** події, `NaN`
    там, де суцільної пачки без `NaN` немає.
    """
    size = legs.SIZE
    count = len(coin["t"])
    starts = np.arange(count - size + 1)      # пачка на кожній події
    starts = starts[legs.whole_part(coin, starts, size, part)]
    base = coin["base"]
    marks = pack_unique.pack_marks(
        pack_unique.windows_of(coin["mag"], starts, size),
        pack_unique.windows_of(coin["sign"], starts, size),
        pack_unique.windows_of(np.abs(coin["x"][:, 0]) / base, starts, size),
        pack_unique.windows_of(np.abs(coin["x"][:, -1]) / base, starts, size),
        list(coin["features"]))

    board = np.full((count, marks.shape[1]), np.nan, dtype=np.float32)
    board[starts + size - 1] = marks
    side = {}
    for look in sorted({legs.LOOK} | set(LOOKS)):
        found = (coin["context"] if look == legs.LOOK
                 else legs.context_of(coin["ema"], coin["pivots"], look))
        found = dict(found)
        found["move"] = np.maximum(found["run"], found["draw"])
        side[look] = np.column_stack(
            [found[name] for name in leg_context.CONTEXT]).astype(np.float32)
    return {"pair": coin["pair"], "marks": board, "context": side,
            "ends": starts + size - 1, "count": count,
            "pivots": np.array([point.index for point in coin["pivots"]],
                               dtype=np.int64)}


def lag_rows(board: dict, lag: int) -> dict:
    """Приклади одного щабля: ознаки кандидата, контекст зараз і мітка.

    Пачка кандидата стоїть за правилом класу: `LEAD` подій до кандидата
    включно і `TAIL` після, тобто `[c − LEAD + 1, c + TAIL]`, де
    `c = e − N`. `board` тримає пачку за її **останньою** подією, тому
    береться `c + TAIL`.

    Так пачка не заходить у майбутнє: остання її подія `e − N + TAIL` не
    пізніша за «зараз», поки `N` не менше за `TAIL`.

    Питання ставиться на кожній події, де пачка кандидата вміщається в
    ряд. Жодного відбору за суцільністю чи `NaN`: де ознак немає, вони
    підуть нулями, а контекст визначений завжди.
    """
    ends = board["ends"]
    place = ends - lag + legs.TAIL       # остання подія пачки кандидата
    keep = (place >= 0) & (place < board["count"])
    ends, place = ends[keep], place[keep]
    label = np.isin(ends - lag, board["pivots"]).astype(np.int8)
    return {"marks": board["marks"][place],
            "context": {look: values[ends]
                        for look, values in board["context"].items()},
            "y": label, "ends": ends}


def gather(boards: list, lag: int) -> dict:
    body = [lag_rows(one, lag) for one in boards]
    return {"marks": np.vstack([one["marks"] for one in body]),
            "context": {look: np.vstack([one["context"][look]
                                         for one in body])
                        for look in body[0]["context"]},
            "y": np.concatenate([one["y"] for one in body]),
            "coin": np.concatenate([np.full(len(one["y"]), index, np.int16)
                                    for index, one in enumerate(body)]),
            "days": sum(len(one["y"]) for one in body)
            * legs.EVENT_LENGTH / 86400}


def one_lag(boards: list, lag: int, sets=SETS, seed: int = SEED,
            log=print) -> dict:
    """Один щабель драбини: кожен набір входів своєю моделлю."""
    packs = gather(boards, lag)
    body = {"lag": lag, "minutes": round(lag * legs.EVENT_LENGTH / 60, 1),
            "packs": int(len(packs["y"])), "reversal": int(packs["y"].sum()),
            "days": legs.cell(packs["days"]), "sets": []}
    if body["reversal"] < 2:
        log(f"      N {lag:>3}: розворотів {body['reversal']} — пропуск")
        return body
    for name, wide, looks in sets:
        started = time.time()
        columns = [packs["context"][look] for look in looks]
        if wide:
            columns.insert(0, packs["marks"])
        x = np.nan_to_num(np.hstack(columns), nan=0.0, posinf=0.0,
                          neginf=0.0)
        score = leg_context.out_of_coin(x, packs["y"], packs["coin"], seed)
        found = {"set": name, "columns": int(x.shape[1]),
                 "looks": list(looks)}
        found.update(leg_context.measure(packs["y"], score))
        found["curve"] = leg_context.curve_of(packs["y"], score,
                                              packs["days"], RECALL)
        found["seconds"] = round(time.time() - started, 1)
        body["sets"].append(found)
    best = body["sets"][0]["curve"][-1]
    log(f"      N {lag:>3} ({body['minutes']:>5.0f} хв): розворотів "
        f"{body['reversal']:>3}, точність {best['precision']}, "
        f"×{best['lift']} до бази, сигналів/добу {best['per_day']}")
    return body


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lags", type=int, nargs="+", default=list(LAGS))
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=RESULTS)
    args = parser.parse_args()

    print("[монети]")
    coins = legs.collect(args.data)
    lengths = np.array([one["events"] for coin in coins
                        for one in coin["legs"]])
    print(f"      ніг {len(lengths)}, подій у нозі: медіана "
          f"{np.median(lengths):.0f}, чверть {np.quantile(lengths, 0.25):.0f}, "
          f"три чверті {np.quantile(lengths, 0.75):.0f}")
    boards = [coin_board(coin) for coin in coins]
    print("[драбина]")
    rows = [one_lag(boards, lag, seed=args.seed) for lag in args.lags]

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "pivot_delay.json").write_text(json.dumps({
        "script": "research/23-reversal-signal/scripts/pivot_delay.py",
        "command": "python3 research/23-reversal-signal/scripts/"
                   "pivot_delay.py",
        "class": legs.CLASS, "class_title": "клас210х10-1х7д/д",
        "features": coins[0]["features"], "part": "train",
        "lags": list(args.lags),
        "recall_grid": list(RECALL),
        "sets": [name for name, _, _ in SETS], "looks": list(LOOKS),
        "size": legs.SIZE, "lead": legs.LEAD, "tail": legs.TAIL,
        "look": legs.LOOK, "seed": args.seed,
        "context_names": list(leg_context.CONTEXT),
        "leg_events": {"legs": int(len(lengths)),
                       "median": legs.cell(np.median(lengths)),
                       "low": legs.cell(np.quantile(lengths, 0.25)),
                       "high": legs.cell(np.quantile(lengths, 0.75))},
        "cut_utc": f"{CUT} 00:00:00", "end_utc": f"{END} 00:00:00",
        "pairs": list(PAIRS), "threshold": legs.THRESHOLD,
        "period": legs.PERIOD, "event_seconds": legs.EVENT_LENGTH,
        "rows": rows, "ready": True}, ensure_ascii=False), encoding="utf-8")
    print(f"записано {args.out}/pivot_delay.json")


if __name__ == "__main__":
    main()
